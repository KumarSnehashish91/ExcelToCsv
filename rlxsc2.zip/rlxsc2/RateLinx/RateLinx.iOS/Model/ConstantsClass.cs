﻿using System;
using CoreGraphics;
using UIKit;

namespace RateLinx.iOS
{
	public static class ConstantsClass
	{//string[] strMnuText={"Home","AboutUs","Products","Events","Serivce","Clients","Help","Solution","ContactUs"};

		public static string[] arrMenuText = new string[] { "Home", "AboutUs", "Products", "Events", "Serivce", "Clients", "Help", "Solution", "ContactUs", "" };
		public static string[] arrMenuIcon = new string[] { "Images/icon_home", "Images/icon_aboutus", "Images/icon_product", "Images/icon_event", "Images/icon_service", "Images/icon_client", "Images/icon_help", "Images/icon_solution", "Images/icon_contactus", "" };
		//-----------Font And Co-ordinates  --------------//
		public static float fontSize = 12f;
		public const int xCoordinate = 101;
		public const int delay = 5000;
		public const int trackingDelay = 300000;
		public const double animationDuration = 0.5;
		//---------------End ------------------------//
		public const string strDone = "Done";
		public const string strVoid = "Are you sure you want to void this shipment?";
		public const string strEnterReason = "Enter Reason";
		public const string strBlock = "Are you sure you want to block payment of this shipment?";
		public const string strCompose = "compose";
		public const string strReply = "reply";
		public const string strBid = "bid";
		public const string strSupport = "Support";
		public const string strHistory = "history";
		public const string strReplyMsg = "Please enter the message for reply";
		public const string shipping = "Shipping";
		public const string iOS = "iOS";
		public const string strRateEntriesChareg = "Rate Entries - Charges Detail";
		public const string strRateEntriesComment = "Rate Entries - Comment";
		public const string strTruckRequest = "TRUCKLOAD Request";
		public const string croxSign = "X";
		//----------Awarded Shipment---------------//
		public const string AwardedFor = " for ";
		public const string lblFor = "For:";
		public const string lblFrom = "From: ";
		public const string lblTo = "To:";
		public const string lblPickup = "Pickup:";
		public const string lblDriverID = "DriverID:";
		public const string lblDeliver = "Deliver:";
		public const string lblEmail = "Email:";
		public const string lblPhone = "Phone:";
		//------Line Detail Adpter--------//
		public const string lineNum = "LineNum";
		public const string pallets = "Pallets";//
		public const string pieces = "Pieces";
		public const string UOM = "UOM";
		public const string item = "Item";
		public const string descr = "Descr";
		public const string length = "Length";
		public const string strClass = "Class";
		public const string FAK = "FAK";
		public const string weight = "Weight";
		//------Rate Detail Adapter--------------//
		public const string address = "Address";
		public const string addressTo = " To ";
		public const string commodities = "Commodities: ";
		public const string options = "Options: ";
		public const string pickupDelivery = "Pickup/Delivery";
		public const string assignDriver = "Assign Driver:";
		public const string usercredentials = "UserCredentials";
		public static int currentTab = 1;

		public static bool appInBackGround = false;

		#region color codes 

		internal static UIColor tableRowOddColor = UIColor.FromRGB(224, 223, 223);

		internal static UIColor tableRowEvenColor = UIColor.FromRGB(240, 239, 239);

		internal static UIColor awardShipOddColor = UIColor.FromRGB(236, 234, 234);

		internal static UIColor awardShipEvenColor = UIColor.FromRGB(216, 215, 215);

		internal static UIColor shipmentHeadColor = UIColor.FromRGB(35, 32, 27);

		internal static UIColor btnColorRed = UIColor.FromRGB(137, 18, 40);

		internal static UIColor btnColorBlue = UIColor.FromRGB(66, 139, 202);

		internal static UIColor conversationHeadClr = UIColor.FromRGB(48, 43, 37);

		internal static UIColor separatorClr = UIColor.FromRGB(157, 34, 53);

		internal static UIColor historyColumnBGC = UIColor.FromRGB(58, 55, 53);

		internal static UIColor fileHeadBGC = UIColor.FromRGB(75, 72, 69);

		internal static UIColor viewClr1 = UIColor.FromRGB(206, 205, 205);

		internal static UIColor viewClr2 = UIColor.FromRGB(232, 232, 232);

		internal static UIColor saveTrackInfoBGC = UIColor.FromRGB(116, 2, 30);

		internal static UIColor txtForeGroundCLR = UIColor.FromRGB(220, 220, 220);
		internal static UIColor viewLiveTracking = UIColor.FromRGB(216, 215, 215);
		internal static UIColor viewAutomaticTracking = UIColor.FromRGB(236, 234, 234);
		#endregion

		#region Frame

		internal static CGRect viewFrmae = new CGRect(0, 0, 10, 40);
		internal static CGRect lblDashipmentFrmae = new CGRect(20, 0, 100, 50);
		internal static CGRect imageview = new CGRect(10, 11, 25, 20);
		internal static CGRect lblEquipmentFrmae = new CGRect(40, 6, 150, 24);
		internal static CGRect checkLiveTrackingFrmae = new CGRect(10, 12, 25, 25);
		internal static CGRect lblEnableTrackText = new CGRect(10, 12, 15, 15);
		internal static CGRect switchFrame = new CGRect(0, 10, 100, 100);
		#endregion


		internal static string dateFormatMMddyy = "MM/dd/yy";
		internal static string dateFormatYYYYDDMM = "yyyy/dd/MM";

		internal static string dateFormatMMDDYYYY= "MM/dd/yyyy";
		internal const string yearRateHistory = "20";
	}
}

