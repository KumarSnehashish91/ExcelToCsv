﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Foundation;
using UIKit;
using CoreLocation;
using RateLinx.iOS;

namespace RateLinx.iOS
{
	public class LocationManager
	{
		protected CLLocationManager locMgr;
		public event EventHandler<LocationUpdatedEventArgs> LocationUpdated = delegate { };
		public LocationManager()
		{
			this.locMgr = new CLLocationManager();
            this.locMgr.PausesLocationUpdatesAutomatically = true;
			// iOS 8 has additional permissions requirements
			if (UIDevice.CurrentDevice.CheckSystemVersion(8, 0))
			{
				locMgr.RequestAlwaysAuthorization(); // works in background
				//locMgr.RequestWhenInUseAuthorization (); // only in foreground
			}
			if (UIDevice.CurrentDevice.CheckSystemVersion(9, 0))
			{

                locMgr.AllowsBackgroundLocationUpdates = false;
			}
			//LocationUpdated += PrintLocation;
		}

		public CLLocationManager LocMgr
		{
			get { return this.locMgr; }
		}

		//public void StartLocationUpdates()
		//{
		//	// We need the user's permission for our app to use the GPS in iOS. This is done either by the user accepting
		//	// the popover when the app is first launched, or by changing the permissions for the app in Settings
		//	if (CLLocationManager.LocationServicesEnabled)
		//	{

		//		//set the desired accuracy, in meters
  //              LocMgr.DesiredAccuracy = CLLocation.AccuracyKilometer;

		//		LocMgr.LocationsUpdated += (object sender, CLLocationsUpdatedEventArgs e) => {
		//			// fire our custom Location Updated event
		//			LocationUpdated(this, new LocationUpdatedEventArgs(e.Locations[e.Locations.Length - 1]));
		//		};

		//		LocMgr.StartUpdatingLocation();
		//	}
		//}

		//public void PrintLocation(object sender, LocationUpdatedEventArgs e)
		//{
		//	try
		//	{
		//		CLLocation location = e.Location;
		//		Util.location = location;
		//		//			Console.WriteLine("Altitude: " + location.Altitude + " meters");
		//		//			Console.WriteLine("Longitude: " + location.Coordinate.Longitude);
		//		//			Console.WriteLine("Latitude: " + location.Coordinate.Latitude);
		//		//			Console.WriteLine("Course: " + location.Course);
		//		//			Console.WriteLine("Speed: " + location.Speed);
		//		//
		//		//			NSUserDefaults.StandardUserDefaults.SetString(location.Coordinate.Longitude.ToString(), "Longitude");
		//		//			NSUserDefaults.StandardUserDefaults.SetString(location.Coordinate.Latitude.ToString(), "Latitude");
		//	}
		//	catch (Exception ex)
		//	{
		//		Console.Write(ex.Message);
		//	}
		//}
	}
}