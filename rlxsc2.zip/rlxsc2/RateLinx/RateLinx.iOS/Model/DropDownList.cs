﻿using System;

namespace RateLinx.iOS
{
	public class DropDownList
	{
		public string Id { 
			get; set; 
		}
		public string DisplayText {
			get;
			set;
		}

		public bool IsSelected {
			get;
			set;
		}
	}
}

