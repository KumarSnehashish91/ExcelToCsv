﻿using System;
namespace RateLinx.iOS
{
	public class ComposeTo
	{
		public string strComposeTo { get; set;}

		public bool selected { get; set; }

		public ComposeTo(string strComposeTo, bool selected)
		{
			this.strComposeTo = strComposeTo;
			this.selected = selected;
		}
	}
}
