﻿using System;
using UIKit;

namespace RateLinx.iOS
{
    public class ModalPickerTransitionDelegate : UIViewControllerTransitioningDelegate
    {
        public ModalPickerTransitionDelegate()
        {
        }
        /// <summary>
        /// override method for Get Animation Controller for present
        /// </summary>
        /// <param name="presented"></param>
        /// <param name="presenting"></param>
        /// <param name="source"></param>
        /// <returns></returns>
		public override IUIViewControllerAnimatedTransitioning GetAnimationControllerForPresentedController(UIViewController presented, UIViewController presenting, UIViewController source)
        {
            var controller = new ModalPickerAnimatedTransitioning();
            controller.IsPresenting = true;

            return controller;
        }
        /// <summary>
        /// override method for Get Animation Controller for dismiss
        /// </summary>
        /// <param name="dismissed"></param>
        /// <returns></returns>
		public override IUIViewControllerAnimatedTransitioning GetAnimationControllerForDismissedController(UIViewController dismissed)
        {
            var controller = new ModalPickerAnimatedDismissed();
            controller.IsPresenting = false;

            return controller;
        }
        /// <summary>
        /// override method for Get Animation Controller for presentation
        /// </summary>
        /// <param name="animator"></param>
        /// <returns></returns>
		public override IUIViewControllerInteractiveTransitioning GetInteractionControllerForPresentation(IUIViewControllerAnimatedTransitioning animator)
        {
            return null;
        }
        /// <summary>
        /// override method for Get Animation Controller for Dismissal
        /// </summary>
        /// <param name="animator"></param>
        /// <returns></returns>
		public override IUIViewControllerInteractiveTransitioning GetInteractionControllerForDismissal(IUIViewControllerAnimatedTransitioning animator)
        {
            return null;
        }
    }
}

