﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace RateLinx.iOS
{
    /// <summary>
    /// 
    /// </summary>
    public class RateHistoryResult
    {
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "Client ID")]
        public string ClientID { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "Loc ID")]
        public int LocID { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Mode { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "Rate Type")]
        public string RateType { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "Load Num")]
        public string LoadNum { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "Auction Status")]
        public string AuctionStatus { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "Rate Status")]
        public string RateStatus { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "Date Opened")]
        public string DateOpened { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "Rate Deadline")]
        public string RateDeadline { get; set; }

        /// <summary>
        /// Gets or sets the ship from.
        /// </summary>
        /// <value>The ship from.</value>
        [JsonProperty(PropertyName = "Ship From")]
        public string ShipFrom { get; set; }

        /// <summary>
        /// Gets or sets the ship to.
        /// </summary>
        /// <value>The ship to.</value>
        [JsonProperty(PropertyName = "Ship To")]
        public string ShipTo { get; set; }
        /// <summary>
        /// Gets or sets the pickup.
        /// </summary>
        /// <value>The pickup.</value>
        public string Pickup { get; set; }
        /// <summary>
        /// Gets or sets the reference.
        /// </summary>
        /// <value>The reference.</value>
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets the user created.
        /// </summary>
        /// <value>The user created.</value>
        [JsonProperty(PropertyName = "User Created")]
        public string UserCreated { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="T:RateLinx.iOS.RateHistoryResult"/> is check box checked.
        /// </summary>
        /// <value><c>true</c> if is check box checked; otherwise, <c>false</c>.</value>
        public bool isCheckBoxChecked { get; set; }
    }
}