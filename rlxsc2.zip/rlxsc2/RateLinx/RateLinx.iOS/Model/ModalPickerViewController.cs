﻿using System;
using UIKit;
using CoreGraphics;
using Foundation;

namespace RateLinx.iOS
{
    public delegate void ModalPickerDimissedEventHandler(object sender, EventArgs e);

    public class ModalPickerViewController : UIViewController
    {
        public event ModalPickerDimissedEventHandler OnModalPickerDismissed;
        private const float HeaderBarHeight = 40;

        public UIColor HeaderBackgroundColor { get; set; }
        public UIColor HeaderTextColor { get; set; }
        public string HeaderText { get; set; }
        public string DoneButtonText { get; set; }
        public string CancelButtonText { get; set; }

        public UIDatePicker DatePicker { get; set; }
        public UIPickerView PickerView { get; set; }
        private ModalPickerType pickerType;
        public ModalPickerType PickerType
        {
            get { return pickerType; }
            set
            {
                switch (value)
                {
                    case ModalPickerType.Date:
                        DatePicker = new UIDatePicker(CGRect.Empty);
                        PickerView = null;
                        break;
                    case ModalPickerType.Custom:
                        DatePicker = null;
                        PickerView = new UIPickerView(CGRect.Empty);
                        break;
                    default:
                        break;
                }

                pickerType = value;
            }
        }

        private UILabel headerLabel;
        private UIButton doneButton;
        private UIButton cancelButton;
        private UIViewController parent;
        private UIView internalView;
        /// <summary>
        /// constructor for model picker view controller
        /// </summary>
        /// <param name="pickerType"></param>
        /// <param name="headerText"></param>
        /// <param name="parent"></param>
		public ModalPickerViewController(ModalPickerType pickerType, string headerText, UIViewController parent)
        {
			HeaderBackgroundColor = UIColor.White;
            HeaderTextColor = UIColor.Black;
            HeaderText = headerText;
            PickerType = pickerType;
            this.parent = parent;
            DoneButtonText = NSBundle.MainBundle.LocalizedString("done", null);
            CancelButtonText = NSBundle.MainBundle.LocalizedString("cancel", null);
        }
        /// <summary>
        /// method for did load
        /// </summary>
		public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            InitializeControls();
        }
        /// <summary>
        /// method for view will Appear
        /// </summary>
        /// <param name="animated"></param>
		public override void ViewWillAppear(bool animated)
        {
            base.ViewDidAppear(animated);

            Show();
        }
        /// <summary>
        /// method to initialize controls
        /// </summary>
        public void InitializeControls()
        {
			View.BackgroundColor = UIColor.Clear;
            internalView = new UIView();

            headerLabel = new UILabel(new CGRect(0, 0, 320 / 2, 44));
            headerLabel.AutoresizingMask = UIViewAutoresizing.FlexibleWidth;
            headerLabel.BackgroundColor = HeaderBackgroundColor;
            headerLabel.TextColor = HeaderTextColor;
            headerLabel.Text = HeaderText;
            headerLabel.TextAlignment = UITextAlignment.Center;

            cancelButton = UIButton.FromType(UIButtonType.System);
            cancelButton.SetTitleColor(HeaderTextColor, UIControlState.Normal);
            cancelButton.BackgroundColor = UIColor.Clear;
            cancelButton.SetTitle(CancelButtonText, UIControlState.Normal);
            cancelButton.TouchUpInside += CancelButtonTapped;

            doneButton = UIButton.FromType(UIButtonType.System);
			doneButton.SetTitleColor(HeaderTextColor, UIControlState.Normal);
            doneButton.BackgroundColor = UIColor.Clear;
            doneButton.SetTitle(DoneButtonText, UIControlState.Normal);
            doneButton.TouchUpInside += DoneButtonTapped;

            switch (PickerType)
            {
                case ModalPickerType.Date:
                    DatePicker.BackgroundColor = UIColor.White;
                    internalView.AddSubview(DatePicker);
                    break;
                case ModalPickerType.Custom:
				PickerView.BackgroundColor = UIColor.Green;
                    internalView.AddSubview(PickerView);
                    break;
                default:
                    break;
            }
            internalView.BackgroundColor = HeaderBackgroundColor;

            internalView.AddSubview(headerLabel);
            internalView.AddSubview(cancelButton);
            internalView.AddSubview(doneButton);

            Add(internalView);
        }
        /// <summary>
        /// method to show 
        /// </summary>
        /// <param name="onRotate"></param>
        public void Show(bool onRotate = false)
        {
            var buttonSize = new CGSize(71, 30);

            var width = parent.View.Frame.Width;

            var internalViewSize = CGSize.Empty;
            switch (pickerType)
            {
                case ModalPickerType.Date:
                    internalViewSize = new CGSize(width, DatePicker.Frame.Height + HeaderBarHeight);
                    break;
                case ModalPickerType.Custom:
                    internalViewSize = new CGSize(width, PickerView.Frame.Height + HeaderBarHeight);
                    break;
                default:
                    break;
            }

            var internalViewFrame = CGRect.Empty;
            if (InterfaceOrientation == UIInterfaceOrientation.Portrait)
            {
                if (onRotate)
                {
                    internalViewFrame = new CGRect(0, View.Frame.Height - internalViewSize.Height,
                        internalViewSize.Width, internalViewSize.Height);
                }
                else
                {
                    internalViewFrame = new CGRect(0, View.Bounds.Height - internalViewSize.Height,
                        internalViewSize.Width, internalViewSize.Height);
                }
            }
            else
            {
                if (onRotate)
                {
                    internalViewFrame = new CGRect(0, View.Bounds.Height - internalViewSize.Height,
                        internalViewSize.Width, internalViewSize.Height);
                }
                else
                {
                    internalViewFrame = new CGRect(0, View.Frame.Height - internalViewSize.Height,
                        internalViewSize.Width, internalViewSize.Height);
                }
            }
            internalView.Frame = internalViewFrame;

            switch (pickerType)
            {
                case ModalPickerType.Date:
                    DatePicker.Frame = new CGRect(DatePicker.Frame.X, HeaderBarHeight, internalView.Frame.Width,
                        DatePicker.Frame.Height);
                    break;
                case ModalPickerType.Custom:
                    PickerView.Frame = new CGRect(PickerView.Frame.X, HeaderBarHeight, internalView.Frame.Width,
                        PickerView.Frame.Height);
                    break;
                default:
                    break;
            }

            headerLabel.Frame = new CGRect(20 + buttonSize.Width, 4, parent.View.Frame.Width - (40 + (2 * buttonSize.Width)), 35);
            doneButton.Frame = new CGRect(internalViewFrame.Width - buttonSize.Width - 10, 7, buttonSize.Width, buttonSize.Height);
            cancelButton.Frame = new CGRect(10, 7, buttonSize.Width, buttonSize.Height);
        }
        /// <summary>
        /// method to Done Button tap event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		public void DoneButtonTapped(object sender, EventArgs e)
        {
            DismissViewController(true, null);
            if (OnModalPickerDismissed != null)
            {
                OnModalPickerDismissed(sender, e);
            }
        }
        /// <summary>
        /// event on cancel button tapped
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void CancelButtonTapped(object sender, EventArgs e)
        {
            DismissViewController(true, null);
        }
        /// <summary>
        /// override method for did Rotate
        /// </summary>
        /// <param name="fromInterfaceOrientation"></param>
		public override void DidRotate(UIInterfaceOrientation fromInterfaceOrientation)
        {
            base.DidRotate(fromInterfaceOrientation);

            if (InterfaceOrientation == UIInterfaceOrientation.Portrait ||
                InterfaceOrientation == UIInterfaceOrientation.LandscapeLeft ||
                InterfaceOrientation == UIInterfaceOrientation.LandscapeRight)
            {
                Show(true);
                View.SetNeedsDisplay();
            }
        }
    }
    /// <summary>
    /// enum for modal picker type
    /// </summary>
	public enum ModalPickerType
    {
        Date = 0,
        Custom = 1
    }
}

