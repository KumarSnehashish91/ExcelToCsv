using System;
using System.Collections.Generic;
using CoreGraphics;
using Foundation;
using RateLinx.Helper;
using RateLinx.Models;
using UIKit;

namespace RateLinx.iOS
{
	class ComposeToListAdapter : UITableViewSource
	{
		List<AllowedConversationToList> AllowedConversationToList;

		public ComposeToListAdapter(List<AllowedConversationToList> AllowedConversationToList)
		{
			CommanUtil.lstAllowedConversationList = null;
			CommanUtil.lstAllowedConversationList = new List<CustomerConversationList>();
			foreach (AllowedConversationToList objAllowedList in AllowedConversationToList)
			{
				CommanUtil.lstAllowedConversationList.Add(new CustomerConversationList { Action = objAllowedList.Action, Value = objAllowedList.Value, Key = objAllowedList.Key });
			}
			this.AllowedConversationToList = AllowedConversationToList;

		}
		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			UITableViewCell objTableCell = new UITableViewCell(new CGRect(0, 0, tableView.Frame.Width, 30));

			UIView viewForPicker = new UIView(new CGRect(0, 0, tableView.Frame.Width, 30));
			viewForPicker.UserInteractionEnabled = true;

			UILabel lblOption = new UILabel(new CGRect(10, 0, tableView.Frame.Width - 60, 30));
			lblOption.Text = AllowedConversationToList[indexPath.Row].Value;

			UIButton btnSelectOption = new UIButton();
			btnSelectOption.Frame = new CGRect(tableView.Frame.Width - 40, 4, 22, 22);
			btnSelectOption.BackgroundColor = UIColor.White;
			btnSelectOption.Layer.CornerRadius = 2;
			btnSelectOption.Layer.BorderWidth = 2;
			btnSelectOption.UserInteractionEnabled = true;





			if (AllowedConversationToList[indexPath.Row].Action == false)
			{
				btnSelectOption.SetBackgroundImage(null, UIControlState.Normal);
			}
			else
			{
				btnSelectOption.SetBackgroundImage(new UIImage("Images/CheckMark.png"), UIControlState.Normal);
			}

			btnSelectOption.TouchUpInside += delegate
			{
				SelectCarriers(btnSelectOption, indexPath.Row);
			};

			viewForPicker.AddSubviews(lblOption, btnSelectOption);
			objTableCell.AddSubview(viewForPicker);
			return objTableCell;

		}
		void SelectCarriers(UIButton btnSelectOption, nfloat row)
		{
			if (CommanUtil.lstAllowedConversationList[(int)row].Action == false)
			{
				btnSelectOption.SetBackgroundImage(new UIImage("Images/CheckMark.png"), UIControlState.Normal);
				//AllowedConversationToList[(int)row].Action = true;

				//CommanUtil.lstAllowedConversationList.Add(AllowedConversationToList[(int)row]);
				CommanUtil.lstAllowedConversationList[(int)row].Action = true;
			}
			else
			{
				btnSelectOption.SetBackgroundImage(null, UIControlState.Normal);
				CommanUtil.lstAllowedConversationList[(int)row].Action = false;

				//CommanUtil.lstAllowedConversationList.RemoveAt((int)row);
			}
		}


		public override nint RowsInSection(UITableView tableview, nint section)
		{

//lstAllowedConversationList
			return AllowedConversationToList.Count;
		}
	}

	
}