using Foundation;
using System;
using UIKit;

namespace RateLinx.iOS
{
    public partial class Web : UIViewController
    {
        public Web (IntPtr handle) : base (handle)
        {
        }
    }
}