// WARNING
//
// This file has been generated automatically by Xamarin Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace RateLinx.iOS
{
    [Register ("CustCellActiveShipments")]
    partial class CustCellActiveShipments
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView ActiveShipmentTableHeader { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnActiveHeader { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblActiveDeadline { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblActiveFor { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblActiveFrom { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblActiveLeftHead { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblActiveMode { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblActivePickup { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblActiveTo { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITableView tblBidDetails { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewNoBids { get; set; }

        [Action ("BtnActiveHeader_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnActiveHeader_TouchUpInside (UIKit.UIButton sender);

        void ReleaseDesignerOutlets ()
        {
            if (ActiveShipmentTableHeader != null) {
                ActiveShipmentTableHeader.Dispose ();
                ActiveShipmentTableHeader = null;
            }

            if (btnActiveHeader != null) {
                btnActiveHeader.Dispose ();
                btnActiveHeader = null;
            }

            if (lblActiveDeadline != null) {
                lblActiveDeadline.Dispose ();
                lblActiveDeadline = null;
            }

            if (lblActiveFor != null) {
                lblActiveFor.Dispose ();
                lblActiveFor = null;
            }

            if (lblActiveFrom != null) {
                lblActiveFrom.Dispose ();
                lblActiveFrom = null;
            }

            if (lblActiveLeftHead != null) {
                lblActiveLeftHead.Dispose ();
                lblActiveLeftHead = null;
            }

            if (lblActiveMode != null) {
                lblActiveMode.Dispose ();
                lblActiveMode = null;
            }

            if (lblActivePickup != null) {
                lblActivePickup.Dispose ();
                lblActivePickup = null;
            }

            if (lblActiveTo != null) {
                lblActiveTo.Dispose ();
                lblActiveTo = null;
            }

            if (tblBidDetails != null) {
                tblBidDetails.Dispose ();
                tblBidDetails = null;
            }

            if (viewNoBids != null) {
                viewNoBids.Dispose ();
                viewNoBids = null;
            }
        }
    }
}