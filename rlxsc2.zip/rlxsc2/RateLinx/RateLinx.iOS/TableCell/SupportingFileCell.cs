using Foundation;
using System;
using UIKit;
using RateLinx.Helper;
using CoreGraphics;

namespace RateLinx.iOS
{
	partial class SupportingFileCell : UITableViewCell
	{
		int fileIndex = 0;
		ShipmentDetailController objShipmentDetailController;
		public SupportingFileCell(IntPtr handle) : base(handle)
		{
		}
		public void UpdateCell(string objFileDetails, int rowNumber,ShipmentDetailController shipmentDetailController, UITableView tableView)
		{
			try
			{
				lblFileDetail.Frame = new CGRect(0, 0, tableView.Frame.Width, 30);
				btnFileName.Frame = new CGRect(0, 0, tableView.Frame.Width, 30);
                this.objShipmentDetailController = shipmentDetailController;
				fileIndex = rowNumber;
				UIColor objColorCode = null;
				if (rowNumber % 2 == 0)
				{
					objColorCode = UIColor.FromRGB(224, 223, 223);
				}
				else
				{
					objColorCode = UIColor.FromRGB(240, 239, 239);
				}
				//File Name
				int cutFileName = objFileDetails.LastIndexOf('/');
				if (cutFileName != -1)
				{
					lblFileDetail.Text = "    " + objFileDetails.Substring(cutFileName + 1);
				}
				lblFileDetail.Font = UIFont.FromName(Constants.strFontName, 11.0f);
				lblFileDetail.BackgroundColor = objColorCode;
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Buttons the file name touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnFileName_TouchUpInside(UIButton sender)
		{
			try
			{
				//string ddff = "sadas";
				objShipmentDetailController.RedirectToWebView(fileIndex);
			}
			catch(Exception ex)
			{
				string message = ex.Message;
			}
		}

	}
}