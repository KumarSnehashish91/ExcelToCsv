using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;
using System.Collections.Generic;
using CoreGraphics;
using RateLinx.Models;
using RateLinx.Helper;

namespace RateLinx.iOS
{
    partial class OrderHistoryCell : UITableViewCell
    {

        public OrderHistoryCell(IntPtr handle) : base(handle)
        {
        }

        public void UpdateCell(OrderHistory objRateHistoryResult, int rowNumber)
        {
            

            UIColor objColorCode = null;
            if (rowNumber % 2 == 0)
            {
                objColorCode = UIColor.FromRGB(224, 223, 223);
            }
            else
            {
                objColorCode = UIColor.FromRGB(240, 239, 239);
            }

            UIView viewSelectOrder = new UIView();
            viewSelectOrder.Frame = new CGRect(0, 0, 75, viewRowOrderHistory.Frame.Height);
            viewSelectOrder.BackgroundColor = objColorCode;

            UIButton btnCheck = new UIButton(new CGRect(20, 13, 23, 23));
            btnCheck.BackgroundColor = UIColor.White;
            btnCheck.Layer.CornerRadius = 2;
            btnCheck.Layer.BorderWidth = 2;
            btnCheck.TouchUpInside += delegate
            {
                if (objRateHistoryResult.isCheckBoxChecked)
                {
                    btnCheck.SetBackgroundImage(null, UIControlState.Normal);
                    objRateHistoryResult.isCheckBoxChecked = false;
                }
                else
                {
                    btnCheck.SetBackgroundImage(new UIImage("Images/CheckMark.png"), UIControlState.Normal);
                    objRateHistoryResult.isCheckBoxChecked = true;
                }
            };
            if (objRateHistoryResult.isCheckBoxChecked)
            {
                btnCheck.SetBackgroundImage(new UIImage("Images/CheckMark.png"), UIControlState.Normal);
            }
            else
            {
                btnCheck.SetBackgroundImage(null, UIControlState.Normal);
            }
            viewSelectOrder.AddSubview(btnCheck);
            viewRowOrderHistory.AddSubview(viewSelectOrder);
            viewRowOrderHistory.BackgroundColor = objColorCode;

            nfloat marginBtwCol = 2;
            nfloat XPosition = 77;

            UILabel OrderID = new UILabel(new CGRect(XPosition, 1, 80, 50));
            OrderID.Text = objRateHistoryResult.OrderID;        
            OrderID.TextColor = UIColor.Black;
            OrderID.Font = UIFont.FromName(Constants.strFontName, 14.0f);
            OrderID.TextAlignment = UITextAlignment.Center;
            OrderID.LineBreakMode = UILineBreakMode.WordWrap;
            OrderID.BackgroundColor = objColorCode;


            XPosition += OrderID.Frame.Width + marginBtwCol;

            UILabel StoreID = new UILabel(new CGRect(XPosition, 1, 80, 50));
            StoreID.Text = objRateHistoryResult.StoreID;            
            StoreID.TextColor = UIColor.Black;
            StoreID.Font = UIFont.FromName(Constants.strFontName, 14.0f);
            StoreID.TextAlignment = UITextAlignment.Center;
            StoreID.LineBreakMode = UILineBreakMode.WordWrap;
            StoreID.BackgroundColor = objColorCode;

            XPosition += StoreID.Frame.Width + marginBtwCol;

            UILabel Status = new UILabel(new CGRect(XPosition, 1, 100, 50));
            Status.Text = objRateHistoryResult.Status;           
            Status.TextColor = UIColor.Black;
            Status.Font = UIFont.FromName(Constants.strFontName, 14.0f);
            Status.TextAlignment = UITextAlignment.Center;
            Status.LineBreakMode = UILineBreakMode.WordWrap;
            Status.BackgroundColor = objColorCode;

            XPosition += Status.Frame.Width + marginBtwCol;

            UILabel OrderDate = new UILabel(new CGRect(XPosition, 1, 170, 50));
            OrderDate.Text = Convert.ToString(objRateHistoryResult.OrderDate);          
            OrderDate.TextColor = UIColor.Black;
            OrderDate.Font = UIFont.FromName(Constants.strFontName, 14.0f);
            OrderDate.TextAlignment = UITextAlignment.Center;
            OrderDate.LineBreakMode = UILineBreakMode.CharacterWrap;
            OrderDate.BackgroundColor = objColorCode;

            XPosition += OrderDate.Frame.Width + marginBtwCol;

            UILabel ShipTo_Attention = new UILabel(new CGRect(XPosition, 1, 150, 50));
            ShipTo_Attention.Text = objRateHistoryResult.ShipTo_Attention;         
            ShipTo_Attention.TextColor = UIColor.Black;
            ShipTo_Attention.Font = UIFont.FromName(Constants.strFontName, 14.0f);
            ShipTo_Attention.TextAlignment = UITextAlignment.Center;
            ShipTo_Attention.LineBreakMode = UILineBreakMode.CharacterWrap;
            ShipTo_Attention.BackgroundColor = objColorCode;

            XPosition += ShipTo_Attention.Frame.Width + marginBtwCol;

            UILabel ShipTo_Company = new UILabel(new CGRect(XPosition, 1, 171, 50));
            ShipTo_Company.Text = "Ship to Company";//            
            ShipTo_Company.TextColor = UIColor.Black;
            ShipTo_Company.Font = UIFont.FromName(Constants.strFontName, 14.0f);
            ShipTo_Company.TextAlignment = UITextAlignment.Center;
            ShipTo_Company.LineBreakMode = UILineBreakMode.CharacterWrap;
            ShipTo_Company.BackgroundColor = objColorCode;

            XPosition += ShipTo_Company.Frame.Width;

            viewRowOrderHistory.Frame = new CGRect(0, 0, XPosition, 50);
            viewRowOrderHistory.BackgroundColor = UIColor.FromRGB(240, 239, 239);

            viewRowOrderHistory.AddSubviews(OrderID, StoreID, Status, OrderDate, ShipTo_Attention, ShipTo_Company);

        }

    }
}
