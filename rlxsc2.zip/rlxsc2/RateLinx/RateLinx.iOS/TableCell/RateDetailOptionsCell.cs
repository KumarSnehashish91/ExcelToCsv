using Foundation;
using System;
using UIKit;
using RateLinx.Models;
using CoreGraphics;

namespace RateLinx.iOS
{
    public partial class RateDetailOptionsCell : UITableViewCell
    {
        public RateDetailOptionsCell (IntPtr handle) : base (handle)
        {
        }

		internal void UpdateCell(CarrierShipmentDetails objCarrierShipmentDetails, UITableView tableView)
		{

			UITableView tblSSesDetails = new UITableView(new CGRect(0, 1, tableView.Frame.Width, viewOptions.Frame.Height - 1));
			tblSSesDetails.RowHeight = 25f;
			tblSSesDetails.EstimatedRowHeight = 25f;
			tblSSesDetails.Source = new SSesDetailsAdapter(objCarrierShipmentDetails.SSes);
			viewOptions.AddSubview(tblSSesDetails);

			viewOptions.Frame = new CGRect(0, 0, tableView.Frame.Width, objCarrierShipmentDetails.SSes.Count * 25);
			viewOptions.BackgroundColor = UIColor.Black; ;

		}
	}
}