using Foundation;
using System;
using UIKit;
using RateLinx.Models;
using System.Collections.Generic;
using CoreGraphics;
using RateLinx.Helper;
using ObjCRuntime;
using System.Linq;

namespace RateLinx.iOS
{
    public partial class ConversationTableCell : UITableViewCell
    {

		Conversation objConversation;
		UITapGestureRecognizer tapGestureImageLeft, tapGestureLorry, tapGestureFromTo, tapGestureTime, tapGestureMsg;
		ShipmentDetailController shipmentDetailController;
		List<UIButton> lstAttachementButtons;

        public ConversationTableCell (IntPtr handle) : base (handle)
        {

        }

		internal void UpdateCell(Conversation conversation, UITableView tableView, nint section, int row, UIView viewReplySection, UITableViewCell conversationTableCell, UIView mainView, ShipmentDetailController shipmentDetailController)
		{
			this.objConversation = conversation;
			this.shipmentDetailController = shipmentDetailController;

			nfloat imageWidth = 0;

			if (tableView.Frame.Width > 414)
			{
				imageWidth = 400;
			}
			else
			{
				imageWidth = 300;
			}


			nfloat height = 20;
			imgLorry.Frame = new CGRect(30, 5, 15, 15);
			foreach (UIView view in contentView)
			{
				view.RemoveFromSuperview();
			}
			//lblMessage.SizeToFit();
			lblMessage.Lines = 0;
			imgLeft.Frame = new CGRect(0, 3, imageWidth, conversationTableCell.Frame.Height- 6);
			if (conversation.Message.Count() >0  && conversation.Message.Count() < 60)
			{
				height+= 40;
				lblMessage.Frame = new CGRect(30, imgLorry.Frame.Bottom, imgLeft.Frame.Width - 42, 40);

			}
			else if (conversation.Message.Count() > 60 && conversation.Message.Count() < 90)
			{
				height+= 55;
				lblMessage.Frame = new CGRect(30, imgLorry.Frame.Bottom, imgLeft.Frame.Width - 42, 55);
			}
			else if (conversation.Message.Count() > 90 && conversation.Message.Count() < 120)
			{
				height+= 70;
				lblMessage.Frame = new CGRect(30, imgLorry.Frame.Bottom, imgLeft.Frame.Width - 42, 70);
			}
			else
			{
				height+= 85;
				lblMessage.Frame = new CGRect(30, imgLorry.Frame.Bottom, imgLeft.Frame.Width - 42, 85);
			}

			if (conversation.Attachments != null && conversation.Attachments.Count > 0)
			{
				if (conversation.Attachments.Count == 1)
				{
					height += 25;
					viewFileContainer.Frame = new CGRect(30, lblMessage.Frame.Bottom, imgLeft.Frame.Width - 55, 25);
					viewFileContainer.BackgroundColor = UIColor.Blue;
					viewFileContainer.Hidden = false;
				}
				else if (conversation.Attachments.Count == 2)
				{
					height += 50;
					viewFileContainer.Frame = new CGRect(30, lblMessage.Frame.Bottom, imgLeft.Frame.Width - 55, 50);
					viewFileContainer.Hidden = false;
				}
				else
				{
					height += 75;
					viewFileContainer.Frame = new CGRect(30, lblMessage.Frame.Bottom, imgLeft.Frame.Width - 55, 75);
					viewFileContainer.Hidden = false;
				}
			}
			else
			{
				viewFileContainer.Frame = new CGRect(30, lblMessage.Frame.Bottom, imgLeft.Frame.Width - 55, 0);
				viewFileContainer.Hidden = true;

			}

			height += 6;




			lblTime.Frame = new CGRect(30, imgLeft.Frame.Bottom -20, (imgLeft.Frame.Width - 50)/2, 20);


			lblFrom.Frame = new CGRect((imgLeft.Frame.Width - 50)/2 + 30, imgLeft.Frame.Bottom -25, (imgLeft.Frame.Width - 50)/2, 20);


			contentView.Frame = new CGRect(0, 0, tableView.Frame.Width, conversationTableCell.Frame.Height);

			nfloat indicatorWidth;

			if ((tableView.Frame.Width - imageWidth + 20) < 100)
			{
				indicatorWidth = 60;
			}
			else
			{
				indicatorWidth = 80;
			}


			imgIndicator.Frame = new CGRect(imageWidth + 10, contentView.Frame.Height/2 - 25, indicatorWidth, 50);

			contentView.AddSubviews(imgLeft, imgLorry, lblMessage, viewFileContainer, lblTime, lblFrom, imgIndicator);
			//conversationTableCell.Frame = contentView.Bounds;
			imgLeft.Image = UIImage.FromBundle("Images/grey.png");
			lblMessage.AdjustsFontSizeToFitWidth = true;
			lblMessage.Text = conversation.Message;

			lblTime.Text = conversation.TimeStamp;
			lblTime.SizeToFit();

			if (conversation.Attachments != null && conversation.Attachments.Count > 0)
			{
				lstAttachementButtons = new List<UIButton>();
				int btnCount = 0;

				foreach (UIView view in viewFileContainer)
				{
					view.RemoveFromSuperview();
				}
				nfloat yCordinate = 0;

				foreach (string strAttachment in conversation.Attachments)
				{
					int cutFileName = strAttachment.LastIndexOf('/');
					if (cutFileName != -1)
					{
						//int cutFileName = conversation.Attachments[0].LastIndexOf('/');
						UIButton btnAttachment = new UIButton(new CGRect(0, yCordinate, viewFileContainer.Frame.Width, 15));
						btnAttachment.Font = UIFont.FromName(Helper.Constants.strFontName, 15f);
						btnAttachment.SetTitleColor(UIColor.Blue, UIControlState.Normal);
						btnAttachment.HorizontalAlignment = UIControlContentHorizontalAlignment.Left;
						btnAttachment.SetTitle(conversation.Attachments[0].Substring(cutFileName + 1), UIControlState.Normal);
						btnAttachment.UserInteractionEnabled = true;

						btnAttachment.TouchUpInside +=delegate {
							OpenFileInWebView(btnAttachment);
						};


						btnAttachment.Tag = btnCount;
						viewFileContainer.AddSubview(btnAttachment);

						lstAttachementButtons.Add(btnAttachment);

						yCordinate += 25;
						btnCount++;

					}
				}

			}
			else
			{
				//constraint[0].Constant = 0;
				//lblFileName.Text = string.Empty;
			}
			//UIButton btnShowReply = new UIButton();
			//btnShowReply.Tag = row;
			//btnShowReply.Frame = imgLeft.Bounds;
			//btnShowReply.BackgroundColor = UIColor.Clear;

			//contentView.AddSubview(btnShowReply);

			if (viewReplySection.Hidden)
			{
               
				imgLeft.Image = UIImage.FromBundle("Images/grey.png");
				viewFileContainer.BackgroundColor = UIColor.FromRGB(244, 243, 243);
			}
			else
			{
				if (conversation.ID == CommanUtil.replyForConversation.ID)
				{
					imgLeft.Image = UIImage.FromBundle("Images/blue.png");
					viewFileContainer.BackgroundColor = UIColor.FromRGB(105, 192, 236);
				}
				else
				{
					mainView.EndEditing(true);
					imgLeft.Image = UIImage.FromBundle("Images/grey.png");
					viewFileContainer.BackgroundColor = UIColor.FromRGB(244, 243, 243);
				}
			}
			tapGestureImageLeft = new UITapGestureRecognizer(new Action( delegate {

				ViewChildConversationTapped(tableView, section, row, viewReplySection, conversation, viewFileContainer, imgLeft, mainView);
			}));
			imgLeft.AddGestureRecognizer(tapGestureImageLeft);

			tapGestureLorry = new UITapGestureRecognizer(new Action( delegate {

				ViewChildConversationTapped(tableView, section, row, viewReplySection, conversation, viewFileContainer, imgLeft, mainView);
			}));
			imgLorry.AddGestureRecognizer(tapGestureLorry);

			tapGestureMsg = new UITapGestureRecognizer(new Action( delegate {

				ViewChildConversationTapped(tableView, section, row, viewReplySection, conversation, viewFileContainer, imgLeft, mainView);
			}));
			lblMessage.AddGestureRecognizer(tapGestureMsg);

			tapGestureFromTo = new UITapGestureRecognizer(new Action( delegate {

				ViewChildConversationTapped(tableView, section, row, viewReplySection, conversation, viewFileContainer, imgLeft, mainView);
			}));
			lblFrom.AddGestureRecognizer(tapGestureFromTo);

			tapGestureTime = new UITapGestureRecognizer(new Action( delegate {

				ViewChildConversationTapped(tableView, section, row, viewReplySection, conversation, viewFileContainer, imgLeft, mainView);
			}));
			lblTime.AddGestureRecognizer(tapGestureTime);

		}

		void OpenFileInWebView(UIButton btnAttachment)
		{
			if (lstAttachementButtons != null && lstAttachementButtons.Count > 0)
			{
				foreach (UIButton btnAttachfile in lstAttachementButtons)
				{
					if (btnAttachment.Tag == btnAttachfile.Tag)
					{
						btnAttachment.SetTitleColor(UIColor.Red, UIControlState.Highlighted);
					}
					else
					{
						btnAttachment.SetTitleColor(UIColor.Blue, UIControlState.Highlighted);
					}
				}
			}
			string fileUrl = objConversation.Attachments[Convert.ToInt32(btnAttachment.Tag)];
			shipmentDetailController.OpenConversationFile(fileUrl);
			
		}

		void ViewChildConversationTapped(UITableView tableView, nint section, int row, UIView viewReplySection, Conversation conversation, UIView viewFileContainer, UIImageView imgLeft, UIView mainView)
		{

			CommanUtil.replyForConversation = conversation;

			if (viewReplySection.Hidden)
			{
				viewReplySection.Hidden = false;

				viewFileContainer.BackgroundColor = UIColor.FromRGB(105, 192, 236);
				imgLeft.Image = UIImage.FromBundle("Images/blue.png");
			}
			else
			{
				mainView.EndEditing(true);
				viewReplySection.Hidden = true;

				imgLeft.Image = UIImage.FromBundle("Images/grey.png");
				viewFileContainer.BackgroundColor = UIColor.FromRGB(244, 243, 243);
			}

			CommanUtil.sectionNo = section;
			tableView.ReloadData();

		}
}
}