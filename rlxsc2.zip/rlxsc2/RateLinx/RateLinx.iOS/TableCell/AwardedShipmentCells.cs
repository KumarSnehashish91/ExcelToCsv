using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;
using RateLinx.Models;
using RateLinx.Helper;
using CoreGraphics;
using System.Collections.Generic;

namespace RateLinx.iOS
{
	partial class AwardedShipmentCells : UITableViewCell
	{
		DashboardController dashboardController;
		CustomPopup customAlert = null;
		string addressKey = string.Empty;
		public AwardedShipmentCells(IntPtr handle) : base(handle)
		{
		}

		public void UpdateCell(AwardedShipments objAwardedShipments, DashboardController dashboardController, UITableView tableView)
		{
			

		}
		void GoToMap()
		{
			if (Reachability.InternetConnectionStatus())
			{
				dashboardController.RedirectToMap(addressKey);
			}
			else
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, dashboardController, "", 1);
				dashboardController.View.Add(this.customAlert);
			}
		}
	}
}
