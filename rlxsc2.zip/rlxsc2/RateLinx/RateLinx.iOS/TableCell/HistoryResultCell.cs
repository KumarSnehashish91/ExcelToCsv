using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;
using System.Collections.Generic;
using CoreGraphics;

namespace RateLinx.iOS
{
	partial class HistoryResultCell : UITableViewCell
	{

		public HistoryResultCell (IntPtr handle) : base (handle)
		{
		}

		public void UpdateCell(RateHistoryResult objRateHistoryResult, List<RateHistoryColumns> lstHistoryResultcolumns, int rowNumber)
		{

			UIColor objColorCode = null;

			if (rowNumber % 2 == 0)
			{
				objColorCode = UIColor.FromRGB(224,223,223);
			}
			else
			{
				objColorCode =  UIColor.FromRGB(240,239,239);
			}

           

			int marginBtwCol = 2;
			int XPosition = 0;
			//int index = 0;
			foreach (RateHistoryColumns objRateHistoryColumn in lstHistoryResultcolumns)
			{
				Dictionary<string, object> objDictionary = new Dictionary<string, object>();
				foreach (var prop in objRateHistoryResult.GetType().GetProperties())
				{
				  Console.WriteLine("{0} = {1}", prop.Name, prop.GetValue(objRateHistoryResult, null));

					objDictionary.Add(prop.Name, prop.GetValue(objRateHistoryResult, null));
				}
				if (!objRateHistoryColumn.Hidden)
				{
					if (objRateHistoryColumn.FieldName.Contains(" "))
					{
						string strFieldName = objRateHistoryColumn.FieldName.Replace(" ", string.Empty);
						foreach (KeyValuePair<string, object> kvpHistoryRow in objDictionary)
						{
							if (kvpHistoryRow.Key == strFieldName)
							{
								UILabel objColumnName = new UILabel();
								objColumnName.Lines = 0;
								objColumnName.LineBreakMode = UILineBreakMode.WordWrap;
								objColumnName.Frame = new CGRect(XPosition, 1, 120, rowHistoryResult.Frame.Height);
								objColumnName.Text = "  " + Convert.ToString(kvpHistoryRow.Value);
								objColumnName.TextColor = UIColor.Black;
								objColumnName.Font = UIFont.FromName("Century Gothic", 13.0f);
								objColumnName.BackgroundColor = objColorCode;
								rowHistoryResult.AddSubview(objColumnName);
								XPosition =XPosition + 120 + marginBtwCol;
							}
						}
					}
					else
					{
						foreach (KeyValuePair<string, object> kvpHistoryRow in objDictionary)
						{
							if (kvpHistoryRow.Key == objRateHistoryColumn.FieldName)
							{
								UILabel objColumnName = new UILabel();
								objColumnName.Lines = 0;
								objColumnName.LineBreakMode = UILineBreakMode.WordWrap;
								objColumnName.Frame = new CGRect(XPosition, 1, 120, rowHistoryResult.Frame.Height);
								objColumnName.Text = "  " + Convert.ToString(kvpHistoryRow.Value);
								objColumnName.TextColor = UIColor.Black;
								objColumnName.Font = UIFont.FromName("Century Gothic", 13.0f);
								objColumnName.BackgroundColor = objColorCode;
								rowHistoryResult.AddSubview(objColumnName);
								XPosition =XPosition + 120 + marginBtwCol;
							}
						}
					}
				}
			    





				//UILabel objColumnName = new UILabel();
				//objColumnName.Lines = 0;
				//objColumnName.LineBreakMode = UILineBreakMode.WordWrap;

				//switch (objRateHistoryColumn.FieldName) 
				//{
				//	case "Client ID":
				//		objColumnName.Frame = new CGRect(XPosition, 0, 120, rowHistoryResult.Frame.Height-1);
				//		objColumnName.Text = objRateHistoryResult.ClientID;
				//		objColumnName.TextColor = UIColor.White;
				//		objColumnName.BackgroundColor = UIColor.ScrollViewTexturedBackgroundColor;
				//		rowHistoryResult.AddSubview(objColumnName);
				//		XPosition =XPosition + 120 + marginBtwCol;
				//		break;
				//	case "Loc ID":
				//		objColumnName.Frame = new CGRect(XPosition, 0, 60, rowHistoryResult.Frame.Height-1);
				//		objColumnName.Text = Convert.ToString(objRateHistoryResult.LocID);
				//		objColumnName.TextColor = UIColor.White;
				//		objColumnName.BackgroundColor = UIColor.ScrollViewTexturedBackgroundColor;
				//		rowHistoryResult.AddSubview(objColumnName);
				//		XPosition =XPosition + 60 + marginBtwCol;
				//		break;
				//	case "Mode":
				//		objColumnName.Frame = new CGRect(XPosition, 0, 120, rowHistoryResult.Frame.Height-1);
				//		objColumnName.Text = objRateHistoryResult.Mode;
				//		objColumnName.TextColor = UIColor.White;
				//		objColumnName.BackgroundColor = UIColor.ScrollViewTexturedBackgroundColor;
				//		rowHistoryResult.AddSubview(objColumnName);
				//		XPosition =XPosition + 120 + marginBtwCol;
				//		break;
				//	case "Rate Type":
				//		objColumnName.Frame = new CGRect(XPosition, 0, 120, rowHistoryResult.Frame.Height-1);
				//		objColumnName.Text = objRateHistoryResult.RateType;
				//		objColumnName.TextColor = UIColor.White;
				//		objColumnName.BackgroundColor = UIColor.ScrollViewTexturedBackgroundColor;
				//		rowHistoryResult.AddSubview(objColumnName);
				//		XPosition =XPosition + 120 + marginBtwCol;
				//		break;
				//	case "Load Num":
				//		objColumnName.Frame = new CGRect(XPosition, 0, 150, rowHistoryResult.Frame.Height-1);
				//		objColumnName.Text = objRateHistoryResult.LoadNum;
				//		objColumnName.TextColor = UIColor.White;
				//		objColumnName.BackgroundColor = UIColor.ScrollViewTexturedBackgroundColor;
				//		rowHistoryResult.AddSubview(objColumnName);
				//		XPosition =XPosition + 150 + marginBtwCol;
				//		break;
				//	case "Auction Status":
				//		objColumnName.Frame = new CGRect(XPosition, 0, 150, rowHistoryResult.Frame.Height-1);
				//		objColumnName.Text = objRateHistoryResult.AuctionStatus;
				//		objColumnName.TextColor = UIColor.White;
				//		objColumnName.BackgroundColor = UIColor.ScrollViewTexturedBackgroundColor;
				//		rowHistoryResult.AddSubview(objColumnName);
				//		XPosition =XPosition + 150 + marginBtwCol;
				//		break;
				//	case "Rate Status":
				//		objColumnName.Frame = new CGRect(XPosition, 0, 130, rowHistoryResult.Frame.Height-1);
				//		objColumnName.Text = objRateHistoryResult.RateStatus;
				//		objColumnName.TextColor = UIColor.White;
				//		objColumnName.BackgroundColor = UIColor.ScrollViewTexturedBackgroundColor;
				//		rowHistoryResult.AddSubview(objColumnName);
				//		XPosition =XPosition + 130 + marginBtwCol;
				//		break;
				//	case "Date Opened":
				//		objColumnName.Frame = new CGRect(XPosition, 0, 150, rowHistoryResult.Frame.Height-1);
				//		objColumnName.Text = objRateHistoryResult.DateOpened;
				//		objColumnName.TextColor = UIColor.White;
				//		objColumnName.BackgroundColor = UIColor.ScrollViewTexturedBackgroundColor;
				//		rowHistoryResult.AddSubview(objColumnName);
				//		XPosition =XPosition + 150 + marginBtwCol;
				//		break;
				//	case "Rate Deadline":
				//		objColumnName.Frame = new CGRect(XPosition, 0, 150, rowHistoryResult.Frame.Height-1);
				//		objColumnName.Text = objRateHistoryResult.RateDeadline;
				//		objColumnName.TextColor = UIColor.White;
				//		objColumnName.BackgroundColor = UIColor.ScrollViewTexturedBackgroundColor;
				//		rowHistoryResult.AddSubview(objColumnName);
				//		XPosition =XPosition + 150 + marginBtwCol;
				//		break;
				//	case "Ship From":
				//		objColumnName.Frame = new CGRect(XPosition, 0, 150, rowHistoryResult.Frame.Height-1);
				//		objColumnName.Text = objRateHistoryResult.ShipFrom;
				//		objColumnName.TextColor = UIColor.White;
				//		objColumnName.BackgroundColor = UIColor.ScrollViewTexturedBackgroundColor;
				//		rowHistoryResult.AddSubview(objColumnName);
				//		XPosition =XPosition + 150 + marginBtwCol;
				//		break;
				//	case "Ship To":
				//		objColumnName.Frame = new CGRect(XPosition, 0, 150, rowHistoryResult.Frame.Height-1);
				//		objColumnName.Text = objRateHistoryResult.ShipTo;
				//		objColumnName.TextColor = UIColor.White;
				//		objColumnName.BackgroundColor = UIColor.ScrollViewTexturedBackgroundColor;
				//		rowHistoryResult.AddSubview(objColumnName);
				//		XPosition =XPosition + 150 + marginBtwCol;
				//		break;
				//	case "Pickup":
				//		objColumnName.Frame = new CGRect(XPosition, 0, 150, rowHistoryResult.Frame.Height-1);
				//		objColumnName.Text = objRateHistoryResult.Pickup;
				//		objColumnName.TextColor = UIColor.White;
				//		objColumnName.BackgroundColor = UIColor.ScrollViewTexturedBackgroundColor;
				//		rowHistoryResult.AddSubview(objColumnName);
				//		XPosition =XPosition + 150 + marginBtwCol;
				//		break;
				//	case "Reference":
				//		objColumnName.Frame = new CGRect(XPosition, 0, 100, rowHistoryResult.Frame.Height-1);
				//		objColumnName.Text = objRateHistoryResult.Reference;
				//		objColumnName.TextColor = UIColor.White;
				//		objColumnName.BackgroundColor = UIColor.ScrollViewTexturedBackgroundColor;
				//		rowHistoryResult.AddSubview(objColumnName);
				//		XPosition =XPosition + 100 + marginBtwCol;
				//		break;
				//	case "User Created":
				//		objColumnName.Frame = new CGRect(XPosition, 0, 120, rowHistoryResult.Frame.Height-1);
				//		objColumnName.Text = objRateHistoryResult.UserCreated;
				//		objColumnName.TextColor = UIColor.White;
				//		objColumnName.BackgroundColor = UIColor.ScrollViewTexturedBackgroundColor;
				//		rowHistoryResult.AddSubview(objColumnName);
				//		XPosition =XPosition + 120 + marginBtwCol;
				//		break;
				//	default:
			 //           objColumnName.Frame = new CGRect(XPosition, 0, 120, rowHistoryResult.Frame.Height-1);
				//		objColumnName.Text = objRateHistoryResult.ClientID;
				//		objColumnName.TextColor = UIColor.White;
				//		objColumnName.BackgroundColor = UIColor.ScrollViewTexturedBackgroundColor;
				//		rowHistoryResult.AddSubview(objColumnName);
				//		XPosition =XPosition + 120 + marginBtwCol;
			 //           break;
				//}
			}


			rowHistoryResult.Frame = new CGRect(0, 0, XPosition, 47);

			rowHistoryResult.BackgroundColor =  UIColor.FromRGB(240,239,239);

			//UIView objCellDivider = new UIView(new CGRect(0, 46, XPosition, 1));
			//objCellDivider.BackgroundColor = UIColor.Red;
			//rowHistoryResult.AddSubview(objCellDivider);



			//rowHistoryResult.BackgroundColor = UIColor.Red;
			//lblClientID.Text = objRateHistoryResult.ClientID;
			//lblLoadNo.Text = objRateHistoryResult.LoadNum;
			//lblMode.Text = objRateHistoryResult.Mode;
			//lblPickup.Text = objRateHistoryResult.Pickup;
			//lblDateOpened.Text = objRateHistoryResult.DateOpened;
			//lblRateDeadline.Text = objRateHistoryResult.RateDeadline;
			//lblAuctionStatus.Text = objRateHistoryResult.AuctionStatus;
			//lblLocID.Text = Convert.ToString(objRateHistoryResult.LocID);
			//lblRateType.Text = objRateHistoryResult.RateType;
			//lblReference.Text = objRateHistoryResult.Reference;
			//lblShipFrom.Text = objRateHistoryResult.ShipFrom;
			//lblShipTo.Text = objRateHistoryResult.ShipTo;
			//lblUserCreated.Text = objRateHistoryResult.UserCreated;
			//lblRateStatus.Text = objRateHistoryResult.RateStatus;

		}
	}
}
