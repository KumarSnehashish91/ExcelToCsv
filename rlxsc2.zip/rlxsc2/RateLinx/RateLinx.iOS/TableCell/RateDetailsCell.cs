using Foundation;
using System;
using UIKit;
using CoreGraphics;
using RateLinx.Models;
using System.Collections.Generic;
using RateLinx.Helper;

namespace RateLinx.iOS
{
	public partial class RateDetailsCell : UITableViewCell
	{
		
		UIButton btnVoid, btnBlock;

		List<UIView> lstUIViews;

		public RateDetailsCell(IntPtr handle) : base(handle)
		{
			
			btnBlock = new UIButton();
			btnVoid = new UIButton();
			lstUIViews = new List<UIView>();
		}


		internal void UpdateCell(int section, CarrierShipmentDetails objCarrierShipmentDetails, ShipmentDetailController objShipmentDetailController, UITableView tableView)
		{
			try
			{
				//contentView.BackgroundColor = UIColor.LightGray;
				nfloat labelWidth = tableView.Frame.Width / 2 - 50;
				nfloat textWidth = tableView.Frame.Width / 2 + 40;
				nfloat textXCord = tableView.Frame.Width / 2 - 40;
				nfloat yCordinate = 0;
				ConstantsClass.fontSize = 11f;

				UIView viewLoadNum = new UIView(new CGRect(0, 0, tableView.Frame.Width, 30));
				viewLoadNum.BackgroundColor = UIColor.FromRGB(224, 223, 223);

				UILabel lblLoadNoLabel = new UILabel(new CGRect(10, 10, labelWidth, 10));
				lblLoadNoLabel.Text = NSBundle.MainBundle.GetLocalizedString("loadNum", null);
				lblLoadNoLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				UILabel lblLoadNo = new UILabel(new CGRect(textXCord, 10, textWidth, 10));
				lblLoadNo.Text = objCarrierShipmentDetails.BolNum;
				lblLoadNo.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				viewLoadNum.AddSubviews(lblLoadNoLabel, lblLoadNo);
				yCordinate += 30;
				lstUIViews.Add(viewLoadNum);


				UIView viewPickup = new UIView(new CGRect(0, viewLoadNum.Frame.Bottom, tableView.Frame.Width, 30));
				viewPickup.BackgroundColor = UIColor.White;
				UILabel lblPickupLabel = new UILabel(new CGRect(10, 10, labelWidth, 10));
                lblPickupLabel.Text = NSBundle.MainBundle.GetLocalizedString("pickupNum", null);
				lblPickupLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				UILabel lblPickup = new UILabel(new CGRect(textXCord, 10, textWidth, 10));
				lblPickup.Text = objCarrierShipmentDetails.ClientBolNum;
				lblPickup.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				viewPickup.AddSubviews(lblPickupLabel, lblPickup);
				yCordinate += 30;
				lstUIViews.Add(viewPickup);

				UIView viewStatus = new UIView(new CGRect(0, viewPickup.Frame.Bottom, tableView.Frame.Width, 30));
				viewStatus.BackgroundColor = UIColor.FromRGB(224, 223, 223);
				UILabel lblStatusLabel = new UILabel(new CGRect(10, 10, labelWidth, 10));
                lblStatusLabel.Text = NSBundle.MainBundle.GetLocalizedString("status", null);
				lblStatusLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				UILabel lblStatus = new UILabel(new CGRect(textXCord, 10, textWidth, 10));
				lblStatus.Text = objCarrierShipmentDetails.Status;
				lblStatus.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				viewStatus.AddSubviews(lblStatusLabel, lblStatus);
				yCordinate += 30;
				lstUIViews.Add(viewStatus);
				//////viewStatus.AddSubview();

				UIView viewDateOpen = new UIView(new CGRect(0, viewStatus.Frame.Bottom, tableView.Frame.Width, 30));
				viewDateOpen.BackgroundColor = UIColor.White;
				UILabel lblDateOpenLabel = new UILabel(new CGRect(10, 10, labelWidth, 10));
                lblDateOpenLabel.Text = NSBundle.MainBundle.GetLocalizedString("dateOpend", null);
				lblDateOpenLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				UILabel lblDateOpen = new UILabel(new CGRect(textXCord, 10, textWidth, 10));
				lblDateOpen.Text = objCarrierShipmentDetails.DateOpenedStr;
				lblDateOpen.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				viewDateOpen.AddSubviews(lblDateOpenLabel, lblDateOpen);
				yCordinate += 30;
				lstUIViews.Add(viewDateOpen);
				//-------------Starting Price-----------//

				UIView viewStartingPrice = new UIView(new CGRect(0, viewDateOpen.Frame.Bottom, tableView.Frame.Width, 0));

				if (objCarrierShipmentDetails.StartingPrice > 0)
				{
					viewStartingPrice = new UIView(new CGRect(0, viewDateOpen.Frame.Bottom, tableView.Frame.Width, 30));
					viewStartingPrice.BackgroundColor = UIColor.White;
					UILabel lblStartingPrice = new UILabel(new CGRect(10, 10, labelWidth, 10));
                    lblStartingPrice.Text = NSBundle.MainBundle.GetLocalizedString("startingPrice", null);
					lblStartingPrice.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					UILabel lblStartingPriceVal = new UILabel(new CGRect(textXCord, 10, textWidth, 10));
					lblStartingPriceVal.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					lblStartingPriceVal.Text = "$" + Convert.ToString(objCarrierShipmentDetails.StartingPrice);
					viewStartingPrice.AddSubviews(lblStartingPrice, lblStartingPriceVal);
					yCordinate += 30;
					lstUIViews.Add(viewStartingPrice);
				}

				UIView viewUserCreated = new UIView(new CGRect(0, viewStartingPrice.Frame.Bottom, tableView.Frame.Width, 30));

				viewUserCreated.BackgroundColor = UIColor.FromRGB(224, 223, 223);
				UILabel lblUserCreatedLabel = new UILabel(new CGRect(10, 10, labelWidth, 10));
                lblUserCreatedLabel.Text = NSBundle.MainBundle.GetLocalizedString("userCreated", null);
				lblUserCreatedLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				UILabel lblUserCreated = new UILabel(new CGRect(textXCord, 10, textWidth, 10));
				lblUserCreated.Text = objCarrierShipmentDetails.UserCreated;
				lblUserCreated.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				viewUserCreated.AddSubviews(lblUserCreatedLabel, lblUserCreated);
				yCordinate += 30;
				lstUIViews.Add(viewUserCreated);

				UIView viewDateAwarded = new UIView(new CGRect(0, viewUserCreated.Frame.Bottom, tableView.Frame.Width, 30));
				viewDateAwarded.BackgroundColor = UIColor.White;
				UILabel lblDateAwardedLabel = new UILabel(new CGRect(10, 10, labelWidth, 10));
                lblDateAwardedLabel.Text = NSBundle.MainBundle.GetLocalizedString("dateAwarded", null);
				lblDateAwardedLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				UILabel lblDateAwarded = new UILabel(new CGRect(textXCord, 10, textWidth, 10));
				lblDateAwarded.Text = objCarrierShipmentDetails.DateAwardedStr;
				lblDateAwarded.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				viewDateAwarded.AddSubviews(lblDateAwardedLabel, lblDateAwarded);
				yCordinate += 30;
				lstUIViews.Add(viewDateAwarded);
				UIView viewSentCarriers = new UIView(new CGRect(0, viewDateAwarded.Frame.Bottom, tableView.Frame.Width, 0));

				if (objCarrierShipmentDetails.ViewAs == Constants.strCustomer)
				{
					viewSentCarriers.Frame = new CGRect(0, viewDateAwarded.Frame.Bottom, tableView.Frame.Width, 30);
					viewSentCarriers.BackgroundColor = UIColor.FromRGB(224, 223, 223); ;
					UILabel lblSentCarriersLabel = new UILabel(new CGRect(10, 10, labelWidth, 10));
                    lblSentCarriersLabel.Text = NSBundle.MainBundle.GetLocalizedString("rateSendto", null);
					lblSentCarriersLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					UILabel lblSentCarriers = new UILabel(new CGRect(textXCord, 10, textWidth, 10));
					lblSentCarriers.Text = objCarrierShipmentDetails.SentCarriers;
					lblSentCarriers.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					viewSentCarriers.AddSubviews(lblSentCarriersLabel, lblSentCarriers);
					yCordinate += 30;
					lstUIViews.Add(viewSentCarriers);
				}

				UIView viewInvoiceCreatedOn = new UIView(new CGRect(0, viewSentCarriers.Frame.Bottom, tableView.Frame.Width, 0));

				if (!string.IsNullOrEmpty(objCarrierShipmentDetails.InvoiceCreatedOn))
				{
					viewInvoiceCreatedOn.Frame = new CGRect(0, viewSentCarriers.Frame.Bottom, tableView.Frame.Width, 30);
					lstUIViews.Add(viewInvoiceCreatedOn);

					viewInvoiceCreatedOn.BackgroundColor = UIColor.White;
					UILabel lblInvoiceCreatedOnLabel = new UILabel(new CGRect(10, 10, labelWidth, 10));
                    lblInvoiceCreatedOnLabel.Text = NSBundle.MainBundle.GetLocalizedString("invoiceCreated", null);
					lblInvoiceCreatedOnLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					UILabel lblInvoiceCreatedOn = new UILabel(new CGRect(textXCord, 10, textWidth, 10));
					lblInvoiceCreatedOn.Text = objCarrierShipmentDetails.InvoiceCreatedOn;
					lblInvoiceCreatedOn.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					viewInvoiceCreatedOn.AddSubviews(lblInvoiceCreatedOnLabel, lblInvoiceCreatedOn);
					yCordinate += 30;
					lstUIViews.Add(viewInvoiceCreatedOn);
				}
				//--------Lowest Price -------------//
				bool isShowCharges = CommanUtil.isShowCharges;
				UIView viewLowestPrice = new UIView(new CGRect(0, viewInvoiceCreatedOn.Frame.Bottom, tableView.Frame.Width, 0));
				//viewLowestPrice = new UIView(new CGRect(0, viewInvoiceCreatedOn.Frame.Bottom, tableView.Frame.Width, 60));
				//viewLowestPrice.BackgroundColor = UIColor.FromRGB(224, 223, 223);
				//UILabel lblLowestPrice = new UILabel(new CGRect(10, 20, tableView.Frame.Width, 20));
				//lblLowestPrice.TextColor = UIColor.Black;
				//lblLowestPrice.Text = objCarrierShipmentDetails.LowestPriceLbl + ": $" + objCarrierShipmentDetails.LowestPrice;
				//viewLowestPrice.AddSubview(lblLowestPrice);
				//yCordinate += 30;
				//lstUIViews.Add(viewLowestPrice);
				if (isShowCharges)
				{
					if (objCarrierShipmentDetails.LowestPrice > 0)
					{
						viewLowestPrice = new UIView(new CGRect(0, viewInvoiceCreatedOn.Frame.Bottom, tableView.Frame.Width, 60));
						viewLowestPrice.BackgroundColor = UIColor.FromRGB(224, 223, 223);
						UILabel lblLowestPrice = new UILabel(new CGRect(10, 20, tableView.Frame.Width, 20));
						lblLowestPrice.TextColor = UIColor.Black;
						lblLowestPrice.Text = objCarrierShipmentDetails.LowestPriceLbl + ": $" + objCarrierShipmentDetails.LowestPrice;
						viewLowestPrice.AddSubview(lblLowestPrice);
						yCordinate += 30;
						lstUIViews.Add(viewLowestPrice);
					}
				}

				UIView viewRateType = new UIView(new CGRect(0, viewLowestPrice.Frame.Bottom, tableView.Frame.Width, 30));

				viewRateType.BackgroundColor = UIColor.White;
				UILabel lblRateTypeLabel = new UILabel(new CGRect(10, 10, labelWidth, 10));
                lblRateTypeLabel.Text = NSBundle.MainBundle.GetLocalizedString("rateType", null);
				lblRateTypeLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				UILabel lblRateType = new UILabel(new CGRect(textXCord, 10, textWidth, 10));
				lblRateType.Text = objCarrierShipmentDetails.BidType;
				lblRateType.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				viewRateType.AddSubviews(lblRateTypeLabel, lblRateType);
				yCordinate += 30;
				lstUIViews.Add(viewRateType);

				UIView viewRateDeadLine = new UIView(new CGRect(0, viewRateType.Frame.Bottom, tableView.Frame.Width, 30));
				viewRateDeadLine.BackgroundColor = UIColor.FromRGB(224, 223, 223);
				UILabel lblRateDeadLineLabel = new UILabel(new CGRect(10, 10, labelWidth, 10));
                lblRateDeadLineLabel.Text = NSBundle.MainBundle.GetLocalizedString("rateDeadline", null);
				lblRateDeadLineLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				UILabel lblRateDeadLine = new UILabel(new CGRect(textXCord, 10, textWidth, 10));
				lblRateDeadLine.Text = objCarrierShipmentDetails.DeadLineStr;
				lblRateDeadLine.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				viewRateDeadLine.AddSubviews(lblRateDeadLineLabel, lblRateDeadLine);
				yCordinate += 30;
				lstUIViews.Add(viewRateDeadLine);

				UIView viewPickupOn = new UIView(new CGRect(0, viewRateDeadLine.Frame.Bottom, tableView.Frame.Width, 30));
				viewPickupOn.BackgroundColor = UIColor.White;
				UILabel lblPickupOnLabel = new UILabel(new CGRect(10, 10, labelWidth, 10));
                lblPickupOnLabel.Text = NSBundle.MainBundle.GetLocalizedString("pickOn", null);
				lblPickupOnLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				UILabel lblPickupOn = new UILabel(new CGRect(textXCord, 10, textWidth, 10));
				lblPickupOn.Text = objCarrierShipmentDetails.PickupStr;
				lblPickupOn.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				viewPickupOn.AddSubviews(lblPickupOnLabel, lblPickupOn);
				yCordinate += 30;
				lstUIViews.Add(viewPickupOn);

				UIView viewDeliverOn = new UIView(new CGRect(0, viewPickupOn.Frame.Bottom, tableView.Frame.Width, 30));
				viewDeliverOn.BackgroundColor = UIColor.FromRGB(224, 223, 223);
				UILabel lblDeliverOnLabel = new UILabel(new CGRect(10, 10, labelWidth, 10));
                lblDeliverOnLabel.Text = NSBundle.MainBundle.GetLocalizedString("deliveryon", null);
				lblDeliverOnLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				UILabel lblDeliverOn = new UILabel(new CGRect(textXCord, 10, textWidth, 10));
				lblDeliverOn.Text = objCarrierShipmentDetails.DeliverOnStr;
				lblDeliverOn.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				viewDeliverOn.AddSubviews(lblDeliverOnLabel, lblDeliverOn);
				yCordinate += 30;
				lstUIViews.Add(viewDeliverOn);

				UIView viewDriver = new UIView(new CGRect(0, viewDeliverOn.Frame.Bottom, tableView.Frame.Width, 30));
				viewDriver.BackgroundColor = UIColor.White;
				UILabel lblDriverLabel = new UILabel(new CGRect(10, 10, labelWidth, 10));
                lblDriverLabel.Text = NSBundle.MainBundle.GetLocalizedString("driver", null);
				lblDriverLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				UILabel lblDriver = new UILabel(new CGRect(textXCord, 10, textWidth, 10));
				lblDriver.Text = objCarrierShipmentDetails.DriverID;
				lblDriver.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				viewDriver.AddSubviews(lblDriverLabel, lblDriver);
				yCordinate += 30;
				lstUIViews.Add(viewDriver);

				UIView viewReference = new UIView(new CGRect(0, viewDriver.Frame.Bottom, tableView.Frame.Width, 30));
				viewReference.BackgroundColor = UIColor.FromRGB(224, 223, 223);
				UILabel lblReferenceLabel = new UILabel(new CGRect(10, 10, labelWidth, 10));
				lblReferenceLabel.Text = objCarrierShipmentDetails.ReferenceLbl;
				lblReferenceLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				UILabel lblReference = new UILabel(new CGRect(textXCord, 10, textWidth, 10));
				lblReference.Text = objCarrierShipmentDetails.Reference;
				lblReference.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				viewReference.AddSubviews(lblReferenceLabel, lblReference);
				yCordinate += 30;
				lstUIViews.Add(viewReference);

				UIView viewComments = new UIView(new CGRect(0, viewReference.Frame.Bottom, tableView.Frame.Width, 30));
				viewComments.BackgroundColor = UIColor.White;
				UILabel lblCommentsLabel = new UILabel(new CGRect(10, 10, labelWidth, 10));
                lblCommentsLabel.Text = NSBundle.MainBundle.GetLocalizedString("comments", null);
				lblCommentsLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				UILabel lblComments = new UILabel(new CGRect(textXCord, 10, textWidth, 10));
				lblComments.Text = objCarrierShipmentDetails.Comments;
				lblComments.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				viewComments.AddSubviews(lblCommentsLabel, lblComments);
				yCordinate += 30;
				lstUIViews.Add(viewComments);
				UIView viewClientStatement = new UIView(new CGRect(0, viewComments.Frame.Bottom, tableView.Frame.Width, 0));
				//------------Void, Block Functionality And Statement ---------------------//
				if (!string.IsNullOrEmpty(objCarrierShipmentDetails.SCACStatement))
				{
					viewClientStatement.Frame = new CGRect(0, viewComments.Frame.Bottom, tableView.Frame.Width, 30);
					viewClientStatement.BackgroundColor = UIColor.FromRGB(224, 223, 223);
					UILabel lblClientStatementLabel = new UILabel(new CGRect(10, 10, labelWidth, 10));
                    lblClientStatementLabel.Text = NSBundle.MainBundle.GetLocalizedString("clientComment", null);
					lblClientStatementLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					UILabel lblClientStatement = new UILabel(new CGRect(textXCord, 10, textWidth, 10));
					lblClientStatement.Text = objCarrierShipmentDetails.SCACStatement;
					lblClientStatement.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					viewClientStatement.AddSubviews(lblClientStatementLabel, lblClientStatement);
					yCordinate += 30;
					lstUIViews.Add(viewClientStatement);
				}

				UIView viewVoidBlockButton = new UIView(new CGRect(0, viewClientStatement.Frame.Bottom, tableView.Frame.Width, 0));

				if (objCarrierShipmentDetails.ViewAs.ToUpper() == Constants.strCustomer.ToUpper())
				{
					viewVoidBlockButton.Frame = new CGRect(0, viewClientStatement.Frame.Bottom, tableView.Frame.Width, 30);

					if (objCarrierShipmentDetails.CanVoid)
					{
						btnVoid.Frame = new CGRect(10, 10, 60, 20);
						btnVoid.Layer.CornerRadius = 5;
						btnVoid.BackgroundColor = UIColor.FromRGB(157, 34, 53);
						btnVoid.Font = UIFont.FromName(Constants.strFontName, 13f);
                        btnVoid.SetTitle(NSBundle.MainBundle.GetLocalizedString("void", null), UIControlState.Normal);
						btnVoid.UserInteractionEnabled = true;
                        viewVoidBlockButton.UserInteractionEnabled = true;
						//btnVoid.TouchUpInside += delegate
						//{
						//	VoidShipmentPopup objConfirmPopup = new VoidShipmentPopup(objShipmentDetailController.View, objShipmentDetailController);
						//	UIView viewConfirmpop = objConfirmPopup.GetPopupScreen();
						//	objShipmentDetailController.View.Add(viewConfirmpop);
						//};

                        btnVoid.TouchUpInside +=delegate {
                        
                            VoidShipmentPopup objConfirmPopup = new VoidShipmentPopup(objShipmentDetailController.View, objShipmentDetailController);
                            UIView viewConfirmpop = objConfirmPopup.GetPopupScreen();
                            objShipmentDetailController.View.Add(viewConfirmpop);
                        };

					}
					if (objCarrierShipmentDetails.CanBlock)
					{
						btnBlock.Frame = new CGRect(textXCord, 10, 80, 20);
						btnBlock.Layer.CornerRadius = 5;
						btnBlock.BackgroundColor = UIColor.FromRGB(157, 34, 53);
						btnBlock.Font = UIFont.FromName(Constants.strFontName, 13f);
                        btnBlock.SetTitle(NSBundle.MainBundle.GetLocalizedString("block", null), UIControlState.Normal);
						btnBlock.UserInteractionEnabled = true;

						lstUIViews.Add(viewVoidBlockButton);
						yCordinate += 30;

						btnBlock.TouchUpInside += delegate
						{
							BlockShipmentPopup objConfirmPopup = new BlockShipmentPopup(objShipmentDetailController.View, objShipmentDetailController);
							UIView viewConfirmpop = objConfirmPopup.GetPopupScreen();
							objShipmentDetailController.View.Add(viewConfirmpop);
						};
					}
					viewVoidBlockButton.AddSubviews(btnVoid, btnBlock);
				}

				contentView.Frame = new CGRect(0, 0, tableView.Frame.Width, yCordinate);

				contentView.Add(viewLoadNum);
				contentView.Add(viewPickup);
				contentView.Add(viewStatus);
				contentView.Add(viewDateOpen);

				contentView.Add(viewStartingPrice);
				contentView.Add(viewUserCreated);
				contentView.Add(viewDateAwarded);

				contentView.Add(viewInvoiceCreatedOn);

				contentView.Add(viewSentCarriers);

				contentView.Add(viewLowestPrice);

				contentView.Add(viewRateType);
				contentView.Add(viewRateDeadLine);
				contentView.Add(viewPickupOn);
				contentView.Add(viewDeliverOn);
				contentView.Add(viewDriver);
				contentView.Add(viewReference);
				contentView.Add(viewComments);

				contentView.Add(viewClientStatement);
                contentView.Add(viewVoidBlockButton);

				for (int i = 0; i < lstUIViews.Count; i++)
				{
					if (i % 2 == 0)
					{
						lstUIViews[i].BackgroundColor = UIColor.FromRGB(224, 223, 223);
					}
					else
					{
						lstUIViews[i].BackgroundColor = UIColor.White;
					}
				}
			}
			catch 
			{
				throw;
			}
		}

		public void TapGestureCalled(UIView contentView)
		{
			//Console.WriteLine("Tap gesture");
		}

}
}