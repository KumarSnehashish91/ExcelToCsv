using Foundation;
using System;
using UIKit;
using RateLinx.Models;
using CoreGraphics;
using System.Collections.Generic;
using RateLinx.Helper;

namespace RateLinx.iOS
{
    public partial class CommoditiesCell : UITableViewCell
    {
        public CommoditiesCell (IntPtr handle) : base (handle)
        {
        }

		internal void UpdateCell(CarrierShipmentDetails objCarrierShipmentDetails)
		{
			nfloat xCordinate = 0;
			UIView viewLine = new UIView(new CGRect(0, 0, viewCommodities.Frame.Width, 1));
			viewLine.BackgroundColor = UIColor.White;
			viewCommodities.AddSubview(viewLine);

			UIScrollView scrollView = new UIScrollView
			{
				Frame = new CGRect(0, 1, viewCommodities.Frame.Width, viewCommodities.Frame.Height),
				ContentSize = new CGSize(1008, 20),
				BackgroundColor = UIColor.LightGray,
				AutoresizingMask = UIViewAutoresizing.FlexibleWidth,
				Bounces = false
			};

			List<Content> lstContents = objCarrierShipmentDetails.Contents;


			UILabel lblCountry = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
			lblCountry.BackgroundColor = UIColor.FromRGB(75, 72, 69);
			lblCountry.Text = NSBundle.MainBundle.LocalizedString("country",null);
			lblCountry.TextColor = UIColor.White;
			lblCountry.TextAlignment = UITextAlignment.Center;
			lblCountry.Font = UIFont.FromName(Constants.strFontName, 12f);
			scrollView.AddSubview(lblCountry);
			xCordinate = lblCountry.Frame.X + 101;

			UILabel lblCode = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
			lblCode.BackgroundColor = UIColor.FromRGB(75, 72, 69);
			lblCode.Text = NSBundle.MainBundle.LocalizedString("code",null);
			lblCode.TextColor = UIColor.White;
			lblCode.TextAlignment = UITextAlignment.Center;
			lblCode.Font = UIFont.FromName(Constants.strFontName, 12f);
			scrollView.AddSubview(lblCode);
			xCordinate = lblCode.Frame.X + 101;

			UILabel lblNumber = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
			lblNumber.BackgroundColor = UIColor.FromRGB(75, 72, 69);
			lblNumber.Text = NSBundle.MainBundle.LocalizedString("number",null);
			lblNumber.TextColor = UIColor.White;
			lblNumber.TextAlignment = UITextAlignment.Center;
			lblNumber.Font = UIFont.FromName(Constants.strFontName, 12f);
			scrollView.AddSubview(lblNumber);
			xCordinate = lblNumber.Frame.X + 101;

			UILabel lblDescription = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
			lblDescription.BackgroundColor = UIColor.FromRGB(75, 72, 69);
			lblDescription.Text = NSBundle.MainBundle.LocalizedString("description",null);
			lblDescription.TextColor = UIColor.White;
			lblDescription.TextAlignment = UITextAlignment.Center;
			lblDescription.Font = UIFont.FromName(Constants.strFontName, 12f);
			scrollView.AddSubview(lblDescription);
			xCordinate = lblDescription.Frame.X + 101;

			UILabel lblQty = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
			lblQty.BackgroundColor = UIColor.FromRGB(75, 72, 69);
			lblQty.Text = NSBundle.MainBundle.LocalizedString("qty",null);
			lblQty.TextColor = UIColor.White;
			lblQty.TextAlignment = UITextAlignment.Center;
			lblQty.Font = UIFont.FromName(Constants.strFontName, 12f);
			scrollView.AddSubview(lblQty);
			xCordinate = lblQty.Frame.X + 101;

			UILabel lblUOM = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
			lblUOM.BackgroundColor = UIColor.FromRGB(75, 72, 69);
			lblUOM.Text = NSBundle.MainBundle.LocalizedString("UOM",null);
			lblUOM.TextColor = UIColor.White;
			lblUOM.TextAlignment = UITextAlignment.Center;
			lblUOM.Font = UIFont.FromName(Constants.strFontName, 12f);
			scrollView.AddSubview(lblUOM);
			xCordinate = lblUOM.Frame.X + 101;

			UILabel lblPrice = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
			lblPrice.BackgroundColor = UIColor.FromRGB(75, 72, 69);
			lblPrice.Text = NSBundle.MainBundle.LocalizedString("price",null);
			lblPrice.TextColor = UIColor.White;
			lblPrice.TextAlignment = UITextAlignment.Center;
			lblPrice.Font = UIFont.FromName(Constants.strFontName, 12f);
			scrollView.AddSubview(lblPrice);
			xCordinate = lblPrice.Frame.X + 101;

			UILabel lblValue = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
			lblValue.BackgroundColor = UIColor.FromRGB(75, 72, 69);
			lblValue.Text = NSBundle.MainBundle.LocalizedString("value",null);
			lblValue.TextColor = UIColor.White;
			lblValue.TextAlignment = UITextAlignment.Center;
			lblValue.Font = UIFont.FromName(Constants.strFontName, 12f);
			scrollView.AddSubview(lblValue);
			xCordinate = lblValue.Frame.X + 101;

			UILabel lblWeight = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
			lblWeight.BackgroundColor = UIColor.FromRGB(75, 72, 69);
			lblWeight.Text = NSBundle.MainBundle.LocalizedString("weight",null);
			lblWeight.TextColor = UIColor.White;
			lblWeight.TextAlignment = UITextAlignment.Center;
			lblWeight.Font = UIFont.FromName(Constants.strFontName, 12f);
			scrollView.AddSubview(lblWeight);
			xCordinate = lblWeight.Frame.X + 101;

			scrollView.ContentSize = new CGSize(xCordinate, viewCommodities.Frame.Height);

			UITableView tblContents = new UITableView
			{
				Frame = new CGRect(0, 20, xCordinate, 0),
				AutoresizingMask = UIViewAutoresizing.FlexibleWidth,
				BackgroundColor = UIColor.Red,
				Bounces = false
			};

			if (lstContents != null)
			{
				tblContents.Frame = new CGRect(0, 20, xCordinate, lstContents.Count * 25);
				tblContents.Source = new ShipmentContentsAdapter(lstContents);

				scrollView.Frame = new CGRect(0, 0, viewCommodities.Frame.Width, 20 + lstContents.Count * 25);
				scrollView.ContentSize = new CGSize(tblContents.Frame.Width, 20 + lstContents.Count * 25);
			}
			tblContents.AutoresizingMask = UIViewAutoresizing.FlexibleWidth;

			tblContents.BackgroundColor = UIColor.Red;


			scrollView.AddSubview(tblContents);
			viewCommodities.Add(scrollView);
		}
	}
}