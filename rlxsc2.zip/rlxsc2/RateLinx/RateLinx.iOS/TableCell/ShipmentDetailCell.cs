using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace RateLinx.iOS
{
	partial class ShipmentDetailCell : UITableViewCell
	{
		public static readonly NSString Key = new NSString("HeaderCell");
		public static readonly UINib Nib;


		static ShipmentDetailCell()
		{
			Nib = UINib.FromName("HeaderCell", NSBundle.MainBundle);
		}


		public ShipmentDetailCell (IntPtr handle) : base (handle)
		{
		}
	}
}
