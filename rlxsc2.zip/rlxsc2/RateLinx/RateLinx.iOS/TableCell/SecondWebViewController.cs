using Foundation;
using System;
using UIKit;

namespace RateLinx.iOS
{
	public partial class SecondWebViewController : UIViewController
	{
		public string fileURL;
		public SecondWebViewController(IntPtr handle) : base(handle)
		{
		}
		/// <summary>
		/// Views the did load.
		/// </summary>
		public override void ViewDidLoad()
		{
			try
			{

				base.ViewDidLoad();
				fileWebView.LoadRequest(new NSUrlRequest(new NSUrl(fileURL)));
				//string htmlStr = "<h1>Devebnder</h1>";
				//fileWebView.LoadHtmlString(htmlStr, new NSUrl("Devender", true));
				//Tap Gesture 
				//TapGestureRecognizer();

			}
			catch
			{
				throw;

			}
		}
	}
}