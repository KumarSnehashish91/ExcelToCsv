using Foundation;
using System;
using UIKit;
using RateLinx.Models;

namespace RateLinx.iOS
{
    public partial class CarrierBidDetail : UITableViewCell
    {
        public CarrierBidDetail (IntPtr handle) : base (handle)
        {
			
        }

		internal void UpdateCell(Bid objBid, int row)
		{
			lblPrice.Text = Convert.ToString(objBid.Price);
			lblStatus.Text = objBid.Status;
			lblAlt.Text = Convert.ToString(objBid.AltTerms);
			lblCarrier.Text = objBid.Carrier;
		}
}
}