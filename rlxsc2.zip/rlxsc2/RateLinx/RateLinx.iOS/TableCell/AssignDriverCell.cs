using Foundation;
using System;
using UIKit;
using RateLinx.Models;
using CoreGraphics;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using RateLinx.Helper;
using RateLinx.APIs;
using System.Collections.Generic;

namespace RateLinx.iOS
{
	public partial class AssignDriverCell : UITableViewCell
	{
		ShipmentDetailController ShipmentDetailController;
		UIPickerView pickerView = null;
		PickerDataModel pickerDataModel = null;
		UIButton doneButton = null;
		UIView viewPicker = null;
		CustomPopup customAlert = null;
		CarrierShipmentDetails objCarrierShipmentDetail;
		UIButton btnPickDriver;

		UITapGestureRecognizer tapGesture;


		public AssignDriverCell(IntPtr handle) : base(handle)
		{
		}

		internal void UpdateCell(CarrierShipmentDetails objCarrierShipmentDetails, ShipmentDetailController objShipmentDetailController, UITableView tableView)
		{

			foreach (UIView view in viewAssignDriver)
			{
				view.RemoveFromSuperview();
			}

			this.ShipmentDetailController = objShipmentDetailController;
			this.objCarrierShipmentDetail = objCarrierShipmentDetails;

			UILabel lblAssignDriver = new UILabel(new CGRect(10, 5, tableView.Frame.Width * 0.3, 25));
			lblAssignDriver.Font = UIFont.FromName(Constants.strFontName, 13f);
			lblAssignDriver.Text = NSBundle.MainBundle.LocalizedString("assignDriver",null);
			btnPickDriver = null;
			btnPickDriver = new UIButton(new CGRect(tableView.Frame.Width * 0.3, 5, tableView.Frame.Width * 0.3 , 25));
			btnPickDriver.Layer.CornerRadius = 5;
			btnPickDriver.Layer.BorderWidth = 0.5f;
			btnPickDriver.BackgroundColor = UIColor.White;
			btnPickDriver.SetTitleColor(UIColor.Black, UIControlState.Normal);

			btnPickDriver.Font = UIFont.FromName(Constants.strFontName, 13f);
			btnPickDriver.SetTitle(NSBundle.MainBundle.LocalizedString("selectDriver",null), UIControlState.Normal);
			btnPickDriver.TouchUpInside += delegate
			{
				BindDriver();
			};
			UIButton btnAssignDriver = new UIButton(new CGRect(tableView.Frame.Width * 0.6 + 20, 5, tableView.Frame.Width * 0.3, 25));
			btnAssignDriver.Layer.CornerRadius = 5;
			btnAssignDriver.BackgroundColor = UIColor.FromRGB(157, 34, 53);
			btnAssignDriver.Font = UIFont.FromName(Constants.strFontName, 13f);
			btnAssignDriver.SetTitle(NSBundle.MainBundle.LocalizedString("assignDriver",null), UIControlState.Normal);
			btnAssignDriver.TouchUpInside += async delegate {
				await ShipmentDetailController.SaveDriver(objCarrierShipmentDetails, btnPickDriver.TitleLabel.Text);
				btnPickDriver.SetTitle(NSBundle.MainBundle.LocalizedString("selectDriver",null), UIControlState.Normal);
			}; 
			viewAssignDriver.BackgroundColor = UIColor.FromRGB(224, 223, 223);

			viewAssignDriver.Frame = new CGRect(0, 0, tableView.Frame.Width, 50);

			viewAssignDriver.AddSubviews(lblAssignDriver, btnPickDriver, btnAssignDriver);
		}

		/// <summary>
		/// Binds the Driver drop down.
		/// </summary>
		public void BindDriver()
		{
			try
			{
				string selectedValue = string.Empty;
				//int xPosition = (int)(ShipmentDetailController.View.Frame.Width - 300) / 2;
				int yPosition = (int)(ShipmentDetailController.View.Frame.Height - 180) / 2;
				UIView pickerParentView = new UIView();
				viewPicker = new UIView(new CGRect(20, yPosition - 100, ShipmentDetailController.View.Frame.Width - 40, 210));
				viewPicker.BackgroundColor = UIColor.White;
				viewPicker.Layer.CornerRadius = 10;
				viewPicker.Layer.BorderWidth = 1;
				viewPicker.Layer.BorderColor = UIColor.Black.CGColor;
				pickerView = new UIPickerView(new CGRect(0, 0, viewPicker.Frame.Width, 180));
				pickerView.BackgroundColor = UIColor.White;
				pickerView.ShowSelectionIndicator = true;
				// create our simple picker model
				List<string> driverArray = null;
				driverArray = new List<string>();
				if (objCarrierShipmentDetail.AssignableDrivers != null)
				{
					List<AssignableDriver> objAssignableDriver = new List<AssignableDriver>();
					objAssignableDriver = objCarrierShipmentDetail.AssignableDrivers;//Get Assinable driver from lstShipmentDetail
					//driverArray.Add(Constants.strDriver);
					foreach (var item in objAssignableDriver)
					{
						driverArray.Add(item.Value);
					}
				}
				else
				{
					driverArray.Add(Constants.strDriver);
				}
				pickerDataModel = new PickerDataModel(driverArray);
				// set it on our picker class
				pickerView.Model = pickerDataModel;
				// Create a 'done' button for the toolbar and add it to the toolbar
				doneButton = new UIButton(new CGRect(0, 180, viewPicker.Frame.Width, 30));
				doneButton.BringSubviewToFront(ShipmentDetailController.View);
				doneButton.SetTitle(ConstantsClass.strDone, UIControlState.Normal);
				doneButton.BackgroundColor = UIColor.FromRGB(137, 18, 40);
				doneButton.Layer.CornerRadius = 10;
				doneButton.UserInteractionEnabled = true;
				viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });
				pickerDataModel.ValueChanged += (s, e) =>
				{
					selectedValue = "  " + pickerDataModel.SelectedItem;
				};

				doneButton.TouchUpInside += (s, e) =>
				{
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
					if (!string.IsNullOrEmpty(selectedValue))
					{
						btnPickDriver.SetTitle(selectedValue, UIControlState.Normal);
					}
					else
					{
						btnPickDriver.SetTitle(driverArray[0], UIControlState.Normal);
					}
				};
				viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });


				pickerParentView.Frame = ShipmentDetailController.View.Frame;

				pickerParentView.BackgroundColor = UIColor.Clear;

				pickerParentView.Add(viewPicker);


				ShipmentDetailController.View.Add(pickerParentView);


				tapGesture = new UITapGestureRecognizer(new Action(delegate {
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
				}));
				pickerParentView.AddGestureRecognizer(tapGesture);


			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, ShipmentDetailController, "", 1);
				ShipmentDetailController.View.Add(this.customAlert);
			}
		}

	}
}