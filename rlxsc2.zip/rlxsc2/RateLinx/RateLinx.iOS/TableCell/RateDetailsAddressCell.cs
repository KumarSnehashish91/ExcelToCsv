using Foundation;
using System;
using UIKit;
using RateLinx.Models;
using CoreGraphics;
using RateLinx.Helper;

namespace RateLinx.iOS
{
	public partial class RateDetailsAddressCell : UITableViewCell
	{
		ShipmentDetailController shipmentDetailController;
		string addressKey;
		public RateDetailsAddressCell(IntPtr handle) : base(handle)
		{
		}

		internal void UpdateCell(CarrierShipmentDetails objCarrierShipmentDetails, ShipmentDetailController objShipmentDetailController, UITableView tableView)
		{
			try
			{
				this.shipmentDetailController = objShipmentDetailController;
				nfloat labelWidth = tableView.Frame.Width / 2 - 10;
				nfloat textWidth = tableView.Frame.Width / 2 - 10;
				nfloat textXCord = tableView.Frame.Width / 2 + 10;

				UIView viewWhiteSpace = new UIView(new CoreGraphics.CGRect(0, 0, tableView.Frame.Width, 1));
				viewWhiteSpace.BackgroundColor = UIColor.White;
				UIView viewAddressHeader = new UIView(new CoreGraphics.CGRect(0, 1, tableView.Frame.Width, 29));
				viewAddressHeader.BackgroundColor = UIColor.FromRGB(75, 72, 69);

				UILabel lblOriginAddress = new UILabel(new CoreGraphics.CGRect(10, 0, labelWidth, viewAddressHeader.Frame.Height));
				lblOriginAddress.TextAlignment = UITextAlignment.Left;
				lblOriginAddress.Text = NSBundle.MainBundle.GetLocalizedString("orgAddress", null);
				//lblOriginAddress.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				lblOriginAddress.TextColor = UIColor.White;
				lblOriginAddress.Font = UIFont.FromName(Constants.strFontName, 13f);
				UILabel lblDestinationAddress = new UILabel(new CoreGraphics.CGRect(textXCord, 0, textWidth, viewAddressHeader.Frame.Height));
				lblDestinationAddress.TextAlignment = UITextAlignment.Left;
                lblDestinationAddress.Text = NSBundle.MainBundle.GetLocalizedString("destAddress", null);
				lblDestinationAddress.Font = UIFont.FromName(Constants.strFontName, 13f);
				//lblDestinationAddress.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
				lblDestinationAddress.TextColor = UIColor.White;
				viewAddressHeader.AddSubviews(lblOriginAddress, lblDestinationAddress);
				//224,223,223
				UIView viewSourceAddress = new UIView(new CoreGraphics.CGRect(0, 30, tableView.Frame.Width / 2, 200));
				viewSourceAddress.BackgroundColor = UIColor.FromRGB(224, 223, 223);


				UIView viewDestinationAddress = new UIView(new CoreGraphics.CGRect(viewSourceAddress.Frame.Width, 30, tableView.Frame.Width / 2, 200));
				viewDestinationAddress.BackgroundColor = UIColor.FromRGB(224, 223, 223);

				Address sourceAddress, destinationAddress = null;
				if (objCarrierShipmentDetails.Addresses.Count > 1)
				{
					sourceAddress = objCarrierShipmentDetails.Addresses[0];
					destinationAddress = objCarrierShipmentDetails.Addresses[1];

					nfloat yCordinate = 5;

					nfloat yCordinate1 = 5;
					ConstantsClass.fontSize = 11f;
					UILabel lblSourceAttention, lblSourceAddress1, lblSourceAddress2, lblSourceAddress3, lblSourceAddress4, lblSourceCity = null;

					UILabel lblDestAttention, lblDestAddress1, lblDestAddress2, lblDestAddress3, lblDestAddress4, lblDestCity = null;

					UILabel lblSourceCompany = new UILabel(new CGRect(10, yCordinate, viewSourceAddress.Frame.Width - 10, 20));
					lblSourceCompany.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					lblSourceCompany.Text = sourceAddress.Company;
					yCordinate += lblSourceCompany.Frame.Height;
					viewSourceAddress.AddSubview(lblSourceCompany);
					if (sourceAddress.Attention != "")
					{
						lblSourceAttention = new UILabel(new CGRect(10, yCordinate, viewSourceAddress.Frame.Width - 10, 20));
						lblSourceAttention.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
						lblSourceAttention.Text = sourceAddress.Attention;
						yCordinate += lblSourceAttention.Frame.Height;
						viewSourceAddress.AddSubview(lblSourceAttention);
					}

					if (sourceAddress.Address1 != "")
					{
						lblSourceAddress1 = new UILabel(new CGRect(10, yCordinate, viewSourceAddress.Frame.Width - 10, 20));
						lblSourceAddress1.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
						lblSourceAddress1.TextColor = UIColor.Blue;
						lblSourceAddress1.Text = sourceAddress.Address1;
						lblSourceAddress1.UserInteractionEnabled = true;
						yCordinate += lblSourceAddress1.Frame.Height;
						viewSourceAddress.AddSubview(lblSourceAddress1);
						UITapGestureRecognizer tapGestureSourceAddress1 = new UITapGestureRecognizer(ManageNavigation);
						lblSourceAddress1.AddGestureRecognizer(tapGestureSourceAddress1);
					}
					if (sourceAddress.Address2 != "")
					{
						lblSourceAddress2 = new UILabel(new CGRect(10, yCordinate, viewSourceAddress.Frame.Width - 10, 20));
						lblSourceAddress2.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
						lblSourceAddress2.TextColor = UIColor.Blue;
						lblSourceAddress2.Text = sourceAddress.Address2;
						lblSourceAddress2.UserInteractionEnabled = true;
						yCordinate += lblSourceAddress2.Frame.Height;
						viewSourceAddress.AddSubview(lblSourceAddress2);
						UITapGestureRecognizer tapGestureSourceAddress2 = new UITapGestureRecognizer(ManageNavigation);
						lblSourceAddress2.AddGestureRecognizer(tapGestureSourceAddress2);
					}
					if (sourceAddress.Address3 != "")
					{
						lblSourceAddress3 = new UILabel(new CGRect(10, yCordinate, viewSourceAddress.Frame.Width - 10, 20));
						lblSourceAddress3.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
						lblSourceAddress3.TextColor = UIColor.Blue;
						lblSourceAddress3.Text = sourceAddress.Address3;
						lblSourceAddress3.UserInteractionEnabled = true;
						yCordinate += lblSourceAddress3.Frame.Height;
						viewSourceAddress.AddSubview(lblSourceAddress3);
						UITapGestureRecognizer tapGestureSourceAddress3 = new UITapGestureRecognizer(ManageNavigation);
						lblSourceAddress3.AddGestureRecognizer(tapGestureSourceAddress3);
					}
					if (sourceAddress.Address4 != "")
					{
						lblSourceAddress4 = new UILabel(new CGRect(10, yCordinate, viewSourceAddress.Frame.Width - 10, 20));
						lblSourceAddress4.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
						lblSourceAddress4.TextColor = UIColor.Blue;
						lblSourceAddress4.Text = sourceAddress.Address4;
						lblSourceAddress4.UserInteractionEnabled = true;
						yCordinate += lblSourceAddress4.Frame.Height;
						viewSourceAddress.AddSubview(lblSourceAddress4);
						UITapGestureRecognizer tapGestureSourceAddress4 = new UITapGestureRecognizer(ManageNavigation);
						lblSourceAddress4.AddGestureRecognizer(tapGestureSourceAddress4);
					}
					if (sourceAddress.City != "")
					{
						lblSourceCity = new UILabel(new CGRect(10, yCordinate, viewSourceAddress.Frame.Width - 10, 20));
						lblSourceCity.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
						lblSourceCity.TextColor = UIColor.Blue;
						lblSourceCity.Text = sourceAddress.City;
						lblSourceCity.UserInteractionEnabled = true;

						if (sourceAddress.State != "")
						{
							lblSourceCity.Text += ", " + sourceAddress.State + " ";
						}
						if (sourceAddress.Zip != "")
						{
							lblSourceCity.Text += sourceAddress.Zip;
						}

						yCordinate += lblSourceCity.Frame.Height;
						viewSourceAddress.AddSubview(lblSourceCity);
					}
					if (sourceAddress.Country != "")
					{
						UILabel lblSourceCountry = new UILabel(new CGRect(10, yCordinate, viewSourceAddress.Frame.Width - 10, 20));
						lblSourceCountry.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
						lblSourceCountry.Text = sourceAddress.Country;
						yCordinate += lblSourceCountry.Frame.Height;
						viewSourceAddress.AddSubview(lblSourceCountry);
					}
					string origin = sourceAddress.City + ", " + sourceAddress.State + ", " + sourceAddress.Zip + ", " + sourceAddress.Country;
					UITapGestureRecognizer tapGestureSourceCity = new UITapGestureRecognizer(ManageNavigation);
					lblSourceCity.AddGestureRecognizer(tapGestureSourceCity);

					UILabel lblSourcePhone = new UILabel(new CGRect(10, yCordinate, viewSourceAddress.Frame.Width - 10, 20));
					lblSourcePhone.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
                    lblSourcePhone.Text = NSBundle.MainBundle.GetLocalizedString("phone", null) + sourceAddress.Phone;
					yCordinate += lblSourcePhone.Frame.Height;
					viewSourceAddress.AddSubview(lblSourcePhone);

					UILabel lblSourceEmail = new UILabel(new CGRect(10, yCordinate, viewSourceAddress.Frame.Width - 10, 20));
					lblSourceEmail.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
                    lblSourceEmail.Text = NSBundle.MainBundle.GetLocalizedString("email", null) + sourceAddress.Email;
					yCordinate += lblSourceEmail.Frame.Height;
					viewSourceAddress.AddSubview(lblSourceEmail);

					UILabel lblSourceFax = new UILabel(new CGRect(10, yCordinate, viewSourceAddress.Frame.Width - 10, 20));
					lblSourceFax.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
                    lblSourceFax.Text = NSBundle.MainBundle.GetLocalizedString("fax", null) + sourceAddress.Fax;
					viewSourceAddress.AddSubview(lblSourceFax);


					//----------------------------------------Destination Part------------------------------//

					UILabel lblDestCompany = new UILabel(new CGRect(10, yCordinate1, viewDestinationAddress.Frame.Width - 10, 20));
					lblDestCompany.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
                    lblDestCompany.Text = destinationAddress.Company;
					yCordinate1 += lblDestCompany.Frame.Height;
					viewDestinationAddress.AddSubview(lblDestCompany);
					if (destinationAddress.Attention != "")
					{
						lblDestAttention = new UILabel(new CGRect(10, yCordinate1, viewDestinationAddress.Frame.Width - 10, 20));
						lblDestAttention.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
						lblDestAttention.Text = destinationAddress.Attention;
						yCordinate1 += lblDestAttention.Frame.Height;
						viewDestinationAddress.AddSubview(lblDestAttention);
					}

					if (destinationAddress.Address1 != "")
					{
						lblDestAddress1 = new UILabel(new CGRect(10, yCordinate1, viewDestinationAddress.Frame.Width - 10, 20));
						lblDestAddress1.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
						lblDestAddress1.TextColor = UIColor.Blue;
						lblDestAddress1.Text = destinationAddress.Address1;
						lblDestAddress1.UserInteractionEnabled = true;
						yCordinate1 += lblDestAddress1.Frame.Height;
						viewDestinationAddress.AddSubview(lblDestAddress1);
						UITapGestureRecognizer tapGestureDestAddress1 = new UITapGestureRecognizer(ManageNavigation);
						lblDestAddress1.AddGestureRecognizer(tapGestureDestAddress1);
					}
					if (destinationAddress.Address2 != "")
					{
						lblDestAddress2 = new UILabel(new CGRect(10, yCordinate1, viewDestinationAddress.Frame.Width - 10, 20));
						lblDestAddress2.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
						lblDestAddress2.TextColor = UIColor.Blue;
						lblDestAddress2.Text = destinationAddress.Address2;
						lblDestAddress2.UserInteractionEnabled = true;
						yCordinate1 += lblDestAddress2.Frame.Height;
						viewDestinationAddress.AddSubview(lblDestAddress2);
						UITapGestureRecognizer tapGestureDestAddress2 = new UITapGestureRecognizer(ManageNavigation);
						lblDestAddress2.AddGestureRecognizer(tapGestureDestAddress2);
					}
					if (destinationAddress.Address3 != "")
					{
						lblDestAddress3 = new UILabel(new CGRect(10, yCordinate1, viewDestinationAddress.Frame.Width - 10, 20));
						lblDestAddress3.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
						lblDestAddress3.TextColor = UIColor.Blue;
						lblDestAddress3.Text = destinationAddress.Address3;
						lblDestAddress3.UserInteractionEnabled = true;
						yCordinate1 += lblDestAddress3.Frame.Height;
						viewDestinationAddress.AddSubview(lblDestAddress3);
						UITapGestureRecognizer tapGestureDestAddress3 = new UITapGestureRecognizer(ManageNavigation);
						lblDestAddress3.AddGestureRecognizer(tapGestureDestAddress3);
					}
					if (destinationAddress.Address4 != "")
					{
						lblDestAddress4 = new UILabel(new CGRect(10, yCordinate1, viewDestinationAddress.Frame.Width - 10, 20));
						lblDestAddress4.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
						lblDestAddress4.TextColor = UIColor.Blue;
						lblDestAddress4.Text = destinationAddress.Address4;
						lblDestAddress4.UserInteractionEnabled = true;
						yCordinate1 += lblDestAddress4.Frame.Height;
						viewDestinationAddress.AddSubview(lblDestAddress4);
						UITapGestureRecognizer tapGesturelblDestAddress4 = new UITapGestureRecognizer(ManageNavigation);
						lblDestAddress4.AddGestureRecognizer(tapGesturelblDestAddress4);
					}
					if (destinationAddress.City != "")
					{
						lblDestCity = new UILabel(new CGRect(10, yCordinate1, viewDestinationAddress.Frame.Width - 10, 20));
						lblDestCity.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
						lblDestCity.TextColor = UIColor.Blue;
						lblDestCity.Text = destinationAddress.City;
						lblDestCity.UserInteractionEnabled = true;
						if (destinationAddress.State != "")
						{
							lblDestCity.Text += ", " + destinationAddress.State + " ";
						}
						if (destinationAddress.Zip != "")
						{
							lblDestCity.Text += destinationAddress.Zip;
						}

						yCordinate1 += lblDestCity.Frame.Height;
						viewDestinationAddress.AddSubview(lblDestCity);
					}
					if (destinationAddress.Country != "")
					{
						UILabel lblDestCountry = new UILabel(new CGRect(10, yCordinate1, viewDestinationAddress.Frame.Width - 10, 20));
						lblDestCountry.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
						lblDestCountry.Text = destinationAddress.Country;
						yCordinate1 += lblDestCountry.Frame.Height;
						viewDestinationAddress.AddSubview(lblDestCountry);
					}

					string destination = destinationAddress.City + ", " + destinationAddress.State + ", " + destinationAddress.Zip + ", " + destinationAddress.Country;

					addressKey = origin + "#" + destination + "#" + objCarrierShipmentDetails.BolNum;
					UITapGestureRecognizer tapGestureDesCity = new UITapGestureRecognizer(ManageNavigation);
					lblDestCity.AddGestureRecognizer(tapGestureDesCity);

					UILabel lblDestPhone = new UILabel(new CGRect(10, yCordinate1, viewDestinationAddress.Frame.Width - 10, 20));
					lblDestPhone.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					lblDestPhone.Text = NSBundle.MainBundle.GetLocalizedString("phone", null) + destinationAddress.Phone;
					yCordinate1 += lblDestPhone.Frame.Height;
					viewDestinationAddress.AddSubview(lblDestPhone);

					UILabel lblDestEmail = new UILabel(new CGRect(10, yCordinate1, viewDestinationAddress.Frame.Width - 10, 20));
					lblDestEmail.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					lblDestEmail.Text = NSBundle.MainBundle.GetLocalizedString("email", null) + destinationAddress.Email;
					yCordinate1 += lblDestEmail.Frame.Height;
					viewDestinationAddress.AddSubview(lblDestEmail);

					UILabel lblDestFax = new UILabel(new CGRect(10, yCordinate1, viewDestinationAddress.Frame.Width - 10, 20));
					lblDestFax.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					lblDestFax.Text = NSBundle.MainBundle.GetLocalizedString("fax", null) + destinationAddress.Fax;
					viewDestinationAddress.AddSubview(lblDestFax);

				}
				viewAddressContent.Add(viewAddressHeader);
				viewAddressContent.Add(viewSourceAddress);

				viewAddressContent.Frame = new CGRect(0, 0, tableView.Frame.Width, viewAddressHeader.Frame.Height + viewSourceAddress.Frame.Height + 1);
				viewAddressContent.Add(viewDestinationAddress);
			}
			catch
			{
				throw;
			}
		}

		public void ManageNavigation(UITapGestureRecognizer tapGesture)
		{
			try
			{
				shipmentDetailController.RedirectToMap(addressKey);
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}
	}
}