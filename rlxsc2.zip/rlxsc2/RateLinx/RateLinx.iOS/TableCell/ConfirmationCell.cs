using Foundation;
using System;
using UIKit;
using RateLinx.Models;
using CoreGraphics;
using RateLinx.Helper;

namespace RateLinx.iOS
{
    public partial class ConfirmationCell : UITableViewCell
    {
		ShipmentDetailController objShipmentDetailController;
		string confirmationType = string.Empty;

        public ConfirmationCell (IntPtr handle) : base (handle)
        {
        }

		internal void UpdateCell(CarrierShipmentDetails objCarrierShipmentDetails,ShipmentDetailController shipmentDetailController, UITableView tableView)
		{
			foreach (UIView view in viewConfirmation)
			{
				view.RemoveFromSuperview();
			}
			objShipmentDetailController = shipmentDetailController;
			UIButton btnPickupConfirmation = new UIButton(new CGRect(10, 10, tableView.Frame.Width/2 -20, 25));
			btnPickupConfirmation.Layer.CornerRadius = 5;
			btnPickupConfirmation.BackgroundColor = UIColor.FromRGB(157, 34, 53);
			btnPickupConfirmation.Font = UIFont.FromName(Constants.strFontName, 13f);
			btnPickupConfirmation.SetTitle(NSBundle.MainBundle.GetLocalizedString("pickupConfirmation", null), UIControlState.Normal);
			btnPickupConfirmation.UserInteractionEnabled = true;

			btnPickupConfirmation.TouchUpInside += delegate {
                confirmationType = NSBundle.MainBundle.GetLocalizedString("pickupConfirmation", null);
				GoTopuckupAndDeliveryConfirmation(objCarrierShipmentDetails.ProNum);
			};

			UIButton btnDeliveryConfirmation = new UIButton(new CGRect(tableView.Frame.Width / 2 + 10, 10, tableView.Frame.Width/2 -20, 25));
			btnDeliveryConfirmation.Layer.CornerRadius = 5;
			btnDeliveryConfirmation.BackgroundColor = UIColor.FromRGB(157, 34, 53);
			btnDeliveryConfirmation.Font = UIFont.FromName(Constants.strFontName, 13f);
            btnDeliveryConfirmation.SetTitle(NSBundle.MainBundle.GetLocalizedString("deliveryConfirmation", null), UIControlState.Normal);
			btnDeliveryConfirmation.TouchUpInside += delegate
			{
                confirmationType = NSBundle.MainBundle.GetLocalizedString("deliveryConfirmation", null);
				GoTopuckupAndDeliveryConfirmation(objCarrierShipmentDetails.ProNum);
			};
            UIButton btnEquipmentScan;
            if (objCarrierShipmentDetails.DispatchFlag && string.IsNullOrEmpty(objCarrierShipmentDetails.DriverID))
            {
                btnEquipmentScan =new UIButton(new CGRect(10, 10, tableView.Frame.Width / 2 - 20, 25));
            }
            else
            {
                 btnEquipmentScan = new UIButton(new CGRect(10, 45, tableView.Frame.Width / 2 - 20, 25)); 
            }
			
			btnEquipmentScan.Layer.CornerRadius = 5;
			btnEquipmentScan.BackgroundColor = UIColor.FromRGB(157, 34, 53);
			btnEquipmentScan.Font = UIFont.FromName(Constants.strFontName, 13f);
			btnEquipmentScan.SetTitle(Constants.strEquipment, UIControlState.Normal);
			btnEquipmentScan.UserInteractionEnabled = true;

			btnEquipmentScan.TouchUpInside +=delegate {
				GoToEquipmentScanning();
				
			};

            UIButton btnFindCurrentLoc;
            if (objCarrierShipmentDetails.DispatchFlag && string.IsNullOrEmpty(objCarrierShipmentDetails.DriverID))
            {
                btnFindCurrentLoc = new UIButton(new CGRect(tableView.Frame.Width / 2 + 10, 10, tableView.Frame.Width / 2 - 20, 25));
            }
            else
            {
                btnFindCurrentLoc = new UIButton(new CGRect(tableView.Frame.Width / 2 + 10, 45, tableView.Frame.Width / 2 - 20, 25));
            }

			 
			if (objCarrierShipmentDetails.ViewAs.Equals(Constants.strCustomer.ToUpper()))
			{
				//btnFindCurrentLoc.Frame = new CGRect(tableView.Frame.Width / 2 + 10, 45, tableView.Frame.Width / 2 - 20, 25);
				btnFindCurrentLoc.Layer.CornerRadius = 5;
				btnFindCurrentLoc.BackgroundColor = UIColor.FromRGB(157, 34, 53);
				btnFindCurrentLoc.Font = UIFont.FromName(Constants.strFontName, 13f);
				btnFindCurrentLoc.SetTitle(Constants.btnTextCurrentLc, UIControlState.Normal);
				btnFindCurrentLoc.TouchUpInside += delegate
				{
					string trackingKey = objCarrierShipmentDetails.ClientID + "|" + objCarrierShipmentDetails.LocID + "|" + objCarrierShipmentDetails.BolNum + "#" + "";
					objShipmentDetailController.RedirectToShipmentTracking(trackingKey);
				};
				viewConfirmation.Frame = new CGRect(0, 0, tableView.Frame.Width, 80);
			}
            if (objCarrierShipmentDetails.DispatchFlag && string.IsNullOrEmpty(objCarrierShipmentDetails.DriverID))
            {
                viewConfirmation.AddSubviews(btnEquipmentScan, btnFindCurrentLoc);
            }
            else
            {
                viewConfirmation.AddSubviews(btnPickupConfirmation, btnDeliveryConfirmation, btnEquipmentScan, btnFindCurrentLoc);
            }
		}

		void GoToEquipmentScanning()
		{

			objShipmentDetailController.RedirectToEquipmentScanning();
		}

		void GoTopuckupAndDeliveryConfirmation(string proNumber)
		{
			objShipmentDetailController.RedirectToConfirmation(confirmationType, proNumber);
		}
}
}