using System;
using System.Collections.Generic;
using CoreGraphics;
using Foundation;
using RateLinx.Helper;
using RateLinx.Models;
using UIKit;

namespace RateLinx.iOS
{
	class ShipmentContentsAdapter : UITableViewSource
	{
		List<Content> lstContents;

		public ShipmentContentsAdapter(List<Content> lstContents)
		{
			this.lstContents = lstContents;
		}

		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			nfloat xCordinate = 0;
			ConstantsClass.fontSize = 11f;
			UIColor altColor = null;
			UITableViewCell objContentCell = new UITableViewCell(new CGRect(0, 0, tableView.Frame.Width, 25));

			UIView viewContents = new UIView(new CGRect(0, 0, objContentCell.Frame.Width, 25));

			//objContentCell.BackgroundColor = UIColor.Red;

			objContentCell.AddSubview(viewContents);


			Dictionary<string, object> dictionaryContent = new Dictionary<string, object>();
			foreach (var prop in lstContents[indexPath.Row].GetType().GetProperties())
			{
				Console.WriteLine("{0} = {1}", prop.Name, prop.GetValue(lstContents[indexPath.Row], null));

				dictionaryContent.Add(prop.Name, prop.GetValue(lstContents[indexPath.Row], null));
			}
			if (indexPath.Row % 2 == 0)
			{
				altColor = UIColor.FromRGB(224, 223, 223);
			}
			else
			{
				altColor = UIColor.LightGray;
			}
			//xCordinate
			foreach (KeyValuePair<string, object> kvpContent in dictionaryContent)
			{
				if (kvpContent.Key.ToUpper().Equals(NSBundle.MainBundle.LocalizedString("PRODUCERCOUNTRY", null)))
				{
					UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
					objLabel.BackgroundColor = UIColor.FromRGB(75, 72, 69);
					objLabel.Text = NSBundle.MainBundle.LocalizedString("country", null);
					objLabel.TextColor = UIColor.White;
					objLabel.TextAlignment = UITextAlignment.Center;
					objLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					viewContents.AddSubview(objLabel);
					xCordinate = objLabel.Frame.X + 101;
				}
				else if (kvpContent.Key.ToUpper().Equals(NSBundle.MainBundle.LocalizedString("itemCode", null)))
				{
					UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
					objLabel.BackgroundColor = UIColor.FromRGB(75, 72, 69);
					objLabel.Text = NSBundle.MainBundle.LocalizedString("code", null);
					objLabel.TextColor = UIColor.White;
					objLabel.TextAlignment = UITextAlignment.Center;
					objLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					viewContents.AddSubview(objLabel);
					xCordinate = objLabel.Frame.X + 101;
				}
				else if (kvpContent.Key.ToUpper().Equals("ITEMNUMBER"))
				{
					UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
					objLabel.BackgroundColor = UIColor.FromRGB(75, 72, 69);
					objLabel.Text = NSBundle.MainBundle.LocalizedString("number", null);
					objLabel.TextColor = UIColor.White;
					objLabel.TextAlignment = UITextAlignment.Center;
					objLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					viewContents.AddSubview(objLabel);
					xCordinate = objLabel.Frame.X + 101;
				}
				else if (kvpContent.Key.ToUpper().Equals(NSBundle.MainBundle.LocalizedString("description", null)))
				{
					UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
					objLabel.BackgroundColor = UIColor.FromRGB(75, 72, 69);
					objLabel.Text = NSBundle.MainBundle.LocalizedString("description", null);
					objLabel.TextColor = UIColor.White;
					objLabel.TextAlignment = UITextAlignment.Center;
					objLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					viewContents.AddSubview(objLabel);
					xCordinate = objLabel.Frame.X + 101;
				}
				else if (kvpContent.Key.ToUpper().Equals(NSBundle.MainBundle.LocalizedString("qty", null)))
				{
					UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
					objLabel.BackgroundColor = UIColor.FromRGB(75, 72, 69);
					objLabel.Text = NSBundle.MainBundle.LocalizedString("qty", null);
					objLabel.TextColor = UIColor.White;
					objLabel.TextAlignment = UITextAlignment.Center;
					objLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					viewContents.AddSubview(objLabel);
					xCordinate = objLabel.Frame.X + 101;
				}
				else if (kvpContent.Key.ToUpper().Equals(NSBundle.MainBundle.LocalizedString("UOM", null)))
				{
					UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
					objLabel.BackgroundColor = UIColor.FromRGB(75, 72, 69);
					objLabel.Text = NSBundle.MainBundle.LocalizedString("UOM", null);
					objLabel.TextColor = UIColor.White;
					objLabel.TextAlignment = UITextAlignment.Center;
					objLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					viewContents.AddSubview(objLabel);
					xCordinate = objLabel.Frame.X + 101;
				}
				else if (kvpContent.Key.ToUpper().Equals(NSBundle.MainBundle.LocalizedString("UNITVALUE", null)))
				{
					UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
					objLabel.BackgroundColor = UIColor.FromRGB(75, 72, 69);
					objLabel.Text = NSBundle.MainBundle.LocalizedString("price", null);
					objLabel.TextColor = UIColor.White;
					objLabel.TextAlignment = UITextAlignment.Center;
					objLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					viewContents.AddSubview(objLabel);
					xCordinate = objLabel.Frame.X + 101;
				}
				else if (kvpContent.Key.ToUpper().Equals(NSBundle.MainBundle.LocalizedString("DECLAREDVALUE", null)))
				{
					UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
					objLabel.BackgroundColor = UIColor.FromRGB(75, 72, 69);
					objLabel.Text = NSBundle.MainBundle.LocalizedString("value", null);
					objLabel.TextColor = UIColor.White;
					objLabel.TextAlignment = UITextAlignment.Center;
					objLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					viewContents.AddSubview(objLabel);
					xCordinate = objLabel.Frame.X + 101;
				}
				else if (kvpContent.Key.ToUpper().Equals(NSBundle.MainBundle.LocalizedString("weight", null)))
				{
					UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
					objLabel.BackgroundColor = UIColor.FromRGB(75, 72, 69);
					objLabel.Text = NSBundle.MainBundle.LocalizedString("weight", null);
					objLabel.TextColor = UIColor.White;
					objLabel.TextAlignment = UITextAlignment.Center;
					objLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					viewContents.AddSubview(objLabel);
					xCordinate = objLabel.Frame.X + 101;
				}
			}
			return objContentCell;
		}

		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return lstContents.Count;
		}
	}
}