using Foundation;
using System;
using UIKit;
using RateLinx.Models;
using System.Collections.Generic;
using CoreGraphics;
using RateLinx.Helper;

namespace RateLinx.iOS
{
    public partial class RateDetailLineCell : UITableViewCell
    {
		//static nfloat xCordinate = 0;
        public RateDetailLineCell (IntPtr handle) : base (handle)
        {
        }

		internal void UpdateCell(CarrierShipmentDetails objCarrierShipmentDetails, UITableView tableView)
		{
            //viewLineDetails.Frame = new CGRect(0,0, tableView.Frame.wi)
			nfloat xCordinate = 0;
			UIView viewLine = new UIView(new CGRect(0, 0, tableView.Frame.Width, 1));
			viewLine.BackgroundColor = UIColor.White;
			viewLineDetails.AddSubview(viewLine);

            UIScrollView scrollView = new UIScrollView
            {
                Frame = new CGRect(0, 1, tableView.Frame.Width, objCarrierShipmentDetails.LineDetails.Count * 25 + 20),
                ContentSize = new CGSize(1008, 100),
                BackgroundColor = UIColor.LightGray,
                AutoresizingMask = UIViewAutoresizing.FlexibleWidth,
                Bounces = false
            };


			List<LineDetail> lstLineDetails = objCarrierShipmentDetails.LineDetails;

			Dictionary<string, object> dictionaryLineDetail = new Dictionary<string, object>();
			foreach (var prop in lstLineDetails[0].GetType().GetProperties())
			{
				Console.WriteLine("{0} = {1}", prop.Name, prop.GetValue(lstLineDetails[0], null));

				dictionaryLineDetail.Add(prop.Name, prop.GetValue(lstLineDetails[0], null));
			}
			ConstantsClass.fontSize = 12f;
			//xCordinate
			foreach (KeyValuePair<string, object> kvpLineDetail in dictionaryLineDetail)
			{
				if (kvpLineDetail.Key.Equals(NSBundle.MainBundle.GetLocalizedString("lineNum",null)))
				{
					UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
					objLabel.BackgroundColor = UIColor.FromRGB(75, 72, 69);
                    objLabel.Text = NSBundle.MainBundle.GetLocalizedString("line",null);
					objLabel.TextColor = UIColor.White;
					objLabel.TextAlignment = UITextAlignment.Center;
					objLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					scrollView.AddSubview(objLabel);
					xCordinate = objLabel.Frame.X + 101;
				}
                else if (kvpLineDetail.Key.Equals(NSBundle.MainBundle.GetLocalizedString("pallets",null)))
				{
					UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
					objLabel.BackgroundColor = UIColor.FromRGB(75, 72, 69);
                    objLabel.Text = NSBundle.MainBundle.GetLocalizedString("pallets",null);
					objLabel.TextColor = UIColor.White;
					objLabel.TextAlignment = UITextAlignment.Center;
					objLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					scrollView.AddSubview(objLabel);
					xCordinate = objLabel.Frame.X + 101;
				}
                else if (kvpLineDetail.Key.Equals(NSBundle.MainBundle.GetLocalizedString("pieces",null)))
				{
					UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
					objLabel.BackgroundColor = UIColor.FromRGB(75, 72, 69);
                    objLabel.Text = NSBundle.MainBundle.GetLocalizedString("pieces",null);
					objLabel.TextColor = UIColor.White;
					objLabel.TextAlignment = UITextAlignment.Center;
					objLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					scrollView.AddSubview(objLabel);
					xCordinate = objLabel.Frame.X + 101;
				}
                else if (kvpLineDetail.Key.Equals(NSBundle.MainBundle.GetLocalizedString("UOM",null)))
				{
					UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
					objLabel.BackgroundColor = UIColor.FromRGB(75, 72, 69);
                    objLabel.Text = NSBundle.MainBundle.GetLocalizedString("UOM",null);
					objLabel.TextColor = UIColor.White;
					objLabel.TextAlignment = UITextAlignment.Center;
					objLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					scrollView.AddSubview(objLabel);
					xCordinate = objLabel.Frame.X + 101;
				}
                else if (kvpLineDetail.Key.Equals(NSBundle.MainBundle.GetLocalizedString("item",null)))
				{
					UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
					objLabel.BackgroundColor = UIColor.FromRGB(75, 72, 69);
                    objLabel.Text = NSBundle.MainBundle.GetLocalizedString("item",null);
					objLabel.TextColor = UIColor.White;
					objLabel.TextAlignment = UITextAlignment.Center;
					objLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					scrollView.AddSubview(objLabel);
					xCordinate = objLabel.Frame.X + 101;
				}
                else if (kvpLineDetail.Key.Equals(NSBundle.MainBundle.GetLocalizedString("descr",null)))
				{
					UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
					objLabel.BackgroundColor = UIColor.FromRGB(75, 72, 69);
                    objLabel.Text = NSBundle.MainBundle.GetLocalizedString("description",null);
					objLabel.TextColor = UIColor.White;
					objLabel.TextAlignment = UITextAlignment.Center;
					objLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					scrollView.AddSubview(objLabel);
                    xCordinate = objLabel.Frame.X + 101;
				}
                else if (kvpLineDetail.Key.Equals(NSBundle.MainBundle.GetLocalizedString("length",null)))
				{
					UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
					objLabel.BackgroundColor = UIColor.FromRGB(75, 72, 69);
                    objLabel.Text = NSBundle.MainBundle.GetLocalizedString("dimension",null);
					objLabel.TextColor = UIColor.White;
					objLabel.TextAlignment = UITextAlignment.Center;
					objLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					scrollView.AddSubview(objLabel);
					xCordinate = objLabel.Frame.X + 101;
				}
                else if (kvpLineDetail.Key.Equals(NSBundle.MainBundle.GetLocalizedString("strClass",null)))
				{
					UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
					objLabel.BackgroundColor = UIColor.FromRGB(75, 72, 69);
                    objLabel.Text = NSBundle.MainBundle.GetLocalizedString("strClass",null);
					objLabel.TextColor = UIColor.White;
					objLabel.TextAlignment = UITextAlignment.Center;
					objLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					scrollView.AddSubview(objLabel);
					xCordinate = objLabel.Frame.X + 101;
				}
                else if (kvpLineDetail.Key.Equals(NSBundle.MainBundle.GetLocalizedString("FAK",null)))
				{
					UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
					objLabel.BackgroundColor = UIColor.FromRGB(75, 72, 69);
                    objLabel.Text = NSBundle.MainBundle.GetLocalizedString("FAK",null) + " "+
                        NSBundle.MainBundle.GetLocalizedString("strClass",null) ;
					objLabel.TextColor = UIColor.White;
					objLabel.TextAlignment = UITextAlignment.Center;
					objLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					scrollView.AddSubview(objLabel);
					xCordinate = objLabel.Frame.X + 101;
				}
                else if (kvpLineDetail.Key.Equals(NSBundle.MainBundle.GetLocalizedString("weight",null)))
				{
					UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 20));
					objLabel.BackgroundColor = UIColor.FromRGB(75, 72, 69);
                    objLabel.Text = NSBundle.MainBundle.GetLocalizedString("weight",null);
					objLabel.TextColor = UIColor.White;
					objLabel.TextAlignment = UITextAlignment.Center;
					objLabel.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					scrollView.AddSubview(objLabel);
					xCordinate = objLabel.Frame.X + 101;
				}
			}

            viewLineDetails.Frame = new CGRect(0, 0, tableView.Frame.Width, 20 + lstLineDetails.Count * 25);
			UITableView tblLineDetails = new UITableView
			{
				Frame = new CGRect(0, 20, xCordinate, viewLineDetails.Frame.Height - 20),
				ContentSize = new CGSize(viewLineDetails.Frame.Width, viewLineDetails.Frame.Height - 20),
				AutoresizingMask = UIViewAutoresizing.FlexibleWidth,
				BackgroundColor = UIColor.Red,
				Bounces = false
			};

			tblLineDetails.Source = new LineDetailsAdapter(lstLineDetails);
			tblLineDetails.AutoresizingMask = UIViewAutoresizing.FlexibleWidth;
            tblLineDetails.RowHeight = 25;
			tblLineDetails.BackgroundColor = UIColor.Red;

            scrollView.DirectionalLockEnabled = true;
			scrollView.AddSubview(tblLineDetails);
			
			viewLineDetails.Add(scrollView);
		}
	}
}