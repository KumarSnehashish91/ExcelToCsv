using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;
using RateLinx.Models;
using RateLinx.Helper;
using System.Collections.Generic;
using CoreGraphics;
using Plugin.Connectivity;

namespace RateLinx.iOS
{
	partial class ActiveShipmentCells : UITableViewCell
	{
		DashboardController dashboardController;
		string compositeKey;
		UIView viewBidDetails;
		UIView viewBidsHeader;
		UITapGestureRecognizer tapGestureTo, tapGestureFrom;
		string addressKey;
		CustomPopup customAlert = null;
		public ActiveShipmentCells(IntPtr handle) : base(handle)
		{
			viewBidDetails = new UIView();
			viewBidsHeader = new UIView();
		}

		public void UpdateCell(DashboardController dashboardController, ActiveShipments objActiveShipment, int rowNum, UITableView tableView)
		{
			UIColor evenColor, oddColor;
			if (objActiveShipment.ViewAs.ToUpper() == Constants.strCarrier.ToUpper())
			{
				if (objActiveShipment.CarrierAlertLevel.ToUpper() == Constants.btnTextOk.ToUpper())
				{
					evenColor = UIColor.FromRGB(138, 230, 138);
					oddColor = UIColor.FromRGB(153, 255, 153);
				}
				else if (objActiveShipment.CarrierAlertLevel.ToUpper() == Constants.strWarning.ToUpper())
				{
					evenColor = UIColor.FromRGB(239, 239, 143);
					oddColor = UIColor.FromRGB(255, 255, 153);
				}
				else
				{
					evenColor = UIColor.FromRGB(243, 146, 146);
					oddColor = UIColor.FromRGB(255, 153, 153);
				}
			}
			else
			{
				evenColor = UIColor.FromRGB(216,215,215);
				oddColor = UIColor.FromRGB(236,234,234);
			}
			compositeKey = objActiveShipment.ClientID + "|" + objActiveShipment.BolNum + "|" + "";
			this.dashboardController = dashboardController;

			nfloat yCordinate = 0;

			nfloat width = tableView.Frame.Width;

			UIView viewActiveShipmentContainer = new UIView();


			UIView viewActiveShipmentHeader = new UIView(new CGRect(0, yCordinate, width, 45));
			viewActiveShipmentHeader.BackgroundColor = UIColor.Black;
			yCordinate += viewActiveShipmentHeader.Frame.Height;


			UIImageView imgHammer = new UIImageView(new CGRect(5, 12, 20, 20));
			imgHammer.Image = UIImage.FromBundle("Images/hammer-icon.png");

			UILabel lblBolWithPrice = new UILabel(new CGRect(30 , 0, width * 0.6, 45));
			lblBolWithPrice.Lines = 0;
			lblBolWithPrice.LineBreakMode = UILineBreakMode.WordWrap;
			lblBolWithPrice.TextColor = UIColor.White;
			lblBolWithPrice.Font = UIFont.FromName(Constants.strFontName, 10f);


			UILabel lblTimer = new UILabel(new CGRect(width * 0.6 + 35, 0, width * 0.2, 45));
			lblTimer.Lines = 0;
			lblTimer.LineBreakMode = UILineBreakMode.WordWrap;
			lblTimer.TextColor = UIColor.White;
			lblTimer.Font = UIFont.FromName(Constants.strFontName, 10f);

			UIImageView imgArrow = new UIImageView(new CGRect(width - 25, 12, 20, 20));
			imgArrow.Image = UIImage.FromBundle("Images/arrow-icon.png");

			UIButton btnActiveShipmentHeader = new UIButton();
			btnActiveShipmentHeader.Frame = viewActiveShipmentHeader.Bounds;
			btnActiveShipmentHeader.TouchUpInside += delegate {
				if (Reachability.InternetConnectionStatus())
				{
					GoToShipmentDetails(objActiveShipment.ClientID + "|" + objActiveShipment.BolNum + "|" + "");
				}
				else
				{
                    this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.isOnline, true, dashboardController, "", 1);
					dashboardController.View.Add(this.customAlert);
					return;
				}
                	
			};

			viewActiveShipmentHeader.AddSubviews(imgHammer, imgArrow, lblTimer, lblBolWithPrice, btnActiveShipmentHeader);


			List<UIView> lstViews = new List<UIView>();

			UIView viewFor = new UIView(new CGRect(0, 0, 0, 0));

			if (objActiveShipment.ViewAs.ToUpper() == Constants.strCarrier.ToUpper())
			{
				viewFor.Frame = new CGRect(0, yCordinate, width, 40);

				viewFor.BackgroundColor = evenColor;
				//viewFor.BackgroundColor = UIColor.LightGray;

				UILabel lblForLabel = new UILabel(new CGRect(20, 0, width / 3, 40));
				lblForLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
				lblForLabel.Text = NSBundle.MainBundle.LocalizedString("for",null);


				UILabel lblForText = new UILabel(new CGRect(width / 3 + 20, 0, width - (width / 3 + 20), 40));
				lblForText.Font = UIFont.FromName(Constants.strFontName, 13f);
				lblForText.Text = objActiveShipment.ClientID;
				viewFor.AddSubviews(lblForLabel, lblForText);

				yCordinate += 40;

				//viewActiveShipmentContainer.AddSubview(viewFor);
				lstViews.Add(viewFor);
			}


			UIView viewDeadLine = new UIView(new CGRect(0, yCordinate, width, 40));
			viewDeadLine.BackgroundColor = oddColor;
			//viewDeadLine.BackgroundColor = UIColor.Green;

			UILabel lblDeadLineLabel = new UILabel(new CGRect(20, 0, width / 3, 40));
			lblDeadLineLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
			lblDeadLineLabel.Text = NSBundle.MainBundle.LocalizedString("deadLine",null);

			UILabel lblDeadLineText = new UILabel(new CGRect(width / 3 + 20, 0, width - (width / 3 + 20), 40));
			lblDeadLineText.Font = UIFont.FromName(Constants.strFontName, 13f);
			lblDeadLineText.Text = objActiveShipment.DeadLineStr;

			viewDeadLine.AddSubviews(lblDeadLineLabel, lblDeadLineText);
			lstViews.Add(viewDeadLine);
			yCordinate += 40;

			UIView viewFrom = new UIView(new CGRect(0, yCordinate, width, 40));
			viewFrom.BackgroundColor = evenColor;
			//viewFrom.BackgroundColor = UIColor.LightGray;

			UILabel lblFromLabel = new UILabel(new CGRect(20, 0, width / 3, 40));
			lblFromLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
			lblFromLabel.Text = NSBundle.MainBundle.LocalizedString("from",null);


			UILabel lblFromText = new UILabel(new CGRect(width / 3 + 20, 0, width - (width / 3 + 20), 40));
			lblFromText.Font = UIFont.FromName(Constants.strFontName, 13f);
			lblFromText.Text = objActiveShipment.OriginCity + ", " + objActiveShipment.OriginState + " " + objActiveShipment.OriginZip;
			lblFromText.Lines = 0;
			lblFromText.UserInteractionEnabled = true;
			lblFromText.TextColor = UIColor.Blue;
			viewFrom.AddSubviews(lblFromLabel, lblFromText);
			lstViews.Add(viewFrom);
			yCordinate += 40;


			UIView viewTo = new UIView(new CGRect(0, yCordinate, width, 40));
			viewTo.BackgroundColor = oddColor;
			//viewTo.BackgroundColor = UIColor.Green;

			UILabel lblToLabel = new UILabel(new CGRect(20, 0, width / 3, 40));
			lblToLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
			lblToLabel.Text = NSBundle.MainBundle.LocalizedString("to",null);

			UILabel lblToText = new UILabel(new CGRect(width / 3 + 20, 0, width - (width / 3 + 20), 40));
			lblToText.Font = UIFont.FromName(Constants.strFontName, 13f);
			lblToText.Text = objActiveShipment.ShipToCity + ", " + objActiveShipment.ShipToState + " " + objActiveShipment.ShipToZip;
			lblToText.TextColor = UIColor.Blue;
			lblToText.UserInteractionEnabled = true;
			lblToText.Lines = 0;
			viewTo.AddSubviews(lblToLabel, lblToText);
			lstViews.Add(viewTo);
			yCordinate += 40;


			UIView viewPickup = new UIView(new CGRect(0, yCordinate, width, 40));
			viewPickup.BackgroundColor = evenColor;
			//viewPickup.BackgroundColor = UIColor.LightGray;

			UILabel lblPickupLabel = new UILabel(new CGRect(20, 0, width / 3, 40));
			lblPickupLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
			lblPickupLabel.Text = NSBundle.MainBundle.LocalizedString("pickup",null);


			UILabel lblPickupText = new UILabel(new CGRect(width / 3 + 20, 0, width - (width / 3 + 20), 40));
			lblPickupText.Font = UIFont.FromName(Constants.strFontName, 13f);
			lblPickupText.Text = objActiveShipment.PickupStr;
			lblPickupText.Lines = 0;
			viewPickup.AddSubviews(lblPickupLabel, lblPickupText);
			lstViews.Add(viewPickup);
			yCordinate += 40;


			UIView viewMode = new UIView(new CGRect(0, yCordinate, width, 40));
			viewMode.BackgroundColor = oddColor;
			//viewMode.BackgroundColor = UIColor.Green;

			UILabel lblModeLabel = new UILabel(new CGRect(20, 0, width / 3, 40));
			lblModeLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
			lblModeLabel.Text = NSBundle.MainBundle.LocalizedString("mode",null);


			UILabel lblModeText = new UILabel(new CGRect(width / 3 + 20, 0, width - (width / 3 + 20), 40));
			lblModeText.Font = UIFont.FromName(Constants.strFontName, 13f);
			lblModeText.Text = objActiveShipment.Mode;
			lblModeText.Lines = 0;

			viewMode.AddSubviews(lblModeLabel, lblModeText);
			lstViews.Add(viewMode);
			yCordinate += 40;


			viewActiveShipmentContainer.AddSubviews(viewFor, viewActiveShipmentHeader, viewDeadLine, viewFrom, viewTo, viewPickup, viewMode);

			//viewActiveShipmentContainer.BackgroundColor = UIColor.Red;

			viewActiveShipmentContainer.Frame = new CGRect(0, 0, width, yCordinate);
			viewBidDetails.RemoveFromSuperview();

			UILabel lblBidMsg = new UILabel(new CGRect(20, 0, width / 10 * 6, 40));
			lblBidMsg.Font = UIFont.FromName(Constants.strFontName, 13f);
			lblBidMsg.TextColor = UIColor.FromRGB(137,18,40);

			if (objActiveShipment.ViewAs.ToUpper() == Constants.strCarrier.ToUpper())
			{
				viewBidDetails.Frame = new CGRect(0, viewActiveShipmentContainer.Frame.Bottom, width, 40);

				if (objActiveShipment.CarriersBid > 0)
				{
					lblBidMsg.Frame = new CGRect(20, 0, width / 10 * 5, 40);
					lblBidMsg.Text = NSBundle.MainBundle.LocalizedString("youCurrentBid",null);


					UILabel lblBidAmount = new UILabel(new CGRect(width / 10 * 5 + 30, 0, width / 10 * 3, 40));
					lblBidAmount.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblBidAmount.TextColor = UIColor.Blue;
					lblBidAmount.Text = "$" + Convert.ToString(objActiveShipment.CarriersBid);

					foreach (UIView view in viewBidDetails)
					{
						view.RemoveFromSuperview();
					}

					viewBidDetails.AddSubviews(lblBidMsg, lblBidAmount);

					//yCordinate += 40;

				}
				else
				{
					foreach (UIView view in viewBidDetails)
					{
						view.RemoveFromSuperview();
					}
					lblBidMsg.Text = NSBundle.MainBundle.LocalizedString("noBid",null);

					UIButton btnBidNow = new UIButton(new CGRect(width / 10 * 6 + 30, 9, width / 10 * 2, 22));
					btnBidNow.SetTitle(NSBundle.MainBundle.LocalizedString("bidNow",null), UIControlState.Normal);
					btnBidNow.Font = UIFont.FromName(Constants.strFontName, 13f);
					btnBidNow.Layer.CornerRadius = 5;
					btnBidNow.BackgroundColor = UIColor.FromRGB(137,18,40);
					btnBidNow.TouchUpInside +=delegate {
						if (Reachability.InternetConnectionStatus())
						{
							compositeKey = objActiveShipment.ClientID + "|" + objActiveShipment.BolNum + "|" + ConstantsClass.strBid;
							dashboardController.SegueFromDashboradToShipmentDetail(compositeKey);

						}
						else
						{
							this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, dashboardController, "", 1);
							dashboardController.View.Add(this.customAlert);
						}
					};
					viewBidDetails.AddSubviews(lblBidMsg, btnBidNow);
				}
			}
			else
			{
				
				if (objActiveShipment.Bids != null && objActiveShipment.Bids.Count > 0)
				{
					viewBidDetails.Frame = new CGRect(0, viewActiveShipmentContainer.Frame.Bottom, width, 40 + objActiveShipment.Bids.Count * 30);

					viewBidsHeader.RemoveFromSuperview();
					foreach (UIView view in viewBidDetails)
					{
						view.RemoveFromSuperview();
					}

					foreach (UIView view in viewBidsHeader)
					{
						view.RemoveFromSuperview();
					}

					viewBidsHeader.Frame = new CGRect(5, 5, width - 10, 25);
					viewBidsHeader.BackgroundColor = UIColor.FromRGB(35, 32, 27);

					UILabel lblCarrier = new UILabel(new CGRect(0, 0, viewBidsHeader.Frame.Width / 4, 25));
					lblCarrier.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblCarrier.TextColor = UIColor.White;
					lblCarrier.TextAlignment = UITextAlignment.Center;
					lblCarrier.Text = NSBundle.MainBundle.LocalizedString("carrier",null);

					UILabel lblPrice = new UILabel(new CGRect(viewBidsHeader.Frame.Width / 4, 0, viewBidsHeader.Frame.Width / 4, 25));
					lblPrice.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblPrice.TextColor = UIColor.White;
					lblPrice.TextAlignment = UITextAlignment.Center;
					lblPrice.Text = NSBundle.MainBundle.LocalizedString("price",null);

					UILabel lblAlternate = new UILabel(new CGRect(viewBidsHeader.Frame.Width / 4 * 2, 0, viewBidsHeader.Frame.Width / 4, 25));
					lblAlternate.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblAlternate.TextColor = UIColor.White;
					lblAlternate.TextAlignment = UITextAlignment.Center;
					lblAlternate.Text = NSBundle.MainBundle.LocalizedString("alt",null);

					UILabel lblStatus = new UILabel(new CGRect(viewBidsHeader.Frame.Width / 4 * 3, 0, viewBidsHeader.Frame.Width / 4, 25));
					lblStatus.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblStatus.TextColor = UIColor.White;
					lblStatus.TextAlignment = UITextAlignment.Center;
					lblStatus.Text =  NSBundle.MainBundle.LocalizedString("status",null);

					UITableView tblBids = new UITableView(new CGRect(5, viewBidsHeader.Frame.Bottom, viewBidsHeader.Frame.Width, objActiveShipment.Bids.Count * 25));
					tblBids.RowHeight = 25;
					tblBids.Bounces = false;
					tblBids.AllowsSelection = false;
					tblBids.Source = new ActiveBidsAdapter(objActiveShipment.Bids);

					viewBidsHeader.AddSubviews(lblCarrier, lblPrice, lblAlternate, lblStatus);

					viewBidDetails.AddSubviews(viewBidsHeader, tblBids);
					//viewBidDetails.RemoveFromSuperview();
				}
				else
				{
					viewBidDetails.RemoveFromSuperview();
					viewBidDetails.Frame = new CGRect(0, viewActiveShipmentContainer.Frame.Bottom, width, 40);

					foreach (UIView view in viewBidDetails)
					{
						view.RemoveFromSuperview();
					}
					lblBidMsg.Text = NSBundle.MainBundle.LocalizedString("noBidYet",null);

					viewBidDetails.AddSubview(lblBidMsg);
				}
			}

			//viewActiveShipmentContainer.AddSubview(viewBidDetails);
			viewActiveShipment.AddSubviews(viewActiveShipmentContainer, viewBidDetails);

			if (!string.IsNullOrEmpty(objActiveShipment.LowestPriceLbl))
			{
				lblBolWithPrice.Text = objActiveShipment.BolNum;
				if (objActiveShipment.IsTest == true)
				{
					lblBolWithPrice.Text += Helper.Constants.strTestBol;
				}
			}
			else
			{
				lblBolWithPrice.Text = objActiveShipment.BolNum;
				if (objActiveShipment.IsTest == true)
				{
					lblBolWithPrice.Text += Helper.Constants.strTestBol;
				}
				lblBolWithPrice.Text = lblBolWithPrice.Text + " : " + objActiveShipment.LowestPriceLbl + " - " + "$" + objActiveShipment.LowestPrice;
			}

			addressKey = lblFromText.Text + "#" + objActiveShipment.ShipToCity + ", "
						+ objActiveShipment.ShipToState + ", " + objActiveShipment.ShipToZip + "#" + objActiveShipment.BolNum;

			lblTimer.Text = CountDown(objActiveShipment.DeadLineStr);

			tapGestureTo = new UITapGestureRecognizer(GoToMap);
			lblToText.AddGestureRecognizer(tapGestureTo);

					tapGestureFrom = new UITapGestureRecognizer(GoToMap);
			lblFromText.AddGestureRecognizer(tapGestureFrom);

			//List<Bid> lstBid = new List<Bid>();


		}

		void GoToShipmentDetails(string activeShipCompositeKey)
		{
			dashboardController.SegueFromDashboradToShipmentDetail(activeShipCompositeKey);
		}

		void GoToMap()
		{
			if (Reachability.InternetConnectionStatus())
			{
				dashboardController.RedirectToMap(addressKey);
			}
			else
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, dashboardController, "", 1);
				dashboardController.View.Add(this.customAlert);
			}
		}
		public void GoToDetails()
		{
			UIAlertView alert = new UIAlertView();
			alert.Title = NSBundle.MainBundle.LocalizedString("error",null);
			alert.AddButton(NSBundle.MainBundle.LocalizedString("okText",null));
			alert.AddButton(NSBundle.MainBundle.LocalizedString("cancel",null));
			alert.Message = NSBundle.MainBundle.LocalizedString("errorMessage", null);
			alert.Show();
		}

		/// <summary>
		/// Count Down Timer
		/// </summary>
		/// <param name="DeadLineStr"></param>
		/// <returns></returns>
		public string CountDown(string DeadLineStr)
		{
			try
			{
				string timerMessage = string.Empty;
				if (!string.IsNullOrEmpty(DeadLineStr))
				{
					//Remove slashes from date time string
					string[] bidDeadLine = DeadLineStr.Split('/');
					string[] year = bidDeadLine[2].Split(' '); //Remove space between year and time
					string[] time = year[1].Split(':');  //split hours and time
					DateTime bidDateTime = new DateTime(Convert.ToInt32(year[0]), Convert.ToInt32(bidDeadLine[0]), Convert.ToInt32(bidDeadLine[1]), Convert.ToInt32(time[0]), Convert.ToInt32(time[1]), Convert.ToInt32(time[2]));
					DateTime currentTime = DateTime.Now;
					decimal span = Convert.ToDecimal(bidDateTime.Subtract(currentTime).TotalMilliseconds);
					int diffDays = (int)Math.Floor(span / (1000 * 3600 * 24));
					int hours = (int)Math.Floor(span / 3600000); // 1 Hour = 36000 Milliseconds
					int minutes = (int)Math.Floor((span % 3600000) / 60000); // 1 Minutes = 60000 Milliseconds
					int seconds = (int)Math.Floor(((span % 360000) % 60000) / 1000);// 1 Second = 1000 Milliseconds

					RemainingTime objRemainingTime = new RemainingTime
					{
						Days = diffDays,
						Hours = hours,
						Minutes = minutes,
						Seconds = seconds
					};
					var clock = hours + ":" + minutes + ":" + seconds;

					if (bidDateTime > currentTime)
					{
						if (objRemainingTime.Days > 0)
						{
							timerMessage = objRemainingTime.Days + NSBundle.MainBundle.LocalizedString("days", null);
						}
						else if (objRemainingTime.Hours == 0 && objRemainingTime.Minutes == 0 && objRemainingTime.Seconds == 0)
						{
							timerMessage = NSBundle.MainBundle.LocalizedString("pastDeadline", null);
						}
						else
						{
							timerMessage = clock + NSBundle.MainBundle.LocalizedString("left", null);
						}
					}
					else
					{
						timerMessage = NSBundle.MainBundle.LocalizedString("pastDeadline", null);;
					}
				}
				return timerMessage;
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
				return null;
			}
		}


	}
}
