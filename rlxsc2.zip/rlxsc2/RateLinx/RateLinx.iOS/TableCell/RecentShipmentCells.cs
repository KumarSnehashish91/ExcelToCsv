using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;
using RateLinx.Models;
using RateLinx.Helper;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace RateLinx.iOS
{
	partial class RecentShipmentCells : UITableViewCell
	{
		//DashboardController dashboardController;
		//string compositeKey;
		//string addressKey;
		//string pickupAndConfirmationKey;
		//RecentShipments objRecentShipment;
		public RecentShipmentCells(IntPtr handle) : base(handle)
		{
		}

		//public void UpdateCell(DashboardController dashboardController, RecentShipments objRecentShipments)
		//{
		//	this.objRecentShipment = objRecentShipments;
		//	this.dashboardController = dashboardController;
			//Assign Values from API response btnCompareRoute btnPickup btnDelivery
		//	if (objRecentShipments.ViewAs == Constants.strCustomer)
		//	{
		//		//				btnCompareRoute.Visibility = ViewStates.Invisible;
		//		//				btnfindCurrentlc.Visibility = ViewStates.Visible;
		//		//				lnrlocationbuttons.Visibility = ViewStates.Visible;
		//		//				btnfindCurrentlc.Text = Constants.btnTextCurrentLc;
		//		//				btnCompareRoute.Text = Constants.btnTextCompare;
		//		btnLiveTracking.SetTitle(Constants.btnTextCurrentLc, UIControlState.Normal);
		//	}
		//	else
		//	{
		//		btnLiveTracking.SetTitle(objRecentShipments.SCAC, UIControlState.Normal);
		//		//				lnrlocationbuttons.Visibility = ViewStates.Visible;
		//		//				btnCompareRoute.Visibility = ViewStates.Invisible;
		//		//				btnfindCurrentlc.Visibility = ViewStates.Visible;
		//		//btnfindCurrentlc.Text = objRecentShipments.SCAC;
		//	}
		//	if (objRecentShipments.Status == Constants.strClosed)
		//	{
		//		//btnPickup.Visibility = ViewStates.Visible;
		//		//btnDelivery.Visibility = ViewStates.Visible;
		//	}
		//	else
		//	{
		//		//btnPickup.Visibility = ViewStates.Gone;
		//		//btnDelivery.Visibility = ViewStates.Gone;
		//	}
		//	//			btnDelivery.Click += delegate
		//	//			{
		//	//				GotoShipConfirmation(position, Constants.strDeliveryConf);
		//	//			};
		//	//			btnPickup.Click += delegate
		//	//			{
		//	//				GotoShipConfirmation(position, Constants.strPickConf);
		//	//			};
		//	//			btnfindCurrentlc.Click += delegate
		//	//			{
		//	//				if (objRecentShipments.SCAC.ToUpper() == Constants.strLiveTrack || btnfindCurrentlc.Text ==Constants.btnTextCurrentLc)
		//	//				{
		//	//					GoToTrackingMap(position, objRecentShipments);
		//	//				}
		//	//				else
		//	//				{
		//	//					Utility objUtility = new Utility();
		//	//					Dialog confirmDialog = objUtility.GetDialog(context, Constants.strDialogHdr, Constants.strStopTracking, Constants.btnTextYes, Constants.btnTextNo, string.Empty, ViewStates.Gone, ViewStates.Visible, ViewStates.Visible, ViewStates.Visible, ViewStates.Visible, ViewStates.Gone);
		//	//					Button btnConfirm = confirmDialog.FindViewById<Button>(Resource.Id.btnYes);
		//	//
		//	//					btnConfirm.Click += delegate
		//	//					{
		//	//						StopLiveTracking(objRecentShipments);
		//	//						confirmDialog.Hide();
		//	//					};
		//	//
		//	//				}
		//	//			};
		//	//			btnCompareRoute.Click += delegate
		//	//			{
		//	//				GoToComparisonRouteMap(position);
		//	//			};
		//	lblRecentBolNo.Text = objRecentShipments.BolNum;
		//	lblRecentFor.Text = objRecentShipments.ClientID;
		//	lblRecentFrom.Text = objRecentShipments.OriginCity + ", "
		//		+ objRecentShipments.OriginState + " "
		//		+ objRecentShipments.OriginZip;
		//	lblRecentTo.Text = objRecentShipments.OriginCompany + "\n"
		//		+ objRecentShipments.OriginAddress1 + "\n"
		//		+ objRecentShipments.OriginAddress2 + "\n"
		//		+ objRecentShipments.ShipToCity + ", "
		//		+ objRecentShipments.ShipToState + " " + objRecentShipments.ShipToZip;
		//	lblRecentPickup.Text = objRecentShipments.PickupStr;
		//	lblRecentDriverID.Text = objRecentShipments.DriverID;
		//	lblRecentDeliver.Text = objRecentShipments.DeliverOnStr;
		//	lblRecentEmail.Text = objRecentShipments.OriginEmail;
		//	lblRecentPhone.Text = objRecentShipments.OriginPhone;



		//	compositeKey = objRecentShipments.ClientID + "|" + objRecentShipments.BolNum + "|" + "";
		//	//sending values to other page
		//	addressKey = lblRecentFrom.Text + "#" + objRecentShipments.ShipToCity + ", "
		//		+ objRecentShipments.ShipToState + ", " + objRecentShipments.ShipToZip + "#" + objRecentShipments.BolNum;
		//}

		//partial void BtnRecentHeader_TouchUpInside(UIButton sender)
		//{
		//	dashboardController.SegueFromDashboradToShipmentDetail(compositeKey);
		//}

		//partial void BtnRecentFrom_TouchUpInside(UIButton sender)
		//{
		//	dashboardController.RedirectToMap(addressKey);
		//}

		//partial void BtnRecentTo_TouchUpInside(UIButton sender)
		//{
		//	dashboardController.RedirectToMap(addressKey);
		//}

		//partial void BtnLiveTracking_TouchUpInside(UIButton sender)
		//{
		//	if (btnLiveTracking.TitleLabel.Text.ToUpper() == Constants.strLiveTrack.ToUpper())
		//	{
		//		dashboardController.GoToLiveTracking(objRecentShipment);
		//	}
		//	else if (btnLiveTracking.TitleLabel.Text.ToUpper() == Constants.strStopTrack.ToUpper())
		//	{
		//		StopTrackingPopup objStopTracking = new StopTrackingPopup(dashboardController.View, dashboardController, objRecentShipment);
		//		dashboardController.View.Add(objStopTracking.GetPopupScreen());
		//		//dashboardController.GoToLiveTracking(objRecentShipment);
		//	}
		//	else
		//	{
		//		string trackingKey = objRecentShipment.ClientID + "|" + objRecentShipment.LocID + "|" + objRecentShipment.BolNum + "#" + "";
		//		dashboardController.RedirectToShipmentTracking(trackingKey);
		//	}
		//}

		//partial void BtnPickupConfirmation_TouchUpInside(UIButton sender)
		//{
		//	pickupAndConfirmationKey = Constants.strPickConf + "#" + objRecentShipment.ClientID + "|" + objRecentShipment.LocID + "|" + objRecentShipment.BolNum;
		//	dashboardController.RedirectToConfirmation(pickupAndConfirmationKey);
		//}

		//partial void BtnDeliveryConfirmation_TouchUpInside(UIButton sender)
		//{
		//	pickupAndConfirmationKey = Constants.strDeliveryConf + "#" + objRecentShipment.ClientID + "|" + objRecentShipment.LocID + "|" + objRecentShipment.BolNum;
		//	dashboardController.RedirectToConfirmation(pickupAndConfirmationKey);
		//}


	}
}
