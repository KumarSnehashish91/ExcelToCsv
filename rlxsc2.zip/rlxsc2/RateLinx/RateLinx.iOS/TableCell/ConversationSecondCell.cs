using Foundation;
using System;
using UIKit;
using RateLinx.Models;
using CoreGraphics;
using RateLinx.Helper;
using System.Linq;
using System.Collections.Generic;

namespace RateLinx.iOS
{
	public partial class ConversationSecondCell : UITableViewCell
	{
		UITapGestureRecognizer tapGestureImageLeft, tapGestureLorry, tapGestureFromTo, tapGestureTime, tapGestureMsg;
		ShipmentDetailController shipmentDetailController;
		Conversation objConversation;
		List<UIButton> lstAttachementButtons;

		public ConversationSecondCell(IntPtr handle) : base(handle)
		{
		}

		internal void UpdateCell(Conversation conversation, UITableView tableView, nint section, UIView viewReplySection, UITableViewCell conversationSecondCell, UIView mainView, ShipmentDetailController shipmentDetailController)
		{
			this.objConversation = conversation;
			this.shipmentDetailController = shipmentDetailController;
			contentView.Frame = new CGRect(0, 0, tableView.Frame.Width, conversationSecondCell.Frame.Height);

			nfloat imageWidth = 0;

			if (tableView.Frame.Width > 414)
			{
				imageWidth = 400;
			}
			else
			{
				imageWidth = 300;
			}

			nfloat height = 20;
			nfloat xCordinate = tableView.Frame.Width - imageWidth + 10;



			imgBuilding.Frame = new CGRect(xCordinate + 20, 5, 15, 15);

			foreach (UIView view in contentView)
			{
				view.RemoveFromSuperview();
			}


			//lblMessage.SizeToFit();
			lblMessage.Lines = 0;
			imgRight.Frame = new CGRect(xCordinate, 3, imageWidth, conversationSecondCell.Frame.Height - 6);
			if (conversation.Message.Count() > 0 && conversation.Message.Count() < 60)
			{
				height += 40;
				lblMessage.Frame = new CGRect(xCordinate + 20, imgBuilding.Frame.Bottom, imgRight.Frame.Width - 42, 40);

			}
			else if (conversation.Message.Count() > 60 && conversation.Message.Count() < 90)
			{
				height += 55;
				lblMessage.Frame = new CGRect(xCordinate + 20, imgBuilding.Frame.Bottom, imgRight.Frame.Width - 42, 55);
			}
			else if (conversation.Message.Count() > 90 && conversation.Message.Count() < 120)
			{
				height += 70;
				lblMessage.Frame = new CGRect(xCordinate + 20, imgBuilding.Frame.Bottom, imgRight.Frame.Width - 42, 70);
			}
			else
			{
				height += 85;
				lblMessage.Frame = new CGRect(xCordinate + 20, imgBuilding.Frame.Bottom, imgRight.Frame.Width - 42, 85);
			}

			if (conversation.Attachments != null && conversation.Attachments.Count > 0)
			{
				if (conversation.Attachments.Count == 1)
				{
					height += 25;
					viewFileContainer.Frame = new CGRect(xCordinate + 20, lblMessage.Frame.Bottom, imgRight.Frame.Width - 55, 25);
					//viewFileContainer.BackgroundColor = UIColor.Blue;
					viewFileContainer.Hidden = false;
				}
				else if (conversation.Attachments.Count == 2)
				{
					height += 50;
					viewFileContainer.Frame = new CGRect(xCordinate + 20, lblMessage.Frame.Bottom, imgRight.Frame.Width - 55, 50);
					viewFileContainer.Hidden = false;
				}
				else
				{
					height += 75;
					viewFileContainer.Frame = new CGRect(xCordinate + 20, lblMessage.Frame.Bottom, imgRight.Frame.Width - 55, 75);
					viewFileContainer.Hidden = false;
				}
			}
			else
			{
				viewFileContainer.Frame = new CGRect(xCordinate + 20, lblMessage.Frame.Bottom, imgRight.Frame.Width - 55, 0);
				viewFileContainer.Hidden = true;

			}

			height += 6;




			lblTime.Frame = new CGRect(xCordinate + 20, imgRight.Frame.Bottom -20, (imgRight.Frame.Width - 50) / 2, 20);

			lblFrom.Frame = new CGRect(lblTime.Frame.X + lblTime.Frame.Width + 20, imgRight.Frame.Bottom -25, (imgRight.Frame.Width - 50) / 2, 20);


			contentView.AddSubviews(imgRight, imgBuilding, lblMessage, viewFileContainer, lblTime, lblFrom);
			lblMessage.AdjustsFontSizeToFitWidth = true;
			lblMessage.Text = conversation.Message;

			lblTime.Text = conversation.TimeStamp;
			lblTime.SizeToFit();
			if (conversation.Attachments != null && conversation.Attachments.Count > 0)
			{
				lstAttachementButtons = new List<UIButton>();
				int btnCount = 0;

				foreach (UIView view in viewFileContainer)
				{
					view.RemoveFromSuperview();
				}

				foreach (UIView view in viewFileContainer)
				{
					view.RemoveFromSuperview();
				}
				nfloat yCordinate = 0;
				foreach (string strAttachment in conversation.Attachments)
				{
					int cutFileName = strAttachment.LastIndexOf('/');
					if (cutFileName != -1)
					{

						UIButton btnAttachment = new UIButton(new CGRect(0, yCordinate, viewFileContainer.Frame.Width, 15));
						btnAttachment.Font = UIFont.FromName(Helper.Constants.strFontName, 15f);
						btnAttachment.SetTitleColor(UIColor.Blue, UIControlState.Normal);
						btnAttachment.HorizontalAlignment = UIControlContentHorizontalAlignment.Left;
						btnAttachment.SetTitle(strAttachment.Substring(cutFileName + 1), UIControlState.Normal);
						btnAttachment.Tag = btnCount;
						viewFileContainer.AddSubview(btnAttachment);

						lstAttachementButtons.Add(btnAttachment);
						btnAttachment.TouchUpInside +=delegate {
							OpenFileInWebView(btnAttachment);
						};


						yCordinate += 25;
						btnCount++;
						//lblFileName.Text = "  " + conversation.Attachments[0].Substring(cutFileName + 1);

					}

				}



			}
			else
			{
				//constraint[0].Constant = 0;
				//lblFileName.Text = string.Empty;
			}


			//UIButton btnShowReply = new UIButton();
			//btnShowReply.Frame = imgRight.Bounds;
			//btnShowReply.BackgroundColor = UIColor.Clear;

			//contentView.AddSubview(btnShowReply);




			tapGestureImageLeft = new UITapGestureRecognizer(new Action( delegate {

				ViewChildConversationTapped(tableView, section, viewReplySection, mainView);
			}));
			imgRight.AddGestureRecognizer(tapGestureImageLeft);

			tapGestureLorry = new UITapGestureRecognizer(new Action( delegate {

				ViewChildConversationTapped(tableView, section, viewReplySection,  mainView);
			}));
			imgBuilding.AddGestureRecognizer(tapGestureLorry);

			tapGestureMsg = new UITapGestureRecognizer(new Action( delegate {

				ViewChildConversationTapped(tableView, section, viewReplySection, mainView);
			}));
			lblMessage.AddGestureRecognizer(tapGestureMsg);

			tapGestureFromTo = new UITapGestureRecognizer(new Action( delegate {

				ViewChildConversationTapped(tableView, section, viewReplySection, mainView);
			}));
			lblFrom.AddGestureRecognizer(tapGestureFromTo);

			tapGestureTime = new UITapGestureRecognizer(new Action( delegate {

				ViewChildConversationTapped(tableView, section, viewReplySection, mainView);
			}));
			lblTime.AddGestureRecognizer(tapGestureTime);



			//btnShowReply.TouchUpInside += delegate
			//{
			//	mainView.EndEditing(true);
			//	ViewChildConversationTapped(tableView, section, viewReplySection);
			//};
		}

		void OpenFileInWebView(UIButton btnAttachment)
		{
			if (lstAttachementButtons != null && lstAttachementButtons.Count > 0)
			{
				foreach (UIButton btnAttachfile in lstAttachementButtons)
				{
					if (btnAttachment.Tag == btnAttachfile.Tag)
					{
						btnAttachment.SetTitleColor(UIColor.Red, UIControlState.Highlighted);
					}
					else
					{
						btnAttachment.SetTitleColor(UIColor.Blue, UIControlState.Highlighted);
					}
				}
			}

			string fileUrl = objConversation.Attachments[Convert.ToInt32(btnAttachment.Tag)];
			shipmentDetailController.OpenConversationFile(fileUrl);
		}

		void ViewChildConversationTapped(UITableView tableView, nint section, UIView viewReplySection, UIView mainView)
		{
			mainView.EndEditing(true);
			ResignFirstResponder();
			//CommanUtil.isChatFooterHide = true;
			viewReplySection.Hidden = true;
			CommanUtil.sectionNo = section;
			tableView.ReloadData();
		}
	}
}