using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;
using RateLinx.Models;
using Helper = RateLinx.Helper;
using System.Collections.Generic;
using ObjCRuntime;

namespace RateLinx.iOS
{
	partial class CustCellActiveShipments : UITableViewCell
	{
		DashboardController dashboardController;
		//UITapGestureRecognizer tapGesture;
		string compositeKey;
		public CustCellActiveShipments(IntPtr handle) : base(handle)
		{
		}

		public void UpdateCell(DashboardController dashboardController, ActiveShipments objActiveShipment, int rowNum)
		{
			this.dashboardController = dashboardController;
			//var array = NSBundle.MainBundle.LoadNib("ActiveShipmentBidHeader", this, null);
			//UIView view = Runtime.GetNSObject(array.ValueAt(0)) as UIView;

			//tblBidDetails.TableHeaderView = view;
			//lblBidPrice.Hidden = true;
			//UILabel label = new UILabel(new CoreGraphics.CGRect(10, 10, viewBidDetails.Frame.Width - 20, 30));
			//label.Text = "Dynamically created label";
			////label.BackgroundColor = UIColor.Red;
			//viewBidDetails.AddSubview(label);

			List<Bid> lstBid = new List<Bid>();
			//lstBid.AddRange(objActiveShipment.Bids);

			//lstBid.Add(new Bid { AltTerms = true, CanAward = true, CanConfirm = true, CanDeny = true, Carrier = "Demo", EntryType = "ET", ID = 111, IsNew = true, Price = 400, Status = "Status" });
			//lstBid.Add(new Bid { AltTerms = true, CanAward = true, CanConfirm = true, CanDeny = true, Carrier = "Demo", EntryType = "ET", ID = 111, IsNew = true, Price = 400, Status = "Status" });
			//lstBid.Add(new Bid { AltTerms = true, CanAward = true, CanConfirm = true, CanDeny = true, Carrier = "Demo", EntryType = "ET", ID = 111, IsNew = true, Price = 400, Status = "Status" });

			tblBidDetails.Hidden = true;

			//tblBidDetails.Bounds = new CoreGraphics.CGRect(viewNoBids.Bounds.X, viewNoBids.Bounds.Y + 50, 350, 200);
			//tblBidDetails.RowHeight = UITableView.AutomaticDimension;
			//tblBidDetails.EstimatedRowHeight = 10;
			//tblBidDetails.ReloadData();
			tblBidDetails.Source = new ActiveShipmentBidDetails(lstBid);
			//viewNoBid.Hidden = true;
			//viewBidHeading.Hidden = true;


			//if (objActiveShipment.Bids != null && objActiveShipment.Bids.Count > 0)
			//{

			//	//List<Bid> lstBid = new List<Bid>();
			//	//lstBid.AddRange(objActiveShipment.Bids);

			//	//lstBid.Add(new Bid { AltTerms = true, CanAward = true, CanConfirm = true, CanDeny = true, Carrier = "Demo", EntryType = "ET", ID = 111, IsNew = true, Price = 400, Status = "Status" });
			//	//lstBid.Add(new Bid { AltTerms = true, CanAward = true, CanConfirm = true, CanDeny = true, Carrier = "Demo", EntryType = "ET", ID = 111, IsNew = true, Price = 400, Status = "Status" });
			//	//lstBid.Add(new Bid { AltTerms = true, CanAward = true, CanConfirm = true, CanDeny = true, Carrier = "Demo", EntryType = "ET", ID = 111, IsNew = true, Price = 400, Status = "Status" });


			//	//tblBidDetails.Source = new ActiveShipmentBidDetails(lstBid);
			//	//viewNoBid.Hidden = true;
			//	//viewBidHeading.Hidden = true;
			//}
			//else
			//{
			//	viewNoBid.Hidden = false;
			//	lblBidMsg.Text = "There are no bids yet.";
			//	btnBidNow.Hidden = true;
			//	viewBidHeading.Hidden = true;
			//	tblBidDetails.Hidden = true;
			//	if (objActiveShipment.CarriersBid != -1)
			//	{


			//		//lblBidMsg.Text = "Your current bid is :  $300";
			//		//lblBidPrice.Text = Convert.ToString(objActiveShipment.Bids[0].Price);
			//		btnBidNow.Hidden = true;
			//		lblBidPrice.Hidden = false;
			//		lblBidMsg.TextColor = UIColor.Black;
			//	}
			//	else
			//	{
			//		if (objActiveShipment.ViewAs.ToUpper() == "CARRIER")
			//		{ 
			//			//lblBidMsg.Text = "You have no current bids!";
			//		}
			//		else 
			//		{ 
			//			//lblBidMsg.Text = "There are no bids yet.";
			//			//btnBidNow.Hidden = true;
			//		}

			//	}

			//	//viewNoBid.Hidden = true;
			//	//viewBidHeading.Hidden = true;
			//	//tblBidDetails.Hidden = true;
			//}

			//viewNoBid.Hidden = true;
			//viewBidHeading.Hidden = true;
			//activeShipment = objActiveShipment;

			if (objActiveShipment.LowestPriceLbl == "N/A")
			{
				lblActiveLeftHead.Text = objActiveShipment.BolNum;
				if (objActiveShipment.IsTest == true)
				{
					lblActiveLeftHead.Text += Helper.Constants.strTestBol;
				}
			}
			else
			{
				lblActiveLeftHead.Text = objActiveShipment.BolNum;
				if (objActiveShipment.IsTest == true)
				{
					lblActiveLeftHead.Text += Helper.Constants.strTestBol;
				}
				lblActiveLeftHead.Text = lblActiveLeftHead.Text + " : " + objActiveShipment.LowestPriceLbl + " - " + "$" + objActiveShipment.LowestPrice;
			}
			if (objActiveShipment.ViewAs == Helper.Constants.strCarrier)
			{
				//Count Down timer
				//lblActiveRightHead.Text = CountDown (objActiveShipment.DeadLineStr);
			}
			lblActiveFor.Text = objActiveShipment.ClientID;
			lblActiveDeadline.Text = objActiveShipment.DeadLineStr;

			lblActiveFrom.Text = objActiveShipment.OriginCity + ", "
			+ objActiveShipment.OriginState + " "
			+ objActiveShipment.OriginZip;
			lblActiveTo.Text = objActiveShipment.ShipToCity + ", "
			+ objActiveShipment.ShipToState + " " + objActiveShipment.ShipToZip;
			lblActivePickup.Text = objActiveShipment.PickupStr;
			lblActiveMode.Text = objActiveShipment.Mode;
			//Composite key for getting the shipment details
			compositeKey = objActiveShipment.ClientID + "|" + objActiveShipment.BolNum;


			//lblDynamic.Hidden = true;
			//lblDynamic.Frame = new CoreGraphics.CGRect(0, 0, 0, 0);

			//lblActiveShipment.LineBreakMode = UILineBreakMode.WordWrap;
			//lblActiveShipment.Lines = 0;
			if (rowNum == 1)
			{
				//lblName.Text = "Ravi";
				//lblPlace.Text = "Delhi";
				//lblContent.Text = "n a situation like our two stacked labels, Auto Layout needs a way to figure out which of the two labels to expand. It does so by inspecting each label's priority behaviors. In the case of content hugging, the label with the lowest priority will lose and in turn, will grow with its container. The label with the higher priority does the inverse";

				//lblActiveShipment.
				//lblActiveShipment.Text = "n a situation like our two stacked labels, Auto Layout needs a way to figure out which of the two labels to expand. It does so by inspecting each label's priority behaviors. In the case of content hugging, the label with the lowest priority will lose and in turn, will grow with its container. The label with the higher priority does the inverse";

			}
			else
			{
				//lblName.Text = "Mark";
				//lblPlace.Text = "US";
				//lblContent.Text = " stacked labels, Auto Layout needs a way to figure out which of the two labels to expand. It does so by inspecting each label's priority behaviors. In the case of content hugging, the label with the lowest priority will lose and in turn, will grow with its container. The label with the higher priority does the inverse stacked labels, Auto Layout needs a way to figure out which of the two labels to expand. It does so by inspecting each label's priority behaviors. In the case of content hugging, the label with the lowest priority will lose and in turn, will grow with its container. The label with the higher priority does the inverse";

				//lblActiveShipment.Text = "In a situation like our two stacked labels, Auto Layout needs a way to figure out which of the two labels to expand. It does so by inspecting each label's priority behaviors. In the case of content hugging, the label with the lowest priority will lose and in turn, will grow with its container. The label with the higher priority does the inverse; it wins the battle of priorities and keeps its size to match its intrinsic content size. If both happen to be equal to each other, then the system can choose any view to expand that it feels like. Undefined behavior like this is never good as it can vary from OS to OS.";

			}
		}

		public void GoToDetails()
		{
			UIAlertView alert = new UIAlertView();
			alert.Title = "Error";
			alert.AddButton("OK");
			alert.AddButton("Cancel");
			alert.Message = "This should be an error message";
			//alert.AlertViewStyle = UIAlertViewStyle.SecureTextInput;
			alert.Show();
		}

		/// <summary>
		/// Count Down Timer
		/// </summary>
		/// <param name="DeadLineStr"></param>
		/// <returns></returns>
		public string CountDown(string DeadLineStr)
		{
			try
			{
				string timerMessage = string.Empty;
				if (!string.IsNullOrEmpty(DeadLineStr))
				{
					//Remove slashes from date time string
					string[] bidDeadLine = DeadLineStr.Split('/');
					string[] year = bidDeadLine[2].Split(' '); //Remove space between year and time
					string[] time = year[1].Split(':');  //split hours and time
					DateTime bidDateTime = new DateTime(Convert.ToInt32(year[0]), Convert.ToInt32(bidDeadLine[0]), Convert.ToInt32(bidDeadLine[1]), Convert.ToInt32(time[0]), Convert.ToInt32(time[1]), Convert.ToInt32(time[2]));
					DateTime currentTime = DateTime.Now;
					decimal span = Convert.ToDecimal(bidDateTime.Subtract(currentTime).TotalMilliseconds);
					int diffDays = (int)Math.Floor(span / (1000 * 3600 * 24));
					int hours = (int)Math.Floor(span / 3600000); // 1 Hour = 36000 Milliseconds
					int minutes = (int)Math.Floor((span % 3600000) / 60000); // 1 Minutes = 60000 Milliseconds
					int seconds = (int)Math.Floor(((span % 360000) % 60000) / 1000);// 1 Second = 1000 Milliseconds

					RemainingTime objRemainingTime = new RemainingTime
					{
						Days = diffDays,
						Hours = hours,
						Minutes = minutes,
						Seconds = seconds
					};
					var clock = hours + ":" + minutes + ":" + seconds;

					if (bidDateTime > currentTime)
					{
						if (objRemainingTime.Days > 0)
						{
							timerMessage = objRemainingTime.Days + " days left";
						}
						else if (objRemainingTime.Hours == 0 && objRemainingTime.Minutes == 0 && objRemainingTime.Seconds == 0)
						{
							timerMessage = "Past deadline";
						}
						else
						{
							timerMessage = clock + "  left";
						}
					}
					else
					{
						timerMessage = "Past deadline";
					}
				}
				return timerMessage;
			}
			catch
			{
				throw;
			}
		}

		//partial void BtnActiveHeaderClick_TouchUpInside(UIButton sender)
		//{
		//	dashboardController.SegueFromDashboradToShipmentDetail(compositeKey);
		//}

		partial void BtnActiveHeader_TouchUpInside(UIButton sender)
		{
			dashboardController.SegueFromDashboradToShipmentDetail(compositeKey);
		}
	}
}
