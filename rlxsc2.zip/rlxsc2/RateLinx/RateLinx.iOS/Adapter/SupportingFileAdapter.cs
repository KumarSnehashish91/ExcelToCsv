﻿using System;
using System.Collections.Generic;
using Foundation;
using RateLinx.Helper;
using UIKit;

namespace RateLinx.iOS
{
	public class SupportingFileAdapter : UITableViewSource
	{
		#region Variable Declaration

		List<string> lstSupportingFile = null;  // Declare Supporting File list
		ShipmentDetailController objShipmentDetailController;

		#endregion

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.SupportingFileAdapter"/> class.
		/// </summary>
		/// <param name="shipmentDetailController">Shipment detail controller.</param>
		/// <param name="lstSupportingFiles">Lst supporting files.</param>
		public SupportingFileAdapter(ShipmentDetailController shipmentDetailController, List<string> lstSupportingFiles)
		{
           	this.objShipmentDetailController = shipmentDetailController;
			lstSupportingFile = lstSupportingFiles;
		}
		/// <summary>
		/// Rowses the in section.
		/// </summary>
		/// <returns>The in section.</returns>
		/// <param name="tableview">Tableview.</param>
		/// <param name="section">Section.</param>
		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return lstSupportingFile.Count;
		}
		/// <summary>
		/// Gets the height for row.
		/// </summary>
		/// <returns>The height for row.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override nfloat GetHeightForRow(UITableView tableView, NSIndexPath indexPath)
		{
			return 30;
		}
		/// <summary>
		/// Gets the cell.
		/// </summary>
		/// <returns>The cell.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			try
			{
				SupportingFileCell cell = (SupportingFileCell)tableView.DequeueReusableCell("SupportingFileIdentity") as SupportingFileCell;
				if (cell != null)
				{
					string objFileDetails = lstSupportingFile[indexPath.Row];
					cell.UpdateCell(objFileDetails, indexPath.Row,objShipmentDetailController, tableView);
					cell.TextLabel.Font = UIFont.FromName(Constants.strFontName, 11.0f);
					return cell;
				}
				else
				{
					return null;
				}
			}
			catch
			{
				throw;
			}
		}
	}
}

