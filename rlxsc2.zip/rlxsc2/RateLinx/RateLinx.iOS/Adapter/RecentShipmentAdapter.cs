﻿using System;
using UIKit;
using Foundation;
using System.Linq;
using System.Collections.Generic;
using RateLinx.Models;
using CoreGraphics;
using RateLinx.Helper;
using System.Threading.Tasks;
using RateLinx.APIs;
using Newtonsoft.Json;
using ToastIOS;

namespace RateLinx.iOS
{


	public class RecentShipmentAdapter : UITableViewSource
	{

		#region Variable Declaration
		//RecentShipments objRecentShipments;
		DashboardController dashboardController;
		string cellIdentifier = "RecentShipmentIdentifier";
		public List<RecentShipments> lstRecentShipments = null;  // Declare Recent shipment list
		//string compositeKey;
		string addressKey;
		string pickupAndConfirmationKey;
		//DriversList objDriversList = null;
		CustomPopup customAlert = null;
		ServiceHelper objServiceHelper = null;
		UITapGestureRecognizer tapGestureTo, tapGestureFrom;
		UIPickerView pickerView = null;
		PickerDataModel pickerDataModel = null;
		UIButton doneButton = null;
		UIView viewPicker = null;
		LoadingOverlay loadPop;
		#endregion

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.RecentShipmentAdapter"/> class.
		/// </summary>
		/// <param name="dashboardController">Dashboard controller.</param>
		/// <param name="recentShipment">Recent shipment.</param>
		public RecentShipmentAdapter(DashboardController dashboardController, List<RecentShipments> recentShipment)
		{
			lstRecentShipments = recentShipment;
			this.dashboardController = dashboardController;
			objServiceHelper = new ServiceHelper();
		}
		/// <summary>
		/// Rowses the in section.
		/// </summary>
		/// <returns>The in section.</returns>
		/// <param name="tableview">Tableview.</param>
		/// <param name="section">Section.</param>
		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return lstRecentShipments.Count;
		}
		/// <summary>
		/// Gets the height for row.
		/// </summary>
		/// <returns>The height for row.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override nfloat GetHeightForRow(UITableView tableView, NSIndexPath indexPath)
		{
			nfloat heignt = 480;
			//Add conditions
			if (lstRecentShipments[indexPath.Row].ViewAs.ToUpper() == Constants.strCarrier.ToUpper())
			{
				if (lstRecentShipments[indexPath.Row].DispatchFlag)
				{
					if (CommanUtil.UserPermissions != null && CommanUtil.UserPermissions.Count > 0)
					{
						if (CommanUtil.UserPermissions.Contains(Constants.dispatcher) &&
									CommanUtil.UserPermissions.Contains(Constants.dispatcherDriver))
						{
							if (!string.IsNullOrEmpty(lstRecentShipments[indexPath.Row].DriverID)
								&& lstRecentShipments[indexPath.Row].DriverID.Equals(CommanUtil.userID))
							{
								
							}
							else
							{
								if (!string.IsNullOrEmpty(lstRecentShipments[indexPath.Row].DriverID)
									&& !lstRecentShipments[indexPath.Row].DriverID.Equals(CommanUtil.userID))
								{
									
								}
								else
								{
                                    heignt = 410;
								}
							}
						}
						else if (CommanUtil.UserPermissions.Contains(Constants.dispatcherDriver))
						{
							if (!string.IsNullOrEmpty(lstRecentShipments[indexPath.Row].DriverID)
							   && lstRecentShipments[indexPath.Row].DriverID.Equals(CommanUtil.userID))
							{

							}
							else
							{
                                heignt = 410;
							}
						}
                        else
                        {
                            heignt = 410;
                        }
					}
				}
				else
				{
					if (!string.IsNullOrEmpty(lstRecentShipments[indexPath.Row].DriverID)
						&& !lstRecentShipments[indexPath.Row].DriverID.Equals(CommanUtil.userID))
					{
                        heignt = 410;
					}
				}
			}
            else
            {
                heignt = 450;
            }

			return heignt;
		}
		/// <summary>
		/// Gets the cell.
		/// </summary>
		/// <returns>The cell.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			try
			{
				RecentShipmentCells cell = (RecentShipmentCells)tableView.DequeueReusableCell(cellIdentifier) as RecentShipmentCells;
				if (cell != null)
				{
					//objRecentShipments = lstRecentShipments[indexPath.Row];
					//cell.UpdateCell(dashboardController, objRecentShipments);
					//cell.TextLabel.Font = UIFont.FromName(Constants.strFontName, 11.0f);

					//compositeKey = objRecentShipments.ClientID + "|" + objRecentShipments.BolNum + "|" + "";
					//cell.UpdateCell(objRecentShipments, dashboardController, tableView);
					UIColor evenColor, oddColor;
					evenColor = Constants.awardShipEvenColor;
					oddColor = Constants.awardShipOddColor;

					nfloat width = tableView.Frame.Width;

					nfloat yCordinate = 0;


					UIView viewRecentShipmentHeader = new UIView(new CGRect(0, 0, tableView.Frame.Width, 45));
					viewRecentShipmentHeader.BackgroundColor = Constants.shipmentHeadColor;

					UIButton btnRecentHeader = new UIButton();
					btnRecentHeader.Frame = viewRecentShipmentHeader.Bounds;
					btnRecentHeader.BackgroundColor = UIColor.Clear;

					btnRecentHeader.TouchUpInside += delegate
					{
                        GoToShipmentDetails(lstRecentShipments[indexPath.Row].ClientID + "|" + lstRecentShipments[indexPath.Row].BolNum + "|" + "");
					};
					viewRecentShipmentHeader.AddSubview(btnRecentHeader);

					UIImageView imgHammerIcon = new UIImageView(new CGRect(5, 12, 20, 20));

					imgHammerIcon.Image = new UIImage("Images/hammer-icon.png");

					UIButton btnTrackLocation = new UIButton(new CGRect(viewRecentShipmentHeader.Frame.Width - 30, 12, 25, 25));

					btnTrackLocation.SetImage(UIImage.FromFile("Images/locationicon.png"), UIControlState.Normal);

					btnTrackLocation.TouchUpInside += delegate
					{
                        UpdateShipmentStatus(lstRecentShipments[indexPath.Row]);
					};


					UILabel lblAwardedBolNo = new UILabel(new CGRect(35, 0, viewRecentShipmentHeader.Frame.Width - 100, 45));

					lblAwardedBolNo.TextColor = UIColor.White;
					lblAwardedBolNo.Font = UIFont.FromName(Constants.strFontName, 11f);

					lblAwardedBolNo.Text = lstRecentShipments[indexPath.Row].BolNum;


					//UIImageView imgArrowIcon = new UIImageView(new CGRect(viewRecentShipmentHeader.Frame.Width - 30, 12, 20, 20));

					//imgArrowIcon.Image = new UIImage("Images/arrow-icon.png");

					viewRecentShipmentHeader.AddSubviews(imgHammerIcon, lblAwardedBolNo, btnTrackLocation);

					yCordinate += viewRecentShipmentHeader.Frame.Height;


					List<UIView> lstViews = new List<UIView>();


					UIView viewFor = new UIView(new CGRect(0, yCordinate, width, 40));


					viewFor.BackgroundColor = evenColor;
					//viewFor.BackgroundColor = UIColor.LightGray;

					UILabel lblForLabel = new UILabel(new CGRect(20, 0, width / 3, 40));
					lblForLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblForLabel.Text = NSBundle.MainBundle.GetLocalizedString("for", null);


					UILabel lblForText = new UILabel(new CGRect(width / 3 + 20, 0, width - (width / 3 + 20), 40));
					lblForText.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblForText.Text = lstRecentShipments[indexPath.Row].ClientID;
					viewFor.AddSubviews(lblForLabel, lblForText);

					yCordinate += 40;


					lstViews.Add(viewFor);

					UIView viewFrom = new UIView(new CGRect(0, yCordinate, width, 40));
					viewFrom.BackgroundColor = oddColor;
					//viewFrom.BackgroundColor = UIColor.LightGray;

					UILabel lblFromLabel = new UILabel(new CGRect(20, 0, width / 3, 40));
					lblFromLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblFromLabel.Text = NSBundle.MainBundle.GetLocalizedString("from", null);


					UILabel lblFromText = new UILabel(new CGRect(width / 3 + 20, 0, width - (width / 3 + 20), 40));
					lblFromText.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblFromText.Text = lstRecentShipments[indexPath.Row].OriginCity + ", " + lstRecentShipments[indexPath.Row].OriginState + " " + lstRecentShipments[indexPath.Row].OriginZip;
					lblFromText.Lines = 0;
					lblFromText.UserInteractionEnabled = true;
					lblFromText.TextColor = UIColor.Blue;
					viewFrom.AddSubviews(lblFromLabel, lblFromText);
					lstViews.Add(viewFrom);
					yCordinate += 40;


					UIView viewTo = new UIView(new CGRect(0, yCordinate, width, 40));
					viewTo.BackgroundColor = evenColor;
					//viewTo.BackgroundColor = UIColor.Green;

					UILabel lblToLabel = new UILabel(new CGRect(20, 0, width / 3, 40));
					lblToLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblToLabel.Text = NSBundle.MainBundle.GetLocalizedString("to", null);

					UILabel lblToText = new UILabel(new CGRect(width / 3 + 20, 0, width - (width / 3 + 20), 40));
					lblToText.Font = UIFont.FromName(Constants.strFontName, 13f);
					//lblToText.Text = objRecentShipments.ShipToCity + ", " + objRecentShipments.ShipToState + " " + objRecentShipments.ShipToZip;
                    //lstRecentShipments[indexPath.Row].OriginCompany + "\n"
                        //+ lstRecentShipments[indexPath.Row].OriginAddress1 + "\n"
                        //+ lstRecentShipments[indexPath.Row].OriginAddress2 + "\n"
					lblToText.Text = lstRecentShipments[indexPath.Row].ShipToCity + ", "
						+ lstRecentShipments[indexPath.Row].ShipToState + " " + lstRecentShipments[indexPath.Row].ShipToZip;

					lblToText.Lines = 0;
					lblToText.UserInteractionEnabled = true;
					lblToText.TextColor = UIColor.Blue;
					viewTo.AddSubviews(lblToLabel, lblToText);
					lstViews.Add(viewTo);
					yCordinate += 40;


					UIView viewPickup = new UIView(new CGRect(0, yCordinate, width, 40));
					viewPickup.BackgroundColor = oddColor;
					//viewPickup.BackgroundColor = UIColor.LightGray;

					UILabel lblPickupLabel = new UILabel(new CGRect(20, 0, width / 3, 40));
					lblPickupLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblPickupLabel.Text = NSBundle.MainBundle.GetLocalizedString("pickup", null);


					UILabel lblPickupText = new UILabel(new CGRect(width / 3 + 20, 0, width - (width / 3 + 20), 40));
					lblPickupText.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblPickupText.Text = lstRecentShipments[indexPath.Row].PickupStr;
					lblPickupText.Lines = 0;
					viewPickup.AddSubviews(lblPickupLabel, lblPickupText);
					lstViews.Add(viewPickup);
					yCordinate += 40;


					UIView viewDriverId = new UIView(new CGRect(0, yCordinate, width, 40));
					viewDriverId.BackgroundColor = evenColor;
					//viewDriverId.BackgroundColor = UIColor.Green;

					UILabel lblDriverLabel = new UILabel(new CGRect(20, 0, width / 3, 40));
					lblDriverLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblDriverLabel.Text = NSBundle.MainBundle.GetLocalizedString("driverId", null);

					UILabel lblDriverText = new UILabel(new CGRect(width / 3 + 20, 0, width - (width / 3 + 20), 40));
					lblDriverText.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblDriverText.Text = lstRecentShipments[indexPath.Row].DriverID;

					viewDriverId.AddSubviews(lblDriverLabel, lblDriverText);
					lstViews.Add(viewDriverId);
					yCordinate += 40;


					UIView viewDelivery = new UIView(new CGRect(0, yCordinate, width, 40));
					viewDelivery.BackgroundColor = oddColor;
					//viewDelivery.BackgroundColor = UIColor.LightGray;

					UILabel lblDeliverLabel = new UILabel(new CGRect(20, 0, width / 3, 40));
					lblDeliverLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
                    lblDeliverLabel.Text = NSBundle.MainBundle.GetLocalizedString("deliver", null);


					UILabel lblDeliverText = new UILabel(new CGRect(width / 3 + 20, 0, width - (width / 3 + 20), 40));
					lblDeliverText.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblDeliverText.Text = lstRecentShipments[indexPath.Row].DeliverOnStr;
					lblDeliverText.Lines = 0;
					viewDelivery.AddSubviews(lblDeliverLabel, lblDeliverText);
					lstViews.Add(viewPickup);
					yCordinate += 40;


					UIView viewEmail = new UIView(new CGRect(0, yCordinate, width, 40));
					viewEmail.BackgroundColor = evenColor;
					//viewEmail.BackgroundColor = UIColor.LightGray;

					UILabel lblEmailLabel = new UILabel(new CGRect(20, 0, width / 3, 40));
					lblEmailLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
                    lblEmailLabel.Text = NSBundle.MainBundle.GetLocalizedString("email", null);


					UILabel lblEmailText = new UILabel(new CGRect(width / 3 + 20, 0, width - (width / 3 + 20), 40));
					lblEmailText.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblEmailText.Text = lstRecentShipments[indexPath.Row].OriginEmail;
					lblEmailText.Lines = 0;
					viewEmail.AddSubviews(lblEmailLabel, lblEmailText);
					lstViews.Add(viewPickup);
					yCordinate += 40;

					UIView viewPhoneId = new UIView(new CGRect(0, yCordinate, width, 40));
					viewPhoneId.BackgroundColor = oddColor;
					//viewPhoneId.BackgroundColor = UIColor.Green;

					UILabel lblPhoneLabel = new UILabel(new CGRect(20, 0, width / 3, 40));
					lblPhoneLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
                    lblPhoneLabel.Text = NSBundle.MainBundle.GetLocalizedString("phone", null);

					UILabel lblPhoneText = new UILabel(new CGRect(width / 3 + 20, 0, width - (width / 3 + 20), 40));
					lblPhoneText.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblPhoneText.Text = lstRecentShipments[indexPath.Row].OriginPhone;

					viewPhoneId.AddSubviews(lblPhoneLabel, lblPhoneText);
					lstViews.Add(viewPhoneId);
					yCordinate += 40;
					UIView viewLocation = new UIView(new CGRect(0, yCordinate, width, 40));
					viewLocation.BackgroundColor = evenColor;
					UIButton btnLiveTracking = new UIButton(new CGRect(10, 5, width / 2 - 20, 30));
					btnLiveTracking.Layer.CornerRadius = 5;
					btnLiveTracking.BackgroundColor = Constants.btnColorRed;
					btnLiveTracking.SetTitleColor(UIColor.White, UIControlState.Normal);
					btnLiveTracking.UserInteractionEnabled = true;
					btnLiveTracking.Font = UIFont.FromName(Constants.strFontName, 13f);
					btnLiveTracking.Tag = 1;
					UIButton btnCompareRoute = new UIButton(new CGRect(width / 2 + 10, 5, width / 2 - 20, 30));
					btnCompareRoute.Layer.CornerRadius = 5;
					btnCompareRoute.BackgroundColor = UIColor.FromRGB(137, 18, 40);
					btnCompareRoute.SetTitleColor(UIColor.White, UIControlState.Normal);
					btnCompareRoute.UserInteractionEnabled = true;
					btnCompareRoute.Font = UIFont.FromName(Constants.strFontName, ConstantsClass.fontSize);
					btnCompareRoute.TouchUpInside += delegate
					{
                      		GoToComparisonRouteMap(lstRecentShipments[indexPath.Row]);
					};
					btnCompareRoute.SetTitle(Constants.btnTextCompare, UIControlState.Normal);
					viewLocation.AddSubviews(btnLiveTracking, btnCompareRoute);


                    yCordinate += 40;
                    UIView viewPickupDelivery = new UIView(new CGRect(0, yCordinate, width, 40));
                    viewPickupDelivery.BackgroundColor = oddColor;
                    UIButton btnPickupConfirmation = new UIButton(new CGRect(10, 5, width / 2 - 20, 30));
                    btnPickupConfirmation.Layer.CornerRadius = 5;
                    btnPickupConfirmation.BackgroundColor = Constants.btnColorRed;
                    btnPickupConfirmation.SetTitleColor(UIColor.White, UIControlState.Normal);
                    btnPickupConfirmation.UserInteractionEnabled = true;
                    btnPickupConfirmation.SetTitle(Constants.strPickup, UIControlState.Normal);
                    btnPickupConfirmation.Font = UIFont.FromName(Constants.strFontName, 13f);
                    btnPickupConfirmation.TouchUpInside += delegate
                    {
                        PickupConfirmation(lstRecentShipments[indexPath.Row]);
                    };
                    UIButton btnDeliveryConfirmation = new UIButton(new CGRect(width / 2 + 10, 5, width / 2 - 20, 30));
                    btnDeliveryConfirmation.Layer.CornerRadius = 5;
                    btnDeliveryConfirmation.BackgroundColor = Constants.btnColorRed;
                    btnDeliveryConfirmation.SetTitleColor(UIColor.White, UIControlState.Normal);
                    btnDeliveryConfirmation.UserInteractionEnabled = true;
                    btnDeliveryConfirmation.SetTitle(Constants.strDeliveryConf, UIControlState.Normal);
                    btnDeliveryConfirmation.Font = UIFont.FromName(Constants.strFontName, 13f);
                    btnDeliveryConfirmation.TouchUpInside += delegate
                    {
                        DeliveryConfirmation(lstRecentShipments[indexPath.Row]);
                    };
                    viewPickupDelivery.AddSubviews(btnPickupConfirmation, btnDeliveryConfirmation);

                    addressKey = lblFromText.Text + "#" + lstRecentShipments[indexPath.Row].ShipToCity + ", "
                        + lstRecentShipments[indexPath.Row].ShipToState + ", " + lstRecentShipments[indexPath.Row].ShipToZip + "#" + lstRecentShipments[indexPath.Row].BolNum;

                    tapGestureTo = new UITapGestureRecognizer(GoToMap);
                    lblToText.AddGestureRecognizer(tapGestureTo);

                    tapGestureFrom = new UITapGestureRecognizer(GoToMap);
                    lblFromText.AddGestureRecognizer(tapGestureFrom);
                    cell.AddSubviews(viewRecentShipmentHeader, viewDriverId, viewFrom, viewTo,
                            viewPickup, viewFor, viewDelivery, viewEmail, viewPhoneId,
                             viewLocation, viewPickupDelivery);
                    
					//Add conditions
					if (lstRecentShipments[indexPath.Row].ViewAs.ToUpper() == Constants.strCustomer.ToUpper())
					{
						btnCompareRoute.Hidden = false;
						btnLiveTracking.Hidden = false;
						btnLiveTracking.SetTitle(Constants.trackShipment, UIControlState.Normal);
					}
					else
					{
						btnCompareRoute.Hidden = true;
						btnLiveTracking.Hidden = false;
						btnTrackLocation.Hidden = false;
						btnLiveTracking.SetTitle(Constants.updateShipmentStatus, UIControlState.Normal);
						if (lstRecentShipments[indexPath.Row].DispatchFlag)
						{
							if (CommanUtil.UserPermissions != null && CommanUtil.UserPermissions.Count > 0)
							{
								if (CommanUtil.UserPermissions.Contains(Constants.dispatcher) &&
									CommanUtil.UserPermissions.Contains(Constants.dispatcherDriver))
								{
									if (!string.IsNullOrEmpty(lstRecentShipments[indexPath.Row].DriverID)
										&& lstRecentShipments[indexPath.Row].DriverID.Equals(CommanUtil.userID))
									{
										btnLiveTracking.SetTitle(Constants.updateShipmentStatus, UIControlState.Normal);
									}
									else
									{
										if (!string.IsNullOrEmpty(lstRecentShipments[indexPath.Row].DriverID)
											&& !lstRecentShipments[indexPath.Row].DriverID.Equals(CommanUtil.userID))
										{
											btnLiveTracking.SetTitle(Constants.trackShipment, UIControlState.Normal); //Track
										}
										else
										{
                                            //btnPickupConfirmation.Hidden = true;
											btnTrackLocation.Hidden = true;
											btnLiveTracking.SetTitle(Constants.assignDriver, UIControlState.Normal);//Check from the driver's API. If Driver's API gives 0 result then button text will be "Update Shipment Status".
										}
									}
								}
								else if (CommanUtil.UserPermissions.Contains(Constants.dispatcherDriver))
								{
									if (!string.IsNullOrEmpty(lstRecentShipments[indexPath.Row].DriverID)
									   && lstRecentShipments[indexPath.Row].DriverID.Equals(CommanUtil.userID))
									{
										btnTrackLocation.Hidden = false;
										btnLiveTracking.SetTitle(Constants.updateShipmentStatus, UIControlState.Normal);//Check from the driver's API. If Driver's API gives 0 result then button text will be "Update Shipment Status".
									}
									else
									{
                                       
										btnTrackLocation.Hidden = true;
										btnLiveTracking.Hidden = true;
									}
								}
							}
						}
						else
						{
							if (!string.IsNullOrEmpty(lstRecentShipments[indexPath.Row].DriverID)
									   && !lstRecentShipments[indexPath.Row].DriverID.Equals(CommanUtil.userID))
							{
								btnTrackLocation.Hidden = true;
								btnLiveTracking.Hidden = true;
							}
						}
					}
					btnLiveTracking.TouchUpInside += delegate
					{
                        UpdateShipmentStatus(lstRecentShipments[indexPath.Row]);
					};
					
					return cell;
				}
				else
				{
					return null;
				}
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
				return null;
			}
		}

		/// <summary>
		/// Tracks the update shipment location.
		/// </summary>
		/// <param name="objRecentShipments">Object recent shipments.</param>
		async void TrackUpdateShipmentLocation(RecentShipments objRecentShipments, string btnfindCurrentlc)
		{
			try
			{
				CGRect bounds = UIScreen.MainScreen.Bounds;
				if(loadPop != null)
				loadPop =null;
				loadPop = new LoadingOverlay(bounds);
				List<ShipmentActivity> lstShipmentActivity = null;
				if (objRecentShipments.ViewAs.ToUpper() == Constants.strCarrier.ToUpper())
				{
					if (btnfindCurrentlc == Constants.updateShipmentStatus)
					{
						dashboardController.Add(loadPop);
						await Task.Delay(100);
						lstShipmentActivity = await Util.GetRealtimeShipmentStatus(objRecentShipments.ClientID + "/" + objRecentShipments.BolNum);
						loadPop.Hide();
						if (lstShipmentActivity != null && lstShipmentActivity.Count > 0)
						{
                            if (lstShipmentActivity[lstShipmentActivity.Count - 1].Status == Constants.completedkey)
							{
								Toast.MakeText(Constants.shipmentCompleted).SetDuration(5000).Show();
							}
							else
							{
								UpdateShipmentStatusController updateShipmentStatusController;
								updateShipmentStatusController = (UpdateShipmentStatusController)dashboardController.Storyboard.InstantiateViewController("UpdateShipmentStatusController");
								updateShipmentStatusController.objRecentShipments = objRecentShipments;
								updateShipmentStatusController.lstShipmentActivity = lstShipmentActivity;
								dashboardController.NavigationController.PushViewController(updateShipmentStatusController, true);
							}
						}
						else
						{
							UpdateShipmentStatusController updateShipmentStatusController;
							updateShipmentStatusController = (UpdateShipmentStatusController)dashboardController.Storyboard.InstantiateViewController("UpdateShipmentStatusController");
							updateShipmentStatusController.objRecentShipments = objRecentShipments;
							updateShipmentStatusController.lstShipmentActivity = lstShipmentActivity;
							dashboardController.NavigationController.PushViewController(updateShipmentStatusController, true);

						}
					}
					else
					{
						RealTimeTrackingController realTimeTrackingController;

						realTimeTrackingController = (RealTimeTrackingController)dashboardController.Storyboard.InstantiateViewController("RealTimeTrackingController");

						realTimeTrackingController.objRecentShipments = objRecentShipments;

						dashboardController.NavigationController.PushViewController(realTimeTrackingController, true);
					}

				}
				else
				{
					RealTimeTrackingController realTimeTrackingController;

					realTimeTrackingController = (RealTimeTrackingController)dashboardController.Storyboard.InstantiateViewController("RealTimeTrackingController");

					realTimeTrackingController.objRecentShipments = objRecentShipments;

					dashboardController.NavigationController.PushViewController(realTimeTrackingController, true);
				}
			}
			catch
			{
				loadPop.Hide();
				Console.WriteLine(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Deliveries the confirmation.
		/// </summary>
		/// <param name="objRecentShipments">Object recent shipments.</param>
		void DeliveryConfirmation(RecentShipments objRecentShipments)
		{
			pickupAndConfirmationKey = Constants.strDeliveryConf + "#" + objRecentShipments.ClientID + "|" + objRecentShipments.LocID + "|" + objRecentShipments.BolNum;
			dashboardController.RedirectToConfirmation(pickupAndConfirmationKey, objRecentShipments.ProNum);
		}

		void PickupConfirmation(RecentShipments objRecentShipments)
		{
			pickupAndConfirmationKey = Constants.strPickConf + "#" + objRecentShipments.ClientID + "|" + objRecentShipments.LocID + "|" + objRecentShipments.BolNum;
			dashboardController.RedirectToConfirmation(pickupAndConfirmationKey, objRecentShipments.ProNum);
		}

		/// <summary>
		/// Enables update shipment status tracking.
		/// </summary>
		/// <param name="objRecentShipment">Object recent shipment.</param>
		void UpdateShipmentStatus(RecentShipments objRecentShipment)
		{
			try
			{
                
				if (objRecentShipment.ViewAs.ToUpper() == Constants.strCarrier.ToUpper())
				{
					if (objRecentShipment.DispatchFlag)
					{
						if (CommanUtil.UserPermissions != null && CommanUtil.UserPermissions.Count > 0)
						{
							if (CommanUtil.UserPermissions.Contains(Constants.dispatcher) &&
								CommanUtil.UserPermissions.Contains(Constants.dispatcherDriver))
							{
								if (!string.IsNullOrEmpty(objRecentShipment.DriverID)
									&& objRecentShipment.DriverID.Equals(CommanUtil.userID))
								{
									UpdateTrackShipment(Constants.updateShipmentStatus, objRecentShipment);
								}
								else
								{
									if (!string.IsNullOrEmpty(objRecentShipment.DriverID)
										&& !objRecentShipment.DriverID.Equals(CommanUtil.userID))
									{
										UpdateTrackShipment(Constants.trackShipment, objRecentShipment);//trackShipment
									}
									else
									{
										UpdateTrackShipment(Constants.assignDriver, objRecentShipment);
									}
								}
							}
							else if (CommanUtil.UserPermissions.Contains(Constants.dispatcherDriver))
							{
								if (!string.IsNullOrEmpty(objRecentShipment.DriverID)
								   && objRecentShipment.DriverID.Equals(CommanUtil.userID))
								{

									UpdateTrackShipment(Constants.updateShipmentStatus, objRecentShipment);
								}
							}
						}
						else
						{

							UpdateTrackShipment(Constants.updateShipmentStatus, objRecentShipment);
						}
					}
					else
					{

						UpdateTrackShipment(Constants.updateShipmentStatus, objRecentShipment);
					}
				}
				else
				{

					UpdateTrackShipment(Constants.trackShipment, objRecentShipment);
				}
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}

		}


		/// <summary>
		/// Updates the track shipment.
		/// </summary>
		/// <param name="btnfindCurrentlc">Btnfind currentlc.</param>
		/// <param name="objRecentShipment">Object recent shipment.</param>
		public async void UpdateTrackShipment(string btnfindCurrentlc, RecentShipments objRecentShipment)
		{
			try
			{
				if (btnfindCurrentlc == Constants.assignDriver)
				{
					await BindDrivers(objRecentShipment);
				}
				else
				{
					TrackUpdateShipmentLocation(objRecentShipment, btnfindCurrentlc);
				}
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Binds the drivers.
		/// </summary>
		/// <returns>The drivers.</returns>
		/// <param name="objRecentShipment">Object recent shipment.</param>
		public async Task BindDrivers(RecentShipments objRecentShipment)
		{
			try
			{
				loadPop = null;
				CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
				if (loadPop == null)
				{
					loadPop = new LoadingOverlay(bounds);
				}
				string driverList = string.Empty;
				List<string> lstDrivers = new List<string>();
				if (!string.IsNullOrEmpty(CommanUtil.tokenNo))
				{
					if (Reachability.InternetConnectionStatus()) //Check Internet
					{
						//Get the service Helper Object
						dashboardController.View.Add(loadPop);
						//Get the Shipments
						driverList = await objServiceHelper.GetDriverList();
						if (!string.IsNullOrEmpty(driverList))
						{

							DriversList objDriversList = JsonConvert.DeserializeObject<DriversList>(driverList);
							// lstDrivers.Add(Constants.filterBy); //My Self Text
							if (objDriversList != null && objDriversList.Drivers.Count > 0)
							{
								foreach (var item in objDriversList.Drivers)
								{
									lstDrivers.Add(item.UserID);
								}
							}
							loadPop.Hide();
						}
					}
				}

				int yPosition = (int)(dashboardController.View.Frame.Height - 180) / 2;
				UIView pickerParentView = new UIView();
				viewPicker = new UIView(new CGRect(20, yPosition - 100, dashboardController.View.Frame.Width - 40, 210));
				viewPicker.BackgroundColor = UIColor.White;
				viewPicker.Layer.CornerRadius = 10;
				viewPicker.Layer.BorderWidth = 1;
				viewPicker.Layer.BorderColor = UIColor.Black.CGColor;
				pickerView = new UIPickerView(new CGRect(0, 0, viewPicker.Frame.Width, 180));
				pickerView.BackgroundColor = UIColor.White;
				pickerView.ShowSelectionIndicator = true;
				// create our simple picker model
				pickerDataModel = new PickerDataModel(lstDrivers);  //Assign Driver List 
																	// set it on our picker class
				pickerView.Model = pickerDataModel;
				// Create a 'done' button for the toolbar and add it to the toolbar
				doneButton = new UIButton(new CGRect(0, 180, viewPicker.Frame.Width, 30));
				doneButton.BringSubviewToFront(dashboardController.View);
				doneButton.SetTitle("Assign Driver", UIControlState.Normal);
				doneButton.BackgroundColor = ConstantsClass.btnColorRed;
				doneButton.Layer.CornerRadius = 10;
				doneButton.UserInteractionEnabled = true;
				viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });
				pickerDataModel.ValueChanged += (s, e) =>
				{
					//selectedValue = "  " + pickerDataModel.SelectedItem;
				};
				dashboardController.View.Add(viewPicker);
				//Done button click event
				doneButton.TouchUpInside += async (s, e) =>
				{
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
					await AssignDriverAsync(pickerDataModel.SelectedItem, objRecentShipment);
				};
				viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });
				pickerParentView.Frame = dashboardController.View.Frame;
				pickerParentView.BackgroundColor = UIColor.Clear;
				pickerParentView.Add(viewPicker);
				dashboardController.View.Add(pickerParentView);
				var tapGesture = new UITapGestureRecognizer(new Action(delegate
				{
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
				}));
				pickerParentView.AddGestureRecognizer(tapGesture);
			}
			catch(Exception ex)
			{
				string msg = ex.Message;
				loadPop.Hide();
				return;
			}
		}

		/// <summary>
		/// Assigns the driver async.
		/// </summary>
		/// <returns>The driver async.</returns>
		/// <param name="driverId">Driver identifier.</param>
		/// <param name="objRecentShipment">Object recent shipment.</param>
		private async Task AssignDriverAsync(string driverId, RecentShipments objRecentShipment)
		{
			try
			{
				string message = string.Empty;
				AssignDriver assignDriver = null;
				loadPop = null;
				CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
				if (loadPop == null)
				{
					loadPop = new LoadingOverlay(bounds);
				}
				if (!string.IsNullOrEmpty(CommanUtil.tokenNo))
				{
					if (Reachability.InternetConnectionStatus()) //Check Internet
					{
						dashboardController.View.Add(loadPop);
						#region Assign Driver object
						assignDriver = new AssignDriver();
						assignDriver.bolNum = objRecentShipment.BolNum;
						assignDriver.clientID = objRecentShipment.ClientID;
						assignDriver.dispatcherID = objRecentShipment.SCAC;
						assignDriver.dispatcherToken = CommanUtil.tokenNo;
						assignDriver.driverID = driverId;
						#endregion
						message = await Util.Node_AssignDriver(assignDriver);
						if (!string.IsNullOrEmpty(message))
						{
							loadPop.Hide();
							this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Convert.ToString(message), true, dashboardController, "", 1);
							dashboardController.View.Add(this.customAlert);
							message = string.Empty;
						}
					}
					else
					{
						this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Convert.ToString(Constants.strNoInternet), true, dashboardController, "", 1);
						dashboardController.View.Add(this.customAlert);
					}
				}
			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Convert.ToString(Constants.strErrorOccured), true, dashboardController, "", 1);
				dashboardController.View.Add(this.customAlert);
				if (loadPop != null)
				{
					loadPop.Hide();//Hide Loader
				}
			}
		}


		/// <summary>
		/// Compare Carrier Route
		/// </summary>
		/// <param name="position">position of shipment</param>
		private void GoToComparisonRouteMap(RecentShipments objRecentShipments)
		{
			string compareKey = objRecentShipments.OriginCity + ", "
				+ objRecentShipments.OriginState + " "
				+ objRecentShipments.OriginZip + "#" + objRecentShipments.ShipToCity + ", "
				+ objRecentShipments.ShipToState + ", " + objRecentShipments.ShipToZip + "#" + objRecentShipments.BolNum;
			dashboardController.RedirectToCompareRoute(compareKey);
		}

		/// <summary>
		/// Gos to shipment details.
		/// </summary>
		/// <param name="compositeKeyAwarded">Composite key awarded.</param>
		void GoToShipmentDetails(string compositeKeyAwarded)
		{
			dashboardController.SegueFromDashboradToShipmentDetail(compositeKeyAwarded);
		}

		/// <summary>
		/// Redirects to map.
		/// </summary>
		void GoToMap()
		{
			dashboardController.RedirectToMap(addressKey);
		}
	}
}

