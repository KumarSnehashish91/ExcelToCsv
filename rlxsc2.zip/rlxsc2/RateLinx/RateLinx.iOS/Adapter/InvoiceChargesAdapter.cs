using System;
using System.Collections.Generic;
using CoreGraphics;
using Foundation;
using RateLinx.Helper;
using RateLinx.Models;
using UIKit;

namespace RateLinx.iOS
{
	class InvoiceChargesAdapter : UITableViewSource
	{

		#region Variable Declaration

		List<Charges> listCharges;
		UIView viewInvoiceBottom;
		UILabel lblAddedCharges;
		UIView viewChargeTableHeading;
		UIView viewAddCharge;
		UILabel lblFileHeading;
		UITableView tblFiles;
		UIScrollView scrollViewInvoice;
		List<string> objFileList;
		#endregion
		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.InvoiceChargesAdapter"/> class.
		/// </summary>
		/// <param name="listCharges">List charges.</param>
		/// <param name="viewInvoiceBottom">View invoice bottom.</param>
		/// <param name="lblAddedCharges">Lbl added charges.</param>
		/// <param name="viewChargeTableHeading">View charge table heading.</param>
		/// <param name="lblFileHeading">Lbl file heading.</param>
		/// <param name="tblFiles">Tbl files.</param>
		/// <param name="scrollViewInvoice">Scroll view invoice.</param>
		/// <param name="objFileList">Object file list.</param>
		/// <param name="viewAddCharge">View add charge.</param>
		public InvoiceChargesAdapter(List<Charges> listCharges, UIView viewInvoiceBottom, UILabel lblAddedCharges,
									 UIView viewChargeTableHeading, UILabel lblFileHeading, UITableView tblFiles, UIScrollView scrollViewInvoice, List<string> objFileList, UIView viewAddCharge)
		{
			this.listCharges = listCharges;
			this.viewInvoiceBottom = viewInvoiceBottom;
			this.lblAddedCharges = lblAddedCharges;
			this.viewChargeTableHeading = viewChargeTableHeading;
			this.lblFileHeading = lblFileHeading;
			this.tblFiles = tblFiles;
			this.scrollViewInvoice = scrollViewInvoice;
			this.objFileList = objFileList;
			this.viewAddCharge = viewAddCharge;

		}
		/// <summary>
		/// Gets the cell.
		/// </summary>
		/// <returns>The cell.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{

			try
			{
				UIColor altColor = null;
				if (indexPath.Row % 2 == 0)
				{
					altColor = Constants.tableRowOddColor;
				}
				else
				{
					altColor = UIColor.LightGray;
				}

				UITableViewCell invoiceChargeCell = new UITableViewCell(new CGRect(0, 0, tableView.Frame.Width, 35));



				invoiceChargeCell.BackgroundColor = altColor;

				UIView viewAction = new UIView(new CGRect(0, 0, tableView.Frame.Width * 0.3, 35));

				UIButton btnAction = new UIButton(new CGRect(viewAction.Frame.Width/2-10, 2, 35, 30));
				btnAction.Layer.CornerRadius = 10;

				viewAction.AddSubview(btnAction);
				//btnAction.Font = UIFont.FromName(Constants.strFontName, 15f);
				btnAction.ContentMode = UIViewContentMode.Center;
				btnAction.SetImage(UIImage.FromBundle("Images/error.PNG"), UIControlState.Normal);

				//btnAction.SetTitle(NSBundle.MainBundle.LocalizedString("croxSign", null), UIControlState.Normal);
				btnAction.HorizontalAlignment = UIControlContentHorizontalAlignment.Center;
				btnAction.SetTitleColor(UIColor.Red, UIControlState.Normal);
				btnAction.UserInteractionEnabled = true;
				btnAction.Tag = indexPath.Row;

				btnAction.TouchUpInside += delegate
				{
					MaintainInvoiceChargesList(btnAction.Tag, tableView);
				};
				UILabel lblCharge = new UILabel(new CGRect(tableView.Frame.Width * 0.3, 0, tableView.Frame.Width * 0.3, 35));
				lblCharge.TextColor = UIColor.Black;
				lblCharge.Font = UIFont.FromName(Constants.strFontName, 13f);
				lblCharge.Text = listCharges[indexPath.Row].Value;
				lblCharge.TextAlignment = UITextAlignment.Center;



				UILabel lblAmount = new UILabel(new CGRect(tableView.Frame.Width * 0.6, 0, tableView.Frame.Width / 10 * 4, 35));
				lblAmount.TextColor = UIColor.Black;
				lblAmount.Font = UIFont.FromName(Constants.strFontName, 13f);
				lblAmount.Text = listCharges[indexPath.Row].ID;
				lblAmount.TextAlignment = UITextAlignment.Center;

				invoiceChargeCell.AddSubviews(viewAction, lblCharge, lblAmount);

				return invoiceChargeCell;
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Maintains the invoice charges list.
		/// </summary>
		/// <param name="tag">Tag.</param>
		/// <param name="tableView">Table view.</param>
		void MaintainInvoiceChargesList(nint tag, UITableView tableView)
		{
			listCharges.RemoveAt(Convert.ToInt32(tag));
			if (listCharges.Count == 0)
			{
				lblAddedCharges.Frame = new CGRect(0, 0, viewInvoiceBottom.Frame.Width, 0);
				viewChargeTableHeading.Frame = new CGRect(15, lblAddedCharges.Frame.Bottom + 10, viewInvoiceBottom.Frame.Width - 30, 0);
			}
			tableView.Source = new InvoiceChargesAdapter(listCharges, viewInvoiceBottom, lblAddedCharges, viewChargeTableHeading, lblFileHeading, tblFiles, scrollViewInvoice, objFileList, viewAddCharge);
			tableView.Frame = new CGRect(15, viewChargeTableHeading.Frame.Bottom, viewInvoiceBottom.Frame.Width - 30, listCharges.Count * 25);
			tableView.ReloadData();
			lblFileHeading.Frame = new CGRect(15, tableView.Frame.Y + listCharges.Count * 35 + 20, viewInvoiceBottom.Frame.Width - 30, 30);
			if (objFileList != null && objFileList.Count > 0)
			{

				tblFiles.Frame = new CGRect(15, lblFileHeading.Frame.Bottom, viewInvoiceBottom.Frame.Width - 30, objFileList.Count * 25);
			}
			else
			{
				tblFiles.Frame = new CGRect(15, lblFileHeading.Frame.Bottom, viewInvoiceBottom.Frame.Width - 30, 0);
			}
			viewInvoiceBottom.Frame = new CGRect(0, viewAddCharge.Frame.Bottom, viewAddCharge.Frame.Width, tblFiles.Frame.Bottom);
			scrollViewInvoice.ContentSize = new CGSize(viewInvoiceBottom.Frame.Width, viewInvoiceBottom.Frame.Bottom);
			scrollViewInvoice.ScrollEnabled = true;
			scrollViewInvoice.AutoresizingMask = UIViewAutoresizing.FlexibleHeight;


		}
		/// <summary>
		/// Rowses the in section.
		/// </summary>
		/// <returns>The in section.</returns>
		/// <param name="tableview">Tableview.</param>
		/// <param name="section">Section.</param>
		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return listCharges.Count;
		}
	}
}