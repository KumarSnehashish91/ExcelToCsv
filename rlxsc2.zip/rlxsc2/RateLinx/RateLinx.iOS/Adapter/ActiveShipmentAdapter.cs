﻿using System;
using UIKit;
using Foundation;
using Newtonsoft.Json.Linq;
using RateLinx.Helper;
using RateLinx.Models;
using System.Threading.Tasks;
using RateLinx.APIs;
using ToastIOS;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Linq;

namespace RateLinx.iOS
{
	public class ActiveShipmentAdapter : UITableViewSource
	{
		#region Variable Declaration

		public List<ActiveShipments> lstActiveShipments = null;  // Declare active shipment list
		DashboardController dashboardController;

		#endregion
		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.ActiveShipmentAdapter"/> class.
		/// </summary>
		/// <param name="dashboardController">Dashboard controller.</param>
		/// <param name="activeShipment">Active shipment.</param>
		public ActiveShipmentAdapter(DashboardController dashboardController, List<ActiveShipments> activeShipment)
		{
			lstActiveShipments = activeShipment;
			this.dashboardController = dashboardController;
		}
		/// <summary>
		/// Rowses the in section.
		/// </summary>
		/// <returns>The in section.</returns>
		/// <param name="tableview">Tableview.</param>
		/// <param name="section">Section.</param>
		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return lstActiveShipments.Count;
		}
		/// <summary>
		/// Gets the height for row.
		/// </summary>
		/// <returns>The height for row.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override nfloat GetHeightForRow(UITableView tableView, NSIndexPath indexPath)
		{

			nfloat activeShipmentCellHeight = 285;
			if (lstActiveShipments[indexPath.Row].ViewAs.ToUpper() == Constants.strCustomer.ToUpper())
			{
				activeShipmentCellHeight -= 40;

				if (lstActiveShipments[indexPath.Row].Bids != null && lstActiveShipments[indexPath.Row].Bids.Count > 0)
				{
					activeShipmentCellHeight += 40 + lstActiveShipments[indexPath.Row].Bids.Count * 25;
				}
				else
				{
					activeShipmentCellHeight += 40;
				}
			}
			else
			{
				activeShipmentCellHeight += 40;
			}

			return activeShipmentCellHeight;

		}
		/// <summary>
		/// Rows the selected.
		/// </summary>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override void RowSelected(UITableView tableView, NSIndexPath indexPath)
		{
			var dsd = lstActiveShipments[indexPath.Row];
			tableView.DeselectRow(indexPath, true);
		}

		public void updateCellInfo(UITableView tableView, NSIndexPath indexPath)
		{
			ActiveShipmentCells cell = tableView.CellAt(indexPath)!= null ? (ActiveShipmentCells)tableView.CellAt(indexPath) : null;
			if (cell!=null){
				ActiveShipments objActiveShipments = lstActiveShipments[indexPath.Row];
				objActiveShipments = lstActiveShipments[indexPath.Row];
				cell.UpdateCell(dashboardController, objActiveShipments, indexPath.Row, tableView);
			}
		}

		/// <summary>
		/// Gets the cell.
		/// </summary>
		/// <returns>The cell.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			try
			{
				ActiveShipmentCells cell = (ActiveShipmentCells)tableView.DequeueReusableCell("ActiveShipment", indexPath);
				if (cell != null)
				{
					ActiveShipments objActiveShipments = lstActiveShipments[indexPath.Row];
					objActiveShipments = lstActiveShipments[indexPath.Row];
					cell.UpdateCell(dashboardController, objActiveShipments, indexPath.Row, tableView);
					return cell;

				}
				else
				{
					return null;
				}
			}
			catch
			{
				throw;

			}

		}


	}
}
