using System;
using System.Collections.Generic;
using CoreGraphics;
using Foundation;
using RateLinx.Helper;
using RateLinx.Models;
using UIKit;

namespace RateLinx.iOS
{
	class SSesDetailsAdapter : UITableViewSource
	{

		#region Variable Declaration

		List<SS> sSes;

		#endregion


		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.SSesDetailsAdapter"/> class.
		/// </summary>
		/// <param name="sSes">S ses.</param>
		public SSesDetailsAdapter(List<SS> sSes)
		{
			this.sSes = sSes;
		}
		/// <summary>
		/// Rowses the in section.
		/// </summary>
		/// <returns>The in section.</returns>
		/// <param name="tableview">Tableview.</param>
		/// <param name="section">Section.</param>
		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return sSes.Count;
		}

		/// <summary>
		/// Gets the cell.
		/// </summary>
		/// <returns>The cell.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			try
			{
				//tableView.RowHeight = 25;
				//nfloat yCordinate = 0;
				UIColor altColor = null;
				if (indexPath.Row % 2 == 0)
				{
					altColor = Constants.tableRowOddColor;
				}
				else
				{
					altColor = UIColor.LightGray;
				}


				UITableViewCell objSSesCell = new UITableViewCell(new CGRect(0, 0, tableView.Frame.Width, 25));
				objSSesCell.Frame = new CGRect(0, 0, tableView.Frame.Width, 25);
				objSSesCell.BackgroundColor = UIColor.Red;
				UIView viewSSesDetail = new UIView(new CGRect(0, 0, tableView.Frame.Width, objSSesCell.Frame.Height));
				viewSSesDetail.BackgroundColor = altColor;


				UILabel lblSSesOption = new UILabel(new CGRect(10, 0, tableView.Frame.Width / 2 - 10, viewSSesDetail.Frame.Height));
				lblSSesOption.TextColor = UIColor.Black;
				lblSSesOption.Font = UIFont.FromName(Constants.strFontName, 11f);
				lblSSesOption.Text = sSes[indexPath.Row].ID;
				UILabel lblSSesText = new UILabel(new CGRect(tableView.Frame.Width / 2, 0, tableView.Frame.Width / 2 - 10, viewSSesDetail.Frame.Height));
				lblSSesText.TextColor = UIColor.Black;
				lblSSesText.Font = UIFont.FromName(Constants.strFontName, 11f);
				lblSSesText.Text = sSes[indexPath.Row].Value;


				//yCordinate = viewSSesDetail.Frame.Height;

				viewSSesDetail.AddSubviews(lblSSesOption, lblSSesText);
				objSSesCell.AddSubview(viewSSesDetail);
				return objSSesCell;
			}
			catch
			{
				throw;
			}
		}


	}
}