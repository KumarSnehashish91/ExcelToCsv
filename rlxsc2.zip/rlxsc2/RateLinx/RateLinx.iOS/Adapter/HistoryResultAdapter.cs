﻿using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;
using RateLinx.Models;
using RateLinx.Helper;
using System.Collections.Generic;
using CoreGraphics;

namespace RateLinx.iOS
{
	public class HistoryResultAdapter : UITableViewSource
	{
		#region Variable Declaration

		List<RateHistoryResult> lstRateHistoryResult;
		List<RateHistoryColumns> lstHistoryResultColumns;
		HistoryResultController objHistoryResultController;
		#endregion
		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.HistoryResultAdapter"/> class.
		/// </summary>
		/// <param name="lstRateHistoryResult">Lst rate history result.</param>
		/// <param name="lstHistoryResultColumns">Lst history result columns.</param>
		public HistoryResultAdapter (List<RateHistoryResult> lstRateHistoryResult, List<RateHistoryColumns> lstHistoryResultColumns,HistoryResultController objHistoryResultController) 
		{
			this.lstRateHistoryResult = lstRateHistoryResult;
			this.lstHistoryResultColumns = lstHistoryResultColumns;
			this.objHistoryResultController = objHistoryResultController;
		}

		/// <summary>
		/// Rowses the in section.
		/// </summary>
		/// <returns>The in section.</returns>
		/// <param name="tableview">Tableview.</param>
		/// <param name="section">Section.</param>
		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return lstRateHistoryResult.Count;
		}

		/// <summary>
		/// Gets the cell.
		/// </summary>
		/// <returns>The cell.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			try
			{
				HistoryResultCell cell = (HistoryResultCell)tableView.DequeueReusableCell("HistoryResultIdentity", indexPath);

				RateHistoryResult objRateHistoryResult = lstRateHistoryResult[indexPath.Row];

				if (cell != null)
				{
					cell.UpdateCell(objRateHistoryResult, lstHistoryResultColumns, indexPath.Row);
					cell.TextLabel.Font = UIFont.FromName(Constants.strFontName, 13.0f);
					cell.SelectionStyle = UITableViewCellSelectionStyle.None;
					return cell;

				}


				else
				{
					return null;
				}
			}
			catch(Exception ex)
			{
				Console.Write(ex.Message);
				return null;
			}

		}
		public override nfloat GetHeightForRow(UITableView tableView, NSIndexPath indexPath)
		{
			return 44;
		}
		public override nint NumberOfSections(UITableView tableView)
		{
			return 1;
		}
		public override UIView GetViewForHeader(UITableView tableView, nint section)
		{

			UIView viewHistoryResultHeader = new UIView();
                      
			viewHistoryResultHeader.Frame = new CGRect(0, 0, tableView.Frame.Width, 47);
			int marginBtwCol = 2;
			int XPosition = 0;

			foreach (RateHistoryColumns objRateHistoryColumn in lstHistoryResultColumns)
			{
				if (!objRateHistoryColumn.Hidden)
				{
					UILabel objColumnName = new UILabel();

					objColumnName.Frame = new CGRect(XPosition, 1, 120, viewHistoryResultHeader.Frame.Height);
					objColumnName.Text = "  " + objRateHistoryColumn.FieldName;
					objColumnName.TextColor = UIColor.Red;
					objColumnName.BackgroundColor = UIColor.Black;
					objColumnName.Font = UIFont.FromName(Constants.strFontName, 14.0f);
					viewHistoryResultHeader.AddSubview(objColumnName);
					XPosition = XPosition + 120 + marginBtwCol;
				}
			}
			//UILabel lblTest = new UILabel();
			//lblTest.Bounds = viewHistoryResultHeader.Bounds;
			//lblTest.TextColor = UIColor.Black;
			//viewHistoryResultHeader.AddSubview(lblTest);

			//lblTest.Text = "Testing message in the history result page....";
			viewHistoryResultHeader.BackgroundColor = UIColor.White;
			UIView viewDivider1 = new UIView();
			viewDivider1.Frame = new CGRect(0, viewHistoryResultHeader.Frame.Height - 2, XPosition, 3);
			viewDivider1.BackgroundColor = UIColor.White;
			viewHistoryResultHeader.AddSubview(viewDivider1);

			return viewHistoryResultHeader;
		}
		public override nfloat GetHeightForHeader(UITableView tableView, nint section)
		{
			return 47;
		}

		public override void RowSelected(UITableView tableView, NSIndexPath indexPath)
		{
            if (CommanUtil.IsTimeOut())
            {
                string compareKey = lstRateHistoryResult[indexPath.Row].ClientID + "|" + lstRateHistoryResult[indexPath.Row].LoadNum + "|" + ConstantsClass.strHistory;
                objHistoryResultController.SegueFromHistoryToShipmentDetail(compareKey);
            }
            else
            {
                return;
            }
		}
	}
}

