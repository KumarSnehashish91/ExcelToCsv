﻿using System;
using UIKit;
using Foundation;
using Newtonsoft.Json.Linq;
using RateLinx.Helper;
using RateLinx.Models;
using System.Threading.Tasks;
using RateLinx.APIs;
using ToastIOS;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Linq;

namespace RateLinx.iOS
{
	public class ActiveShipmentBidDetails : UITableViewSource
	{
		#region Variable Declaration

		List<Bid> lstBids = null;  

		#endregion


		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.ActiveShipmentBidDetails"/> class.
		/// </summary>
		/// <param name="lstBids">Lst bids.</param>
		public ActiveShipmentBidDetails(List<Bid> lstBids)
		{
			this.lstBids = lstBids;

		}
		/// <summary>
		/// Rowses the in section.
		/// </summary>
		/// <returns>The in section.</returns>
		/// <param name="tableview">Tableview.</param>
		/// <param name="section">Section.</param>
		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return lstBids.Count;
		}
		/// <summary>
		/// Gets the height for row.
		/// </summary>
		/// <returns>The height for row.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override nfloat GetHeightForRow(UITableView tableView, NSIndexPath indexPath)
		{
			//tableView.Bounds = new CoreGraphics.CGRect(0, 0, 0, 0);
			if (lstBids.Count == 0)
			{
				//tableView.Bounds = new CoreGraphics.CGRect(0, 0, 0, 0);
				return 0;
			}
			else
			{
				return 30;
			}
		}
		/// <summary>
		/// Gets the cell.
		/// </summary>
		/// <returns>The cell.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			try
			{
				CarrierBidDetail cell = (CarrierBidDetail)tableView.DequeueReusableCell("CarrierBidDetails", indexPath);//getting cell id

				Bid objBid = lstBids[indexPath.Row];
				cell.UpdateCell(objBid, indexPath.Row);
				return cell;

			}
			catch (Exception ex)
			{
				throw ex;
			}

		}

	}
}

