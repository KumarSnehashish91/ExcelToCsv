﻿using System;
using UIKit;
using Foundation;
using System.Linq;
using System.Collections.Generic;
using RateLinx.Models;
using CoreGraphics;
using RateLinx.Helper;

namespace RateLinx.iOS
{
	public class AwardedShipmentAdapter : UITableViewSource
	{
		#region Variable Declaration

		private string cellIdentifier = "AwardedShipmentIdentifier";
		DashboardController dashboardController;
		public List<AwardedShipments> lstAwardedShipments = null;  // Declare Awarded shipment list
		string addressKey;
		CustomPopup customAlert = null;
		UITapGestureRecognizer tapGestureTo, tapGestureFrom;
		#endregion


		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.AwardedShipmentAdapter"/> class.
		/// </summary>
		/// <param name="awardedShipment">Awarded shipment.</param>
		/// <param name="dashboardController">Dashboard controller.</param>
		public AwardedShipmentAdapter(List<AwardedShipments> awardedShipment, DashboardController dashboardController)
		{
			lstAwardedShipments = awardedShipment;
			this.dashboardController = dashboardController;
		}
		/// <summary>
		/// Rowses the in section.
		/// </summary>
		/// <returns>The in section.</returns>
		/// <param name="tableview">Tableview.</param>
		/// <param name="section">Section.</param>
		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return lstAwardedShipments.Count;
		}
		/// <summary>
		/// Gets the height for row.
		/// </summary>
		/// <returns>The height for row.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override nfloat GetHeightForRow(UITableView tableView, NSIndexPath indexPath)
		{
			if (lstAwardedShipments[indexPath.Row].ViewAs == Constants.strCarrier)
			{
				return 250;
			}
			else
			{
				return 210;
			}
		}
		/// <summary>
		/// Gets the cell.
		/// </summary>
		/// <returns>The cell.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			try
			{
				AwardedShipmentCells cell = (AwardedShipmentCells)tableView.DequeueReusableCell(cellIdentifier) as AwardedShipmentCells;////getting cell id
				if (cell != null)
				{
					AwardedShipments objAwardedShipments = lstAwardedShipments[indexPath.Row];


					//compositeKey = objAwardedShipments.ClientID + "|" + objAwardedShipments.BolNum + "|" + "";

					UIColor evenColor, oddColor;
					evenColor = Constants.awardShipEvenColor;
					oddColor = Constants.awardShipOddColor;

					nfloat width = tableView.Frame.Width;

					nfloat yCordinate = 0;


					UIView viewAwardedShipmentHeader = new UIView(new CGRect(0, 0, tableView.Frame.Width, 45));
					viewAwardedShipmentHeader.BackgroundColor = Constants.shipmentHeadColor;

					UIButton btnAwardedHeader = new UIButton();
					btnAwardedHeader.Frame = viewAwardedShipmentHeader.Bounds;
					btnAwardedHeader.BackgroundColor = UIColor.Clear;

					btnAwardedHeader.TouchUpInside += delegate
					{
                        GoToShipmentDetails(objAwardedShipments.ClientID + "|" + objAwardedShipments.BolNum + "|" + "");
					};
					viewAwardedShipmentHeader.AddSubview(btnAwardedHeader);

					UIImageView imgHammerIcon = new UIImageView(new CGRect(5, 12, 20, 20));

					imgHammerIcon.Image = new UIImage("Images/hammer-icon.png");

					UILabel lblAwardedBolNo = new UILabel(new CGRect(35, 0, viewAwardedShipmentHeader.Frame.Width - 100, 45));

					lblAwardedBolNo.TextColor = UIColor.White;
					lblAwardedBolNo.Font = UIFont.FromName(Constants.strFontName, 11f);

					lblAwardedBolNo.Text = objAwardedShipments.BolNum;
                    decimal awardedPrice = Convert.ToDecimal(objAwardedShipments.AwardedPrice);
                    var awardedDecimalPrice = string.Format("{0:0.00}", awardedPrice);
					if (objAwardedShipments.IsTest == true)
					{
						lblAwardedBolNo.Text = lblAwardedBolNo.Text + Constants.strTestBol;
					}
					else
					{
                        lblAwardedBolNo.Text = lblAwardedBolNo.Text + " for " + "$" + awardedDecimalPrice;
					}


					UIImageView imgArrowIcon = new UIImageView(new CGRect(viewAwardedShipmentHeader.Frame.Width - 30, 12, 20, 20));

					imgArrowIcon.Image = new UIImage("Images/arrow-icon.png");

					viewAwardedShipmentHeader.AddSubviews(imgHammerIcon, lblAwardedBolNo, imgArrowIcon);

					yCordinate += viewAwardedShipmentHeader.Frame.Height;


					List<UIView> lstViews = new List<UIView>();


					UIView viewFor = new UIView(new CGRect(0, yCordinate, width, 0));

					if (objAwardedShipments.ViewAs == Constants.strCarrier)
					{
						viewFor.Frame = new CGRect(0, yCordinate, width, 40);

						viewFor.BackgroundColor = evenColor;
						//viewFor.BackgroundColor = UIColor.LightGray;

						UILabel lblForLabel = new UILabel(new CGRect(20, 0, width / 3, 40));
						lblForLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
						lblForLabel.Text = NSBundle.MainBundle.LocalizedString("for", null);


						UILabel lblForText = new UILabel(new CGRect(width / 3 + 20, 0, width - (width / 3 + 20), 40));
						lblForText.Font = UIFont.FromName(Constants.strFontName, 13f);
						lblForText.Text = objAwardedShipments.ClientID;
						viewFor.AddSubviews(lblForLabel, lblForText);

						yCordinate += 40;
					}
					tableView.AddSubview(viewFor);
					lstViews.Add(viewFor);

					UIView viewFrom = new UIView(new CGRect(0, yCordinate, width, 40));
					viewFrom.BackgroundColor = oddColor;
					//viewFrom.BackgroundColor = UIColor.LightGray;

					UILabel lblFromLabel = new UILabel(new CGRect(20, 0, width / 3, 40));
					lblFromLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblFromLabel.Text = NSBundle.MainBundle.LocalizedString("from", null);

					UILabel lblFromText = new UILabel(new CGRect(width / 3 + 20, 0, width - (width / 3 + 20), 40));
					lblFromText.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblFromText.Text = objAwardedShipments.OriginCity + ", " + objAwardedShipments.OriginState + " " + objAwardedShipments.OriginZip;
					lblFromText.Lines = 0;
					lblFromText.UserInteractionEnabled = true;
					lblFromText.TextColor = UIColor.Blue;
					viewFrom.AddSubviews(lblFromLabel, lblFromText);
					lstViews.Add(viewFrom);
					yCordinate += 40;
					UIView viewTo = new UIView(new CGRect(0, yCordinate, width, 40));
					viewTo.BackgroundColor = evenColor;

					UILabel lblToLabel = new UILabel(new CGRect(20, 0, width / 3, 40));
					lblToLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblToLabel.Text = NSBundle.MainBundle.LocalizedString("to", null);

					UILabel lblToText = new UILabel(new CGRect(width / 3 + 20, 0, width - (width / 3 + 20), 40));
					lblToText.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblToText.Text = objAwardedShipments.ShipToCity + ", " + objAwardedShipments.ShipToState + " " + objAwardedShipments.ShipToZip;
					lblToText.Lines = 0;
					lblToText.UserInteractionEnabled = true;
					lblToText.TextColor = UIColor.Blue;
					viewTo.AddSubviews(lblToLabel, lblToText);
					lstViews.Add(viewTo);
					yCordinate += 40;


					UIView viewPickup = new UIView(new CGRect(0, yCordinate, width, 40));
					viewPickup.BackgroundColor = oddColor;
					//viewPickup.BackgroundColor = UIColor.LightGray;

					UILabel lblPickupLabel = new UILabel(new CGRect(20, 0, width / 3, 40));
					lblPickupLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblPickupLabel.Text = NSBundle.MainBundle.LocalizedString("pickup", null);


					UILabel lblPickupText = new UILabel(new CGRect(width / 3 + 20, 0, width - (width / 3 + 20), 40));
					lblPickupText.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblPickupText.Text = objAwardedShipments.PickupStr;
					lblPickupText.Lines = 0;
					viewPickup.AddSubviews(lblPickupLabel, lblPickupText);
					lstViews.Add(viewPickup);
					yCordinate += 40;


					UIView viewDriverId = new UIView(new CGRect(0, yCordinate, width, 40));
					viewDriverId.BackgroundColor = evenColor;
					//viewDriverId.BackgroundColor = UIColor.Green;

					UILabel lblDriverLabel = new UILabel(new CGRect(20, 0, width / 3, 40));
					lblDriverLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblDriverLabel.Text = NSBundle.MainBundle.LocalizedString("driverId", null);

					UILabel lblDriverText = new UILabel(new CGRect(width / 3 + 20, 0, width - (width / 3 + 20), 40));
					lblDriverText.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblDriverText.Text = objAwardedShipments.DriverID;

					viewDriverId.AddSubviews(lblDriverLabel, lblDriverText);
					lstViews.Add(viewDriverId);
					yCordinate += 40;
					cell.AddSubviews(viewAwardedShipmentHeader, viewDriverId, viewFrom, viewTo, viewPickup, viewFor);
					addressKey = lblFromText.Text + "#" + objAwardedShipments.ShipToCity + ", "
						+ objAwardedShipments.ShipToState + ", " + objAwardedShipments.ShipToZip + "#" + objAwardedShipments.BolNum;

					tapGestureTo = new UITapGestureRecognizer(GoToMap);
					lblToText.AddGestureRecognizer(tapGestureTo);

					tapGestureFrom = new UITapGestureRecognizer(GoToMap);
					lblFromText.AddGestureRecognizer(tapGestureFrom);


					return cell;
				}
				else
				{
					return null;
				}

			}
			catch
			{
				throw;
			}
			//return null;
		}
		/// <summary>
		/// Gos to shipment details.
		/// </summary>
		/// <param name="compositeKeyAwarded">Composite key awarded.</param>
		void GoToShipmentDetails(string compositeKeyAwarded)
		{
			if (Reachability.InternetConnectionStatus())
			{
				dashboardController.SegueFromDashboradToShipmentDetail(compositeKeyAwarded);
			}
			else
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, dashboardController, "", 1);
				dashboardController.View.Add(this.customAlert);
			}
		}
		/// <summary>
		/// Redirects to map.
		/// </summary>
		void GoToMap()
		{
			if (Reachability.InternetConnectionStatus())
			{
				dashboardController.RedirectToMap(addressKey);
			}
			else
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, dashboardController, "", 1);
				dashboardController.View.Add(this.customAlert);
			}
		}
	}
}

