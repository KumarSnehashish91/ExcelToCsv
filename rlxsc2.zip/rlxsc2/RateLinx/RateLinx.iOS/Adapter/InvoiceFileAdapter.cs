using System;
using System.Collections.Generic;
using CoreGraphics;
using Foundation;
using RateLinx.Helper;
using UIKit;

namespace RateLinx.iOS
{
	class InvoiceFileAdapter : UITableViewSource
	{
		#region Variable Declaration

		int fileIndex = 0;
		List<string> objFileList;
		InvoiceController invoiceController;
		#endregion

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.InvoiceFileAdapter"/> class.
		/// </summary>
		/// <param name="objFileList">Object file list.</param>
		/// <param name="objInvoiceController">Object invoice controller.</param>
		public InvoiceFileAdapter(List<string> objFileList,InvoiceController objInvoiceController)
		{
			this.objFileList = objFileList;
			this.invoiceController = objInvoiceController;
		}
		/// <summary>
		/// Gets the cell.
		/// </summary>
		/// <returns>The cell.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			try
			{
				UIColor altColor = null;
				if (indexPath.Row % 2 == 0)
				{
					altColor = Constants.tableRowOddColor;
				}
				else
				{
					altColor = UIColor.LightGray;
				}
				fileIndex = indexPath.Row;
				UITableViewCell invoiceFileCell = new UITableViewCell(new CGRect(0, 0, tableView.Frame.Width, 25));
				invoiceFileCell.BackgroundColor = altColor;

				UIButton btnFileName = new UIButton();
				btnFileName.Frame = new CGRect(0, 0, tableView.Frame.Width, 25);
				btnFileName.SetTitleColor(UIColor.Blue, UIControlState.Normal);
				btnFileName.Font = UIFont.FromName(Constants.strFontName, 13f);
				int cutFileName = objFileList[indexPath.Row].LastIndexOf('/');
				btnFileName.SetTitle(" " + objFileList[indexPath.Row].Substring(cutFileName + 1), UIControlState.Normal);
				btnFileName.HorizontalAlignment = UIControlContentHorizontalAlignment.Left;
				btnFileName.TouchUpInside +=delegate {
					invoiceController.RedirectToWebView(fileIndex);
				};
				invoiceFileCell.AddSubview(btnFileName);
				return invoiceFileCell;
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
				return null;
			}
			
		}
		/// <summary>
		/// Rowses the in section.
		/// </summary>
		/// <returns>The in section.</returns>
		/// <param name="tableview">Tableview.</param>
		/// <param name="section">Section.</param>
		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return objFileList.Count;
		}
		/// <summary>
		/// Gets the height for row.
		/// </summary>
		/// <returns>The height for row.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override nfloat GetHeightForRow(UITableView tableView, NSIndexPath indexPath)
		{
			return 25;
		}
		
	}
}