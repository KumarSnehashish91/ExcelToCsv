﻿using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;
using RateLinx.Models;
using RateLinx.Helper;
using System.Collections.Generic;
using CoreGraphics;

namespace RateLinx.iOS
{
    public class OrderHistoryAdapter : UITableViewSource
    {
        #region Variable Declaration

        List<OrderHistory> lstRateHistoryResult;
        //List<RateHistoryColumns> lstHistoryResultColumns;
        List<string> lstColumn = new List<string>();
        OrderHistoryController objOrderHistoryController;
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="T:RateLinx.iOS.OrderHistoryAdapter"/> class.
        /// </summary>
        /// <param name="lstRateHistoryResult">Lst rate history result.</param>
        /// <param name="objOrderHistoryController">Object order history controller.</param>
        public OrderHistoryAdapter(List<OrderHistory> lstRateHistoryResult, OrderHistoryController objOrderHistoryController)
        {
            this.lstRateHistoryResult = lstRateHistoryResult;
            //this.lstHistoryResultColumns = lstHistoryResultColumns;
            this.objOrderHistoryController = objOrderHistoryController;
        }

        /// <summary>
        /// Rowses the in section.
        /// </summary>
        /// <returns>The in section.</returns>
        /// <param name="tableview">Tableview.</param>
        /// <param name="section">Section.</param>
        public override nint RowsInSection(UITableView tableview, nint section)
        {
            return lstRateHistoryResult.Count;
        }

        /// <summary>
        /// Gets the cell.
        /// </summary>
        /// <returns>The cell.</returns>
        /// <param name="tableView">Table view.</param>
        /// <param name="indexPath">Index path.</param>
        public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
        {
            
            try
            {
                OrderHistoryCell cell = (OrderHistoryCell)tableView.DequeueReusableCell("OrderHistoryCell", indexPath);
                OrderHistory objRateHistoryResult = lstRateHistoryResult[indexPath.Row];
                if (cell != null)
                {
                    cell.UpdateCell(objRateHistoryResult, indexPath.Row);
                    cell.TextLabel.Font = UIFont.FromName(Constants.strFontName, 13.0f);
                    cell.SelectionStyle = UITableViewCellSelectionStyle.None;
                    return cell;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
                return null;
            }
        }
        public override nfloat GetHeightForRow(UITableView tableView, NSIndexPath indexPath)
        {
            return 44;
        }
        public override nint NumberOfSections(UITableView tableView)
        {
            return 1;
        }
        public override UIView GetViewForHeader(UITableView tableView, nint section)
        {
            nfloat marginBtwCol = 2;
            nfloat XPosition = 0;

            UIView viewHistoryResultHeader = new UIView();
           
            UILabel lblSelecAllText = new UILabel(new CGRect(XPosition, 1, 75, 50));
            lblSelecAllText.Text = "";//             "+ "Select All"
            lblSelecAllText.TextColor = UIColor.White;
            lblSelecAllText.BackgroundColor = UIColor.Black;
            lblSelecAllText.Font = UIFont.FromName(Constants.strFontName, 14.0f);
            lblSelecAllText.TextAlignment = UITextAlignment.Center;
            UIButton btnCheck = new UIButton(new CGRect(20, 13, 23, 23));
            btnCheck.BackgroundColor = UIColor.White;
            btnCheck.Layer.CornerRadius = 2;
            btnCheck.Layer.BorderWidth = 2;
            btnCheck.Layer.BorderColor = UIColor.FromRGB(157,34,53).CGColor;

            XPosition += lblSelecAllText.Frame.Width + marginBtwCol;

            UILabel OrderID = new UILabel(new CGRect(XPosition, 1, 80, 50));
            OrderID.Text = "Order ID";//             "+ "Select All"
            OrderID.TextColor = UIColor.White;
            OrderID.BackgroundColor = UIColor.Black;
            OrderID.Font = UIFont.FromName(Constants.strFontName, 14.0f);
            OrderID.TextAlignment = UITextAlignment.Center;
         
            XPosition += OrderID.Frame.Width + marginBtwCol;

            UILabel StoreID = new UILabel(new CGRect(XPosition, 1, 80, 50));
            StoreID.Text = "Store ID";//             "+ "Select All"
            StoreID.TextColor = UIColor.White;
            StoreID.BackgroundColor = UIColor.Black;
            StoreID.Font = UIFont.FromName(Constants.strFontName, 14.0f);
            StoreID.TextAlignment = UITextAlignment.Center;

            XPosition += StoreID.Frame.Width + marginBtwCol;

            UILabel Status = new UILabel(new CGRect(XPosition, 1, 100, 50));
            Status.Text = "Status";//             "+ "Select All"
            Status.TextColor = UIColor.White;
            Status.BackgroundColor = UIColor.Black;
            Status.Font = UIFont.FromName(Constants.strFontName, 14.0f);
            Status.TextAlignment = UITextAlignment.Center;

            XPosition += Status.Frame.Width + marginBtwCol;

            UILabel OrderDate = new UILabel(new CGRect(XPosition, 1, 170, 50));
            OrderDate.Text = "Order Date";//             "+ "Select All"
            OrderDate.TextColor = UIColor.White;
            OrderDate.BackgroundColor = UIColor.Black;
            OrderDate.Font = UIFont.FromName(Constants.strFontName, 14.0f);
            OrderDate.TextAlignment = UITextAlignment.Center;

            XPosition += OrderDate.Frame.Width + marginBtwCol;

            UILabel ShipTo_Attention = new UILabel(new CGRect(XPosition, 1, 150, 50));
            ShipTo_Attention.Text = "Ship To";//             "+ "Select All"
            ShipTo_Attention.TextColor = UIColor.White;
            ShipTo_Attention.BackgroundColor = UIColor.Black;
            ShipTo_Attention.Font = UIFont.FromName(Constants.strFontName, 14.0f);
            ShipTo_Attention.TextAlignment = UITextAlignment.Center;

            XPosition += ShipTo_Attention.Frame.Width + marginBtwCol;

            UILabel ShipTo_Company = new UILabel(new CGRect(XPosition, 1, 171, 50));
            ShipTo_Company.Text = "Ship to Company";//             "+ "Select All"
            ShipTo_Company.TextColor = UIColor.White;
            ShipTo_Company.BackgroundColor = UIColor.Black;
            ShipTo_Company.Font = UIFont.FromName(Constants.strFontName, 14.0f);
            ShipTo_Company.TextAlignment = UITextAlignment.Center;
            ShipTo_Company.LineBreakMode = UILineBreakMode.WordWrap;

            XPosition += ShipTo_Company.Frame.Width;

            btnCheck.TouchUpInside += delegate
            {
                SelectDeSelectAllOrders(btnCheck, tableView);
            };
            if (!isChecked)
            {
                btnCheck.SetBackgroundImage(null, UIControlState.Normal);
            }
            else
            {
                btnCheck.SetBackgroundImage(new UIImage("Images/CheckMark.png"), UIControlState.Normal);
            }
            //viewSelectAll.AddSubviews(btnCheck, lblSelecAllText);
            viewHistoryResultHeader.AddSubviews(lblSelecAllText, btnCheck,OrderID,StoreID, Status, OrderDate, ShipTo_Attention, ShipTo_Company);//(lblSelecAllText,btnCheck) 

            //tableView.Frame = new CGRect(0, 0, XPosition, lstRateHistoryResult.Count * 47);

            viewHistoryResultHeader.Frame = new CGRect(0, 0, tableView.Frame.Width, 50);


            viewHistoryResultHeader.BackgroundColor = UIColor.White;
            UIView viewDivider1 = new UIView();
            viewDivider1.Frame = new CGRect(0, viewHistoryResultHeader.Frame.Height - 2, XPosition, 3);
            viewDivider1.BackgroundColor = UIColor.White;
            viewHistoryResultHeader.AddSubview(viewDivider1);
            return viewHistoryResultHeader;
        }

        bool isChecked = false;
        void SelectDeSelectAllOrders(UIButton btnSelectAll, UITableView uITableView)
        {
            try
            {
                if (!isChecked)
                {
                    isChecked = true;
                }
                else
                {
                    isChecked = false;
                }
                lstRateHistoryResult.ForEach(x => x.isCheckBoxChecked = isChecked);
                uITableView.ReloadData();
            }
            catch
            {
                throw;
            }
        }

        public override nfloat GetHeightForHeader(UITableView tableView, nint section)
        {
            return 47;
        }

        public override void RowSelected(UITableView tableView, NSIndexPath indexPath)
        {

            //string compareKey = lstRateHistoryResult[indexPath.Row].ClientID + "|" + lstRateHistoryResult[indexPath.Row].LoadNum + "|" + ConstantsClass.strHistory;
            //objHistoryResultController.SegueFromHistoryToShipmentDetail(compareKey);
        }
    }
}

