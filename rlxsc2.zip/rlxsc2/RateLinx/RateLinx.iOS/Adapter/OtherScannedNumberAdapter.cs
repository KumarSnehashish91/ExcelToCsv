using System;
using System.Collections.Generic;
using CoreGraphics;
using Foundation;
using RateLinx.Helper;
using UIKit;

namespace RateLinx.iOS
{
	class OtherScannedNumberAdapter : UITableViewSource
	{

		#region Variable Declaration

		List<string> lstOtherScannedNos;

		#endregion
		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.OtherScannedNumberAdapter"/> class.
		/// </summary>
		/// <param name="lstOtherScannedNos">Lst other scanned nos.</param>
		public OtherScannedNumberAdapter(List<string> lstOtherScannedNos)
		{
			this.lstOtherScannedNos = lstOtherScannedNos;
		}
		/// <summary>
		/// Gets the cell.
		/// </summary>
		/// <returns>The cell.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			try
			{
				UITableViewCell cellScannedNo = new UITableViewCell(new CGRect(0, 0, tableView.Frame.Width, 25));

				UILabel lblScannedNo = new UILabel(new CGRect(0, 0, 170, 25));

				lblScannedNo.Text = lstOtherScannedNos[indexPath.Row];

				UIButton btnDeleteNo = new UIButton(new CGRect(200, 0, 20, 20));
				btnDeleteNo.SetTitle(NSBundle.MainBundle.LocalizedString("croxSign", null), UIControlState.Normal);
				btnDeleteNo.SetTitleColor(Constants.btnColorRed, UIControlState.Normal);
				btnDeleteNo.UserInteractionEnabled = true;
				btnDeleteNo.Tag = indexPath.Row;

				btnDeleteNo.TouchUpInside += delegate
				{
					MaintainOtherScannedBarcode(btnDeleteNo.Tag, tableView);
				};


				cellScannedNo.AddSubviews(lblScannedNo, btnDeleteNo);


				return cellScannedNo;
			}
			catch
			{
				throw;
			}
		}
		/// <summary>
		/// Maintains the other scanned barcode.
		/// </summary>
		/// <param name="tag">Tag.</param>
		/// <param name="tableView">Table view.</param>
		void MaintainOtherScannedBarcode(nint tag, UITableView tableView)
		{
			lstOtherScannedNos.RemoveAt(Convert.ToInt32(tag));

			if (lstOtherScannedNos.Count == 0)
			{
				tableView.Hidden = true;
			}

			tableView.Source = new OtherScannedNumberAdapter(lstOtherScannedNos);
			tableView.ReloadData();

		}
		/// <summary>
		/// Rowses the in section.
		/// </summary>
		/// <returns>The in section.</returns>
		/// <param name="tableview">Tableview.</param>
		/// <param name="section">Section.</param>
		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return lstOtherScannedNos.Count;
		}
	}
}