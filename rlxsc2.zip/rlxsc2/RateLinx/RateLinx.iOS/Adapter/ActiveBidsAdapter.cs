using System;
using System.Collections.Generic;
using CoreGraphics;
using Foundation;
using RateLinx.Helper;
using RateLinx.Models;
using UIKit;

namespace RateLinx.iOS
{
	class ActiveBidsAdapter : UITableViewSource
	{
		List<Bid> bids;

		public ActiveBidsAdapter(List<Bid> bids)
		{
			this.bids = bids;
		}

		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			UITableViewCell cellActiveBid = new UITableViewCell(new CGRect(0, 0, tableView.Frame.Width, 25));

			UIColor objColorCode = null;

			if (indexPath.Row % 2 == 0)
			{
				objColorCode = UIColor.FromRGB(224, 223, 223);
			}
			else
			{
				objColorCode = UIColor.FromRGB(240, 239, 239);
			}

			cellActiveBid.BackgroundColor = objColorCode;

			UILabel lblCarrier = new UILabel(new CGRect(0, 0, tableView.Frame.Width / 4, 25));
			lblCarrier.Font = UIFont.FromName(Constants.strFontName, 13f);
			lblCarrier.TextColor = UIColor.Black;
			lblCarrier.TextAlignment = UITextAlignment.Center;
			lblCarrier.Text = bids[indexPath.Row].Carrier;

			UILabel lblPrice = new UILabel(new CGRect(tableView.Frame.Width / 4, 0, tableView.Frame.Width / 4, 25));
			lblPrice.Font = UIFont.FromName(Constants.strFontName, 13f);
			lblPrice.TextColor = UIColor.Black;
			lblPrice.TextAlignment = UITextAlignment.Center;
			lblPrice.Text = Convert.ToString(bids[indexPath.Row].Price);

			UILabel lblAlternate = new UILabel(new CGRect(tableView.Frame.Width / 4 * 2, 0, tableView.Frame.Width / 4, 25));
			lblAlternate.Font = UIFont.FromName(Constants.strFontName, 13f);
			lblAlternate.TextColor = UIColor.Black;
			lblAlternate.TextAlignment = UITextAlignment.Center;
			lblAlternate.Text = Convert.ToString(bids[indexPath.Row].AltTerms);

			UILabel lblStatus = new UILabel(new CGRect(tableView.Frame.Width / 4 * 3, 0, tableView.Frame.Width / 4, 25));
			lblStatus.Font = UIFont.FromName(Constants.strFontName, 13f);
			lblStatus.TextColor = UIColor.Black;
			lblStatus.TextAlignment = UITextAlignment.Center;
			lblStatus.Text = bids[indexPath.Row].Status;

			cellActiveBid.AddSubviews(lblCarrier, lblPrice, lblAlternate, lblStatus);


			return cellActiveBid;
		}

		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return bids.Count;
		}
	}
}