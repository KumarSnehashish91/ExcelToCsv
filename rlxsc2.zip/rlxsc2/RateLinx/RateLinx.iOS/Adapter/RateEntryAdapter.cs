using System;
using System.Collections.Generic;
using CoreGraphics;
using Foundation;
using RateLinx.Models;
using UIKit;

namespace RateLinx.iOS
{
	class RateEntryAdapter : UITableViewSource
	{
		#region Variable Declaration

		UITableView objTableView;
		static nint tabCount = -1;
		static bool isExpanded = false;

		#endregion


		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.RateEntryAdapter"/> class.
		/// </summary>
		/// <param name="entries">Entries.</param>
		/// <param name="view">View.</param>
		/// <param name="xCordinate">X cordinate.</param>
		public RateEntryAdapter(List<Entry> entries, UIView view, nfloat xCordinate)
		{

		}
		/// <summary>
		/// Gets the cell.
		/// </summary>
		/// <returns>The cell.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			try
			{
				UITableViewCell objTableCell = new UITableViewCell(new CGRect(0, 0, tableView.Frame.Width, 150));
				objTableView = tableView;
				UIView viewRateEntry = new UIView();
				viewRateEntry.Frame = objTableCell.Bounds;
				viewRateEntry.BackgroundColor = UIColor.Black;
				objTableCell.AddSubview(viewRateEntry);
				return objTableCell;
			}
			catch
			{
				throw;
			}
		}
		/// <summary>
		/// Rowses the in section.
		/// </summary>
		/// <returns>The in section.</returns>
		/// <param name="tableview">Tableview.</param>
		/// <param name="section">Section.</param>
		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return 1;
		}
		/// <summary>
		/// Numbers the of sections.
		/// </summary>
		/// <returns>The of sections.</returns>
		/// <param name="tableView">Table view.</param>
		public override nint NumberOfSections(UITableView tableView)
		{
			return 3;
		}
		/// <summary>
		/// Estimateds the height for header.
		/// </summary>
		/// <returns>The height for header.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="section">Section.</param>
		public override nfloat EstimatedHeightForHeader(UITableView tableView, nint section)
		{
			return 30;
		}
		/// <summary>
		/// Estimateds the height for footer.
		/// </summary>
		/// <returns>The height for footer.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="section">Section.</param>
		public override nfloat EstimatedHeightForFooter(UITableView tableView, nint section)
		{
			return 2;
		}
		/// <summary>
		/// Gets the height for row.
		/// </summary>
		/// <returns>The height for row.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override nfloat GetHeightForRow(UITableView tableView, NSIndexPath indexPath )
		{
			if (indexPath.Section == tabCount)
			{
				if (isExpanded == false)
				{
					isExpanded = true;
					return 150;
				}
				else
				{
					isExpanded = false;
					return 0;
				}
			}
			else
			{
				return 0;
			}
		}
		/// <summary>
		/// Gets the view for footer.
		/// </summary>
		/// <returns>The view for footer.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="section">Section.</param>
		public override UIView GetViewForFooter(UITableView tableView, nint section)
		{
			UIView objUIView = new UIView(new CoreGraphics.CGRect(0, 0, tableView.Frame.Width, 2));
			objUIView.BackgroundColor = UIColor.White;
			return objUIView;
		}
		/// <summary>
		/// Gets the view for header.
		/// </summary>
		/// <returns>The view for header.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="section">Section.</param>
		public override UIView GetViewForHeader(UITableView tableView, nint section )
		{
			
			UIView viewHeader = new UIView(new CGRect(0, 0, tableView.Frame.Width, 30));
			viewHeader.BackgroundColor = UIColor.Red;
			UIButton objButton = new UIButton(new CGRect(10, 5, 100, 20));
			objButton.SetTitle(NSBundle.MainBundle.LocalizedString("details", null), UIControlState.Normal);
			objButton.BackgroundColor = UIColor.White;
			objButton.SetTitleColor(UIColor.Black, UIControlState.Normal);
			objButton.UserInteractionEnabled = true;
			objButton.Tag = section;
			objButton.TouchUpInside +=delegate {
				ExpandSection(objButton.Tag);
			};

			viewHeader.AddSubview(objButton);

			viewHeader.Tag = section;
			return viewHeader;
		}
		/// <summary>
		/// Shows the details.
		/// </summary>
		/// <param name="tag">Tag.</param>
		void ShowDetails(nint tag)
		{
			//throw new NotImplementedException();
		}
		/// <summary>
		/// Expands the section.
		/// </summary>
		/// <param name="headerCount">Header count.</param>
		public void ExpandSection(nint headerCount)
		{
			tabCount = headerCount;

			objTableView.BeginUpdates();
			objTableView.EndUpdates();
		}
	}
}