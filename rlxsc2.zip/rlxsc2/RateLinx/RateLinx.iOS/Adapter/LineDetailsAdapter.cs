using System;
using System.Collections.Generic;
using CoreGraphics;
using Foundation;
using RateLinx.Helper;
using RateLinx.Models;
using UIKit;

namespace RateLinx.iOS
{
	class LineDetailsAdapter : UITableViewSource
	{

		#region Variable Declaration

		List<LineDetail> lstLineDetails;

		#endregion


		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.LineDetailsAdapter"/> class.
		/// </summary>
		/// <param name="lstLineDetails">Lst line details.</param>
		public LineDetailsAdapter(List<LineDetail> lstLineDetails)
		{
			this.lstLineDetails = lstLineDetails;
		}

		/// <summary>
		/// Rowses the in section.
		/// </summary>
		/// <returns>The in section.</returns>
		/// <param name="tableview">Tableview.</param>
		/// <param name="section">Section.</param>
		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return lstLineDetails.Count;
		}

		/// <summary>
		/// Gets the cell.
		/// </summary>
		/// <returns>The cell.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			try
			{

				nfloat xCordinate = 0;
				UIColor altColor = null;
				UITableViewCell objLineDetailCell = new UITableViewCell(new CGRect(0, 0, tableView.Frame.Width, 25));

				UIView viewLineDetail = new UIView(new CGRect(0, 0, objLineDetailCell.Frame.Width, 25));

				//objLineDetailCell.BackgroundColor = UIColor.Red;

				objLineDetailCell.AddSubview(viewLineDetail);


				Dictionary<string, object> dictionaryLineDetail = new Dictionary<string, object>();
				foreach (var prop in lstLineDetails[indexPath.Row].GetType().GetProperties())
				{
					Console.WriteLine("{0} = {1}", prop.Name, prop.GetValue(lstLineDetails[indexPath.Row], null));

					dictionaryLineDetail.Add(prop.Name, prop.GetValue(lstLineDetails[indexPath.Row], null));
				}
				if (indexPath.Row % 2 == 0)
				{
					altColor = Constants.tableRowOddColor;
				}
				else
				{
					altColor = UIColor.LightGray;
				}
				//xCordinate
				foreach (KeyValuePair<string, object> kvpLineDetail in dictionaryLineDetail)
				{
					if (kvpLineDetail.Key.Equals(NSBundle.MainBundle.GetLocalizedString("lineNum",null)))
					{
						UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 25));
						objLabel.BackgroundColor = altColor;
						objLabel.Text = Convert.ToString(lstLineDetails[indexPath.Row].LineNum);
						objLabel.TextColor = UIColor.Black;
						objLabel.TextAlignment = UITextAlignment.Center;
						objLabel.Font = UIFont.FromName(Constants.strFontName, 12f);
						viewLineDetail.AddSubview(objLabel);
						xCordinate = objLabel.Frame.X + 101;
					}
                    else if (kvpLineDetail.Key.Equals(NSBundle.MainBundle.GetLocalizedString("pallets",null)))
					{
						UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 25));
						objLabel.BackgroundColor = altColor;
						objLabel.Text = Convert.ToString(lstLineDetails[indexPath.Row].Pallets);
						objLabel.TextColor = UIColor.Black;
						objLabel.TextAlignment = UITextAlignment.Center;
						objLabel.Font = UIFont.FromName(Constants.strFontName, 12f);
						viewLineDetail.AddSubview(objLabel);
						xCordinate = objLabel.Frame.X + 101;
					}
                    else if (kvpLineDetail.Key.Equals(NSBundle.MainBundle.GetLocalizedString("pieces",null)))
					{
						UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 25));
						objLabel.BackgroundColor = altColor;
						objLabel.Text = Convert.ToString(lstLineDetails[indexPath.Row].Pieces);
						objLabel.TextColor = UIColor.Black;
						objLabel.TextAlignment = UITextAlignment.Center;
						objLabel.Font = UIFont.FromName(Constants.strFontName, 12f);
						viewLineDetail.AddSubview(objLabel);
						xCordinate = objLabel.Frame.X + 101;
					}
                    else if (kvpLineDetail.Key.Equals(NSBundle.MainBundle.GetLocalizedString("UOM",null)))
					{
						UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 25));
						objLabel.BackgroundColor = altColor;
						objLabel.Text = lstLineDetails[indexPath.Row].UOM;
						objLabel.TextColor = UIColor.Black;
						objLabel.TextAlignment = UITextAlignment.Center;
						objLabel.Font = UIFont.FromName(Constants.strFontName, 12f);
						viewLineDetail.AddSubview(objLabel);
						xCordinate = objLabel.Frame.X + 101;
					}
                    else if (kvpLineDetail.Key.Equals(NSBundle.MainBundle.GetLocalizedString("item",null)))
					{
						UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 25));
						objLabel.BackgroundColor = altColor;
						objLabel.Text = lstLineDetails[indexPath.Row].Item;
						objLabel.TextColor = UIColor.Black;
						objLabel.TextAlignment = UITextAlignment.Center;
						objLabel.Font = UIFont.FromName(Constants.strFontName, 12f);
						viewLineDetail.AddSubview(objLabel);
						xCordinate = objLabel.Frame.X + 101;
					}
                    else if (kvpLineDetail.Key.Equals(NSBundle.MainBundle.GetLocalizedString("descr",null)))
					{
						UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 25));
						objLabel.BackgroundColor = altColor;
						objLabel.Text = lstLineDetails[indexPath.Row].Descr;
						objLabel.TextColor = UIColor.Black;
						objLabel.TextAlignment = UITextAlignment.Center;
						objLabel.Font = UIFont.FromName(Constants.strFontName, 12f);
						viewLineDetail.AddSubview(objLabel);
						xCordinate = objLabel.Frame.X + 101;
					}
                    else if (kvpLineDetail.Key.Equals(NSBundle.MainBundle.GetLocalizedString("length",null)))
					{
						UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 25));
						objLabel.BackgroundColor = altColor;
						objLabel.Text = Convert.ToString(lstLineDetails[indexPath.Row].Length) +" x "
							+Convert.ToString(lstLineDetails[indexPath.Row].Width) +" x "
							+Convert.ToString(lstLineDetails[indexPath.Row].Height);
						objLabel.TextColor = UIColor.Black;
						objLabel.TextAlignment = UITextAlignment.Center;
						objLabel.Font = UIFont.FromName(Constants.strFontName, 12f);
						viewLineDetail.AddSubview(objLabel);
						xCordinate = objLabel.Frame.X + 101;
					}
                    else if (kvpLineDetail.Key.Equals(NSBundle.MainBundle.GetLocalizedString("strClass",null)))
					{
						UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 25));
						objLabel.BackgroundColor = altColor;
						objLabel.Text = Convert.ToString(lstLineDetails[indexPath.Row].Class);
						objLabel.TextColor = UIColor.Black;
						objLabel.TextAlignment = UITextAlignment.Center;
						objLabel.Font = UIFont.FromName(Constants.strFontName, 12f);
						viewLineDetail.AddSubview(objLabel);
						xCordinate = objLabel.Frame.X + 101;
					}
                    else if (kvpLineDetail.Key.Equals(NSBundle.MainBundle.GetLocalizedString("FAK",null)))
					{
						UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 25));
						objLabel.BackgroundColor = altColor;
						objLabel.Text = lstLineDetails[indexPath.Row].FAK;
						objLabel.TextColor = UIColor.Black;
						objLabel.TextAlignment = UITextAlignment.Center;
						objLabel.Font = UIFont.FromName(Constants.strFontName, 12f);
						viewLineDetail.AddSubview(objLabel);
						xCordinate = objLabel.Frame.X + 101;
					}
                    else if (kvpLineDetail.Key.Equals(NSBundle.MainBundle.GetLocalizedString("weight",null)))
					{
						UILabel objLabel = new UILabel(new CoreGraphics.CGRect(xCordinate, 0, 100, 25));
						objLabel.BackgroundColor = altColor;
                        objLabel.Text = Convert.ToString(Math.Round(Convert.ToDecimal(lstLineDetails[indexPath.Row].Weight), 2));
						objLabel.TextColor = UIColor.Black;
						objLabel.TextAlignment = UITextAlignment.Center;
						objLabel.Font = UIFont.FromName(Constants.strFontName, 12f);
						viewLineDetail.AddSubview(objLabel);
						xCordinate = objLabel.Frame.X + 101;
					}
				}
				return objLineDetailCell;
			}
			catch
			{
				throw;
			}
		}


	}
}