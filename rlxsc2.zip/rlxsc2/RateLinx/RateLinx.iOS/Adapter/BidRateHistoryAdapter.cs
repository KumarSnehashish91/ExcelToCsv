using System;
using System.Collections.Generic;
using CoreGraphics;
using Foundation;
using RateLinx.Helper;
using RateLinx.Models;
using UIKit;

namespace RateLinx.iOS
{
	class BidRateHistoryAdapter : UITableViewSource
	{

		#region Variable Declaration

		List<OldEntry> entries;


		#endregion
		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.BidRateHistoryAdapter"/> class.
		/// </summary>
		/// <param name="entries">Entries.</param>
		public BidRateHistoryAdapter(List<OldEntry> entries)
		{
			this.entries = entries;
		}
		/// <summary>
		/// Gets the cell.
		/// </summary>
		/// <returns>The cell.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			try
			{
				UIColor altColor = null;
				if (indexPath.Row % 2 == 0)
				{
					altColor = Constants.tableRowOddColor;
				}
				else
				{
					altColor = UIColor.LightGray;
				}

				UITableViewCell bidRateHistoryCell = new UITableViewCell(new CGRect(0, 0, tableView.Frame.Width, 30));
				bidRateHistoryCell.BackgroundColor = altColor;


				UILabel lblCarrier = new UILabel(new CGRect(5, 0, tableView.Frame.Width / 10 * 2.5-5, 30));
				if (entries[indexPath.Row].Status.ToUpper() == "BID" || entries[indexPath.Row].Status.ToUpper() == "CONFIRMED")
				{
					lblCarrier.Font = UIFont.FromName("Helvetica-Bold", 12f);
				}
				else
				{
					lblCarrier.Font = UIFont.FromName(Constants.strFontName, 12f);
				}
				lblCarrier.TextAlignment = UITextAlignment.Left;
				lblCarrier.Text = entries[indexPath.Row].SCAC;
				lblCarrier.TextColor = UIColor.Black;


				UILabel lblAmount = new UILabel(new CGRect(tableView.Frame.Width / 10 * 2.5 + 6, 0, tableView.Frame.Width / 10 * 2.5-5, 30));

				if (entries[indexPath.Row].Status.ToUpper() == "BID" || entries[indexPath.Row].Status.ToUpper() == "CONFIRMED")
				{

					lblAmount.Font = UIFont.FromName("Helvetica-Bold", 12f);
				}
				else
				{
					lblAmount.Font = UIFont.FromName(Constants.strFontName, 12f);
				}

				lblAmount.TextAlignment = UITextAlignment.Left;
				lblAmount.Text = "$" + Convert.ToString(entries[indexPath.Row].Price);
				lblAmount.TextColor = UIColor.Black;


				UILabel lblDateEntered = new UILabel(new CGRect(lblAmount.Frame.X + lblAmount.Frame.Width + 6, 0, tableView.Frame.Width / 10 * 5 - 7, 30));

				if (entries[indexPath.Row].Status.ToUpper() == "BID" || entries[indexPath.Row].Status.ToUpper() == "CONFIRMED")
				{

					lblDateEntered.Font = UIFont.FromName("Helvetica-Bold", 12f);
				}
				else
				{
					lblDateEntered.Font = UIFont.FromName(Constants.strFontName, 12f);
				}

				lblDateEntered.TextAlignment = UITextAlignment.Left;
				lblDateEntered.Text = entries[indexPath.Row].EnteredOnStr;
				lblDateEntered.TextColor = UIColor.Black;


				bidRateHistoryCell.AddSubviews(lblCarrier, lblAmount, lblDateEntered);



				return bidRateHistoryCell;
			}
			catch
			{
				throw;
			}
		}
		/// <summary>
		/// Rowses the in section.
		/// </summary>
		/// <returns>The in section.</returns>
		/// <param name="tableview">Tableview.</param>
		/// <param name="section">Section.</param>
		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return entries.Count;
		}
		/// <summary>
		/// Gets the height for row.
		/// </summary>
		/// <returns>The height for row.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override nfloat GetHeightForRow(UITableView tableView, NSIndexPath indexPath)
		{
			return 30;
		}
	}
}