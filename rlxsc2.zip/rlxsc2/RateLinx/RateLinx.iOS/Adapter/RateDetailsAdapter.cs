using System;
using Foundation;
using UIKit;
using System.Collections.Generic;
using RateLinx.Models;
using CoreGraphics;
using RateLinx.Helper;
using System.Linq;

namespace RateLinx.iOS
{
	public class RateDetailsAdapter : UITableViewSource
	{
		#region Variable Declaration
		UITapGestureRecognizer tapGestureSection1, tapGestureSection2, tapGestureSection3, tapGestureSection4, tapGestureSection5, tapGestureSection6, tapGestureCommodities;
		CarrierShipmentDetails objCarrierShipmentDetails;
		UITableView objTableView;
		bool forConfirmation = false;
		List<Entry> entries = null;
		ShipmentDetailController objShipmentDetailController;

		bool isRateSection, isAddressSection, isDetailsLineSection, isOptionsSection, isConfirmationSection, isAssignDriverSection, isCommoditiesSection = false;

		UIView viewTruckloadRequest, viewAddress, viewLineDetails, viewOptions, viewCommodities, viewConfirmation, viewForCarrier = null;

		bool isExpanded = false;

		#endregion

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.RateDetailsAdapter"/> class.
		/// </summary>
		/// <param name="objCarrierShipmentDetails">Object carrier shipment details.</param>
		/// <param name="shipmentDetailController">Shipment detail controller.</param>
		public RateDetailsAdapter(CarrierShipmentDetails objCarrierShipmentDetails,ShipmentDetailController shipmentDetailController)
		{
			this.objCarrierShipmentDetails = objCarrierShipmentDetails;
			objShipmentDetailController = shipmentDetailController;
			viewCommodities = new UIView();

			viewTruckloadRequest = new UIView();
			viewAddress = new UIView();
			viewLineDetails  = new UIView();
			viewOptions = new UIView();
			viewCommodities  = new UIView();
			viewConfirmation = new UIView();
			viewForCarrier = new UIView();

		}
		/// <summary>
		/// Gets the cell.
		/// </summary>
		/// <returns>The cell.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			try
			{
				objTableView = tableView;

				if (indexPath.Section == 0)
				{
					RateDetailsCell rateDetailsCell = (RateDetailsCell)tableView.DequeueReusableCell("RateDetailIdentifier", indexPath);
					rateDetailsCell.Frame = new CGRect(0, 0, tableView.Frame.Width, 550);
					rateDetailsCell.UpdateCell(indexPath.Section, objCarrierShipmentDetails, objShipmentDetailController, tableView);
					return rateDetailsCell;
				}
				else if (indexPath.Section == 1)
				{
					RateDetailsAddressCell rateDetailsAddressCell = (RateDetailsAddressCell)tableView.DequeueReusableCell("RateDetailsAddressCell", indexPath);
					rateDetailsAddressCell.UpdateCell(objCarrierShipmentDetails, objShipmentDetailController, tableView);
					rateDetailsAddressCell.TextLabel.Font = UIFont.FromName(Constants.strFontName, 11.0f);
					return rateDetailsAddressCell;
				}
				else if (indexPath.Section == 2)
				{
					RateDetailLineCell rateDetailLineCell = (RateDetailLineCell)tableView.DequeueReusableCell("RateDetailLineCell", indexPath);
					rateDetailLineCell.UpdateCell(objCarrierShipmentDetails, tableView);
					rateDetailLineCell.TextLabel.Font = UIFont.FromName(Constants.strFontName, 11.0f);
					return rateDetailLineCell;
				}
				else if (indexPath.Section == 3)
				{
					CommoditiesCell commoditiesCell = (CommoditiesCell)tableView.DequeueReusableCell("CommoditiesCell", indexPath);
					commoditiesCell.UpdateCell(objCarrierShipmentDetails);
					commoditiesCell.TextLabel.Font = UIFont.FromName(Constants.strFontName, 11.0f);
					return commoditiesCell;
				}
				else if (indexPath.Section == 4)
				{
					RateDetailOptionsCell rateDetailOptionsCell = (RateDetailOptionsCell)tableView.DequeueReusableCell("RateDetailOptionsCell", indexPath);
					rateDetailOptionsCell.UpdateCell(objCarrierShipmentDetails, tableView);
					rateDetailOptionsCell.TextLabel.Font = UIFont.FromName(Constants.strFontName, 11.0f);
					return rateDetailOptionsCell;
				}
				else if (indexPath.Section == 5)
				{
					ConfirmationCell confirmationCell = (ConfirmationCell)tableView.DequeueReusableCell("ConfirmationCell", indexPath);
					confirmationCell.UpdateCell(objCarrierShipmentDetails, objShipmentDetailController , tableView);
					confirmationCell.TextLabel.Font = UIFont.FromName(Constants.strFontName, 11.0f);
					return confirmationCell;
				}
				else if (indexPath.Section == 6)
				{
					AssignDriverCell assignDriverCell = (AssignDriverCell)tableView.DequeueReusableCell("AssignDriverCell", indexPath);
					assignDriverCell.UpdateCell(objCarrierShipmentDetails, objShipmentDetailController, tableView);
					assignDriverCell.TextLabel.Font = UIFont.FromName(Constants.strFontName, 11.0f);
					return assignDriverCell;

				}
				else
				{
					return null;
				}
			}
			catch
			{
				//Console.Write(Constants.strErrorOccured);
				return null;

			}
		}
		/// <summary>
		/// Rowses the in section.
		/// </summary>
		/// <returns>The in section.</returns>
		/// <param name="tableview">Tableview.</param>
		/// <param name="section">Section.</param>
		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return 1;
		}

		/// <summary>
		/// Numbers the of sections.
		/// </summary>
		/// <returns>The of sections.</returns>
		/// <param name="tableView">Table view.</param>
		public override nint NumberOfSections(UITableView tableView)
		{
			return 7;
		}

		/// <summary>
		/// Estimateds the height for header.
		/// </summary>
		/// <returns>The height for header.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="section">Section.</param>
		public override nfloat EstimatedHeightForHeader(UITableView tableView, nint section)
		{
			if (section == 3)
			{
				if (objCarrierShipmentDetails!=null && objCarrierShipmentDetails.Contents != null && objCarrierShipmentDetails.Contents.Count > 0)
				{
					return 75;
				}
				else
				{
					return 0;
				}
			}
			else if (section == 6)
			{
				if (objCarrierShipmentDetails!=null && objCarrierShipmentDetails.CanAssignDriver && objCarrierShipmentDetails.ViewAs.ToUpper() == Constants.strCarrier.ToUpper())
				{
					return 0;
				}
				else
				{
					return 0;
				}

			}
			else if (section == 5)
			{
				if (objCarrierShipmentDetails!=null && objCarrierShipmentDetails.Status.ToUpper() == Constants.strClosed.ToUpper())
				{
					entries = new List<Entry>();
					entries = objCarrierShipmentDetails.Entries;
					forConfirmation = entries.Count(entry => entry.Status == Constants.strCONFIRMED) > 0;
				}
				if (forConfirmation)
				{
					return 75;
				}
				else
				{
					return 0;
				}
			}
			else
			{
				return 75;
			}
		}

		/// <summary>
		/// Estimateds the height for footer.
		/// </summary>
		/// <returns>The height for footer.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="section">Section.</param>
		public override nfloat EstimatedHeightForFooter(UITableView tableView, nint section)
		{
			if (section == 3)
			{
				if (objCarrierShipmentDetails!=null && objCarrierShipmentDetails.Contents !=null && objCarrierShipmentDetails.Contents.Count > 0)
				{
					return 2;
				}
				else
				{
					return 0;
				}
			}
			else if (section == 6)
			{
				if (objCarrierShipmentDetails!=null && objCarrierShipmentDetails.ViewAs.ToUpper() != Constants.strCustomer.ToUpper() && objCarrierShipmentDetails.CanAssignDriver)
				{
					return 2;
				}
				else
				{
					return 0;
				}

			}
			else if (section == 5)
			{
				if (objCarrierShipmentDetails!=null && objCarrierShipmentDetails.Status.ToUpper() == Constants.strClosed.ToUpper())
				{
					entries = new List<Entry>();
					entries = objCarrierShipmentDetails.Entries;
					forConfirmation = entries.Count(entry => entry.Status == "CONFIRMED") > 0;
				}
				if (forConfirmation)
				{
					return 2;
				}
				else
				{
					return 0;
				}
			}
			else
			{
				return 2;				
			}
		}

		/// <summary>
		/// Gets the height for row.
		/// </summary>
		/// <returns>The height for row.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override nfloat GetHeightForRow(UITableView tableView, NSIndexPath indexPath)
		{
			try
			{
				nfloat rowHeightTruckload = 390;
				if (indexPath.Section == 0 && isRateSection == true)
				{
					if (isExpanded == false)
					{
						viewTruckloadRequest.BackgroundColor = Constants.separatorClr;
						isExpanded = true;

						if (objCarrierShipmentDetails.StartingPrice > 0)
						{
							rowHeightTruckload += 30;
						}
						if (objCarrierShipmentDetails.ViewAs == Constants.strCustomer)
						{
							rowHeightTruckload += 30;
						}
						if (!string.IsNullOrEmpty(objCarrierShipmentDetails.InvoiceCreatedOn))
						{
							rowHeightTruckload += 30;
						}
						if (!string.IsNullOrEmpty(objCarrierShipmentDetails.InvoiceCreatedOn))
						{
							rowHeightTruckload += 30;
						}
						if (CommanUtil.isShowCharges)
						{
							if (objCarrierShipmentDetails.LowestPrice > 0)
							{
								rowHeightTruckload += 60;
							}
						}
						if (!string.IsNullOrEmpty(objCarrierShipmentDetails.SCACStatement))
						{
							rowHeightTruckload += 30;
						}
						if (objCarrierShipmentDetails.ViewAs.ToUpper() == Constants.strCustomer.ToUpper() && objCarrierShipmentDetails.CanVoid)
						{
							rowHeightTruckload += 50;
						}
						else
						{
							rowHeightTruckload += 20;
						}

						return rowHeightTruckload;
					}
					else
					{
						viewTruckloadRequest.BackgroundColor = Constants.conversationHeadClr;
						isExpanded = false;
						return 0;
					}

				}
				else if (indexPath.Section == 1 && isAddressSection == true)
				{
					if (isExpanded == false)
					{
						viewAddress.BackgroundColor = Constants.separatorClr;
						isExpanded = true;
						return 225;
					}
					else
					{
						viewAddress.BackgroundColor = Constants.conversationHeadClr;
						isExpanded = false;
						return 0;
					}

				}
				else if (indexPath.Section == 2 && isDetailsLineSection == true)
				{
					if (isExpanded == false)
					{
						viewLineDetails.BackgroundColor = Constants.separatorClr;
						isExpanded = true;


						return (objCarrierShipmentDetails.LineDetails.Count * 25 + 20);
					}
					else
					{
						viewLineDetails.BackgroundColor = Constants.conversationHeadClr;
						isExpanded = false;
						return 0;
					}

				}
				else if (indexPath.Section == 3 && isCommoditiesSection == true)
				{
					if (isExpanded == false)
					{
						viewCommodities.BackgroundColor = Constants.separatorClr;
						isExpanded = true;
						nfloat rowHeight = 50;
						if (objCarrierShipmentDetails.Contents != null && objCarrierShipmentDetails.Contents.Count > 0)
						{
							rowHeight += objCarrierShipmentDetails.Contents.Count * 25;
						}

						return rowHeight;
					}
					else
					{
						viewCommodities.BackgroundColor = Constants.conversationHeadClr;
						isExpanded = false;
						return 0;
					}

				}
				else if (indexPath.Section == 4 && isOptionsSection == true)
				{
					//lstUIViews[3].BackgroundColor = UIColor.Red;
					if (isExpanded == false)
					{
						viewOptions.BackgroundColor = Constants.separatorClr;
						isExpanded = true;
						return (objCarrierShipmentDetails.SSes.Count * 25 + 1);

						//return 200;
					}
					else
					{
						viewOptions.BackgroundColor = Constants.conversationHeadClr;
						isExpanded = false;
						return 0;
					}
				}
				else if (indexPath.Section == 5 && isConfirmationSection == true)
				{
					//lstUIViews[3].BackgroundColor = UIColor.Red;
					if (isExpanded == false)
					{
						viewConfirmation.BackgroundColor = Constants.separatorClr;
						isExpanded = true;
                        //if(objCarrierShipmentDetails.DispatchFlag && string.IsNullOrEmpty(objCarrierShipmentDetails.DriverID))
                        //{
                        //    return 40;
                        //}
                        //else
                        //{
                        //    return 80;
                        //}
                        return 80;
						//return 200;
					}
					else
					{
						viewConfirmation.BackgroundColor = Constants.conversationHeadClr;
						isExpanded = false;
						return 0;
					}
				}
				else if (indexPath.Section == 6 && isAssignDriverSection == true)
				{
					//lstUIViews[3].BackgroundColor = UIColor.Red;
					if (isExpanded == false)
					{
						viewForCarrier.BackgroundColor = Constants.separatorClr;
						isExpanded = true;
						return 50; ;

						//return 200;
					}
					else
					{
						viewForCarrier.BackgroundColor = Constants.conversationHeadClr;
						isExpanded = false;
						return 0;
					}
				}
				else
				{
					return 0;
				}
			}
			catch
			{
				throw;
			}
			//return 150;
		}
		public override UIView GetViewForFooter(UITableView tableView, nint section)
		{
			UIView objUIView = new UIView(new CoreGraphics.CGRect(0, 0, tableView.Frame.Width, 4));
			objUIView.BackgroundColor = UIColor.White;
			return objUIView;
		}
		public override UIView GetViewForHeader(UITableView tableView, nint section)
		{
			try
			{
				//UIView objUIView = null;
				if (section == 0)
				{
					viewTruckloadRequest = new UIView(new CoreGraphics.CGRect(0, 0, tableView.Frame.Width, 75));
					viewTruckloadRequest.BackgroundColor = Constants.conversationHeadClr;
					viewTruckloadRequest.Tag = section;

					UILabel lblRequest = new UILabel(new CoreGraphics.CGRect(10, 5, viewTruckloadRequest.Frame.Width - 60, 15));
					UILabel lblLowestPrice = new UILabel(new CoreGraphics.CGRect(10, lblRequest.Frame.Y + 20, viewTruckloadRequest.Frame.Width - 60, 15));
					UILabel lblPickupOn = new UILabel(new CoreGraphics.CGRect(10, lblLowestPrice.Frame.Y + 20, viewTruckloadRequest.Frame.Width - 60, 15));

					lblRequest.TextColor = UIColor.White;
					lblLowestPrice.TextColor = UIColor.White;
					lblPickupOn.TextColor = UIColor.White;

					UIImageView imgArrow = new UIImageView(new CoreGraphics.CGRect(viewTruckloadRequest.Frame.Width - 50, 20, 40, 40));
					imgArrow.Image = UIImage.FromBundle("Images/tab-down.png");

					//First Tab
					bool isShowCharges = CommanUtil.isShowCharges;
					lblRequest.Text = objCarrierShipmentDetails.Mode + Constants.strREQUEST;
					if (isShowCharges)
					{
						if (objCarrierShipmentDetails.LowestPrice > 0)
						{
							lblLowestPrice.Text = objCarrierShipmentDetails.LowestPriceLbl + " : $" + objCarrierShipmentDetails.LowestPrice;
						}
						else
						{
							lblLowestPrice.Text = "";
						}
					}
					lblPickupOn.Text = Constants.strPick + objCarrierShipmentDetails.PickupStr;
					lblRequest.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblLowestPrice.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblPickupOn.Font = UIFont.FromName(Constants.strFontName, 12f);
					tapGestureSection1 = new UITapGestureRecognizer(new Action(delegate
									{
										ExpandSection(Convert.ToInt32(viewTruckloadRequest.Tag));
									}));
					viewTruckloadRequest.AddGestureRecognizer(tapGestureSection1);


					viewTruckloadRequest.AddSubview(lblRequest);
					viewTruckloadRequest.AddSubview(lblLowestPrice);
					viewTruckloadRequest.AddSubview(lblPickupOn);
					viewTruckloadRequest.AddSubview(imgArrow);
					return viewTruckloadRequest;

				}
				else if (section == 1)
				{
                    viewAddress = new UIView(new CoreGraphics.CGRect(0, 0, tableView.Frame.Width, 75));
					viewAddress.BackgroundColor = Constants.conversationHeadClr;

					viewAddress.Tag = section;

					UILabel lblAddressLabel = new UILabel(new CoreGraphics.CGRect(10, 15, viewAddress.Frame.Width - 60, 15));
					UILabel lblAddress = new UILabel(new CoreGraphics.CGRect(10, lblAddressLabel.Frame.Y + 20, viewAddress.Frame.Width - 60, 30));
					lblAddress.Lines = 0;
					lblAddress.LineBreakMode = UILineBreakMode.WordWrap;

					lblAddressLabel.TextColor = UIColor.White;
					lblAddress.TextColor = UIColor.White;


					UIImageView imgArrow = new UIImageView(new CoreGraphics.CGRect(viewAddress.Frame.Width - 50, 20, 40, 40));
					imgArrow.Image = UIImage.FromBundle("Images/tab-down.png");

					lblAddressLabel.Text = ConstantsClass.address;
					List<Address> objAddress = new List<Address>();
					objAddress = objCarrierShipmentDetails.Addresses.ToList();
					if (objAddress != null)
					{
						foreach (var item in objAddress)
						{
							if (item.Type == Constants.strORIGIN)
							{
								if (!string.IsNullOrEmpty(item.City))
								{
									lblAddress.Text = item.City;
								}
								if (!string.IsNullOrEmpty(item.State))
								{
									lblAddress.Text += " " + item.State + " " + item.Zip;
								}
							}
							if (item.Type == Constants.strSHIPTO)
							{
								if (!string.IsNullOrEmpty(item.City))
								{
									lblAddress.Text += ConstantsClass.addressTo + item.City;
								}
								if (!string.IsNullOrEmpty(item.State))
								{
									lblAddress.Text += " " + item.State + " " + item.Zip;
								}
							}
						}
					}
					lblAddress.Font = UIFont.FromName(Constants.strFontName, 15f);
					//lblAddress.SizeToFit();
					lblAddressLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblAddressLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
					tapGestureSection2 = new UITapGestureRecognizer(new Action(delegate
									{
										ExpandSection(Convert.ToInt32(viewAddress.Tag));
									}));
					viewAddress.AddGestureRecognizer(tapGestureSection2);


					viewAddress.AddSubview(lblAddressLabel);
					viewAddress.AddSubview(lblAddress);
					viewAddress.AddSubview(imgArrow);
					return viewAddress;
				}
				else if (section == 2)
				{
                    viewLineDetails = new UIView(new CoreGraphics.CGRect(0, 0, tableView.Frame.Width, 75));
					viewLineDetails.BackgroundColor = Constants.conversationHeadClr;

					//lstUIViews.Add(objUIView);
					viewLineDetails.Tag = section;

					UILabel lblDetailsLabel = new UILabel(new CoreGraphics.CGRect(10, 20, viewLineDetails.Frame.Width - 60, 15));
					UILabel lblDetails = new UILabel(new CoreGraphics.CGRect(10, lblDetailsLabel.Frame.Y + 20, viewLineDetails.Frame.Width - 60, 15));

					lblDetailsLabel.TextColor = UIColor.White;
					lblDetails.TextColor = UIColor.White;

					UIImageView imgArrow = new UIImageView(new CoreGraphics.CGRect(viewLineDetails.Frame.Width - 50, 20, 40, 40));
					imgArrow.Image = UIImage.FromBundle("Images/tab-down.png");

					if (objCarrierShipmentDetails.IsTest)
					{
						lblDetailsLabel.Text = Constants.strDetail;
					}
					else
					{
						lblDetailsLabel.Text = Constants.strDetailHead;
					}
					List<LineDetail> objDetails = new List<LineDetail>();
					objDetails = objCarrierShipmentDetails.LineDetails;
                    if (objDetails != null)
                    {
                        decimal weight = 00;
                        decimal Pallets = 00;
                        decimal Pieces = 00;
                        foreach (var itemDetails in objDetails)
                        {
                            weight += Convert.ToDecimal(itemDetails.Weight);
                            Pallets += Convert.ToDecimal(itemDetails.Pallets);
                            Pieces += Convert.ToDecimal(itemDetails.Pieces);
                        }
                        lblDetails.Text = Convert.ToString(Math.Round(weight, 2)) +
                               Constants.strlbs + Convert.ToString(Math.Round(Pallets, 2)) +
                               Constants.strPallets + Convert.ToString(Math.Round(Pieces, 2)) +
                               Constants.strPieces;
                    }
					lblDetailsLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblDetails.Font = UIFont.FromName(Constants.strFontName, 13f);
					tapGestureSection3 = new UITapGestureRecognizer(new Action(delegate
									{
										ExpandSection(Convert.ToInt32(viewLineDetails.Tag));
									}));
					viewLineDetails.AddGestureRecognizer(tapGestureSection3);
					viewLineDetails.AddSubview(lblDetailsLabel);
					viewLineDetails.AddSubview(lblDetails);
					viewLineDetails.AddSubview(imgArrow);
					return viewLineDetails;
				}
				else if (section == 3)
				{
                    viewCommodities = new UIView(new CoreGraphics.CGRect(0, 0, tableView.Frame.Width, 75));
					viewCommodities.BackgroundColor = Constants.conversationHeadClr;

					viewCommodities.Tag = section;

					UILabel lblCommodities = new UILabel(new CoreGraphics.CGRect(10, 20, viewCommodities.Frame.Width - 60, 15));
					lblCommodities.TextColor = UIColor.White;

					UIImageView imgArrow = new UIImageView(new CoreGraphics.CGRect(viewCommodities.Frame.Width - 50, 20, 40, 40));
					imgArrow.Image = UIImage.FromBundle("Images/tab-down.png");

					lblCommodities.Text = ConstantsClass.commodities;

					lblCommodities.Font = UIFont.FromName(Constants.strFontName, 13f);

					tapGestureCommodities = new UITapGestureRecognizer(new Action(delegate
													{
														ExpandSection(Convert.ToInt32(viewCommodities.Tag));
													}));
					viewCommodities.AddGestureRecognizer(tapGestureCommodities);
					viewCommodities.AddSubviews(lblCommodities, imgArrow);

					return viewCommodities;


				}
				else if (section == 4)
				{
                    viewOptions = new UIView(new CoreGraphics.CGRect(0, 0, tableView.Frame.Width, 75));
					viewOptions.BackgroundColor = Constants.conversationHeadClr;

					viewOptions.Tag = section;

					UILabel lblOptionsLabel = new UILabel(new CoreGraphics.CGRect(10, 20, viewOptions.Frame.Width - 60, 15));
					UILabel lblOptions = new UILabel(new CoreGraphics.CGRect(10, lblOptionsLabel.Frame.Y + 20, viewOptions.Frame.Width - 60, 15));

					lblOptionsLabel.TextColor = UIColor.White;
					lblOptions.TextColor = UIColor.White;


					UIImageView imgArrow = new UIImageView(new CoreGraphics.CGRect(viewOptions.Frame.Width - 50, 20, 40, 40));
					imgArrow.Image = UIImage.FromBundle("Images/tab-down.png");

					lblOptionsLabel.Text = ConstantsClass.options;
					List<SS> objOptions = new List<SS>();
					if (objCarrierShipmentDetails.SSes != null)
					{
						objOptions = objCarrierShipmentDetails.SSes.ToList();
						lblOptions.Text = Convert.ToString(objOptions.Count()) + Constants.strDetailHead;
					}
					lblOptionsLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblOptions.Font = UIFont.FromName(Constants.strFontName, 13f);
					tapGestureSection4 = new UITapGestureRecognizer(new Action(delegate
									{
										ExpandSection(Convert.ToInt32(viewOptions.Tag));
									}));
					viewOptions.AddGestureRecognizer(tapGestureSection4);


					viewOptions.AddSubview(lblOptionsLabel);
					viewOptions.AddSubview(lblOptions);
					viewOptions.AddSubview(imgArrow);
					return viewOptions;
				}
				else if (section == 5)
				{
                    viewConfirmation = new UIView(new CoreGraphics.CGRect(0, 0, tableView.Frame.Width, 75));
					viewConfirmation.BackgroundColor = Constants.conversationHeadClr;
					viewConfirmation.Tag = section;

					UILabel lblConfirmationLabel = new UILabel(new CoreGraphics.CGRect(10, 20, viewConfirmation.Frame.Width - 60, 15));
					UILabel lblConfirmation = new UILabel(new CoreGraphics.CGRect(10, lblConfirmationLabel.Frame.Y + 20, viewConfirmation.Frame.Width - 60, 15));

					lblConfirmationLabel.TextColor = UIColor.White;
					lblConfirmation.TextColor = UIColor.White;


					UIImageView imgArrow = new UIImageView(new CoreGraphics.CGRect(viewConfirmation.Frame.Width - 50, 20, 40, 40));
					imgArrow.Image = UIImage.FromBundle("Images/tab-down.png");

					lblConfirmationLabel.Text = Constants.strConfirmation + ":";
					lblConfirmation.Text = ConstantsClass.pickupDelivery;
					lblConfirmationLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
					lblConfirmation.Font = UIFont.FromName(Constants.strFontName, 13f);

					tapGestureSection5 = new UITapGestureRecognizer(new Action(delegate
									{
										ExpandSection(Convert.ToInt32(viewConfirmation.Tag));
									}));
					viewConfirmation.AddGestureRecognizer(tapGestureSection5);
					viewConfirmation.AddSubviews(lblConfirmationLabel, lblConfirmation, imgArrow);
					return viewConfirmation;
				}
				else if (section == 6)
				{
                    viewForCarrier = new UIView(new CoreGraphics.CGRect(0, 0, tableView.Frame.Width, 75));
					viewForCarrier.BackgroundColor = Constants.conversationHeadClr;
					viewForCarrier.Tag = section;

					UILabel lblAssignDriver = new UILabel(new CoreGraphics.CGRect(10, 20, viewForCarrier.Frame.Width - 60, 15));
					lblAssignDriver.TextColor = UIColor.White;
					UIImageView imgArrow = new UIImageView(new CoreGraphics.CGRect(viewForCarrier.Frame.Width - 50, 20, 40, 40));
					imgArrow.Image = UIImage.FromBundle("Images/tab-down.png");
					lblAssignDriver.Text = ConstantsClass.assignDriver;
					lblAssignDriver.Font = UIFont.FromName(Constants.strFontName, 13f);
					tapGestureSection6 = new UITapGestureRecognizer(new Action(delegate
									{
										ExpandSection(Convert.ToInt32(viewForCarrier.Tag));
									}));
					viewForCarrier.AddGestureRecognizer(tapGestureSection6);
					viewForCarrier.AddSubviews(lblAssignDriver, imgArrow);
					return viewForCarrier;
				}
				else
				{
					return null;
				}
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
				return null;
			}
		}

		/// <summary>
		/// Expands the section.
		/// </summary>
		/// <param name="headerCount">Header count.</param>
		public void ExpandSection(int headerCount)
		{
			try
			{
				//isExpanded = false;
				if (headerCount == 0)
				{
					viewAddress.BackgroundColor = Constants.conversationHeadClr;
					viewLineDetails.BackgroundColor = Constants.conversationHeadClr;
					viewOptions.BackgroundColor = Constants.conversationHeadClr;
					viewConfirmation.BackgroundColor = Constants.conversationHeadClr;
					viewForCarrier.BackgroundColor = Constants.conversationHeadClr;
					viewCommodities.BackgroundColor = Constants.conversationHeadClr;


					isRateSection = true;
					isAddressSection = false;
					isDetailsLineSection = false;
					isOptionsSection = false;
					isConfirmationSection = false;
					isAssignDriverSection = false;
					isCommoditiesSection = false;
					//sectionNo = 0;
				}
				else if (headerCount == 1)
				{
					viewTruckloadRequest.BackgroundColor = Constants.conversationHeadClr;
					viewLineDetails.BackgroundColor = Constants.conversationHeadClr;
					viewOptions.BackgroundColor = Constants.conversationHeadClr;
					viewConfirmation.BackgroundColor = Constants.conversationHeadClr;
					viewForCarrier.BackgroundColor = Constants.conversationHeadClr;
					viewCommodities.BackgroundColor = Constants.conversationHeadClr;
					isRateSection = false;
					isAddressSection = true;
					isDetailsLineSection = false;
					isOptionsSection = false;
					isConfirmationSection = false;
					isAssignDriverSection = false;
					isCommoditiesSection = false;
					//sectionNo = 1;
				}
				else if (headerCount == 2)
				{
					viewTruckloadRequest.BackgroundColor = Constants.conversationHeadClr;
					viewAddress.BackgroundColor = Constants.conversationHeadClr;
					viewOptions.BackgroundColor = Constants.conversationHeadClr;
					viewConfirmation.BackgroundColor = Constants.conversationHeadClr;
					viewForCarrier.BackgroundColor = Constants.conversationHeadClr;
					viewCommodities.BackgroundColor = Constants.conversationHeadClr;
					isRateSection = false;
					isAddressSection = false;
					isDetailsLineSection = true;
					isOptionsSection = false;
					isConfirmationSection = false;
					isAssignDriverSection = false;
					isCommoditiesSection = false;
					//sectionNo = 2;
				}
				else if (headerCount == 3)
				{
					viewTruckloadRequest.BackgroundColor = Constants.conversationHeadClr;
					viewLineDetails.BackgroundColor = Constants.conversationHeadClr;
					viewAddress.BackgroundColor = Constants.conversationHeadClr;
					viewOptions.BackgroundColor = Constants.conversationHeadClr;
					viewConfirmation.BackgroundColor = Constants.conversationHeadClr;
					viewForCarrier.BackgroundColor = Constants.conversationHeadClr;
					isRateSection = false;
					isAddressSection = false;
					isDetailsLineSection = false;
					isCommoditiesSection = true;
					isOptionsSection = false;
					isConfirmationSection = false;
					isAssignDriverSection = false;
					//sectionNo = 2;
				}
				else if (headerCount == 4)
				{
					viewTruckloadRequest.BackgroundColor = Constants.conversationHeadClr;
					viewAddress.BackgroundColor = Constants.conversationHeadClr;
					viewLineDetails.BackgroundColor = Constants.conversationHeadClr;
					viewConfirmation.BackgroundColor = Constants.conversationHeadClr;
					viewForCarrier.BackgroundColor = Constants.conversationHeadClr;
					viewCommodities.BackgroundColor = Constants.conversationHeadClr;
					isRateSection = false;
					isAddressSection = false;
					isDetailsLineSection = false;
					isCommoditiesSection = false;
					isOptionsSection = true;
					isConfirmationSection = false;
					isAssignDriverSection = false;
					//sectionNo = 3;
				}
				else if (headerCount == 5)
				{
					viewTruckloadRequest.BackgroundColor = Constants.conversationHeadClr;
					viewAddress.BackgroundColor = Constants.conversationHeadClr;
					viewLineDetails.BackgroundColor = Constants.conversationHeadClr;
					viewConfirmation.BackgroundColor = Constants.conversationHeadClr;
					viewForCarrier.BackgroundColor = Constants.conversationHeadClr;
					viewCommodities.BackgroundColor = Constants.conversationHeadClr;
					isRateSection = false;
					isAddressSection = false;
					isDetailsLineSection = false;
					isCommoditiesSection = false;
					isOptionsSection = false;
					isConfirmationSection = true;
					isAssignDriverSection = false;
					//sectionNo = 4;
				}
				else if (headerCount == 6)
				{
					viewTruckloadRequest.BackgroundColor = Constants.conversationHeadClr;
					viewAddress.BackgroundColor = Constants.conversationHeadClr;
					viewLineDetails.BackgroundColor = Constants.conversationHeadClr;
					viewConfirmation.BackgroundColor = Constants.conversationHeadClr;
					viewForCarrier.BackgroundColor = Constants.conversationHeadClr;
					viewCommodities.BackgroundColor = Constants.conversationHeadClr;
					isRateSection = false;
					isAddressSection = false;
					isDetailsLineSection = false;
					isCommoditiesSection = false;
					isOptionsSection = false;
					isConfirmationSection = false;
					isAssignDriverSection = true;
					//sectionNo = 5;
				}
				objTableView.BeginUpdates();
				//objTableView.ReloadData();
				objTableView.EndUpdates();
			}
			catch
			{
				throw;
			}
		}
	}
}

