using System;
using System.Collections.Generic;
using CoreGraphics;
using Foundation;
using RateLinx.Helper;
using RateLinx.Models;
using UIKit;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using RateLinx.APIs;

namespace RateLinx.iOS
{
	class RateEntriesAdapter : UITableViewSource
	{

		#region Variable Declaration

		List<Entry> entries;
		CustomPopup customAlert = null;
		UIView mainView;
		UIImageView imgLorry;
		CarrierShipmentDetails carrierShipmentDetail;
		ShipmentDetailController shipmentDetailController;
		//CustomPopup customAlert = null;
		LoadingOverlay loadPop;
		UITapGestureRecognizer tapGestureChargeBreakup, tapGestureComment, tapGestureConfirmShip, tapGestureDenyShip, tapGestureLory;

		#endregion

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.RateEntriesAdapter"/> class.
		/// </summary>
		/// <param name="entries">Entries.</param>
		/// <param name="mainView">Main view.</param>
		/// <param name="carrierShipmentDetail">Carrier shipment detail.</param>
		/// <param name="shipmentDetailController">Shipment detail controller.</param>
		public RateEntriesAdapter(List<Entry> entries, UIView mainView, CarrierShipmentDetails carrierShipmentDetail, ShipmentDetailController shipmentDetailController)
		{
			this.entries = entries;
			this.mainView = mainView;
			this.carrierShipmentDetail = carrierShipmentDetail;
			this.shipmentDetailController = shipmentDetailController;
		}
		/// <summary>
		/// Rowses the in section.
		/// </summary>
		/// <returns>The in section.</returns>
		/// <param name="tableview">Tableview.</param>
		/// <param name="section">Section.</param>
		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return entries.Count;
		}

		public override nfloat GetHeightForRow(UITableView tableView, NSIndexPath indexPath)
		{
			return 35;
		}

		/// <summary>
		/// Gets the cell.
		/// </summary>
		/// <returns>The cell.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			try
			{
				nfloat xCordinate = 0;

				nfloat xCordinateImages = 10;

				//if (!Constants.isRateEntry)
				//{
				//	xCordinate = 35;
				//}
				UIColor altColor = null;
				UITableViewCell objRateEntriesCell = new UITableViewCell(new CGRect(0, 0, tableView.Frame.Width, 35));
				UIView viewRateEntry = new UIView(new CGRect(0, 0, tableView.Frame.Width, 35));
				objRateEntriesCell.AddSubview(viewRateEntry);
				if (indexPath.Row % 2 == 0)
				{
					altColor = Constants.tableRowOddColor;
				}
				else
				{
					altColor = UIColor.LightGray;
				}
				viewRateEntry.BackgroundColor = altColor;
				UIView viewAwardDenyConfirm = new UIView(new CGRect(xCordinate, 0, 100, 35));
				viewRateEntry.AddSubview(viewAwardDenyConfirm);
				xCordinate += viewAwardDenyConfirm.Frame.Width + 1;
				UIImageView imgConfirmShip = new UIImageView(new CGRect(xCordinateImages, 7.5, 20, 20));
				UIImageView imgDenyShip = new UIImageView(new CGRect(xCordinateImages, 7.5, 20, 20));
				imgLorry = new UIImageView(new CGRect(xCordinateImages, 2, 20, 20));
				if (entries[indexPath.Row].CanConfirm)
				{
					imgConfirmShip = new UIImageView(new CGRect(xCordinateImages, 7.5, 20, 20));
					imgConfirmShip.Image = UIImage.FromBundle("Images/confShip.png");
					xCordinateImages += imgConfirmShip.Frame.Width + 10;

					tapGestureConfirmShip = new UITapGestureRecognizer();
					tapGestureConfirmShip.AddTarget(new Action(delegate
					{
						ShowConfirmShipPopup(entries[indexPath.Row]);
					}));
					imgConfirmShip.AddGestureRecognizer(tapGestureConfirmShip);

					imgConfirmShip.UserInteractionEnabled = true;
				}
				if (entries[indexPath.Row].CanDeny)
				{
					imgDenyShip = new UIImageView(new CGRect(xCordinateImages, 7.5, 20, 20));
					imgDenyShip.Image = UIImage.FromBundle("Images/denyShip.png");
					xCordinateImages += imgDenyShip.Frame.Width + 10;

					tapGestureDenyShip = new UITapGestureRecognizer();
					tapGestureDenyShip.AddTarget(new Action(delegate
					{
						ShowDenyShipPopup(entries[indexPath.Row]);
					}));
					imgDenyShip.AddGestureRecognizer(tapGestureDenyShip);

					imgDenyShip.UserInteractionEnabled = true;

				}
				if (entries[indexPath.Row].CanAward)
				{
					imgLorry = new UIImageView(new CGRect(xCordinateImages, 7.5, 20, 20));
					imgLorry.Image = UIImage.FromBundle("Images/lorry.png");
					xCordinateImages += imgLorry.Frame.Width + 10;

					tapGestureLory = new UITapGestureRecognizer();
					tapGestureLory.AddTarget(new Action(delegate
					{
						if (Reachability.InternetConnectionStatus())
						{
							AwardedShipmentVisibility(entries[indexPath.Row]);
						}
						else
						{
							customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, shipmentDetailController, "", 1);
							shipmentDetailController.View.Add(customAlert); 						}

					}));
					imgLorry.AddGestureRecognizer(tapGestureLory);
					imgLorry.UserInteractionEnabled = true;
				}

				viewAwardDenyConfirm.AddSubviews(imgConfirmShip, imgDenyShip, imgLorry);

				UIView viewComments = new UIView(new CGRect(xCordinate, 0, 100, 35));
				xCordinate += viewAwardDenyConfirm.Frame.Width + 1;
				if (Constants.isComments)
				{
					UIImageView imageComment = new UIImageView(new CGRect(42, 7.5, 20, 20));
					imageComment.Image = UIImage.FromBundle("Images/comments5.png");

					tapGestureComment = new UITapGestureRecognizer();
					tapGestureComment.AddTarget(new Action(delegate
					{
						ShowBidComment(entries[indexPath.Row]);
					}));
					imageComment.AddGestureRecognizer(tapGestureComment);

					imageComment.UserInteractionEnabled = true;


					viewComments.AddSubview(imageComment);

				}
				viewRateEntry.AddSubview(viewComments);

				UILabel lblCarrier = new UILabel(new CGRect(xCordinate, 0, 100, 35));
				lblCarrier.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblCarrier.Text = entries[indexPath.Row].SCAC;
				lblCarrier.TextColor = UIColor.Black;
				lblCarrier.TextAlignment = UITextAlignment.Center;
				viewRateEntry.AddSubview(lblCarrier);
				xCordinate += lblCarrier.Frame.Width + 1;

				UILabel lblCarrierName = new UILabel(new CGRect(xCordinate, 0, 100, 35));
				lblCarrierName.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblCarrierName.Text = entries[indexPath.Row].CarrierName;
				lblCarrierName.TextColor = UIColor.Black;
				lblCarrierName.TextAlignment = UITextAlignment.Center;
				viewRateEntry.AddSubview(lblCarrierName);
				xCordinate += lblCarrierName.Frame.Width + 1;

				UILabel lblShipmentCost = new UILabel(new CGRect(xCordinate, 0, 100, 35));
				lblShipmentCost.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblShipmentCost.Text = "$" + Convert.ToString(entries[indexPath.Row].Price);
				lblShipmentCost.TextColor = UIColor.Blue;
				lblShipmentCost.TextAlignment = UITextAlignment.Center;
				viewRateEntry.AddSubview(lblShipmentCost);
				xCordinate += lblShipmentCost.Frame.Width + 1;
				tapGestureChargeBreakup = new UITapGestureRecognizer();
				tapGestureChargeBreakup.AddTarget(new Action(delegate
				{
					ShowChargesDetail(entries[indexPath.Row]);
				}));
				lblShipmentCost.AddGestureRecognizer(tapGestureChargeBreakup);

				lblShipmentCost.UserInteractionEnabled = true;

				UILabel lblTermsAlt = new UILabel(new CGRect(xCordinate, 0, 100, 35));
				lblTermsAlt.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblTermsAlt.Text = entries[indexPath.Row].Altered ? NSBundle.MainBundle.GetLocalizedString("btnYes",null) : NSBundle.MainBundle.GetLocalizedString("btnNo",null);
				lblTermsAlt.TextColor = UIColor.Black;
				lblTermsAlt.TextAlignment = UITextAlignment.Center;
				viewRateEntry.AddSubview(lblTermsAlt);
				xCordinate += lblTermsAlt.Frame.Width + 1;

				UILabel lblStatus = new UILabel(new CGRect(xCordinate, 0, 100, 35));
				lblStatus.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblStatus.Text = entries[indexPath.Row].Status;
				lblStatus.TextColor = UIColor.Black;
				lblStatus.TextAlignment = UITextAlignment.Center;
				viewRateEntry.AddSubview(lblStatus);
				xCordinate += lblStatus.Frame.Width + 1;

				UILabel lblAuthedBy = new UILabel(new CGRect(xCordinate, 0, 100, 35));
				lblAuthedBy.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblAuthedBy.Text = entries[indexPath.Row].AuthedBy;
				lblAuthedBy.TextColor = UIColor.Black;
				lblAuthedBy.TextAlignment = UITextAlignment.Center;
				viewRateEntry.AddSubview(lblAuthedBy);
				xCordinate += lblAuthedBy.Frame.Width + 1;

				UILabel lblDeliveryDate = new UILabel(new CGRect(xCordinate, 0, 0, 0));
				if (Constants.isDeliveryDate)
				{
					lblDeliveryDate = new UILabel(new CGRect(xCordinate, 0, 100, 35));
					lblDeliveryDate.Font = UIFont.FromName(Constants.strFontName, 12f);
					lblDeliveryDate.Text = entries[indexPath.Row].DeliverOnStr;
					lblDeliveryDate.TextColor = UIColor.Black;
					lblDeliveryDate.TextAlignment = UITextAlignment.Center;
					viewRateEntry.AddSubview(lblDeliveryDate);
					xCordinate += lblDeliveryDate.Frame.Width + 1;
				}
				UILabel lblDateEntered = new UILabel(new CGRect(xCordinate, 0, 200, 35));
				lblDateEntered.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblDateEntered.Text = entries[indexPath.Row].EnteredOnStr;
				lblDateEntered.TextColor = UIColor.Black;
				lblDateEntered.TextAlignment = UITextAlignment.Center;
				viewRateEntry.AddSubview(lblDateEntered);
				xCordinate += lblDateEntered.Frame.Width + 1;

				UILabel lblAwarded = new UILabel(new CGRect(xCordinate, 0, 100, 35));
				lblAwarded.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblAwarded.Text = entries[indexPath.Row].Winner ? NSBundle.MainBundle.GetLocalizedString("btnYes", null) : NSBundle.MainBundle.GetLocalizedString("pending", null);
				lblAwarded.TextColor = UIColor.Black;
				lblAwarded.TextAlignment = UITextAlignment.Center;
				viewRateEntry.AddSubview(lblAwarded);
				xCordinate += lblAwarded.Frame.Width + 1;

				UILabel lblReason = new UILabel(new CGRect(xCordinate, 0, 100, 35));
				lblReason.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblReason.Text = entries[indexPath.Row].DenyReason;
				lblReason.TextColor = UIColor.Black;
				lblReason.TextAlignment = UITextAlignment.Center;
				viewRateEntry.AddSubview(lblReason);
				xCordinate += lblReason.Frame.Width + 1;
				return objRateEntriesCell;
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Shows the confirm ship popup.
		/// </summary>
		/// <param name="entry">Entry.</param>
		void ShowConfirmShipPopup(Entry entry)
		{
            if (!CommanUtil.IsTimeOut())
            {
                return;
            }
			ConfirmShipmentPopup objConfirmShipmentPopup = new ConfirmShipmentPopup(mainView, carrierShipmentDetail, shipmentDetailController);

			UIView viewConfirmShipPopup = objConfirmShipmentPopup.GetPopupScreen();

			mainView.Add(viewConfirmShipPopup);
		}

		/// <summary>
		/// Shows the deny ship popup.
		/// </summary>
		/// <param name="entry">Entry.</param>
		void ShowDenyShipPopup(Entry entry)
		{
            if (!CommanUtil.IsTimeOut())
            {
                return;
            }
			DenyShipmentPopup objDenyShipmentPopup = new DenyShipmentPopup(mainView, carrierShipmentDetail, shipmentDetailController);

			UIView viewDenyShipPopup = objDenyShipmentPopup.GetPopupScreen();

			mainView.Add(viewDenyShipPopup);
		}

		/// <summary>
		/// Awardeds the shipment visibility.
		/// </summary>
		/// <param name="entry">Entry.</param>
		private async void AwardedShipmentVisibility(Entry entry)
		{
			try
			{
				int bidID = carrierShipmentDetail.Entries[0].ID;
				double minPrice = 0.00;
				string PayLoad = string.Empty;
				double entryPrice = carrierShipmentDetail.Entries[0].Price;
				if (carrierShipmentDetail.NeedsNonOptReason)
				{
					minPrice = carrierShipmentDetail.Entries[0].Price;
					for (int count = 0; count < carrierShipmentDetail.Entries.Count; count++)
					{
						if (carrierShipmentDetail.Entries[count].Price <= minPrice)
						{
							minPrice = carrierShipmentDetail.Entries[count].Price;
						}
					}
					if (minPrice != entryPrice)
					{
						//NeedsNonOptReason = true;
						//This will Remove When popUp functionality will be implement
						PayLoad = "{}";
						await AwardShipment(bidID, PayLoad);
						imgLorry.Hidden = true;
					}
					else
					{
						PayLoad = "{}";
						await AwardShipment(bidID, PayLoad);
						imgLorry.Hidden = true;
					}
				}
				else
				{
					PayLoad = "{}";
					await AwardShipment(bidID, PayLoad);
					imgLorry.Hidden = true;
				}
			}
			catch
			{
				Console.WriteLine("");
			}
		}

		/// <summary>
		/// Award Shipment
		/// </summary>
		/// <param name="bidID"></param>
		/// <param name="payLoad"></param>
		private async Task AwardShipment(int bidID, string payLoad)
		{
			try
			{
				JObject response = null;
				ServiceHelper objServiceHelper = new ServiceHelper();
				string shipmentId = CommanUtil.CompositeKey(carrierShipmentDetail.ClientID, carrierShipmentDetail.LocID, carrierShipmentDetail.BolNum);
				CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
                if (!CommanUtil.IsTimeOut())
                {
                    return;
                }
				if (loadPop == null)
				{
					loadPop = new LoadingOverlay(bounds);
				}
				mainView.Add(loadPop);
				string methodURI = APIMethods.shipmentDetails + "/" + shipmentId + "/" + bidID + "/" + APIMethods.award;
				string token = CommanUtil.tokenNo;
				var Result = await objServiceHelper.PostRequestJson(payLoad, methodURI, token, true);
				if (Result != null)
				{
					response = JObject.Parse(Result);
					string message = Convert.ToString(response[Constants.strErrorMessage]);
					if (!string.IsNullOrEmpty(message))
					{
						loadPop.Hide();
						ErrorPopup objErrorPopup = new ErrorPopup(mainView, message, shipmentDetailController);
						UIView viewErrorpop = objErrorPopup.GetErrorPopup();
						mainView.Add(viewErrorpop);
					}
					else
					{
						loadPop.Hide();
						string key = carrierShipmentDetail.ClientID + "|" + carrierShipmentDetail.BolNum + "|" + ConstantsClass.strBid;
						shipmentDetailController.RefreshShipmentDetail(key);
					}
					loadPop.Hide();
				}
				else
				{
					loadPop.Hide();
				}
			}
			catch
			{
				loadPop.Hide();
				throw;
			}
		}
		/// <summary>
		/// Shows the bid comment.
		/// </summary>
		/// <param name="entry">Entry.</param>
		void ShowBidComment(Entry entry)
		{
			BidCommnetPopup objBidCommentPopup = new BidCommnetPopup(mainView, entry);

			UIView viewBidComment = objBidCommentPopup.GetPopupScreen();

			mainView.Add(viewBidComment);
		}
		/// <summary>
		/// Shows the charges detail.
		/// </summary>
		/// <param name="entry">Entry.</param>
		void ShowChargesDetail(Entry entry)
		{
			ChargeBreakupPopup objChargeBreakupPopup = new ChargeBreakupPopup(mainView, entry);

			UIView viewChargeBreakup = objChargeBreakupPopup.GetPopupScreen();

			mainView.Add(viewChargeBreakup);
		}
	}
}