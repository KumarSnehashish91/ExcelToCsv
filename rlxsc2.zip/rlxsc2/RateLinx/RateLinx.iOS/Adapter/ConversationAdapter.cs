using System;
using Foundation;
using RateLinx.Models;
using UIKit;
using System.Collections.Generic;
using System.Linq;
using CoreGraphics;
using RateLinx.Helper;
using CoreAnimation;
using System.Threading.Tasks;

namespace RateLinx.iOS
{
	class ConversationAdapter : UITableViewSource
	{


		#region Variable Declaration

		UITapGestureRecognizer tapGestureConversationHead;
		static nint tabCount = -1;
	//	UITableView objTableView;
		bool isExpanded = false;
		public CarrierShipmentDetails lstShipmentDetail;
		UIView viewReplySection;
		List<Conversation> lstConversationHeading = null;
		List<Conversation> lstConversationTemp = null;
		List<List<Conversation>> lstListConversation = new List<List<Conversation>>();
		ShipmentDetailController shipmentDetailController;
		List<UIView> listViewHeading = null;

		UIView mainView;
		#endregion


		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.ConversationAdapter"/> class.
		/// </summary>
		/// <param name="lstShipmentDetail">Lst shipment detail.</param>
		/// <param name="viewReply">View reply.</param>
		public ConversationAdapter(CarrierShipmentDetails lstShipmentDetail, UIView viewReply, UIView parentView,ShipmentDetailController objShipmentDetailController)
		{
			shipmentDetailController = objShipmentDetailController;
			isExpanded = false;
			mainView = parentView;
			if (lstShipmentDetail != null)
			{
				this.lstShipmentDetail = lstShipmentDetail;
				lstConversationHeading = lstShipmentDetail.Conversations.Where(conversation => conversation.Level == 0).ToList();
			}
			listViewHeading = new List<UIView>();
			this.viewReplySection = viewReply;
			ManipulateConversationList();

		}
		/// <summary>
		/// Manipulates the conversation list.
		/// </summary>
		void ManipulateConversationList()
		{
			try
			{
				int j = 0;

				lstConversationTemp = new List<Conversation>();


				if (lstShipmentDetail.Conversations != null)
				{
					foreach (Conversation conversation in lstShipmentDetail.Conversations)
					{
						if (j == 0 && conversation.Level == 0)
						{
							j++;
							lstConversationTemp.Add(conversation);
						}
						else if (conversation.Level != 0)
						{
							lstConversationTemp.Add(conversation);
						}
						else if (j != 0 && conversation.Level == 0)
						{
							List<Conversation> lstTempCov = new List<Conversation>();
							lstTempCov.AddRange(lstConversationTemp);
							lstListConversation.Add(lstTempCov);
							lstConversationTemp.Clear();
							lstConversationTemp.Add(conversation);
						}


					}

				}
				lstListConversation.Add(lstConversationTemp);
			}
			catch
			{
				throw;
			}

		}
		/// <summary>
		/// Gets the cell.
		/// </summary>
		/// <returns>The cell.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			try
			{
				//objTableView = tableView;

				if (lstListConversation[indexPath.Section].Count > 0)
				{

					if (CommanUtil.ViewAs == lstListConversation[indexPath.Section][indexPath.Row].ClientType)
					{
						ConversationSecondCell conversationSecondCell = (ConversationSecondCell)tableView.DequeueReusableCell("ConversationSecondCell", indexPath);
						conversationSecondCell.UpdateCell(lstListConversation[indexPath.Section][indexPath.Row], tableView, indexPath.Section, viewReplySection, conversationSecondCell, mainView,shipmentDetailController);

						return conversationSecondCell;

					}
					else
					{
						ConversationTableCell conversationTableCell = (ConversationTableCell)tableView.DequeueReusableCell("ConversationTableCell", indexPath);
						conversationTableCell.UpdateCell(lstListConversation[indexPath.Section][indexPath.Row], tableView, indexPath.Section, indexPath.Row, viewReplySection, conversationTableCell, mainView,shipmentDetailController);

						return conversationTableCell;

					}

				}
				else
				{
					UITableViewCell tableCell = new UITableViewCell();
					tableCell.Frame = new CGRect(0, 0, tableView.Frame.Width, 0);
					return tableCell;


				}
			}
			catch
			{
				throw;
			}
		}
		/// <summary>
		/// Rowses the in section.
		/// </summary>
		/// <returns>The in section.</returns>
		/// <param name="tableview">Tableview.</param>
		/// <param name="section">Section.</param>
		public override nint RowsInSection(UITableView tableview, nint section)
		{

			if (section == tabCount)
			{

				if (isExpanded == true)
				{
					nint count = lstListConversation[Convert.ToInt32(section)].Count;
					return count;
				}
				else
				{
					return 0;
				}
			}
			else
			{
				return 0;
			}
		}
		/// <summary>
		/// Numbers the of sections.
		/// </summary>
		/// <returns>The of sections.</returns>
		/// <param name="tableView">Table view.</param>
		public override nint NumberOfSections(UITableView tableView)
		{
			return lstConversationHeading.Count;
		}
		public override nfloat EstimatedHeightForHeader(UITableView tableView, nint section)
		{
			return 67;
		}
		/// <summary>
		/// Gets the height for row.
		/// </summary>
		/// <returns>The height for row.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="indexPath">Index path.</param>
		public override nfloat GetHeightForRow(UITableView tableView, NSIndexPath indexPath)
		{
			try
			{
				nfloat height = 20;
				if (indexPath.Section == tabCount)
				{

					if (isExpanded == true)
					{
						if (lstListConversation[indexPath.Section][indexPath.Row].Message.Count() > 0 && lstListConversation[indexPath.Section][indexPath.Row].Message.Count() < 60)
						{
							height += 40;
						}
						else if (lstListConversation[indexPath.Section][indexPath.Row].Message.Count() > 60 && lstListConversation[indexPath.Section][indexPath.Row].Message.Count() < 90)
						{
							height += 55;
						}
						else if (lstListConversation[indexPath.Section][indexPath.Row].Message.Count() > 90 && lstListConversation[indexPath.Section][indexPath.Row].Message.Count() < 120)
						{
							height += 70;
						}
						else
						{
							height += 85;
						}

						if (lstListConversation[indexPath.Section][indexPath.Row].Attachments != null && lstListConversation[indexPath.Section][indexPath.Row].Attachments.Count > 0)
						{
							if (lstListConversation[indexPath.Section][indexPath.Row].Attachments.Count == 1)
							{
								height += 25;
							}
							else if (lstListConversation[indexPath.Section][indexPath.Row].Attachments.Count == 2)
							{
								height += 50;
							}
							else
							{
								height += 75;
							}
						}

						height += 26;


						return height;
					}
					else
					{
						return 0;
					}
				}
				else
				{
					return 0;
				}
			}
			catch
			{
				throw;
			}
		}
		/// <summary>
		/// Gets the view for header.
		/// </summary>
		/// <returns>The view for header.</returns>
		/// <param name="tableView">Table view.</param>
		/// <param name="section">Section.</param>
		public override UIView GetViewForHeader(UITableView tableView, nint section)
		{
			UIView viewConversationHeader = new UIView(new CGRect(0, 0, tableView.Frame.Width, 67));
			viewConversationHeader.BackgroundColor = Constants.conversationHeadClr;

			viewConversationHeader.Tag = section;

			UILabel lblTime = new UILabel(new CoreGraphics.CGRect(10, 5, viewConversationHeader.Frame.Width - 60, 15));
			UILabel lblSubject = new UILabel(new CoreGraphics.CGRect(10, lblTime.Frame.Y + 20, viewConversationHeader.Frame.Width - 60, 15));
			UILabel lblFromTo = new UILabel(new CoreGraphics.CGRect(10, lblSubject.Frame.Y + 20, viewConversationHeader.Frame.Width - 60, 15));

			lblTime.TextColor = UIColor.White;
			lblSubject.TextColor = UIColor.White;
			lblFromTo.TextColor = UIColor.White;

			UIImageView imgArrow = new UIImageView(new CoreGraphics.CGRect(viewConversationHeader.Frame.Width - 50, 15, 35, 35));
			imgArrow.Image = UIImage.FromBundle("Images/tab-down.png");


			UIView viewSeparator = new UIView(new CoreGraphics.CGRect(0, viewConversationHeader.Frame.Height-2, viewConversationHeader.Frame.Width, 2));
			viewSeparator.BackgroundColor = Constants.separatorClr;

			//First Tab
			lblTime.Text = lstConversationHeading[Convert.ToInt32(section)].TimeStamp;
			lblSubject.Text =lstConversationHeading[Convert.ToInt32(section)].Subject;;
			lblFromTo.Text = NSBundle.MainBundle.LocalizedString("from",null) + lstConversationHeading[Convert.ToInt32(section)].FromClient + "(" + lstConversationHeading[Convert.ToInt32(section)].FromUser + ") To: " + lstConversationHeading[Convert.ToInt32(section)].ToList;// DEMOTL (Demo) To: Demo";
			lblTime.Font = UIFont.FromName(Constants.strFontName, 13f);
			lblSubject.Font = UIFont.FromName(Constants.strFontName, 13f);
			lblFromTo.Font = UIFont.FromName(Constants.strFontName, 13f);
			tapGestureConversationHead = new UITapGestureRecognizer(new Action(delegate
			{
				ExpandSection(Convert.ToInt32(viewConversationHeader.Tag), tableView);
				Util.ActiveConversationHeader = Convert.ToInt32(viewConversationHeader.Tag);

			}));
			viewConversationHeader.AddGestureRecognizer(tapGestureConversationHead);


			viewConversationHeader.AddSubview(lblTime);
			viewConversationHeader.AddSubview(lblSubject);
			viewConversationHeader.AddSubview(lblFromTo);
			viewConversationHeader.AddSubview(imgArrow);
			viewConversationHeader.AddSubview(viewSeparator);

			listViewHeading.Add(viewConversationHeader);

			return viewConversationHeader;
		}
		/// <summary>
		/// Expands the section.
		/// </summary>
		/// <param name="headerCount">Header count.</param>
		/// <param name="viewConversationHeader">View conversation header.</param>
		/// <param name="tableView">Table view.</param>
		public void ExpandSection(nint headerCount, UITableView tableView)
		{
			viewReplySection.Hidden = true;
			if (isExpanded == false)
			{
				isExpanded = true;
			}
			else
			{
				isExpanded = false;
			}

			CommanUtil.sectionNo = -1;
			tabCount = headerCount;
			nint count = lstListConversation[Convert.ToInt32(headerCount)].Count;

			tableView.ReloadData();

		}

}
}