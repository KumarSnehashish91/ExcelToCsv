﻿using System;
using PubnubApi;

namespace RateLinx.iOS
{
	/// <summary>
	/// 
	/// </summary>
	public class DemoPublishResult : PNCallback<PNPublishResult>
	{
		readonly Action<string> callback;
		readonly Pubnub pubnub = new Pubnub(null);
		/// <summary>
		/// 
		/// </summary>
		/// <param name="displayCallback"></param>
		public DemoPublishResult(Action<string> displayCallback)
		{
			callback = displayCallback;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="result"></param>
		/// <param name="status"></param>
		public override void OnResponse(PNPublishResult result, PNStatus status)
		{
			if (result != null)
			{
				callback(pubnub.JsonPluggableLibrary.SerializeToJsonString(result));
			}
			else if (status != null)
			{
				callback(pubnub.JsonPluggableLibrary.SerializeToJsonString(status));
			}
		}
	};

	/// <summary>
	/// 
	/// </summary>
	public class DemoSubscribeCallback : SubscribeCallback
	{
		readonly Action<string> callback;
		/// <summary>
		/// 
		/// </summary>
		/// <param name="displayCallback"></param>
		public DemoSubscribeCallback(Action<string> displayCallback)
		{
			callback = displayCallback;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="pubnub"></param>
		/// <param name="messageResult"></param>
		public override void Message<T>(Pubnub pubnub, PNMessageResult<T> messageResult)
		{
			if (messageResult != null)
			{
				callback(pubnub.JsonPluggableLibrary.SerializeToJsonString(messageResult));
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="pubnub"></param>
		/// <param name="presenceResult"></param>
		public override void Presence(Pubnub pubnub, PNPresenceEventResult presenceResult)
		{
			if (presenceResult != null)
			{
				callback(pubnub.JsonPluggableLibrary.SerializeToJsonString(presenceResult));
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="pubnub"></param>
		/// <param name="statusObj"></param>
		public override void Status(Pubnub pubnub, PNStatus statusObj)
		{
			string msg = string.Format("Operation: {0}; Category: {1};  StatusCode: {2}", statusObj.Operation, statusObj.Category, statusObj.StatusCode);
			callback(msg);

			if (statusObj.Category == PNStatusCategory.PNUnexpectedDisconnectCategory)
			{
				// This event happens when radio / connectivity is lost
				System.Diagnostics.Debug.WriteLine("PNUnexpectedDisconnectCategory");
			}
			else if (statusObj.Category == PNStatusCategory.PNConnectedCategory)
			{
				//Console.WriteLine("CONNECTED {0} Channels = {1}, ChannelGroups = {2}", status.StatusCode, string.Join(",", status.AffectedChannels), string.Join(",", status.AffectedChannelGroups));
				// Connect event. You can do stuff like publish, and know you'll get it.
				// Or just use the connected event to confirm you are subscribed for
				// UI / internal notifications, etc
				System.Diagnostics.Debug.WriteLine("PNConnectedCategory");
			}
			else if (statusObj.Category == PNStatusCategory.PNReconnectedCategory)
			{
				//Console.WriteLine("RE-CONNECTED {0} Channels = {1}, ChannelGroups = {2}", status.StatusCode, string.Join(",", status.AffectedChannels), string.Join(",", status.AffectedChannelGroups));
				// Happens as part of our regular operation. This event happens when
				// radio / connectivity is lost, then regained.
				System.Diagnostics.Debug.WriteLine("PNReconnectedCategory");
			}
			else if (statusObj.Category == PNStatusCategory.PNDecryptionErrorCategory)
			{
				// Handle messsage decryption error. Probably client configured to
				// encrypt messages and on live data feed it received plain text.
				System.Diagnostics.Debug.WriteLine("PNDecryptionErrorCategory");
			}
		}
	}

	/// <summary>
	/// 
	/// </summary>
	public class DemoChannelGroupRemoveChannel : PNCallback<PNChannelGroupsRemoveChannelResult>
	{
		readonly Action<string> callback;
		readonly Pubnub pubnub = new Pubnub(null);
		/// <summary>
		/// 
		/// </summary>
		/// <param name="displayCallback"></param>
		public DemoChannelGroupRemoveChannel(Action<string> displayCallback)
		{
			this.callback = displayCallback;
		}
		/// <summary>
		/// 
		/// </summary>
		/// <param name="result"></param>
		/// <param name="status"></param>
		public override void OnResponse(PNChannelGroupsRemoveChannelResult result, PNStatus status)
		{
			if (result != null)
			{
				this.callback(pubnub.JsonPluggableLibrary.SerializeToJsonString(result));
			}
			else if (status != null)
			{
				this.callback(pubnub.JsonPluggableLibrary.SerializeToJsonString(status));
			}
		}
	}
}
