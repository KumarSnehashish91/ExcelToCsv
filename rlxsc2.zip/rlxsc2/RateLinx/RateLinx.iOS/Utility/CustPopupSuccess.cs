﻿using System;
using Foundation;
using UIKit;
using System.CodeDom.Compiler;
using CoreGraphics;
using RateLinx.iOS;
using System.Threading.Tasks;
using ToastIOS;

namespace RateLinx.iOS
{
	public class CustPopupSuccess : UIView
	{
		// control declarations
		UIView customPopupView;
		UIView backgroundView;
		//UIViewController UIViewCtrl;
		//Utility utility = new Utility ();
		public string securityCode;

		public event EventHandler ValueChanged;

		public void SetValue (string newValue, bool notify)
		{
			if (newValue != null) {
				securityCode = newValue;

				if (ValueChanged != null) {
					ValueChanged (this, EventArgs.Empty);
				}
			}
		}
		public CustPopupSuccess (CGRect frame, string txtMessage, bool alertType, UIViewController uiViewCtrl, string btnParamNo) : base (frame)
		{			
			AutoresizingMask = UIViewAutoresizing.All;
			//UIViewCtrl = uiViewCtrl;

			// derive the center x and y
			nfloat centerX = Frame.Width / 2;
			nfloat centerY = Frame.Height / 2;



			backgroundView = new UIView (new CGRect (0, 0, Frame.Size.Width, frame.Size.Height));
			backgroundView.BackgroundColor = UIColor.Clear;

			backgroundView.AutoresizingMask = UIViewAutoresizing.All;

			customPopupView = new UIView (new CGRect (centerX / 10, centerY - 110, centerX + 150, 160));
			customPopupView.BackgroundColor = UIColor.FromRGB (48, 43, 37);
			customPopupView.Layer.CornerRadius = 10;
			customPopupView.Layer.BorderWidth = (System.nfloat)0.5;
			customPopupView.Layer.BorderColor = UIColor.Black.CGColor;
			//customPopupView.Layer.MasksToBounds = false;



			UIView uiViewHeader = new UIView(new CGRect (0, 10, customPopupView.Frame.Width, 40));
			uiViewHeader.BackgroundColor = UIColor.FromRGB (48, 43, 37);

			customPopupView.AddSubview (uiViewHeader);



			//nfloat cpvwidth = customPopupView.Frame.Size.Width;
			UILabel lblHeader = new UILabel (new CGRect (50, 0, 200, 30));
			//lbldataConfirm.Font = UIFont.FromName ("Roboto-Regular", 18f);
			lblHeader.Text = NSBundle.MainBundle.LocalizedString("error",null);
			lblHeader.TextColor = UIColor.White;
			lblHeader.Font = UIFont.BoldSystemFontOfSize(20);
			lblHeader.TextAlignment = UITextAlignment.Left;

			//lbldataConfirm.Lines = 0;
			//lbldataConfirm.LineBreakMode = UILineBreakMode.WordWrap;
			uiViewHeader.AddSubview (lblHeader);

			UIButton btnCross = new UIButton(new CGRect((customPopupView.Frame.Width - 30), 0, 20, 20));
			btnCross.SetTitle(NSBundle.MainBundle.LocalizedString("croxSign",null), UIControlState.Normal);

			//btnCross.BackgroundColor = UIColor.Gray;
			btnCross.Layer.CornerRadius = 5;
			uiViewHeader.AddSubview(btnCross);

			UIImageView headImageView = new UIImageView (UIImage.FromFile ("Images/error.png"));
			headImageView.Frame = new CoreGraphics.CGRect (10, 0, 40, 30);
			uiViewHeader.AddSubview (headImageView);

			UIView uiContent = new UIView(new CGRect(0, 50, customPopupView.Frame.Width, 59.7));
			uiContent.BackgroundColor = UIColor.White;
			customPopupView.AddSubview (uiContent);

			UILabel lblMessage = new UILabel(new CGRect(20, 0, customPopupView.Frame.Width-30, uiContent.Frame.Height));

			lblMessage.Text = NSBundle.MainBundle.LocalizedString("enterClientId",null);
			lblMessage.TextColor = UIColor.Black;
			lblMessage.TextAlignment = UITextAlignment.Left;
			lblMessage.Lines = 0;
			lblMessage.LineBreakMode = UILineBreakMode.WordWrap;
			uiContent.AddSubview (lblMessage);
			UIView uiSeparator = new UIView(new CGRect(0, 109.7, customPopupView.Frame.Width, (System.nfloat)0.3));
			uiSeparator.BackgroundColor = UIColor.LightGray;
			customPopupView.AddSubview (uiSeparator);
			UIView uiViewFooter = new UIView(new CGRect(0, 110, customPopupView.Frame.Width, 50));
			uiViewFooter.BackgroundColor = UIColor.White;
			customPopupView.AddSubview (uiViewFooter);

			UIButton btnOK = new UIButton(new CGRect((customPopupView.Frame.Width-70), 10, 50, 30));
			btnOK.SetTitle(NSBundle.MainBundle.LocalizedString("okText",null), UIControlState.Normal);
			btnOK.BackgroundColor = UIColor.White;
			//btnOK.Font = UIFont.BoldSystemFontOfSize(20);
			btnOK.Layer.CornerRadius = 5;
			btnOK.Layer.BorderWidth = (System.nfloat)0.5;
			btnOK.Layer.BorderColor = UIColor.Black.CGColor;
			btnOK.SetTitleColor(UIColor.Black, UIControlState.Normal);
			uiViewFooter.AddSubview(btnOK);

			btnCross.TouchUpInside += delegate
			{

				Hide();
			};
			btnOK.TouchUpInside += delegate
			{
				Hide();
			};

			customPopupView.Center = this.Center;
			//backgroundView.AddSubview (customPopupView);
			backgroundView.Alpha = 0.75f;
			backgroundView.Center = this.Center;
			AddSubview (backgroundView); 
			AddSubview (customPopupView);
		}

		public void Hide ()
		{
            this.Hidden = true;
		}
	}
}



