﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CoreLocation;
using Foundation;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RateLinx.APIs;
using RateLinx.Helper;
using RateLinx.Models;

namespace RateLinx.iOS
{
	public class Util
	{
		/// <summary>
		/// The customer aution.
		/// </summary>
		public static List<string> carrierAution = new List<string>
				{
					"All",
					"Requires Confirmation",
					"Requires a Response",
					"Requires Rate or Verification",
					"Confirmed Shipments"
		};

		/// <summary>
		/// The carrier aution.
		/// </summary>
		public static List<string> customerAution = new List<string> {
					"All",
					"Open Auctions",
					"Awarded Auctions"
		};
		//Static list of string for invoice charge
		public static List<string> invoiceCharge = new List<string> {
			"DETENTION CHG",
			"MISC CHG"
		};
		//Static list of string for the driver filter functionality for Awarded shipments and Recent Shipments for Carrier login
		public static List<string> driverList = new List<string> {
			"All",
			"Myself"
		};

		//public static CLLocation location;

		public static bool isPushRegisterd = false;//variable to confirm push notification registered or not

		public static bool isMenuVisible = false;//variable to check if the menu view is visible

		public static bool isViewRotated = false;//variable to check if the view is rotated throughout the application

		public static int currentTabAssigned = 0;//variable is being used to check conversation part

		public static int ActiveConversationHeader = -1; //To check which conversation header is active to inflate the conversation on reply

		/// <summary>
		/// Get Country Details
		/// </summary>
		/// <param name="context"></param>
		/// <returns></returns>
		public static async Task<List<CountryDetails>> GetCountryDetails()
		{
			try
			{
				List<CountryDetails> lstCountryDetails = null;
				if (Reachability.InternetConnectionStatus())
				{
					//Get the service Helper Object
					ServiceHelper objServicehelper = new ServiceHelper();
					// create json object that holds the api values
					//Method Name
					string methodName = APIMethods.getCountry;
					//Alerts.showBusyLoader(context);
					//Get the Shipments
					var strResponse = await objServicehelper.GetRequest(CommanUtil.tokenNo, methodName, true);
					//Alerts.HideBusyLoader();

					lstCountryDetails = new List<CountryDetails>();

					if (strResponse != null)
					{
						lstCountryDetails = (List<CountryDetails>)JsonConvert.DeserializeObject(strResponse, typeof(List<CountryDetails>));
					}
				}
				return lstCountryDetails;
			}
			catch
			{
				throw;
			}
		}
		//CopyRight text with application name for footer 
		public static string GetCopyRight()
		{
			return "© " + DateTime.Now.Year + " RateLinx";
		}

		/// <summary>
		/// Binds the shipment details.
		/// </summary>
		/// <returns>The shipment details.</returns>
		public static async Task<string> BindShipmentDetails(string compositeKey)
		{
			string strResponse = string.Empty;
			try
			{
				if (Reachability.InternetConnectionStatus() && !string.IsNullOrEmpty(CommanUtil.tokenNo))
				{
					ServiceHelper objServicehelper = new ServiceHelper();
					//Method Name
					string methodName = APIMethods.shipmentDetails + "/" + compositeKey;
					strResponse = await objServicehelper.GetRequest(CommanUtil.tokenNo, methodName, true);
					if (!string.IsNullOrEmpty(strResponse))
					{
						JObject jobject = JObject.Parse(strResponse);
						if (string.IsNullOrEmpty(Convert.ToString(jobject["Message"])))
						{

							//Removing Local storage
							NSUserDefaults.StandardUserDefaults.RemoveObject("shipmentDetails");
							NSUserDefaults.StandardUserDefaults.SetString(strResponse, "shipmentDetails");

						}
						else
						{
							strResponse = string.Empty;
							//Post Error Logger Request 
							//await Util.ErrorLog("API-ShipmentDetail", Convert.ToString(jobject["Message"]), strToken);
							//this.customAlert = new CustomPopup (UIScreen.MainScreen.Bounds, jobject ["Message"].ToString (), true, this, "", 1);
							//this.View.Add (this.customAlert);
						}
					}
					else
					{

						//this.customAlert = new CustomPopup (UIScreen.MainScreen.Bounds, Constants.strNetwork, true, this, "", 1);
						//this.View.Add (this.customAlert);
					}
				}
				return strResponse;
			}
			catch
			{
				return strResponse;
			}
		}

		/// <summary>
		/// Error Log
		/// </summary>
		/// <param name="recordId">Record Id</param>
		/// <param name="message">Error Message</param>
		/// <param name="tokenNo">Token Number</param>
		public static async Task ErrorLog(string recordId, string message, string tokenNo)
		{
			try
			{
				if (Reachability.InternetConnectionStatus() && !string.IsNullOrEmpty(tokenNo))
				{
					string strPostData = string.Empty;
					ServiceHelper objServiceHelper = new ServiceHelper();
					strPostData = "RecordID=" + recordId + "&Message=" + message;
					//Post Error Logger Request 
					var response = await objServiceHelper.PostRequest(strPostData, APIMethods.logerror, tokenNo, true);
					if (response != null)
					{
						//Toast.MakeText(context, Convert.ToString(jsonResponse), ToastLength.Long).Show();
					}
					else
					{
						//Toast.MakeText(context, "Error", ToastLength.Long).Show();
					}
					objServiceHelper = null;
				}
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Calculate angle
		/// </summary>
		/// <param name="radians"></param>
		/// <returns></returns>
		public static double radiansToDegrees(double radians)
		{
			return radians * 180.0 / Math.PI;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="latLng1"></param>
		/// <param name="latLng2"></param>
		/// <returns></returns>
		public static float BearingBetweenLocation(CLLocationCoordinate2D latLng1, CLLocationCoordinate2D latLng2)
		{
			try
			{
				double lat1 = latLng1.Latitude;
				double lng1 = latLng1.Longitude;
				// destination
				double lat2 = latLng2.Latitude;
				double lng2 = latLng2.Longitude;

				double dLon = (lng2 - lng1);
				double y = Math.Sin(dLon) * Math.Cos(lat2);
				double x = Math.Cos(lat1) * Math.Sin(lat2) - Math.Sin(lat1) * Math.Cos(lat2) * Math.Cos(dLon);
				float brng = (float)radiansToDegrees((Math.Atan2(y, x)));
				brng = (360 - ((brng + 360) % 360));
				return brng + 90;
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
				return 0;
			}
		}


		/// <summary>
		/// Get bearing for rotate marker
		/// </summary>
		/// <param name="latLng1"></param>
		/// <param name="latLng2"></param>
		/// <returns></returns>
		public static float BearingBetweenLocations(CLLocationCoordinate2D latLng1, CLLocationCoordinate2D latLng2)
		{
			try
			{
				//new added
				double lat = Math.Abs(latLng1.Latitude - latLng2.Latitude);
				double lng = Math.Abs(latLng1.Longitude - latLng2.Longitude);
				if (latLng1.Latitude < latLng2.Latitude && latLng1.Longitude < latLng2.Longitude)
				{
					double angl = Math.Atan(lng / lat);
					return (float)(90 - radiansToDegrees(angl));
				}
				else if (latLng1.Latitude >= latLng2.Latitude && latLng1.Longitude < latLng2.Longitude)
				{
					return (float)((90 - radiansToDegrees(Math.Atan(lng / lat))) + 180);
				}
				else if (latLng1.Latitude >= latLng2.Latitude && latLng1.Longitude >= latLng2.Longitude)
				{
					return (float)(radiansToDegrees(Math.Atan(lng / lat)) + 270);
				}
				else if (latLng1.Latitude < latLng2.Latitude && latLng1.Longitude >= latLng2.Longitude)
				{
					return (float)((radiansToDegrees(Math.Atan(lng / lat))) + 270);
				}
				else
				{
					return -1;
				}
			}
			catch
			{
				return -1;
			}
		}


		/// <summary>
		/// 
		/// </summary>
		/// <param name="my_latlong"></param>
		/// <param name="frnd_latlong"></param>
		/// <returns></returns>
		public static decimal GetDistance(CLLocation my_latlong, CLLocation frnd_latlong)
		{
			decimal dist = 0;
			try
			{
				double distance = my_latlong.DistanceFrom(frnd_latlong);
				distance = distance / 1000.0f;
				dist = Convert.ToDecimal((distance / 1.609f).ToString("F"));
				return dist;
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
				return dist;
			}
		}



		/// <summary>
		/// 
		/// </summary>
		public static async Task<string> Node_GetToken()
		{
			try
			{
				ServiceHelper objServiceHelper = new ServiceHelper();
				TokenReq objTokenReq = new TokenReq();
				string requestData = string.Empty;
				requestData = JsonConvert.SerializeObject(objTokenReq);
				string result = await objServiceHelper.Node_PostRequestJson(requestData, APIMethods.node_Auth, "", false);
				if (!string.IsNullOrEmpty(result))
				{
					DispatureToken objDispatureToken = JsonConvert.DeserializeObject<DispatureToken>(result);
					if (objDispatureToken.statusNum == 200)
					{
						result = objDispatureToken.data.accessToken;
						return result;
					}
					else
					{
						result = string.Empty;
					}
				}
				else
				{
					result = string.Empty;
				}
				objServiceHelper = null;
				objTokenReq = null;
				requestData = string.Empty;
				return result;
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
				return "";
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="assignDriver"></param>
		public static async Task<string> Node_AssignDriver(AssignDriver assignDriver)
		{
			try
			{
				//node_AssignDriver
				string tokenNo = await Node_GetToken();
				ServiceHelper objServiceHelper = new ServiceHelper();
				string requestData = string.Empty;
				requestData = JsonConvert.SerializeObject(assignDriver);
				string result = await objServiceHelper.Node_PostRequestJson(requestData, APIMethods.node_AssignDriver, tokenNo, true);
				if (!string.IsNullOrEmpty(result))
				{
					AssignDriverRes objAssignDriverRes = JsonConvert.DeserializeObject<AssignDriverRes>(result);
					if (objAssignDriverRes.statusNum == 200)
					{
						result = objAssignDriverRes.statusMsg;
					}
					else
					{
						result = objAssignDriverRes.statusMsg;
					}
				}
				else
				{
					result = Constants.strErrorOccured;
				}
				objServiceHelper = null;
				requestData = string.Empty;
				return result;
			}
			catch
			{
				Console.WriteLine(Constants.strErrorMessage);
				return Constants.strErrorMessage;
			}
		}

		/// <summary>
		/// Get Shipment tracking status
		/// </summary>
		/// <param name="bolNum"></param>
		/// <returns></returns>
		public static async Task<List<ShipmentActivity>> GetRealtimeShipmentStatus(string bolNum)
		{
			List<ShipmentActivity> lstShipmentActivity = new List<ShipmentActivity>();
			try
			{
				string tokenNo = await Node_GetToken(); //Get the token
				ServiceHelper objServiceHelper = new ServiceHelper();
				//string requestData = string.Empty;
				string result = await objServiceHelper.Node_GetRequest(tokenNo, APIMethods.node_GetShipmentStatus + bolNum, true);
				if (!string.IsNullOrEmpty(result))
				{
					RealTimeShipmentStatus realTimeShipmentStatus = JsonConvert.DeserializeObject<RealTimeShipmentStatus>(result);
					if (realTimeShipmentStatus.statusNum == 200)
					{
						lstShipmentActivity = realTimeShipmentStatus.data.Activities;
					}
					else
					{
						result = Constants.strErrorOccured;
					}
				}
				else
				{
					result = Constants.strErrorOccured;
				}
				objServiceHelper = null;
				//requestData = string.Empty;
				return lstShipmentActivity;
			}
			catch
			{
				Console.WriteLine(Constants.strErrorMessage);
				return lstShipmentActivity;
			}
		}

		/// <summary>
		/// Update Real time tracking Status of shipment
		/// </summary>
		/// <param name="updateRealTimeStatus"></param>
		public static async Task<string> UpdateRealTimeStatus(UpdateRealTimeStatus updateRealTimeStatus)
		{
			try
			{
				//node_AssignDriver
				string tokenNo = await Node_GetToken();
				ServiceHelper objServiceHelper = new ServiceHelper();
				string requestData = string.Empty;
				requestData = JsonConvert.SerializeObject(updateRealTimeStatus);
				string result = await objServiceHelper.Node_PostRequestJson(requestData, APIMethods.node_UpdateShipmentStatus, tokenNo, true);
				if (!string.IsNullOrEmpty(result))
				{
					RealTimeShipmentStatus realTimeShipmentStatusRes = JsonConvert.DeserializeObject<RealTimeShipmentStatus>(result);
					if (realTimeShipmentStatusRes.statusNum == 200)
					{
						result = realTimeShipmentStatusRes.statusMsg;
					}
					else
					{
						result = "";
					}
				}
				else
				{
					result = "";
				}
				objServiceHelper = null;
				requestData = string.Empty;
				return result;
			}
			catch
			{
				Console.WriteLine(Constants.strErrorMessage);
				return Constants.strErrorMessage;
			}
		}

       
	}
}
