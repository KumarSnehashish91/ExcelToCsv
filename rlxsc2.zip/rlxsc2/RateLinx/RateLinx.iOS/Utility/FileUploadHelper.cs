using System;
using System.Collections.Generic;

using System.Net;
using StreamReference = System.IO.Stream;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using RateLinx.APIs;
using RateLinx.Models;
using Newtonsoft.Json;
using RateLinx.Helper;
using Foundation;

namespace RateLinx.iOS
{
    /// <summary>
    /// 
    /// </summary>
    public class FileUploadHelper
    {
        /// <summary>
        /// 
        /// </summary>
        static RegisterDevice objDevice = null;

        /// <summary>
        /// Function To register device for notification service
        /// </summary>
        /// <returns></returns>
		public static async void FnRegisterDevice(bool notificationEnabled, string deviceToken)
        {
			string result = string.Empty;
            try
            {
				if (Reachability.InternetConnectionStatus() && !string.IsNullOrEmpty(CommanUtil.tokenNo)) //
				{
					string requestBody = string.Empty;
					ServiceHelper objSevice = new ServiceHelper();
					//Get device Details
					objDevice = GetDeviceInfo();
					objDevice.App = NSBundle.MainBundle.GetLocalizedString("shipReq", null);
					objDevice.ServerToken = deviceToken;
					objDevice.Enabled = notificationEnabled;
					//serialize the request
					requestBody = JsonConvert.SerializeObject(objDevice);
					result = objSevice.RegisterToken(requestBody, APIMethods.autoPushReg, CommanUtil.tokenNo, true);
					if (!string.IsNullOrEmpty(result))
					{
						var Jobject = JsonConvert.DeserializeObject(result);
						if (Jobject.ToString() == Constants.strSuccess)
						{
							Util.isPushRegisterd = true;
						}
						else
						{
							await Util.ErrorLog("TokenAPI", "TokenAPI", CommanUtil.tokenNo);
						}
					}
					else
					{
						Util.isPushRegisterd = false;
					}
				}
				else
				{
					Util.isPushRegisterd = false;
				}
                objDevice = null;
            }
            catch
            {
				Console.WriteLine(Constants.strErrorOccured);
            }
        }


        /// <summary>
        /// Creating JSON Request
        /// </summary>
        /// <param name="uploadResult">file uploaded result</param>
        /// <returns></returns>
        public static string UploadsJsonRequest(string uploadResult)
        {
            try
            {
                string jsonRequest = string.Empty;
                Dictionary<string, string> objResponse = JsonConvert.DeserializeObject<Dictionary<string, string>>(uploadResult);
                foreach (KeyValuePair<string, string> objKVP in objResponse)
                {
                    jsonRequest += "{\"SaveAsFilename\":\"" + objKVP.Key + "\",\"ULFilename\":\"" + objKVP.Value + "\"}";
                }
                objResponse = null;
                return jsonRequest;
            }
            catch
            {
                throw;
            }
        }


        /// <summary>
        /// Getting file name from file path
        /// </summary>
        /// <param name="filePath">Required Selected file path</param>
        /// <returns></returns>
        public static string GetFileName(string filePath)
        {
            try
            {
                string fileName = string.Empty;
				Random randomNo = new Random();
				int ranNo =randomNo.Next();
				string filType =filePath.Split('.')[1];
				fileName =Convert.ToString(ranNo)+"."+ filType;
                return fileName;
			}
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Get Device Details
        /// </summary>
        /// <returns></returns>
        public static RegisterDevice GetDeviceInfo()
		{
			objDevice = new RegisterDevice ();
#if __IOS__
			objDevice.DeviceID = UIKit.UIDevice.CurrentDevice.IdentifierForVendor.AsString();//"b9be5d4cd5d3f0d04a9afd30cbe1a6d2ce28f7a3";8570717E-60DA-42B8-B24B-509ECF3DFF58
			objDevice.DeviceType = ConstantsClass.iOS;
			objDevice.DeviceVer = NSBundle.MainBundle.InfoDictionary[new NSString("CFBundleVersion")].ToString();
#else
            // FYI won't work on devices prior to Gingerbread 2.3
            objDevice.DeviceID = Build.Serial;
            objDevice.DeviceType = "Android";
            objDevice.DeviceVer = Build.VERSION.Release;
            // int apiVersion = (int)Build.VERSION.SdkInt

#endif
			return objDevice;
		}


        /// <summary>
        /// File Upload functionality
        /// </summary>
        /// <param name="bytes"></param>
        /// <param name="file"></param>
        /// <param name="strMethod"></param>
        /// <param name="token"></param>
        /// <param name="isHeader"></param>
        /// <returns></returns>
		public async Task<string> PostFiles(byte[] bytes,string fileName, string strMethod, string token, bool isHeader)
        {
            try
            {
				if (Reachability.InternetConnectionStatus())
				{
					string serviceUri = string.Empty;
					serviceUri = APIBaseUri.baseUri + strMethod;
					using (ByteArrayContent fileContent = new ByteArrayContent(bytes))
					{
						fileContent.Headers.ContentType = MediaTypeHeaderValue.Parse("application/octet-stream");
						//fileContent.Headers.Add("Authorization", "bearer" + token);
						fileContent.Headers.ContentDisposition = new ContentDispositionHeaderValue("form-data")
						{
							FileName = fileName
						};
						string boundary = "---8d0f01e6b3b5dafaaadaad";
						using (MultipartFormDataContent multipartContent = new MultipartFormDataContent(boundary))
						{
							multipartContent.Add(fileContent);
							//multipartContent.Headers.Add("Authorization", "bearer " + token);
							using (HttpClient httpClient = new HttpClient())
							{
								httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", token);
								using (HttpResponseMessage response = await httpClient.PostAsync(serviceUri, multipartContent))
								{
									if (response.IsSuccessStatusCode)
									{
										string content = await response.Content.ReadAsStringAsync();
										response.Dispose();
										return content;
									}
									else
									{
										return null;
									}
								}
							}
						}
					}
				}
				else
				{
					return "{error:\"nullResponse\",Message:\"" + Constants.isOnline + "\"}";
				}
            }
            catch (WebException ex)
            {
                WebResponse response = ex.Response;
                string text;
                if (ex.Status == WebExceptionStatus.Timeout)
                {
                    // Handle timeout exception
					text = "{error:\"nullResponse\",Message:\""+Constants.strTimeOut+".\"}";
                    return text;
                }

                else if (response == null)
                {
					text = "{error:\"nullResponse\",Message:\"" + Constants.strNetwork + "\"}";
                    return text;
                }
                else
                {
                    HttpWebResponse httpResponse = (HttpWebResponse)response;
                    Console.WriteLine("Error code: {0}", httpResponse.StatusCode);
                    StreamReference data = response.GetResponseStream();

                    var reader = new StreamReader(data);
                    text = reader.ReadToEnd();
                    return text;
                }
            }

        }


	}
}