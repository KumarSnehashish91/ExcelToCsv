﻿using System;
using Foundation;
using UIKit;
using System.CodeDom.Compiler;
using CoreGraphics;
using RateLinx.iOS;
using System.Threading.Tasks;
using ToastIOS;

namespace RateLinx.iOS
{
	public class CustomPopupOfferSuccess : UIView
	{
		// control declarations
		UIView customPopupView;
		UIView backgroundView;
		//UIViewController UIViewCtrl;
		//Utility utility = new Utility ();
		public string securityCode;

		public event EventHandler ValueChanged;

		public void SetValue (string newValue, bool notify)
		{
			if (newValue != null) {
				securityCode = newValue;

				if (ValueChanged != null) {
					ValueChanged (this, EventArgs.Empty);
				}
			}
		}
		public CustomPopupOfferSuccess (CGRect frame, string txtMessage, bool alertType, UIViewController uiViewCtrl, string btnParamNo) : base (frame)
		{			
			AutoresizingMask = UIViewAutoresizing.All;
			//UIViewCtrl = uiViewCtrl;

			// derive the center x and y
			nfloat centerX = Frame.Width / 2;
			nfloat centerY = Frame.Height / 2;



			backgroundView = new UIView (new CGRect (0, 0, Frame.Size.Width, frame.Size.Height));
			backgroundView.BackgroundColor = UIColor.Clear;

			backgroundView.AutoresizingMask = UIViewAutoresizing.All;

			customPopupView = new UIView (new CGRect (centerX / 6, centerY - 110, centerX + 105, 270));
			customPopupView.BackgroundColor = UIColor.White;

			customPopupView.Layer.MasksToBounds = false;
			//customPopupView.Layer.CornerRadius = 10.0f;

			nfloat cpvwidth = customPopupView.Frame.Size.Width;
			UILabel lbldataConfirm = new UILabel (new CGRect (10, -20, centerX + 90, 100));
			//lbldataConfirm.Font = UIFont.FromName ("Roboto-Regular", 18f);
			lbldataConfirm.Text = NSBundle.MainBundle.LocalizedString("sucess",null).ToUpper();
			lbldataConfirm.TextColor = UIColor.FromRGB (85, 141, 140);
			lbldataConfirm.TextAlignment = UITextAlignment.Center;
			lbldataConfirm.Lines = 0;
			lbldataConfirm.LineBreakMode = UILineBreakMode.WordWrap;
			customPopupView.AddSubview (lbldataConfirm);
			var hrImageView = new UIImageView (UIImage.FromFile ("Images/activeicon.png"));
			hrImageView.Frame = new CoreGraphics.CGRect (0, 50, customPopupView.Frame.Size.Width, 2);
			customPopupView.AddSubview (hrImageView);

			UILabel lbldata = new UILabel (new CGRect (0, 50, customPopupView.Frame.Size.Width, 100));
			//lbldata.Font = UIFont.FromName ("Roboto-Regular", 13f);
			lbldata.Text = txtMessage;
			lbldata.TextColor = UIColor.Gray;
			lbldata.TextAlignment = UITextAlignment.Center;
			lbldata.Lines = 0;
			lbldata.LineBreakMode = UILineBreakMode.WordWrap;
		
			UIImageView successImage = new UIImageView (new CGRect (customPopupView.Frame.Width / 2 - 25, customPopupView.Frame.Height / 2, 50, 50));
			successImage.Image = UIImage.FromFile ("Images/activeicon.png");

			if (alertType) {
				UIButton btnOK = new UIButton (new CGRect (0, 220, customPopupView.Bounds.Width, 50));
				//btnOK.Font = UIFont.FromName ("Roboto-Regular", 18f);

				btnOK.SetTitleColor (UIColor.White, UIControlState.Normal);
				btnOK.BackgroundColor = UIColor.FromRGB (85, 141, 140);
				btnOK.SetTitle (NSBundle.MainBundle.LocalizedString("okText",null), UIControlState.Normal);
				btnOK.HorizontalAlignment = UIControlContentHorizontalAlignment.Center;
				btnOK.TouchUpInside += delegate {
                    SetValue(NSBundle.MainBundle.LocalizedString("sucess",null), true);
					Hide();
				};
				customPopupView.AddSubviews (lbldata, btnOK, successImage);
			} 
			customPopupView.Center = this.Center;
			backgroundView.Alpha = 0.75f;
			backgroundView.Center = this.Center;
			AddSubview (backgroundView); 
			AddSubview (customPopupView);
		}

		public void Hide ()
		{
			//if (UIViewCtrl != null) {
			//	this.Hidden = true;
			//}

            this.Hidden = true;
		}
	}
}






