﻿using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;
using System.Collections.Generic;
using CoreGraphics;
using RateLinx.Helper;
using RateLinx.Models;
using RateLinx.APIs;
using Newtonsoft.Json.Linq;
using System.Threading.Tasks;

namespace RateLinx.iOS
{
	public class UnawardConfirmationPopup
	{
		UIView mainView;
		string message = string.Empty;
		CarrierShipmentDetails carrierShipmentDetail;
		ShipmentDetailController shipmentDetailController;
		LoadingOverlay loadPop;

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.UnawardConfirmationPopup"/> class.
		/// </summary>
		/// <param name="view">View.</param>
		/// <param name="message">Message.</param>
		/// <param name="carrierShipmentDetail">Carrier shipment detail.</param>
		/// <param name="shipmentDetailController">Shipment detail controller.</param>
		public UnawardConfirmationPopup(UIView view, string message, CarrierShipmentDetails carrierShipmentDetail, ShipmentDetailController shipmentDetailController)
		{
			mainView = view;
			this.message = message;
			this.carrierShipmentDetail = carrierShipmentDetail;
			this.shipmentDetailController = shipmentDetailController;
		}

		/// <summary>
		/// Gets the popup screen.
		/// </summary>
		/// <returns>The popup screen.</returns>
		public UIView GetPopupScreen()
		{
			try
			{
				UIView popupView = new UIView();
				popupView.Frame = mainView.Bounds;
				popupView.BackgroundColor = UIColor.Clear;

				UIView viewUnawardConfirmation = new UIView(new CGRect(10, 100, mainView.Frame.Width - 20, 170));
				viewUnawardConfirmation.BackgroundColor = UIColor.White;
				viewUnawardConfirmation.Layer.CornerRadius = 5;
				viewUnawardConfirmation.Layer.BorderWidth = 0.5f;

				UIView viewTopMargin = new UIView(new CGRect(0, 0, viewUnawardConfirmation.Frame.Width, 10));
				viewTopMargin.BackgroundColor = Constants.conversationHeadClr;
				viewTopMargin.Layer.CornerRadius = 5;

				UIView viewUnawardConfirmationHead = new UIView(new CGRect(0, 5, viewUnawardConfirmation.Frame.Width, 40));
				viewUnawardConfirmationHead.BackgroundColor = Constants.conversationHeadClr;

				UIImageView imageConfirm = new UIImageView(new CGRect(10, 8, 25, 20));
				imageConfirm.Image = UIImage.FromBundle("Images/warning.png");

				UILabel lblBidCommentHead = new UILabel(new CGRect(40, 6, 150, 24));

				lblBidCommentHead.BackgroundColor = Constants.conversationHeadClr;
				lblBidCommentHead.Font = UIFont.FromName(Constants.strFontName, 15f);
				lblBidCommentHead.Text = NSBundle.MainBundle.LocalizedString("Confirm", null);
				lblBidCommentHead.TextColor = UIColor.White;

				UIButton btnPopupClose = new UIButton(new CGRect(viewUnawardConfirmation.Frame.Width - 25, 5, 25, 20));
				btnPopupClose.Layer.CornerRadius = 10;

				btnPopupClose.ContentMode = UIViewContentMode.Center;
				btnPopupClose.SetImage(UIImage.FromBundle("Images/error.PNG"), UIControlState.Normal);

				btnPopupClose.TouchUpInside += delegate
				{
					popupView.Hidden = true;
				};

				viewUnawardConfirmationHead.AddSubviews(imageConfirm, lblBidCommentHead, btnPopupClose);

				UIView viewUnawardConfirmationContent = new UIView(new CGRect(0, viewUnawardConfirmationHead.Frame.Y + viewUnawardConfirmationHead.Frame.Height, viewUnawardConfirmation.Frame.Width, 85));


				UILabel lblBidComment = new UILabel(new CGRect(10, 0, viewUnawardConfirmationContent.Frame.Width - 10, viewUnawardConfirmationContent.Frame.Height));
				lblBidComment.Font = UIFont.FromName(Constants.strFontName, 13f);
				lblBidComment.Lines = 0;

				lblBidComment.Text = message;

				viewUnawardConfirmationContent.AddSubview(lblBidComment);

				UIView viewBottomSeparator = new UIView(new CGRect(0, viewUnawardConfirmationContent.Frame.Y + viewUnawardConfirmationContent.Frame.Height, viewUnawardConfirmation.Frame.Width, 0.5));
				viewBottomSeparator.BackgroundColor = Constants.conversationHeadClr;

				UIButton btnCancel = new UIButton(new CGRect(viewUnawardConfirmation.Frame.Width - 60, viewBottomSeparator.Frame.Bottom + 5, 50, 25));
				btnCancel.SetTitle(NSBundle.MainBundle.LocalizedString("btnNo", null), UIControlState.Normal);
				btnCancel.BackgroundColor = Constants.btnColorBlue;
				btnCancel.Layer.CornerRadius = 5;

				btnCancel.TouchUpInside += delegate
				{
					popupView.Hidden = true;
				};

				UIButton btnOk = new UIButton(new CGRect(viewUnawardConfirmation.Frame.Width - 120, viewBottomSeparator.Frame.Bottom + 5, 50, 25));
				btnOk.SetTitle(NSBundle.MainBundle.LocalizedString("btnYes", null), UIControlState.Normal);
				btnOk.SetTitleColor(UIColor.Black, UIControlState.Normal);
				btnOk.Layer.BorderWidth = 1;
				btnOk.BackgroundColor = UIColor.White;
				btnOk.Layer.CornerRadius = 5;

				//btnOk.Layer.BorderWidth = 2;
				btnOk.TouchUpInside += async delegate
				{
					if (message == Constants.awardConfirmation)
					{
						await UnAwardShipment();
					}
					else
					{
						await ReSubmitShipment();
					}
					popupView.Hidden = true;
				};

				viewUnawardConfirmation.AddSubviews(viewTopMargin, viewUnawardConfirmationHead, viewUnawardConfirmationContent, viewBottomSeparator, btnCancel, btnOk);
				popupView.AddSubview(viewUnawardConfirmation);
				popupView.Hidden = false;
				return popupView;
			}
			catch
			{
				throw;
			}
		}


		/// <summary>
		/// Un-AwardShipment
		/// </summary>
		private async Task UnAwardShipment()
		{
			try
			{
				CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
				if (loadPop == null)
				{
					loadPop = new LoadingOverlay(bounds);
				}

				string id = CommanUtil.CompositeKey(carrierShipmentDetail.ClientID, carrierShipmentDetail.LocID, carrierShipmentDetail.BolNum);
				string methodURI = APIMethods.shipmentDetails + "/" + id + "/" + APIMethods.unAward;
				string comment = carrierShipmentDetail.Entries[0].Comments;
				ServiceHelper objServiceHelper = new ServiceHelper();
				mainView.Add(loadPop);
				var Result = await objServiceHelper.PostRequest("", methodURI, CommanUtil.tokenNo, true);
				if (Result != null && Result.Replace("\"", " ").Trim().ToUpper() == Constants.strSuccess.ToUpper())
				{
					loadPop.Hide();
					CommanUtil.shipClientIdBolNo = carrierShipmentDetail.ClientID + "|" + carrierShipmentDetail.BolNum + "|" + "2";
					string key = carrierShipmentDetail.ClientID + "|" + carrierShipmentDetail.BolNum + "|" + ConstantsClass.strBid;
					shipmentDetailController.RefreshShipmentDetail(key);
				}
				else
				{
					JObject response = JObject.Parse(Result);
					string Message = Convert.ToString(response[Constants.strErrorMessage]);
					if (!string.IsNullOrEmpty(Message))
					{
						ErrorPopup objErrorPopup = new ErrorPopup(mainView, Message, shipmentDetailController);
						UIView viewErrorpop = objErrorPopup.GetErrorPopup();
						mainView.Add(viewErrorpop);
						loadPop.Hide();
					}
				}
			}
			catch
			{
				loadPop.Hide();
				throw;
			}
		}

		/// <summary>
		/// Re-Submit Shipment
		/// </summary>
		private async Task ReSubmitShipment()
		{
			try
			{
				ServiceHelper objServiceHelper = new ServiceHelper();
				string id = CommanUtil.CompositeKey(carrierShipmentDetail.ClientID, carrierShipmentDetail.LocID, carrierShipmentDetail.BolNum);
				string methodURL = APIMethods.shipmentDetails + "/" + id + "/" + APIMethods.reSubmitShipment;
				CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
				if (loadPop == null)
				{
					loadPop = new LoadingOverlay(bounds);
				}
				var Result = await objServiceHelper.PostRequest("", methodURL, CommanUtil.tokenNo, true);
				mainView.Add(loadPop);
				if (Result != null && Result.Replace("\"", " ").Trim() == Constants.strSuccess)
				{
					CustomeConfirmationPopup objCustomeConfirmationPopup = new CustomeConfirmationPopup(mainView, Constants.reSubmitShipmentConfirm);
					UIView viewCustomepop = objCustomeConfirmationPopup.GetPopupScreen();
					mainView.Add(viewCustomepop);
				}
				else if (Result != null)
				{
					JObject response = JObject.Parse(Result);
					string Message = Convert.ToString(response[Constants.strErrorMessage]);
					if (!string.IsNullOrEmpty(Message))
					{
						ErrorPopup objErrorPopup = new ErrorPopup(mainView, Message, shipmentDetailController);
						UIView viewErrorpop = objErrorPopup.GetErrorPopup();
						mainView.Add(viewErrorpop);
						loadPop.Hide();
					}

				}
			}
			catch
			{
				loadPop.Hide();
				throw;
			}
		}


	}
}
