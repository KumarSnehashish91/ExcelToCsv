﻿using System;
using UIKit;
using CoreGraphics;
using RateLinx.Helper;
using Foundation;

namespace RateLinx.iOS
{
	public class WarningPopup
	{
		UIView mainView;
		string msgWarning;

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.WarningPopup"/> class.
		/// </summary>
		/// <param name="view">View.</param>
		/// <param name="msgWarning">Message warning.</param>
		public WarningPopup(UIView view, string msgWarning)
		{
			mainView = view;
			this.msgWarning = msgWarning;
		}

		/// <summary>
		/// Gets the warning pop.
		/// </summary>
		/// <returns>The warning pop.</returns>
		public UIView GetWarningPop()
		{
			UIView popupView = new UIView();
			popupView.Frame = mainView.Bounds;
			popupView.BackgroundColor = UIColor.Clear;

			UIView viewWarning = new UIView(new CGRect(10, 100, mainView.Frame.Width - 20, 170));
			viewWarning.BackgroundColor = UIColor.White;
			viewWarning.Layer.CornerRadius = 5;
			viewWarning.Layer.BorderWidth = 0.5f;

			UIView viewTopMargin = new UIView(new CGRect(0, 0, viewWarning.Frame.Width, 10));
			viewTopMargin.BackgroundColor = Constants.conversationHeadClr;
			viewTopMargin.Layer.CornerRadius = 5;

			UIView viewWarningHead = new UIView(new CGRect(0, 5, viewWarning.Frame.Width, 40));
			viewWarningHead.BackgroundColor = Constants.conversationHeadClr;

			UIImageView imageConfirm = new UIImageView(new CGRect(10, 8, 25, 20));
			imageConfirm.Image = UIImage.FromBundle("Images/warning.png");


			UILabel lblWarningHead = new UILabel(new CGRect(40, 6, viewWarning.Frame.Width - 100, 24));

			lblWarningHead.BackgroundColor = Constants.conversationHeadClr;
			lblWarningHead.Font = UIFont.FromName(Constants.strFontName, 15f);
			lblWarningHead.Text = NSBundle.MainBundle.LocalizedString("warning", null);
			lblWarningHead.TextColor = UIColor.White;

			UIButton btnPopupClose = new UIButton(new CGRect(viewWarning.Frame.Width - 25, 5, 25, 20));
			btnPopupClose.Layer.CornerRadius = 10;

			btnPopupClose.ContentMode = UIViewContentMode.Center;
			btnPopupClose.SetImage(UIImage.FromBundle("Images/error.PNG"), UIControlState.Normal);


			btnPopupClose.TouchUpInside += delegate
			{
				popupView.Hidden = true;
			};

			viewWarningHead.AddSubviews(imageConfirm, lblWarningHead, btnPopupClose);

			UIView viewWarningContent = new UIView(new CGRect(0, viewWarningHead.Frame.Y + viewWarningHead.Frame.Height, viewWarning.Frame.Width, 75));


			UILabel lblWarningMsg = new UILabel(new CGRect(10, 10, viewWarningContent.Frame.Width - 10, 35));
			lblWarningMsg.Font = UIFont.FromName(Constants.strFontName, 12f);
			lblWarningMsg.Lines = 0;
			lblWarningMsg.Text = msgWarning;

			viewWarningContent.AddSubviews(lblWarningMsg);

			UIView viewBottomSeparator = new UIView(new CGRect(0, viewWarningContent.Frame.Y + viewWarningContent.Frame.Height, viewWarning.Frame.Width, 0.5));
			viewBottomSeparator.BackgroundColor = Constants.conversationHeadClr;

			UIButton btnOk = new UIButton(new CGRect(viewWarning.Frame.Width - 90, viewWarning.Frame.Height - 40, 80, 30));
			btnOk.SetTitle(NSBundle.MainBundle.LocalizedString("okText", null), UIControlState.Normal);
			btnOk.BackgroundColor = Constants.btnColorBlue;
			btnOk.Layer.CornerRadius = 5;

			btnOk.TouchUpInside += delegate
			{
				popupView.Hidden = true;
			};

			//View.Add(popupView);
			viewWarning.AddSubviews(viewTopMargin, viewWarningHead, viewWarningContent, viewBottomSeparator, btnOk);
			popupView.AddSubview(viewWarning);


			popupView.Hidden = false;



			return popupView;
		}

	}
}

