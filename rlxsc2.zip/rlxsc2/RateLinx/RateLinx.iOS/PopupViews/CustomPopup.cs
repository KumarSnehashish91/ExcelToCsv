﻿using System;
using Foundation;
using UIKit;
using System.CodeDom.Compiler;
using CoreGraphics;
using RateLinx.iOS;
using System.Threading.Tasks;

namespace RateLinx.iOS
{
	public class CustomPopup : UIView
	{
		// control declarations

		UIView customPopupView;
		UIView backgroundView;
		//UIViewController objViewController;
		public CustomPopup(CGRect frame, string txtMessage, bool alertType, UIViewController ObjView, string btnParamNo, int NoLine) : base(frame)
		{
			Load(frame, txtMessage, alertType, ObjView, btnParamNo, NoLine);
		}

		public async void Load(CGRect frame, string txtMessage, bool alertType, UIViewController ObjView, string btnParamNo, int NoLine)
		{
			// configurable bits
			AutoresizingMask = UIViewAutoresizing.All;

			// derive the center x and y
			nfloat centerX = Frame.Width / 2;
			nfloat centerY = Frame.Height / 2;
			backgroundView = new UIView(new CGRect(0, 0, Frame.Size.Width, frame.Size.Height));
			UILabel lbldata;
			if (NoLine == 1)
			{
				customPopupView = new UIView(new CGRect(Frame.Width - 30, centerY, Frame.Width - 60, 50));
				lbldata = new UILabel(new CGRect(10, 0, customPopupView.Frame.Width - 20, 50));
			}
			else
			{
				customPopupView = new UIView(new CGRect(centerX / 6, centerY, centerX + 105, 50));
				lbldata = new UILabel(new CGRect(10, 0, customPopupView.Frame.Width - 20, 50));
			}

			//customPopupView.BackgroundColor =UIColor.FromRGB ((int)ConfigEntity.EPColorHeader.Red, (int)ConfigEntity.EPColorHeader.Green, (int)ConfigEntity.EPColorHeader.Blue);
			//customPopupView.Layer.BorderColor = UIColor.FromRGB ((int)ConfigEntity.EPColorHeader.Red, (int)ConfigEntity.EPColorHeader.Green, (int)ConfigEntity.EPColorHeader.Blue).CGColor;
			//customPopupView.Layer.BorderWidth = 1.0f;
			customPopupView.Layer.CornerRadius = 10;
			customPopupView.Layer.MasksToBounds = false;

			//lbldata.Font = UIFont.FromName ("gothic.ttf", 16.5f);
			lbldata.Text = txtMessage;
			lbldata.TextColor = UIColor.White;
			lbldata.TextAlignment = UITextAlignment.Center;
			lbldata.Lines = 0;
			lbldata.LineBreakMode = UILineBreakMode.WordWrap;

			if (alertType)
			{
				customPopupView.AddSubviews(lbldata);
			}
			//customPopupView.AutoresizingMask = UIViewAutoresizing.All;
			customPopupView.Center = this.Center;
			customPopupView.Frame = new CGRect(customPopupView.Frame.X, backgroundView.Frame.Height - 150, customPopupView.Frame.Width, customPopupView.Frame.Height);
			customPopupView.BackgroundColor = UIColor.DarkGray;
			backgroundView.AddSubview(customPopupView);
			backgroundView.Center = this.Center;
			AddSubview(backgroundView);
			await Task.Delay(2000);
			Hide();
		}

		/// <summary>
		/// Fades out the control and then removes it from the super view
		/// </summary>
		public void Hide()
		{
			//if (objViewController != null)
			//objViewController.NavigationController.PopViewController (true);
			UIView.Animate(
				0.5, // duration
				() =>
				{
					Alpha = 0;
				},
				() =>
				{
					RemoveFromSuperview();
				}
			);
		}
	}
}
