﻿using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;
using System.Collections.Generic;
using CoreGraphics;
using RateLinx.Helper;
using RateLinx.Models;

namespace RateLinx.iOS
{
	public class ConversationHeadingPopup
	{
		public ConversationHeadingPopup(UIView view, Entry objEntry)
		{
			
		}

		public UIView GetPopupScreen()
		{
			UIView viewConversationSubject = new UIView();


			return viewConversationSubject;
		}

	}
}
