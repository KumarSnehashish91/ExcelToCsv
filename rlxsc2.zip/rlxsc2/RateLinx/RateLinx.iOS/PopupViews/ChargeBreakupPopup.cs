﻿using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;
using System.Collections.Generic;
using CoreGraphics;
using RateLinx.Helper;
using RateLinx.Models;


namespace RateLinx.iOS
{
	public class ChargeBreakupPopup
	{
		UIView mainView;
		Entry objEntry;

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.ChargeBreakupPopup"/> class.
		/// </summary>
		/// <param name="view">View.</param>
		/// <param name="objEntry">Object entry.</param>
		public ChargeBreakupPopup(UIView view, Entry objEntry)
		{
			mainView = view;
			this.objEntry = objEntry;
		}
		/// <summary>
		/// Gets the popup screen.
		/// </summary>
		/// <returns>The popup screen.</returns>
		public UIView GetPopupScreen()
		{
			try
			{
				Constants.isRateEntry = true;
				UIView popupView = new UIView();
				popupView.Frame = mainView.Bounds;
				popupView.BackgroundColor = UIColor.Clear;
				UIView viewChargeBreakup = new UIView(new CGRect(10, 100, mainView.Frame.Width - 20, 200));
				viewChargeBreakup.BackgroundColor = UIColor.White;
				viewChargeBreakup.Layer.CornerRadius = 5;
				viewChargeBreakup.Layer.BorderWidth = 0.5f;
				UIView viewTopMargin = new UIView(new CGRect(0, 0, viewChargeBreakup.Frame.Width, 10));
				viewTopMargin.BackgroundColor = Constants.conversationHeadClr;
				viewTopMargin.Layer.CornerRadius = 5;
				UIView viewChargesDetailHead = new UIView(new CGRect(0, 5, viewChargeBreakup.Frame.Width, 40));
				viewChargesDetailHead.BackgroundColor = Constants.conversationHeadClr;
				UILabel lblChargesDetailHead = new UILabel(new CGRect(10, 6, viewChargeBreakup.Frame.Width - 30, 24));
				lblChargesDetailHead.BackgroundColor = Constants.conversationHeadClr;
				lblChargesDetailHead.Font = UIFont.FromName(Constants.strFontName, 15f);
				lblChargesDetailHead.Text = NSBundle.MainBundle.LocalizedString("rateEntryDetail", null);
				lblChargesDetailHead.TextColor = UIColor.White;
				UIButton btnPopupClose = new UIButton(new CGRect(viewChargeBreakup.Frame.Width - 25, 5, 25, 20));
				btnPopupClose.Layer.CornerRadius = 10;

				btnPopupClose.ContentMode = UIViewContentMode.Center;
				btnPopupClose.SetImage(UIImage.FromBundle("Images/error.PNG"), UIControlState.Normal);


				btnPopupClose.TouchUpInside += delegate
				{
					popupView.Hidden = true;
				};
				viewChargesDetailHead.AddSubviews(lblChargesDetailHead, btnPopupClose);
				UIView viewRateEntryContent = new UIView(new CGRect(0, viewChargesDetailHead.Frame.Y + viewChargesDetailHead.Frame.Height, viewChargeBreakup.Frame.Width, 105));
				UIView viewBasecharge = new UIView(new CGRect(20, 15, viewRateEntryContent.Frame.Width - 40, 25));
				viewBasecharge.BackgroundColor = Constants.tableRowOddColor;
				UILabel lblbaseChargeLabel = new UILabel(new CGRect(5, 0, viewBasecharge.Frame.Width / 2 - 5, 25));
				lblbaseChargeLabel.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblbaseChargeLabel.Text = objEntry.Charges[1].ID;
				UILabel lblbaseCharge = new UILabel(new CGRect(viewBasecharge.Frame.Width / 2, 0, viewBasecharge.Frame.Width / 2, 25));
				lblbaseCharge.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblbaseCharge.Text = "$" + Convert.ToString(objEntry.Charges[1].Value);
				lblbaseCharge.TextAlignment = UITextAlignment.Center;
				viewBasecharge.AddSubviews(lblbaseChargeLabel, lblbaseCharge);


				UIView viewAccessorialCharge = new UIView(new CGRect(20, 40, viewRateEntryContent.Frame.Width - 40, 0));
				viewAccessorialCharge.Frame = new CGRect(20, 40, viewRateEntryContent.Frame.Width - 40, 25);
				UILabel lblAccessorialChargeLabel = new UILabel(new CGRect(5, 0, viewAccessorialCharge.Frame.Width / 2 - 5, 25));
				lblAccessorialChargeLabel.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblAccessorialChargeLabel.Text = objEntry.Charges[0].ID;

				UILabel lblAccessorialCharge = new UILabel(new CGRect(viewAccessorialCharge.Frame.Width / 2, 0, viewAccessorialCharge.Frame.Width / 2, 25));
				lblAccessorialCharge.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblAccessorialCharge.Text = "$" + Convert.ToString(objEntry.Charges[0].Value);
				lblAccessorialCharge.TextAlignment = UITextAlignment.Center;

				viewAccessorialCharge.AddSubviews(lblAccessorialChargeLabel, lblAccessorialCharge);
				viewAccessorialCharge.BackgroundColor = Constants.tableRowEvenColor;


				UIView viewFuelCharge = new UIView(new CGRect(0, 0, 0, 0));
				if (objEntry.Charges.Count > 2)
				{
					viewFuelCharge.Frame = new CGRect(20, 65, viewRateEntryContent.Frame.Width - 40, 25);
					viewFuelCharge.BackgroundColor = Constants.tableRowOddColor;
					UILabel lblFuelChargeLabel = new UILabel(new CGRect(5, 0, viewFuelCharge.Frame.Width / 2 - 5, 25));
					lblFuelChargeLabel.Font = UIFont.FromName(Constants.strFontName, 12f);
					lblFuelChargeLabel.Text = objEntry.Charges[2].ID;
					UILabel lblFuelCharge = new UILabel(new CGRect(viewFuelCharge.Frame.Width / 2, 0, viewFuelCharge.Frame.Width / 2, 25));
					lblFuelCharge.Font = UIFont.FromName(Constants.strFontName, 12f);
					lblFuelCharge.Text = "$" + Convert.ToString(objEntry.Charges[2].Value);
					lblFuelCharge.TextAlignment = UITextAlignment.Center;
					viewFuelCharge.AddSubviews(lblFuelChargeLabel, lblFuelCharge);
				}
				viewRateEntryContent.AddSubviews(viewBasecharge, viewAccessorialCharge, viewFuelCharge);
				UIView viewBottomSeparator = new UIView(new CGRect(0, viewRateEntryContent.Frame.Y + viewRateEntryContent.Frame.Height, viewChargeBreakup.Frame.Width, 0.5));
				viewBottomSeparator.BackgroundColor = Constants.conversationHeadClr;
				UIButton btnOk = new UIButton(new CGRect(viewChargeBreakup.Frame.Width - 60, viewChargeBreakup.Frame.Height - 40, 50, 30));
				btnOk.SetTitle(NSBundle.MainBundle.LocalizedString("okText", null), UIControlState.Normal);
				btnOk.BackgroundColor = Constants.btnColorBlue;
				btnOk.Layer.CornerRadius = 5;
				//btnOk.Layer.BorderWidth = 2;
				btnOk.TouchUpInside += delegate
				{
					popupView.Hidden = true;
				};
				//View.Add(popupView);
				viewChargeBreakup.AddSubviews(viewTopMargin, viewChargesDetailHead, viewRateEntryContent, viewBottomSeparator, btnOk);
				popupView.AddSubview(viewChargeBreakup);
				popupView.Hidden = false;
				return popupView;
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
				return null;
			}
		}

	}
}
