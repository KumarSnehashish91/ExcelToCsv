﻿using System;
using System.Collections;
using System.Collections.Generic;
using CoreGraphics;
using RateLinx.Helper;
using RateLinx.Models;
using UIKit;
using System.Linq;
using Foundation;

namespace RateLinx.iOS
{
	public class ComposeToPopup
	{
		UIView mainView;
		//List<string> composeTo;
		//CommanUtil commanClass = new CommanUtil();

		List<AllowedConversationToList> AllowedConversationToList = null;
	
		UITextView btnSelectedItem;


		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.ComposeToPopup"/> class.
		/// </summary>
		/// <param name="view">View.</param>
		/// <param name="AllowedConversationToList">Allowed conversation to list.</param>
		/// <param name="btnSelectedItem">Button selected item.</param>
		public ComposeToPopup(UIView view, List<AllowedConversationToList> AllowedConversationToList, UITextView btnSelectedItem)
		{
			mainView = view;
			this.AllowedConversationToList = AllowedConversationToList;

			this.btnSelectedItem = btnSelectedItem;
		}

		/// <summary>
		/// Gets the popup screen.
		/// </summary>
		/// <returns>The popup screen.</returns>
		public UIView GetPopupScreen()
		{
			try
			{
				UIView popupView = new UIView();
				popupView.Frame = mainView.Bounds;
				popupView.BackgroundColor = UIColor.Clear;

				UIView viewComposeToPopup = new UIView(new CGRect(10, 100, mainView.Frame.Width - 20, 135));
				viewComposeToPopup.BackgroundColor = UIColor.White;
				viewComposeToPopup.Layer.CornerRadius = 5;
				viewComposeToPopup.Layer.BorderWidth = 0.5f;

				UIView viewTopMargin = new UIView(new CGRect(0, 0, viewComposeToPopup.Frame.Width, 10));
				//viewTopMargin.BackgroundColor = Constants.conversationHeadClr;
				viewTopMargin.Layer.CornerRadius = 5;
				viewTopMargin.Layer.BorderWidth = 0.0f;

				UITableView tblComposeTo = new UITableView(new CGRect(0, 10, viewComposeToPopup.Frame.Width, 50));
				tblComposeTo.RowHeight = 30;
				tblComposeTo.Bounces = false;
				tblComposeTo.TableFooterView = new UIView(CGRect.Empty);

				if (AllowedConversationToList.Count == 1)
				{
					tblComposeTo.Frame = new CGRect(0, 10, viewComposeToPopup.Frame.Width, 50);
				}
				else if (AllowedConversationToList.Count <= 10)
				{
					tblComposeTo.Frame = new CGRect(0, 10, viewComposeToPopup.Frame.Width, AllowedConversationToList.Count * 30);
				}
				else
				{
					tblComposeTo.Frame = new CGRect(0, 10, viewComposeToPopup.Frame.Width, 300);
				}
				tblComposeTo.AllowsSelection = false;

				tblComposeTo.Source = new ComposeToListAdapter(AllowedConversationToList);

				UIView viewBottomSeparator = new UIView(new CGRect(0, tblComposeTo.Frame.Bottom + 20, viewComposeToPopup.Frame.Width, 0.5));
				viewBottomSeparator.BackgroundColor = Constants.conversationHeadClr;

				UIButton btnOk = new UIButton(new CGRect(viewComposeToPopup.Frame.Width - 70, viewBottomSeparator.Frame.Bottom + 10, 50, 25));
				btnOk.SetTitle(NSBundle.MainBundle.LocalizedString("okText", null), UIControlState.Normal);
				btnOk.BackgroundColor = Constants.btnColorBlue;
				btnOk.Layer.CornerRadius = 5;
				//btnOk.Layer.BorderWidth = 2;


				UIButton btnCancel = new UIButton(new CGRect(viewComposeToPopup.Frame.Width - 150, viewBottomSeparator.Frame.Bottom + 10, 70, 25));
				btnCancel.SetTitle(NSBundle.MainBundle.LocalizedString("cancel", null), UIControlState.Normal);
				btnCancel.BackgroundColor = UIColor.White;
				btnCancel.SetTitleColor(UIColor.Black, UIControlState.Normal);
				btnCancel.Layer.CornerRadius = 5;
				btnCancel.Layer.BorderWidth = 1;

				btnCancel.TouchUpInside += delegate
				{
					popupView.Hidden = true;
				};

				btnOk.TouchUpInside += delegate
				{
					MaintainSelectedList();
					popupView.Hidden = true;
				};

				viewComposeToPopup.Frame = new CGRect(10, 100, mainView.Frame.Width - 20, btnOk.Frame.Bottom + 10);
				viewComposeToPopup.AddSubviews(viewTopMargin, tblComposeTo, viewBottomSeparator, btnOk, btnCancel);
				popupView.AddSubview(viewComposeToPopup);
				popupView.Hidden = false;
				return popupView;
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
				return null;
			}
		}

		/// <summary>
		/// Maintains the selected list.
		/// </summary>
		void MaintainSelectedList()
		{
			try
			{
				int AllowedListCount = 0;
				foreach (CustomerConversationList objAllowed in CommanUtil.lstAllowedConversationList)
				{

					for (int count = 0; count < AllowedConversationToList.Count; count++)
					{
						if (AllowedConversationToList[count].Value == objAllowed.Value)
						{
							AllowedConversationToList[count].Action = objAllowed.Action;
						}
					}
				}
				AllowedListCount = AllowedConversationToList.Where(objList => objList.Action == true).Count();


				if (AllowedListCount == 1)
				{

					btnSelectedItem.Text = AllowedConversationToList.Where(objList => objList.Action == true).FirstOrDefault().Value;
				}
				else
				{
					btnSelectedItem.Text = Convert.ToString(AllowedListCount) + NSBundle.MainBundle.LocalizedString("selected", null);
				}
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}

		}
}
}
