﻿using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;
using System.Collections.Generic;
using CoreGraphics;
using RateLinx.Helper;
using RateLinx.Models;
using RateLinx.APIs;
using Newtonsoft.Json;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace RateLinx.iOS
{
	public class DenyShipmentPopup
	{

		#region Variable Declaration

		UIView mainView;
		CarrierShipmentDetails carrierShipmentDetail;
		ShipmentDetailController shipmentDetailController;
		UITextView txtDenyReason;
		UIView popupView;
		CustomPopup customAlert = null;
		LoadingOverlay loadPop;

		#endregion

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.DenyShipmentPopup"/> class.
		/// </summary>
		/// <param name="view">View.</param>
		/// <param name="carrierShipmentDetail">Carrier shipment detail.</param>
		/// <param name="shipmentDetailController">Shipment detail controller.</param>
		public DenyShipmentPopup(UIView view, CarrierShipmentDetails carrierShipmentDetail, ShipmentDetailController shipmentDetailController)
		{
			mainView = view;
			this.carrierShipmentDetail = carrierShipmentDetail;
			this.shipmentDetailController = shipmentDetailController;
		}

		/// <summary>
		/// Gets the popup screen.
		/// </summary>
		/// <returns>The popup screen.</returns>
		public UIView GetPopupScreen()
		{
			try
			{
				popupView = new UIView();
				popupView.Frame = mainView.Bounds;
				popupView.BackgroundColor = UIColor.Clear;

				UIView viewDenyShipment = new UIView(new CGRect(10, 100, mainView.Frame.Width - 20, 200));
				viewDenyShipment.BackgroundColor = UIColor.White;
				viewDenyShipment.Layer.CornerRadius = 5;
				viewDenyShipment.Layer.BorderWidth = 0.5f;

				UIView viewTopMargin = new UIView(new CGRect(0, 0, viewDenyShipment.Frame.Width, 10));
				viewTopMargin.BackgroundColor = Constants.conversationHeadClr;
				viewTopMargin.Layer.CornerRadius = 5;

				UIView viewDenyShipmentHead = new UIView(new CGRect(0, 5, viewDenyShipment.Frame.Width, 40));
				viewDenyShipmentHead.BackgroundColor = Constants.conversationHeadClr;

				UILabel lblDenyShipmentHead = new UILabel(new CGRect(10, 6, viewDenyShipment.Frame.Width - 100, 24));

				lblDenyShipmentHead.BackgroundColor = Constants.conversationHeadClr;
				lblDenyShipmentHead.Font = UIFont.FromName(Constants.strFontName, 15f);
				lblDenyShipmentHead.Text = NSBundle.MainBundle.LocalizedString("denyShipment", null);
				lblDenyShipmentHead.TextColor = UIColor.White;

				UIButton btnPopupClose = new UIButton(new CGRect(viewDenyShipment.Frame.Width - 25, 5, 25, 20));
				btnPopupClose.Layer.CornerRadius = 10;

				btnPopupClose.ContentMode = UIViewContentMode.Center;
				btnPopupClose.SetImage(UIImage.FromBundle("Images/error.PNG"), UIControlState.Normal);



				btnPopupClose.TouchUpInside += delegate
				{
					popupView.Hidden = true;
				};

				viewDenyShipmentHead.AddSubviews(lblDenyShipmentHead, btnPopupClose);

				UIView viewDenyShipmentContent = new UIView(new CGRect(0, viewDenyShipmentHead.Frame.Y + viewDenyShipmentHead.Frame.Height, viewDenyShipment.Frame.Width, 105));


				UILabel lblDenyReason = new UILabel(new CGRect(10, 10, viewDenyShipmentContent.Frame.Width - 10, 35));
				lblDenyReason.Font = UIFont.FromName(Constants.strFontName, 13f);
				lblDenyReason.Lines = 0;
				lblDenyReason.Text = NSBundle.MainBundle.LocalizedString("enterDeniedReason", null);

				UILabel lblEnterReason = new UILabel(new CGRect(10, 50, viewDenyShipmentContent.Frame.Width / 2 - 10, 25));
				lblEnterReason.Font = UIFont.FromName(Constants.strFontName, 13f);
				lblEnterReason.Text = NSBundle.MainBundle.LocalizedString("enterReason", null);

				txtDenyReason = new UITextView(new CGRect(viewDenyShipmentContent.Frame.Width / 2, 50, viewDenyShipmentContent.Frame.Width / 2 - 10, 25));
				txtDenyReason.Layer.BorderWidth = 1;
				txtDenyReason.Layer.CornerRadius = 5;

				viewDenyShipmentContent.AddSubviews(lblDenyReason, lblEnterReason, txtDenyReason);

				UIView viewBottomSeparator = new UIView(new CGRect(0, viewDenyShipmentContent.Frame.Y + viewDenyShipmentContent.Frame.Height, viewDenyShipment.Frame.Width, 0.5));
				viewBottomSeparator.BackgroundColor = Constants.conversationHeadClr;

				UIButton btnCancel = new UIButton(new CGRect(viewDenyShipment.Frame.Width - 90, viewDenyShipment.Frame.Height - 40, 80, 30));
				btnCancel.SetTitle(NSBundle.MainBundle.LocalizedString("cancel", null), UIControlState.Normal);
				btnCancel.BackgroundColor = Constants.btnColorBlue;
				btnCancel.Layer.CornerRadius = 5;

				UIButton btnConfirm = new UIButton(new CGRect(viewDenyShipment.Frame.Width - 180, viewDenyShipment.Frame.Height - 40, 80, 30));
				btnConfirm.SetTitle(NSBundle.MainBundle.LocalizedString("Confirm", null), UIControlState.Normal);
				btnConfirm.SetTitleColor(UIColor.Black, UIControlState.Normal);

				btnConfirm.BackgroundColor = UIColor.White;
				btnConfirm.Layer.CornerRadius = 5;
				btnConfirm.Layer.BorderWidth = 0.5f;
				btnCancel.TouchUpInside += delegate
				{
					popupView.Hidden = true;
				};
				btnConfirm.TouchUpInside += async delegate
				{
					await AcceptDenyShip();
				};
				viewDenyShipment.AddSubviews(viewTopMargin, viewDenyShipmentHead, viewDenyShipmentContent, viewBottomSeparator, btnCancel, btnConfirm);
				popupView.AddSubview(viewDenyShipment);


				popupView.Hidden = false;
				return popupView;
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Accept And Deny Shipment
		/// </summary>
		public async Task AcceptDenyShip()
		{
			try
			{
				int bidId = carrierShipmentDetail.Entries[0].ID;
				if (string.IsNullOrEmpty(txtDenyReason.Text))
				{
                    this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strEnterProNo, true, shipmentDetailController, "", 1);
					this.mainView.Add(this.customAlert);
				}
				else
				{
					CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
					if (loadPop == null)
					{
						loadPop = new LoadingOverlay(bounds);
					}
					mainView.Add(loadPop);
					ServiceHelper objServiceHelper = new ServiceHelper();
					string denyToken = CommanUtil.tokenNo;
					string id = CommanUtil.CompositeKey(carrierShipmentDetail.ClientID, carrierShipmentDetail.LocID, carrierShipmentDetail.BolNum);
					string denyURI = APIMethods.shipmentDetails + "/" + id + "/" + bidId + "/" + APIMethods.deny;
					string payLoad = "{" + "\"DenyReason\"" + ":" + "\"" + txtDenyReason.Text + "\"" + "}";
					var Result = await objServiceHelper.PostRequestJson(payLoad, denyURI, denyToken, true);
					if (Result != null && Result.Replace("\"", " ").Trim().ToUpper() == Constants.strSuccess.ToUpper())
					{
						loadPop.Hide();
						popupView.Hidden = true;
						string key = carrierShipmentDetail.ClientID + "|" + carrierShipmentDetail.BolNum + "|" + ConstantsClass.strBid;
						shipmentDetailController.RefreshShipmentDetail(key);
					}
					else
					{
						JObject response = JObject.Parse(Result);
						string Message = Convert.ToString(response[Constants.strErrorMessage]);
						if (!string.IsNullOrEmpty(Message))
						{
							ErrorPopup objErrorPopup = new ErrorPopup(mainView, Message, shipmentDetailController);
							UIView viewErrorpop = objErrorPopup.GetErrorPopup();
							mainView.Add(viewErrorpop);
							loadPop.Hide();
							popupView.Hidden = true;
						}
					}
				}
			}
			catch
			{
				loadPop.Hide();
			}
		}

	}
}
