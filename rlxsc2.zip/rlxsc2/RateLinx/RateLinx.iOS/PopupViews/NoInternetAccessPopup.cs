﻿using System;
using UIKit;
using CoreGraphics;
using RateLinx.Helper;
using Foundation;

namespace RateLinx.iOS
{
	public class NoInternetAccessPopup
	{
		UIView mainView;
		UINavigationController navigationController;

		public NoInternetAccessPopup(UIView view, UINavigationController navigationController)
		{
			this.navigationController = navigationController;
			mainView = view;
		}

		/// <summary>
		/// Gets the error popup.
		/// </summary>
		/// <returns>The error popup.</returns>
		public UIView GetErrorPopup()
		{
			try
			{
				UIView popupView = new UIView();
				popupView.Frame = mainView.Bounds;
				popupView.BackgroundColor = UIColor.Clear;

				UIView viewError = new UIView(new CGRect(10, 100, mainView.Frame.Width - 20, 170));
				viewError.BackgroundColor = UIColor.White;
				viewError.Layer.CornerRadius = 5;
				viewError.Layer.BorderWidth = 0.5f;

				UIView viewTopMargin = new UIView(new CGRect(0, 0, viewError.Frame.Width, 10));
				viewTopMargin.BackgroundColor = Constants.conversationHeadClr;
				viewTopMargin.Layer.CornerRadius = 5;

				UIView viewErrorHead = new UIView(new CGRect(0, 5, viewError.Frame.Width, 40));
				viewErrorHead.BackgroundColor = Constants.conversationHeadClr;

				UIImageView imageConfirm = new UIImageView(new CGRect(10, 8, 25, 20));
				imageConfirm.Image = UIImage.FromBundle("Images/warning.png");


				UILabel lblErrorHead = new UILabel(new CGRect(40, 6, viewError.Frame.Width - 100, 24));

				lblErrorHead.BackgroundColor = Constants.conversationHeadClr;
				lblErrorHead.Font = UIFont.FromName(Constants.strFontName, 15f);
				lblErrorHead.Text = NSBundle.MainBundle.LocalizedString("warning", null);
				lblErrorHead.TextColor = UIColor.White;

				UIButton btnPopupClose = new UIButton(new CGRect(viewError.Frame.Width - 25, 5, 25, 20));
				btnPopupClose.Layer.CornerRadius = 10;

				btnPopupClose.ContentMode = UIViewContentMode.Center;
				btnPopupClose.SetImage(UIImage.FromBundle("Images/error.PNG"), UIControlState.Normal);



				btnPopupClose.TouchUpInside += delegate
				{

					UIStoryboard board = UIStoryboard.FromName("Main", null);
					var dashboardController = (DashboardController)board.InstantiateViewController("DashboardController");
					popupView.Hidden = true;
					dashboardController.RedirectToLogin(navigationController);

				};

				viewErrorHead.AddSubviews(imageConfirm, lblErrorHead, btnPopupClose);

				UIView viewErrorContent = new UIView(new CGRect(0, viewErrorHead.Frame.Y + viewErrorHead.Frame.Height, viewError.Frame.Width, 75));


				UILabel lblErrorMsg = new UILabel(new CGRect(10, 10, viewErrorContent.Frame.Width - 10, 55));
				lblErrorMsg.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblErrorMsg.Lines = 0;
				lblErrorMsg.Text = Constants.isOnline;

				viewErrorContent.AddSubviews(lblErrorMsg);

				UIView viewBottomSeparator = new UIView(new CGRect(0, viewErrorContent.Frame.Y + viewErrorContent.Frame.Height, viewError.Frame.Width, 0.5));
				viewBottomSeparator.BackgroundColor = Constants.conversationHeadClr;

				UIButton btnOk = new UIButton(new CGRect(viewError.Frame.Width - 90, viewError.Frame.Height - 40, 80, 30));
				btnOk.SetTitle(NSBundle.MainBundle.LocalizedString("okText", null), UIControlState.Normal);
				btnOk.BackgroundColor = Constants.btnColorBlue;
				btnOk.Layer.CornerRadius = 5;

				btnOk.TouchUpInside += delegate
				{
					UIStoryboard board = UIStoryboard.FromName("Main", null);
					var dashboardController = (DashboardController)board.InstantiateViewController("DashboardController");
					popupView.Hidden = true;
					dashboardController.RedirectToLogin(navigationController);
				};
				viewError.AddSubviews(viewTopMargin, viewErrorHead, viewErrorContent, viewBottomSeparator, btnOk);
				popupView.AddSubview(viewError);
				popupView.Hidden = false;
				return popupView;
			}
			catch
			{
				throw;
			}

		}
	}
}
