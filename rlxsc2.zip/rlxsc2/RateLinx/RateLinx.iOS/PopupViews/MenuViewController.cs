﻿using System;
using System.Threading.Tasks;
using CoreGraphics;
using Foundation;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RateLinx.APIs;
using RateLinx.Helper;
using UIKit;

namespace RateLinx.iOS
{
	public class MenuViewController : UIView
	{
        void HandleFunc()
        {
        }


		#region Global used variables
		UIView parentView;
		UITapGestureRecognizer tapGestureFacebook, tapGestureTwitter, tapGestureLnkdn, tapGestureYoutube, tapGestureGPlus, 
        tapGestureRSS,tapGestureHome,tapGestureRateHistory,tapGestureDailyOrder,tapGestureDashboard,
        tapGestureNews,tapGestureFeedback,tapGestureAbout,tapGestureNotification,tapGestureLogout= null;
		UIImageView imgFaceBook, imgTwitter, imgYoutube, imgLnkdn, imgGPlus, imgRSS;
        UIView homeUI,rateHistoryUI,dailyOrderUI,dashboardUI,newsUI,feedbackUI,aboutUI,notificationUI,logoutUI;
		UISwitch switchNotification;
		UIWebView webView = null;
		ServiceHelper objServicehelper = null;
		string methodName = string.Empty;
		string strResponse = string.Empty;
		string redirectURL = string.Empty;
		JObject jobject = null;
		HelpAndFeedbackController objHelpAndFeedbackController;
		DashboardController objDashboardController;
		RateHistoryController objRateHistoryController;
		HistoryResultController objHistoryResultController;
        OrderHistoryController objOrderHistoryController;
		#endregion

		public MenuViewController(UIView parentView)
		{
			this.parentView = parentView;
		}

        public UIView DisplayMenuView(HelpAndFeedbackController objHelpAndFeedbackController, 
                                      DashboardController objDashboardController, RateHistoryController objRateHistoryController, HistoryResultController objHistoryResultController, OrderHistoryController objOrderHistoryController, UIImageView imgMenu)
        {
            try
            {
                this.objHelpAndFeedbackController = objHelpAndFeedbackController;
                this.objDashboardController = objDashboardController;
                this.objRateHistoryController = objRateHistoryController;
                this.objHistoryResultController = objHistoryResultController;
                this.objOrderHistoryController = objOrderHistoryController;
                UIView menuParentView = new UIView(new CGRect(-1000, 0, parentView.Frame.Width, parentView.Frame.Height));
                menuParentView.BackgroundColor = UIColor.Clear;
                nfloat menuViewWidth;
                if (parentView.Frame.Width > 414)
                {
                    menuViewWidth = 400;
                }
                else
                {
                    menuViewWidth = parentView.Frame.Width / 10 * 8;
                }
                UIView menuView = new UIView();
                if (parentView.Frame.Height == 812)
                {
                    menuView.Frame = new CGRect(0, 45, menuViewWidth, parentView.Frame.Height - 80);
                }
                else
                {
                    menuView.Frame = new CGRect(0, 20, menuViewWidth, parentView.Frame.Height - 20);
                }

                menuParentView.AddSubview(menuView);



                //UIView viewDivider1 = new UIView(new CGRect(0, 40, menuView.Frame.Width, 1));
                //viewDivider1.BackgroundColor = UIColor.White;


                UIScrollView menuScrollView = new UIScrollView(new CGRect(0, 41, menuView.Frame.Width, menuView.Frame.Height - 91));

                UIView viewLinkContainer = new UIView(new CGRect(0, 0, menuView.Frame.Width, 620));

                menuScrollView.ContentSize = new CGSize(menuView.Frame.Width, viewLinkContainer.Frame.Height);

                nfloat yCordinate = 0;

                UIImageView imgMenuHeader = new UIImageView(new CGRect(60, 0, menuView.Frame.Width - 120, 120));
                imgMenuHeader.Image = new UIImage("Images/logo.png");
                imgMenuHeader.BackgroundColor = UIColor.White;


                UIView headerUI=new UIImageView(new CGRect(0, yCordinate, menuView.Frame.Width, 120));
                headerUI.AddSubviews(imgMenuHeader);
                headerUI.BackgroundColor = UIColor.White;

                yCordinate += headerUI.Frame.Height;

                UIView viewDivider1 = new UIView(new CGRect(0, yCordinate + 40, menuView.Frame.Width, 1));
                viewDivider1.BackgroundColor = UIColor.White;
                yCordinate += 1;

                UIImageView imgHome = new UIImageView(new CGRect(20,  10, 30, 30));
                imgHome.Image = new UIImage("Images/home.png");
                UIButton btnHome = new UIButton(new CGRect(80, 0, menuView.Frame.Width - 20, 50));//height = menuView.Frame.Height * 0.070
                btnHome.SetTitle("Home", UIControlState.Normal);
                btnHome.HorizontalAlignment = UIControlContentHorizontalAlignment.Left;
                btnHome.TouchUpInside += delegate
                {
                    //Util.isMenuVisible = false;
                    //imgMenu.UserInteractionEnabled = true;

                    //RedirectToHome();
                    SidebarMenuTapGesture(tapGestureHome);
                };
                homeUI = new UIView(new CGRect(0, yCordinate, menuView.Frame.Width, 50));
                homeUI.AddSubviews(imgHome, btnHome);
                tapGestureHome = new UITapGestureRecognizer(SidebarMenuTapGesture);
                homeUI.AddGestureRecognizer(tapGestureHome);
                homeUI.UserInteractionEnabled = true;

                yCordinate += btnHome.Frame.Height;

                UIView viewDivider2 = new UIView(new CGRect(0, yCordinate, menuView.Frame.Width, 1));
                viewDivider2.BackgroundColor = UIColor.White;

                yCordinate += 1;


                UIImageView imgRateHistory = new UIImageView(new CGRect(20,  10, 30, 30));
                imgRateHistory.Image = new UIImage("Images/rate_history.png");
                UIButton btnRateHistory = new UIButton(new CGRect(80, 0, menuView.Frame.Width - 20, 50));
                btnRateHistory.SetTitle("Rate History", UIControlState.Normal);
                btnRateHistory.HorizontalAlignment = UIControlContentHorizontalAlignment.Left;
                btnRateHistory.TouchUpInside += delegate
                {
                    //Util.isMenuVisible = false;
                    //imgMenu.UserInteractionEnabled = true;

                    //RedirectToRateHistory();
                    SidebarMenuTapGesture(tapGestureRateHistory);
                };
                rateHistoryUI = new UIView(new CGRect(0, yCordinate, menuView.Frame.Width, 50));
                rateHistoryUI.AddSubviews(imgRateHistory, btnRateHistory);
                tapGestureRateHistory = new UITapGestureRecognizer(SidebarMenuTapGesture);
                rateHistoryUI.AddGestureRecognizer(tapGestureRateHistory);
                rateHistoryUI.UserInteractionEnabled = true;

                yCordinate += btnRateHistory.Frame.Height;

                UIView viewDivider3 = new UIView(new CGRect(0, yCordinate, menuView.Frame.Width, 1));
                viewDivider3.BackgroundColor = UIColor.White;

                yCordinate += 1;

                UIImageView imgDailyOrder = new UIImageView(new CGRect(20,  10, 30, 30));
                imgDailyOrder.Image = new UIImage("Images/Daily_orders.png");

                #region New Menu "Order History"
                UIButton btnOrderHistory = new UIButton(new CGRect(80, 0, menuView.Frame.Width - 20, 50));
                btnOrderHistory.SetTitle("Daily Orders", UIControlState.Normal);
                btnOrderHistory.HorizontalAlignment = UIControlContentHorizontalAlignment.Left;
                btnOrderHistory.TouchUpInside += delegate
                {
                    //Util.isMenuVisible = false;
                    //imgMenu.UserInteractionEnabled = true;

                    //RedirectToOrderHistory();
                    SidebarMenuTapGesture(tapGestureDailyOrder);
                };
                dailyOrderUI = new UIView(new CGRect(0, yCordinate, menuView.Frame.Width, 50));
                dailyOrderUI.AddSubviews(imgDailyOrder, btnOrderHistory);
                tapGestureDailyOrder = new UITapGestureRecognizer(SidebarMenuTapGesture);
                dailyOrderUI.AddGestureRecognizer(tapGestureDailyOrder);
                dailyOrderUI.UserInteractionEnabled = true;

                yCordinate += btnOrderHistory.Frame.Height;

                UIView viewDividerOrder = new UIView(new CGRect(0, yCordinate, menuView.Frame.Width, 1));
                viewDividerOrder.BackgroundColor = UIColor.White;

                yCordinate += 1;
                #endregion

                UIImageView imgDashboard = new UIImageView(new CGRect(20,  10, 30, 30));
                imgDashboard.Image = new UIImage("Images/dashboard.png");

                UIButton btnDashBoard = new UIButton(new CGRect(80, 0, menuView.Frame.Width - 20, 50));
                btnDashBoard.SetTitle("Your DashBoard", UIControlState.Normal);
                btnDashBoard.HorizontalAlignment = UIControlContentHorizontalAlignment.Left;
                btnDashBoard.TouchUpInside += delegate
                {
                    //Util.isMenuVisible = false;
                    //menuParentView.Hidden = true;
                    //imgMenu.UserInteractionEnabled = true;
                    //RedirectToDashBoardURL();
                    SidebarMenuTapGesture(tapGestureDashboard);
                };
                dashboardUI = new UIView(new CGRect(0, yCordinate, menuView.Frame.Width, 50));
                dashboardUI.AddSubviews(imgDashboard, btnDashBoard);
                tapGestureDashboard = new UITapGestureRecognizer(SidebarMenuTapGesture);
                dashboardUI.AddGestureRecognizer(tapGestureDashboard);
                dashboardUI.UserInteractionEnabled = true;

                yCordinate += btnDashBoard.Frame.Height;

                UIView viewDivider4 = new UIView(new CGRect(0, yCordinate, menuView.Frame.Width, 1));
                viewDivider4.BackgroundColor = UIColor.White;
                yCordinate += 1;

                UIImageView imgNews = new UIImageView(new CGRect(20,  10, 30, 30));
                imgNews.Image = new UIImage("Images/news.png");

                UIButton btnNews = new UIButton(new CGRect(80, 0, menuView.Frame.Width - 20, 50));
                btnNews.SetTitle("RateLinx News", UIControlState.Normal);
                btnNews.HorizontalAlignment = UIControlContentHorizontalAlignment.Left;
                btnNews.TouchUpInside += delegate
                {
                    //Util.isMenuVisible = false;
                    //menuParentView.Hidden = true;
                    //imgMenu.UserInteractionEnabled = true;
                    //RedirectToNewsURL();
                    SidebarMenuTapGesture(tapGestureNews);
                };
                newsUI = new UIView(new CGRect(0, yCordinate, menuView.Frame.Width, 50));
                newsUI.AddSubviews(imgNews, btnNews);
                tapGestureNews = new UITapGestureRecognizer(SidebarMenuTapGesture);
                newsUI.AddGestureRecognizer(tapGestureNews);
                newsUI.UserInteractionEnabled = true;

                yCordinate += btnNews.Frame.Height;

                UIView viewDivider5 = new UIView(new CGRect(0, yCordinate, menuView.Frame.Width, 1));
                viewDivider5.BackgroundColor = UIColor.White;

                yCordinate += 1;

                UIImageView imghelp = new UIImageView(new CGRect(20,  10, 30, 30));
                imghelp.Image = new UIImage("Images/feedback.png");

                UIButton btnHelpAndFeedback = new UIButton(new CGRect(80, 0, menuView.Frame.Width - 20, 50));
                btnHelpAndFeedback.SetTitle("Help and Feedback", UIControlState.Normal);
                btnHelpAndFeedback.HorizontalAlignment = UIControlContentHorizontalAlignment.Left;
                btnHelpAndFeedback.TouchUpInside += delegate
                {
                    //Util.isMenuVisible = false;
                    //imgMenu.UserInteractionEnabled = true;
                    //RedirectToHelpAndFeedback();
                    SidebarMenuTapGesture(tapGestureFeedback);
                };
                feedbackUI = new UIView(new CGRect(0, yCordinate, menuView.Frame.Width, 50));
                feedbackUI.AddSubviews(imghelp, btnHelpAndFeedback);
                tapGestureFeedback = new UITapGestureRecognizer(SidebarMenuTapGesture);
                feedbackUI.AddGestureRecognizer(tapGestureFeedback);
                feedbackUI.UserInteractionEnabled = true;

                yCordinate += btnHelpAndFeedback.Frame.Height;


                UIView viewDivider6 = new UIView(new CGRect(0, yCordinate, menuView.Frame.Width, 1));
                viewDivider6.BackgroundColor = UIColor.White;

                yCordinate += 1;

                UIImageView imgAbout = new UIImageView(new CGRect(20,  10, 30, 30));
                imgAbout.Image = new UIImage("Images/about.png");

                UIButton btnAboutRateLinx = new UIButton(new CGRect(80, 0, menuView.Frame.Width - 20, 50));
                btnAboutRateLinx.SetTitle("About RateLinx", UIControlState.Normal);
                btnAboutRateLinx.HorizontalAlignment = UIControlContentHorizontalAlignment.Left;
                btnAboutRateLinx.TouchUpInside += delegate
                {
                    //Util.isMenuVisible = false;
                    //menuParentView.Hidden = true;
                    //imgMenu.UserInteractionEnabled = true;
                    //RedirectToAboutRateLinxURL();
                    SidebarMenuTapGesture(tapGestureAbout);
                };
                aboutUI = new UIView(new CGRect(0, yCordinate, menuView.Frame.Width, 50));
                aboutUI.AddSubviews(imgAbout, btnAboutRateLinx);
                tapGestureAbout = new UITapGestureRecognizer(SidebarMenuTapGesture);
                aboutUI.AddGestureRecognizer(tapGestureAbout);
                aboutUI.UserInteractionEnabled = true;

                yCordinate += btnAboutRateLinx.Frame.Height;


                UIView viewDivider7 = new UIView(new CGRect(0, yCordinate, menuView.Frame.Width, 1));
                viewDivider7.BackgroundColor = UIColor.White;

                yCordinate += 1;

                UIButton btnSettings = new UIButton(new CGRect(0, yCordinate, menuView.Frame.Width, 60));//menuView.Frame.Height * 0.080
                btnSettings.SetTitle(" Settings", UIControlState.Normal);
                btnSettings.HorizontalAlignment = UIControlContentHorizontalAlignment.Left;
                btnSettings.UserInteractionEnabled = false;
                btnSettings.BackgroundColor = UIColor.LightGray;

                yCordinate += btnSettings.Frame.Height;

                UIImageView imgNotification = new UIImageView(new CGRect(20,  10, 30, 30));
                imgNotification.Image = new UIImage("Images/notification.png");

                UIButton btnPushNotification = new UIButton(new CGRect(80, yCordinate, menuView.Frame.Width * 0.7 - 20, 50));
                btnPushNotification.SetTitle("Push Notification", UIControlState.Normal);
                btnPushNotification.HorizontalAlignment = UIControlContentHorizontalAlignment.Left;
                btnPushNotification.UserInteractionEnabled = false;

                switchNotification = new UISwitch(new CGRect(menuView.Frame.Width * 0.7 + 20, yCordinate + 10, 60, btnPushNotification.Frame.Height - 20));

                notificationUI = new UIView(new CGRect(0, yCordinate, menuView.Frame.Width, 50));
                notificationUI.AddSubviews(imgNotification, btnPushNotification,switchNotification);
                tapGestureNotification = new UITapGestureRecognizer(SidebarMenuTapGesture);
                notificationUI.AddGestureRecognizer(tapGestureNotification);
                notificationUI.UserInteractionEnabled = true;

                yCordinate += btnPushNotification.Frame.Height;

                UIView viewDivider8 = new UIView(new CGRect(0, yCordinate, menuView.Frame.Width, 1));
                viewDivider8.BackgroundColor = UIColor.White;

                yCordinate += 1;

                UIImageView imgLogout = new UIImageView(new CGRect(20,  10, 30, 30));
                imgLogout.Image = new UIImage("Images/logout.png");

                UIButton btnLogout = new UIButton(new CGRect(80, 0, menuView.Frame.Width, 50));
                btnLogout.SetTitle("Logout", UIControlState.Normal);
                btnLogout.HorizontalAlignment = UIControlContentHorizontalAlignment.Left;
                btnLogout.TouchUpInside += delegate
                {
                    //Util.isMenuVisible = false;
                    //imgMenu.UserInteractionEnabled = true;
                    //CommanUtil.isApplicationAlive = false;
                    //CommanUtil.stopPooling = true;
                    //LogOutFromApp();
                    SidebarMenuTapGesture(tapGestureLogout);
                };
                logoutUI = new UIView(new CGRect(0, yCordinate, menuView.Frame.Width, 50));
                logoutUI.AddSubviews(imgLogout, btnLogout);
                tapGestureLogout = new UITapGestureRecognizer(SidebarMenuTapGesture);
                logoutUI.AddGestureRecognizer(tapGestureLogout);
                logoutUI.UserInteractionEnabled = true;

                yCordinate += btnLogout.Frame.Height;

                UIView viewDivider9 = new UIView(new CGRect(0, yCordinate, menuView.Frame.Width, 1));
                viewDivider9.BackgroundColor = UIColor.White;

                yCordinate += 1;

               
                viewLinkContainer.AddSubviews(headerUI,rateHistoryUI,dailyOrderUI,dashboardUI,newsUI,aboutUI,notificationUI,logoutUI, feedbackUI, homeUI, viewDivider2, viewDivider3, viewDividerOrder, 
                                     viewDivider4,  viewDivider5,  viewDivider6, 
                                              viewDivider7, btnSettings, btnPushNotification, switchNotification, viewDivider8,  viewDivider9);

                UIView viewSocialLinkContainer = new UIView(new CGRect(0, menuView.Frame.Height - 50, menuView.Frame.Width, 50));
                viewSocialLinkContainer.BackgroundColor = UIColor.FromRGB(137, 17, 28);

                nfloat xCordinate = (viewSocialLinkContainer.Frame.Width - 230) / 2;

                imgFaceBook = new UIImageView(new CGRect(xCordinate, 10, 30, 30));
                imgFaceBook.Image = new UIImage("Images/facebook.png");
                xCordinate += 40;

                imgTwitter = new UIImageView(new CGRect(xCordinate, 10, 30, 30));
                imgTwitter.Image = new UIImage("Images/twitter.png");
                xCordinate += 40;

                imgYoutube = new UIImageView(new CGRect(xCordinate, 10, 30, 30));
                imgYoutube.Image = new UIImage("Images/youtube.png");
                xCordinate += 40;

                imgLnkdn = new UIImageView(new CGRect(xCordinate, 10, 30, 30));
                imgLnkdn.Image = new UIImage("Images/lnkdin.png");
                xCordinate += 40;

                imgGPlus = new UIImageView(new CGRect(xCordinate, 10, 30, 30));
                imgGPlus.Image = new UIImage("Images/google-plus.png");
                xCordinate += 40;

                imgRSS = new UIImageView(new CGRect(xCordinate, 10, 30, 30));
                imgRSS.Image = new UIImage("Images/rss.png");

                tapGestureFacebook = new UITapGestureRecognizer(SocialMediaLinks);
                imgFaceBook.AddGestureRecognizer(tapGestureFacebook);
                imgFaceBook.UserInteractionEnabled = true;

                tapGestureTwitter = new UITapGestureRecognizer(SocialMediaLinks);
                imgTwitter.AddGestureRecognizer(tapGestureTwitter);
                imgTwitter.UserInteractionEnabled = true;

                tapGestureLnkdn = new UITapGestureRecognizer(SocialMediaLinks);
                imgLnkdn.AddGestureRecognizer(tapGestureLnkdn);
                imgLnkdn.UserInteractionEnabled = true;

                tapGestureYoutube = new UITapGestureRecognizer(SocialMediaLinks);
                imgYoutube.AddGestureRecognizer(tapGestureYoutube);
                imgYoutube.UserInteractionEnabled = true;

                tapGestureGPlus = new UITapGestureRecognizer(SocialMediaLinks);
                imgGPlus.AddGestureRecognizer(tapGestureGPlus);
                imgGPlus.UserInteractionEnabled = true;

                tapGestureRSS = new UITapGestureRecognizer(SocialMediaLinks);
                imgRSS.AddGestureRecognizer(tapGestureRSS);
                imgRSS.UserInteractionEnabled = true;

                bool isPushAllowed = NSUserDefaults.StandardUserDefaults.BoolForKey("isPushAllowed");
                switchNotification.On = isPushAllowed;
                CommanUtil.isPushAllowed = isPushAllowed;

                switchNotification.ValueChanged += delegate
                {

                    PushNotificationSwitchHandler(switchNotification);
                };
                viewSocialLinkContainer.AddSubviews(imgFaceBook, imgTwitter, imgYoutube, imgLnkdn, imgGPlus, imgRSS);

                menuScrollView.AddSubview(viewLinkContainer);

                menuView.AddSubviews(viewDivider1, menuScrollView, viewSocialLinkContainer);

                menuView.BackgroundColor = UIColor.Black;

                UIButton btnCloseMenu = new UIButton(new CGRect(menuView.Frame.Width - 35, 7, 25, 25));
                //btnCloseMenu.SetTitle("Close", UIControlState.Normal);
                //btnCloseMenu.SetTitleColor(UIColor.Red, UIControlState.Normal);
                btnCloseMenu.SetImage(UIImage.FromFile("Images/redcross.png"), UIControlState.Normal);

                btnCloseMenu.TouchUpInside += delegate
                {
                    Util.isMenuVisible = false;
                    imgMenu.UserInteractionEnabled = true;
                    UIView.Animate(0.3,
                    () =>
                    {
                        menuParentView.Frame = new CGRect(-1000, 20, parentView.Frame.Width, parentView.Frame.Height - 20);

                    });
                };

                menuView.AddSubview(btnCloseMenu);
                return menuParentView;

            }
            catch
            {
                throw;
            }
        }

		void LogOutFromApp()
		{
			try
			{
				NSUserDefaults.StandardUserDefaults.SetString(JsonConvert.SerializeObject(null), "objTrackList");
				CommanUtil.userID = string.Empty;
				CommanUtil.isStopAllTracking = true;
				CommanUtil.isTrackingEnable = false;
				LoginController loginController;
				if (objHelpAndFeedbackController != null)
				{
					loginController = (LoginController)objHelpAndFeedbackController.Storyboard.InstantiateViewController("LoginController");
					loginController.logOut = "logOut";
					objHelpAndFeedbackController.NavigationController.PushViewController(loginController, true);
				}
				else if (objDashboardController != null)
				{
					loginController = (LoginController)objDashboardController.Storyboard.InstantiateViewController("LoginController");
					loginController.logOut = "logOut";
					objDashboardController.NavigationController.PushViewController(loginController, true);
				}
                else if (objRateHistoryController != null)
                {
                    loginController = (LoginController)objRateHistoryController.Storyboard.InstantiateViewController("LoginController");
                    loginController.logOut = "logOut";
                    objRateHistoryController.NavigationController.PushViewController(loginController, true);
                }
                else if (objOrderHistoryController != null)
                {
                    loginController = (LoginController)objOrderHistoryController.Storyboard.InstantiateViewController("LoginController");
                    loginController.logOut = "logOut";
                    objOrderHistoryController.NavigationController.PushViewController(loginController, true);
                }
				else
                {
                    if (objHistoryResultController != null)
                    {
                        loginController = (LoginController)objHistoryResultController.Storyboard.InstantiateViewController("LoginController");
                        loginController.logOut = "logOut";
                        objHistoryResultController.NavigationController.PushViewController(loginController, true);
                    }
				}
			}
            catch(Exception ex)
			{
                Console.Write(ex.Message);
			}
		}

		void RedirectToAboutRateLinxURL()
		{
			//SidebarController.CloseMenu ();
			webView = new UIWebView();
			webView.ShouldStartLoad = HandleShouldStartLoad;
			webView.LoadRequest(new NSUrlRequest(new NSUrl(CommanUtil.linkRateLinxAbout)));
		}

		void RedirectToHelpAndFeedback()
		{
			try
			{
				HelpAndFeedbackController helpAndFeedbackController;
				if (objDashboardController != null)
				{
					helpAndFeedbackController = (HelpAndFeedbackController)objDashboardController.Storyboard.InstantiateViewController("HelpAndFeedbackController");
					CustomPopup customAlert = null;
					if (Reachability.InternetConnectionStatus())
					{
						objDashboardController.NavigationController.PushViewController(helpAndFeedbackController, true);
					}
					else
					{
						customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.isOnline, true, helpAndFeedbackController, "", 1);
						helpAndFeedbackController.View.Add(customAlert);
					}

				}
				else if (objRateHistoryController != null)
				{
					helpAndFeedbackController = (HelpAndFeedbackController)objRateHistoryController.Storyboard.InstantiateViewController("HelpAndFeedbackController");
					objRateHistoryController.NavigationController.PushViewController(helpAndFeedbackController, true);
				}
				else if (objHelpAndFeedbackController != null)
				{
					helpAndFeedbackController = (HelpAndFeedbackController)objHelpAndFeedbackController.Storyboard.InstantiateViewController("HelpAndFeedbackController");
					objHelpAndFeedbackController.NavigationController.PushViewController(helpAndFeedbackController, true);
				}
                else if (objOrderHistoryController != null)
                {
                    helpAndFeedbackController = (HelpAndFeedbackController)objOrderHistoryController.Storyboard.InstantiateViewController("HelpAndFeedbackController");
                    objOrderHistoryController.NavigationController.PushViewController(helpAndFeedbackController, true);
                }
				else
				{
					if (objHistoryResultController != null)
					{
						helpAndFeedbackController = (HelpAndFeedbackController)objHistoryResultController.Storyboard.InstantiateViewController("HelpAndFeedbackController");
						objHistoryResultController.NavigationController.PushViewController(helpAndFeedbackController, true);
					}
				}
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}

		void RedirectToNewsURL()
		{
			//SidebarController.CloseMenu ();
			webView = new UIWebView();
			webView.ShouldStartLoad = HandleShouldStartLoad;
			webView.LoadRequest(new NSUrlRequest(new NSUrl(CommanUtil.linkRateLinxNews)));
		}

		async void RedirectToDashBoardURL()
		{
			
			try
			{
				//SidebarController.CloseMenu ();
				objServicehelper = new ServiceHelper();
				methodName = APIMethods.getSSOurl;
				//Alerts.showBusyLoader(this);  Loader
				strResponse = await objServicehelper.GetRequest(CommanUtil.tokenNo, methodName, true);
				if (!String.IsNullOrEmpty(strResponse))
				{
					jobject = JObject.Parse(strResponse);
					redirectURL = Convert.ToString(jobject["url"]);
					webView = new UIWebView();
					webView.ShouldStartLoad = HandleShouldStartLoad;
					webView.LoadRequest(new NSUrlRequest(new NSUrl(redirectURL)));
				}
				else
				{
					jobject = null;
				}

			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}

        void RedirectToOrderHistory()
        {
            try
            {
                OrderHistoryController orderHistoryController;

                if (objDashboardController != null)
                {
                    orderHistoryController = (OrderHistoryController)objDashboardController.Storyboard.InstantiateViewController("OrderHistoryController");
                    CustomPopup customAlert = null;
                    if (Reachability.InternetConnectionStatus())
                    {
                        objDashboardController.NavigationController.PushViewController(orderHistoryController, true);
                    }
                    else
                    {
                        customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.isOnline, true, orderHistoryController, "", 1);
                        orderHistoryController.View.Add(customAlert);
                    }

                }
                else if (objRateHistoryController != null)
                {
                    orderHistoryController = (OrderHistoryController)objRateHistoryController.Storyboard.InstantiateViewController("OrderHistoryController");
                    objRateHistoryController.NavigationController.PushViewController(orderHistoryController, true);
                }
                else if (objHelpAndFeedbackController != null)
                {
                    orderHistoryController = (OrderHistoryController)objHelpAndFeedbackController.Storyboard.InstantiateViewController("OrderHistoryController");
                    objHelpAndFeedbackController.NavigationController.PushViewController(orderHistoryController, true);
                }
                else if (objOrderHistoryController != null)
                {
                    orderHistoryController = (OrderHistoryController)objOrderHistoryController.Storyboard.InstantiateViewController("OrderHistoryController");
                    objOrderHistoryController.NavigationController.PushViewController(orderHistoryController, true);
                }
                else
                {
                    if (objHistoryResultController != null)
                    {
                        orderHistoryController = (OrderHistoryController)objHistoryResultController.Storyboard.InstantiateViewController("OrderHistoryController");
                        objHistoryResultController.NavigationController.PushViewController(orderHistoryController, true);
                    }
                }

            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
            }
        }

		void RedirectToRateHistory()
		{
			try
			{
				RateHistoryController rateHistoryController;

				if (objDashboardController != null)
				{
					rateHistoryController = (RateHistoryController)objDashboardController.Storyboard.InstantiateViewController("RateHistoryController");
					CustomPopup customAlert = null;
					if (Reachability.InternetConnectionStatus())
					{
						objDashboardController.NavigationController.PushViewController(rateHistoryController, true);
					}
					else
					{
						customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.isOnline, true, rateHistoryController, "", 1);
						rateHistoryController.View.Add(customAlert);
					}

				}
				else if (objRateHistoryController != null)
				{
					rateHistoryController = (RateHistoryController)objRateHistoryController.Storyboard.InstantiateViewController("RateHistoryController");
					objRateHistoryController.NavigationController.PushViewController(rateHistoryController, true);
				}
				else if (objHelpAndFeedbackController != null)
				{
					rateHistoryController = (RateHistoryController)objHelpAndFeedbackController.Storyboard.InstantiateViewController("RateHistoryController");
					objHelpAndFeedbackController.NavigationController.PushViewController(rateHistoryController, true);
				}
                else if (objOrderHistoryController != null)
                {
                    rateHistoryController = (RateHistoryController)objOrderHistoryController.Storyboard.InstantiateViewController("RateHistoryController");
                    objOrderHistoryController.NavigationController.PushViewController(rateHistoryController, true);
                }
				else
				{
					if (objHistoryResultController != null)
					{
						rateHistoryController = (RateHistoryController)objHistoryResultController.Storyboard.InstantiateViewController("RateHistoryController");
						objHistoryResultController.NavigationController.PushViewController(rateHistoryController, true);
					}
				}
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}

		void RedirectToHome()
		{
			try
			{
				
				DashboardController dashboardController;
				if (objDashboardController != null)
				{
					
					dashboardController = (DashboardController)objDashboardController.Storyboard.InstantiateViewController("DashboardController");

					objDashboardController.NavigationController.PushViewController(dashboardController, true);

					//customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.isOnline, true, dashboardController, "", 1);
					//dashboardController.View.Add(customAlert);
				}

				else if (objRateHistoryController != null)
				{
					dashboardController = (DashboardController)objRateHistoryController.Storyboard.InstantiateViewController("DashboardController");
					objRateHistoryController.NavigationController.PushViewController(dashboardController, true);

				}
                else if (objOrderHistoryController != null)
                {
                    dashboardController = (DashboardController)objOrderHistoryController.Storyboard.InstantiateViewController("DashboardController");
                    objOrderHistoryController.NavigationController.PushViewController(dashboardController, true);

                }
				else if (objHelpAndFeedbackController != null)
				{
					objHelpAndFeedbackController.PerformSegue("HelpAndFeedbackToHomeSegue", null);
				}
				else
				{
					if (objHistoryResultController != null)
					{
						dashboardController = (DashboardController)objHistoryResultController.Storyboard.InstantiateViewController("DashboardController");
						objHistoryResultController.NavigationController.PushViewController(dashboardController, true);

					}
				}

			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}
        /// <summary>
        /// Handles the should start load.
        /// </summary>
        /// <returns><c>true</c>, if should start load was handled, <c>false</c> otherwise.</returns>
        /// <param name="webView">Web view.</param>
        /// <param name="request">Request.</param>
        /// <param name="navigationType">Navigation type.</param>
		bool HandleShouldStartLoad(UIWebView webView, NSUrlRequest request, UIWebViewNavigationType navigationType)
		{
			UIApplication.SharedApplication.OpenUrl(request.Url);
			//SidebarController.CloseMenu();
			return true;
		}


		//partial void BtnPushSwitch_TouchUpInside(UIButton sender)
		//{
		//	PushNotificationSwitchHandler(pushNotificationSwitch);
		//}

		async void PushNotificationSwitchHandler(UISwitch pushNotificationControl)
		{
			try
			{
				LoadingOverlay loadPop;
				CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
				loadPop = new LoadingOverlay(bounds);
				if (objHelpAndFeedbackController != null)
				{
					objHelpAndFeedbackController.View.Add(loadPop);
				}
				if (objDashboardController != null)
				{
					objDashboardController.View.Add(loadPop);
				}
				else
				{
					objRateHistoryController.View.Add(loadPop);
				}
				await Task.Delay(5000);
				if (pushNotificationControl.On)
				{
					switchNotification.On = true;
					CommanUtil.isPushAllowed = true;
					NSUserDefaults.StandardUserDefaults.SetBool(true, "isPushAllowed");
				}
				else
				{
					switchNotification.On = false;
					CommanUtil.isPushAllowed = false;
					NSUserDefaults.StandardUserDefaults.SetBool(false, "isPushAllowed");
				}
				AppDelegate objDelegate = new AppDelegate();
				objDelegate.PushRegisterd();
				loadPop.Hide();
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}


		/// <summary>
		/// Socials the media links.
		/// </summary>
		/// <param name="tapGesture">Tap gesture.</param>
		public void SocialMediaLinks(UITapGestureRecognizer tapGesture)
		{
			Util.isMenuVisible = false;
			string socialMedialURL = string.Empty;
			if (tapGesture.View.Equals(imgFaceBook))
			{
				socialMedialURL = CommanUtil.linkFacebook;
			}
			else if (tapGesture.View.Equals(imgTwitter))
			{
				socialMedialURL = CommanUtil.linkTwitter;
			}
			else if (tapGesture.View.Equals(imgLnkdn))
			{
				socialMedialURL = CommanUtil.linkLnkdn;
			}
			else if (tapGesture.View.Equals(imgYoutube))
			{
				socialMedialURL = CommanUtil.linkYoutube;
			}
			    else if (tapGesture.View.Equals(imgGPlus))
			{
				socialMedialURL = CommanUtil.linkGooglePlus;
			}
			else if (tapGesture.View.Equals(imgRSS))
			{
				socialMedialURL = CommanUtil.linkRSS;
			}

			webView = new UIWebView();
			webView.ShouldStartLoad = HandleShouldStartLoad;
			webView.LoadRequest(new NSUrlRequest(new NSUrl(socialMedialURL)));
		}


        public void SidebarMenuTapGesture(UITapGestureRecognizer sidebarMenuTapGesture)
        {
            Util.isMenuVisible = false;
            //imgMenu.UserInteractionEnabled = true;
            if (sidebarMenuTapGesture.View.Equals(homeUI))
            {
                RedirectToHome();
            }
            else if (sidebarMenuTapGesture.View.Equals(rateHistoryUI))
            {
                RedirectToRateHistory();
            }
            else if (sidebarMenuTapGesture.View.Equals(dailyOrderUI))
            {
                RedirectToOrderHistory();
            }
            else if (sidebarMenuTapGesture.View.Equals(dashboardUI))
            {
                //menuParentView.Hidden = true;
                RedirectToDashBoardURL();
            }
            else if (sidebarMenuTapGesture.View.Equals(newsUI))
            {
                //menuParentView.Hidden = true;
                RedirectToNewsURL();
            }
            else if (sidebarMenuTapGesture.View.Equals(feedbackUI))
            {
                RedirectToHelpAndFeedback();
            }
            else if (sidebarMenuTapGesture.View.Equals(aboutUI))
            {
                //menuParentView.Hidden = true;
                RedirectToAboutRateLinxURL();
            }
            //else if (sidebarMenuTapGesture.View.Equals(notificationUI))
            //{
            //    RedirectToHome();
            //}
            else if (sidebarMenuTapGesture.View.Equals(logoutUI))
            {
                CommanUtil.isApplicationAlive = false;
                CommanUtil.stopPooling = true;
                LogOutFromApp();
            }
        }

	}
}
