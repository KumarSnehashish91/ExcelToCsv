﻿using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;
using System.Collections.Generic;
using CoreGraphics;
using RateLinx.Helper;
using RateLinx.Models;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using RateLinx.APIs;
using ToastIOS;

namespace RateLinx.iOS
{
	public class ConfirmShipmentPopup
	{

		#region Variable Declaration

		UIView mainView;
		CarrierShipmentDetails carrierShipmentDetail;
		ShipmentDetailController shipmentDetailController;
		UITextView txtProNum;
		UIView popupView;
		LoadingOverlay loadPop;
		//CustomPopup customAlert = null;

		#endregion


		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.ConfirmShipmentPopup"/> class.
		/// </summary>
		/// <param name="view">View.</param>
		/// <param name="carrierShipmentDetail">Carrier shipment detail.</param>
		/// <param name="shipmentDetailController">Shipment detail controller.</param>
		public ConfirmShipmentPopup(UIView view, CarrierShipmentDetails carrierShipmentDetail, ShipmentDetailController shipmentDetailController)
		{
			mainView = view;
			this.carrierShipmentDetail = carrierShipmentDetail;
			this.shipmentDetailController = shipmentDetailController;
		}
		/// <summary>
		/// Gets the popup screen.
		/// </summary>
		/// <returns>The popup screen.</returns>
		public UIView GetPopupScreen()
		{
			try
			{
				popupView = new UIView();
				popupView.Frame = mainView.Bounds;
				popupView.BackgroundColor = UIColor.Clear;

				UIView viewConfirmShipment = new UIView(new CGRect(10, 100, mainView.Frame.Width - 20, 200));
				viewConfirmShipment.BackgroundColor = UIColor.White;
				viewConfirmShipment.Layer.CornerRadius = 5;
				viewConfirmShipment.Layer.BorderWidth = 0.5f;

				UIView viewTopMargin = new UIView(new CGRect(0, 0, viewConfirmShipment.Frame.Width, 10));
				viewTopMargin.BackgroundColor = Constants.conversationHeadClr;
				viewTopMargin.Layer.CornerRadius = 5;

				UIView viewConfirmShipmentHead = new UIView(new CGRect(0, 5, viewConfirmShipment.Frame.Width, 40));
				viewConfirmShipmentHead.BackgroundColor = Constants.conversationHeadClr;
				UILabel lblDenyShipmentHead = new UILabel(new CGRect(10, 6, viewConfirmShipment.Frame.Width - 100, 24));

				lblDenyShipmentHead.BackgroundColor = Constants.conversationHeadClr;
				lblDenyShipmentHead.Font = UIFont.FromName(Constants.strFontName, 15f);
				lblDenyShipmentHead.Text = NSBundle.MainBundle.GetLocalizedString("confirmShipment", null);
				lblDenyShipmentHead.TextColor = UIColor.White;

				UIButton btnPopupClose = new UIButton(new CGRect(viewConfirmShipment.Frame.Width - 25, 5, 25, 20));
				btnPopupClose.Layer.CornerRadius = 10;

				btnPopupClose.ContentMode = UIViewContentMode.Center;
				btnPopupClose.SetImage(UIImage.FromBundle("Images/error.PNG"), UIControlState.Normal);

				btnPopupClose.TouchUpInside += delegate
				{
					popupView.Hidden = true;
				};

				viewConfirmShipmentHead.AddSubviews(lblDenyShipmentHead, btnPopupClose);

				UIView viewConfirmShipmentContent = new UIView(new CGRect(0, viewConfirmShipmentHead.Frame.Y + viewConfirmShipmentHead.Frame.Height, viewConfirmShipment.Frame.Width, 105));

				UILabel lblConfirmation = new UILabel(new CGRect(10, 10, viewConfirmShipmentContent.Frame.Width - 10, 35));
				lblConfirmation.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblConfirmation.Lines = 0;
				lblConfirmation.Text = NSBundle.MainBundle.GetLocalizedString("enterProNo", null);

				UILabel lblEnterProNum = new UILabel(new CGRect(10, 50, viewConfirmShipmentContent.Frame.Width / 2 - 10, 25));
				lblEnterProNum.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblEnterProNum.Text = NSBundle.MainBundle.GetLocalizedString("enterPro", null);

				txtProNum = new UITextView(new CGRect(viewConfirmShipmentContent.Frame.Width / 2, 50, viewConfirmShipmentContent.Frame.Width / 2 - 10, 25));
				txtProNum.Layer.BorderWidth = 1;
				txtProNum.Layer.CornerRadius = 5;

				viewConfirmShipmentContent.AddSubviews(lblConfirmation, lblEnterProNum, txtProNum);

				UIView viewBottomSeparator = new UIView(new CGRect(0, viewConfirmShipmentContent.Frame.Y + viewConfirmShipmentContent.Frame.Height, viewConfirmShipment.Frame.Width, 0.5));
				viewBottomSeparator.BackgroundColor = Constants.conversationHeadClr;

				UIButton btnCancel = new UIButton(new CGRect(viewConfirmShipment.Frame.Width - 90, viewConfirmShipment.Frame.Height - 40, 80, 30));
				btnCancel.SetTitle(NSBundle.MainBundle.GetLocalizedString("cancel", null), UIControlState.Normal);
				btnCancel.BackgroundColor = Constants.btnColorBlue;
				btnCancel.Layer.CornerRadius = 5;

				UIButton btnConfirm = new UIButton(new CGRect(viewConfirmShipment.Frame.Width - 180, viewConfirmShipment.Frame.Height - 40, 80, 30));
				btnConfirm.SetTitle(NSBundle.MainBundle.GetLocalizedString("btnConfirmText", null), UIControlState.Normal);
				btnConfirm.SetTitleColor(UIColor.Black, UIControlState.Normal);

				btnConfirm.BackgroundColor = UIColor.White;
				btnConfirm.Layer.CornerRadius = 5;
				btnConfirm.Layer.BorderWidth = 0.5f;
				btnCancel.TouchUpInside += delegate
				{
					popupView.Hidden = true;
				};
				btnConfirm.TouchUpInside += async delegate
				{
					await AcceptDenyShip();
				};
				viewConfirmShipment.AddSubviews(viewTopMargin, viewConfirmShipmentHead, viewConfirmShipmentContent, viewBottomSeparator, btnCancel, btnConfirm);
				popupView.AddSubview(viewConfirmShipment);
				popupView.Hidden = false;
				return popupView;
			}
			catch
			{
				throw;
			}
		}


		/// <summary>
		/// Accept And Deny Shipment
		/// </summary>
		public async Task AcceptDenyShip()
		{
			try
			{
				int bidId = carrierShipmentDetail.Entries[0].ID;
				string payLoad = "{" + "\"ProNumber\"" + ":" + "\"" + txtProNum.Text + "\"" + "}";
				if (string.IsNullOrEmpty(txtProNum.Text))
				{
					//this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strEnterProNo, true, shipmentDetailController, "", 1);
					//this.mainView.Add(this.customAlert);
                    Toast.MakeText(Constants.strEnterProNo).SetDuration(Constants.toastDuration).Show();
                    return;
				}
                if (CommanUtil.IsSpecialCharacter(txtProNum.Text))
                {
                    Toast.MakeText(Constants.specialCharacterMessage).SetDuration(Constants.toastDuration).Show();
                    return;
                }
				else
				{
					try
					{
						CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
						if (loadPop == null)
						{
							loadPop = new LoadingOverlay(bounds);
						}
						mainView.Add(loadPop);
						ServiceHelper objServiceHelper = new ServiceHelper();
						string token = CommanUtil.tokenNo;
						string id = CommanUtil.CompositeKey(carrierShipmentDetail.ClientID, carrierShipmentDetail.LocID, carrierShipmentDetail.BolNum);
						string methodURI = APIMethods.shipmentDetails + "/" + id + "/" + bidId + "/" + APIMethods.confirm;

						string Result = await objServiceHelper.PostRequestJson(payLoad, methodURI, token, true);
						if (Result != null && Result.Replace("\"", " ").Trim().ToUpper() == Constants.strSuccess.ToUpper())
						{
							loadPop.Hide();
							popupView.Hidden = true;
							string key = carrierShipmentDetail.ClientID + "|" + carrierShipmentDetail.BolNum + "|" + ConstantsClass.strBid;
							shipmentDetailController.RefreshShipmentDetail(key);
						}
						else
						{
							JObject response = JObject.Parse(Result);
							string Message = Convert.ToString(response[Constants.strErrorMessage]);
							if (!string.IsNullOrEmpty(Message))
							{
								ErrorPopup objErrorPopup = new ErrorPopup(mainView, Message, shipmentDetailController);
								UIView viewErrorpop = objErrorPopup.GetErrorPopup();
								mainView.Add(viewErrorpop);
								loadPop.Hide();
								popupView.Hidden = true;
							}
						}
					}
					catch
					{
						loadPop.Hide();
					}

				}
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}

	}
}
