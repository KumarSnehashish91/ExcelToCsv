﻿using System;
using CoreGraphics;
using Foundation;
using RateLinx.Helper;
using RateLinx.Models;
using UIKit;

namespace RateLinx.iOS
{
	public class RateHistoryPopup
	{
		UIView mainView;
		CarrierShipmentDetails lstShipmentDetail = null;

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.RateHistoryPopup"/> class.
		/// </summary>
		/// <param name="view">View.</param>
		public RateHistoryPopup(UIView view)
		{
			mainView = view;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.RateHistoryPopup"/> class.
		/// </summary>
		/// <param name="view">View.</param>
		/// <param name="lstShipmentDetail">Lst shipment detail.</param>
		public RateHistoryPopup(UIView view, CarrierShipmentDetails lstShipmentDetail)
		{
			mainView = view;
			this.lstShipmentDetail = lstShipmentDetail;
		}

		/// <summary>
		/// Gets the popup screen.
		/// </summary>
		/// <returns>The popup screen.</returns>
		public UIView GetPopupScreen()
		{
			try
			{
				UIView popupView = new UIView();
				popupView.Frame = mainView.Bounds;
				popupView.BackgroundColor = UIColor.Clear;

				UIView viewRateHistoryPopup = new UIView(new CGRect(10, 100, mainView.Frame.Width - 20, 200));
				viewRateHistoryPopup.BackgroundColor = UIColor.White;
				viewRateHistoryPopup.Layer.CornerRadius = 5;
				viewRateHistoryPopup.Layer.BorderWidth = 0.5f;

				UIView viewTopMargin = new UIView(new CGRect(0, 0, viewRateHistoryPopup.Frame.Width, 10));
				viewTopMargin.BackgroundColor = Constants.conversationHeadClr;
				viewTopMargin.Layer.CornerRadius = 5;


				UIView viewRateHistoryHead = new UIView(new CGRect(0, 5, viewRateHistoryPopup.Frame.Width, 40));
				viewRateHistoryHead.BackgroundColor = Constants.conversationHeadClr;

				UILabel lblRateEntryHead = new UILabel(new CGRect(10, 6, viewRateHistoryPopup.Frame.Width - 100, 24));

				lblRateEntryHead.BackgroundColor = Constants.conversationHeadClr;
				lblRateEntryHead.Font = UIFont.FromName(Constants.strFontName, 15f);
				lblRateEntryHead.Text = NSBundle.MainBundle.LocalizedString("RateHistory", null);
				lblRateEntryHead.TextColor = UIColor.White;

				UIButton btnPopupClose = new UIButton(new CGRect(viewRateHistoryPopup.Frame.Width - 25, 5, 25, 20));
				btnPopupClose.Layer.CornerRadius = 10;

				btnPopupClose.ContentMode = UIViewContentMode.Center;
				btnPopupClose.SetImage(UIImage.FromBundle("Images/error.PNG"), UIControlState.Normal);


				btnPopupClose.TouchUpInside += delegate
				{
					popupView.Hidden = true;
				};

				viewRateHistoryHead.AddSubviews(lblRateEntryHead, btnPopupClose);

				UIView viewRateHistoryContent = new UIView();


				UIView viewRateHistoryTableHead = new UIView(new CGRect(3, 20, viewRateHistoryHead.Frame.Width - 6, 25));


				UILabel lblCarrier = new UILabel(new CGRect(0, 0, viewRateHistoryTableHead.Frame.Width / 10 * 2.5, 25));
				lblCarrier.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblCarrier.TextAlignment = UITextAlignment.Center;
				lblCarrier.Text = NSBundle.MainBundle.LocalizedString("carrier", null);
				lblCarrier.TextColor = UIColor.White;
				lblCarrier.BackgroundColor = Constants.fileHeadBGC;

				UILabel lblAmount = new UILabel(new CGRect(viewRateHistoryTableHead.Frame.Width / 10 * 2.5 + 1, 0, viewRateHistoryTableHead.Frame.Width / 10 * 2.5, 25));
				lblAmount.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblAmount.TextAlignment = UITextAlignment.Center;
				lblAmount.Text = NSBundle.MainBundle.LocalizedString("amount", null);
				lblAmount.TextColor = UIColor.White;
				lblAmount.BackgroundColor = Constants.fileHeadBGC;

				UILabel lblDateEntered = new UILabel(new CGRect(viewRateHistoryTableHead.Frame.Width / 10 * 5 + 2, 0, viewRateHistoryTableHead.Frame.Width / 10 * 5 - 2, 25));
				lblDateEntered.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblDateEntered.TextAlignment = UITextAlignment.Center;
				lblDateEntered.Text = NSBundle.MainBundle.LocalizedString("dateEntered", null);
				lblDateEntered.TextColor = UIColor.White;
				lblDateEntered.BackgroundColor = Constants.fileHeadBGC;

				viewRateHistoryTableHead.AddSubviews(lblCarrier, lblAmount, lblDateEntered);
				UITableView tblRateHistory = new UITableView();
				tblRateHistory.Bounces = false;
				tblRateHistory.ShowsVerticalScrollIndicator = false;
				if (lstShipmentDetail.OldEntries != null && lstShipmentDetail.OldEntries.Count > 0)
				{
					if (lstShipmentDetail.OldEntries.Count <= 5)
					{
						tblRateHistory.Frame = new CGRect(3, viewRateHistoryTableHead.Frame.Bottom, viewRateHistoryHead.Frame.Width - 6, lstShipmentDetail.OldEntries.Count * 30);
					}
					else
					{
						tblRateHistory.Frame = new CGRect(3, viewRateHistoryTableHead.Frame.Bottom, viewRateHistoryHead.Frame.Width - 6, 165);
					}


					tblRateHistory.Source = new BidRateHistoryAdapter(lstShipmentDetail.OldEntries);
					tblRateHistory.AllowsSelection = false;
					tblRateHistory.UserInteractionEnabled = true;



					viewRateHistoryContent.Frame = new CGRect(0, viewRateHistoryTableHead.Frame.Bottom, viewRateHistoryPopup.Frame.Width, tblRateHistory.Frame.Bottom + 30);

				}
				else
				{
					tblRateHistory.Frame = new CGRect(3, viewRateHistoryTableHead.Frame.Height + 10, viewRateHistoryContent.Frame.Width - 6, 0);

					viewRateHistoryContent.Frame = new CGRect(0, viewRateHistoryHead.Frame.Bottom, viewRateHistoryPopup.Frame.Width, 70);
				}


				viewRateHistoryContent.AddSubviews(viewRateHistoryTableHead, tblRateHistory);


				UIView viewBottomSeparator = new UIView(new CGRect(0, viewRateHistoryContent.Frame.Bottom + 10, viewRateHistoryPopup.Frame.Width, 0.5));
				viewBottomSeparator.BackgroundColor = Constants.conversationHeadClr;

				UIButton btnOk = new UIButton(new CGRect(viewRateHistoryPopup.Frame.Width - 70, viewBottomSeparator.Frame.Bottom + 10, 50, 25));
				btnOk.SetTitle(NSBundle.MainBundle.LocalizedString("okText", null), UIControlState.Normal);
				btnOk.BackgroundColor = Constants.btnColorBlue;
				btnOk.Layer.CornerRadius = 5;
				//btnOk.Layer.BorderWidth = 2;
				btnOk.TouchUpInside += delegate
				{
					popupView.Hidden = true;
				};

				//View.Add(popupView)
				viewRateHistoryPopup.Frame = new CGRect(10, 100, mainView.Frame.Width - 20, btnOk.Frame.Bottom + 10);
				viewRateHistoryPopup.AddSubviews(viewTopMargin, viewRateHistoryHead, viewRateHistoryContent, viewBottomSeparator, btnOk);
				popupView.AddSubview(viewRateHistoryPopup);
				popupView.Hidden = false;

				return popupView;
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
				return null;
			}
		}
	}
}
