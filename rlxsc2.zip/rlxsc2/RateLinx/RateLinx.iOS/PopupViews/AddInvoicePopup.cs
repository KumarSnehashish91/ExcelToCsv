﻿using System;
using UIKit;
using CoreGraphics;
using RateLinx.Helper;
using Foundation;

namespace RateLinx.iOS
{
	public class AddInvoicePopup
	{

		#region Variable Declaration

		UIView mainView;
		string message = string.Empty;
		InvoiceController objInvoiceController;
		#endregion

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.AddInvoicePopup"/> class.
		/// </summary>
		/// <param name="view">View.</param>
		/// <param name="message">Message.</param>
		/// <param name="objInvoiceController">Object invoice controller.</param>
		public AddInvoicePopup (UIView view,string message,InvoiceController objInvoiceController)
		{
			mainView = view;
			this.message = message;
			this.objInvoiceController = objInvoiceController;
		}
		/// <summary>
		/// Gets the popup screen.
		/// </summary>
		/// <returns>The popup screen.</returns>
		public UIView GetPopupScreen()
		{
			try {
				UIView popupView = new UIView ();
				popupView.Frame = mainView.Bounds;
				popupView.BackgroundColor = UIColor.Clear;

				UIView viewUnawardConfirmation = new UIView (new CGRect (10, 100, mainView.Frame.Width - 20, 170));
				viewUnawardConfirmation.BackgroundColor = UIColor.White;
				viewUnawardConfirmation.Layer.CornerRadius = 5;
				viewUnawardConfirmation.Layer.BorderWidth = 0.5f;

				UIView viewTopMargin = new UIView (new CGRect (0, 0, viewUnawardConfirmation.Frame.Width, 10));
				viewTopMargin.BackgroundColor = Constants.conversationHeadClr;
				viewTopMargin.Layer.CornerRadius = 5;

				UIView viewUnawardConfirmationHead = new UIView (new CGRect (0, 5, viewUnawardConfirmation.Frame.Width, 40));
				viewUnawardConfirmationHead.BackgroundColor = Constants.conversationHeadClr;

				UIImageView imageConfirm = new UIImageView (new CGRect (10, 8, 25, 20));
				imageConfirm.Image = UIImage.FromBundle ("Images/warning.png");

				UILabel lblBidCommentHead = new UILabel (new CGRect (40, 6, 150, 24));

				lblBidCommentHead.BackgroundColor = Constants.conversationHeadClr;
				lblBidCommentHead.Font = UIFont.FromName (Constants.strFontName, 15f);
				lblBidCommentHead.Text = Constants.strDialogHdr + "!";
				lblBidCommentHead.TextColor = UIColor.White;

				UIButton btnPopupClose = new UIButton(new CGRect(viewUnawardConfirmation.Frame.Width - 25, 5, 25, 20));
				btnPopupClose.Layer.CornerRadius = 10;

				btnPopupClose.ContentMode = UIViewContentMode.Center;
				btnPopupClose.SetImage(UIImage.FromBundle("Images/error.PNG"), UIControlState.Normal);




				btnPopupClose.TouchUpInside += delegate {
					popupView.Hidden = true;
				};

				viewUnawardConfirmationHead.AddSubviews (imageConfirm, lblBidCommentHead, btnPopupClose);

				UIView viewUnawardConfirmationContent = new UIView (new CGRect (0, viewUnawardConfirmationHead.Frame.Y + viewUnawardConfirmationHead.Frame.Height, viewUnawardConfirmation.Frame.Width, 85));


				UILabel lblBidComment = new UILabel (new CGRect (10, 0, viewUnawardConfirmationContent.Frame.Width - 10, viewUnawardConfirmationContent.Frame.Height));
				lblBidComment.Font = UIFont.FromName (Constants.strFontName, 13f);
				lblBidComment.Lines = 0;

				lblBidComment.Text = message;


				viewUnawardConfirmationContent.AddSubview (lblBidComment);

				UIView viewBottomSeparator = new UIView (new CGRect (0, viewUnawardConfirmationContent.Frame.Y + viewUnawardConfirmationContent.Frame.Height, viewUnawardConfirmation.Frame.Width, 0.5));
				viewBottomSeparator.BackgroundColor = Constants.conversationHeadClr;

				UIButton btnOk = new UIButton (new CGRect (viewUnawardConfirmation.Frame.Width - 160, viewBottomSeparator.Frame.Bottom + 5, 50, 25));
				btnOk.SetTitle (Constants.btnTextOk, UIControlState.Normal);
				btnOk.BackgroundColor = UIColor.White;
				btnOk.SetTitleColor(UIColor.Black,UIControlState.Normal);
				btnOk.Layer.BorderColor = UIColor.Black.CGColor;
				btnOk.Layer.CornerRadius = 5;
				btnOk.Layer.BorderWidth = 1;

				UIButton btnCancel = new UIButton (new CGRect (viewUnawardConfirmation.Frame.Width - 100, viewBottomSeparator.Frame.Bottom + 5, 80, 25));
				btnCancel.SetTitle (Constants.btnTextCancel, UIControlState.Normal);
				btnCancel.BackgroundColor = Constants.btnColorBlue;
				btnCancel.Layer.CornerRadius = 5;

				//btnOk.Layer.BorderWidth = 2;
				btnOk.TouchUpInside += delegate {
					objInvoiceController.CreateInvoice ();
					popupView.Hidden = true;
				};

				btnCancel.TouchUpInside += delegate {
					popupView.Hidden = true;
				};

				viewUnawardConfirmation.AddSubviews (viewTopMargin, viewUnawardConfirmationHead, viewUnawardConfirmationContent, viewBottomSeparator, btnOk, btnCancel);
				popupView.AddSubview (viewUnawardConfirmation);

				popupView.Hidden = false;

				return popupView;
			} catch {

				throw;
			}
		}

	}
}

