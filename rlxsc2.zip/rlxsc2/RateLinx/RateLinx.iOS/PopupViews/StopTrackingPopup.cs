﻿using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;
using System.Collections.Generic;
using CoreGraphics;
using RateLinx.Helper;
using RateLinx.Models;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using RateLinx.APIs;

namespace RateLinx.iOS
{
	public class StopTrackingPopup
	{
		UIView mainView;
		DashboardController objdashboardController;
		RecentShipments objRecentShipment;

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.StopTrackingPopup"/> class.
		/// </summary>
		/// <param name="view">View.</param>
		/// <param name="dashboardController">Dashboard controller.</param>
		/// <param name="recentShipment">Recent shipment.</param>
		public StopTrackingPopup(UIView view, DashboardController dashboardController,RecentShipments recentShipment)
		{
			mainView = view;
			this.objdashboardController = dashboardController;
			this.objRecentShipment = recentShipment;
		}

		/// <summary>
		/// Gets the popup screen.
		/// </summary>
		/// <returns>The popup screen.</returns>
		public UIView GetPopupScreen(nint tag)
		{
			try
			{
				UIView popupView = new UIView();
				popupView.Frame = mainView.Bounds;
				popupView.BackgroundColor = UIColor.Clear;

				UIView viewUnawardConfirmation = new UIView(new CGRect(10, 100, mainView.Frame.Width - 20, 170));
				viewUnawardConfirmation.BackgroundColor = UIColor.White;
				viewUnawardConfirmation.Layer.CornerRadius = 5;
				viewUnawardConfirmation.Layer.BorderWidth = 0.5f;

				UIView viewTopMargin = new UIView(new CGRect(0, 0, viewUnawardConfirmation.Frame.Width, 10));
				viewTopMargin.BackgroundColor = Constants.conversationHeadClr;
				viewTopMargin.Layer.CornerRadius = 5;

				UIView viewUnawardConfirmationHead = new UIView(new CGRect(0, 5, viewUnawardConfirmation.Frame.Width, 40));
				viewUnawardConfirmationHead.BackgroundColor = Constants.conversationHeadClr;

				UIImageView imageConfirm = new UIImageView(new CGRect(10, 8, 25, 20));
				imageConfirm.Image = UIImage.FromBundle("Images/warning.png");

				UILabel lblBidCommentHead = new UILabel(new CGRect(40, 6, 150, 24));

				lblBidCommentHead.BackgroundColor = Constants.conversationHeadClr;
				lblBidCommentHead.Font = UIFont.FromName(Constants.strFontName, 15f);
				lblBidCommentHead.Text = NSBundle.MainBundle.LocalizedString("Confirm", null);
				lblBidCommentHead.TextColor = UIColor.White;

				UIButton btnPopupClose = new UIButton(new CGRect(viewUnawardConfirmation.Frame.Width - 25, 5, 25, 20));
				btnPopupClose.Layer.CornerRadius = 10;

				btnPopupClose.ContentMode = UIViewContentMode.Center;
				btnPopupClose.SetImage(UIImage.FromBundle("Images/error.PNG"), UIControlState.Normal);



				btnPopupClose.TouchUpInside += delegate
				{
					popupView.Hidden = true;
				};

				viewUnawardConfirmationHead.AddSubviews(imageConfirm, lblBidCommentHead, btnPopupClose);

				UIView viewUnawardConfirmationContent = new UIView(new CGRect(0, viewUnawardConfirmationHead.Frame.Y + viewUnawardConfirmationHead.Frame.Height, viewUnawardConfirmation.Frame.Width, 85));


				UILabel lblBidComment = new UILabel(new CGRect(10, 0, viewUnawardConfirmationContent.Frame.Width - 10, viewUnawardConfirmationContent.Frame.Height));
				lblBidComment.Font = UIFont.FromName(Constants.strFontName, 13f);
				lblBidComment.Lines = 0;
				if (tag == 1)
				{
					lblBidComment.Text = NSBundle.MainBundle.LocalizedString("youWantTotrack", null);	
				}
				else
				{
					lblBidComment.Text = NSBundle.MainBundle.LocalizedString("stopAllTracking", null);	
				}


				viewUnawardConfirmationContent.AddSubview(lblBidComment);

				UIView viewBottomSeparator = new UIView(new CGRect(0, viewUnawardConfirmationContent.Frame.Y + viewUnawardConfirmationContent.Frame.Height, viewUnawardConfirmation.Frame.Width, 0.5));
				viewBottomSeparator.BackgroundColor = Constants.conversationHeadClr;

				UIButton btnOk = new UIButton(new CGRect(viewUnawardConfirmation.Frame.Width - 160, viewBottomSeparator.Frame.Bottom + 5, 50, 25));
				btnOk.SetTitle(Constants.btnTextYes, UIControlState.Normal);
				btnOk.BackgroundColor = UIColor.White;
				btnOk.SetTitleColor(UIColor.Black, UIControlState.Normal);
				btnOk.Layer.BorderColor = UIColor.Black.CGColor;
				btnOk.Layer.CornerRadius = 5;
				btnOk.Layer.BorderWidth = 1;

				UIButton btnCancel = new UIButton(new CGRect(viewUnawardConfirmation.Frame.Width - 100, viewBottomSeparator.Frame.Bottom + 5, 80, 25));
				btnCancel.SetTitle(Constants.btnTextNo, UIControlState.Normal);
				btnCancel.BackgroundColor = Constants.btnColorBlue;
				btnCancel.Layer.CornerRadius = 5;
				//btnOk.Layer.BorderWidth = 2;
				btnOk.TouchUpInside += delegate
				{
					if (tag ==1)
					{
						if (objRecentShipment != null)
						{
							objdashboardController.StopLiveTracking(objRecentShipment);
						}
					}
					else
					{
						objdashboardController.StopAllTracking();
					}
					popupView.Hidden = true;
				};

				btnCancel.TouchUpInside += delegate
				{
					popupView.Hidden = true;
				};

				viewUnawardConfirmation.AddSubviews(viewTopMargin, viewUnawardConfirmationHead, viewUnawardConfirmationContent, viewBottomSeparator, btnOk, btnCancel);
				popupView.AddSubview(viewUnawardConfirmation);

				popupView.Hidden = false;
				return popupView;
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
				return null;
			}
		}
	}
}
