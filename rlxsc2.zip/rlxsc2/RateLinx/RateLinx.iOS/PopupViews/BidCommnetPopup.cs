﻿using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;
using System.Collections.Generic;
using CoreGraphics;
using RateLinx.Helper;
using RateLinx.Models;

namespace RateLinx.iOS
{
	public class BidCommnetPopup
	{

		#region Variable Declaration

		UIView mainView;
		Entry objEntry;

		#endregion

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.BidCommnetPopup"/> class.
		/// </summary>
		/// <param name="view">View.</param>
		/// <param name="objEntry">Object entry.</param>
		public BidCommnetPopup(UIView view, Entry objEntry)
		{
			mainView = view;
			this.objEntry = objEntry;
		}

		/// <summary>
		/// Gets the popup screen.
		/// </summary>
		/// <returns>The popup screen.</returns>
		public UIView GetPopupScreen()
		{
			try
			{
				Constants.isRateEntry = true;
				UIView popupView = new UIView();
				popupView.Frame = mainView.Bounds;
				popupView.BackgroundColor = UIColor.Clear;

				UIView viewBidComment = new UIView(new CGRect(10, 100, mainView.Frame.Width - 20, 200));
				viewBidComment.BackgroundColor = UIColor.White;
				viewBidComment.Layer.CornerRadius = 5;
				viewBidComment.Layer.BorderWidth = 0.5f;

				UIView viewTopMargin = new UIView(new CGRect(0, 0, viewBidComment.Frame.Width, 10));
				viewTopMargin.BackgroundColor = Constants.conversationHeadClr;
				viewTopMargin.Layer.CornerRadius = 5;




				UIView viewBidCommentHead = new UIView(new CGRect(0, 5, viewBidComment.Frame.Width, 40));
				viewBidCommentHead.BackgroundColor = Constants.conversationHeadClr;

				UILabel lblBidCommentHead = new UILabel(new CGRect(10, 6, viewBidComment.Frame.Width - 30, 24));

				lblBidCommentHead.BackgroundColor = Constants.conversationHeadClr;
				lblBidCommentHead.Font = UIFont.FromName(Constants.strFontName, 15f);
				lblBidCommentHead.Text = NSBundle.MainBundle.LocalizedString("rateEntries", null);
				lblBidCommentHead.TextColor = UIColor.White;

				UIButton btnPopupClose = new UIButton(new CGRect(viewBidComment.Frame.Width - 25, 5, 25, 20));
				btnPopupClose.Layer.CornerRadius = 10;

				btnPopupClose.ContentMode = UIViewContentMode.Center;
				btnPopupClose.SetImage(UIImage.FromBundle("Images/error.PNG"), UIControlState.Normal);

				btnPopupClose.TouchUpInside += delegate
				{
					popupView.Hidden = true;
				};

				viewBidCommentHead.AddSubviews(lblBidCommentHead, btnPopupClose);

				UIView viewBidCommentContent = new UIView(new CGRect(0, viewBidCommentHead.Frame.Y + viewBidCommentHead.Frame.Height, viewBidComment.Frame.Width, 105));


				UILabel lblBidComment = new UILabel(new CGRect(10, 20, viewBidCommentContent.Frame.Width - 10, 25));
				lblBidComment.Font = UIFont.FromName(Constants.strFontName, 13f);
				lblBidComment.Text = objEntry.Comments;


				viewBidCommentContent.AddSubview(lblBidComment);

				//UIView viewBottomSeparator = new UIView(new CGRect(0, viewBidCommentContent.Frame.Y + viewBidCommentContent.Frame.Height, viewBidComment.Frame.Width, 0.5));
				//viewBottomSeparator.BackgroundColor = Constants.conversationHeadClr;

				UIButton btnOk = new UIButton(new CGRect(viewBidComment.Frame.Width - 60, viewBidComment.Frame.Height - 40, 50, 30));
				btnOk.SetTitle(NSBundle.MainBundle.LocalizedString("okText", null), UIControlState.Normal);
				btnOk.BackgroundColor = Constants.btnColorBlue;
				btnOk.Layer.CornerRadius = 5;
				//btnOk.Layer.BorderWidth = 2;

				btnOk.TouchUpInside += delegate
				{
					popupView.Hidden = true;
				};

				//View.Add(popupView);
				//viewBidComment.AddSubviews(viewTopMargin, viewBidCommentHead, viewBidCommentContent, viewBottomSeparator, btnOk);
                viewBidComment.AddSubviews(viewTopMargin, viewBidCommentHead, viewBidCommentContent,  btnOk);
				popupView.AddSubview(viewBidComment);


				popupView.Hidden = false;



				return popupView;
			}
			catch
			{
				throw;
			}
		}

	}
}
