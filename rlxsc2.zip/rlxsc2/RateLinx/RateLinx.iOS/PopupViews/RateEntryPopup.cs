﻿using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;
using System.Collections.Generic;
using CoreGraphics;
using RateLinx.Helper;
using RateLinx.Models;


namespace RateLinx.iOS
{
	public class RateEntryPopup
	{
		UIView mainView;
		CarrierShipmentDetails lstShipmentDetail = null;
		ShipmentDetailController shipmentDetailController;

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.RateEntryPopup"/> class.
		/// </summary>
		/// <param name="view">View.</param>
		public RateEntryPopup(UIView view)
		{
			mainView = view;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.RateEntryPopup"/> class.
		/// </summary>
		/// <param name="view">View.</param>
		/// <param name="lstShipmentDetail">Lst shipment detail.</param>
		/// <param name="shipmentDetailController">Shipment detail controller.</param>
		public RateEntryPopup(UIView view, CarrierShipmentDetails lstShipmentDetail, ShipmentDetailController shipmentDetailController)
		{
			mainView = view;
			this.lstShipmentDetail = lstShipmentDetail;
			this.shipmentDetailController = shipmentDetailController;
		}

		/// <summary>
		/// Gets the popup screen.
		/// </summary>
		/// <returns>The popup screen.</returns>
		public UIView GetPopupScreen()
		{

			Constants.isRateEntry = true;
			UIView popupView = new UIView();
			popupView.Frame = mainView.Bounds;
			popupView.BackgroundColor = UIColor.Clear;

			UIView viewRateEntriesPopup = new UIView(new CGRect(10, 100, mainView.Frame.Width - 20, 200));
			viewRateEntriesPopup.BackgroundColor = UIColor.White;
			viewRateEntriesPopup.Layer.CornerRadius = 5;
			viewRateEntriesPopup.Layer.BorderWidth = 0.5f;

			UIView viewTopMargin = new UIView(new CGRect(0, 0, viewRateEntriesPopup.Frame.Width, 10));
			viewTopMargin.BackgroundColor = Constants.conversationHeadClr;
			viewTopMargin.Layer.CornerRadius = 5;


			UIView viewRateEntriesHead = new UIView(new CGRect(0, 5, viewRateEntriesPopup.Frame.Width, 40));
			viewRateEntriesHead.BackgroundColor = Constants.conversationHeadClr;

			UILabel lblRateEntryHead = new UILabel(new CGRect(10, 6, viewRateEntriesPopup.Frame.Width - 100, 24));

			lblRateEntryHead.BackgroundColor = Constants.conversationHeadClr;
			lblRateEntryHead.Font = UIFont.FromName(Constants.strFontName, 15f);
			lblRateEntryHead.Text = NSBundle.MainBundle.GetLocalizedString("rateEntriesHeader", null);
			lblRateEntryHead.TextColor = UIColor.White;

			UIButton btnPopupClose = new UIButton(new CGRect(viewRateEntriesPopup.Frame.Width - 25, 5, 25, 20));
			btnPopupClose.Layer.CornerRadius = 10;

			btnPopupClose.ContentMode = UIViewContentMode.Center;
			btnPopupClose.SetImage(UIImage.FromBundle("Images/error.PNG"), UIControlState.Normal);

			btnPopupClose.TouchUpInside += delegate
			{
				popupView.Hidden = true;
			};

			viewRateEntriesHead.AddSubviews(lblRateEntryHead, btnPopupClose);

			UIView viewRateEntryContent = new UIView(new CGRect(0, 50, viewRateEntriesPopup.Frame.Width, lstShipmentDetail.Entries.Count * 35 + 45));

			#region Rate Entries Section

			UIView viewRateEntriesTableHead = new UIView();

			nfloat xCordinateRateEntry = 2;
			UILabel lblAction1 = new UILabel(new CGRect(xCordinateRateEntry, 0, 100, 25));
			lblAction1.Font = UIFont.FromName(Constants.strFontName, 12f);
			lblAction1.TextAlignment = UITextAlignment.Center;
			lblAction1.Text = NSBundle.MainBundle.GetLocalizedString("action", null);
			lblAction1.TextColor = UIColor.White;
			lblAction1.BackgroundColor = Constants.fileHeadBGC;
			xCordinateRateEntry += lblAction1.Frame.Width + 1;

			UILabel lblAction2 = new UILabel(new CGRect(xCordinateRateEntry, 0, 0, 25));
			foreach (Entry objEntry in lstShipmentDetail.Entries)
			{
				if (!string.IsNullOrEmpty(objEntry.Comments))
				{
					lblAction2 = new UILabel(new CGRect(xCordinateRateEntry, 0, 100, 25));
					lblAction2.Font = UIFont.FromName(Constants.strFontName, 12f);
					lblAction2.TextAlignment = UITextAlignment.Center;
					lblAction2.Text = NSBundle.MainBundle.GetLocalizedString("action", null);
					lblAction2.TextColor = UIColor.White;
					lblAction2.BackgroundColor = Constants.fileHeadBGC;
					xCordinateRateEntry += lblAction2.Frame.Width + 1;

					Constants.isComments = true;
					break;
				}
			}
			UILabel lblCarrier = new UILabel(new CGRect(xCordinateRateEntry, 0, 100, 25));
			lblCarrier.Font = UIFont.FromName(Constants.strFontName, 12f);
			lblCarrier.TextAlignment = UITextAlignment.Center;
			lblCarrier.Text = NSBundle.MainBundle.GetLocalizedString("carrier", null);
			lblCarrier.TextColor = UIColor.White;
			lblCarrier.BackgroundColor = Constants.fileHeadBGC;
			xCordinateRateEntry += lblCarrier.Frame.Width + 1;

			UILabel lblCarrierName = new UILabel(new CGRect(xCordinateRateEntry, 0, 100, 25));
			lblCarrierName.Font = UIFont.FromName(Constants.strFontName, 12f);
			lblCarrierName.TextAlignment = UITextAlignment.Center;
			lblCarrierName.Text = NSBundle.MainBundle.GetLocalizedString("carrierName", null);
			lblCarrierName.TextColor = UIColor.White;
			lblCarrierName.BackgroundColor = Constants.fileHeadBGC;
			xCordinateRateEntry += lblCarrierName.Frame.Width + 1;

			UILabel lblShipmentCost = new UILabel(new CGRect(xCordinateRateEntry, 0, 100, 25));
			lblShipmentCost.Font = UIFont.FromName(Constants.strFontName, 12f);
			lblShipmentCost.TextAlignment = UITextAlignment.Center;
			lblShipmentCost.Text = NSBundle.MainBundle.GetLocalizedString("shipmentCost", null);
			lblShipmentCost.TextColor = UIColor.White;
			lblShipmentCost.BackgroundColor = Constants.fileHeadBGC;
			xCordinateRateEntry += lblShipmentCost.Frame.Width + 1;

			UILabel lblTermsAlt = new UILabel(new CGRect(xCordinateRateEntry, 0, 100, 25));
			lblTermsAlt.Font = UIFont.FromName(Constants.strFontName, 12f);
			lblTermsAlt.TextAlignment = UITextAlignment.Center;
			lblTermsAlt.Text = NSBundle.MainBundle.GetLocalizedString("termsAltered", null);
			lblTermsAlt.TextColor = UIColor.White;
			lblTermsAlt.BackgroundColor = Constants.fileHeadBGC;
			xCordinateRateEntry += lblTermsAlt.Frame.Width + 1;

			UILabel lblStatus = new UILabel(new CGRect(xCordinateRateEntry, 0, 100, 25));
			lblStatus.Font = UIFont.FromName(Constants.strFontName, 12f);
			lblStatus.TextAlignment = UITextAlignment.Center;
			lblStatus.Text = NSBundle.MainBundle.GetLocalizedString("status", null);
			lblStatus.TextColor = UIColor.White;
			lblStatus.BackgroundColor = Constants.fileHeadBGC;
			xCordinateRateEntry += lblStatus.Frame.Width + 1;

			UILabel lblAuthedBy = new UILabel(new CGRect(xCordinateRateEntry, 0, 100, 25));
			lblAuthedBy.Font = UIFont.FromName(Constants.strFontName, 12f);
			lblAuthedBy.TextAlignment = UITextAlignment.Center;
			lblAuthedBy.Text = NSBundle.MainBundle.GetLocalizedString("authedBy", null);
			lblAuthedBy.TextColor = UIColor.White;
			lblAuthedBy.BackgroundColor = Constants.fileHeadBGC;
			xCordinateRateEntry += lblAuthedBy.Frame.Width + 1;

			UILabel lblDateEntered = new UILabel(new CGRect(xCordinateRateEntry, 0, 200, 25));
			lblDateEntered.Font = UIFont.FromName(Constants.strFontName, 12f);
			lblDateEntered.TextAlignment = UITextAlignment.Center;
			lblDateEntered.Text = NSBundle.MainBundle.GetLocalizedString("dateEntered", null);
			lblDateEntered.TextColor = UIColor.White;
			lblDateEntered.BackgroundColor = Constants.fileHeadBGC;
			xCordinateRateEntry += lblDateEntered.Frame.Width + 1;

			UILabel lblAwarded = new UILabel(new CGRect(xCordinateRateEntry, 0, 100, 25));
			lblAwarded.Font = UIFont.FromName(Constants.strFontName, 12f);
			lblAwarded.TextAlignment = UITextAlignment.Center;
			lblAwarded.Text = NSBundle.MainBundle.GetLocalizedString("awarded", null);
			lblAwarded.TextColor = UIColor.White;
			lblAwarded.BackgroundColor = Constants.fileHeadBGC;
			xCordinateRateEntry += lblAwarded.Frame.Width + 1;

			UILabel lblReason = new UILabel(new CGRect(xCordinateRateEntry, 0, 100, 25));
			lblReason.Font = UIFont.FromName(Constants.strFontName, 12f);
			lblReason.TextAlignment = UITextAlignment.Center;
			lblReason.Text = NSBundle.MainBundle.GetLocalizedString("reason", null);
			lblReason.TextColor = UIColor.White;
			lblReason.BackgroundColor = Constants.fileHeadBGC;
			xCordinateRateEntry += lblReason.Frame.Width + 1;
			viewRateEntriesTableHead.AddSubviews(lblAction1, lblAction2, lblCarrier, lblCarrierName, lblShipmentCost, lblTermsAlt, lblStatus,
				lblAuthedBy, lblDateEntered, lblAwarded, lblReason);
			//lblRateEntryHead.Frame = new CGRect(0, 0, xCordinateRateEntry, 25);
			UIScrollView scrollView = new UIScrollView
			{
				Frame = new CGRect(0, 10, viewRateEntryContent.Frame.Width, (lstShipmentDetail.Entries.Count * 35 + 50)),
				ContentSize = new CGSize(xCordinateRateEntry + 2, (lstShipmentDetail.Entries.Count * 35 + 30)),
				//AutoresizingMask = UIViewAutoresizing.FlexibleWidth,
				Bounces = false
			};

			viewRateEntriesTableHead.Frame = new CGRect(0, 10, scrollView.Frame.Width - 20, 25);
			scrollView.AddSubview(viewRateEntriesTableHead);

			UITableView tblRateEntries = new UITableView(new CGRect(2, viewRateEntriesTableHead.Frame.Height + 10, xCordinateRateEntry, lstShipmentDetail.Entries.Count * 35 + 10));

			tblRateEntries.Source = new RateEntriesAdapter(lstShipmentDetail.Entries, mainView, lstShipmentDetail, shipmentDetailController);
			tblRateEntries.AllowsSelection = false;
			tblRateEntries.UserInteractionEnabled = true;
			tblRateEntries.RowHeight = 25;
			tblRateEntries.Bounces = false;

			scrollView.AddSubview(tblRateEntries);
			viewRateEntryContent.AddSubview(scrollView);
			#endregion

			UIView viewBottomSeparator = new UIView(new CGRect(0, viewRateEntryContent.Frame.Y + viewRateEntryContent.Frame.Height, viewRateEntriesPopup.Frame.Width, 0.5));
			viewBottomSeparator.BackgroundColor = Constants.conversationHeadClr;

			UIButton btnOk = new UIButton(new CGRect(viewRateEntriesPopup.Frame.Width - 60, viewBottomSeparator.Frame.Y + 15, 50, 30));
			btnOk.SetTitle(NSBundle.MainBundle.GetLocalizedString("okText", null), UIControlState.Normal);
			btnOk.BackgroundColor = Constants.btnColorBlue;
			btnOk.Layer.CornerRadius = 5;
			//btnOk.Layer.BorderWidth = 2;
			btnOk.TouchUpInside += delegate
			{
				popupView.Hidden = true;
			};
			viewRateEntriesPopup.Frame = new CGRect(10, 100, mainView.Frame.Width - 20, btnOk.Frame.Y + btnOk.Frame.Height + 20);
			viewRateEntriesPopup.AddSubviews(viewTopMargin, viewRateEntriesHead, viewRateEntryContent, viewBottomSeparator, btnOk);
			popupView.AddSubview(viewRateEntriesPopup);
			popupView.Hidden = false;

			return popupView;
		}
	}
}
