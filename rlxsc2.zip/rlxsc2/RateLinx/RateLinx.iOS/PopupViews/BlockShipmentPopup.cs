﻿using System;
using UIKit;
using CoreGraphics;
using RateLinx.Helper;
using Foundation;

namespace RateLinx.iOS
{
	public class BlockShipmentPopup
	{
		#region Variable Declaration

		UIView mainView;
		ShipmentDetailController ShipmentDetailController;

		#endregion

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.BlockShipmentPopup"/> class.
		/// </summary>
		/// <param name="view">View.</param>
		/// <param name="objShipmentDetailController">Object shipment detail controller.</param>
		public BlockShipmentPopup(UIView view, ShipmentDetailController objShipmentDetailController)
		{
			mainView = view;
			this.ShipmentDetailController = objShipmentDetailController;
		}

		/// <summary>
		/// Gets the popup screen.
		/// </summary>
		/// <returns>The popup screen.</returns>
		public UIView GetPopupScreen()
		{
			try
			{
				UIView popupView = new UIView();
				popupView.Frame = mainView.Bounds;
				popupView.BackgroundColor = UIColor.Clear;

				UIView viewUnawardConfirmation = new UIView(new CGRect(10, 100, mainView.Frame.Width - 20, 185));
				viewUnawardConfirmation.BackgroundColor = UIColor.White;
				viewUnawardConfirmation.Layer.CornerRadius = 5;
				viewUnawardConfirmation.Layer.BorderWidth = 0.5f;

				UIView viewTopMargin = new UIView(new CGRect(0, 0, viewUnawardConfirmation.Frame.Width, 10));
				viewTopMargin.BackgroundColor = Constants.conversationHeadClr;
				viewTopMargin.Layer.CornerRadius = 5;

				UIView viewUnawardConfirmationHead = new UIView(new CGRect(0, 5, viewUnawardConfirmation.Frame.Width, 40));
				viewUnawardConfirmationHead.BackgroundColor = Constants.conversationHeadClr;

				UIImageView imageConfirm = new UIImageView(new CGRect(10, 8, 25, 20));
				imageConfirm.Image = UIImage.FromBundle("Images/warning.png");

				UILabel lblBidCommentHead = new UILabel(new CGRect(40, 6, 150, 24));

				lblBidCommentHead.BackgroundColor = Constants.conversationHeadClr;
				lblBidCommentHead.Font = UIFont.FromName(Constants.strFontName, 15f);
				lblBidCommentHead.Text = Constants.strDialogHdr + "!";
				lblBidCommentHead.TextColor = UIColor.White;

				UIButton btnPopupClose = new UIButton(new CGRect(viewUnawardConfirmation.Frame.Width - 25, 5, 25, 20));
				btnPopupClose.Layer.CornerRadius = 10;

				btnPopupClose.ContentMode = UIViewContentMode.Center;
				btnPopupClose.SetImage(UIImage.FromBundle("Images/error.PNG"), UIControlState.Normal);



				btnPopupClose.TouchUpInside += delegate
				{
					popupView.Hidden = true;
				};

				viewUnawardConfirmationHead.AddSubviews(imageConfirm, lblBidCommentHead, btnPopupClose);

				UIView viewUnawardConfirmationContent = new UIView(new CGRect(0, viewUnawardConfirmationHead.Frame.Y + viewUnawardConfirmationHead.Frame.Height, viewUnawardConfirmation.Frame.Width, 100));


				UILabel lblBidComment = new UILabel(new CGRect(10, 0, viewUnawardConfirmationContent.Frame.Width - 10, 25));
				lblBidComment.Font = UIFont.FromName(Constants.strFontName, 13f);
				lblBidComment.Lines = 0;
				lblBidComment.Text = ConstantsClass.strBlock;

				UILabel lblenterReson = new UILabel(new CGRect(10, lblBidComment.Frame.Y + lblBidComment.Frame.Height, viewUnawardConfirmationContent.Frame.Width - 10, 25));
				lblenterReson.Font = UIFont.FromName(Constants.strFontName, 13f);
				lblenterReson.Lines = 0;
				lblenterReson.Text = ConstantsClass.strEnterReason;

				UITextView txtEnterReason = new UITextView(new CGRect(10, lblenterReson.Frame.Y + lblenterReson.Frame.Height, viewUnawardConfirmationHead.Frame.Width-20, 35));
				txtEnterReason.Layer.BorderWidth = 1;
				txtEnterReason.Layer.CornerRadius = 5;

				viewUnawardConfirmationContent.AddSubviews(lblBidComment,lblenterReson,txtEnterReason);

				UIView viewBottomSeparator = new UIView(new CGRect(0, viewUnawardConfirmationContent.Frame.Y + viewUnawardConfirmationContent.Frame.Height, viewUnawardConfirmation.Frame.Width, 0.5));
				viewBottomSeparator.BackgroundColor = Constants.conversationHeadClr;

				UIButton btnOk = new UIButton(new CGRect(viewUnawardConfirmation.Frame.Width - 160, viewBottomSeparator.Frame.Bottom + 5, 50, 25));
				btnOk.SetTitle(Constants.btnTextYes, UIControlState.Normal);
				btnOk.BackgroundColor = UIColor.White;
				btnOk.SetTitleColor(UIColor.Black, UIControlState.Normal);
				btnOk.Layer.BorderColor = UIColor.Black.CGColor;
				btnOk.Layer.CornerRadius = 5;
				btnOk.Layer.BorderWidth = 1;

				UIButton btnCancel = new UIButton(new CGRect(viewUnawardConfirmation.Frame.Width - 100, viewBottomSeparator.Frame.Bottom + 5, 80, 25));
				btnCancel.SetTitle(Constants.btnTextNo, UIControlState.Normal);
				btnCancel.BackgroundColor = Constants.btnColorBlue;
				btnCancel.Layer.CornerRadius = 5;

				//btnOk.Layer.BorderWidth = 2;
				btnOk.TouchUpInside += async delegate
				{
					await ShipmentDetailController.BlockShipment(txtEnterReason.Text);
					popupView.Hidden = true;
				};

				btnCancel.TouchUpInside += delegate
				{
					popupView.Hidden = true;
				};

				viewUnawardConfirmation.AddSubviews(viewTopMargin, viewUnawardConfirmationHead, viewUnawardConfirmationContent, viewBottomSeparator, btnOk, btnCancel);
				popupView.AddSubview(viewUnawardConfirmation);

				popupView.Hidden = false;

				return popupView;
			}
			catch
			{

				throw;
			}
		}
	}
}
