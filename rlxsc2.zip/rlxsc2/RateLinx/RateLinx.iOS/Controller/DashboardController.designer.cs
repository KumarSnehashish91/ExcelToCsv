// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace RateLinx.iOS
{
    [Register ("DashboardController")]
    partial class DashboardController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView ActiveShipmentVW { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView AwardedShipmentVW { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnActive { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnAwareded { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnRecent { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgActiveShip { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgAwardedShip { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgBack { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgMenu { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgRecentShip { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblCopyRight { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView RecentShipmentVW { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITableView tblActiveShipment { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITableView tblAwardedShipment { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITableView tblRecentShipment { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewActiveShipment { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewAwarededShipment { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewContainer { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewDivider2 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewHomeHeader { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewRecentShipments { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (ActiveShipmentVW != null) {
                ActiveShipmentVW.Dispose ();
                ActiveShipmentVW = null;
            }

            if (AwardedShipmentVW != null) {
                AwardedShipmentVW.Dispose ();
                AwardedShipmentVW = null;
            }

            if (btnActive != null) {
                btnActive.Dispose ();
                btnActive = null;
            }

            if (btnAwareded != null) {
                btnAwareded.Dispose ();
                btnAwareded = null;
            }

            if (btnRecent != null) {
                btnRecent.Dispose ();
                btnRecent = null;
            }

            if (imgActiveShip != null) {
                imgActiveShip.Dispose ();
                imgActiveShip = null;
            }

            if (imgAwardedShip != null) {
                imgAwardedShip.Dispose ();
                imgAwardedShip = null;
            }

            if (imgBack != null) {
                imgBack.Dispose ();
                imgBack = null;
            }

            if (imgMenu != null) {
                imgMenu.Dispose ();
                imgMenu = null;
            }

            if (imgRecentShip != null) {
                imgRecentShip.Dispose ();
                imgRecentShip = null;
            }

            if (lblCopyRight != null) {
                lblCopyRight.Dispose ();
                lblCopyRight = null;
            }

            if (RecentShipmentVW != null) {
                RecentShipmentVW.Dispose ();
                RecentShipmentVW = null;
            }

            if (tblActiveShipment != null) {
                tblActiveShipment.Dispose ();
                tblActiveShipment = null;
            }

            if (tblAwardedShipment != null) {
                tblAwardedShipment.Dispose ();
                tblAwardedShipment = null;
            }

            if (tblRecentShipment != null) {
                tblRecentShipment.Dispose ();
                tblRecentShipment = null;
            }

            if (viewActiveShipment != null) {
                viewActiveShipment.Dispose ();
                viewActiveShipment = null;
            }

            if (viewAwarededShipment != null) {
                viewAwarededShipment.Dispose ();
                viewAwarededShipment = null;
            }

            if (viewContainer != null) {
                viewContainer.Dispose ();
                viewContainer = null;
            }

            if (viewDivider2 != null) {
                viewDivider2.Dispose ();
                viewDivider2 = null;
            }

            if (viewHomeHeader != null) {
                viewHomeHeader.Dispose ();
                viewHomeHeader = null;
            }

            if (viewRecentShipments != null) {
                viewRecentShipments.Dispose ();
                viewRecentShipments = null;
            }
        }
    }
}