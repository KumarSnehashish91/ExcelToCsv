using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;
using System.Collections.Generic;
using CoreGraphics;
using RateLinx.Helper;
using RateLinx.Models;
using Newtonsoft.Json.Linq;
using RateLinx.APIs;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;
using System.Runtime.InteropServices;
using System.Linq;

namespace RateLinx.iOS
{
	public class NextPreviousToolBar : UIToolbar
	{
		public UIView prevTextField { get; set; }
		public UIView currentTextField { get; set; }
		public UIView nextTextField { get; set; }
		public NextPreviousToolBar() : base()
		{
		}
		/// <summary>
		/// Initializes a new instance of the <see cref="T:SSSportsExchange.iOS.NextPreviousToolBar"/> class.
		/// </summary>
		/// <param name="curr">Curr.</param>
		/// <param name="prev">Previous.</param>
		/// <param name="next">Next.</param>
		public NextPreviousToolBar(UIView curr, UIView prev, UIView next)
		{
			this.currentTextField = curr;
			this.prevTextField = prev;
			this.nextTextField = next;

			AddButtonsToToolBar();
		}
		/// <summary>
		/// Adds the buttons to tool bar.
		/// </summary>
		void AddButtonsToToolBar()
		{
			Frame = new CoreGraphics.CGRect(0.0f, 0.0f, 320, 44.0f);
			TintColor = UIColor.DarkGray;
			Translucent = false;
			Items = new UIBarButtonItem[] {
								//		new UIBarButtonItem ("Prev",
								//	UIBarButtonItemStyle.Bordered, delegate {
								//		prevTextField.BecomeFirstResponder ();
								//	} ) { Enabled = prevTextField != null },
								//new UIBarButtonItem ("Next",
								//	UIBarButtonItemStyle.Bordered, delegate {
								//		nextTextField.BecomeFirstResponder ();
								//	} ) { Enabled = nextTextField != null },
								new
								UIBarButtonItem (UIBarButtonSystemItem.FlexibleSpace),
								new UIBarButtonItem (UIBarButtonSystemItem.Done, delegate {
									currentTextField.ResignFirstResponder ();



										} )
									};
		}
	}

	public partial class ShipmentDetailController : UIViewController
	{

		#region Global used controls
		public string compositeKey;
		string strToken = string.Empty;
		//string refresh = string.Empty;
		CarrierShipmentDetails lstShipmentDetail = null;
		//CommanUtil objCommanUtil = null;
		JObject jobject = null;
		ServiceHelper objServicehelper = null;
		string methodName = string.Empty;
		//UIScrollView scrollView;
		string strResponse = string.Empty;
		UITapGestureRecognizer tapGesture, tapGestureRateDetail, tapGestureSupporting, tapGestureNewRate, tapGestureConversations, tapRateEntryImg,
		tapGestureInvoice, tapGestureTrackingInfo, tapGestureReplyContainer;
		UISwipeGestureRecognizer swipeRateDetail, swipeSupportingToRateDetail, swipeSupportingToNewRate,
			swipeNewRateToSupporting, swipeNewRateToConversation, swipConversations;
		LoadingOverlay loadPop;
		CustomPopup customAlert = null;
		private SupportingFileAdapter objSupportingFileAdapter;
		List<string> lstFiles = null;
		string fileUrl = string.Empty;
		UIImagePickerController imagePicker = null;
		byte[] bytes = null;
		string fileName = null;
		FileUploadHelper objFileUploadHelper = null;
		bool isAcknowledge, isRateCheck = false;
        UITextField txtBaseCharge, txtAccessCharge, txtFuelCharge, txtComments = null;
        UITextView txtReply, txtDeliveryDate, txtDelTime1, txtDelTime2 = null;
		UIButton btnSubmitRate;
		//, btnReSubmit, btnRateHistory
		DateTime pickupDate_dt = DateTime.Today;
		//dateTime2
		bool isReviewedNdAck = false;
		bool isAlteredTerms = false;
		string delDate = string.Empty;
		string delTime1 = string.Empty;
		string delTime2 = string.Empty;
		string payload_str = string.Empty;
		string[] activityDate = new string[2];
		string[] strArrayDelDate = null;
		//string newDelDate = string.Empty;
		static string id = string.Empty;
		UITableView tblRateEntries;
		string ActivityDate, ratePayload, pickupDtTm_str = string.Empty;
		ModalPickerViewController modalPicker = null;
		UIView viewReply, viewReplyContainer;
		UILabel lblSumCharge;
		UIPickerView pickerView = null;
		UIButton doneButton = null;
		UIView viewPicker = null;
		string shipmentResult = string.Empty;
		private NSObject _didShowNotificationObserver;
		private NSObject _willHideNotificationObserver;
		private nfloat amountToScroll = 0.0f;
		private bool isViewDisappeared = false;
		UIToolbar toolbar;
		public int tabNumber = 1;
		bool isBrowsingFile = false;

		bool viewLoaded = false;
		//bool isOrientationchanged = false;
		#endregion


		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.ShipmentDetailController"/> class.
		/// </summary>
		/// <param name="handle">Handle.</param>
		public ShipmentDetailController(IntPtr handle) : base(handle)
		{
			viewReply = new UIView();
			viewReplyContainer = new UIView();
			txtReply = new UITextView();

		}


		/// <summary>
		/// Views the did load.
		/// </summary>
		public override async void ViewDidLoad()
		{
			try
			{
				base.ViewDidLoad();


				lblCopyRight.Text = Util.GetCopyRight();
				viewLoaded = true;
				isViewDisappeared = false;
				NavigationController.NavigationBarHidden = true;

				NavigationController.SetNavigationBarHidden(true, true);

				#region Move UI View Up Handling
				// Keyboard popup
				//_didShowNotificationObserver = NSNotificationCenter.DefaultCenter.AddObserver
				//								(UIKeyboard.DidShowNotification, KeyBoardDidShow, this);

				//// Keyboard Down
				//_willHideNotificationObserver = NSNotificationCenter.DefaultCenter.AddObserver
				//													(UIKeyboard.WillHideNotification, KeyBoardWillHide, this);
				#endregion

				if (Util.currentTabAssigned == 4)
				{
					tabNumber = Util.currentTabAssigned;
					Util.currentTabAssigned = 0;
				}
				else
				{
					Util.currentTabAssigned = 0;
				}
				//Bind Shipment Details

				strToken = CommanUtil.tokenNo;
				lblBolNo.Text = compositeKey.Split('|')[1];
				await BindShipmentDetails();
				if (string.IsNullOrEmpty(shipmentResult))
				{
					//Tap Gesture 
					TapGestureRecognizer();
					//Slide Gesture
					SwipeGestureRecognizer();
					SupportingController();
					viewHeaderShipDetails.BackgroundColor = UIColor.FromPatternImage(UIImage.FromFile("Images/top-bg.png"));
					viewShipmentHead.BackgroundColor = UIColor.FromPatternImage(UIImage.FromFile("Images/top-bg.png"));
					tblRateDetails.Frame = RateDetailView.Bounds;

					tblRateDetails.Bounces = false;
					tblRateDetails.Source = new RateDetailsAdapter(lstShipmentDetail, this);
					tblRateDetails.AllowsSelection = false;
					tblRateDetails.TableFooterView = new UIView(CGRect.Empty);
					tblRateDetails.ReloadData();
					tblFileDetails.AllowsSelection = false;
					if (lstShipmentDetail.CanInvoice)
					{
						imgInvoice.Hidden = false;
						imgInvoice.Image = UIImage.FromBundle("Images/invoice.png");
					}
					else
					{
						imgInvoice.Hidden = true;
					}
					if (lstShipmentDetail.CanAddTracking)
					{
                        if (lstShipmentDetail.DispatchFlag && string.IsNullOrEmpty(lstShipmentDetail.DriverID))
                        {
                            imgTrackingInfo.Hidden = true;
                        }
                        else
                        {
                            imgTrackingInfo.Image = UIImage.FromBundle("Images/tracking.png");
                            imgTrackingInfo.Tag = 1;
                        }
					}
					else
					{
						if (lstShipmentDetail.ViewAs.ToUpper() == Constants.strCustomer.ToUpper() && lstShipmentDetail.Status.ToUpper() == Constants.strClosed.ToUpper())
						{
							imgTrackingInfo.Image = UIImage.FromBundle("Images/bol.png");
							imgTrackingInfo.Tag = 2;
						}
					}
					if (lstShipmentDetail.ViewAs.ToUpper() == Constants.strCustomer.ToUpper())
					{
						lblNewRate.Text = "RATE ENTRIES";
					}
					else
					{
						lblNewRate.Text = "PLACE NEW RATE";
					}
					NewRateSection();
					ConversationSection();
					//UIView divider1 = new UIView(new CGRect(viewDetailsFooter.Frame.Width / 4, 0, 1,viewDetailsFooter.Frame.Height));
					//UIView divider2 = new UIView(new CGRect(viewDetailsFooter.Frame.Width / 4 *2, 0, 1, viewDetailsFooter.Frame.Height));
					//UIView divider3 = new UIView(new CGRect(viewDetailsFooter.Frame.Width / 4 *3, 0, 1, viewDetailsFooter.Frame.Height));
					////UIView viewSlider = new UIView(new CGRect(0, 0, viewDetailsFooter.Frame.Width / 4, 2));
					////viewSlider.BackgroundColor = UIColor.Red;
					//viewDetailsFooter.AddSubviews(divider1, divider2, divider3);
					#region When Clicked out side keyboard, Close the Keyboard
					UITapGestureRecognizer g_recognizer = new UITapGestureRecognizer(() =>
					{
						txtReply.ResignFirstResponder();
					});

					this.View.AddGestureRecognizer(g_recognizer);
					#endregion
					#region Add Next,Previous Buttons to Toolbar
					txtReply.InputAccessoryView = new NextPreviousToolBar(txtReply, null, null);

					#endregion
				}
				else
				{
					CommanUtil.shipmentDetail = true;
					shipmentResult = string.Empty;
					this.NavigationController.PopViewController(true);
				}
			}
			catch (Exception ex)
			{
				Console.Write(ex.Message);
			}
		}

		public override UIInterfaceOrientationMask GetSupportedInterfaceOrientations()
		{
			return UIInterfaceOrientationMask.Portrait;
		}

		public override void ViewDidAppear(bool animated)
		{
			base.ViewDidAppear(animated);
			if (isBrowsingFile)
			{
				isBrowsingFile = false;
			}
			else
			{
				if (isViewDisappeared)
				{
					if (Util.isViewRotated)
					{
						ViewForOrientationChange();
						Util.isViewRotated = false;
					}
					else
					{
						Util.isViewRotated = false;
					}
					isViewDisappeared = false;
				}
				else
				{
					isViewDisappeared = false;
				}
			}
		}

		public override void ViewDidDisappear(bool animated)
		{ 
			base.ViewDidAppear(animated);
			isViewDisappeared = true;
		}

		public override void DidRotate(UIInterfaceOrientation fromInterfaceOrientation)
		{
			ViewForOrientationChange();
		}

		public void ViewForOrientationChange()
		{
			viewReply.Hidden = true;
			if (tabNumber == 1)
			{
				tblRateDetails.Frame = RateDetailView.Bounds;
				tblRateDetails.ReloadData();
				tblFileDetails.ReloadData();
				NewRateSection();
				ConversationSection();
				tblConversation.ReloadData();
			}
			else if (tabNumber == 2)
			{
				tblFileDetails.Frame = viewFileContainer.Bounds;
				tblRateDetails.ReloadData();
				tblFileDetails.ReloadData();
				NewRateSection();
				ConversationSection();
				tblConversation.ReloadData();
			}
			else if (tabNumber == 3)
			{
				tblRateDetails.ReloadData();
				tblFileDetails.ReloadData();
				NewRateSection();
				ConversationSection();
				tblConversation.ReloadData();
			}
			else
			{
				tblRateDetails.ReloadData();
				tblFileDetails.ReloadData();
				NewRateSection();
				ConversationSection();
				tblConversation.ReloadData();
			}

		}
		#region ViewWillAppear

		public override void ViewWillAppear(bool animated)
		{
			base.ViewWillAppear(animated);
			_didShowNotificationObserver = NSNotificationCenter.DefaultCenter.AddObserver(UIKeyboard.DidShowNotification, KeyBoardDidShow);

			_willHideNotificationObserver = NSNotificationCenter.DefaultCenter.AddObserver(UIKeyboard.WillHideNotification, KeyBoardWillHide);
		}
		#endregion


		#region ViewWillDisappear
		public override void ViewWillDisappear(bool animated)
		{
			base.ViewWillDisappear(animated);
			if (_didShowNotificationObserver != null)
			{
				NSNotificationCenter.DefaultCenter.RemoveObserver(_didShowNotificationObserver);
			}

			if (_willHideNotificationObserver != null)
			{
				NSNotificationCenter.DefaultCenter.RemoveObserver(_willHideNotificationObserver);
			}
		}
		#endregion

		#region KeyBoardDidShow
		private void KeyBoardDidShow(NSNotification notification)
		{
			// get the keyboard size
			CGRect notificationBounds = UIKeyboard.BoundsFromNotification(notification);

			if (txtReply.IsFirstResponder && amountToScroll == 0)
			{
				amountToScroll = notificationBounds.Height - 100;
				ScrollTheView();
			}
			else
			{
				
			}

		}
		#endregion

		#region KeyBoardWillHide
		/// <summary>
		/// Keies the board will hide.
		/// </summary>
		/// <param name="notification">Notification.</param>
		private void KeyBoardWillHide(NSNotification notification)
		{
			amountToScroll = 0;
			viewShipmentDetails.Frame = new CGRect(0, 20, View.Frame.Width, View.Frame.Height - 20);
		
		}
		#endregion

		#region ScrollTheView
		/// <summary>
		/// Scrolls the view.
		/// </summary>
		/// <param name="move">If set to <c>true</c> move.</param>
		private void ScrollTheView()
		{

			// scroll the view up or down
			UIView.BeginAnimations(string.Empty, System.IntPtr.Zero);
			UIView.SetAnimationDuration(0.3);

			CGRect frame = viewShipmentDetails.Frame;

			frame.Y = -amountToScroll;

			viewShipmentDetails.Frame = frame;
			UIView.CommitAnimations();
		}
		#endregion


		#region DidReceiveMemoryWarning
		/// <Docs>Called when the system is running low on memory.</Docs>
		/// <summary>
		/// Dids the receive memory warning.
		/// </summary>
		public override void DidReceiveMemoryWarning()
		{
			base.DidReceiveMemoryWarning();
			// Release any cached data, images, etc that aren't in use.
		}

		#endregion


		/// <summary>
		/// Views the did appear.
		/// </summary>
		/// <param name="animated">If set to <c>true</c> animated.</param>
		//public override void ViewDidAppear(bool animated)
		//{
		//	try
		//	{
		//		base.ViewDidAppear(animated);

		//		//managingTab();
		//	}
		//	catch (Exception ex)
		//	{
		//		Console.Write(ex.Message);
		//	}
		//}

		/// <summary>
		/// Managings the tab. Changing Text Color and image Click on tabs
		/// </summary>
		void managingTab()
		{
			try
			{
				if (compositeKey.Split('|')[2].Equals(ConstantsClass.strCompose) || compositeKey.Split('|')[2].Equals(ConstantsClass.strReply))
				{
					RateDetailView.Hidden = true;
					ConversationView.Hidden = false;
					NewRateView.Hidden = true;
					SupportingView.Hidden = true;

					ShipmentsIconTextChange(UIColor.Black, UIColor.Black, UIColor.Black,
					UIColor.Red, "RateEntry", "Supporting",
					"NewRate", "ConversationHover");

				}
				else if (compositeKey.Split('|')[2].Equals(ConstantsClass.strBid))
				{
					tabNumber = 3;
					RateDetailView.Hidden = true;
					ConversationView.Hidden = true;
					NewRateView.Hidden = false;
					SupportingView.Hidden = true;

					ShipmentsIconTextChange(UIColor.Black, UIColor.Black, UIColor.Red,
					UIColor.Black, "RateEntry", "Supporting",
					"NewRateHover", "Conversation");

				}
				else if (compositeKey.Split('|')[2].Equals(ConstantsClass.strSupport))
				{
					RateDetailView.Hidden = true;
					ConversationView.Hidden = true;
					NewRateView.Hidden = true;
					SupportingView.Hidden = false;

					ShipmentsIconTextChange(UIColor.Black, UIColor.Red, UIColor.Black,
	UIColor.Black, "RateEntry", "SupportingHover",
											"NewRate", "Conversation");
				}
				else
				{
					RateDetailView.Hidden = false;
					ConversationView.Hidden = false;
					NewRateView.Hidden = false;
					SupportingView.Hidden = false;
					ShipmentsIconTextChange(UIColor.Red, UIColor.Black, UIColor.Black,
					UIColor.Black, "RateEntryHover", "Supporting",
					"NewRate", "Conversation");

				}
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Taps the gesture recognizer.
		/// </summary>
		void TapGestureRecognizer()
		{
			try
			{
				tapGestureInvoice = new UITapGestureRecognizer(GoToInvoice);
				imgInvoice.AddGestureRecognizer(tapGestureInvoice);
				tapGestureTrackingInfo = new UITapGestureRecognizer(GoToTrackingInfo);
				imgTrackingInfo.AddGestureRecognizer(tapGestureTrackingInfo);
				//Navigation
				tapGesture = new UITapGestureRecognizer(ManageNavigation);
				imgBack.AddGestureRecognizer(tapGesture);
				tapGesture = new UITapGestureRecognizer(ManageNavigation);
				imgRefresh.AddGestureRecognizer(tapGesture);

				//Slider Functionality
				//Rate Detail
				tapGestureRateDetail = new UITapGestureRecognizer(ShipmentDetailTapChange);
				imgRateDetail.AddGestureRecognizer(tapGestureRateDetail);
				//Supproting
				tapGestureSupporting = new UITapGestureRecognizer(ShipmentDetailTapChange);
				imgSupporting.AddGestureRecognizer(tapGestureSupporting);
				//Place New RAte
				tapGestureNewRate = new UITapGestureRecognizer(ShipmentDetailTapChange);
				imgPlaceRate.AddGestureRecognizer(tapGestureNewRate);
				//Converstions
				tapGestureConversations = new UITapGestureRecognizer(ShipmentDetailTapChange);
				imgConversation.AddGestureRecognizer(tapGestureConversations);
				//Changing Text Color and image Click on tabs
				managingTab();
				//ShipmentsIconTextChange(UIColor.Red, UIColor.Black, UIColor.Black,
				//	UIColor.Black, "RateEntryHover", "Supporting",
				//	"NewRate", "Conversation");


				var gesture = new UITapGestureRecognizer(() =>
				{
					if (viewPicker != null)
					{
						viewPicker.Hidden = true;
						pickerView.Hidden = true;
						doneButton.Hidden = true;
					}
					if (modalPicker != null)
					{
						DismissViewController(true, null);
					}
					View.EndEditing(true);
				});
				gesture.CancelsTouchesInView = false;
				View.AddGestureRecognizer(gesture);
				NewRateView.AddGestureRecognizer(gesture);

			}
			catch (Exception ex)
			{
				Console.Write(ex.Message);
			}
		}

		/// <summary>
		/// Swipes the gesture recognizer.
		/// </summary>
		void SwipeGestureRecognizer()
		{
			try
			{
				swipeRateDetail = new UISwipeGestureRecognizer(SlideRateDetailToSupporting);
				swipeRateDetail.Direction = UISwipeGestureRecognizerDirection.Left;
				RateDetailView.AddGestureRecognizer(swipeRateDetail);

				swipeSupportingToRateDetail = new UISwipeGestureRecognizer(SlideSupportingToRateDetail);
				swipeSupportingToRateDetail.Direction = UISwipeGestureRecognizerDirection.Right;
				SupportingView.AddGestureRecognizer(swipeSupportingToRateDetail);

				swipeSupportingToNewRate = new UISwipeGestureRecognizer(SlideSupportingToNewRate);
				swipeSupportingToNewRate.Direction = UISwipeGestureRecognizerDirection.Left;
				SupportingView.AddGestureRecognizer(swipeSupportingToNewRate);

				swipeNewRateToSupporting = new UISwipeGestureRecognizer(SlideNewRateToSupporting);
				swipeNewRateToSupporting.Direction = UISwipeGestureRecognizerDirection.Right;
				NewRateView.AddGestureRecognizer(swipeNewRateToSupporting);

				swipeNewRateToConversation = new UISwipeGestureRecognizer(SlideNewRateToConversation);
				swipeNewRateToConversation.Direction = UISwipeGestureRecognizerDirection.Left;
				NewRateView.AddGestureRecognizer(swipeNewRateToConversation);

				swipConversations = new UISwipeGestureRecognizer(SlideConversationsToNewRate);
				swipConversations.Direction = UISwipeGestureRecognizerDirection.Right;
				ConversationView.AddGestureRecognizer(swipConversations);
			}
			catch (Exception ex)
			{
				Console.Write(ex.Message);
			}
		}
		/// <summary>
		/// Gos to tracking info.
		/// </summary>
		void GoToTrackingInfo()
		{
			try
			{
                if (CommanUtil.IsTimeOut())
                {
                    Util.ActiveConversationHeader = -1;
                    if (imgTrackingInfo != null && imgTrackingInfo.Tag == 1)
                    {
                        TrackingInfoController trackingInfoController =
                            this.Storyboard.InstantiateViewController
                            ("TrackingInfoController") as TrackingInfoController;
                        this.NavigationController.PushViewController(trackingInfoController, true);
                    }
                    else
                    {
                        PrintBol();
                    }
                }
                else
                {
                    return;
                }
			}
			catch
			{
				throw;
			}
		}
		/// <summary>
		/// Gos to invoice.
		/// </summary>
		void GoToInvoice()
		{
			try
			{
				Util.ActiveConversationHeader = -1;
				InvoiceController invoiceController =
					this.Storyboard.InstantiateViewController
					("InvoiceController") as InvoiceController;
				
				this.NavigationController.PushViewController(invoiceController, true);

				//UIView.BeginAnimations(null);
				//UIView.SetAnimationDuration(1);
				//UIView.SetAnimationTransition(UIViewAnimationTransition.CurlUp, NavigationController.View,true);
				//UIView.CommitAnimations();

			}
			catch
			{
				throw;
			}
		}


		/// <summary>
		/// Shipmentses the icon text change.
		/// </summary>
		/// <param name="rateDetailColor">Rate detail color.</param>
		/// <param name="supportingColor">Supporting color.</param>
		/// <param name="newRateColor">New rate color.</param>
		/// <param name="conversationColor">Conversation color.</param>
		/// <param name="pathRateDetail">Path rate detail.</param>
		/// <param name="pathSupporting">Path supporting.</param>
		/// <param name="pathNewRate">Path new rate.</param>
		/// <param name="pathConversation">Path conversation.</param>
		public void ShipmentsIconTextChange(UIColor rateDetailColor, UIColor supportingColor, UIColor newRateColor,
											 UIColor conversationColor, string pathRateDetail, string pathSupporting,
											 string pathNewRate, string pathConversation)
		{
			try
			{
				lblRateDetail.TextColor = rateDetailColor;
				lblSupporting.TextColor = supportingColor;
				lblNewRate.TextColor = newRateColor;
				lblConversation.TextColor = conversationColor;

				imgRateDetail.Image = UIImage.FromBundle(pathRateDetail);
				imgSupporting.Image = UIImage.FromBundle(pathSupporting);
				imgPlaceRate.Image = UIImage.FromBundle(pathNewRate);
				imgConversation.Image = UIImage.FromBundle(pathConversation);
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Shipments the icon tap change.
		/// </summary>
		/// <param name="tapGesture">Tap gesture.</param>
		public void ShipmentDetailTapChange(UITapGestureRecognizer tapGesture)
		{
			try
			{
				ResetReplyForConversation();
				RateDetailView.Hidden = false;
				ConversationView.Hidden = false;
				NewRateView.Hidden = false;
				SupportingView.Hidden = false;
				if (tapGesture.View.Equals(imgRateDetail))
				{
					RateDetailSlide();
				}
				else if (tapGesture.View.Equals(imgSupporting))
				{
					SupportingSlide();
				}
				else if (tapGesture.View.Equals(imgPlaceRate))
				{
					NewRateSlide();
				}
				else if (tapGesture.View.Equals(imgConversation))
				{
					ConversationsSlide();
				}
			}
			catch
			{
				throw;
			}

		}

		public void ResetReplyForConversation()
		{
			if (viewReply != null)
			{
				ResignFirstResponder();
				viewReply.Hidden = true;
				CommanUtil.isChatFooterHide = true;
				txtReply.Text = "";
				tblConversation.ReloadData();
				tblConversation.BeginUpdates();
				tblConversation.EndUpdates();

			}
		}

		/// <summary>
		/// Rates the detail slide.
		/// </summary>
		public void RateDetailSlide()
		{

			try
			{
				
				tabNumber = 1;
				RateDetailView.Hidden = false;
				SupportingView.Hidden = true;
				NewRateView.Hidden = true;
				ConversationView.Hidden = true;
				ResetReplyForConversation();
				ShipmentsIconTextChange(UIColor.Red, UIColor.Black, UIColor.Black,
					UIColor.Black, "RateEntryHover", "Supporting",
					"NewRate", "Conversation");
				SupportingView.Frame = new CGRect(SupportingView.Frame.Width, SupportingView.Frame.Top, SupportingView.Frame.Width, SupportingView.Frame.Height);
				NewRateView.Frame = new CGRect(NewRateView.Frame.Width, NewRateView.Frame.Top, NewRateView.Frame.Width, NewRateView.Frame.Height);
				ConversationView.Frame = new CGRect(ConversationView.Frame.Width, ConversationView.Frame.Top, ConversationView.Frame.Width, ConversationView.Frame.Height);
				UIView.Animate(ConstantsClass.animationDuration,
					() =>
					{
						RateDetailView.Frame = new CGRect(0, RateDetailView.Frame.Top, RateDetailView.Frame.Width, RateDetailView.Frame.Height);

					});
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Supportings the slide.
		/// </summary>
		public void SupportingSlide()
		{
			try
			{
				tabNumber = 2;
				RateDetailView.Hidden = true;
				SupportingView.Hidden = false;
				NewRateView.Hidden = true;
				ConversationView.Hidden = true;
				ResetReplyForConversation();
				ShipmentsIconTextChange(UIColor.Black, UIColor.Red, UIColor.Black,
					UIColor.Black, "RateEntry", "SupportingHover",
					"NewRate", "Conversation");

				NewRateView.Frame = new CGRect(NewRateView.Frame.Width, NewRateView.Frame.Top, NewRateView.Frame.Width, NewRateView.Frame.Height);
				ConversationView.Frame = new CGRect(ConversationView.Frame.Width, ConversationView.Frame.Top, ConversationView.Frame.Width, ConversationView.Frame.Height);
				RateDetailView.Frame = new CGRect(-RateDetailView.Frame.Width, RateDetailView.Frame.Top, RateDetailView.Frame.Width, RateDetailView.Frame.Height);

				UIView.Animate(ConstantsClass.animationDuration,
					() =>
					{
						SupportingView.Frame = new CGRect(0, SupportingView.Frame.Top, SupportingView.Frame.Width, SupportingView.Frame.Height);

					});
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// News the rate slide.
		/// </summary>
		public void NewRateSlide()
		{
			try
			{
				tabNumber = 3;
				RateDetailView.Hidden = true;
				SupportingView.Hidden = true;
				NewRateView.Hidden = false;
				ConversationView.Hidden = true;
				ShipmentsIconTextChange(UIColor.Black, UIColor.Black, UIColor.Red,
					UIColor.Black, "RateEntry", "Supporting",
					"NewRateHover", "Conversation");
				SupportingView.Frame = new CGRect(-SupportingView.Frame.Width, SupportingView.Frame.Top, SupportingView.Frame.Width, SupportingView.Frame.Height);
				ConversationView.Frame = new CGRect(ConversationView.Frame.Width, ConversationView.Frame.Top, ConversationView.Frame.Width, ConversationView.Frame.Height);
				RateDetailView.Frame = new CGRect(-RateDetailView.Frame.Width, RateDetailView.Frame.Top, RateDetailView.Frame.Width, RateDetailView.Frame.Height);

				UIView.Animate(ConstantsClass.animationDuration,
					() =>
					{
						NewRateView.Frame = new CGRect(0, NewRateView.Frame.Top, NewRateView.Frame.Width, NewRateView.Frame.Height);

					});
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Supportings the slide.
		/// </summary>
		public void ConversationsSlide()
		{
			try
			{
				tabNumber = 4;
				RateDetailView.Hidden = true;
				SupportingView.Hidden = true;
				NewRateView.Hidden = true;
				ConversationView.Hidden = false;
				ShipmentsIconTextChange(UIColor.Black, UIColor.Black, UIColor.Black,
					UIColor.Red, "RateEntry", "Supporting",
					"NewRate", "ConversationHover");

				SupportingView.Frame = new CGRect(-SupportingView.Frame.Width, SupportingView.Frame.Top, SupportingView.Frame.Width, SupportingView.Frame.Height);
				NewRateView.Frame = new CGRect(-NewRateView.Frame.Width, NewRateView.Frame.Top, NewRateView.Frame.Width, NewRateView.Frame.Height);
				RateDetailView.Frame = new CGRect(-RateDetailView.Frame.Width, RateDetailView.Frame.Top, RateDetailView.Frame.Width, RateDetailView.Frame.Height);
				UIView.Animate(ConstantsClass.animationDuration,
					() =>
					{
						ConversationView.Frame = new CGRect(0, ConversationView.Frame.Top, ConversationView.Frame.Width, ConversationView.Frame.Height);

					});
			}
			catch
			{
				throw;
			}
		}
		/// <summary>
		/// Buttons the compose message touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnComposeMessage_TouchUpInside(UIButton sender)
		{
			try
			{
				ComposeMessageController composeMessageController =
									this.Storyboard.InstantiateViewController
										("ComposeMessageController") as ComposeMessageController;
				this.NavigationController.PushViewController(composeMessageController, true);

			}
			catch (Exception ex)
			{
				Console.Write(ex.Message);
			}
		}

		/// <summary>
		/// Rates the detail to supporting.
		/// </summary>
		public void SlideRateDetailToSupporting()
		{
			try
			{
				SupportingSlide();
			}
			catch
			{
				throw;
			}

		}

		/// <summary>
		/// Slides the supporting to rate detail.
		/// </summary>
		public void SlideSupportingToRateDetail()
		{
			try
			{
				RateDetailSlide();
			}
			catch
			{
				throw;
			}

		}

		/// <summary>
		/// Slides the supporting to new rate.
		/// </summary>
		public void SlideSupportingToNewRate()
		{
			try
			{
				NewRateSlide();
			}
			catch
			{
				throw;
			}

		}

		/// <summary>
		/// Slides the new rate to supporting.
		/// </summary>
		public void SlideNewRateToSupporting()
		{
			try
			{
				ResetReplyForConversation();

				tabNumber = 2;
				RateDetailView.Hidden = true;
				SupportingView.Hidden = false;
				NewRateView.Hidden = true;
				ConversationView.Hidden = true;

				ShipmentsIconTextChange(UIColor.Black, UIColor.Red, UIColor.Black,
					UIColor.Black, "RateEntry", "SupportingHover",
					"NewRate", "Conversation");

				NewRateView.Frame = new CGRect(NewRateView.Frame.Width, NewRateView.Frame.Top, NewRateView.Frame.Width, NewRateView.Frame.Height);
				ConversationView.Frame = new CGRect(ConversationView.Frame.Width, ConversationView.Frame.Top, ConversationView.Frame.Width, ConversationView.Frame.Height);
				RateDetailView.Frame = new CGRect(-RateDetailView.Frame.Width, RateDetailView.Frame.Top, RateDetailView.Frame.Width, RateDetailView.Frame.Height);

				UIView.Animate(ConstantsClass.animationDuration,
					() =>
					{
						SupportingView.Frame = new CGRect(0, SupportingView.Frame.Top, SupportingView.Frame.Width, SupportingView.Frame.Height);
					});
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Slides the new rate to conversation.
		/// </summary>
		public void SlideNewRateToConversation()
		{
			try
			{
				ResetReplyForConversation();
				ConversationsSlide();
			}
			catch
			{
				throw;
			}

		}

		/// <summary>
		/// Slides the conversations to new rate.
		/// </summary>
		public void SlideConversationsToNewRate()
		{
			try
			{

				ResetReplyForConversation();

				tabNumber = 3;
				RateDetailView.Hidden = true;
				SupportingView.Hidden = true;
				NewRateView.Hidden = false;
				ConversationView.Hidden = true;

				ShipmentsIconTextChange(UIColor.Black, UIColor.Black, UIColor.Red,
					UIColor.Black, "RateEntry", "Supporting",
					"NewRateHover", "Conversation");
				SupportingView.Frame = new CGRect(-SupportingView.Frame.Width, SupportingView.Frame.Top, SupportingView.Frame.Width, SupportingView.Frame.Height);
				ConversationView.Frame = new CGRect(ConversationView.Frame.Width, ConversationView.Frame.Top, ConversationView.Frame.Width, ConversationView.Frame.Height);
				RateDetailView.Frame = new CGRect(-RateDetailView.Frame.Width, RateDetailView.Frame.Top, RateDetailView.Frame.Width, RateDetailView.Frame.Height);

				UIView.Animate(ConstantsClass.animationDuration,
					() =>
					{
						NewRateView.Frame = new CGRect(0, NewRateView.Frame.Top, NewRateView.Frame.Width, NewRateView.Frame.Height);

					});
			}
			catch
			{
				throw;
			}
		}


		/// <summary>
		/// Binds the shipment details.
		/// </summary>
		/// <returns>The shipment details.</returns>
		public async Task<string> BindShipmentDetails()
		{
			try
			{
				if (!string.IsNullOrEmpty(strToken))
				{
					CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
					if (loadPop == null)
					{
						loadPop = new LoadingOverlay(bounds);
					}
					objServicehelper = new ServiceHelper();
					//Method Name
					methodName = APIMethods.shipmentDetails + "/" + compositeKey;
					View.Add(loadPop);
					strResponse = await objServicehelper.GetRequest(strToken, methodName, true);
					if (!string.IsNullOrEmpty(strResponse))
 					{
						loadPop.Hide();
						jobject = JObject.Parse(strResponse);
						if (string.IsNullOrEmpty(Convert.ToString(jobject["Message"])))
						{
							lstShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(strResponse);
							shipmentResult = string.Empty;
							//Removing Local storage
							NSUserDefaults.StandardUserDefaults.RemoveObject("shipmentDetails");
							NSUserDefaults.StandardUserDefaults.SetString(strResponse, "shipmentDetails");
							BindSupportingFile(lstShipmentDetail.SupportFiles);
						}
						else
						{
							strResponse = string.Empty;
							shipmentResult = jobject["Message"].ToString();
							//Post Error Logger Request 
							await Util.ErrorLog("API-ShipmentDetail", Convert.ToString(jobject["Message"]), strToken);
							loadPop.Hide();
							this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
							this.View.Add(this.customAlert);

						}
					}
					else
					{
						loadPop.Hide();
						this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strNetwork, true, this, "", 1);
						this.View.Add(this.customAlert);
					}
				}
				return strResponse;
			}
			catch (Exception ex)
			{
				//string message = ex.Message;
                return ex.Message;
			}
		}


		/// <summary>
		/// Manages the navigation.
		/// </summary>
		/// <param name="tapGesture">Tap gesture.</param>
		public void ManageNavigation(UITapGestureRecognizer tapGesture)
		{
			try
			{
				Util.ActiveConversationHeader = -1;
				if (tapGesture.View.Equals(imgBack))
				{
					if (compositeKey.Split('|')[2].Equals(ConstantsClass.strHistory))
					{
                        this.NavigationController.PopViewController(true);
					}
					else
					{
						if (Reachability.InternetConnectionStatus())
						{
							DashboardController dashboardController =
							this.Storyboard.InstantiateViewController
							("DashboardController") as DashboardController;
							this.NavigationController.PushViewController(dashboardController, true);

						}
						else
						{
							this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.isOnline, true, this, "", 1);
							this.View.Add(this.customAlert);
						}

					}

				}
				else
				{
					loadPop = null;
					//Refresh Shipment Detail
					this.NavigationController.DismissViewController(true, null);
					ShipmentDetailController objShipmentDetailController =
					this.Storyboard.InstantiateViewController
					("ShipmentDetailController") as ShipmentDetailController;
					objShipmentDetailController.compositeKey = compositeKey;

					this.NavigationController.PushViewController(objShipmentDetailController, false);
					//await BindShipmentDetails();

				}
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Redirects to map.
		/// </summary>
		/// <param name="addressKey">Address key.</param>
		public void RedirectToMap(string addressKey)
		{
			try
			{
				if (Reachability.InternetConnectionStatus())
				{
					MapController objMapController =
										this.Storyboard.InstantiateViewController
										("MapController") as MapController;
					objMapController.addressKey = addressKey;

					this.NavigationController.PushViewController(objMapController, true);
				}
				else
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
					this.View.Add(this.customAlert);
				}
			}
			catch
			{
				throw;
			}
		}

        /// <summary>
        /// Open Selected file or Image.
        /// </summary>
        /// <param name="fileIndex">File index.</param>
        public void RedirectToWebView(int fileIndex)
        {
            try
            {
                fileUrl = lstFiles[fileIndex];                 CommanUtil.fileURL = fileUrl;
                WebViewController objWebViewController =
                      this.Storyboard.InstantiateViewController
                     ("WebViewController") as WebViewController;                 objWebViewController.strHeading = Constants.strSupporting + Constants.strFile;
                this.NavigationController.PushViewController(objWebViewController, true);

            }
            catch
            {
                throw;
            }
        }

		/// <summary>
		/// Handles the should start load.
		/// </summary>
		/// <returns><c>true</c>, if should start load was handled, <c>false</c> otherwise.</returns>
		/// <param name="webView">Web view.</param>
		/// <param name="request">Request.</param>
		/// <param name="navigationType">Navigation type.</param>
		bool HandleShouldStartLoad(UIWebView webView, NSUrlRequest request, UIWebViewNavigationType navigationType)
		{
			UIApplication.SharedApplication.OpenUrl(request.Url);
			return true;
		}

		/// <summary>
		/// Open Selected file or Image.
		/// </summary>
        /// <param name="fileUrl">File index.</param>
		public void OpenConversationFile(string fileUrl)
		{
			try
			{
                CommanUtil.fileURL = fileUrl;
                WebViewController objWebViewController =
                    this.Storyboard.InstantiateViewController
                    ("WebViewController") as WebViewController;                 objWebViewController.strHeading = Constants.strConversation + Constants.strFile;
                this.NavigationController.PushViewController(objWebViewController, true);

			}
			catch
			{
				throw;
			}
		}


		/// <summary>
		/// Redirects to confirmation.
		/// </summary>
		/// <param name="confirmationType">Confirmation type.</param>
		public void RedirectToConfirmation(string confirmationType, string proNumber)
		{
			try
			{
                if (CommanUtil.IsTimeOut())
                {
                    string confiramtionKey = confirmationType + "#" + lstShipmentDetail.ClientID + "|" + lstShipmentDetail.LocID + "|" + lstShipmentDetail.BolNum;
                    PickupAndDeliveryController objPickupAndDeliveryController =
                                        this.Storyboard.InstantiateViewController
                                                                            ("PickupAndDeliveryController") as PickupAndDeliveryController;
                    objPickupAndDeliveryController.compositeKey = confiramtionKey;
                    objPickupAndDeliveryController.proNumber = proNumber;
                    this.NavigationController.PushViewController(objPickupAndDeliveryController, true);
                }
                else
                {
                    return;
                }
			}
			catch (Exception ex)
			{
				string message = ex.Message;
				throw;
			}
		}


		/// <summary>
        /// Redirects to equipment scanning.
        /// </summary>
		public void RedirectToEquipmentScanning()
		{
			try
			{
                if (CommanUtil.IsTimeOut())
                {
                    //string confiramtionKey = confirmationType + "#" + lstShipmentDetail.ClientID + "|" + lstShipmentDetail.LocID + "|" + lstShipmentDetail.BolNum;
                    EquipmentScanController equipmentScanController =
                                        this.Storyboard.InstantiateViewController
                                                                            ("EquipmentScanController") as EquipmentScanController;
                    //objPickupAndDeliveryController.compositeKey = confiramtionKey;
                    this.NavigationController.PushViewController(equipmentScanController, true);
                }
                else
                {
                    return;
                }
			}
			catch (Exception ex)
			{
				string message = ex.Message;
				throw;
			}
		}

		/// <summary>
		/// Redirects to shipment tracking.
		/// </summary>
		public void RedirectToShipmentTracking(string trackingKey)
		{
			try
			{
				ShipmentTrackingController objShipmentTrackingController =
					this.Storyboard.InstantiateViewController
					("ShipmentTrackingController") as ShipmentTrackingController;
				objShipmentTrackingController.compositeKey = trackingKey;
				this.NavigationController.PushViewController(objShipmentTrackingController, true);
			}
			catch
			{
				throw;
			}
		}
	

		/// <summary>
		/// Redirects to map.
		/// </summary>
		/// <param name="addressKey">Address key.</param>
		public void RedirectToDashBoard()
		{
			try
			{
				ResetRateEntries();
			}
			catch
			{
				throw;
			}
		}


		#region Save Driver 
		/// <summary>
		/// Saves the driver.
		/// </summary>
		/// <returns>The driver.</returns>
		/// <param name="objCarrierShipmentDetails">Object carrier shipment details.</param>
		/// <param name="selectedDriver">Selected driver.</param>
		public async Task SaveDriver(CarrierShipmentDetails objCarrierShipmentDetails, string selectedDriver)
		{
			try
			{
                if (!CommanUtil.IsTimeOut())
                {
                    return;
                }
				if (!string.IsNullOrEmpty(selectedDriver))
				{
					JObject jsonResponse = null;
					string name = selectedDriver;//SelectedItem.ToString();
					if (name.Trim() == Constants.strDriver.Trim())
					{
						this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strSelectDriver, true, this, "", 1);
						View.Add(this.customAlert);
					}
					else
					{
						CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
						loadPop = null;
						if (loadPop == null)
						{
							loadPop = new LoadingOverlay(bounds);
						}
						View.Add(loadPop);
						string method = APIMethods.Shipment + "/" + objCarrierShipmentDetails.ClientID + "|" + objCarrierShipmentDetails.LocID + "|" + objCarrierShipmentDetails.BolNum + "/" + APIMethods.driverid;
						string data = "DriverID=" + name;
						ServiceHelper objServiceHelper = new ServiceHelper();
						var response = await objServiceHelper.PostRequest(data, method, CommanUtil.tokenNo, true);
						if (response != null)
						{
							if (response.Replace("\"", " ").Trim().ToUpper() == Constants.strSuccess.ToUpper())
							{
								loadPop.Hide();
								new UIAlertView("", NSBundle.MainBundle.GetLocalizedString("driverAssigned", null), null, Constants.btnTextOk, null).Show();
							}
							else
							{
								//Post Error Logger Request 
								jsonResponse = JObject.Parse(response);
								await Util.ErrorLog(Constants.invoiceUploads, Convert.ToString(jsonResponse[Constants.strErrorMessage]), CommanUtil.tokenNo);
								this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Convert.ToString(jsonResponse[Constants.strErrorMessage]), true, this, "", 1);
								View.Add(this.customAlert);
								loadPop.Hide();
							}
							response = null;
						}
					}
				}
				else
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strSelectDriver, true, this, "", 1);
					View.Add(this.customAlert);
				}
			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				View.Add(this.customAlert);
				loadPop.Hide();
			}
		}

		#endregion

		#region Void And Block

		/// <summary>
		/// Block Shipment on Click of Block Button under truck load section
		/// </summary>
		/// <returns>The shipment.</returns>
		/// <param name="reason">Reason.</param>
		public async Task BlockShipment(string reason)
		{
			try
			{

				JObject jsonResponse = null;
                if (!CommanUtil.IsTimeOut())
                {
                    return;
                }
				if (!string.IsNullOrEmpty(reason))
				{
					CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
					if (loadPop != null)
					{
						loadPop = null;
						loadPop = new LoadingOverlay(bounds);
					}
					View.Add(loadPop);
					string method = APIMethods.shipmentDetails + "/" + lstShipmentDetail.ClientID + "|" + lstShipmentDetail.LocID + "|" + lstShipmentDetail.BolNum + "/" + APIMethods.Block;
					string data = "Reason=" + reason;
					ServiceHelper objServiceHelper = new ServiceHelper();
					var response = await objServiceHelper.PostRequest(data, method, strToken, true);
					if (!string.IsNullOrEmpty(response))
					{
						if (response.Replace("\"", " ").Trim().ToUpper() == Constants.strBlockMsg.ToUpper())
						{
							method = lstShipmentDetail.ClientID + "|" + lstShipmentDetail.BolNum;
							await Util.BindShipmentDetails(method);//Bind shipment
							loadPop.Hide();
						}
						else
						{
							jsonResponse = JObject.Parse(response);
							await Util.ErrorLog(ConstantsClass.strVoid, Convert.ToString(jsonResponse[Constants.strErrorMessage]), CommanUtil.tokenNo);
							this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Convert.ToString(jsonResponse[Constants.strErrorMessage]), true, this, "", 1);
							this.View.Add(this.customAlert);
							loadPop.Hide();
						}
						response = null;
					}
				}
			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
				loadPop.Hide();
			}
		}

		/// <summary>
		/// Void Shipment under the truckload section
		/// </summary>
		public async Task VoidShipment()
		{
			try
			{
				//Loader
				CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
                if (!CommanUtil.IsTimeOut())
                {
                    return;
                }
				if (loadPop != null)
				{
					loadPop = null;
					loadPop = new LoadingOverlay(bounds);
				}
				View.Add(loadPop);
				JObject jsonResponse = null;
				ServiceHelper objServiceHelper = new ServiceHelper();
				string method = APIMethods.shipmentDetails + "/" + lstShipmentDetail.ClientID + "|" + lstShipmentDetail.LocID + "|" + lstShipmentDetail.BolNum + "/" + APIMethods.Void;
				string reqData = string.Empty;
				var response = await objServiceHelper.PostRequest(reqData, method, strToken, true);
				if (response != null)
				{
					if (response.Replace("\"", " ").Trim().ToUpper() == Constants.strVoidMsg.ToUpper())
					{
						loadPop.Hide();
						DashboardController dashboardController =
						this.Storyboard.InstantiateViewController
						("DashboardController") as DashboardController;
						this.NavigationController.PushViewController(dashboardController, true);
					}
					else
					{
						jsonResponse = JObject.Parse(response);
						await Util.ErrorLog(ConstantsClass.strVoid, Convert.ToString(jsonResponse[Constants.strErrorMessage]), CommanUtil.tokenNo);
						this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Convert.ToString(jsonResponse[Constants.strErrorMessage]), true, this, "", 1);
						this.View.Add(this.customAlert);
						loadPop.Hide();
					}
					response = null;
				}
			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
				loadPop.Hide();
			}
		}

		#endregion

		#region Supporting View Implementation

		/// <summary>
		/// Supportings the controller.
		/// </summary>
		void SupportingController()
		{
			try
			{
				btnChooseFile.Layer.BorderWidth = 1;
				btnChooseFile.Layer.CornerRadius = 6;
				btnUpload.Font = UIFont.FromName(Constants.strFontName, 12.0f);
				btnChooseFile.Layer.BorderColor = UIColor.Black.CGColor;

				btnUpload.Font = UIFont.FromName(Constants.strFontName, 12.0f);
				btnUpload.Layer.CornerRadius = 8;

			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Binds the supporting file Details.
		/// </summary>
		public void BindSupportingFile(List<string> objFiles)
		{
			try
			{
				if (objFiles != null)
				{
					tblFileDetails.Hidden = false;
					tblFileDetails.Bounces = false;
					lstFiles = new List<string>();
					lstFiles = objFiles;
					objSupportingFileAdapter = new SupportingFileAdapter(this, objFiles);
					tblFileDetails.Source = objSupportingFileAdapter;
					tblFileDetails.TableFooterView = new UIView(CGRect.Empty);

					tblFileDetails.ReloadData();
				}
				else
				{
					tblFileDetails.Hidden = true;
				}
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Buttons the choose file touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnChooseFile_TouchUpInside(UIButton sender)
		{
			
			try
			{
				ConstantsClass.currentTab = 2;
				BrowserFile();
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Browsers the file.
		/// </summary>
		public void BrowserFile()
		{
			try
			{
				imagePicker = new UIImagePickerController();
				imagePicker.SourceType = UIImagePickerControllerSourceType.PhotoLibrary;
				imagePicker.MediaTypes = UIImagePickerController.AvailableMediaTypes(UIImagePickerControllerSourceType.PhotoLibrary);
				imagePicker.FinishedPickingMedia += Handle_FinishedPickingMedia;
				imagePicker.Canceled += Handle_Canceled;
				NavigationController.PresentModalViewController(imagePicker, true);
				isBrowsingFile = true;

			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Handles the finished picking media.
		/// </summary>
		/// <param name="sender">Sender.</param>
		/// <param name="e">E.</param>
		public void Handle_FinishedPickingMedia(object sender, UIImagePickerMediaPickedEventArgs e)
		{
			try
			{
				// determine what was selected, video or image
				bool isImage = false;
				switch (e.Info[UIImagePickerController.MediaType].ToString())
				{
					case "public.image":
						isImage = true;
						break;
					case "public.video":
						isImage = false;
						break;
				}
				// get common info (shared between images and video)
				NSUrl referenceURL = e.Info[new NSString("UIImagePickerControllerReferenceURL")] as NSUrl;
				if (referenceURL != null)
				{
					string fileNm = FileUploadHelper.GetFileName(referenceURL.LastPathComponent.ToString());
					lblFileName.Text = fileNm;
					fileName = fileNm;
					// if it was an image, get the other image info
					if (isImage)
					{
						// get the original image
						UIImage originalImage = e.Info[UIImagePickerController.OriginalImage] as UIImage;
						//MediaFile dsds;
						using (var imageData = originalImage.AsJPEG(0.6f))
						{
							bytes = new byte[imageData.Length];
							Marshal.Copy(imageData.Bytes, bytes, 0, Convert.ToInt32(imageData.Length));
						}
					}
					else
					{
						// get video url
						NSUrl mediaURL = e.Info[UIImagePickerController.MediaURL] as NSUrl;
						if (mediaURL != null)
						{

						}
					}
					//FileData filedata = await CrossFilePicker.Current.PickFile();
					// dismiss the picker
					//imagePicker.DismissModalViewControllerAnimated(true);
					imagePicker.DismissModalViewController(true);
				}
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Handles the canceled.
		/// </summary>
		/// <param name="sender">Sender.</param>
		/// <param name="e">E.</param>
		void Handle_Canceled(object sender, EventArgs e)
		{
			imagePicker.DismissModalViewController(true);
		}

		/// <summary>
		/// Buttons the upload touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnUpload_TouchUpInside(UIButton sender)
		{
			try
			{
                if (!CommanUtil.IsTimeOut())
                {
                    return;
                }
				if (Reachability.InternetConnectionStatus())
				{
					if (!string.IsNullOrEmpty(fileName))
					{
						UploadFiles();
					}
					else
					{
						this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strChooseFile, true, this, "", 1);
						this.View.Add(this.customAlert);
					}
				}
				else
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
					this.View.Add(this.customAlert);
				}

			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Uploads the files.
		/// </summary>
		public async void UploadFiles()
		{
			try
			{
				if (bytes != null && !string.IsNullOrEmpty(fileName))
				{
					//Loader
					CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
					if (loadPop != null)
					{
						loadPop = null;
						loadPop = new LoadingOverlay(bounds);
					}
					View.Add(loadPop);
					string jsonRequest = string.Empty;
					string uploadResult = await UploadBitmapAsync(bytes);
					if (uploadResult != null)
					{
						jobject = JObject.Parse(uploadResult);
						if (string.IsNullOrEmpty(Convert.ToString(jobject["Message"])))
						{
							//File Response will post in another API
							jsonRequest = FileUploadHelper.UploadsJsonRequest(uploadResult);
							methodName = APIMethods.shipmentDetails + "/" + lstShipmentDetail.ClientID + "|" + lstShipmentDetail.LocID + "|" + lstShipmentDetail.BolNum + "/supportfile";
							//Requesting To Other API
							jsonRequest = "{\"Files\":[" + jsonRequest + "]}";
							string fileResult = await objServicehelper.PostRequestJson(jsonRequest, methodName, strToken, true);
							if (fileResult != null)
							{
								lstFiles = JsonConvert.DeserializeObject<List<string>>(fileResult);
								BindSupportingFile(lstFiles); //Re-binding List of files
								lblFileName.Text = "";
								bytes = null;
								loadPop.Hide();
								ConstantsClass.currentTab = 2;
							}
							else
							{
								loadPop.Hide();
								this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strNoFile, true, this, "", 1);
								this.View.Add(this.customAlert);
							}
						}
						else
						{
							loadPop.Hide();
							//await Utility.ErrorLog("Supporting", Convert.ToString(jobject["Message"]), CommanUtil.tokenNo, context);
							this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Convert.ToString(jobject["Message"]), true, this, "", 1);
							this.View.Add(this.customAlert);
						}
					}
					else
					{
						loadPop.Hide();
						this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strNoFile, true, this, "", 1);
						this.View.Add(this.customAlert);
					}

				}
				else
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strChooseFile, true, this, "", 1);
					this.View.Add(this.customAlert);
				}
			}
			catch
			{
				loadPop.Hide();
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strChooseFile, true, this, "", 1);
				this.View.Add(this.customAlert);
			}
		}

		/// <summary>
		/// File upload
		/// </summary>
		/// <param name="bytes">File will be in bytes</param>
		/// <returns></returns>
		public async Task<string> UploadBitmapAsync(byte[] bytes)
		{
			try
			{
				objFileUploadHelper = new FileUploadHelper();
				methodName = APIMethods.supportfile;
				var response = await objFileUploadHelper.PostFiles(bytes, fileName, methodName, strToken, true);
				return response;
			}
			catch
			{
				throw;
			}
		}

		#endregion

		#region Place New Rate Implementation

		/// <summary>
		/// News the rate section.
		/// </summary>
		public void NewRateSection()
		{
			foreach (UIView view in NewRateView)
			{
				view.RemoveFromSuperview();
			}
			string fuelCharge = "0.00";
			string accessoriesCharge = "0.00";
			string baseCharge = "0.00";
			try
			{
				List<UIView> lstViews = new List<UIView>();
				nfloat xCordinate = 0;
				UIView viewAcknowledge, viewDeliveryDate, viewFuelCharge1, viewFuelCharge2, viewCondition = null;
				id = CommanUtil.CompositeKey(lstShipmentDetail.ClientID, lstShipmentDetail.LocID, lstShipmentDetail.BolNum);
				//Need To Change Not Equal Condition
				if (lstShipmentDetail.CanBid)
				{
					if (lstShipmentDetail.AcceptedSSes != null)
					{
						viewAcknowledge = new UIView(new CGRect(0, xCordinate, NewRateView.Frame.Width, 60));
						xCordinate += viewAcknowledge.Frame.Height;
						UIButton btnCheck = new UIButton(new CGRect(5, 10, 20, 20));
						btnCheck.BackgroundColor = UIColor.White;
						btnCheck.Layer.CornerRadius = 2;
						btnCheck.Layer.BorderWidth = 2;
						UISwitch objSwitch = new UISwitch();
						objSwitch.Frame = ConstantsClass.switchFrame;
						objSwitch.Frame = ConstantsClass.switchFrame;
						objSwitch.Draw(ConstantsClass.switchFrame);
						btnCheck.TouchUpInside += delegate
						{
							AcknowledgeRequired(btnCheck);
						};
						UILabel lblAcknowledge = new UILabel(new CGRect(30, 0, NewRateView.Frame.Width - 35, viewAcknowledge.Frame.Height));
						lblAcknowledge.Font = UIFont.FromName(Constants.strFontName, 11f);
						lblAcknowledge.Text = NSBundle.MainBundle.GetLocalizedString("IhaveReview", null);
						lblAcknowledge.Lines = 0;

						//lblAcknowledge.SizeToFit();
						lblAcknowledge.LineBreakMode = UILineBreakMode.WordWrap;
						viewAcknowledge.AddSubviews(objSwitch, lblAcknowledge);
						lstViews.Add(viewAcknowledge);
					}
					//Need To Change Not Equal Condition
					if (lstShipmentDetail.BidWithDelDate)
					{
						viewDeliveryDate = new UIView(new CGRect(0, xCordinate, NewRateView.Frame.Width, 115));

						xCordinate += viewDeliveryDate.Frame.Height;

						UILabel lblDeliveryDate = new UILabel(new CGRect(10, 10, NewRateView.Frame.Width / 2 - 10, 20));
						lblDeliveryDate.Font = UIFont.FromName(Constants.strFontName, 12f);
						lblDeliveryDate.Text = NSBundle.MainBundle.GetLocalizedString("deliveryDate", null);

						txtDeliveryDate = new UITextView(new CGRect(NewRateView.Frame.Width / 2 + 15, 10, NewRateView.Frame.Width / 2 - 30, 25));
						txtDeliveryDate.Layer.CornerRadius = 5;
						txtDeliveryDate.Layer.BorderWidth = 0.5f;

						var deliveryDateTap = new UITapGestureRecognizer(DeliveryDatePicker);
						txtDeliveryDate.AddGestureRecognizer(deliveryDateTap);

						txtDelTime1 = new UITextView(new CGRect(NewRateView.Frame.Width / 2 + 15, 45, NewRateView.Frame.Width / 2 - 30, 25));
						txtDelTime1.Layer.CornerRadius = 5;
						txtDelTime1.Layer.BorderWidth = 0.5f;

						var deliveryTime1Tap = new UITapGestureRecognizer(DeliveryTimePicker);
						txtDelTime1.AddGestureRecognizer(deliveryTime1Tap);

						txtDelTime2 = new UITextView(new CGRect(NewRateView.Frame.Width / 2 + 15, 80, NewRateView.Frame.Width / 2 - 30, 25));
						txtDelTime2.Layer.CornerRadius = 5;
						txtDelTime2.Layer.BorderWidth = 0.5f;
						//txtDelTime2.TopAnchor
						var deliveryTime2Tap = new UITapGestureRecognizer(DeliveryTimePicker);
						txtDelTime2.AddGestureRecognizer(deliveryTime2Tap);

						viewDeliveryDate.AddSubviews(lblDeliveryDate, txtDeliveryDate, txtDelTime1, txtDelTime2);
						lstViews.Add(viewDeliveryDate);
					}

					UIView viewBaseChage = new UIView(new CGRect(0, xCordinate, NewRateView.Frame.Width, 50));

					xCordinate += viewBaseChage.Frame.Height;

					UILabel lblBaseCharge = new UILabel(new CGRect(10, 10, NewRateView.Frame.Width / 2 - 10, 20));
					lblBaseCharge.Font = UIFont.FromName(Constants.strFontName, 12f);
					lblBaseCharge.Text = NSBundle.MainBundle.GetLocalizedString("baseCharge", null);

					UILabel lblDollorSign = new UILabel(new CGRect(NewRateView.Frame.Width / 2, 15, 15, 15));
					lblDollorSign.Font = UIFont.FromName(Constants.strFontName, 12f);
					lblDollorSign.Text = "$";

                    txtBaseCharge = new UITextField(new CGRect(lblDollorSign.Frame.X + 16, 10, NewRateView.Frame.Width / 2 - 30, 30));
					txtBaseCharge.Layer.CornerRadius = 5;
					txtBaseCharge.Layer.BorderWidth = 0.5f;
                    txtBaseCharge.Placeholder = NSBundle.MainBundle.GetLocalizedString("baseCharge", null);
					txtBaseCharge.KeyboardType = UIKeyboardType.NumberPad;


                    txtBaseCharge.ShouldChangeCharacters = (UITextField textField, NSRange range, string replacementString) =>
                    {
                        var length = textField.Text.Length - range.Length + replacementString.Length;
                        return length <= 6;
                    };

                    txtBaseCharge.TouchUpInside += delegate
                    {
                        if (txtFuelCharge != null)
                        {
                            fuelCharge = txtFuelCharge.Text;
                        }
                        if (txtAccessCharge != null)
                        {
                            accessoriesCharge = txtAccessCharge.Text;
                        }
                        CalTotalCharge(txtBaseCharge.Text, accessoriesCharge, fuelCharge);
                    };
					//txtBaseCharge.Layer.BorderColor = new CoreGraphics.CGColor(204,204,204);
					viewBaseChage.AddSubviews(lblBaseCharge, lblDollorSign, txtBaseCharge);
					lstViews.Add(viewBaseChage);
					//Need To Change Not Equal Condition
					if (lstShipmentDetail.UsesBTFuel == false && lstShipmentDetail.HideFuel == false)
					{
						viewFuelCharge1 = new UIView(new CGRect(0, xCordinate, NewRateView.Frame.Width, 50));

						xCordinate += viewFuelCharge1.Frame.Height;

						UILabel lblFuelCharge1 = new UILabel(new CGRect(10, 10, NewRateView.Frame.Width / 2 - 10, 20));
						lblFuelCharge1.Font = UIFont.FromName(Constants.strFontName, 12f);
						lblFuelCharge1.Text = NSBundle.MainBundle.GetLocalizedString("fuelCharge", null);

						UILabel lblDollorSign2 = new UILabel(new CGRect(NewRateView.Frame.Width / 2, 15, 15, 15));
						lblDollorSign2.Font = UIFont.FromName(Constants.strFontName, 12f);
						lblDollorSign2.Text = "$";

                        txtFuelCharge = new UITextField(new CGRect(lblDollorSign2.Frame.X + 16, 10, NewRateView.Frame.Width / 2 - 30, 30));
						txtFuelCharge.Layer.CornerRadius = 5;
						txtFuelCharge.Layer.BorderWidth = 0.5f;
                        txtFuelCharge.Placeholder = NSBundle.MainBundle.GetLocalizedString("fuelCharge", null);
						txtFuelCharge.KeyboardType = UIKeyboardType.NumberPad;

                        txtFuelCharge.ShouldChangeCharacters = (UITextField textField, NSRange range, string replacementString) =>
                        {
                            var length = textField.Text.Length - range.Length + replacementString.Length;
                            return length <= 6;
                        };
                        txtFuelCharge.TouchDragInside += delegate
                        {
                            if (txtBaseCharge != null)
                            {
                                baseCharge = txtBaseCharge.Text;
                            }
                            if (txtAccessCharge != null)
                            {
                                accessoriesCharge = txtAccessCharge.Text;
                            }
                            CalTotalCharge(baseCharge, accessoriesCharge, txtFuelCharge.Text);

                        };
						//txtFuelCharge.Changed += delegate
						//{
							
						//};
						viewFuelCharge1.AddSubviews(lblFuelCharge1, lblDollorSign2, txtFuelCharge);
						lstViews.Add(viewFuelCharge1);
					}
					//Need To Change Not Equal Condition
					if (lstShipmentDetail.UsesBTFuel == true && lstShipmentDetail.HideFuel == false)
					{
						viewFuelCharge2 = new UIView(new CGRect(0, xCordinate, NewRateView.Frame.Width, 50));

						xCordinate += viewFuelCharge2.Frame.Height;

						UILabel lblFuelCharge2Label = new UILabel(new CGRect(10, 10, NewRateView.Frame.Width / 2 - 10, 20));
						lblFuelCharge2Label.Font = UIFont.FromName(Constants.strFontName, 12f);
						lblFuelCharge2Label.Text = NSBundle.MainBundle.GetLocalizedString("fuelCharge", null);

						UILabel lblFuelCharge2 = new UILabel(new CGRect(NewRateView.Frame.Width / 2, 0, NewRateView.Frame.Width / 2 - 10, 50));
						lblFuelCharge2.Font = UIFont.FromName(Constants.strFontName, 11f);
						lblFuelCharge2.Lines = 0;
						lblFuelCharge2.LineBreakMode = UILineBreakMode.WordWrap;
						lblFuelCharge2.Text = NSBundle.MainBundle.GetLocalizedString("fuelSurcharge", null);


						viewFuelCharge2.AddSubviews(lblFuelCharge2Label, lblFuelCharge2);
						lstViews.Add(viewFuelCharge2);

					}
					UIView viewAccesseriesCharge = new UIView(new CGRect(0, xCordinate, NewRateView.Frame.Width, 50));

					xCordinate += viewAccesseriesCharge.Frame.Height;

					UILabel lblAccessoriesCharge = new UILabel(new CGRect(10, 10, NewRateView.Frame.Width / 2 - 10, 20));
					lblAccessoriesCharge.Font = UIFont.FromName(Constants.strFontName, 12f);
					lblAccessoriesCharge.Text = NSBundle.MainBundle.GetLocalizedString("accessorialcharge", null);

					UILabel lblDollorSign3 = new UILabel(new CGRect(NewRateView.Frame.Width / 2, 15, 15, 15));
					lblDollorSign3.Font = UIFont.FromName(Constants.strFontName, 12f);
					lblDollorSign3.Text = "$";

                    txtAccessCharge = new UITextField(new CGRect(lblDollorSign3.Frame.X + 15, 10, NewRateView.Frame.Width / 2 - 30, 30));
					txtAccessCharge.Layer.CornerRadius = 5;
					txtAccessCharge.Layer.BorderWidth = 0.5f;
                    txtAccessCharge.Placeholder = NSBundle.MainBundle.GetLocalizedString("accessorialcharge", null);
					txtAccessCharge.KeyboardType = UIKeyboardType.NumberPad;
                    txtAccessCharge.ShouldChangeCharacters = (UITextField textField, NSRange range, string replacementString) =>
                    {
                        var length = textField.Text.Length - range.Length + replacementString.Length;
                        return length <= 6;
                    };
                    txtAccessCharge.TouchUpInside += delegate
                    {
                        if (txtBaseCharge != null)
                        {
                            baseCharge = txtBaseCharge.Text;
                        }
                        if (txtFuelCharge != null)
                        {
                            fuelCharge = txtFuelCharge.Text;
                        }
                        CalTotalCharge(baseCharge, txtAccessCharge.Text, fuelCharge);
                    };
                    //txtAccessCharge.Changed += delegate
					//{
						
					//};
					viewAccesseriesCharge.AddSubviews(lblAccessoriesCharge, lblDollorSign3, txtAccessCharge);
					lstViews.Add(viewAccesseriesCharge);

					UIView viewTotalCharge = new UIView(new CGRect(0, xCordinate, NewRateView.Frame.Width, 50));
					viewTotalCharge.BackgroundColor = Constants.tableRowOddColor;
					xCordinate += viewTotalCharge.Frame.Height;

					UILabel lblTotalCharge = new UILabel(new CGRect(10, 10, NewRateView.Frame.Width / 2 - 10, 20));
					lblTotalCharge.Font = UIFont.FromName(Constants.strFontName, 12f);
					lblTotalCharge.Text = NSBundle.MainBundle.GetLocalizedString("totalCharge", null);

					UILabel lblDollorSign4 = new UILabel(new CGRect(NewRateView.Frame.Width / 2, 15, 15, 15));
					lblDollorSign4.Font = UIFont.FromName(Constants.strFontName, 12f);
					lblDollorSign4.Text = "$";

					lblSumCharge = new UILabel(new CGRect(lblDollorSign4.Frame.X + 15, 15, NewRateView.Frame.Width / 2 - 10, 15));
					lblSumCharge.Font = UIFont.FromName(Constants.strFontName, 11f);
					lblSumCharge.Text = "0.00";

					viewTotalCharge.AddSubviews(lblTotalCharge, lblDollorSign4, lblSumCharge);
					lstViews.Add(viewTotalCharge);

					if (lstShipmentDetail.CanBidAlterTerms)
					{
						viewCondition = new UIView(new CGRect(0, xCordinate, NewRateView.Frame.Width, 50));
						xCordinate += viewCondition.Frame.Height;
						UIButton btnCheckRate = new UIButton(new CGRect(5, 10, 25, 25));
						btnCheckRate.BackgroundColor = UIColor.White;
						btnCheckRate.Layer.CornerRadius = 2;
						btnCheckRate.Layer.BorderWidth = 2;

						btnCheckRate.TouchUpInside += delegate
						{
							RateCheckTerm(btnCheckRate);
						};
						UILabel lblCondition = new UILabel(new CGRect(40, 15, NewRateView.Frame.Width - 30, 25));
						lblCondition.Font = UIFont.FromName(Constants.strFontName, 11f);
						lblCondition.Text = NSBundle.MainBundle.GetLocalizedString("newRateAlter", null);
						lblCondition.Lines = 0;
						lblCondition.SizeToFit();
						lblCondition.LineBreakMode = UILineBreakMode.WordWrap;
						viewCondition.AddSubviews(btnCheckRate, lblCondition);
						lstViews.Add(viewCondition);
					}

					UIView viewComments = new UIView(new CGRect(0, xCordinate, NewRateView.Frame.Width, 50));
					viewComments.BackgroundColor = Constants.tableRowOddColor;
					xCordinate += viewComments.Frame.Height;


					UILabel lblComment = new UILabel(new CGRect(10, 10, NewRateView.Frame.Width / 2 - 10, 20));
					lblComment.Font = UIFont.FromName(Constants.strFontName, 12f);
					lblComment.Text = NSBundle.MainBundle.GetLocalizedString("comments", null);

                    txtComments = new UITextField(new CGRect(NewRateView.Frame.Width / 2 + 15, 10, NewRateView.Frame.Width / 2 - 30, 30));
					txtComments.Layer.CornerRadius = 5;
					txtComments.Layer.BorderWidth = 0.5f;

					viewComments.AddSubviews(lblComment, txtComments);
					lstViews.Add(viewComments);

					UIView viewSubmitRate = new UIView(new CGRect(0, xCordinate, NewRateView.Frame.Width, 50));
					xCordinate += viewSubmitRate.Frame.Height;

					btnSubmitRate = new UIButton(new CGRect(NewRateView.Frame.Width - 150, 10, 130, 20));
					btnSubmitRate.Layer.CornerRadius = 5;
					btnSubmitRate.BackgroundColor = Constants.separatorClr;
					btnSubmitRate.Font = UIFont.FromName(Constants.strFontName, 13f);
					btnSubmitRate.SetTitle(NSBundle.MainBundle.GetLocalizedString("submitRate", null), UIControlState.Normal);
					viewSubmitRate.AddSubview(btnSubmitRate);
					lstViews.Add(viewSubmitRate);

					toolbar = new UIToolbar(new CoreGraphics.CGRect(new nfloat(0.0f), new nfloat(0.0f), this.View.Frame.Size.Width, new nfloat(44.0f)));
				    toolbar.TintColor = UIColor.White;
				    toolbar.BarStyle = UIBarStyle.Black;
				    toolbar.Translucent = true;
					toolbar.Items = new UIBarButtonItem[]{
			 			 new UIBarButtonItem(UIBarButtonSystemItem.Done, delegate {
							if(txtBaseCharge.IsFirstResponder)
							{
								txtBaseCharge.ResignFirstResponder();
							}
							else if(txtAccessCharge.IsFirstResponder)
							{
								txtAccessCharge.ResignFirstResponder();
							}
							else
							{
								txtComments.ResignFirstResponder();	
							}
						})
					};
					txtBaseCharge.KeyboardAppearance = UIKeyboardAppearance.Default;
					txtBaseCharge.InputAccessoryView = toolbar;
					txtAccessCharge.KeyboardAppearance = UIKeyboardAppearance.Default;
					txtAccessCharge.InputAccessoryView = toolbar;
					txtComments.KeyboardAppearance = UIKeyboardAppearance.Default;
					txtComments.InputAccessoryView = toolbar;
					btnSubmitRate.TouchUpInside += async delegate
					{
                        if (!CommanUtil.IsTimeOut())
                        {
                            return;
                        }
						if (Reachability.InternetConnectionStatus())
						{
							if (txtBaseCharge != null)
							{
								baseCharge = txtBaseCharge.Text;
							}
							if (txtAccessCharge != null)
							{
								accessoriesCharge = txtAccessCharge.Text;
							}
							if (txtFuelCharge != null)
							{
								fuelCharge = txtFuelCharge.Text;
							}
							CalTotalCharge(baseCharge, accessoriesCharge, fuelCharge);
							await SubmitNewRate();
						}
						else
						{
							this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
							this.View.Add(this.customAlert);
						}
					};
				}
				foreach (Entry objEntry in lstShipmentDetail.Entries)
				{
					if (!string.IsNullOrEmpty(objEntry.Comments))
					{
						Constants.isComments = true;
						break;
					}
				}

				UIView viewRateEntries = new UIView();
				viewRateEntries.Frame = new CGRect(0, xCordinate, NewRateView.Frame.Width, 25);
				xCordinate += viewRateEntries.Frame.Height;

				lstViews.Add(viewRateEntries);

				for (int i = 0; i < lstViews.Count; i++)
				{
					if (i % 2 == 0)
					{
						lstViews[i].BackgroundColor = Constants.tableRowOddColor;

					}
					else
					{
						lstViews[i].BackgroundColor = Constants.tableRowEvenColor;
					}
				}

				#region Rate Entries Section

				Constants.isRateEntry = false;

				UIView viewRateEntriesHead = new UIView(new CGRect(1, 0, 300, 25));
				viewRateEntriesHead.BackgroundColor = Constants.conversationHeadClr;

				UILabel lblRateEntryHead = new UILabel();

				lblRateEntryHead.BackgroundColor = Constants.conversationHeadClr;
				lblRateEntryHead.Font = UIFont.FromName(Constants.strFontName, 15f);
				lblRateEntryHead.Text = NSBundle.MainBundle.GetLocalizedString("rateEntriesHeader", null);
				lblRateEntryHead.TextColor = UIColor.White;


				UIView viewRateEntriesTableHead = new UIView(new CGRect(1, 0, viewRateEntries.Frame.Width, 25));

				nfloat xCordinateRateEntry = 0;
				//variable to check if search view image is is shown or not
				//UIView imgSearchView = new UIView(new CGRect(xCordinateRateEntry, 0, 35, 25));
				//imgSearchView.BackgroundColor = Constants.fileHeadBGC;
				//xCordinateRateEntry += imgSearchView.Frame.Width + 1;

				//UIImageView imgSearch = new UIImageView(new CGRect(7, 2, 20, 20));
				//imgSearch.Image = UIImage.FromBundle("Images/search.png");
				//imgSearch.BackgroundColor = Constants.fileHeadBGC;

				//imgSearchView.AddSubview(imgSearch);

				UILabel lblAction1 = new UILabel(new CGRect(xCordinateRateEntry, 0, 100, 25));
				lblAction1.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblAction1.Text = NSBundle.MainBundle.GetLocalizedString("action", null);
				lblAction1.TextAlignment = UITextAlignment.Center;
				lblAction1.TextColor = UIColor.White;
				lblAction1.BackgroundColor = Constants.fileHeadBGC;
				xCordinateRateEntry += lblAction1.Frame.Width + 1;


				UILabel lblAction2 = new UILabel(new CGRect(xCordinateRateEntry, 0, 100, 25));
				lblAction2.Font = UIFont.FromName(Constants.strFontName, 12f);
                lblAction2.Text = NSBundle.MainBundle.GetLocalizedString("comments", null);
				lblAction2.TextAlignment = UITextAlignment.Center;
				lblAction2.TextColor = UIColor.White;
				lblAction2.BackgroundColor = Constants.fileHeadBGC;
				xCordinateRateEntry += lblAction2.Frame.Width + 1;

				UILabel lblCarrier = new UILabel(new CGRect(xCordinateRateEntry, 0, 100, 25));
				lblCarrier.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblCarrier.Text = NSBundle.MainBundle.GetLocalizedString("carrier", null);
				lblCarrier.TextAlignment = UITextAlignment.Center;
				lblCarrier.TextColor = UIColor.White;
				lblCarrier.BackgroundColor = Constants.fileHeadBGC;
				xCordinateRateEntry += lblCarrier.Frame.Width + 1;

				UILabel lblCarrierName = new UILabel(new CGRect(xCordinateRateEntry, 0, 100, 25));
				lblCarrierName.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblCarrierName.Text = NSBundle.MainBundle.GetLocalizedString("carrierName", null);
				lblCarrierName.TextAlignment = UITextAlignment.Center;
				lblCarrierName.TextColor = UIColor.White;
				lblCarrierName.BackgroundColor = Constants.fileHeadBGC;
				xCordinateRateEntry += lblCarrierName.Frame.Width + 1;

				UILabel lblShipmentCost = new UILabel(new CGRect(xCordinateRateEntry, 0, 100, 25));
				lblShipmentCost.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblShipmentCost.Text = NSBundle.MainBundle.GetLocalizedString("shipmentCost", null);
				lblShipmentCost.TextAlignment = UITextAlignment.Center;
				lblShipmentCost.TextColor = UIColor.White;
				lblShipmentCost.BackgroundColor = Constants.fileHeadBGC;
				xCordinateRateEntry += lblShipmentCost.Frame.Width + 1;

				UILabel lblTermsAlt = new UILabel(new CGRect(xCordinateRateEntry, 0, 100, 25));
				lblTermsAlt.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblTermsAlt.Text = NSBundle.MainBundle.GetLocalizedString("termsAltered", null);
				lblTermsAlt.TextAlignment = UITextAlignment.Center;
				lblTermsAlt.TextColor = UIColor.White;
				lblTermsAlt.BackgroundColor = Constants.fileHeadBGC;
				xCordinateRateEntry += lblTermsAlt.Frame.Width + 1;

				UILabel lblStatus = new UILabel(new CGRect(xCordinateRateEntry, 0, 100, 25));
				lblStatus.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblStatus.Text = NSBundle.MainBundle.GetLocalizedString("status", null);
				lblStatus.TextAlignment = UITextAlignment.Center;
				lblStatus.TextColor = UIColor.White;
				lblStatus.BackgroundColor = Constants.fileHeadBGC;
				xCordinateRateEntry += lblStatus.Frame.Width + 1;

				UILabel lblAuthedBy = new UILabel(new CGRect(xCordinateRateEntry, 0, 100, 25));
				lblAuthedBy.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblAuthedBy.Text = NSBundle.MainBundle.GetLocalizedString("authedBy", null);
				lblAuthedBy.TextAlignment = UITextAlignment.Center;
				lblAuthedBy.TextColor = UIColor.White;
				lblAuthedBy.BackgroundColor = Constants.fileHeadBGC;
				xCordinateRateEntry += lblAuthedBy.Frame.Width + 1;

				UILabel lblDeliveryDate1 = new UILabel(new CGRect(xCordinateRateEntry, 0, 0, 0));

				foreach (Entry objEntry in lstShipmentDetail.Entries)
				{
					if (!string.IsNullOrEmpty(objEntry.DeliverOnStr))
					{
						lblDeliveryDate1 = new UILabel(new CGRect(xCordinateRateEntry, 0, 100, 25));
						lblDeliveryDate1.Font = UIFont.FromName(Constants.strFontName, 12f);
						lblDeliveryDate1.Text = NSBundle.MainBundle.GetLocalizedString("deliveryDate", null);
						lblDeliveryDate1.TextAlignment = UITextAlignment.Center;
						lblDeliveryDate1.TextColor = UIColor.White;
						lblDeliveryDate1.BackgroundColor = Constants.fileHeadBGC;
						xCordinateRateEntry += lblDeliveryDate1.Frame.Width + 1;

						Constants.isDeliveryDate = true;
						break;
					}
				}

				UILabel lblDateEntered = new UILabel(new CGRect(xCordinateRateEntry, 0, 200, 25));
				lblDateEntered.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblDateEntered.Text = NSBundle.MainBundle.GetLocalizedString("dateEntered", null);
				lblDateEntered.TextAlignment = UITextAlignment.Center;
				lblDateEntered.TextColor = UIColor.White;
				lblDateEntered.BackgroundColor = Constants.fileHeadBGC;
				xCordinateRateEntry += lblDateEntered.Frame.Width + 1;

				UILabel lblAwarded = new UILabel(new CGRect(xCordinateRateEntry, 0, 100, 25));
				lblAwarded.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblAwarded.Text = NSBundle.MainBundle.GetLocalizedString("awarded", null);
				lblAwarded.TextAlignment = UITextAlignment.Center;
				lblAwarded.TextColor = UIColor.White;
				lblAwarded.BackgroundColor = Constants.fileHeadBGC;
				xCordinateRateEntry += lblAwarded.Frame.Width + 1;

				UILabel lblReason = new UILabel(new CGRect(xCordinateRateEntry, 0, 100, 25));
				lblReason.Font = UIFont.FromName(Constants.strFontName, 12f);
				lblReason.Text = NSBundle.MainBundle.GetLocalizedString("reason", null);
				lblReason.TextAlignment = UITextAlignment.Center;
				lblReason.TextColor = UIColor.White;
				lblReason.BackgroundColor = Constants.fileHeadBGC;
				xCordinateRateEntry += lblReason.Frame.Width + 1;

				viewRateEntriesHead.AddSubview(lblRateEntryHead);
				viewRateEntriesTableHead.Frame = new CGRect(1, 0, xCordinateRateEntry, 25);
				viewRateEntriesTableHead.AddSubviews( lblAction1, lblAction2, lblCarrier, lblCarrierName, lblShipmentCost, lblTermsAlt, lblStatus,
					lblAuthedBy, lblDeliveryDate1, lblDateEntered, lblAwarded, lblReason);


				lblRateEntryHead.Frame = new CGRect(0, 0, xCordinateRateEntry, 25);
				UIScrollView scrollView2 = new UIScrollView
				{
					Frame = new CGRect(0, xCordinate, NewRateView.Frame.Width, (lstShipmentDetail.Entries.Count * 35 + 30)),
					ContentSize = new CGSize(xCordinateRateEntry + 2, (lstShipmentDetail.Entries.Count * 35 + 30)),
					BackgroundColor = UIColor.White,
					AutoresizingMask = UIViewAutoresizing.FlexibleWidth,
					Bounces = false,
					DirectionalLockEnabled = true
				};
				//viewRateEntries.AddSubviews
				viewRateEntries.AddSubviews(viewRateEntriesHead);
				tblRateEntries = new UITableView(new CGRect(1, 25, xCordinateRateEntry, (lstShipmentDetail.Entries.Count * 35 + 5)));
				tblRateEntries.Source = new RateEntriesAdapter(lstShipmentDetail.Entries, View, lstShipmentDetail, this);
				tblRateEntries.ReloadData();
				tblRateEntries.AllowsSelection = false;
				tblRateEntries.Bounces = false;
				tblRateEntries.RowHeight = 35;
				UIView viewForCustomer = new UIView();
				UIScrollView scrollView = new UIScrollView();
				//tblRateEntries.Source = new RateEntryAdapter(lstShipmentDetail.Entries, View, xCordinate);
				xCordinate += tblRateEntries.Frame.Height;
				scrollView2.AddSubviews(viewRateEntriesTableHead, tblRateEntries);
				#endregion
				viewForCustomer = new UIView(new CGRect(0, scrollView2.Frame.Y + scrollView2.Frame.Height, NewRateView.Frame.Width, 50));
				xCordinate += viewForCustomer.Frame.Height;
				if (lstShipmentDetail.ViewAs.ToUpper() == Constants.strCustomer.ToUpper())
				{
					UIButton btnCanSubmit = new UIButton(new CGRect(NewRateView.Frame.Width - 110, 10, 100, 20));
					btnCanSubmit.Layer.CornerRadius = 5;
					btnCanSubmit.BackgroundColor = Constants.separatorClr;
					btnCanSubmit.Font = UIFont.FromName(Constants.strFontName, 12f);
					if (lstShipmentDetail.CanResubmit)
					{
						btnCanSubmit.SetTitle(NSBundle.MainBundle.GetLocalizedString("ReSubmit", null), UIControlState.Normal);
					}
					else if (lstShipmentDetail.CanUnAward)
					{
						btnCanSubmit.SetTitle(NSBundle.MainBundle.GetLocalizedString("UnAward", null), UIControlState.Normal);
					}
					else
					{
						btnCanSubmit.SetTitle(string.Empty, UIControlState.Normal);
						btnCanSubmit.Hidden = true;
					}
					btnCanSubmit.TouchUpInside += delegate
					{
						
						if (btnCanSubmit.TitleLabel.Text.ToUpper() == NSBundle.MainBundle.GetLocalizedString("ReSubmit", null))
						{
							ResubmitConfirmation(View, null);
						}
						else
						{
							UnawardConfirmation(View, null);
						}
					};

					UIButton btnRateHistory = new UIButton(new CGRect(NewRateView.Frame.Width - 220, 10, 100, 20));
					btnRateHistory.Layer.CornerRadius = 5;
					btnRateHistory.BackgroundColor = Constants.separatorClr;
					btnRateHistory.Font = UIFont.FromName(Constants.strFontName, 12f);
					//btnRateHistory.SetTitle("UN-Award", UIControlState.Normal);
					btnRateHistory.SetTitle(NSBundle.MainBundle.GetLocalizedString("RateHistory", null), UIControlState.Normal);
					btnRateHistory.TouchUpInside += delegate
					{
						BidRateHistory(View);
					};

					viewForCustomer.AddSubviews(btnCanSubmit, btnRateHistory);
				}
				scrollView = new UIScrollView
				{
					Frame = new CGRect(1, 1, NewRateView.Frame.Width, NewRateView.Frame.Height),
					ContentSize = new CGSize(NewRateView.Frame.Width, viewForCustomer.Frame.Y + viewForCustomer.Frame.Height),
					AutoresizingMask = UIViewAutoresizing.FlexibleHeight,
					Bounces = false
				};

				foreach (UIView view in lstViews)
				{
					scrollView.AddSubview(view);
				}

				scrollView.AddSubview(scrollView2);

				scrollView.AddSubview(viewForCustomer);

				NewRateView.AddSubview(scrollView);

				tapRateEntryImg = new UITapGestureRecognizer();
				tapRateEntryImg.AddTarget(new Action(delegate
				{
					ShowRateEntries();
				}));
				//imgSearchView.AddGestureRecognizer(tapRateEntryImg);

			}
			catch
			{
				throw;
			}

		}


		/// <summary>
		/// Opens the calender.
		/// </summary>
		/// <param name="type">Type.</param>
		public void DeliveryDatePicker()
		{
			try
			{

				modalPicker = new ModalPickerViewController(ModalPickerType.Date, "", this)
				{
					HeaderBackgroundColor = Constants.btnColorRed,
					HeaderTextColor = UIColor.White,
					TransitioningDelegate = new ModalPickerTransitionDelegate(),
					ModalPresentationStyle = UIModalPresentationStyle.Custom
				};

				modalPicker.DatePicker.Mode = UIDatePickerMode.Date;
				modalPicker.OnModalPickerDismissed += (s, ea) =>
				{
					var dateFormatter = new NSDateFormatter()
					{
						DateFormat = ConstantsClass.dateFormatMMddyy
					};
					txtDeliveryDate.Text = dateFormatter.ToString(modalPicker.DatePicker.Date);
				};
				this.PresentViewController(modalPicker, true, null);
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Opens the calender.
		/// </summary>
		/// <param name="type">Type.</param>
		public void DeliveryTimePicker(UITapGestureRecognizer tapGesture)
		{
			try
			{

				modalPicker = new ModalPickerViewController(ModalPickerType.Date, "", this)
				{
					HeaderBackgroundColor = Constants.btnColorRed,
					HeaderTextColor = UIColor.White,
					TransitioningDelegate = new ModalPickerTransitionDelegate(),
					ModalPresentationStyle = UIModalPresentationStyle.Custom
				};

				modalPicker.DatePicker.Mode = UIDatePickerMode.Time;
				modalPicker.OnModalPickerDismissed += (s, ea) =>
				{
					var TimeFormatter = new NSDateFormatter()
					{
						TimeStyle = NSDateFormatterStyle.Short
					};
					if (tapGesture.View.Equals(txtDelTime1))
					{
						txtDelTime1.Text = " " + TimeFormatter.ToString(modalPicker.DatePicker.Date);
					}
					else
					{
						txtDelTime2.Text = " " + TimeFormatter.ToString(modalPicker.DatePicker.Date);
					}
				};

				this.PresentViewController(modalPicker, true, null);
			}
			catch
			{
				throw;
			}
		}


		/// <summary>
		/// Function to submit new rate bid for the shipment
		/// </summary>
		/// <returns></returns>
		private async Task<bool> SubmitNewRate()
		{
			try
			{
				//Loader
				string accessorialCharge = "0.00";
				string fuelCharge = "0.00";
				string baseCharge = "0.00";
				string comment = string.Empty;
				if (txtDeliveryDate != null && !string.IsNullOrEmpty(txtDeliveryDate.Text))
				{
					ActivityDate = Convert.ToDateTime(txtDeliveryDate.Text).ToString(ConstantsClass.dateFormatMMddyy);
					activityDate = CommanUtil.FormatDate(ActivityDate);
					delDate = activityDate[2] + "-" + activityDate[0] + "-" + activityDate[1];
				}
				if (txtDelTime1 != null && !string.IsNullOrEmpty(txtDelTime1.Text))
				{
					if ((txtDelTime1.Text.Contains("AM")))
					{
						delTime1 = txtDelTime1.Text.Replace("AM", "").Trim();
					}
					else
					{
						delTime1 = txtDelTime1.Text.Replace("PM", "").Trim();
					}
				}
				if (txtDelTime2 != null && !string.IsNullOrEmpty(txtDelTime2.Text))
				{
					if ((txtDelTime2.Text.Contains("AM")))
					{
						delTime2 = txtDelTime2.Text.Replace("AM", "").Trim();
					}
					else
					{
						delTime2 = txtDelTime2.Text.Replace("PM", "").Trim();
					}
				}
				if (isRateCheck)
				{
                    if (string.IsNullOrEmpty(txtComments.Text.Trim()))
					{
						this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strComments, true, this, "", 1);
						this.View.Add(this.customAlert);
						return false;
					}
				}
				if (lstShipmentDetail.AcceptedSSes != null)
				{
					if (isReviewedNdAck != true)
					{
						this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strAcknowledge, true, this, "", 1);
						this.View.Add(this.customAlert);
						return false;
					}
				}
				if (txtBaseCharge == null || string.IsNullOrEmpty(txtBaseCharge.Text) || txtBaseCharge.Text == ".")
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strBaseCharge, true, this, "", 1);
					this.View.Add(this.customAlert);
					return false;
				}
				else
				{
					baseCharge = txtBaseCharge.Text;
				}
				if (txtAccessCharge != null || !string.IsNullOrEmpty(txtAccessCharge.Text))
				{
					accessorialCharge = txtAccessCharge.Text;
				}
				if (lstShipmentDetail.UsesBTFuel == true || lstShipmentDetail.HideFuel == true)
				{
					fuelCharge = "0.00";
				}
				else
				{
					if (txtFuelCharge == null || string.IsNullOrEmpty(txtFuelCharge.Text) || txtFuelCharge.Text == ".")
					{
						this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strFuelCharge, true, this, "", 1);
						this.View.Add(this.customAlert);
						return false;
					}
					else
					{
						fuelCharge = txtFuelCharge.Text;
					}
				}
				if (lstShipmentDetail.CanBidAlterTerms && isAlteredTerms)
				{
					if (txtComments == null || string.IsNullOrEmpty(txtComments.Text))
					{
						this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strComments, true, this, "", 1);
						this.View.Add(this.customAlert);
						return false;
					}
					else
					{
						comment = txtComments.Text;
					}
				}
				else
				{
					comment = txtComments.Text;
				}
				CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
				if (loadPop != null)
				{
					loadPop = null;
					loadPop = new LoadingOverlay(bounds);
				}
				View.Add(loadPop);
				CalTotalCharge(baseCharge, accessorialCharge, fuelCharge);
				methodName = APIMethods.shipmentDetails + "/" + id + "/" + APIMethods.bid;
				ratePayload = GetRatePayload(baseCharge, accessorialCharge, fuelCharge, comment);

				ServiceHelper objServiceHelper = new ServiceHelper();
				string Result = await objServiceHelper.PostRequestJson(ratePayload, methodName, strToken, true);
				if (Result != null)
				{
					var Jobject = JsonConvert.DeserializeObject(Result);
					if (Jobject.ToString().ToUpper() == Constants.strSuccess.ToUpper())
					{
						string result = await BindShipmentDetails();
						if (!string.IsNullOrEmpty(result))
						{
							//Refresh Rate List Table
							NewRateSection();

							loadPop.Hide();
							ResetRateEntries();
						}
					}
					else
					{
						JObject response = JObject.Parse(Result);
						string Message = Convert.ToString(response[Constants.strErrorMessage]);
						jobject = JObject.Parse(Result);
						ResetRateEntries();
						loadPop.Hide();
						ErrorPopup objErrorPopup = new ErrorPopup(View, Message, this);
						UIView viewErrorpop = objErrorPopup.GetErrorPopup();
						View.Add(viewErrorpop);
					}
				}
			}
			catch
			{
				loadPop.Hide();
				ResetRateEntries();
			}
			return true;
		}

		/// <summary>
		/// Calculate Total Charge
		/// </summary>
		/// <param name="baseCharge"></param>
		/// <param name="accessoCharge"></param>
		/// <param name="fuelCharge"></param>
		/// <returns></returns>
		private double CalTotalCharge(string baseCharge, string accessoCharge, string fuelCharge)
		{
			double TotalCharge = 0.0;
			try
			{
				//bool isvalidated = IsValidated(lstShipmentDetail);
				double BaseCharge = 0.00;
				double AccessoCharge = 0.00;
				double FuelCharge = 0.00;
				if (!string.IsNullOrEmpty(baseCharge) && baseCharge != ".")
				{
					BaseCharge = Convert.ToDouble(baseCharge);
				}
				if (!string.IsNullOrEmpty(accessoCharge) && accessoCharge != ".")
				{
					AccessoCharge = Convert.ToDouble(accessoCharge);
				}
				if (!string.IsNullOrEmpty(fuelCharge) && fuelCharge != ".")
				{
					FuelCharge = Convert.ToDouble(fuelCharge);
				}
				TotalCharge = BaseCharge + AccessoCharge + FuelCharge;
				lblSumCharge.Text = " " + Convert.ToString(TotalCharge);
				return TotalCharge;
			}
			catch
			{
				return TotalCharge;
				//throw;
			}
		}

		/// <summary>
		/// IsValidated
		/// </summary>
		/// <param name="lstShipmentDetail"></param>
		/// <returns></returns>
		private bool IsValidated(CarrierShipmentDetails lstShipmentDetail)
		{
			return true;
		}

		/// <summary>
		/// Function to reset all the fields for Rate Entry
		/// </summary>
		public void ResetRateEntries()
		{
			try
			{
				isReviewedNdAck = lstShipmentDetail.AcceptedSSes == null ? false : Convert.ToBoolean(lstShipmentDetail.AcceptedSSes);
				pickupDtTm_str = lstShipmentDetail.PickupStr;
				string[] pickupDate_str = (pickupDtTm_str.Split(' ')[0]).Split('/');
				pickupDate_dt = new DateTime(Convert.ToInt32(pickupDate_str[2]), Convert.ToInt32(pickupDate_str[0]), Convert.ToInt32(pickupDate_str[1]));
				//pickupDate_dt = DateTime.Now;
				pickupDate_dt = pickupDate_dt.AddDays(1);

				string pickUpMonth = (pickupDate_dt.Month) < 10 ? "0" + (pickupDate_dt.Month) : Convert.ToString(pickupDate_dt.Month + 1);
				string pickUpDate = pickupDate_dt.Day < 10 ? "0" + Convert.ToString(pickupDate_dt.Day) : Convert.ToString(pickupDate_dt.Day);
				string pickUpYear = Convert.ToString(pickupDate_dt.Year);
				strArrayDelDate = new string[] { pickUpYear, pickUpMonth, pickUpDate };
				delDate = string.Join("-", strArrayDelDate);
				//string[] splittedPickup = pickupDtTm_str.Split('-');
				//string[] splitDate = splittedPickup[0].Split('/');
				//DateTime dateTime1 = new DateTime(Convert.ToInt32((splitDate[2]).Split(' ')[0]), Convert.ToInt32(splitDate[0]), Convert.ToInt32(splitDate[1]));
				//DateTime dateTime2 = Convert.ToDateTime(splittedPickup[0].Split(' ')[0] + " " + splittedPickup[1].Split(' ')[1] + " " + splittedPickup[1].Split(' ')[2]);
				//delTime1 = (Convert.ToInt32(dateTime1.Hour) < 10 ? "0" + Convert.ToString(dateTime1.Hour) : Convert.ToString(dateTime1.Hour) + ":" + (Convert.ToInt32(dateTime1.Minute) < 10 ? "0" + Convert.ToString(dateTime1.Minute) : Convert.ToString(dateTime1.Minute)));
				//delTime2 = (Convert.ToInt32(dateTime2.Hour) < 10 ? "0" + Convert.ToString(dateTime2.Hour) : Convert.ToString(dateTime2.Hour) + ":" + (Convert.ToInt32(dateTime2.Minute) < 10 ? "0" + Convert.ToString(dateTime2.Minute) : Convert.ToString(dateTime2.Minute)));
				//txtDeliveryDate.Text = delDate;
				//txtDelTime1.Text = dateTime1.ToShortTimeString();
				//txtDelTime2.Text = dateTime2.ToShortTimeString();
				isAlteredTerms = false;
				if (txtComments != null)
				{
					txtComments.Text = string.Empty;
				}
				if (txtBaseCharge != null)
				{
					txtBaseCharge.Text = string.Empty;
				}
				if (txtFuelCharge != null)
				{
					txtFuelCharge.Text = string.Empty;
				}
				if (txtAccessCharge != null)
				{
					txtAccessCharge.Text = string.Empty;
				}
				if (lblSumCharge != null)
				{
					lblSumCharge.Text = "0";
				}
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Function to prepare the payload for the API while submitting new rate
		/// </summary>
		/// <returns>The rate payload.</returns>
		/// <param name="baseCharge">Base charge.</param>
		/// <param name="accessorialCharge">Accessorial charge.</param>
		/// <param name="fuelCharge">Fuel charge.</param>
		/// <param name="comment">Comment.</param>
		public string GetRatePayload(string baseCharge, string accessorialCharge, string fuelCharge, string comment)
		{
			try
			{
				payload_str = "\"BaseCharge\"" + ":" + "\"" + baseCharge + "\"";
				payload_str += "," + "\"FuelCharge\"" + ":" + "\"" + fuelCharge + "\"";
				payload_str += "," + "\"SSCharge\"" + ":" + "\"" + accessorialCharge + "\"";
				if (lstShipmentDetail.BidWithDelDate)
				{
					payload_str += "," + "\"DeliveryDateStart\"" + ":" + "\"" + delDate + " " + delTime1 + "\"";
					payload_str += "," + "\"DeliveryDateEnd\"" + ":" + "\"" + delDate + " " + delTime2 + "\"";
				}
				if (lstShipmentDetail.CanBidAlterTerms)
				{
					payload_str += "," + "\"AlteredTerms\"" + ":" + "\"" + isAlteredTerms + "\"";
				}
				if (lstShipmentDetail.AcceptedSSes != null)
				{
					payload_str += "," + "\"AcceptSSes\"" + ":" + "\"" + true + "\"";
				}
				payload_str += "," + "\"Comments\"" + ":" + "\"" + comment + "\"";
				payload_str = "{" + payload_str + "}";
				return payload_str;
			}
			catch
			{
                return null;
			}
		}

		/// <summary>
		/// Unawards the confirmation.
		/// </summary>
		/// <param name="mainView">Main view.</param>
		/// <param name="p">P.</param>
		void UnawardConfirmation(UIView mainView, object p)
		{
			try
			{
				UnawardConfirmationPopup objUnawardConfirmationPopup = new UnawardConfirmationPopup(mainView, Constants.awardConfirmation, lstShipmentDetail, this);

				UIView viewUnawardConfirmationPopup = objUnawardConfirmationPopup.GetPopupScreen();

				mainView.Add(viewUnawardConfirmationPopup);
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Resubmits the confirmation.
		/// </summary>
		/// <param name="mainView">Main view.</param>
		/// <param name="p">P.</param>
		void ResubmitConfirmation(UIView mainView, object p)
		{
			try
			{

				UnawardConfirmationPopup objUnawardConfirmationPopup = new UnawardConfirmationPopup(mainView, Constants.reSubmitConfirmation, lstShipmentDetail, this);

				UIView viewUnawardConfirmationPopup = objUnawardConfirmationPopup.GetPopupScreen();

				mainView.Add(viewUnawardConfirmationPopup);
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Resubmits the confirmation.

		/// </summary>
		/// <param name="mainView">Main view.</param>
		/// <param name="p">P.</param>
		void BidRateHistory(UIView mainView)
		{
			try
			{

				RateHistoryPopup objUnawardConfirmationPopup = new RateHistoryPopup(mainView, lstShipmentDetail);

				UIView bidRateHistoryPopup = objUnawardConfirmationPopup.GetPopupScreen();

				mainView.Add(bidRateHistoryPopup);
			}
			catch
			{
				throw;
			}
		}


		/// <summary>
		/// Shows the rate entries.
		/// </summary>
		void ShowRateEntries()
		{
			try
			{
				RateEntryPopup objPopupView = new RateEntryPopup(View, lstShipmentDetail, this);

				UIView popupView = objPopupView.GetPopupScreen();

				View.Add(popupView);
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Rates the entry popup close.
		/// </summary>
		/// <param name="popupView">Popup view.</param>
		void RateEntryPopupClose(UIView popupView)
		{
			try
			{
				popupView.Hidden = true;
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Rates the check term.
		/// </summary>
		/// <param name="btnCheckRate">Button check rate.</param>
		void RateCheckTerm(UIButton btnCheckRate)
		{
			try
			{
				if (!isRateCheck)
				{
					btnCheckRate.SetBackgroundImage(new UIImage("Images/CheckMark.png"), UIControlState.Normal);
					isRateCheck = true;
				}
				else
				{
					btnCheckRate.SetBackgroundImage(null, UIControlState.Normal);
					isRateCheck = false;
				}
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Acknowledges the required.
		/// </summary>
		/// <param name="btnAcknowledge">Button acknowledge.</param>
		void AcknowledgeRequired(UIButton btnAcknowledge)
		{
			try
			{
				if (!isAcknowledge)
				{
					btnAcknowledge.SetBackgroundImage(new UIImage("Images/CheckMark.png"), UIControlState.Normal);
					isAcknowledge = true;
				}
				else
				{
					btnAcknowledge.SetBackgroundImage(null, UIControlState.Normal);
					isAcknowledge = false;
				}
			}
			catch
			{
				throw;
			}
		}

		#endregion

		#region Conversation Screen Code

		public void ConversationSection()
		{
			viewReplyContainer = new UIView(new CGRect(0, 20, viewShipmentDetails.Frame.Width, viewShipmentDetails.Frame.Height));
			viewReplyContainer.BackgroundColor = UIColor.Clear;

			tapGestureReplyContainer = new UITapGestureRecognizer(new Action(delegate
			{
				View.EndEditing(true);
				viewReply.Hidden = true;
				CommanUtil.isChatFooterHide = true;
				tblConversation.ReloadData();
			}));
			tblConversation.AddGestureRecognizer(tapGestureReplyContainer);
			if (viewReply != null)
			{
				foreach (UIView view in viewReply)
				{
					view.RemoveFromSuperview();
				}
				viewReply.RemoveFromSuperview();
			}
			viewReply.Frame = new CGRect(0, viewShipmentDetails.Frame.Height - 220, ConversationView.Frame.Width, 100);
			viewReply.BackgroundColor = Constants.tableRowOddColor;
			viewReply.Layer.BorderWidth = 0.5f;

			UILabel lblReplyHeading = new UILabel(new CGRect(10, 5, 200, 20));
			lblReplyHeading.Font = UIFont.FromName(Constants.strFontName, 13f);
			lblReplyHeading.Text = NSBundle.MainBundle.GetLocalizedString("typeMsg", null);
			lblReplyHeading.TextColor = UIColor.Red;
			if (txtReply != null)
			{
				txtReply.RemoveFromSuperview();
				txtReply = new UITextView();
			}
			else
			{
				txtReply = new UITextView();
			}
			txtReply.Frame = new CGRect(15, 30, viewReply.Frame.Width / 10 * 7, 60);
			txtReply.Layer.BorderWidth = 1;
			txtReply.Layer.CornerRadius = 5;
			txtReply.Font = UIFont.FromName(Constants.strFontName, 15f);

			//txtReply.ShouldChangeText = (textField, range, replacementString) =>
			//{
			//	var newLength = textField.Text.Length + replacementString.Length - range.Length;
			//	if (newLength > 150)
			//	{
			//		this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, NSBundle.MainBundle.GetLocalizedString("maxCharacters", null), true, this, "", 2);
			//		this.View.Add(this.customAlert);
			//	}
			//	return newLength <= 150;
			//};
			UIButton btnClose = new UIButton(new CGRect(viewReply.Frame.Width - 25, 5, 20, 15));
			btnClose.SetImage(UIImage.FromBundle("Images/error.PNG"), UIControlState.Normal);

			btnClose.TouchUpInside += delegate
			{
				View.EndEditing(true);
				viewReplyContainer.Hidden = true;
				viewReply.Hidden = true;
				txtReply.Text = "";
				CommanUtil.isChatFooterHide = true;
				tblConversation.ReloadData();
			};

			UIButton btnAttachment = new UIButton(new CGRect(txtReply.Frame.Width + 25, 45, 30, 30));
			btnAttachment.SetImage(UIImage.FromBundle("Images/upload-hover-icon.png"), UIControlState.Normal);

			btnAttachment.TouchUpInside += delegate
			{
				BrowserFile();
			};

			UIButton btnSendMsg = new UIButton(new CGRect(btnAttachment.Frame.X + 45, 45, 30, 30));
			btnSendMsg.SetImage(UIImage.FromBundle("Images/send-icon.png"), UIControlState.Normal);

			viewReply.AddSubviews(txtReply, btnAttachment, btnSendMsg, btnClose, lblReplyHeading);
			//viewReply.Hidden = true;
			viewReplyContainer.Hidden = true;
			if (viewLoaded)
			{
				viewReply.Hidden = true;
			}
			else
			{
				if (!CommanUtil.isChatFooterHide)
				{
					viewReply.Hidden = false;
				}
					
			}
				
			//viewShipmentDetails.AddSubview(viewReply);
			viewShipmentDetails.AddSubview(viewReply);
			//View.AddSubview(viewReplyContainer);
			if (lstShipmentDetail.Conversations != null)
			{
				//List<Conversation> lstConversationHeading = lstShipmentDetail.Conversations.Where(conversation => conversation.Level == 0).ToList();

				//tblConversation.Bounces = false;
				tblConversation.AllowsSelection = false;
				tblConversation.Bounces = false;
				tblConversation.SeparatorStyle = UITableViewCellSeparatorStyle.None;
				tblConversation.Frame = new CGRect(0, viewConversationTop.Frame.Height, ConversationView.Frame.Width, ConversationView.Frame.Height - viewConversationTop.Frame.Height);
				ConversationView.AddSubview(tblConversation);

				ConversationAdapter objConversationAdapter = new ConversationAdapter(lstShipmentDetail, viewReply, View, this);

				if (tblConversation.Source == null)
				{
					tblConversation.Source = objConversationAdapter;
					tblConversation.TableFooterView = new UIView(CGRect.Empty);
				}
				else
				{
					objConversationAdapter.lstShipmentDetail = lstShipmentDetail;
					UIView.PerformWithoutAnimation(delegate
						{
							tblConversation.TableFooterView = new UIView(CGRect.Empty);
							tblConversation.BeginUpdates();
							tblConversation.ReloadSections(NSIndexSet.FromIndex(0), UITableViewRowAnimation.None);
							tblConversation.EndUpdates();
						});
					
				}
				if (Util.ActiveConversationHeader != -1)
				{
					objConversationAdapter.ExpandSection(Util.ActiveConversationHeader, tblConversation);
				}

				//tblConversation.ReloadData();


				//tblConversation.Frame = new CGRect(0, viewConversationTop.Frame.Height, ConversationView.Frame.Width, lstConversationHeading.Count * 67);
				//ConversationView.AddSubview(tblConversation);
				//tblConversation.EstimatedRowHeight = 50;
				////tblConversation.RowHeight = UITableView.AutomaticDimension;
				//tblConversation.Source = new ConversationAdapter(lstShipmentDetail, viewReply);
				//tblConversation.TableFooterView = new UIView(CGRect.Empty);
				//tblConversation.AllowsSelection = false;
				////tblConversation.SeparatorEffect = null;
				//tblConversation.ReloadData();
			}
			else
			{
				tblConversation.Hidden = true;
			}
			btnSendMsg.TouchUpInside += delegate
			{
				if (Reachability.InternetConnectionStatus())
				{
					SendReply(txtReply.Text);
				}
				else
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
					this.View.Add(this.customAlert);
				}
			};

		}

		/// <summary>
		/// Sends the reply.
		/// </summary>
		/// <param name="txtMessage">Text message.</param>
		private async void SendReply(string txtMessage)
		{
			Conversation conversation = null;
			if (CommanUtil.replyForConversation != null)
			{
				conversation = CommanUtil.replyForConversation;
			}
			try
			{
				if (string.IsNullOrEmpty(txtMessage))
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, ConstantsClass.strReplyMsg, true, this, "", 1);
					this.View.Add(this.customAlert);
					return;
				}
				else
				{
					CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
					loadPop = null;
					if (loadPop == null)
					{
						loadPop = new LoadingOverlay(bounds);
					}
					View.Add(loadPop);
					string shipmentId = CommanUtil.CompositeKey(lstShipmentDetail.ClientID, lstShipmentDetail.LocID, lstShipmentDetail.BolNum);
					string jsonRequest = string.Empty;
					if (bytes != null)
					{
						string uploadResult = await UploadBitmapAsync(bytes);
						if (!string.IsNullOrEmpty(uploadResult))
						{
							methodName = APIMethods.shipmentDetails + "/" + shipmentId + "/" + APIMethods.msg;
							jobject = JObject.Parse(uploadResult);
							if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
							{
								jsonRequest = FileUploadHelper.UploadsJsonRequest(uploadResult);
								SaveReplyMessage(conversation, txtMessage, jsonRequest);
							}
							else
							{
								loadPop.Hide();
								await Util.ErrorLog(Constants.strConversation, Convert.ToString(jobject[Constants.strErrorMessage]), strToken);
								this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Convert.ToString(jobject[Constants.strErrorMessage]), true, this, "", 1);
								this.View.Add(this.customAlert);

							}
						}
						else
						{
							loadPop.Hide();
							this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strChooseFile, true, this, "", 1);
							this.View.Add(this.customAlert);
						}

					}
					else
					{
						methodName = APIMethods.shipmentDetails + "/" + shipmentId + "/" + APIMethods.msg;
						SaveReplyMessage(conversation, txtMessage, string.Empty);
					}
				}
			}
			catch
			{

				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
				loadPop.Hide();
			}
		}

		/// <summary>
		/// Save Reply Message
		/// </summary>
		/// <param name="conversation"></param>
		/// <param name="txtMessage"></param>
		/// <param name="jsonRequest"></param>
		private async void SaveReplyMessage(Conversation conversation, string txtMessage, string jsonRequest)
		{
			try
			{
				string jsonReplyRequest = "{"
					+ "\"ReplyToID\":" + "\"" + conversation.ID + "\","
					+ "\"Message\":" + "\"" + txtMessage + "\","
					+ "\"Files\":[" + jsonRequest
					+ "]}";
				objServicehelper = new ServiceHelper();
				string replyResult = await objServicehelper.PostRequestJson(jsonReplyRequest, methodName, strToken, true);
				if (replyResult != null)
				{
					CommanUtil.isReply = true;
					bytes = null;
					string value = lstShipmentDetail.ClientID + "|" + lstShipmentDetail.BolNum + "|" + ConstantsClass.strReply;

					RefreshShipmentDetail(value);
				}
				else
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
					this.View.Add(this.customAlert);
					loadPop.Hide();
				}
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
				loadPop.Hide();
			}
		}

		/// <summary>
		/// Upload Data in Bitmap 
		/// </summary>
		/// <param name="bytes"></param>
		/// <returns></returns>
		public async Task<string> UploadReplyBitmapAsync(byte[] bytes)
		{
			try
			{
				FileUploadHelper objUploadHelper = null;
				string apiMethod = string.Empty;
				objUploadHelper = new FileUploadHelper();
				apiMethod = APIMethods.composeDocs;
				var response = await objUploadHelper.PostFiles(bytes, fileName, apiMethod, strToken, true);
				return response;
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
				loadPop.Hide();
				return null;
			}
		}


		/// <summary>
		/// Refreshs the shipment detail.
		/// </summary>
		/// <param name="compositeKey">Composite key.</param>
		public void RefreshShipmentDetail(string compositeKey)
		{
			try
			{

				if (Reachability.InternetConnectionStatus())
				{
					ShipmentDetailController objShipmentDetailController =
						this.Storyboard.InstantiateViewController
						("ShipmentDetailController") as ShipmentDetailController;
					objShipmentDetailController.compositeKey = compositeKey;
					Util.currentTabAssigned = 4;
					this.NavigationController.PushViewController(objShipmentDetailController, true);
				}
				else
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
					this.View.Add(this.customAlert);
				}
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}

		#endregion

		#region Print Bol

		public async void PrintBol()
		{
			try
			{
				objServicehelper = new ServiceHelper();
				// create json object that holds the api values
				//Method Name
				string shipmentId = CommanUtil.CompositeKey(lstShipmentDetail.ClientID, lstShipmentDetail.LocID, lstShipmentDetail.BolNum);
				methodName = APIMethods.shipmentDetails + "/" + shipmentId + "/" + APIMethods.printBoL;
				CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
				loadPop = null;
				if (loadPop == null)
				{
					loadPop = new LoadingOverlay(bounds);
				}
				View.Add(loadPop);
				//Get the Shipments
				var strResponse = await objServicehelper.GetRequest(strToken, methodName, true);
				if (strResponse != null)
				{
					loadPop.Hide();
					jobject = JObject.Parse(strResponse);
					if (string.IsNullOrEmpty(Convert.ToString(jobject["BOLError"])))
					{
						OpenBol(jobject);
					}
					else
					{
						await Util.ErrorLog(lstShipmentDetail.BolNum, Constants.strPrintBol, strToken);
						string message = Constants.strPrintError;

						PrintBolPopup printBolPopup = new PrintBolPopup(View, message, this);

						UIView printBolView = printBolPopup.GetErrorPopup();

						View.Add(printBolView);
					}
					strResponse = null;
				}
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
				loadPop.Hide();
			}
		}


        /// <summary>
        /// Print Bol NO
        /// </summary>
        /// <param name="jobject"></param>
        private void OpenBol(JObject jobject)
        {
            try
            {
                string BOLReport = Convert.ToString(jobject["BOLReport"]);
                WebViewController objWebViewController =
                      this.Storyboard.InstantiateViewController
                     ("WebViewController") as WebViewController;                 objWebViewController.strHeading = Constants.strPrint;                 CommanUtil.fileURL = BOLReport;
                this.NavigationController.PushViewController(objWebViewController, true);
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
            }
        }
		#endregion

	}

}
