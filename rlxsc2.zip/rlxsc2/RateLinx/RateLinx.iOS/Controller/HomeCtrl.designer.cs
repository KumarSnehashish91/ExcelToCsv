// WARNING
//
// This file has been generated automatically by Xamarin Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace myapp
{
	[Register ("HomeCtrl")]
	partial class HomeCtrl
	{
		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UIButton btnClick { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblEmailID { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblLogin { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblPassword { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UIView MainView { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITextField txtEmailId { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITextField txtPassword { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UIView vwHeader { get; set; }

		[Action ("BtnClick_TouchUpInside:")]
		[GeneratedCode ("iOS Designer", "1.0")]
		partial void BtnClick_TouchUpInside (UIButton sender);

		void ReleaseDesignerOutlets ()
		{
			if (btnClick != null) {
				btnClick.Dispose ();
				btnClick = null;
			}
			if (lblEmailID != null) {
				lblEmailID.Dispose ();
				lblEmailID = null;
			}
			if (lblLogin != null) {
				lblLogin.Dispose ();
				lblLogin = null;
			}
			if (lblPassword != null) {
				lblPassword.Dispose ();
				lblPassword = null;
			}
			if (MainView != null) {
				MainView.Dispose ();
				MainView = null;
			}
			if (txtEmailId != null) {
				txtEmailId.Dispose ();
				txtEmailId = null;
			}
			if (txtPassword != null) {
				txtPassword.Dispose ();
				txtPassword = null;
			}
			if (vwHeader != null) {
				vwHeader.Dispose ();
				vwHeader = null;
			}
		}
	}
}
