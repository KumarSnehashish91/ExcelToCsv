// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace RateLinx.iOS
{
    [Register ("ShipmentDetailController")]
    partial class ShipmentDetailController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnChooseFile { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnComposeMessage { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnUpload { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView ConversationView { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgBack { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgConversation { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgInvoice { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgPlaceRate { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgRateDetail { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgRefresh { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgSupporting { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgTrackingInfo { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblBolNo { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblConversation { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblCopyRight { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblFileName { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblNewRate { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblRateDetail { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblSupporting { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView NewRateView { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView RateDetailView { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView ShipmentDetail { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView SupportingView { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITableView tblConversation { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITableView tblFileDetails { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITableView tblRateDetails { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewConversationTop { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewDetailsFooter { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewFileContainer { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewHeaderShipDetails { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewSeparator { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewShipmentDetails { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewShipmentHead { get; set; }

        [Action ("BtnChooseFile_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnChooseFile_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnComposeMessage_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnComposeMessage_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnUpload_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnUpload_TouchUpInside (UIKit.UIButton sender);

        void ReleaseDesignerOutlets ()
        {
            if (btnChooseFile != null) {
                btnChooseFile.Dispose ();
                btnChooseFile = null;
            }

            if (btnComposeMessage != null) {
                btnComposeMessage.Dispose ();
                btnComposeMessage = null;
            }

            if (btnUpload != null) {
                btnUpload.Dispose ();
                btnUpload = null;
            }

            if (ConversationView != null) {
                ConversationView.Dispose ();
                ConversationView = null;
            }

            if (imgBack != null) {
                imgBack.Dispose ();
                imgBack = null;
            }

            if (imgConversation != null) {
                imgConversation.Dispose ();
                imgConversation = null;
            }

            if (imgInvoice != null) {
                imgInvoice.Dispose ();
                imgInvoice = null;
            }

            if (imgPlaceRate != null) {
                imgPlaceRate.Dispose ();
                imgPlaceRate = null;
            }

            if (imgRateDetail != null) {
                imgRateDetail.Dispose ();
                imgRateDetail = null;
            }

            if (imgRefresh != null) {
                imgRefresh.Dispose ();
                imgRefresh = null;
            }

            if (imgSupporting != null) {
                imgSupporting.Dispose ();
                imgSupporting = null;
            }

            if (imgTrackingInfo != null) {
                imgTrackingInfo.Dispose ();
                imgTrackingInfo = null;
            }

            if (lblBolNo != null) {
                lblBolNo.Dispose ();
                lblBolNo = null;
            }

            if (lblConversation != null) {
                lblConversation.Dispose ();
                lblConversation = null;
            }

            if (lblCopyRight != null) {
                lblCopyRight.Dispose ();
                lblCopyRight = null;
            }

            if (lblFileName != null) {
                lblFileName.Dispose ();
                lblFileName = null;
            }

            if (lblNewRate != null) {
                lblNewRate.Dispose ();
                lblNewRate = null;
            }

            if (lblRateDetail != null) {
                lblRateDetail.Dispose ();
                lblRateDetail = null;
            }

            if (lblSupporting != null) {
                lblSupporting.Dispose ();
                lblSupporting = null;
            }

            if (NewRateView != null) {
                NewRateView.Dispose ();
                NewRateView = null;
            }

            if (RateDetailView != null) {
                RateDetailView.Dispose ();
                RateDetailView = null;
            }

            if (ShipmentDetail != null) {
                ShipmentDetail.Dispose ();
                ShipmentDetail = null;
            }

            if (SupportingView != null) {
                SupportingView.Dispose ();
                SupportingView = null;
            }

            if (tblConversation != null) {
                tblConversation.Dispose ();
                tblConversation = null;
            }

            if (tblFileDetails != null) {
                tblFileDetails.Dispose ();
                tblFileDetails = null;
            }

            if (tblRateDetails != null) {
                tblRateDetails.Dispose ();
                tblRateDetails = null;
            }

            if (viewConversationTop != null) {
                viewConversationTop.Dispose ();
                viewConversationTop = null;
            }

            if (viewDetailsFooter != null) {
                viewDetailsFooter.Dispose ();
                viewDetailsFooter = null;
            }

            if (viewFileContainer != null) {
                viewFileContainer.Dispose ();
                viewFileContainer = null;
            }

            if (viewHeaderShipDetails != null) {
                viewHeaderShipDetails.Dispose ();
                viewHeaderShipDetails = null;
            }

            if (viewSeparator != null) {
                viewSeparator.Dispose ();
                viewSeparator = null;
            }

            if (viewShipmentDetails != null) {
                viewShipmentDetails.Dispose ();
                viewShipmentDetails = null;
            }

            if (viewShipmentHead != null) {
                viewShipmentHead.Dispose ();
                viewShipmentHead = null;
            }
        }
    }
}