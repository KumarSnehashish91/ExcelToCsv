﻿using System;
using System.Drawing;
using Foundation;
using UIKit;
using MonoTouch;
using SidebarNavigation;
namespace RateLinx.iOS
{
	public partial class BaseController : UIViewController
	{
		//RootViewController obj = new RootViewController();
		protected SidebarNavigation.SidebarController SidebarController
		{
			get
			{
				return (UIApplication.SharedApplication.Delegate as AppDelegate).RootViewController.SidebarController;
			}
		}
		// provide access to the navigation controller to all inheriting controllers
		protected NavController NavController
		{
			get
			{
				return (UIApplication.SharedApplication.Delegate as AppDelegate).RootViewController.NavController;
			}
		}

		//provide access to the storyboard to all inheriting controllers
		public override UIStoryboard Storyboard
		{
			get
			{
				return (UIApplication.SharedApplication.Delegate as AppDelegate).RootViewController.Storyboard;
			}
		}

		public BaseController(IntPtr handle) : base(handle)
		{
		}

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();
			// Perform any additional setup after loading the view, typically from a nib.
		}

		public override void ViewDidAppear(bool animated)
		{
			base.ViewDidAppear(animated);
			// Perform any additional setup after loading the view, typically from a ni
		}
	}
}


