using Foundation;
using System;
using UIKit;
using MonoTouch.Dialog;
using MonoTouch.NUnit;

using SidebarNavigation;


namespace RateLinx.iOS
{
    public partial class HomeController : UITabBarController
    {
		

		// the sidebar controller for the app
		public SidebarController SidebarController { get; private set; }

        public HomeController (IntPtr handle) : base (handle)
        {
			
		}
    }
}