// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace RateLinx.iOS
{
    [Register ("HelpAndFeedbackController")]
    partial class HelpAndFeedbackController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnSend { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView HelpAndFeedBackView { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgHome { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgMenu { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblCopyRight { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblHelpFeedback { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIScrollView scrollViewHelpFeedback { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextView txtMessage { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField txtSubject { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewHelpAndFeedback { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewMessage { get; set; }

        [Action ("BtnSend_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnSend_TouchUpInside (UIKit.UIButton sender);

        void ReleaseDesignerOutlets ()
        {
            if (btnSend != null) {
                btnSend.Dispose ();
                btnSend = null;
            }

            if (HelpAndFeedBackView != null) {
                HelpAndFeedBackView.Dispose ();
                HelpAndFeedBackView = null;
            }

            if (imgHome != null) {
                imgHome.Dispose ();
                imgHome = null;
            }

            if (imgMenu != null) {
                imgMenu.Dispose ();
                imgMenu = null;
            }

            if (lblCopyRight != null) {
                lblCopyRight.Dispose ();
                lblCopyRight = null;
            }

            if (lblHelpFeedback != null) {
                lblHelpFeedback.Dispose ();
                lblHelpFeedback = null;
            }

            if (scrollViewHelpFeedback != null) {
                scrollViewHelpFeedback.Dispose ();
                scrollViewHelpFeedback = null;
            }

            if (txtMessage != null) {
                txtMessage.Dispose ();
                txtMessage = null;
            }

            if (txtSubject != null) {
                txtSubject.Dispose ();
                txtSubject = null;
            }

            if (viewHelpAndFeedback != null) {
                viewHelpAndFeedback.Dispose ();
                viewHelpAndFeedback = null;
            }

            if (viewMessage != null) {
                viewMessage.Dispose ();
                viewMessage = null;
            }
        }
    }
}