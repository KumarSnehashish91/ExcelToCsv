// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace RateLinx.iOS
{
    [Register ("RealTimeTrackingController")]
    partial class RealTimeTrackingController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton backButton { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton imgDetails { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblCopyRight { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel txtCurrentLocation { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextView txtDestinationAddress { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel txtDistanceLeft { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel txtDistanceTravelled { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel txtShipmentStatus { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextView txtSourceAddress { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel txtTimeTaken { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewMapControl { get; set; }

        [Action ("BackButton_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BackButton_TouchUpInside (UIKit.UIButton sender);

        [Action ("ImgDetails_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void ImgDetails_TouchUpInside (UIKit.UIButton sender);

        void ReleaseDesignerOutlets ()
        {
            if (backButton != null) {
                backButton.Dispose ();
                backButton = null;
            }

            if (imgDetails != null) {
                imgDetails.Dispose ();
                imgDetails = null;
            }

            if (lblCopyRight != null) {
                lblCopyRight.Dispose ();
                lblCopyRight = null;
            }

            if (txtCurrentLocation != null) {
                txtCurrentLocation.Dispose ();
                txtCurrentLocation = null;
            }

            if (txtDestinationAddress != null) {
                txtDestinationAddress.Dispose ();
                txtDestinationAddress = null;
            }

            if (txtDistanceLeft != null) {
                txtDistanceLeft.Dispose ();
                txtDistanceLeft = null;
            }

            if (txtDistanceTravelled != null) {
                txtDistanceTravelled.Dispose ();
                txtDistanceTravelled = null;
            }

            if (txtShipmentStatus != null) {
                txtShipmentStatus.Dispose ();
                txtShipmentStatus = null;
            }

            if (txtSourceAddress != null) {
                txtSourceAddress.Dispose ();
                txtSourceAddress = null;
            }

            if (txtTimeTaken != null) {
                txtTimeTaken.Dispose ();
                txtTimeTaken = null;
            }

            if (viewMapControl != null) {
                viewMapControl.Dispose ();
                viewMapControl = null;
            }
        }
    }
}