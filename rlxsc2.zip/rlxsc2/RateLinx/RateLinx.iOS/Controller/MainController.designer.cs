// WARNING
//
// This file has been generated automatically by Xamarin Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace myapp
{
	[Register ("MainController")]
	partial class MainController
	{
		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UIButton btnmenu { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblEmail { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblEmailVal { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblId { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblIdVal { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblLogOut { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblName { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblNameVal { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblUserInfo { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UIView vwHeader { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UIView vwMemberInfo { get; set; }

		[Action ("Btnmenu_TouchUpInside:")]
		[GeneratedCode ("iOS Designer", "1.0")]
		partial void Btnmenu_TouchUpInside (UIButton sender);

		void ReleaseDesignerOutlets ()
		{
			if (btnmenu != null) {
				btnmenu.Dispose ();
				btnmenu = null;
			}
			if (lblEmail != null) {
				lblEmail.Dispose ();
				lblEmail = null;
			}
			if (lblEmailVal != null) {
				lblEmailVal.Dispose ();
				lblEmailVal = null;
			}
			if (lblId != null) {
				lblId.Dispose ();
				lblId = null;
			}
			if (lblIdVal != null) {
				lblIdVal.Dispose ();
				lblIdVal = null;
			}
			if (lblLogOut != null) {
				lblLogOut.Dispose ();
				lblLogOut = null;
			}
			if (lblName != null) {
				lblName.Dispose ();
				lblName = null;
			}
			if (lblNameVal != null) {
				lblNameVal.Dispose ();
				lblNameVal = null;
			}
			if (lblUserInfo != null) {
				lblUserInfo.Dispose ();
				lblUserInfo = null;
			}
			if (vwHeader != null) {
				vwHeader.Dispose ();
				vwHeader = null;
			}
			if (vwMemberInfo != null) {
				vwMemberInfo.Dispose ();
				vwMemberInfo = null;
			}
		}
	}
}
