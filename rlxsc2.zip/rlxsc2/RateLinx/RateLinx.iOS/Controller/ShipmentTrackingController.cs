using Foundation;
using System;
using UIKit;
using Google.Maps;
using CoreGraphics;
using CoreLocation;
using RateLinx.GoogleServices;
using System.Threading.Tasks;
using System.Net;
using Newtonsoft.Json;
using RateLinx.Helper;
using RateLinx.APIs;
using Newtonsoft.Json.Linq;
using RateLinx.Models;

namespace RateLinx.iOS
{
	public partial class ShipmentTrackingController : UIViewController
	{
		#region variables declaration
		MapView mapView;
		GeoCodeJSONClass objGeoCodeJSONClass;
		public string addressKey;
		double latitude;
		double longitude;
		string strGeoCodeURL = string.Empty;
		string strHttpResponse = string.Empty;
		//Code snippet to mark source and destination points
		Location SourceLocation { get; set; }
		UITapGestureRecognizer tapGesture;
		string methodName = string.Empty;
		ServiceHelper objHelper = null;
		string response = string.Empty;
		string tokenNo = string.Empty;
		string bolNum = string.Empty;
		string addressType = string.Empty;
		JObject jobject;
		string[] trackingId = null;
		CustomPopup customAlert = null;
		TrackShipment trackingDetail;
		TrackLocation objLocation = null;
		public string compositeKey;
		LoadingOverlay loadPop;

		#endregion

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.ShipmentTrackingController"/> class.
		/// </summary>
		/// <param name="handle">Handle.</param>
		public ShipmentTrackingController(IntPtr handle) : base(handle)
		{
			objHelper = new ServiceHelper();
			objLocation = new TrackLocation();
			tokenNo = CommanUtil.tokenNo;
		}

		/// <summary>
		/// Loads the view.
		/// </summary>
		public override async void LoadView()
		{
			try
			{
				base.LoadView();

				tapGesture = new UITapGestureRecognizer(ManageNavigation);
				imgBack.AddGestureRecognizer(tapGesture);
				await TrackShipment();
			}
			catch
			{
				Console.Write(RateLinx.Helper.Constants.strErrorOccured);
			}
		}

		public override UIInterfaceOrientationMask GetSupportedInterfaceOrientations()
		{
			return UIInterfaceOrientationMask.Portrait;
		}

		public override void DidRotate(UIInterfaceOrientation fromInterfaceOrientation)
		{
			base.DidRotate(fromInterfaceOrientation);

			mapView.Frame = viewMap.Frame;

			if (!Util.isViewRotated)
			{
				Util.isViewRotated = true;
			}
			else
			{
				Util.isViewRotated = false;
			}
		}
		/// <summary>
		/// Track shipment Address
		/// </summary>
		private async Task TrackShipment()
		{
			try
			{
				if (Reachability.InternetConnectionStatus()) 				{
					CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
					loadPop = null;
					if (loadPop == null)
					{
						loadPop = new LoadingOverlay(bounds);
					}
					View.Add(loadPop);
					lblBolNo.Text = compositeKey.Split('#')[0].Split('|')[2];
					trackingId = compositeKey.Split('#');
					string routeFrom = trackingId[1];
					if (routeFrom == RateLinx.Helper.Constants.strTrackAll)
					{
						await GetTrackingPositions();
					}
					else
					{
						response = await GetSpecTrackingPosition();
						if (string.IsNullOrEmpty(response))
						{
							return;
						}
					}
					loadPop.Hide();
				} 				else 				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1); 					this.View.Add(this.customAlert); 				}
			}
			catch
			{
				Console.Write(RateLinx.Helper.Constants.strErrorOccured);
				loadPop.Hide();
			}
		}


		/// <summary>
		/// Fns the http request.
		/// </summary>
		/// <returns>The http request.</returns>
		/// <param name="strURL">String URL.</param>
		static async Task<string> FnHttpRequest(string strURL)
		{
			try
			{
				WebClient client = new WebClient();
				string strResult;
				try
				{
					strResult = await client.DownloadStringTaskAsync(new Uri(strURL));
				}
				catch
				{
					strResult = NSBundle.MainBundle.GetLocalizedString("exception", null);
				}
				finally
				{
					client.Dispose();
					client = null;
				}
				return strResult;
			}
			catch
			{
				Console.Write(RateLinx.Helper.Constants.strErrorOccured);
				return null;
			}
		}


		/// <summary>
		/// Manages the navigation.
		/// </summary>
		/// <param name="tapGesture">Tap gesture.</param>
		public void ManageNavigation(UITapGestureRecognizer tapGesture)
		{
			try
			{
				this.NavigationController.PopViewController(true);
			}
			catch
			{
				Console.Write(RateLinx.Helper.Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Date And Time And Days Calculation
		/// </summary>
		/// <param name="reportedAtDate"></param>
		/// <returns></returns>
		private string getDateTime(string reportedAtDate)
		{
			try
			{
				string[] bidDeadLine = reportedAtDate.Split('T');
				DateTime currentDate = DateTime.Parse(bidDeadLine[0] + " " + bidDeadLine[1]);
				string currMonth = (currentDate.Month + 1) < 10 ? "0" + Convert.ToString(currentDate.Month + 1) : Convert.ToString(currentDate.Month + 1);  //((currentDate.GetMonth() + 1)) < 10 ? "0" + (currentDate.getMonth() + 1) : (currentDate.getMonth() + 1);
				string currDate = (currentDate.Day) < 10 ? "0" + Convert.ToString(currentDate.Day) : Convert.ToString(currentDate.Day);
				string ActiveDate = currMonth + '-' + currDate + '-' + currentDate.Year;
				string hours = (currentDate.Hour) < 10 ? "0" + Convert.ToString(currentDate.Hour) : Convert.ToString(currentDate.Hour);
				string min = (currentDate.Minute) < 10 ? "0" + Convert.ToString(currentDate.Minute) : Convert.ToString(currentDate.Minute);
				string ActiveTime = hours + ":" + min;
				return ActiveDate + " " + ActiveTime;
			}
			catch
			{
				Console.Write(RateLinx.Helper.Constants.strErrorOccured);
				return null;
			}
		}

		/// <summary>
		/// Track All Shipment
		/// </summary>
		/// <returns></returns>
		private async Task GetTrackingPositions()
		{
			try {
				methodName = APIMethods.trackingPositions;
				string city = string.Empty;
				string state = string.Empty;
				string country = string.Empty;
				string activityDescr = string.Empty;
				response = await objHelper.GetRequest (tokenNo, methodName, true);
				if (!string.IsNullOrEmpty (response)) {
					jobject = JObject.Parse (response);
					if (string.IsNullOrEmpty (Convert.ToString (jobject [RateLinx.Helper.Constants.strErrorMessage]))) {
						trackingDetail = JsonConvert.DeserializeObject<TrackShipment> (response);
						//Get the details of shipment and trying to show in map
						for (int index = 0; index < trackingDetail.ShipmentPos.Count; index++) {
							city = trackingDetail.ShipmentPos [index].Positions [0].City;
							state = trackingDetail.ShipmentPos [index].Positions [0].State;
							country = trackingDetail.ShipmentPos [index].Positions [0].Country;
							bolNum = trackingDetail.ShipmentPos [index].BolNum;
							//ReportedBy = trackingDetail.ShipmentPos [index].Positions [index].ReportedBy;
							//ReportedAt = getDateTime (trackingDetail.ShipmentPos [index].Positions [index].ReportedAt);
							activityDescr = trackingDetail.ShipmentPos [index].Positions [index].ActivityDescr;
							addressType = city + " " + state + " " + country;//Update Address
							objLocation.addressType = addressType;
							objLocation.address = city + " " + state + " " + country;//Update Address
							await GeocodeToConsoleAsync (addressType);
						}
					} else {
						response = string.Empty;
						loadPop.Hide ();
						//Post Error Logger Request 
						await Util.ErrorLog (RateLinx.Helper.Constants.strLiveTrack, Convert.ToString (jobject [RateLinx.Helper.Constants.strErrorMessage]), tokenNo);
						this.customAlert = new CustomPopup (UIScreen.MainScreen.Bounds, Convert.ToString (jobject [RateLinx.Helper.Constants.RecentShipments]), true, this, "", 1);
						this.View.Add (this.customAlert);
					}
				} else {
					loadPop.Hide ();
					this.customAlert = new CustomPopup (UIScreen.MainScreen.Bounds, RateLinx.Helper.Constants.strLocation, true, this, "", 1);
					this.View.Add (this.customAlert);

				}
			} catch {
				loadPop.Hide ();
				this.customAlert = new CustomPopup (UIScreen.MainScreen.Bounds, RateLinx.Helper.Constants.strLocation, true, this, "", 1);
				this.View.Add (this.customAlert);

			}
		}

		/// <summary>
		/// Track Perticular Shipment
		/// </summary>
		/// <returns></returns>
		private async Task<string> GetSpecTrackingPosition()
		{
			string result = string.Empty;
			try
			{

				methodName = APIMethods.specTrackingPosition + compositeKey.Split('#')[0];
				objHelper = new ServiceHelper();
				response = await objHelper.GetRequest(tokenNo, methodName, true);
				if (!string.IsNullOrEmpty(response))
				{
					jobject = JObject.Parse(response);
					if (string.IsNullOrEmpty(Convert.ToString(jobject[RateLinx.Helper.Constants.strErrorMessage])))
					{
						trackingDetail = JsonConvert.DeserializeObject<TrackShipment>(response);
						if (!string.IsNullOrEmpty(trackingDetail.ShipmentPos[0].ErrorMsg))
						{
							loadPop.Hide();
							this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, trackingDetail.ShipmentPos[0].ErrorMsg, true, this, "", 1);
							this.View.Add(this.customAlert);
							return result;
						}
						else
						{
							//Get the details of shipment and trying to show in map
							objLocation = new TrackLocation();
							for (int index = 0; index < trackingDetail.ShipmentPos.Count; index++)
							{
								string city, Country, State = string.Empty;
								bolNum = trackingDetail.ShipmentPos[index].BolNum;
								if (trackingDetail.ShipmentPos[index].Positions[index] != null)
								{
									//ReportedBy = trackingDetail.ShipmentPos[index].Positions[index].ReportedBy;
									//ReportedAt = getDateTime(trackingDetail.ShipmentPos[index].Positions[index].ReportedAt);
									latitude = trackingDetail.ShipmentPos[index].Positions[index].Latitude;
									longitude = trackingDetail.ShipmentPos[index].Positions[index].Longitude;
									city = trackingDetail.ShipmentPos[index].Positions[index].City;
									State = trackingDetail.ShipmentPos[index].Positions[index].State;
									Country = trackingDetail.ShipmentPos[index].Positions[index].Country;
									addressType = city + " " + State + " " + Country;
								}
								else
								{
									addressType = NSBundle.MainBundle.GetLocalizedString("defaultCountry", null);
								}
								objLocation.addressType = addressType;
								await GeocodeToConsoleAsync(addressType);
							}
							return bolNum;
						}
					}
					else
					{

						response = string.Empty;
						//Post Error Logger Request 
						await Util.ErrorLog(RateLinx.Helper.Constants.strLiveTrack, Convert.ToString(jobject[RateLinx.Helper.Constants.strErrorMessage]), CommanUtil.tokenNo);
						return result;
					}
				}
				else
				{
					loadPop.Hide();
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, RateLinx.Helper.Constants.strLocation, true, this, "", 1);
					return result;
				}
			}
			catch
			{
				loadPop.Hide();
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, RateLinx.Helper.Constants.strLocation, true, this, "", 1);
				return result;
			}
		}

		/// <summary>
		/// Geocodes to console async.
		/// </summary>
		async Task GeocodeToConsoleAsync(string strSource)
		{
			try
			{
				//mark source point
				strGeoCodeURL = string.Format(RateLinx.Helper.Constants.strDirectionURL, strSource, RateLinx.Helper.Constants.strGoogleServerKey);
				strHttpResponse = await FnHttpRequest(strGeoCodeURL);

				objGeoCodeJSONClass = JsonConvert.DeserializeObject<GeoCodeJSONClass>(strHttpResponse);
				//find GeoCodeJSONClass below in this page
				if (objGeoCodeJSONClass != null && objGeoCodeJSONClass.status == NSBundle.MainBundle.GetLocalizedString("okText", null))
				{
					SourceLocation = new Location() { lat = objGeoCodeJSONClass.results[0].geometry.location.lat, lng = objGeoCodeJSONClass.results[0].geometry.location.lng };
					var camera = CameraPosition.FromCamera(latitude: SourceLocation.lat,
						longitude: SourceLocation.lng,
						zoom: 10);
					mapView = MapView.FromCamera(CGRect.Empty, camera);
					mapView.MyLocationEnabled = true;
					mapView.Settings.MyLocationButton = true;
					mapView.Settings.SetAllGesturesEnabled(true);
					//Sourec
					CLLocationCoordinate2D coord1 = new CLLocationCoordinate2D(latitude, longitude);
					var marker1 = Marker.FromPosition(coord1);
					marker1.Title = string.Format(objLocation.addressType);

					marker1.Map = mapView;

					mapView.Frame = viewMap.Bounds;
					//View = mapView;
					viewMap.AddSubview(mapView);
				}
				else
				{
					var camera = CameraPosition.FromCamera(latitude: 37.0902,
						longitude: -95.7129,
						zoom: 10);
					mapView = MapView.FromCamera(CGRect.Empty, camera);
					mapView.MyLocationEnabled = true;
					mapView.Settings.MyLocationButton = true;
					mapView.Settings.SetAllGesturesEnabled(true);
					//Sourec

					mapView.Frame = viewMap.Bounds;
					//View = mapView;
					viewMap.AddSubview(mapView);
					loadPop.Hide();
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, RateLinx.Helper.Constants.strLocation, true, this, "", 1);
					this.View.Add(this.customAlert);
				}
			}
			catch
			{
                throw;
			}
		}
			
	}
}
