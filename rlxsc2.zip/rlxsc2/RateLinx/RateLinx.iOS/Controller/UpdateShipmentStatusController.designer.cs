// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace RateLinx.iOS
{
    [Register ("UpdateShipmentStatusController")]
    partial class UpdateShipmentStatusController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton backButton { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnPhone { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton imgDetails { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblBolNumber { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblCopyRight { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblCurrentStatus { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblMiles { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblShipmentStatus { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblTotalTime { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblUsername { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UISlider slider { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextView txtDestinationAddress { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextView txtSourceAddress { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewMapControl { get; set; }

        [Action ("BackButton_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BackButton_TouchUpInside (UIKit.UIButton sender);

        [Action ("ImgDetails_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void ImgDetails_TouchUpInside (UIKit.UIButton sender);

        [Action ("SliderDragExit:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void SliderDragExit (UIKit.UISlider sender);

        [Action ("SliderTouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void SliderTouchUpInside (UIKit.UISlider sender);

        void ReleaseDesignerOutlets ()
        {
            if (backButton != null) {
                backButton.Dispose ();
                backButton = null;
            }

            if (btnPhone != null) {
                btnPhone.Dispose ();
                btnPhone = null;
            }

            if (imgDetails != null) {
                imgDetails.Dispose ();
                imgDetails = null;
            }

            if (lblBolNumber != null) {
                lblBolNumber.Dispose ();
                lblBolNumber = null;
            }

            if (lblCopyRight != null) {
                lblCopyRight.Dispose ();
                lblCopyRight = null;
            }

            if (lblCurrentStatus != null) {
                lblCurrentStatus.Dispose ();
                lblCurrentStatus = null;
            }

            if (lblMiles != null) {
                lblMiles.Dispose ();
                lblMiles = null;
            }

            if (lblShipmentStatus != null) {
                lblShipmentStatus.Dispose ();
                lblShipmentStatus = null;
            }

            if (lblTotalTime != null) {
                lblTotalTime.Dispose ();
                lblTotalTime = null;
            }

            if (lblUsername != null) {
                lblUsername.Dispose ();
                lblUsername = null;
            }

            if (slider != null) {
                slider.Dispose ();
                slider = null;
            }

            if (txtDestinationAddress != null) {
                txtDestinationAddress.Dispose ();
                txtDestinationAddress = null;
            }

            if (txtSourceAddress != null) {
                txtSourceAddress.Dispose ();
                txtSourceAddress = null;
            }

            if (viewMapControl != null) {
                viewMapControl.Dispose ();
                viewMapControl = null;
            }
        }
    }
}