// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace RateLinx.iOS
{
    [Register ("PickupAndDeliveryController")]
    partial class PickupAndDeliveryController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgBack { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblCopyRight { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblHeading { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblSignHere { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIScrollView scrollViewConfirmation { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewConfirmation { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        Xamarin.Controls.SignaturePadView viewSignaturePad { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (imgBack != null) {
                imgBack.Dispose ();
                imgBack = null;
            }

            if (lblCopyRight != null) {
                lblCopyRight.Dispose ();
                lblCopyRight = null;
            }

            if (lblHeading != null) {
                lblHeading.Dispose ();
                lblHeading = null;
            }

            if (lblSignHere != null) {
                lblSignHere.Dispose ();
                lblSignHere = null;
            }

            if (scrollViewConfirmation != null) {
                scrollViewConfirmation.Dispose ();
                scrollViewConfirmation = null;
            }

            if (viewConfirmation != null) {
                viewConfirmation.Dispose ();
                viewConfirmation = null;
            }

            if (viewSignaturePad != null) {
                viewSignaturePad.Dispose ();
                viewSignaturePad = null;
            }
        }
    }
}