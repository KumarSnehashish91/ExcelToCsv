using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;
using RateLinx.Helper;
using Newtonsoft.Json.Linq;
using Xamarin.Controls;
using CoreGraphics;
using RateLinx.APIs;
using System.Collections.Generic;
using RateLinx.Models;
using RateLinx.GoogleServices;
using System.IO;
using System.Threading.Tasks;
using CoreLocation;
using Newtonsoft.Json;
using System.Linq;
using ToastIOS;

namespace RateLinx.iOS
{
	public partial class PickupAndDeliveryController : UIViewController
	{
		#region Global used controls
		public string compositeKey;
		public string proNumber;
		UITapGestureRecognizer tapGesture;
		private bool ShowImageView => UIDevice.CurrentDevice.UserInterfaceIdiom == UIUserInterfaceIdiom.Pad;
		List<CountryDetails> lstCountryDetails = null;
		List<StateDetails> lstStateDetails = null;
		List<string> lstStates = null;
		List<string> lstCountries = null;
		List<TrackingDesc> lstTrackingDesc = null;
		int descriptionIndex = 0;
		string countryCode = string.Empty;
		string stateCode = string.Empty;
		JObject jobject = null;
		string[] activityDate = null;
		string newActivityDate, ActivityDate, activityTime, ConfType
		, shipmentID, strBase64String, payload_str, stateName, countryName, city, state, country,
		postDataJson, payloadReturn
		= string.Empty;
		bool chkTrackDetails = false;
		LoadingOverlay loadPop;
		UITextView txtActivityDate, txtActivityTime, txtProNumber, txtCity, txtState, txtCountry, txtDescription;
		ModalPickerViewController modalPicker = null;
		UIPickerView pickerView = null;
		PickerDataModel pickerDataModel = null;
		UIButton doneButton = null;
		UIView viewPicker = null;
		UIView viewTrackingDetails = null;
		UIView viewSubmitDetails = null;
		UIButton btnCheckTrackDetails;
		CustomPopup customAlert = null;
		private nfloat amountToScroll = 0.0f;
		public LocationManager Manager { get; set; }///location
		UIToolbar toolbar;
        Dictionary<string, string> trackingStatus = null;
		#endregion

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.PickupAndDeliveryController"/> class.
		/// </summary>
		/// <param name="handle">Handle.</param>
		public PickupAndDeliveryController(IntPtr handle) : base(handle)
		{
			Manager = new LocationManager();
			txtProNumber = new UITextView();
			txtCity = new UITextView();
		}

		/// <summary>
		/// Views the did load.
		/// </summary>
		public override void ViewDidLoad()
		{
			try
			{
				base.ViewDidLoad();

				lblCopyRight.Text = Util.GetCopyRight();
                trackingStatus = CommanUtil.TrackingStatus();
				toolbar = new UIToolbar(new CoreGraphics.CGRect(new nfloat(0.0f), new nfloat(0.0f), this.View.Frame.Size.Width, new nfloat(44.0f)));
			    toolbar.TintColor = UIColor.White;
			    toolbar.BarStyle = UIBarStyle.Black;
			    toolbar.Translucent = true;

				NSNotificationCenter.DefaultCenter.AddObserver
				(UIKeyboard.DidShowNotification, KeyBoardUpNotification);

				// Keyboard Down
				NSNotificationCenter.DefaultCenter.AddObserver
				(UIKeyboard.WillHideNotification, KeyBoardDownNotification);


				tapGesture = new UITapGestureRecognizer(ManageNavigation);
				imgBack.AddGestureRecognizer(tapGesture);
				var gesture = new UITapGestureRecognizer(() =>
				{
					if (viewPicker != null)
					{
						viewPicker.Hidden = true;
						pickerView.Hidden = true;
						doneButton.Hidden = true;
					}
					if (modalPicker != null)
					{
						DismissViewController(true, null);
					}
					View.EndEditing(true);
				});
				gesture.CancelsTouchesInView = false;
				viewConfirmation.AddGestureRecognizer(gesture);
                SignaturePad();
				viewSignaturePad.Frame = new CGRect(20, lblSignHere.Frame.Bottom + 10, View.Frame.Width - 40, 200);//View.Frame.Height * 0.2

				btnCheckTrackDetails = new UIButton(new CGRect(20, viewSignaturePad.Frame.Bottom + 10, 25, 25));
				btnCheckTrackDetails.BackgroundColor = UIColor.White;
				btnCheckTrackDetails.Layer.CornerRadius = 2;
				btnCheckTrackDetails.Layer.BorderWidth = 2;
                
				btnCheckTrackDetails.TouchUpInside += delegate
				{
					CheckTrackDetails(btnCheckTrackDetails);
				};

				scrollViewConfirmation.AddSubview(btnCheckTrackDetails);
				UILabel lblTrackDetails = new UILabel(new CGRect(50, viewSignaturePad.Frame.Bottom + 10, 200, 25));
				lblTrackDetails.Text = Constants.strTrack;
				lblTrackDetails.TextColor = UIColor.Black;
				lblTrackDetails.Font = UIFont.FromName(Constants.strFontName, 14f);

				scrollViewConfirmation.AddSubview(lblTrackDetails);

				viewSubmitDetails = new UIView();
				viewTrackingDetails = new UIView();
				CreateConfirmationView();
				//Creating Signature Pad
				if (!string.IsNullOrEmpty(compositeKey))
				{
					lblHeading.Text = compositeKey.Split('#')[0];
					shipmentID = compositeKey.Split('#')[1];
					if (compositeKey.Split('#')[0].ToUpper() == Constants.strPickup.ToUpper())
					{
						ConfType = Constants.pickup;
						descriptionIndex = 1;
					}
					else
					{
						ConfType = Constants.strdelivery;
						descriptionIndex = 4;
					}
				}
				lstTrackingDesc = CommanUtil.TrackingDescList();
			}
			catch
			{
				throw;
			}
		}
        /// <summary>
        /// Dids the rotate.
        /// </summary>
        /// <param name="fromInterfaceOrientation">From interface orientation.</param>
		public async override void DidRotate(UIInterfaceOrientation fromInterfaceOrientation)
		{
			viewSignaturePad.Frame = new CGRect(20, lblSignHere.Frame.Bottom + 10, View.Frame.Width - 40, 200);//View.Frame.Height * 0.2

			if (chkTrackDetails)
			{
				await LoadTrackingView(btnCheckTrackDetails);
			}
			if (!Util.isViewRotated)
			{
				Util.isViewRotated = true;
			}
			else
			{
				Util.isViewRotated = false;
			}
		}
        /// <summary>
        /// Gets the supported interface orientations.
        /// </summary>
        /// <returns>The supported interface orientations.</returns>
		public override UIInterfaceOrientationMask GetSupportedInterfaceOrientations()
		{
			return UIInterfaceOrientationMask.Portrait;
		}

		//------------------------------------------------------------//

		#region KeyBoardDidShow
        /// <summary>
        /// Keies the board up notification.
        /// </summary>
        /// <param name="notification">Notification.</param>
		private void KeyBoardUpNotification(NSNotification notification)
		{
			// get the keyboard size
			CGRect notificationBounds = UIKeyboard.BoundsFromNotification(notification);


			if (txtProNumber.IsFirstResponder)
			{
				if ((View.Frame.Height - viewTrackingDetails.Frame.Y) > (notificationBounds.Height + 100))
				{
					amountToScroll = 0;
				}
				else if ((View.Frame.Height - viewTrackingDetails.Frame.Y) < (notificationBounds.Height + 100))
				{
					amountToScroll = (notificationBounds.Height + 100) - (View.Frame.Height - viewTrackingDetails.Frame.Y);
					amountToScroll += 100;
				}
				
			}
			if (txtCity.IsFirstResponder)
			{
				if ((View.Frame.Height - viewTrackingDetails.Frame.Y) > (notificationBounds.Height + 100))
				{
					amountToScroll = 0;
				}
				else if ((View.Frame.Height - viewTrackingDetails.Frame.Y) < (notificationBounds.Height + 100))
				{
					amountToScroll = (notificationBounds.Height + 100) - (View.Frame.Height - viewTrackingDetails.Frame.Y);
					amountToScroll += 200;
				}
			
			}

			ScrollTheView();
		}
		#endregion

		#region KeyBoardWillHide
		/// <summary>
		/// Keies the board will hide.
		/// </summary>
		/// <param name="notification">Notification.</param>
		private void KeyBoardDownNotification(NSNotification notification)
		{
			//topView.Frame = new CGRect(0, 0, View.Frame.Width, 20);
			if (amountToScroll > 0)
			{
				viewConfirmation.Frame = new CGRect(0, 20, View.Frame.Width, View.Frame.Height - 20);
			}
			else
			{
				amountToScroll = 0;
			}
		}
		#endregion

		#region ScrollTheView
        /// <summary>
        /// Scrolls the view.
        /// </summary>
		private void ScrollTheView()
		{
			//topView.Frame = new CGRect(0, 0, View.Frame.Width, 20);
			// scroll the view up or down
			UIView.BeginAnimations(string.Empty, System.IntPtr.Zero);
			UIView.SetAnimationDuration(0.3);

			CoreGraphics.CGRect frame = viewConfirmation.Frame;
			frame.Y = 20;
			if (amountToScroll != 0)
			{
				frame.Y = -amountToScroll;
			}


			viewConfirmation.Frame = frame;
			UIView.CommitAnimations();
		}
		#endregion

		/// <summary>
		/// Gets the current address.
		/// </summary>
		public async Task GetCurrentAddress()
		{
			try
			{
				if (Manager.LocMgr.Location != null)
				{
					//Util.location = Manager.LocMgr.Location;
                    CLLocation location = Manager.LocMgr.Location;
					var geoCoder = new CLGeocoder();
					var placemarks = await geoCoder.ReverseGeocodeLocationAsync(location);
					foreach (var placemark in placemarks)
					{
						if (!string.IsNullOrEmpty(placemark.Locality))
						{
							city = placemark.Locality;
						}
						if (!string.IsNullOrEmpty(placemark.AdministrativeArea))
						{
							state = placemark.AdministrativeArea;
						}
						if (!string.IsNullOrEmpty(placemark.Country))
						{
							country = placemark.Country;
						}
					}
				}
				else
				{
					city = string.Empty;
					state = string.Empty;
					country = string.Empty;
                    Toast.MakeText(Helper.Constants.strLocation).SetDuration(Helper.Constants.toastDuration).Show();
				}
			}
			catch (Exception ex)
			{
                Toast.MakeText(ex.Message).SetDuration(Helper.Constants.toastDuration).Show();
			}
		}

		/// <summary>
		/// Creates the confirmation view.
		/// </summary>
		public void CreateConfirmationView()
		{
			try
			{
				if (viewTrackingDetails != null)
				{
					foreach (UIView view in viewTrackingDetails)
					{
						view.RemoveFromSuperview();
					}
				}
				if (chkTrackDetails == true)
				{
					btnCheckTrackDetails.SetBackgroundImage(new UIImage("Images/CheckMark.png"), UIControlState.Normal);
				}
				else
				{
					btnCheckTrackDetails.SetBackgroundImage(null, UIControlState.Normal);
				}
				if (chkTrackDetails == true)
				{
					viewTrackingDetails.Frame = new CGRect(0, btnCheckTrackDetails.Frame.Bottom + 10, View.Frame.Width, 280);

					nfloat yCordinate = 0;

					nfloat width1 = (viewTrackingDetails.Frame.Width / 2) - 35;
					nfloat width2 = (viewTrackingDetails.Frame.Width / 2) - 20;

					UILabel lblProNum = new UILabel(new CGRect(25, yCordinate, width1, 30));
					lblProNum.Text = Constants.strEnterPro;
					lblProNum.TextColor = UIColor.Black;
					lblProNum.Font = UIFont.FromName(Constants.strFontName, 13f);

					nfloat xCordinate = lblProNum.Frame.X + lblProNum.Frame.Width - 10;

					txtProNumber = new UITextView(new CGRect(xCordinate, yCordinate, width2, 30));
					txtProNumber.Layer.BorderWidth = 1;
					txtProNumber.Layer.CornerRadius = 5;

					if (!string.IsNullOrEmpty(proNumber))
					{
						txtProNumber.Text = proNumber;
					}

					yCordinate += lblProNum.Frame.Height + 10;

					UILabel lblActivityDate = new UILabel(new CGRect(25, yCordinate, width1, 30));
					lblActivityDate.Text = Constants.strActivityDate;
					lblActivityDate.TextColor = UIColor.Black;
					lblActivityDate.Font = UIFont.FromName(Constants.strFontName, 13f);

					txtActivityDate = new UITextView(new CGRect(xCordinate, yCordinate, width2, 30));
					txtActivityDate.Layer.BorderWidth = 1;
					txtActivityDate.Layer.CornerRadius = 5;
					string currentDate = DateTime.Now.ToString(ConstantsClass.dateFormatMMDDYYYY);
					txtActivityDate.Text = currentDate.Contains("-") ? currentDate.Replace('-', '/') : currentDate;

					var deliveryDateTap = new UITapGestureRecognizer(DeliveryDatePicker);
					txtActivityDate.AddGestureRecognizer(deliveryDateTap);

					yCordinate += lblActivityDate.Frame.Height + 10;

					UILabel lblActivityTime = new UILabel(new CGRect(25, yCordinate, width1, 30));
					lblActivityTime.Text = Constants.strActiveTime;
					lblActivityTime.TextColor = UIColor.Black;
					lblActivityTime.Font = UIFont.FromName(Constants.strFontName, 13f);
					//Time
					txtActivityTime = new UITextView(new CGRect(xCordinate, yCordinate, width2, 30));
					txtActivityTime.Layer.BorderWidth = 1;
					txtActivityTime.Layer.CornerRadius = 5;
					var deliveryTime1Tap = new UITapGestureRecognizer(DeliveryTimePicker);
					txtActivityTime.AddGestureRecognizer(deliveryTime1Tap);


					//TimeSpan timespan = new TimeSpan(03, 00, 00);
					//DateTime time = DateTime.Today.Add(timespan);
					txtActivityTime.Text = DateTime.Now.ToShortTimeString();
					yCordinate += lblActivityTime.Frame.Height + 10;

					UILabel lblCity = new UILabel(new CGRect(25, yCordinate, width1, 30));
					lblCity.Text = Constants.strCity;
					lblCity.TextColor = UIColor.Black;
					lblCity.Font = UIFont.FromName(Constants.strFontName, 13f);

					txtCity = new UITextView(new CGRect(xCordinate, yCordinate, width2, 30));
					txtCity.Layer.BorderWidth = 1;
					txtCity.Layer.CornerRadius = 5;

					yCordinate += lblCity.Frame.Height + 10;

					UILabel lblState = new UILabel(new CGRect(25, yCordinate, width1, 30));
					lblState.Text = Constants.strState;
					lblState.TextColor = UIColor.Black;
					lblState.Font = UIFont.FromName(Constants.strFontName, 13f);

					txtState = new UITextView(new CGRect(xCordinate, yCordinate, width2, 30));
					txtState.Layer.BorderWidth = 1;
					txtState.Layer.CornerRadius = 5;
					var stateTap = new UITapGestureRecognizer(BindState);
					txtState.AddGestureRecognizer(stateTap);


					UIButton btnCheckState = new UIButton();

					btnCheckState.Frame = new CGRect(txtState.Frame.X + txtState.Frame.Width -27, yCordinate+ 7, 16, 16);
					btnCheckState.BackgroundColor = UIColor.Clear;

					btnCheckState.SetBackgroundImage(new UIImage("Images/DropDown.png"), UIControlState.Normal);

					//btnCheckState.TouchUpInside += delegate
					//			{
					//				BindState(null);
					//			};
					viewTrackingDetails.AddSubview(btnCheckState);
					yCordinate += lblState.Frame.Height + 10;

					UILabel lblCountry = new UILabel(new CGRect(25, yCordinate, width1, 30));
					lblCountry.Text = Constants.strCountry;
					lblCountry.TextColor = UIColor.Black;
					lblCountry.Font = UIFont.FromName(Constants.strFontName, 13f);

					txtCountry = new UITextView(new CGRect(xCordinate, yCordinate, width2, 30));
					txtCountry.Layer.BorderWidth = 1;
					txtCountry.Layer.CornerRadius = 5;
					var countryTap = new UITapGestureRecognizer(BindCountry);
					txtCountry.AddGestureRecognizer(countryTap);

					UIButton btnCheckCountry = new UIButton();

					btnCheckCountry.Frame = new CGRect(txtCountry.Frame.X + txtCountry.Frame.Width -27, yCordinate+ 7, 16, 16);
					btnCheckCountry.BackgroundColor = UIColor.Clear;

					btnCheckCountry.SetBackgroundImage(new UIImage("Images/DropDown.png"), UIControlState.Normal);

					btnCheckCountry.TouchUpInside += delegate
								{
									//AutomaticTrackingCheck();
								};
					//viewTrackingDetails.AddSubview(btnCheckCountry);


					yCordinate += lblCountry.Frame.Height + 10;

					UILabel lblDescription = new UILabel(new CGRect(25, yCordinate, width1, 30));
					lblDescription.Text = Constants.strDesc;
					lblDescription.TextColor = UIColor.Black;
					lblDescription.Font = UIFont.FromName(Constants.strFontName, 13f);

					txtDescription = new UITextView(new CGRect(xCordinate, yCordinate, width2, 30));
					txtDescription.Layer.BorderWidth = 1;
					txtDescription.Layer.CornerRadius = 5;
					txtDescription.UserInteractionEnabled = false;
					yCordinate += lblDescription.Frame.Height + 10;

					viewTrackingDetails.AddSubviews(lblProNum, txtProNumber, lblActivityDate, txtActivityDate, lblActivityTime, txtActivityTime,
						lblCity, txtCity, lblState, txtState, lblCountry, txtCountry, lblDescription, txtDescription);

					viewTrackingDetails.AddSubviews(btnCheckState, btnCheckCountry);

					//Adding done button with the keyboard which appears when txtProNumber or txtCity is Responder
					toolbar.Items = new UIBarButtonItem[]{
					new UIBarButtonItem(UIBarButtonSystemItem.FlexibleSpace),
		 			new UIBarButtonItem(UIBarButtonSystemItem.Done, delegate {
						if(txtProNumber.IsFirstResponder)
						{
							txtProNumber.ResignFirstResponder();
						}

						else
						{
							txtCity.ResignFirstResponder();
						}
					})
				};
				txtProNumber.KeyboardAppearance = UIKeyboardAppearance.Default;
				txtProNumber.InputAccessoryView = toolbar;

				txtCity.KeyboardAppearance = UIKeyboardAppearance.Default;
				txtCity.InputAccessoryView = toolbar;

				}
				else
				{
					foreach (UIView objView in viewTrackingDetails)
					{
						objView.RemoveFromSuperview();
					}
					viewTrackingDetails = new UIView(new CGRect(0, btnCheckTrackDetails.Frame.Bottom + 5, 0, 0));
				}
				viewSubmitDetails.Frame = new CGRect(0, viewTrackingDetails.Frame.Y + 15 + viewTrackingDetails.Frame.Height, viewConfirmation.Frame.Width, 50);
				foreach (UIView objView in viewSubmitDetails)
				{
					objView.RemoveFromSuperview();
				}

				UIButton btnReset = new UIButton(new CGRect(20, 5, 100, 30));
				btnReset.SetTitle(Constants.strResetSign, UIControlState.Normal);
				btnReset.SetTitleColor(UIColor.White, UIControlState.Normal);
				btnReset.Layer.CornerRadius = 5;
				btnReset.BackgroundColor = ConstantsClass.separatorClr;
				btnReset.Font = UIFont.FromName(Constants.strFontName, 13f);
				btnReset.UserInteractionEnabled = true;
				btnReset.TouchUpInside += delegate
				{
					viewSignaturePad.Clear();
				};

				UIButton btnSubmit = new UIButton(new CGRect(130, 5, 100, 30));
				btnSubmit.SetTitle(Constants.btnSubmit, UIControlState.Normal);
				btnSubmit.SetTitleColor(UIColor.White, UIControlState.Normal);
				btnSubmit.Layer.CornerRadius = 5;
				btnSubmit.BackgroundColor = ConstantsClass.separatorClr;
				btnSubmit.Font = UIFont.FromName(Constants.strFontName, 13f);
				btnSubmit.UserInteractionEnabled = true;
				btnSubmit.TouchUpInside += async delegate
				{
                    if (!CommanUtil.IsTimeOut())
                    {
                        return;
                    }
					if (Reachability.InternetConnectionStatus())
					{
						bool result = await SubmitSignWithDetails();
					}
					else
					{
						this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
						this.View.Add(this.customAlert);
					}
				};

				viewSubmitDetails.AddSubviews(btnReset, btnSubmit);
				viewConfirmation.AddSubviews(viewTrackingDetails, viewSubmitDetails);
				scrollViewConfirmation.AddSubviews(viewTrackingDetails, viewSubmitDetails);
				scrollViewConfirmation.ContentSize = new CGSize(View.Frame.Width, viewSubmitDetails.Frame.Y + viewSubmitDetails.Frame.Height);
			}
            catch(Exception ex)
			{
                Toast.MakeText(ex.Message).SetDuration(Helper.Constants.toastDuration).Show();
			}

		}

		/// <summary>
		/// Signatures the pad.
		/// </summary>
		public void SignaturePad()
		{
			viewSignaturePad.StrokeWidth = 5f;
			viewSignaturePad.StrokeColor = UIColor.Black;
			viewSignaturePad.SignatureLineColor = UIColor.DarkGray;
			viewSignaturePad.BackgroundColor = Constants.tableRowOddColor;
			viewSignaturePad.Layer.ShadowOffset = new System.Drawing.SizeF(0, 0);
			viewSignaturePad.Layer.ShadowOpacity = 0.5f;
			viewSignaturePad.SignaturePrompt.Text = "";
			viewSignaturePad.Caption.TextColor = UIColor.White;
			viewSignaturePad.Caption.Font = UIFont.FromName(Constants.strFontName, 18f);
		}

		/// <summary>
		/// Opens the calender.
		/// </summary>
		/// <param name="type">Type.</param>
		public void DeliveryDatePicker()
		{
			try
			{

				modalPicker = new ModalPickerViewController(ModalPickerType.Date, "", this)
				{
					HeaderBackgroundColor = Constants.btnColorRed,
					HeaderTextColor = UIColor.White,
					TransitioningDelegate = new ModalPickerTransitionDelegate(),
					ModalPresentationStyle = UIModalPresentationStyle.Custom
				};

				modalPicker.DatePicker.Mode = UIDatePickerMode.Date;
				modalPicker.OnModalPickerDismissed += (s, ea) =>
				{
					var dateFormatter = new NSDateFormatter()
					{
						DateFormat = ConstantsClass.dateFormatMMDDYYYY
					};
					txtActivityDate.Text = dateFormatter.ToString(modalPicker.DatePicker.Date);
				};
				this.PresentViewController(modalPicker, true, null);
			}
			catch
			{
                Toast.MakeText(Helper.Constants.strErrorOccured).SetDuration(Helper.Constants.toastDuration).Show();
			}
		}

		/// <summary>
		/// Opens the calender.
		/// </summary>
		/// <param name="type">Type.</param>
		public void DeliveryTimePicker(UITapGestureRecognizer tapGesture)
		{
			try
			{
				modalPicker = new ModalPickerViewController(ModalPickerType.Date, "", this)
				{
					HeaderBackgroundColor = Constants.btnColorRed,
					HeaderTextColor = UIColor.White,
					TransitioningDelegate = new ModalPickerTransitionDelegate(),
					ModalPresentationStyle = UIModalPresentationStyle.Custom
				};

				modalPicker.DatePicker.Mode = UIDatePickerMode.Time;
				modalPicker.OnModalPickerDismissed += (s, ea) =>
				{
					var TimeFormatter = new NSDateFormatter()
					{
						TimeStyle = NSDateFormatterStyle.Short
					};
					if (tapGesture.View.Equals(txtActivityTime))
					{
						txtActivityTime.Text = " " + TimeFormatter.ToString(modalPicker.DatePicker.Date);
					}
					else
					{
						txtActivityTime.Text = " " + TimeFormatter.ToString(modalPicker.DatePicker.Date);
					}
				};

				this.PresentViewController(modalPicker, true, null);
			}
			catch
			{
                Toast.MakeText(Helper.Constants.strErrorOccured).SetDuration(Helper.Constants.toastDuration).Show();
			}
		}

		/// <summary>
		/// Selects the country.
		/// </summary>
		public async void BindCountry(UITapGestureRecognizer tapGesture)
		{
			try
			{
				if (Reachability.InternetConnectionStatus()) 				{
					string selectedValue = string.Empty;
					int yPosition = (int)(View.Frame.Height - 180) / 2;
					UIView pickerParentView = new UIView();
					viewPicker = new UIView(new CGRect(20, yPosition - 100, View.Frame.Width - 40, 210));
					viewPicker.BackgroundColor = UIColor.White;
					viewPicker.Layer.CornerRadius = 10;
					viewPicker.Layer.BorderWidth = 1;
					viewPicker.Layer.BorderColor = UIColor.Black.CGColor;
					pickerView = new UIPickerView(new CGRect(0, 0, viewPicker.Frame.Width, 180));
					pickerView.BackgroundColor = UIColor.White;
					pickerView.ShowSelectionIndicator = true;
					// create our simple picker model
					lstCountryDetails = await GetCountryDetails();
					if (lstCountryDetails != null)
					{
						lstCountries = new List<string>();
						foreach (CountryDetails countryDetails in lstCountryDetails)
						{
							lstCountries.Add(countryDetails.Name);
						}
					}
					pickerDataModel = new PickerDataModel(lstCountries);
					// set it on our picker class
					pickerView.Model = pickerDataModel;
					// Create a 'done' button for the toolbar and add it to the toolbar
					doneButton = new UIButton(new CGRect(0, 180, viewPicker.Frame.Width, 30));
					doneButton.BringSubviewToFront(View);
					doneButton.SetTitle(ConstantsClass.strDone, UIControlState.Normal);
					doneButton.BackgroundColor = ConstantsClass.btnColorRed;
					doneButton.Layer.CornerRadius = 10;
					doneButton.UserInteractionEnabled = true;
					viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });
					pickerDataModel.ValueChanged += (s, e) =>
					{
						selectedValue = pickerDataModel.SelectedItem;
					};
					View.Add(viewPicker);
					doneButton.TouchUpInside += (s, e) =>
					{
						pickerParentView.Hidden = true;
						pickerParentView.RemoveFromSuperview();
						pickerView.Hidden = true;
						pickerView.RemoveFromSuperview();
						doneButton.Hidden = true;
						viewPicker.Hidden = true;
						if (!string.IsNullOrEmpty(selectedValue))
						{
							txtCountry.Text = selectedValue;
							CoutryChangeEvent(selectedValue);
						}
						else
						{
							txtCountry.Text = lstCountries[0];
							CoutryChangeEvent(lstCountries[0]);
						}
					};
					viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });

					pickerParentView.Frame = View.Frame;
					pickerParentView.BackgroundColor = UIColor.Clear;
					pickerParentView.Add(viewPicker);
					View.Add(pickerParentView);
					tapGesture = new UITapGestureRecognizer(new Action(delegate
					{
						pickerParentView.Hidden = true;
						pickerParentView.RemoveFromSuperview();
						pickerView.Hidden = true;
						pickerView.RemoveFromSuperview();
						doneButton.Hidden = true;
						viewPicker.Hidden = true;
					}));
					pickerParentView.AddGestureRecognizer(tapGesture);
				} 				else 				{                     this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1); 					this.View.Add(this.customAlert); 				}
			}
			catch
			{
                Toast.MakeText(Helper.Constants.strErrorOccured).SetDuration(Helper.Constants.toastDuration).Show();
			}
		}

        /// <summary>
        /// Gets the country details.
        /// </summary>
        /// <returns>The country details.</returns>
		public async Task<List<CountryDetails>> GetCountryDetails()
		{
			try
			{
				List<CountryDetails> lstCountryDetails = null;
				//Get the service Helper Object
				ServiceHelper objServicehelper = new ServiceHelper();
				// create json object that holds the api values
				//Method Name
				string methodName = APIMethods.getCountry;
				CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
				if (loadPop == null)
				{
					loadPop = new LoadingOverlay(bounds);
				}
				View.Add(loadPop);
				//Get the Shipments
				var strResponse = await objServicehelper.GetRequest(CommanUtil.tokenNo, methodName, true);
				loadPop.Hide();
				loadPop = null;
				lstCountryDetails = new List<CountryDetails>();
				if (strResponse != null)
				{
					lstCountryDetails = (List<CountryDetails>)JsonConvert.DeserializeObject(strResponse, typeof(List<CountryDetails>));
				}
				return lstCountryDetails;
			}
			catch
			{
				return null;
			}
		}

		/// <summary>
		/// Loading Country According to current Address
		/// </summary>
		public async Task<bool> LoadCountryAndState()
		{
			try
			{
				if (Manager.LocMgr.Location != null)
				{
					await GetCurrentAddress();
				}
				else
				{
                    Toast.MakeText(Helper.Constants.strEnableTracking).SetDuration(Helper.Constants.toastDuration).Show();
				}
				txtCity.Text = city;
				txtCountry.Text = country;

				lstCountryDetails = await GetCountryDetails();
				if (lstCountryDetails != null)
				{
					lstCountries = new List<string>();
					foreach (CountryDetails countryDetails in lstCountryDetails)
					{
						lstCountries.Add(countryDetails.Name);
					}
					if (!string.IsNullOrEmpty(country))
					{
						countryName = lstCountries.Where(x => x.ToUpper().Equals(country.ToUpper())).FirstOrDefault();
					}
					if (!string.IsNullOrEmpty(countryName))
					{
						txtCountry.Text = countryName;

					}
					else
					{
						txtCountry.Text = Constants.strDefaultCountry;
					}

					if (lstCountryDetails != null && lstCountryDetails.Count > 0)
					{
						for (int indexCountry = 0; indexCountry < lstCountryDetails.Count; indexCountry++)
						{
							if (txtCountry.Text.ToUpper().Equals(Convert.ToString(lstCountryDetails[indexCountry].Name.ToUpper())))
							{
								lstStateDetails = lstCountryDetails[indexCountry].States;
							}
						}
					}
					lstStates = new List<string>();
					List<string> lstStateCodes = new List<string>();

					if (lstStateDetails != null && lstStateDetails.Count > 0)
					{
						foreach (StateDetails stateDetails in lstStateDetails)
						{
							lstStates.Add(stateDetails.Name);
							lstStateCodes.Add(stateDetails.Code);

						}
					}
					string newStateCode = string.Empty;

					if (!string.IsNullOrEmpty(state))
					{
						if (lstStates != null && lstStates.Count > 0)
						{
							stateName = lstStates.Where(x => x.ToUpper().Equals(state.ToUpper())).FirstOrDefault();
						}
						if (lstStateCodes != null && lstStateCodes.Count > 0)
						{
							newStateCode = lstStateCodes.Where(x => x.ToUpper().Equals(state.ToUpper())).FirstOrDefault();
						}
					}
					if (!string.IsNullOrEmpty(stateName))
					{
						txtState.Text = stateName;
					}
					else if (!string.IsNullOrEmpty(newStateCode))
					{
						if (lstStateDetails != null && lstStateDetails.Count > 0)
						{
							string newStateName = lstStateDetails.Where(stateDetails => stateDetails.Code.ToUpper()
																		.Equals(newStateCode.ToUpper())).FirstOrDefault().Name;

							if (!string.IsNullOrEmpty(newStateName))
							{
								txtState.Text = newStateName;
							}
							else
							{
								txtState.Text = lstStates[0];
							}

						}
					}
					else
					{
						txtState.Text = lstStates[0];
					}

					return true;
				}
				else
				{
					return false;
				}

			}
			catch
			{
				return false;
			}
		}

		/// <summary>
		/// Coutries the change event.
		/// </summary>
		/// <param name="selectedCountry">Selected country.</param>
		public void CoutryChangeEvent(string selectedCountry)
		{
			try
			{
				for (int indexCountry = 0; indexCountry < lstCountryDetails.Count; indexCountry++)
				{
					if (selectedCountry.Trim().Equals(Convert.ToString(lstCountryDetails[indexCountry].Name)))
					{
						lstStateDetails = lstCountryDetails[indexCountry].States;
					}
				}
				lstStates = new List<string>();
				foreach (StateDetails stateDetails in lstStateDetails)
				{
					lstStates.Add(stateDetails.Name);
				}
				if (lstStates != null)
				{
					txtState.Text = lstStates[0];
				}
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Selects the BindState.
		/// </summary>
		public void BindState(UITapGestureRecognizer tapGesture)
		{
			try
			{
				UIView pickerParentView = new UIView();
				string selectedValue = string.Empty;
				int yPosition = (int)(View.Frame.Height - 180) / 2;
				viewPicker = new UIView(new CGRect(20, yPosition - 100, View.Frame.Width - 40, 210));
				viewPicker.BackgroundColor = UIColor.White;
				viewPicker.Layer.CornerRadius = 10;
				viewPicker.Layer.BorderWidth = 1;
				viewPicker.Layer.BorderColor = UIColor.Black.CGColor;
				pickerView = new UIPickerView(new CGRect(0, 0, viewPicker.Frame.Width, 180));
				pickerView.BackgroundColor = UIColor.White;
				pickerView.ShowSelectionIndicator = true;
				pickerDataModel = new PickerDataModel(lstStates);
				// set it on our picker class
				pickerView.Model = pickerDataModel;
				// Create a 'done' button for the toolbar and add it to the toolbar
				doneButton = new UIButton(new CGRect(0, 180, viewPicker.Frame.Width, 30));
				doneButton.BringSubviewToFront(View);
				doneButton.SetTitle(ConstantsClass.strDone, UIControlState.Normal);
				doneButton.BackgroundColor = ConstantsClass.btnColorRed;
				doneButton.Layer.CornerRadius = 10;
				doneButton.UserInteractionEnabled = true;
				viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });
				pickerDataModel.ValueChanged += (s, e) =>
				{
					selectedValue = pickerDataModel.SelectedItem;
				};

				//selectedValue = pickerDataModel.SelectedItem;
				View.Add(viewPicker);
				doneButton.TouchUpInside += (s, e) =>
				{
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
					if (!string.IsNullOrEmpty(selectedValue))
					{
						txtState.Text = selectedValue;
					}
					else
					{
						txtState.Text = lstStates[0];
					}

				};
				viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });
				pickerParentView.Frame = View.Frame;
				pickerParentView.BackgroundColor = UIColor.Clear;
				pickerParentView.Add(viewPicker);
				View.Add(pickerParentView);
				tapGesture = new UITapGestureRecognizer(new Action(delegate
				{
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
				}));
				pickerParentView.AddGestureRecognizer(tapGesture);
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Checks the track details.
		/// </summary>
		/// <param name="btnCheckRate">Button check rate.</param>
		public async void CheckTrackDetails(UIButton btnCheckRate)
		{
			try
			{
                if (!CommanUtil.IsTimeOut())
                {
                    return;
                }
				if (!chkTrackDetails)
				{
					chkTrackDetails = true;
					await LoadTrackingView(btnCheckRate);
				}
				else
				{
					btnCheckRate.SetBackgroundImage(null, UIControlState.Normal);
					chkTrackDetails = false;
					CreateConfirmationView();
				}
				if (loadPop != null)
				{
					loadPop.Hide();
					loadPop = null;
				}
			}
			catch
			{
				if (loadPop != null)
				{
					loadPop.Hide();
					loadPop = null;

				}
			}
		}

		public async Task LoadTrackingView(UIButton btnCheckRate)
		{
            try
            {
                if (loadPop == null)
                {
                    loadPop = new LoadingOverlay(View.Bounds);
                }
                View.Add(loadPop);

                btnCheckRate.SetBackgroundImage(new UIImage("Images/CheckMark.png"), UIControlState.Normal);
                CreateConfirmationView();
                //GetCurrentAddress();
                if (txtCity != null && chkTrackDetails)
                {
                    if (compositeKey.Split('#')[0].ToUpper() == Constants.strPickup.ToUpper())
                    {
                        ConfType = Constants.pickup;
                        //txtDescription.Text = Constants.strPickup;
                        txtDescription.Text = trackingStatus[lstTrackingDesc[1].value];

                    }
                    else
                    {
                        ConfType = Constants.strdelivery;
                        //txtDescription.Text = Constants.strDeliveryConf;
                        txtDescription.Text = trackingStatus[lstTrackingDesc[2].value];
                    }
                }
                await LoadCountryAndState();
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
            }
		}
		/// <summary>
		/// Manages the navigation.
		/// </summary>
		/// <param name="tapGesture">Tap gesture.</param>
		private void ManageNavigation(UITapGestureRecognizer tapGesture)
		{
			try
			{
				if (tapGesture.View.Equals(imgBack))
				{
					this.NavigationController.PopViewController(true);
				}
			}
			catch
			{
                Toast.MakeText(Helper.Constants.strErrorOccured).SetDuration(Helper.Constants.toastDuration).Show();
			}
		}


		/// <summary>
		/// Gets the signature.
		/// </summary>
		private async Task<bool> GetSignature()
		{
            bool result = false;
			try
			{
				if (!viewSignaturePad.IsBlank)
				{
					var imgSignature = await viewSignaturePad.GetImageStreamAsync(SignatureImageFormat.Png, UIColor.Black, UIColor.White);
					if (imgSignature != null)
					{
						var signatureMemoryStream = new MemoryStream();
						imgSignature.CopyTo(signatureMemoryStream);
						byte[] data = signatureMemoryStream.ToArray();
						strBase64String = Convert.ToBase64String(data);
                        return true;
					}
					else
					{
						return result;
					}
				}
				else
				{
					return result;
				}
			}
			catch
			{
                return result;
			}
		}


		/// <summary>
		/// Submit Sign With Details
		/// </summary>
		private async Task<bool> SubmitSignWithDetails()
		{
			try
			{
				CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;

				if (loadPop != null)
				{
					loadPop = null;
					loadPop = new LoadingOverlay(bounds);
				}
				else
				{
					loadPop = new LoadingOverlay(bounds);
				}
                //if (string.IsNullOrEmpty(strBase64String))
                //{
                //    Toast.MakeText(Constants.enterSignature).SetDuration(Constants.toastDuration).Show();
                //    return false;
                //}

				View.Add(loadPop);
				ServiceHelper objServiceHelper = new ServiceHelper();
				string response = string.Empty;
				string methodURI = APIMethods.shipmentDetails + "/" + shipmentID + "/" + APIMethods.signature;
				string token = CommanUtil.tokenNo;
				bool result = await GetSignature(); //Get The signature Image
                if (!result)
                {
                    loadPop.Hide();
                    loadPop = null;
                    Toast.MakeText(Constants.enterSignature).SetDuration(Constants.toastDuration).Show();
                    return false;
                }
                if (string.IsNullOrEmpty(txtCity.Text))
                {
                    loadPop.Hide();
                    loadPop = null;
                    Toast.MakeText(Constants.enterCity).SetDuration(Constants.toastDuration).Show();
                    return false;
                }

                //else
                //{
					if (!string.IsNullOrEmpty(GetTrackingPayload()))
					{
						payloadReturn = GetTrackingPayload();
					}
					else
					{
						payloadReturn = "{" + "}";
					}
					postDataJson = "{"
					+ "\"Signature64\":" + "\"" + strBase64String + "\","
					+ "\"SignatureImageType\":" + "\"png\","
					+ "\"SignatureType\":" + "\"" + ConfType + "\","
					+ "\"Tracking\":" + payloadReturn
					+ "}";
					response = await objServiceHelper.PostRequestJson(postDataJson, methodURI, token, true);
					if (!string.IsNullOrEmpty(response))
					{
						if (response.Replace("\"", " ").Trim() == Constants.strSuccess)
						{
							//new UIAlertView(Constants.strSignature, Constants.strSuccess, null, Constants.btnTextOk, null).Show();
							viewSignaturePad.Clear();
							strBase64String = string.Empty;
							loadPop.Hide();
							loadPop = null;
							this.NavigationController.PopViewController(true);
						}
						else
						{
							jobject = JObject.Parse(response);
							string message = Convert.ToString(jobject[Constants.strErrorMessage]);
							await Util.ErrorLog(message, message, CommanUtil.tokenNo);
							new UIAlertView(Constants.strSignature, message, null, Constants.btnTextOk, null).Show();
							viewSignaturePad.Clear();
							loadPop.Hide();
							loadPop = null;
						}
					}
					else
					{
						//new UIAlertView(Constants.strSignature, Constants.strNoSignature, null, Constants.btnTextOk, null).Show();
						viewSignaturePad.Clear();
						loadPop.Hide();
						loadPop = null;
					}
					return true;
				//}
				//else
				//{
    //                loadPop.Hide();
    //                loadPop = null;
    //                Toast.MakeText(Constants.enterSignature).SetDuration(Constants.toastDuration).Show();
				//	return false;
				//}

			}
			catch
			{
                loadPop.Hide();
                loadPop = null;
				return false;
			}
		}

		/// <summary>
		/// Preparing payload for hitting API
		/// </summary>
		public string GetTrackingPayload()
		{
			try
			{
				activityDate = new string[2];
				GetCountryStateCode();
				if (!string.IsNullOrEmpty(txtActivityDate.Text))
				{
                    ActivityDate = Convert.ToDateTime(txtActivityDate.Text).ToString(ConstantsClass.dateFormatMMDDYYYY);
					activityDate = CommanUtil.FormatDate(ActivityDate);
					newActivityDate = activityDate[2] + "-" + activityDate[0] + "-" + activityDate[1];
				}
				if (!string.IsNullOrEmpty(txtActivityTime.Text))
				{
					if ((txtActivityTime.Text.Contains("AM")))
					{
						activityTime = txtActivityTime.Text.Replace("AM", "").Trim();
					}
					if ((txtActivityTime.Text.Contains("PM")))
					{
						activityTime = txtActivityTime.Text.Replace("PM", "").Trim();
					}
				}

				payload_str = "{"
				+ "\"ProNumber\":" + "\"" + txtProNumber.Text + "\","
				+ "\"ActivityDate\":" + "\"" + newActivityDate + " " + activityTime + "\","
				+ "\"ActivityCode\":" + "\"" + lstTrackingDesc[descriptionIndex].value + "\","
				+ "\"ActivityDescr\":" + "\"" + Convert.ToString(txtDescription.Text.Trim()) + "\","
				+ "\"City\":" + "\"" + txtCity.Text.Trim() + "\","
				+ "\"State\":" + "\"" + stateCode + "\","
				+ "\"Country\":" + "\"" + countryCode + "\""
				+
				"}";

				return payload_str;
			}
			catch
			{
				return null;
			}
		}

		/// <summary>
		/// Gets Country Code and State Code.
		/// </summary>
		public void GetCountryStateCode()
		{
			try
			{
				for (int indexCountry = 0; indexCountry < lstCountryDetails.Count; indexCountry++)
				{
					if (txtCountry.Text.Trim().Equals(Convert.ToString(lstCountryDetails[indexCountry].Name)))
					{
						countryCode = lstCountryDetails[indexCountry].Code;
						var stateDetail = lstCountryDetails[indexCountry].States.Where(s => s.Name == txtState.Text.Trim()).FirstOrDefault();
						stateCode = stateDetail.Code;
					}
				}
			}
			catch
			{
				throw;
			}
		}

	}
}