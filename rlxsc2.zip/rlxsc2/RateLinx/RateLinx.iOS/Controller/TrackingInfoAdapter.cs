using System;
using CoreGraphics;
using Foundation;
using UIKit;
using System.Collections.Generic;
using RateLinx.Models;

namespace RateLinx.iOS
{
	class TrackingInfoAdapter : UITableViewSource
	{
		List<TrackDetail> lstTrackDetail = null;
		TrackingInfoController trackingInfoController;
		public TrackingInfoAdapter(List<TrackDetail> lstTrackDetails,TrackingInfoController objTrackingInfoController)
		{
			this.trackingInfoController = objTrackingInfoController;
			this.lstTrackDetail = lstTrackDetails;
		}

		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			UIColor altColor = null;
			if (indexPath.Row % 2 == 0)
			{
				altColor = UIColor.FromRGB(224, 223, 223);
			}
			else
			{
				altColor = UIColor.LightGray;
			}
			UITableViewCell cellTrackingInfo = new UITableViewCell(new CGRect(0, 0, tableView.Frame.Width, 30));
			//cellTrackingInfo.BackgroundColor = altColor;

			nfloat labelWidth = (tableView.Frame.Width - 4) / 5;


			UILabel lblActivity = new UILabel(new CGRect(0, 0, labelWidth, 30));
			lblActivity.TextColor = UIColor.Black;
			lblActivity.BackgroundColor = altColor;
			lblActivity.TextAlignment = UITextAlignment.Center;
			lblActivity.Lines = 0;
			lblActivity.Text = lstTrackDetail[indexPath.Row].Activity;
			lblActivity.Font = UIFont.FromName("Century Gothic", 10f);

			UILabel lblCity = new UILabel(new CGRect(labelWidth + 1, 0, labelWidth, 30));
			lblCity.TextColor = UIColor.Black;
			lblCity.BackgroundColor = altColor;
			lblCity.TextAlignment = UITextAlignment.Center;
			lblCity.Lines = 0;
			lblCity.Text = lstTrackDetail[indexPath.Row].City;
			lblCity.Font = UIFont.FromName("Century Gothic", 10f);

			UILabel lblState = new UILabel(new CGRect(labelWidth * 2 + 2, 0, labelWidth, 30));
			lblState.TextColor = UIColor.Black;
			lblState.BackgroundColor = altColor;
			lblState.TextAlignment = UITextAlignment.Center;
			lblState.Lines = 0;
			lblState.Text = lstTrackDetail[indexPath.Row].State;
			lblState.Font = UIFont.FromName("Century Gothic", 10f);

			UILabel lblCountry = new UILabel(new CGRect(labelWidth * 3 + 3, 0, labelWidth, 30));
			lblCountry.TextColor = UIColor.Black;
			lblCountry.BackgroundColor = altColor;
			lblCountry.TextAlignment = UITextAlignment.Center;
			lblCountry.Lines = 0;
			lblCountry.Text = lstTrackDetail[indexPath.Row].Country;
			lblCountry.Font = UIFont.FromName("Century Gothic", 10f);

			UILabel lblDescription = new UILabel(new CGRect(labelWidth * 4 + 4, 0, labelWidth, 30));
			lblDescription.TextColor = UIColor.Black;
			lblDescription.BackgroundColor = altColor;
			lblDescription.TextAlignment = UITextAlignment.Center;
			lblDescription.Lines = 0;
			lblDescription.Text = lstTrackDetail[indexPath.Row].ActivityDescr;
			lblDescription.Font = UIFont.FromName("Century Gothic", 10f);



			cellTrackingInfo.AddSubviews(lblActivity, lblCity, lblState, lblCountry, lblDescription);
			return cellTrackingInfo;

		}

		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return lstTrackDetail.Count;
		}
		public override nfloat GetHeightForRow(UITableView tableView, NSIndexPath indexPath)
		{
			return 30;
		}
	}
}