using Foundation;
using System;
using UIKit;
using RateLinx.Models;
using System.Collections;
using Google.Maps;
using PubnubApi;
using System.Collections.Generic;
using RateLinx.GoogleServices;
using CoreLocation;
using Newtonsoft.Json;
using CoreGraphics;
using System.Threading.Tasks;
using System.Net;
using System.Threading;
using RateLinx.Helper;
using System.Text;

namespace RateLinx.iOS
{
	public partial class RealTimeTrackingController : UIViewController
	{

		#region variables declaration
		MapView mapView;
		public RecentShipments objRecentShipments;
		string originAddress, shipToAddress = string.Empty;
		SubscribeCallbackExt listener;
		static public Pubnub pubnub;
		PNConfiguration config;
		//bool isTrackingEnable = false;
		string channel = string.Empty;
		string channelGroup
		{
			get;
			set;
		}
		float currentZoomLevel = 17;
		//int hours = 0;
		//int minutes = 0;
		//int seconds = 0;
		//int count = 0;
		//decimal totalDistance = 0;
		//string city = string.Empty;
		//string state = string.Empty;
		//string country = string.Empty;
		List<ShipmentActivity> lstShipmentActivity = null;
        //Dictionary<string, string> trackingStatus = null; //shipmentStatus, nodeAPIStatus = null;
		//GeoCodeJSONClass objGeoCodeJSONClass;
		public string addressKey;
		string strSource = string.Empty;
		string strDestination = string.Empty;
		//string strGeoCodeURL = string.Empty;
		string strHttpResponse = string.Empty;
		MutablePath path = new MutablePath();
		//Code snippet to mark source and destination points
		Location SourceLocation { get; set; }
		Location DestinationLocation { get; set; }
		CLLocationCoordinate2D prevCoordinate = new CLLocationCoordinate2D();
		Marker marker3 = null;
		//CLLocation currLocation = null;
		//string address1 = "Chetu A-186/187, A Block, Sector 63, A Block, Sector 63, Noida, Uttar Pradesh 201301";
		//string address2 = "Logix Infotech Park, Plot No: D - 5, Sector 59 D Block, Sector 59 Noida";
        string shipmentStatusValue = string.Empty;//statusCode
		//public CLLocation location = null;
		protected CLLocationManager locMgr;
		//public event EventHandler<LocationUpdatedEventArgs> LocationUpdated = delegate { };
		//int statuscount = 0;status
		LoadingOverlay loadPop;
		bool isAnimateCamera = true;
		UIView viewShowHide = new UIView();
		#endregion


		public class LocalLog : IPubnubLog
		{
			void IPubnubLog.WriteToLog(string logText)
			{
				System.Diagnostics.Debug.WriteLine(logText);

			}
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.RealTimeTrackingController"/> class.
		/// </summary>
		/// <param name="handle">Handle.</param>
		public RealTimeTrackingController(IntPtr handle) : base(handle)
		{
            //shipmentStatus = CommanUtil.ShipmentCurrentStatus();
            //nodeAPIStatus = CommanUtil.NodeAPIStatus();
            //trackingStatus = CommanUtil.TrackingStatus();
		}

		/// <summary>
		/// Views the did load.
		/// </summary>
		public override void ViewDidLoad()
		{
			try
			{
				base.ViewDidLoad();

				viewShowHide.Frame = View.Bounds;
				viewShowHide.BackgroundColor = UIColor.White;
				View.AddSubview(viewShowHide);

				originAddress = objRecentShipments.OriginCompany + " "
							+ objRecentShipments.OriginAddress1 + " "
							+ objRecentShipments.OriginAddress2 + " "
							+ objRecentShipments.OriginCity + ", "
							+ objRecentShipments.OriginState + " " + objRecentShipments.OriginZip;

				shipToAddress = objRecentShipments.ShipToCity + ", " + objRecentShipments.ShipToState + " " + objRecentShipments.ShipToZip;
				strDestination = shipToAddress;//address2;
                strSource = originAddress;
				txtSourceAddress.Text = originAddress;
				txtDestinationAddress.Text = shipToAddress;
				lblCopyRight.Text = Util.GetCopyRight();
				channel = objRecentShipments.ClientID + objRecentShipments.BolNum;
                DrawMap(strSource, strDestination); //Draw map on page
				#region  pub nub settings and callback functionality
				PubNubAccountSetting();
				listener = new SubscribeCallbackExt(
								(o, m) =>
								{
									//Publisher Response
									if (m != null)
									{
										//Display(pubnub.JsonPluggableLibrary.SerializeToJsonString(m.Message));
										var demo = pubnub.JsonPluggableLibrary.SerializeToJsonString(m.Message);
										ShipmentStatus objShipmentStatus = JsonConvert.DeserializeObject<ShipmentStatus>(demo);
										// DriverStatus objDriverStatus 
										GetDirectionResponseAsync(objShipmentStatus);
									}
								},
								(o, p) =>
								{
									//Subscriber join or not 
									if (p != null)
									{
										//Display(p.Event);
									}
								},
								(o, s) =>
								{
									//status code of subscriber
									if (s != null)
									{
										//Display(s.Category + " " + s.Operation + " " + s.StatusCode);
									}
								}
								);

				#endregion
			}
			catch
			{
				Console.WriteLine(Helper.Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Draws the map.
		/// </summary>
		/// <param name="originAdd">Origin add.</param>
		/// <param name="destinationAdd">Destination add.</param>
		public async void DrawMap(string originAdd, string destinationAdd)
		{
			try
			{
				CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
				if (loadPop == null)
				{
					loadPop = new LoadingOverlay(bounds);
				}
				View.Add(loadPop);
				//Get Lat and Long from Address
				await GeocodeToConsoleAsync(originAdd, destinationAdd);

				var camera = CameraPosition.FromCamera(latitude: SourceLocation.lat,
					   longitude: SourceLocation.lng,
					   zoom: 14);
				mapView = MapView.FromCamera(CGRect.Empty, camera);
				//mapView.MyLocationEnabled = true;
				//Sourec
				CLLocationCoordinate2D coord1 = new CLLocationCoordinate2D(SourceLocation.lat, SourceLocation.lng);
				var marker1 = Marker.FromPosition(coord1);
				marker1.Title = string.Format(strSource);
				marker1.Icon = UIImage.FromBundle("Images/MarkerSource.png");
				marker1.Map = mapView;
				//Destination
				CLLocationCoordinate2D coord2 = new CLLocationCoordinate2D(DestinationLocation.lat, DestinationLocation.lng);
				var marker2 = Marker.FromPosition(coord2);
				marker2.Title = string.Format(strDestination);
				marker2.Icon = UIImage.FromBundle("Images/MarkerDest.png");
				marker2.Map = mapView;
				mapView.Frame = viewMapControl.Bounds;
				//View = mapView;
				mapView.Settings.MyLocationButton = true;
				mapView.DidTapMyLocationButton = TapMyLocationButton();
				viewMapControl.AddSubview(mapView);
				await GetShipmentStatusAsync();
				loadPop.Hide();
			}
			catch(Exception ex)
			{
				Console.WriteLine(ex.Message);
				loadPop.Hide();
			}
			viewShowHide.Hidden = true;
			viewShowHide.RemoveFromSuperview();
		}

		/// <summary>
		/// Gets the current location.
		/// </summary>
		/// <returns><c>true</c>, if current location was gotten, <c>false</c> otherwise.</returns>
		public bool GetCurrentLocation()
		{
			try
			{
				isAnimateCamera = true;
				return true;
			}
			catch
			{
				return false;
			}
		}

		/// <summary>
		/// Taps my location button.
		/// </summary>
		/// <returns>The my location button.</returns>
		public GMSDidTapMyLocation TapMyLocationButton()
		{
			try
			{
				GMSDidTapMyLocation objGMSDidTapMyLocation = new GMSDidTapMyLocation((MapView mapView) => GetCurrentLocation());
				return objGMSDidTapMyLocation;
			}
			catch
			{
				return null;
			}
		}

		/// <summary>
		/// Geocodes to console async.
		/// </summary>
		/// <returns>The to console async.</returns>
		/// <param name="originAdd">Origin address.</param>
		/// <param name="destinationAdd">Destination address.</param>
		private async Task GeocodeToConsoleAsync(string originAdd, string destinationAdd)
		{
			try
			{
				CLLocation originCLlocation = new CLLocation();
				CLLocation destinationCLlocation = new CLLocation();
				var geocoder = new CLGeocoder();
				var placeMarkOrigin = geocoder.GeocodeAddressAsync(originAdd);
				await placeMarkOrigin.ContinueWith((addresses) =>
								{
									foreach (var address in addresses.Result)
									{
										originCLlocation = address.Location;
									}
								});

				if (originCLlocation != null)
				{
					SourceLocation = new Location() { lat = originCLlocation.Coordinate.Latitude, lng = originCLlocation.Coordinate.Longitude };
				}
				var placeMarkDest = geocoder.GeocodeAddressAsync(destinationAdd);
				await placeMarkDest.ContinueWith((addresses) =>
								{
									foreach (var address in addresses.Result)
									{
										destinationCLlocation = address.Location;
									}
								});
				if (destinationCLlocation != null)
				{
					DestinationLocation = new Location() { lat = destinationCLlocation.Coordinate.Latitude, lng = destinationCLlocation.Coordinate.Longitude };
				}
				originCLlocation=null;
				destinationCLlocation = null;
			}
			catch
			{
				Console.WriteLine(Helper.Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Fns the http request.
		/// </summary>
		/// <returns>The http request.</returns>
		/// <param name="strURL">String URL.</param>
		public async Task<string> FnHttpRequest(string strURL)
		{
			try
			{
				WebClient client = new WebClient();
				string strResult;
				try
				{
					strResult = await client.DownloadStringTaskAsync(new Uri(strURL));
				}
				catch
				{
					strResult = NSBundle.MainBundle.GetLocalizedString("exception", null);
				}
				finally
				{
					client.Dispose();
					client = null;
				}
				return strResult;
			}
			catch
			{
				Console.WriteLine(Helper.Constants.strErrorOccured);
				return null;
			}
		}

		/// <summary>
		/// Pubs the nub account setting.
		/// </summary>
		public void PubNubAccountSetting()
		{
			try
			{
				config = new PNConfiguration();
				config.SubscribeKey = Helper.Constants.pubnubSubscribeKey;
				config.PublishKey = Helper.Constants.pubnubPublishKey;
				//config.Secure = true;
				config.PubnubLog = new LocalLog();
				config.LogVerbosity = PNLogVerbosity.BODY;
				config.ReconnectionPolicy = PNReconnectionPolicy.LINEAR;
				pubnub = new Pubnub(config);
				Subscribe(channel); //Susbriber for him/her self   
			}
			catch
			{
				Console.WriteLine(Helper.Constants.strErrorOccured);

			}
		}

		public override void ViewDidAppear(bool animated)
		{
			base.ViewDidAppear(animated);
			if (mapView == null)
				mapView = new MapView();
			mapView.Frame = viewMapControl.Bounds;
			viewMapControl.AddSubview(mapView);
		}
		public override void DidRotate(UIInterfaceOrientation fromInterfaceOrientation)
		{
			base.DidRotate(fromInterfaceOrientation);

			mapView.Frame = viewMapControl.Bounds;
			viewMapControl.AddSubview(mapView);

		}

        /// <summary>
        /// Get status of current Shipment
        /// </summary>
        /// <returns></returns>
        async Task GetShipmentStatusAsync()
        {
            try
            {
                //Check the status of shipment
                lstShipmentActivity = await Util.GetRealtimeShipmentStatus(objRecentShipments.ClientID + "/" + objRecentShipments.BolNum);
                if (lstShipmentActivity != null && lstShipmentActivity.Count > 0)
                {
                    CLLocationCoordinate2D currentLatLong = new CLLocationCoordinate2D(Convert.ToDouble(lstShipmentActivity[lstShipmentActivity.Count - 1].Lat), Convert.ToDouble(lstShipmentActivity[lstShipmentActivity.Count - 1].Long));
                    txtCurrentLocation.Text = await GetCurrentAddress(currentLatLong);
                    if (lstShipmentActivity[lstShipmentActivity.Count - 1].Status == Helper.Constants.inTransitkey)
                    {
                        txtShipmentStatus.Text = lstShipmentActivity[lstShipmentActivity.Count - 1].Msg;
                    }
                    else if (lstShipmentActivity[lstShipmentActivity.Count - 1].Status == Helper.Constants.loadingkey)
                    {
                        txtShipmentStatus.Text = lstShipmentActivity[lstShipmentActivity.Count - 1].Msg;
                    }
                    else if (lstShipmentActivity[lstShipmentActivity.Count - 1].Status == Helper.Constants.enRoutekey)
                    {
                        txtShipmentStatus.Text = lstShipmentActivity[lstShipmentActivity.Count - 1].Msg;
                    }
                    else if (lstShipmentActivity[lstShipmentActivity.Count - 1].Status == Helper.Constants.arrivedkey)
                    {
                        txtShipmentStatus.Text = lstShipmentActivity[lstShipmentActivity.Count - 1].Msg;
                    }
                    else if (lstShipmentActivity[lstShipmentActivity.Count - 1].Status == Helper.Constants.completedkey)
                    {
                        txtShipmentStatus.Text = lstShipmentActivity[lstShipmentActivity.Count - 1].Msg;
                        txtDistanceLeft.Text = Helper.Constants.zeroMiles;
                        CLLocation pointB = new CLLocation(DestinationLocation.lat, DestinationLocation.lng);
                        CLLocation pointA = new CLLocation(SourceLocation.lat, SourceLocation.lng);
                        decimal distBtwDestCurrent = Util.GetDistance(pointB, pointA);
                        txtDistanceTravelled.Text = distBtwDestCurrent.ToString() + Helper.Constants.mile;
                        double shipmentStartTime = lstShipmentActivity[0].Time;
                        double shipmentEndTime = lstShipmentActivity[lstShipmentActivity.Count - 1].Time;
                        DateTime dateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0);
                        TimeSpan startTime = dateTime.AddSeconds(shipmentStartTime).TimeOfDay;
                        TimeSpan endTime = dateTime.AddSeconds(shipmentEndTime).TimeOfDay;

                        TimeSpan totalTimeTaken = endTime.Subtract(startTime);

                        txtTimeTaken.Text = totalTimeTaken.ToString().Contains("-") ?
                            totalTimeTaken.ToString().Replace('-', ' ') : totalTimeTaken.ToString();
                    }
                    //               else if (lstShipmentActivity[lstShipmentActivity.Count - 1].Status == trackingStatus["SC"])
                    //{
                    //                   txtShipmentStatus.Text = trackingStatus["SC"];
                    //	txtDistanceLeft.Text = Helper.Constants.zeroMiles;
                    //	CLLocation pointB = new CLLocation(DestinationLocation.lat, DestinationLocation.lng);
                    //	CLLocation pointA = new CLLocation(SourceLocation.lat, SourceLocation.lng);
                    //	decimal distBtwDestCurrent = Util.GetDistance(pointB, pointA);
                    //	txtDistanceTravelled.Text = distBtwDestCurrent.ToString() + Helper.Constants.mile;
                    //	double shipmentStartTime = lstShipmentActivity[0].Time;
                    //	double shipmentEndTime = lstShipmentActivity[lstShipmentActivity.Count - 1].Time;
                    //	DateTime dateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0);
                    //	TimeSpan startTime = dateTime.AddSeconds(shipmentStartTime).TimeOfDay;
                    //	TimeSpan endTime = dateTime.AddSeconds(shipmentEndTime).TimeOfDay;

                    //	TimeSpan totalTimeTaken = endTime.Subtract(startTime);

                    //	txtTimeTaken.Text = totalTimeTaken.ToString().Contains("-")?
                    //		totalTimeTaken.ToString().Replace('-', ' ') : totalTimeTaken.ToString();
                    //}
                    //}
                    else
                    {
                        txtCurrentLocation.Text = originAddress;
                        txtDistanceTravelled.Text = Helper.Constants.zeroMiles;
                        CLLocation pointB = new CLLocation(DestinationLocation.lat, DestinationLocation.lng);
                        CLLocation pointA = new CLLocation(SourceLocation.lat, SourceLocation.lng);
                        decimal distBtwDestCurrent = Util.GetDistance(pointB, pointA);
                        txtDistanceLeft.Text = distBtwDestCurrent.ToString() + Helper.Constants.mile;
                        txtTimeTaken.Text = Helper.Constants.zeroMinutes;
                        txtShipmentStatus.Text = Helper.Constants.shippingNotStart;
                    }
                }
                else
                {
                    txtShipmentStatus.Text = Helper.Constants.shippingNotStart;
                }
            }
            catch
            {
                Console.WriteLine(Helper.Constants.strErrorOccured);
            }
        }

		public override UIInterfaceOrientationMask GetSupportedInterfaceOrientations()
		{
			return UIInterfaceOrientationMask.Portrait;
		}
		public override UIInterfaceOrientation PreferredInterfaceOrientationForPresentation()
		{
			return UIInterfaceOrientation.Portrait;
		}

		public override bool ShouldAutorotate()
		{
			return base.ShouldAutorotate();
		}

		/// <summary>
		/// Gets the direction response async.
		/// </summary>
		/// <returns>The direction response async.</returns>
		/// <param name="objShipmentStatus">Object shipment status.</param>
		public void GetDirectionResponseAsync(ShipmentStatus objShipmentStatus)
		{
			try
			{
				CLLocationCoordinate2D currentCoordinate = new CLLocationCoordinate2D(Convert.ToDouble(objShipmentStatus.CurrentLat), Convert.ToDouble(objShipmentStatus.CurrentLong));
				if (mapView != null && (int)currentCoordinate.Latitude != 0)
				{
					BeginInvokeOnMainThread(new Action(delegate
					{
						//var bearing = currentCoordinate.
						if ((int)prevCoordinate.Latitude == 0)
						{
							prevCoordinate = currentCoordinate;
						}
						if ((int)currentCoordinate.Latitude != 0 && (int)currentCoordinate.Longitude != 0)
						{
							txtShipmentStatus.Text = objShipmentStatus.ShipmentCurrStatus;
							txtCurrentLocation.Text = objShipmentStatus.CurrentLocation;
                            txtDistanceLeft.Text = objShipmentStatus.DistanceLeft + Helper.Constants.mile;
                            txtDistanceTravelled.Text = objShipmentStatus.DistanceTravelled + Helper.Constants.mile;
							txtTimeTaken.Text = objShipmentStatus.TimeTaken;
							float bearing = Util.BearingBetweenLocation(prevCoordinate, currentCoordinate);
							if (float.IsNaN(bearing) || (int)bearing == 0)
							{
								bearing = 180;
							}
							if (marker3 != null)
							{
								//mapView.Clear();
								//marker3.Map = null;
								////marker3 = new Marker();
								////marker3.AppearAnimation = MarkerAnimation.Pop;
								//marker3 = Marker.FromPosition(currentCoordinate);
								//if (!string.IsNullOrEmpty(objShipmentStatus.CurrentLocation))
								//{
								//	marker3.Title = string.Format(objShipmentStatus.CurrentLocation);
								//}
								//else
								//{
								//	marker3.Title = string.Empty;
								//}
								//marker3.Icon = UIImage.FromBundle("Images/CarTopView2.png");
								////marker3.Draggable = true;
								//marker3.Rotation = bearing;
								//marker3.Flat = true;
								//marker3.GroundAnchor = new CGPoint(0.5f, 0.5f);
								//marker3.Map = mapView;
								//marker3.Position = currentCoordinate;
								//marker3.Rotation = bearing;
								//marker3.Flat = true;
								//marker3.GroundAnchor = new CGPoint(0.5f, 0.5f);
                                AnimateMarker(prevCoordinate, currentCoordinate, bearing);
							}
							else
							{
								marker3 = new Marker();
								marker3 = Marker.FromPosition(currentCoordinate);
								if (!string.IsNullOrEmpty(objShipmentStatus.CurrentLocation))
								{
									marker3.Title = string.Format(objShipmentStatus.CurrentLocation);
								}
								else
								{
									marker3.Title = string.Empty;
								}

								marker3.Icon = UIImage.FromBundle("Images/CarTopView2.png");
								//marker3.Draggable = true;
								marker3.Rotation = bearing;
								marker3.Flat = true;
								marker3.GroundAnchor = new CGPoint(0.5f, 0.5f);
								marker3.Map = mapView;
							}
							//Draw line by connecting polyline points
							//GoogleDirectionClass obGoogleDirectionClass = await DrawLineBtwAddress(currentCoordinate, prevCoordinate);
							////Path[] pathhs = new Path[2];
							//////available routes may be more then one
							//if (obGoogleDirectionClass != null && obGoogleDirectionClass.routes.Count > 0)
							//{
							//	Path pathPoly = new MutablePath();
							//	pathPoly.PathOffsetByLatitude(prevCoordinate.Latitude, prevCoordinate.Longitude);
							//	pathPoly.PathOffsetByLatitude(currentCoordinate.Latitude, currentCoordinate.Longitude);
							//	//var path = Google.Maps.Path.FromEncodedPath(obGoogleDirectionClass.routes[0].overview_polyline.points);
							//	var line = Google.Maps.Polyline.FromPath(pathPoly);
							//	line.StrokeWidth = 4f;
							//	line.StrokeColor = UIColor.Blue;
							//	line.Geodesic = true; //more curved path
							//	line.Map = mapView;
							//}
							//path.AddCoordinate(prevCoordinate);
							//path.AddCoordinate(currentCoordinate);
							//Google.Maps.Polyline line = Google.Maps.Polyline.FromPath(path);
							//line.StrokeWidth = 1f;
							//line.StrokeColor = UIColor.Black;
							//line.Geodesic = true; //more curved path
							//line.Map = mapView;
							//Set camera position
							var camera = CameraPosition.FromCamera(currentCoordinate.Latitude,
												   currentCoordinate.Longitude,
												   currentZoomLevel);
							//mapView.Camera = camera;
							if (isAnimateCamera)
							{
								mapView.Animate(camera);
							}
							//Assign Old Latitude and Longitude
							prevCoordinate = currentCoordinate;
							//lblMiles.Text = objShipmentStatus.DistanceTravelled + " Miles"; //GetDistance(StartLatLong, currentLatLang) + " Miles";//Calculate time
							//lblTotalTime.Text = objShipmentStatus.TimeTaken; // RunTimer(); //calculate time
							//Camera change event 
							mapView.CameraPositionChanged += HandleChangedCameraPosition;
						}
					}));

				}
			}
			catch (Exception ex)
			{
				Console.Write(ex.Message);
			}
		}

        /// <summary>
        /// Animates the marker.
        /// </summary>
        /// <param name="marker">Marker.</param>
        /// <param name="currentLatLong">Current lat long.</param>
        /// <param name="rotation">Rotation.</param>
        public void AnimateMarker(CLLocationCoordinate2D marker, CLLocationCoordinate2D currentLatLong, float rotation)
        {
            try
            {
                float start = 1000 * ((float)NSProcessInfo.ProcessInfo.SystemUptime);
                NSTimer.InvokeInBackground(Run);
                void Run()
                {
                    float elapsed = ((float)NSProcessInfo.ProcessInfo.SystemUptime) * 1000 - start;
                    float t = elapsed / 600;
                    double lng = t * currentLatLong.Longitude + (1 - t)
                                                   * marker.Longitude;
                    double lat = t * currentLatLong.Latitude + (1 - t)
                                                   * marker.Latitude;

                    BeginInvokeOnMainThread(new Action(delegate
                    {
                        if (marker3 != null)
                        {
                            marker3.Map = null;
                        }
                        CLLocationCoordinate2D CurrPOS = new CLLocationCoordinate2D(lat, lng);
                        marker3 = Marker.FromPosition(CurrPOS);
                        marker3.Icon = UIImage.FromBundle("Images/CarTopView2.png");
                        //marker3.Draggable = true;
                        marker3.Rotation = rotation;
                        marker3.Flat = true;
                        marker3.GroundAnchor = new CGPoint(0.5f, 0.5f);
                        marker3.Map = mapView;
                        if (t < 1.0)
                        {
                            // Post again 16ms later.
                            //NSTim
                            Task.Delay(16);
                            NSTimer.InvokeInBackground(Run);
                        }
                        else
                        {
                            path.AddCoordinate(prevCoordinate);
                            path.AddCoordinate(CurrPOS);
                            Google.Maps.Polyline line = Google.Maps.Polyline.FromPath(path);
                            line.StrokeWidth = 1f;
                            line.StrokeColor = UIColor.Black;
                            line.Geodesic = true; //more curved path
                            line.Map = mapView;
                        }

                    }));
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

		/// <summary>
		/// Handles the changed camera position.
		/// </summary>
		/// <param name="sender">Sender.</param>
		/// <param name="e">E.</param>
		void HandleChangedCameraPosition(object sender, GMSCameraEventArgs e)
		{
			if ((int)e.Position.Zoom != (int)currentZoomLevel)
			{
				//Console.WriteLine("Postion: {0}", e.Position.Target);
				currentZoomLevel = e.Position.Zoom;
				isAnimateCamera = false;
			}
		}

		///// <summary>
		///// Draws the line btw address.
		///// </summary>
		///// <returns>The line btw address.</returns>
		///// <param name="currentLatLng">Current lat lng.</param>
		///// <param name="previousLatLng">Previous lat lng.</param>
		//public async Task<GoogleDirectionClass> DrawLineBtwAddress(CLLocationCoordinate2D currentLatLng, CLLocationCoordinate2D previousLatLng)
		//{
		//	try
		//	{
		//		GoogleDirectionClass objGoogleDirectionClass = null;
		//		string strGoogleDirectionUrl = MakeURL(currentLatLng, previousLatLng);//string.Format(RateLinx.Helper.Constants.strGoogleDirectionUrl, srcLocation, destination);
		//		strHttpResponse = await FnHttpRequest(strGoogleDirectionUrl);
		//		if (!string.IsNullOrEmpty(strHttpResponse))
		//		{
		//			objGoogleDirectionClass = JsonConvert.DeserializeObject<GoogleDirectionClass>(strHttpResponse);
		//		}
		//		return objGoogleDirectionClass;
		//	}
		//	catch
		//	{
		//		Console.WriteLine(Helper.Constants.strErrorOccured);
		//		return null;
		//	}
		//}

		///// <summary>
		///// Makes the URL.
		///// </summary>
		///// <returns>The URL.</returns>
		///// <param name="currentLatLng">Current lat lng.</param>
		///// <param name="previousLatLng">Previous lat lng.</param>
		//public static string MakeURL(CLLocationCoordinate2D currentLatLng, CLLocationCoordinate2D previousLatLng)
		//{
		//	StringBuilder urlString = new StringBuilder();
		//	urlString.Append("https://maps.googleapis.com/maps/api/directions/json");
		//	urlString.Append("?origin=");// from
		//	urlString.Append(Convert.ToString(previousLatLng.Latitude));
		//	urlString.Append(",");
		//	urlString.Append(Convert.ToString(previousLatLng.Longitude));
		//	urlString.Append("&destination=");// to
		//	urlString.Append(Convert.ToString(currentLatLng.Latitude));
		//	urlString.Append(",");
		//	urlString.Append(Convert.ToString(currentLatLng.Longitude));
		//	//urlString.Append("&sensor=false&mode=driving&alternatives=false");
		//	urlString.Append("&mode=driving&key=" + Helper.Constants.strGoogleServerDirKey + "");
		//	return urlString.ToString();
		//}

		/// <summary>
		/// Gets the current address.
		/// </summary>
		public async Task<string> GetCurrentAddress(CLLocationCoordinate2D location)
		{
			try
			{
				string address = string.Empty;
				CLLocation clLocation = new CLLocation(location.Latitude, location.Longitude);
				var geoCoder = new CLGeocoder();
				var placemarks = await geoCoder.ReverseGeocodeLocationAsync(clLocation);

				foreach (var placemark in placemarks)
				{
					address = placemark.Country + " " + placemark.Locality + " " + placemark.AdministrativeArea;
				}
				clLocation = null;
				geoCoder = null;
				return address;
			}
			catch
			{
				//Console.WriteLine(Helper.Constants.strErrorOccured);
				return "";
			}
		}


		/// <summary>
		/// Subscribe the specified subscriber.
		/// </summary>
		/// <returns>The subscribe.</returns>
		/// <param name="subscriber">Subscriber.</param>
		public void Subscribe(string subscriber)
		{
			//Display("Running " + subscriber + "");
			ThreadPool.QueueUserWorkItem(o =>
			{
				pubnub.AddListener(listener);
				pubnub.Subscribe<object>()
						.Channels(new[] { subscriber })
					  .WithPresence().Execute();
			});
		}


		partial void BackButton_TouchUpInside(UIButton sender)
		{
			NavigationController.PopViewController(true);
		}

		partial void ImgDetails_TouchUpInside(UIButton sender)
		{
			try
			{
				TrackShipDetailsController trackShipDetailsController;
				string shipmentStatus = string.Empty;
				trackShipDetailsController = (TrackShipDetailsController)this.Storyboard.InstantiateViewController("TrackShipDetailsController");
                trackShipDetailsController.compositeKey = objRecentShipments.ClientID + "|" + objRecentShipments.BolNum;
                shipmentStatus = txtShipmentStatus.Text;
				trackShipDetailsController.shipmentStatus = shipmentStatus;
				this.NavigationController.PushViewController(trackShipDetailsController, true);
			}
			catch
			{ }
		}
	}
}