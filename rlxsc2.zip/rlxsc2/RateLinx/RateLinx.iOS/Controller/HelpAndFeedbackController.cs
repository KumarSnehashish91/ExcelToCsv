using Foundation;
using System;
using UIKit;
using RateLinx.Helper;
using MessageUI;
using CoreGraphics;
using System.Drawing;

namespace RateLinx.iOS
{
	public partial class HelpAndFeedbackController : UIViewController
	{
		#region Global used variables
		UITapGestureRecognizer tapGesture = null;
		CustomPopup customAlert = null;
		MFMailComposeViewController mailController;
		private float scroll_amount = 0.0f;    // amount to scroll
		UIView menuView = null;
		UIToolbar toolbar;

		#endregion
		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.HelpAndFeedbackController"/> class.
		/// </summary>
		/// <param name="handle">Handle.</param>
		public HelpAndFeedbackController(IntPtr handle) : base(handle)
		{
		}
		/// <summary>
		/// Views the did load.
		/// </summary>
		public override void ViewDidLoad()
		{
			try
			{
				base.ViewDidLoad();
				lblCopyRight.Text = Util.GetCopyRight();
				//Getting the menu view 
                menuView = new MenuViewController(View).DisplayMenuView(this, null, null, null,null, imgMenu);
				toolbar = new UIToolbar(new CoreGraphics.CGRect(new nfloat(0.0f), new nfloat(0.0f), this.View.Frame.Size.Width, new nfloat(44.0f)));
				toolbar.TintColor = UIColor.White;
				toolbar.BarStyle = UIBarStyle.Black;
				toolbar.Translucent = true;
				toolbar.Items = new UIBarButtonItem[]{
				new UIBarButtonItem(UIBarButtonSystemItem.FlexibleSpace),
	 			new UIBarButtonItem(UIBarButtonSystemItem.Done, delegate {
					if(txtSubject.IsFirstResponder)
					{
						txtSubject.ResignFirstResponder();
					}
					else
					{
						txtMessage.ResignFirstResponder();
					}
				})
			};

				txtSubject.KeyboardAppearance = UIKeyboardAppearance.Default;
				txtSubject.InputAccessoryView = toolbar;

				txtMessage.KeyboardAppearance = UIKeyboardAppearance.Default;
				txtMessage.InputAccessoryView = toolbar;

				lblHelpFeedback.LineBreakMode = UILineBreakMode.WordWrap;
				lblHelpFeedback.Lines = 0;

				tapGesture = new UITapGestureRecognizer(() =>
					View.EndEditing(true)
				);
				HelpAndFeedBackView.AddGestureRecognizer(tapGesture);

				tapGesture = new UITapGestureRecognizer(ManageNavigation);
				imgMenu.AddGestureRecognizer(tapGesture);

				tapGesture = new UITapGestureRecognizer(ManageNavigation);
				imgHome.AddGestureRecognizer(tapGesture);


				NSNotificationCenter.DefaultCenter.AddObserver
				(UIKeyboard.DidShowNotification, KeyBoardUpNotification);
				// Keyboard Down
				NSNotificationCenter.DefaultCenter.AddObserver
				(UIKeyboard.WillHideNotification, KeyBoardDownNotification);
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}
		public override void DidRotate(UIInterfaceOrientation fromInterfaceOrientation)
		{
			if (Util.isMenuVisible)
			{
				if (menuView != null)
				{
					menuView.RemoveFromSuperview();
					menuView = null;
				}
                menuView = new MenuViewController(View).DisplayMenuView(this, null, null, null,null, imgMenu);
				View.AddSubview(menuView);
				menuView.Frame = new CGRect(0, 0, View.Frame.Width, View.Frame.Height);
			}
		}
		public override UIInterfaceOrientationMask GetSupportedInterfaceOrientations()
		{
			return UIInterfaceOrientationMask.Portrait;
		}

		private void KeyBoardUpNotification(NSNotification notification)
		{
			nfloat parentViewheight = View.Frame.Height;
			CGRect notificationBounds = UIKeyboard.BoundsFromNotification(notification);
			if (parentViewheight > 400)
			{
				if (txtMessage.IsFirstResponder)
				{
					if ((viewHelpAndFeedback.Frame.Height - (viewMessage.Frame.Y + txtMessage.Frame.Height)) > (notificationBounds.Height))
					{
						scroll_amount = 0;
					}
					else if ((viewHelpAndFeedback.Frame.Height - (viewMessage.Frame.Y + txtMessage.Frame.Height)) < (notificationBounds.Height))
					{
						scroll_amount = (float)((notificationBounds.Height + 50) - (viewHelpAndFeedback.Frame.Height - (viewMessage.Frame.Y + txtMessage.Frame.Height)));
						scroll_amount -= 50;
					}
					else
					{

					}
					ScrollTheView();
				}
				else
				{

					ScrollTheView();
					scroll_amount = 0;
				}

			}
		}


		private void KeyBoardDownNotification(NSNotification notification)
		{
			scroll_amount = 0;
			ScrollTheView();
		}

		public void ScrollTheView()
		{

			UIView.BeginAnimations(string.Empty, System.IntPtr.Zero);
			UIView.SetAnimationDuration(0.3);

			RectangleF frame = (RectangleF)scrollViewHelpFeedback.Frame;

			if (scroll_amount != 0)
			{
				frame.Y = -(float)scroll_amount;
			}
			else
			{
				frame.Y = 20;
			}
			scroll_amount = 0.0f;
			scrollViewHelpFeedback.Frame = frame;
			UIView.CommitAnimations();
		}

		/// <summary>
		/// Manages the navigation.
		/// </summary>
		/// <param name="tapGesture">Tap gesture.</param>
		public void ManageNavigation(UITapGestureRecognizer tapGesture)
		{
			if (tapGesture.View.Equals(imgHome))
			{
				this.PerformSegue("HelpAndFeedbackToHomeSegue", null);
				//this.NavigationController.PopViewController(true);
			}
			else
			{
				Util.isMenuVisible = true;
                menuView = new MenuViewController(View).DisplayMenuView(this, null, null, null,null,imgMenu);
				View.AddSubview(menuView);

				UIView.Animate(0.3,
				() =>
				{
					if (menuView != null)
					{
						menuView.Frame = new CGRect(0, 0, View.Frame.Width, View.Frame.Height - 20);
					}

				});
			
			}
		}

		/// <summary>
		/// Handles the should start load.
		/// </summary>
		/// <returns><c>true</c>, if should start load was handled, <c>false</c> otherwise.</returns>
		/// <param name="webView">Web view.</param>
		/// <param name="request">Request.</param>
		/// <param name="navigationType">Navigation type.</param>
		bool HandleShouldStartLoad(UIWebView webView, NSUrlRequest request, UIWebViewNavigationType navigationType)
		{
			UIApplication.SharedApplication.OpenUrl(request.Url);
			//SidebarController.CloseMenu();

			return true;
		}
		/// <summary>
		/// Buttons the send touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnSend_TouchUpInside(UIButton sender)
		{
			try
			{
				txtSubject.ResignFirstResponder();
				txtMessage.ResignFirstResponder();
				//email = new Intent(Intent.ActionSend);

				if (!string.IsNullOrEmpty(IsRequiredValidated()))
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, IsRequiredValidated(), true, this, "", 1);
					this.View.Add(this.customAlert);
					return;
				}
				else
				{
					if (!Reachability.InternetConnectionStatus())
					{
						UIView.Animate(0.3,
						() =>
						{
							menuView.Frame = new CGRect(-800, 20, View.Frame.Width, View.Frame.Height - 20);

						});
						this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
						this.View.Add(this.customAlert);
					}

					else
					{
						if (MFMailComposeViewController.CanSendMail)
						{
							if (MFMailComposeViewController.CanSendMail)
							{
								var to = new string[] { Constants.strSendFeedBackEmail };
								mailController = new MFMailComposeViewController();
								mailController.SetToRecipients(to);
								mailController.SetSubject(txtSubject.Text);
								mailController.SetMessageBody(txtMessage.Text, false);
								mailController.Finished += (object s, MFComposeResultEventArgs args) =>
								{
									BeginInvokeOnMainThread(() =>
									{
										args.Controller.DismissViewController(true, null);
									});
								};
							}
							this.PresentViewController(mailController, true, null);
						}
						else
						{
							new UIAlertView(Constants.strEmailNotSupp, Constants.strEmailNotSupp, null, Constants.btnTextOk, null).Show();
						}
						//reset controls text
						txtSubject.Text = string.Empty;
						txtMessage.Text = string.Empty;
					}

				}
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}


		/// <summary>
		/// function for required validation
		/// </summary>
		/// <returns>The required validated.</returns>
		private string IsRequiredValidated()
		{
			string validationMessage = string.Empty;
			try
			{
				//----- Subject ----//
				if (string.IsNullOrEmpty(txtSubject.Text))
				{
					validationMessage = Constants.strSubject;
				}
				//-----  Message ----//
				else if (string.IsNullOrEmpty(txtMessage.Text))
				{
					validationMessage = Constants.strMessage;
				}
				return validationMessage;
			}
			catch
			{
				return validationMessage;
			}
		}
	}
}