// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace RateLinx.iOS
{
    [Register ("CompareRouteController")]
    partial class CompareRouteController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView compareMapView { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgBack { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblBolNo { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblCarrierRoute { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblOptimalRoute { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (compareMapView != null) {
                compareMapView.Dispose ();
                compareMapView = null;
            }

            if (imgBack != null) {
                imgBack.Dispose ();
                imgBack = null;
            }

            if (lblBolNo != null) {
                lblBolNo.Dispose ();
                lblBolNo = null;
            }

            if (lblCarrierRoute != null) {
                lblCarrierRoute.Dispose ();
                lblCarrierRoute = null;
            }

            if (lblOptimalRoute != null) {
                lblOptimalRoute.Dispose ();
                lblOptimalRoute = null;
            }
        }
    }
}