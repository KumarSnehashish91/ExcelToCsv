﻿using System;

using UIKit;

namespace RateLinx.iOS
{
	public partial class NavController : UINavigationController
	{
		public NavController () : base ((string)null, null)
		{
		}

		public override void ViewDidLoad ()
		{
			base.ViewDidLoad ();
			// Perform any additional setup after loading the view, typically from a nib.
			NavigationBar.BarStyle = UIBarStyle.BlackTranslucent;
			this.InteractivePopGestureRecognizer.Enabled = false;
		}
	}
}


