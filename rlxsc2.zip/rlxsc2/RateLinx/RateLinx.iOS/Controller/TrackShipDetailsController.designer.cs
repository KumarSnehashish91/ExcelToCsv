// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace RateLinx.iOS
{
    [Register ("TrackShipDetailsController")]
    partial class TrackShipDetailsController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnBack { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblCopyRight { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblCurrentStatus { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblDeliveryOn { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextView lblDestinationAddress { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblDestinationEmail { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblDestinationFax { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblDestinationPhone { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextView lblOriginAddress { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblOriginEmail { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblOriginFax { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblOriginPhone { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblPickupOn { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblShipmentNo { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewTrackShipDetails { get; set; }

        [Action ("BtnBack_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnBack_TouchUpInside (UIKit.UIButton sender);

        void ReleaseDesignerOutlets ()
        {
            if (btnBack != null) {
                btnBack.Dispose ();
                btnBack = null;
            }

            if (lblCopyRight != null) {
                lblCopyRight.Dispose ();
                lblCopyRight = null;
            }

            if (lblCurrentStatus != null) {
                lblCurrentStatus.Dispose ();
                lblCurrentStatus = null;
            }

            if (lblDeliveryOn != null) {
                lblDeliveryOn.Dispose ();
                lblDeliveryOn = null;
            }

            if (lblDestinationAddress != null) {
                lblDestinationAddress.Dispose ();
                lblDestinationAddress = null;
            }

            if (lblDestinationEmail != null) {
                lblDestinationEmail.Dispose ();
                lblDestinationEmail = null;
            }

            if (lblDestinationFax != null) {
                lblDestinationFax.Dispose ();
                lblDestinationFax = null;
            }

            if (lblDestinationPhone != null) {
                lblDestinationPhone.Dispose ();
                lblDestinationPhone = null;
            }

            if (lblOriginAddress != null) {
                lblOriginAddress.Dispose ();
                lblOriginAddress = null;
            }

            if (lblOriginEmail != null) {
                lblOriginEmail.Dispose ();
                lblOriginEmail = null;
            }

            if (lblOriginFax != null) {
                lblOriginFax.Dispose ();
                lblOriginFax = null;
            }

            if (lblOriginPhone != null) {
                lblOriginPhone.Dispose ();
                lblOriginPhone = null;
            }

            if (lblPickupOn != null) {
                lblPickupOn.Dispose ();
                lblPickupOn = null;
            }

            if (lblShipmentNo != null) {
                lblShipmentNo.Dispose ();
                lblShipmentNo = null;
            }

            if (viewTrackShipDetails != null) {
                viewTrackShipDetails.Dispose ();
                viewTrackShipDetails = null;
            }
        }
    }
}