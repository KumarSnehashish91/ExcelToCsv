using Foundation;
using System;
using UIKit;
using Google.Maps;
using CoreGraphics;
using CoreLocation;
using RateLinx.GoogleServices;
using System.Threading.Tasks;
using System.Net;
using Newtonsoft.Json;
using RateLinx.Helper;

namespace RateLinx.iOS
{
	public partial class MapController : UIViewController
	{
		#region
		MapView mapView;
		GoogleDirectionClass objRoutes;
		GeoCodeJSONClass objGeoCodeJSONClass;
		public string addressKey;
		string strSource = string.Empty;
		string strDestination = string.Empty;
		string strGeoCodeURL = string.Empty;
		string strHttpResponse = string.Empty;
		//Code snippet to mark source and destination points
		Location SourceLocation { get; set; }
		Location DestinationLocation { get; set; }
		UITapGestureRecognizer tapGesture;
		CustomPopup customAlert = null;
		#endregion

		public MapController(IntPtr handle) : base(handle)
		{

		}

		/// <summary>
		/// Loads the view.
		/// </summary>
		public override async void LoadView()
		{
			try
			{
				base.LoadView();
				if (Reachability.InternetConnectionStatus())
				{
					tapGesture = new UITapGestureRecognizer(ManageNavigation);
					imgBack.AddGestureRecognizer(tapGesture);

					// Create a GMSCameraPosition that tells the map to display the
					strSource = addressKey.Split('#')[0];
					strDestination = addressKey.Split('#')[1];
					lblBolNo.Text = addressKey.Split('#')[2];
                    //Get Lat and Long from Address
                    await GeocodeToConsoleAsync(strSource, strDestination);

					var camera = CameraPosition.FromCamera(latitude: SourceLocation.lat,
						   longitude: SourceLocation.lng,
						   zoom: 6);
					mapView = MapView.FromCamera(CGRect.Empty, camera);
					mapView.MyLocationEnabled = true;
					//Sourec
					CLLocationCoordinate2D coord1 = new CLLocationCoordinate2D(SourceLocation.lat, SourceLocation.lng);
					var marker1 = Marker.FromPosition(coord1);
					marker1.Title = string.Format(strSource);
					marker1.Icon = UIImage.FromBundle("Images/MarkerSource.png");
					marker1.Map = mapView;

					//Destination
					CLLocationCoordinate2D coord2 = new CLLocationCoordinate2D(DestinationLocation.lat, DestinationLocation.lng);
					var marker2 = Marker.FromPosition(coord2);
					marker2.Title = string.Format(strDestination);
					marker2.Icon = UIImage.FromBundle("Images/MarkerDest.png");
					marker2.Map = mapView;

					await DrawLineBtwAddress(strSource, strDestination);

					if (objRoutes != null)
					{
						//Draw line by connecting polyline points
						UIColor pathColor = UIColor.Red;
						int intRoutesCount = objRoutes.routes.Count;
						//available routes may be more then one
						for (int intCounter = 0; intCounter < intRoutesCount; intCounter++)
						{
							var path = Google.Maps.Path.FromEncodedPath(objRoutes.routes[intCounter].overview_polyline.points);
							var line = Google.Maps.Polyline.FromPath(path);
							line.StrokeWidth = 3f;
							line.StrokeColor = UIColor.Red;
							line.Geodesic = true; //more curved path
							line.Map = mapView;
						}
					}
					mapView.Frame = viewMapControl.Bounds;
                    mapView.MyLocationEnabled = true;
                    mapView.Settings.MyLocationButton = true;
                    mapView.Settings.ZoomGestures = true;
					//View = mapView;
					viewMapControl.AddSubview(mapView);
				}
				else
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
					this.View.Add(this.customAlert);
				}
			}
			catch
			{
				Console.WriteLine(Helper.Constants.strErrorOccured);
			}
		}

		public override void DidRotate(UIInterfaceOrientation fromInterfaceOrientation)
		{
			base.DidRotate(fromInterfaceOrientation);

			mapView.Frame = viewMapControl.Bounds;
			viewMapControl.AddSubview(mapView);

			if (!Util.isViewRotated)
			{
				Util.isViewRotated = true;
			}
			else
			{
				Util.isViewRotated = false;
			}
		}


        /// <summary>
        /// Geocodes to console async.
        /// </summary>
        /// <returns>The to console async.</returns>
        /// <param name="originAdd">Origin add.</param>
        /// <param name="destinationAdd">Destination add.</param>
        private async Task GeocodeToConsoleAsync(string originAdd, string destinationAdd)
        {
            try
            {
                //mark source point
                CLLocation originCLlocation = new CLLocation();
                CLLocation destinationCLlocation = new CLLocation();
                var geocoder = new CLGeocoder();
                var placeMarkOrigin = geocoder.GeocodeAddressAsync(originAdd);
                await placeMarkOrigin.ContinueWith((addresses) =>
                {
                    foreach (var address in addresses.Result)
                    {
                        originCLlocation = address.Location;
                    }
                });

                if (originCLlocation != null)
                {
                    SourceLocation = new Location() { lat = originCLlocation.Coordinate.Latitude, lng = originCLlocation.Coordinate.Longitude };
                }
                var placeMarkDest = geocoder.GeocodeAddressAsync(destinationAdd);
                await placeMarkDest.ContinueWith((addresses) =>
                {
                    foreach (var address in addresses.Result)
                    {
                        destinationCLlocation = address.Location;
                    }
                });
                if (destinationCLlocation != null)
                {
                    DestinationLocation = new Location() { lat = destinationCLlocation.Coordinate.Latitude, lng = destinationCLlocation.Coordinate.Longitude };
                }
                originCLlocation = null;
                destinationCLlocation = null;
            }
            catch
            {
                Console.WriteLine(Helper.Constants.strErrorOccured);
            }
        }


		/// <summary>
		/// Fns the http request.
		/// </summary>
		/// <returns>The http request.</returns>
		/// <param name="strURL">String URL.</param>
		static async Task<string> FnHttpRequest(string strURL)
		{
			try
			{
				WebClient client = new WebClient();
				string strResult;
				try
				{
					strResult = await client.DownloadStringTaskAsync(new Uri(strURL));
				}
				catch
				{
					strResult = NSBundle.MainBundle.GetLocalizedString("exception", null);
				}
				finally
				{
					client.Dispose();
					client = null;
				}
				return strResult;
			}
			catch
			{
				Console.WriteLine(Helper.Constants.strErrorOccured);
				return null;
			}
		}

		/// <summary>
		/// Draws the line btw address.
		/// </summary>
		/// <returns>The line btw address.</returns>
		/// <param name="srcLocation">Source location.</param>
		/// <param name="destination">Destination.</param>
		public async Task DrawLineBtwAddress(string srcLocation, string destination)
		{
			try
			{
				string strGoogleDirectionUrl = string.Format(RateLinx.Helper.Constants.strGoogleDirectionUrl, srcLocation, destination);
				strHttpResponse = await FnHttpRequest(strGoogleDirectionUrl);
				if (!string.IsNullOrEmpty(strHttpResponse))
				{
					objRoutes = JsonConvert.DeserializeObject<GoogleDirectionClass>(strHttpResponse);
				}
			}
			catch
			{
				Console.WriteLine(Helper.Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Manages the navigation.
		/// </summary>
		/// <param name="tapGesture">Tap gesture.</param>
		public void ManageNavigation(UITapGestureRecognizer tapGesture)
		{
			try
			{
				if (tapGesture.View.Equals(imgBack))
				{
					this.NavigationController.PopViewController(true);
					//this.NavigationController.PopViewController(true);
				}
				else
				{

				}
			}
			catch
			{
				Console.WriteLine(Helper.Constants.strErrorOccured);
			}
		}
	}

}