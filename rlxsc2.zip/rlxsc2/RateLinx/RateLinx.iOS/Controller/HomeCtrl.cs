using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace myapp
{
	partial class HomeCtrl : UIViewController
	{
		//object of custom popup box
		CustomPopup customAlert;
		public HomeCtrl (IntPtr handle) : base (handle)
		{
		}
		public override void ViewDidLoad ()
		{
			base.ViewDidLoad ();
			// Perform any additional setup after loading the view, typically from a nib.
			//to hide the navigation bar
			NavigationController.SetNavigationBarHidden (true, true);
			// code for dismiss keyboard after touch on view 
			var g = new UITapGestureRecognizer (() => View.EndEditing (true));
			g.CancelsTouchesInView = false; //for iOS5
			View.AddGestureRecognizer (g);

			checkIsLogin ();
			SetUI ();
		}
		private void SetUI()
		{
			//Setting backgroung color
			vwHeader.BackgroundColor =  UIColor.FromRGB ((int)ConfigEntity.EPColorHeader.Red, (int)ConfigEntity.EPColorHeader.Green, (int)ConfigEntity.EPColorHeader.Blue);
			//setting custom font family
			lblLogin.Font = UIFont.FromName (MyResource.OpenSansRegularFont, 18);
			lblEmailID.Font = UIFont.FromName (MyResource.OpenSansRegularFont, 18);
			lblPassword.Font = UIFont.FromName (MyResource.OpenSansRegularFont, 18);

			txtEmailId.Font = UIFont.FromName (MyResource.OpenSansRegularFont, 18);
			txtPassword.Font = UIFont.FromName (MyResource.OpenSansRegularFont, 18);

			btnClick.BackgroundColor = UIColor.FromRGB ((int)ConfigEntity.EPLightButtonBG.Red, (int)ConfigEntity.EPLightButtonBG.Green, (int)ConfigEntity.EPLightButtonBG.Blue);
			btnClick.SetTitleColor (UIColor.White, UIControlState.Normal);
			btnClick.Font = UIFont.FromName (MyResource.OpenSansRegularFont, 20);
		}

		private void checkIsLogin()
		{
			if (!string.IsNullOrEmpty (NSUserDefaults.StandardUserDefaults.StringForKey ("isLogin"))) {
				if(NSUserDefaults.StandardUserDefaults.StringForKey ("isLogin") =="yes")
				{
					this.PerformSegue("SequeToMain", null);
				}
 			}
		}
		public override void DidReceiveMemoryWarning ()
		{
			base.DidReceiveMemoryWarning ();
			// Release any cached data, images, etc that aren't in use.
		}
		partial void BtnClick_TouchUpInside (UIButton sender)
		{
			//redirect to another screen
			if (ValidateAll ()) {
				if(txtEmailId.Text.Trim() =="ashisht@chetu.com" && txtPassword.Text.Trim()=="ashish")
				{
					//setting userdefault values
					NSUserDefaults.StandardUserDefaults.SetString("yes","isLogin");
					NSUserDefaults.StandardUserDefaults.SetString(txtEmailId.Text,"UserEmail");
					this.PerformSegue("SequeToMain", null);
				}
				else
				{
					this.customAlert = new CustomPopup (UIScreen.MainScreen.Bounds, "Wrong Email-Id or Password", true, this, "", 1);
					this.View.Add (this.customAlert);	
				}
			}
		}

//		public override void PrepareForSegue (UIStoryboardSegue segue, NSObject sender)
//		{
//			base.PrepareForSegue (segue, sender);
//			if (segue.Identifier.Equals ("SequeToMain")) {
//				//passing values to Edit lead screen
//				var mainController = (MainController)segue.DestinationViewController;
//				mainController.userId = txtEmailId.Text.Trim ();
//			}
//		}

		//Check validation on done button click
		public bool ValidateAll ()
		{
			if (string.IsNullOrEmpty (txtEmailId.Text)) {
				this.customAlert = new CustomPopup (UIScreen.MainScreen.Bounds, "Enter Email-ID", true, this, "", 1);
				this.View.Add (this.customAlert);
				return false;
			} else if (string.IsNullOrEmpty (txtPassword.Text)) {
				this.customAlert = new CustomPopup (UIScreen.MainScreen.Bounds, "Enter Password", true, this, "", 1);
				this.View.Add (this.customAlert);
				return false;
			}
			else {
				return true;
			}
		}
	}
}
