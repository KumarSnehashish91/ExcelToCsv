﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using UIKit;
using Foundation;

namespace myapp
{
	public partial class TeamListController : BaseController
	{
		public List<TeamList> lstTeamList;
		public TeamList selectMember;

		TeamListDataSource teamListDataSource;
		public TeamListController (IntPtr handle): base(handle)
		{
			
		}
		public override void ViewDidLoad ()
		{
			base.ViewDidLoad ();
			// Perform any additional setup after loading the view, typically from a nib.
			SetUI();
			FillList ();
			lstTeamList = lstTeamList.OrderBy (x => x.Name).ToList ();
			//passing pupulated list of LeadListingTableSource constructor
			teamListDataSource = new TeamListDataSource (lstTeamList);
			tblvwTeamList.Source = teamListDataSource;
			tblvwTeamList.TableFooterView = new UIView ();
		}

		public void FillList()
		{
			lstTeamList = new List<TeamList> () {
				new TeamList () {Empid = 101,Name = "Ashish Tanwar",Email = "ashisht@chetu.com"	},
				new TeamList (){ Empid = 102, Name = "Davender Sing", Email = "davenders@chetu.com" },
				new TeamList (){ Empid = 103, Name = "Goutam Sagar", Email = "goutams@chetu.com" },
				new TeamList (){ Empid = 104, Name = "Chander Shekar", Email = "chandas@chetu.com" },
				new TeamList (){ Empid = 105, Name = "Bhabani jena", Email = "bhabanij@chetu.com" },
				new TeamList (){ Empid = 106, Name = "Gaurav Saini", Email = "gouravs@chetu.com" },
				new TeamList (){ Empid = 107, Name = "Nazar khan", Email = "nazark@chetu.com" },
				new TeamList (){ Empid = 108, Name = "Shashank Saxena", Email = "shashanks@chetu.com" },
				new TeamList (){ Empid = 109, Name = "Sudeep kumar", Email = "sudeepk@chetu.com" },
				new TeamList (){ Empid = 110, Name = "Sanjeet reja", Email = "sanjeetr@chetu.com" }
			};
		}

		private void SetUI()
		{
			//Setting backgroung color
			vwHeader.BackgroundColor =  UIColor.FromRGB ((int)ConfigEntity.EPColorHeader.Red, (int)ConfigEntity.EPColorHeader.Green, (int)ConfigEntity.EPColorHeader.Blue);
			//setting custom font family
			lblHeader.Font = UIFont.FromName (MyResource.OpenSansRegularFont, 20);
		}


		public override void ViewWillAppear (bool animated)
		{			
			//binding event handler on uitableview row selected event
			teamListDataSource.OnRowSelect += HandleOnRowSelect;
		}

		public override void ViewWillDisappear (bool animated)
		{
			base.ViewWillDisappear (animated);
			//unbinding event handler on uitableview row selected event
			teamListDataSource.OnRowSelect -= HandleOnRowSelect;
		}

		//custom event handler function for uitableview row selected event
		void HandleOnRowSelect (TeamList tm)
		{	//getting index of selected row
			selectMember = tm;
			//transfer flow to scanleadcontroller for editing
			this.PerformSegue ("SequeListToMain", this);
		}

		public override void PrepareForSegue (UIStoryboardSegue segue, NSObject sender)
		{
			base.PrepareForSegue (segue, sender);

			if (segue.Identifier.Equals ("SequeListToMain")) {	
				//passing lead details to lead scan controller
				var mainController = (MainController)segue.DestinationViewController;
				mainController.teamMember = selectMember;
			}
		}
		public override void DidReceiveMemoryWarning ()
		{
			base.DidReceiveMemoryWarning ();
			// Release any cached data, images, etc that aren't in use.
		}

		partial void Btnmenu_TouchUpInside (UIButton sender)
		{
			SidebarController.ToggleMenu ();
		}
	}
}


