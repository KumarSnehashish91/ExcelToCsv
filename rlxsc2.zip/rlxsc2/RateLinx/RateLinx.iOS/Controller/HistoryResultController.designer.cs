// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace RateLinx.iOS
{
    [Register ("HistoryResultController")]
    partial class HistoryResultController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgHome { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgMenu { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView mainView { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIScrollView scrollViewHistoryResult { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITableView tblHistoryResult { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel txtHistoryRecords { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewDivider { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewPaging { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewResultStatus { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (imgHome != null) {
                imgHome.Dispose ();
                imgHome = null;
            }

            if (imgMenu != null) {
                imgMenu.Dispose ();
                imgMenu = null;
            }

            if (mainView != null) {
                mainView.Dispose ();
                mainView = null;
            }

            if (scrollViewHistoryResult != null) {
                scrollViewHistoryResult.Dispose ();
                scrollViewHistoryResult = null;
            }

            if (tblHistoryResult != null) {
                tblHistoryResult.Dispose ();
                tblHistoryResult = null;
            }

            if (txtHistoryRecords != null) {
                txtHistoryRecords.Dispose ();
                txtHistoryRecords = null;
            }

            if (viewDivider != null) {
                viewDivider.Dispose ();
                viewDivider = null;
            }

            if (viewPaging != null) {
                viewPaging.Dispose ();
                viewPaging = null;
            }

            if (viewResultStatus != null) {
                viewResultStatus.Dispose ();
                viewResultStatus = null;
            }
        }
    }
}