using CoreGraphics;
using Foundation;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RateLinx.APIs;
using RateLinx.Helper;
using System;
using System.Collections.Generic;
using UIKit;
using RateLinx.Models;
using System.Linq;
using System.Threading.Tasks;
using ToastIOS;

namespace RateLinx.iOS
{
    public partial class OrderHistoryController : UIViewController
    {
        UITapGestureRecognizer tapGesture = null;
        UIView menuView;
        List<OrderHistory> lstOrderHistoryResult = null;
        List<string> lstSelectedOrders = null;
        List<UIButton> buttons;
        UIScrollView scrollView;
        int pageCount = 0;
        string postAcceptedOrders = string.Empty;
        bool isKeyboardShow = false;
        LoadingOverlay loadPop;
        nfloat keyboardHeight;
        ServiceHelper objServicehelper = new ServiceHelper();
        public OrderHistoryController (IntPtr handle) : base (handle)
        {
        }

        public override void ViewWillAppear(bool animated)
        {
            base.ViewWillAppear(animated);
            AppDelegate.disableAllOrientation = true;
            //NSNotificationCenter.DefaultCenter.AddObserver
            //                    (UIKeyboard.DidShowNotification, KeyBoardDidShow);
            //// Keyboard Down
            //NSNotificationCenter.DefaultCenter.AddObserver
                                //(UIKeyboard.WillHideNotification, KeyBoardWillHide);

           // _didShowNotificationObserver = NSNotificationCenter.DefaultCenter.AddObserver
           //(UIKeyboard.DidShowNotification, KeyBoardDidShow, this);

            //_willHideNotificationObserver = NSNotificationCenter.DefaultCenter.AddObserver
            //(UIKeyboard.WillHideNotification, KeyBoardWillHide, this);
        }

        public override void ViewWillDisappear(bool animated)
        {
            base.ViewWillDisappear(animated);
            AppDelegate.disableAllOrientation = false;
        }
        public override void ViewDidUnload()
        {
            base.ViewDidUnload();
            AppDelegate.disableAllOrientation = false;
        }
        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            AppDelegate.disableAllOrientation = true;
            objServicehelper = new ServiceHelper();
            tapGesture = new UITapGestureRecognizer(ManageNavigation);
            imgMenu.AddGestureRecognizer(tapGesture);
            tapGesture = new UITapGestureRecognizer(ManageNavigation);
            imgHome.AddGestureRecognizer(tapGesture);

            var g = new UITapGestureRecognizer(() => View.EndEditing(true));
            g.CancelsTouchesInView = false; //for iOS5
            imgHome.AddGestureRecognizer(tapGesture);
            View.AddGestureRecognizer(g);

            NSNotificationCenter.DefaultCenter.AddObserver
                              (UIKeyboard.DidShowNotification, KeyBoardDidShow);
            // Keyboard Down
            //NSNotificationCenter.DefaultCenter.AddObserver
                                //(UIKeyboard.WillHideNotification, KeyBoardWillHide);
            btnAcceptOrders.TouchUpInside += delegate
            {
                if(!CommanUtil.IsTimeOut())
                {
                    return;
                }
                if (lstOrderHistoryResult != null && lstOrderHistoryResult.Count > 0)
                {
                    lstSelectedOrders = lstOrderHistoryResult.Where(mn => mn.isCheckBoxChecked == true).Select(mn => mn.OrderID).ToList();
                    if (lstSelectedOrders != null && lstSelectedOrders.Count > 0)
                    {
                        DailyOrderConfirmationAlert objDailyOrderConfirmationAlert
                        = new DailyOrderConfirmationAlert(this.View,
                                                          string.Format(Constants.strWantToAcceptOrder,
                                                                        lstSelectedOrders.Count), this,
                                                          lstSelectedOrders, APIMethods.approveOrders);
                        View.AddSubview(objDailyOrderConfirmationAlert.GetWarningPop());

                    }
                    else
                    {
                        CustomPopup customPopup = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strSelectOrder, true, this, "", 1);
                        this.View.Add(customPopup);
                    }
                }
            };
            btnDenyOrders.TouchUpInside += delegate
            {
                if (!CommanUtil.IsTimeOut())
                {
                    return;
                }
                if (lstOrderHistoryResult != null && lstOrderHistoryResult.Count > 0)
                {
                    lstSelectedOrders = lstOrderHistoryResult.Where(mn => mn.isCheckBoxChecked == true).Select(mn => mn.OrderID).ToList();
                    if (lstSelectedOrders != null && lstSelectedOrders.Count > 0)
                    {
                        DailyOrderConfirmationAlert objDailyOrderConfirmationAlert
                        = new DailyOrderConfirmationAlert(this.View, 
                                                          string.Format(Constants.strWantToDenyOrder,
                                                                        lstSelectedOrders.Count), this,
                                                          lstSelectedOrders,APIMethods.denyOrders);
                        View.AddSubview(objDailyOrderConfirmationAlert.GetWarningPop());
                    }
                    else
                    {
                        CustomPopup customPopup = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strSelectOrder, true, this, "", 1);
                        this.View.Add(customPopup);
                    }
                }
            };
            BindOrderHistoryData(1, APIMethods.getOrders);
        }

        /// <summary>
        /// Accept and deny the orders.
        /// </summary>
        /// <returns>The and denyorder.</returns>
        /// <param name="lstOrders">Lst orders.</param>
        /// <param name="methodName">Method name.</param>
        public async Task AcceptAndDenyorder(List<string> lstOrders, string methodName)
        {
            try
            {
                CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
                loadPop = new LoadingOverlay(bounds);
                View.Add(loadPop);
                foreach (var orderID in lstOrders)
                {
                    postAcceptedOrders = string.Format(methodName, orderID);
                    await objServicehelper.PostRequestJson("", postAcceptedOrders, CommanUtil.tokenNo, true);
                }
                if (string.IsNullOrEmpty(txtOrderId.Text.Trim()))
                {
                    loadPop.Hide();
                    await BindOrderHistoryData1(pageCount, APIMethods.getOrders);
                }
                else
                {
                    loadPop.Hide();
                    await BindOrderHistoryData1(pageCount, string.Format(APIMethods.getIDWiseOrders, txtOrderId.Text));
                }

            }
            catch
            {
                Toast.MakeText(Helper.Constants.strErrorOccured).SetDuration(Helper.Constants.toastDuration).Show(); 
            }
        }


        /// <summary>
        /// Manages the navigation.
        /// </summary>
        /// <param name="tapGesture">Tap gesture.</param>
        public void ManageNavigation(UITapGestureRecognizer tapGesture)
        {
            if (tapGesture.View.Equals(imgHome))
            {
                this.PerformSegue("SegueFromOrderHistoryToHome", null);
            }
            else
            {
                Util.isMenuVisible = true;
                menuView = new MenuViewController(View).DisplayMenuView(null, null, null, null,this, imgHome);
                View.AddSubview(menuView);

                UIView.Animate(0.3,
                () =>
                {
                    if (menuView != null)
                    {
                        menuView.Frame = new CGRect(0, 0, View.Frame.Width, View.Frame.Height - 20);
                    }

                });
            }
        }

        public void KeyBoardDidShow(NSNotification notification)         {
            var r = UIKeyboard.FrameBeginFromNotification(notification);
            keyboardHeight = r.Height+15;             //nfloat mainViewHeight = View.Frame.Height;             UIDeviceOrientation orientation = UIDevice.CurrentDevice.Orientation;
            if (orientation.Equals("Portrait") || orientation.Equals("PortraitUpsideDown"))             {                                             }
            else if (orientation.Equals("LandscapeRight") || orientation.Equals("LandscapeLeft"))             {                              }
            else
            {
                
            }
            isKeyboardShow = true;
            ScrollTheView(true);         }          private void KeyBoardWillHide()         {
            if (isKeyboardShow)
            {
                isKeyboardShow = false;                 ScrollTheView(false);
            }
        }         private void ScrollTheView(bool move)         {             UIView.BeginAnimations(string.Empty, System.IntPtr.Zero);             UIView.SetAnimationDuration(0.3);              CGRect frame = viewDailyOrderSearch.Frame;              if (move)             {                 frame.Y -= keyboardHeight;             }             else             {                 frame.Y += keyboardHeight;             }              viewDailyOrderSearch.Frame = frame;             UIView.CommitAnimations();         } 

        partial void BtnClear_TouchUpInside(UIButton sender)
        {
            txtOrderId.Text = "";
            BindOrderHistoryData(1, APIMethods.getOrders);
        }

        partial void BtnSearchByOrderID_TouchUpInside(UIButton sender)
        {
            try
            {
                KeyBoardWillHide();
                if (!CommanUtil.IsTimeOut())
                {
                    return;
                }
                if (txtOrderId.Text.Trim() != "")
                {
                    string methodUrl = string.Format(APIMethods.getIDWiseOrders, txtOrderId.Text);
                    //txtOrderId.Text = "";
                    BindOrderHistoryData(1, methodUrl);
                }
                else
                {
                    Toast.MakeText(Helper.Constants.strEnterOrderNo).SetDuration(Helper.Constants.toastDuration).Show();
                }
            }
            catch(Exception )
            {
                Console.Write(Constants.strErrorOccured);
            }
        }

        public async void BindOrderHistoryData(int pageNum, string method)
        {
            int totalResult = await BindOrderHistoryData1(1, method);
            try
            {
                int margin = 2;
                if (totalResult != 0)
                {
                    //viewResultStatus.Hidden = false;
                    //scrollViewHeader.Hidden = false;
                    viewPaging.Hidden = false;
                    //viewDivider.Hidden = false;
                    int pagingCount = totalResult / 20;
                    if (totalResult % 20 > 0)
                    {
                        pagingCount = pagingCount + 1;
                    }
                    lstOrderHistoryResult = lststring(lstOrderHistoryResult, pageNum - 1, 20);
                    scrollView = new UIScrollView
                    {
                        Frame = new CGRect(72, 0, viewPaging.Frame.Width - 72, viewPaging.Frame.Height),
                        ContentSize = new CGSize((pagingCount * 27), viewPaging.Frame.Height),
                        BackgroundColor = UIColor.White,
                        AutoresizingMask = UIViewAutoresizing.FlexibleWidth,
                        Bounces = false,
                        DirectionalLockEnabled = true
                    };
                    viewPaging.AddSubview(scrollView);

                    buttons = new List<UIButton>();
                    if (pagingCount == 0)
                    {
                        var button = UIButton.FromType(UIButtonType.RoundedRect);
                        button.SetTitle("1", UIControlState.Normal);
                        button.Frame = new CGRect(margin, 5, 28, 28);
                        button.BackgroundColor = UIColor.White;
                        button.Tag = 1;
                        button.SetTitleColor(UIColor.Blue, UIControlState.Normal);
                        button.Layer.BorderWidth = 1;
                        button.Layer.CornerRadius = 4;
                        button.Layer.BorderColor = UIColor.LightGray.CGColor;
                        scrollView.AddSubview(button);
                        buttons.Add(button);
                    }
                    else
                    {
                        for (int i = 1; i <= pagingCount; i++)
                        {

                            var button = UIButton.FromType(UIButtonType.RoundedRect);
                            button.SetTitle(i.ToString(), UIControlState.Normal);
                            button.Frame = new CGRect(margin, 5, 28, 28);
                            button.BackgroundColor = UIColor.White;
                            button.Tag = i;
                            button.SetTitleColor(UIColor.Blue, UIControlState.Normal);
                            button.Layer.BorderWidth = 1;
                            button.Layer.CornerRadius = 4;
                            button.Layer.BorderColor = UIColor.LightGray.CGColor;
                            scrollView.AddSubview(button);
                            buttons.Add(button);
                            margin = margin + 32;
                        }
                    }
                    buttons[0].SetTitleColor(UIColor.Red, UIControlState.Normal);
                    foreach (UIButton objButtonPaging in buttons)
                    {
                        objButtonPaging.TouchUpInside += async delegate
                        {
                            foreach (UIButton pagingButton in buttons)
                            {
                                pagingButton.SetTitleColor(UIColor.Blue, UIControlState.Normal);
                            }
                            objButtonPaging.SetTitleColor(UIColor.Red, UIControlState.Normal);
                            await BindOrderHistoryData1(Convert.ToInt32(objButtonPaging.Tag), APIMethods.getOrders);
                        };
                    }
                }
                else
                {
                    //viewResultStatus.Hidden = false;
                    //scrollViewHeader.Hidden = true;
                    viewPaging.Hidden = true;
                    //viewDivider.Hidden = true;

                    txtHistoryRecords.Text = Convert.ToString(totalResult) + "  " + NSBundle.MainBundle.GetLocalizedString("resultview", null);
                }
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
            }
        }



        public async Task<int>  BindOrderHistoryData1(int pageNum, string method)
        {
            loadPop = null;
            int resultCount = 0;
            pageCount = pageNum;
            try
            {
                viewPaging.Hidden = false;
               
                if (Reachability.InternetConnectionStatus())
                {
                    CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
                    loadPop = new LoadingOverlay(bounds);
                    //string query = "shipmentrequests?Page=1&PerPage=20&filters='Date Opened'>=10/05/2015|'Date Opened'<=10/05/2018";
                    //string strToken = CommanUtil.tokenNo;
                    //string uriHistoryResult = method + "?" + query;
                    //Method Name
                    //string methodName = APIMethods.getHistoryResult;
                    View.Add(loadPop);
                    string strResponse = await objServicehelper.GetRequest(CommanUtil.tokenNo, method, true);
                    if (!string.IsNullOrEmpty(strResponse))
                    {
                        loadPop.Hide();
                        lstOrderHistoryResult = (List<OrderHistory>)JsonConvert.DeserializeObject(strResponse, typeof(List<OrderHistory>));
                        resultCount = lstOrderHistoryResult.Count;
                        if (resultCount > 0)
                        {
                            tblHistoryResult.Hidden = false;
                            btnDenyOrders.Hidden = false;
                            btnAcceptOrders.Hidden = false;
                            viewLine1.Hidden = false;
                            viewLine2.Hidden = false;

                            lstOrderHistoryResult = lststring(lstOrderHistoryResult, pageNum - 1, 20);

                            tblHistoryResult.RowHeight = 50;
                            tblHistoryResult.Bounces = false;
                            scrollViewHistoryResult.DirectionalLockEnabled = true;
                            tblHistoryResult.AutoresizingMask = UIViewAutoresizing.FlexibleWidth;

                            tblHistoryResult.Source = new OrderHistoryAdapter(lstOrderHistoryResult, this);
                            tblHistoryResult.TableFooterView = new UIView(CGRect.Empty);
                            tblHistoryResult.ReloadData();
                            scrollViewHistoryResult.ContentSize = new CGSize(840, lstOrderHistoryResult.Count * 47 + 50);
                            tblHistoryResult.Frame = new CGRect(0, 0, 840, scrollViewHistoryResult.Frame.Height);
                            txtHistoryRecords.Text = Convert.ToString(resultCount) + "  " + NSBundle.MainBundle.GetLocalizedString("resultview", null);
                        }
                        else
                        {
                            tblHistoryResult.Hidden = true;
                            btnDenyOrders.Hidden = true;
                            btnAcceptOrders.Hidden = true;
                            viewLine1.Hidden = true;
                            viewLine2.Hidden = true;
                        }
                    }
                }
                else
                {
                    CustomPopup customPopup = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
                    this.View.Add(customPopup);
                }
                return resultCount;
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
                txtHistoryRecords.Text = 0 + "  " + NSBundle.MainBundle.GetLocalizedString("resultview", null);
                //return 0;
                return resultCount;
            }
        }

        static List<OrderHistory> lststring(List<OrderHistory> lstOrderHistoryResult, int page, int pageSize)
        {
            return lstOrderHistoryResult.Skip(page * pageSize).Take(pageSize).ToList();
        }

    }
}