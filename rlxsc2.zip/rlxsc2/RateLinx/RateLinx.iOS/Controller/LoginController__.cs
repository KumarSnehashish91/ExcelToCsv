using Foundation;
using System;
using UIKit;
using Newtonsoft.Json.Linq;
using RateLinx.Helper;
using RateLinx.Models;
using System.Threading.Tasks;
using RateLinx.APIs;
using ToastIOS;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Linq;
using Security;
using CoreGraphics;
using System.Drawing;
using Plugin.Connectivity;

namespace RateLinx.iOS
{
    /// <summary>
    /// Login controller.
    /// </summary>
	public partial class LoginController : UIViewController
    {

        #region Global used variables
        LoadingOverlay loadPop;
        CustomPopup customAlert = null;
        ServiceHelper objServicehelper = null;
        AccountSettings objAccountSettings = null;
        JObject jobject = null;
        bool isRemember = false;
        string validationMessage = string.Empty;
        string postData = string.Empty;
        string methodName = string.Empty;
        string strToken = string.Empty;
        string strResponse = string.Empty;
        bool isLogin = false;
        string clientID = string.Empty;
        string loadNum = string.Empty;
        string slideNo = string.Empty;
        public static string compositeKey = string.Empty;
        string strMessage = string.Empty;
        private const float M_PI = (float)Math.PI;
        public string logOut = string.Empty;
        LoginModels objLogin;
        UIToolbar toolbar;
        private UIView activeTextFieldView;
        private nfloat amountToScroll = 0.0f;
        private nfloat alreadyScrolledAmount = 0.0f;
        private nfloat bottomOfTheActiveTextField = 0.0f;
        private nfloat offsetBetweenKeybordAndTextField = 10.0f;
        private bool isMoveRequired = false;
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="T:RateLinx.iOS.LoginController"/> class.
        /// </summary>
        /// <param name="handle">Handle.</param>
        public LoginController(IntPtr handle) : base(handle)
        {

        }
        /// <summary>
        /// Views the did load.
        /// </summary>
        public override async void ViewDidLoad()
        {
            try
            {
                base.ViewDidLoad();
                toolbar = new UIToolbar(new CoreGraphics.CGRect(new nfloat(0.0f), new nfloat(0.0f), this.View.Frame.Size.Width, new nfloat(44.0f)));
                toolbar.TintColor = UIColor.White;
                toolbar.BarStyle = UIBarStyle.Black;
                toolbar.Translucent = true;
                toolbar.Items = new UIBarButtonItem[]{
                    new UIBarButtonItem(UIBarButtonSystemItem.FlexibleSpace),
                     new UIBarButtonItem(UIBarButtonSystemItem.Done, delegate {
                        if(txtClientId.IsFirstResponder)
                        {
                            txtClientId.ResignFirstResponder();
                        }
                        else if(txtUserName.IsFirstResponder)
                        {
                            txtUserName.ResignFirstResponder();
                        }
                        else
                        {
                            txtPassword.ResignFirstResponder();
                        }
                    })
                };
                txtClientId.KeyboardAppearance = UIKeyboardAppearance.Default;
                txtClientId.InputAccessoryView = toolbar;

                txtUserName.KeyboardAppearance = UIKeyboardAppearance.Default;
                txtUserName.InputAccessoryView = toolbar;

                txtPassword.KeyboardAppearance = UIKeyboardAppearance.Default;
                txtPassword.InputAccessoryView = toolbar;

                UIView viewTop = new UIView(new CGRect(0, 0, View.Frame.Width, 20));
                viewTop.BackgroundColor = UIColor.Red;
                compositeKey = string.Empty;
                UIApplication.SharedApplication.ApplicationIconBadgeNumber = 0;
                var bounds = UIScreen.MainScreen.Bounds;
                //Remove Title
                var navController = base.NavigationController;

                AppDelegate.NavigationController = base.NavigationController;
                navController.NavigationBarHidden = true;

                CommanUtil.userID = string.Empty;
                var gesture = new UITapGestureRecognizer(() =>
               View.EndEditing(true)
                                                        );
                LoginView.AddGestureRecognizer(gesture);

                txtClientId.AttributedPlaceholder = new NSAttributedString(
                    NSBundle.MainBundle.GetLocalizedString(Constants.clientID, null),
                    font: UIFont.FromName(Constants.strFontName, 17.0f),
                    foregroundColor: ConstantsClass.txtForeGroundCLR
                );
                txtUserName.AttributedPlaceholder = new NSAttributedString(
                    NSBundle.MainBundle.GetLocalizedString(Constants.username, null),
                    font: UIFont.FromName(Constants.strFontName, 17.0f),
                    foregroundColor: ConstantsClass.txtForeGroundCLR
                );
                txtPassword.AttributedPlaceholder = new NSAttributedString(
                    NSBundle.MainBundle.GetLocalizedString(Constants.password, null),
                    font: UIFont.FromName(Constants.strFontName, 17.0f),
                    foregroundColor: ConstantsClass.txtForeGroundCLR
                );
                UIView viewClientId = new UIView();
                viewClientId.Frame = ConstantsClass.viewFrmae;
                txtClientId.LeftView = viewClientId;
                txtClientId.LeftViewMode = UITextFieldViewMode.Always;
                UIView viewUserName = new UIView();
                viewUserName.Frame = ConstantsClass.viewFrmae;
                txtUserName.LeftView = viewUserName;
                txtUserName.LeftViewMode = UITextFieldViewMode.Always;
                UIView viewPassword = new UIView();
                viewPassword.Frame = ConstantsClass.viewFrmae;
                txtPassword.LeftView = viewPassword;
                txtPassword.LeftViewMode = UITextFieldViewMode.Always;
                //Get the service Helper Object
                objServicehelper = new ServiceHelper();
                #region Logout and remeber functionality
                postData = NSUserDefaults.StandardUserDefaults.StringForKey(ConstantsClass.usercredentials);
                if (!string.IsNullOrEmpty(postData))
                {
                    objLogin = JsonConvert.DeserializeObject<LoginModels>(postData);
                    if (objLogin != null && objLogin.IsRemember)
                    {
                        rememberMe.On = true;
                        await FnLogout(); //Log out from application 
                    }
                    else
                    {
                        rememberMe.On = false;
                        txtClientId.Text = txtUserName.Text = txtPassword.Text = string.Empty;
                    }
                }
                else
                {
                    rememberMe.On = false;
                    txtClientId.Text = txtUserName.Text = txtPassword.Text = string.Empty;
                }
                #endregion
                // Keyboard popup
                NSNotificationCenter.DefaultCenter.AddObserver
                (UIKeyboard.DidShowNotification, KeyBoardUpNotification);
                // Keyboard Down
                NSNotificationCenter.DefaultCenter.AddObserver
                (UIKeyboard.WillHideNotification, KeyBoardDownNotification);
            }
            catch
            {
                this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
                this.View.Add(this.customAlert);
            }
        }
        /// <summary>
        /// Gets the supported interface orientations.
        /// </summary>
        /// <returns>The supported interface orientations.</returns>
		public override UIInterfaceOrientationMask GetSupportedInterfaceOrientations()
        {
            return UIInterfaceOrientationMask.Portrait;
        }
        /// <summary>
        /// Dids the rotate.
        /// </summary>
        /// <param name="fromInterfaceOrientation">From interface orientation.</param>
		public override void DidRotate(UIInterfaceOrientation fromInterfaceOrientation)
        {
            try
            {
                txtClientId.ResignFirstResponder();
                txtUserName.ResignFirstResponder();
                txtPassword.ResignFirstResponder();

                LoginView.Frame = View.Frame;
                //isOrientationChanged = true;

                if (loadPop != null)
                {
                    loadPop.RemoveFromSuperview();
                    loadPop = null;
                    loadPop = new LoadingOverlay(View.Bounds);
                    View.AddSubview(loadPop);
                }
            }
            catch
            {
                Console.WriteLine(Constants.strErrorOccured);
            }
        }
        /// <summary>
        /// Views the did appear.
        /// </summary>
        /// <param name="animated">If set to <c>true</c> animated.</param>
		public override void ViewDidAppear(bool animated)
        {
            base.ViewDidAppear(animated);
        }
        #region KeyBoardDidShow
        private void KeyBoardUpNotification(NSNotification notification)
        {

            nfloat parentViewheight = View.Frame.Height;
            // get the keyboard size
            CoreGraphics.CGRect notificationBounds = UIKeyboard.BoundsFromNotification(notification);

            // Find what opened the keyboard
            foreach (UIView view in this.View.Subviews)
            {
                foreach (UIView view1 in view)
                {
                    foreach (UIView view2 in view1)
                    {
                        if (view2 != null && view2.IsFirstResponder)
                        {
                            activeTextFieldView = view;
                        }
                    }
                }
            }
            if (parentViewheight > 400)
            {
                if (activeTextFieldView != null)
                {
                    // Bottom of the controller = initial position + height + offset      
                    bottomOfTheActiveTextField = (-150 + activeTextFieldView.Frame.Y + activeTextFieldView.Frame.Height + offsetBetweenKeybordAndTextField);

                    // Calculate how far we need to scroll
                    amountToScroll = (notificationBounds.Height - (View.Frame.Size.Height - bottomOfTheActiveTextField));

                    // Perform the scrolling
                    if (amountToScroll > 0)
                    {
                        bottomOfTheActiveTextField -= alreadyScrolledAmount;
                        amountToScroll = (notificationBounds.Height - (View.Frame.Size.Height - bottomOfTheActiveTextField));
                        alreadyScrolledAmount += amountToScroll;
                        isMoveRequired = true;
                        ScrollTheView(isMoveRequired);
                    }
                    else
                    {
                        isMoveRequired = false;
                    }
                }
            }
        }
        /// <summary>
        /// Keies the board down notification.
        /// </summary>
        /// <param name="notification">Notification.</param>
		private void KeyBoardDownNotification(NSNotification notification)
        {
            bool wasViewMoved = !isMoveRequired;
            if (isMoveRequired)
            {
                ScrollTheView(wasViewMoved);
            }
        }
        /// <summary>
        /// Scrolls the view.
        /// </summary>
        /// <param name="move">If set to <c>true</c> move.</param>
		private void ScrollTheView(bool move)
        {
            // scroll the view up or down
            UIView.BeginAnimations(string.Empty, System.IntPtr.Zero);
            UIView.SetAnimationDuration(0.3);

            CoreGraphics.CGRect frame = View.Frame;

            if (move)
            {
                frame.Y -= amountToScroll;
            }
            else
            {
                frame.Y += alreadyScrolledAmount;
                amountToScroll = 0;
                alreadyScrolledAmount = 0;
            }

            View.Frame = frame;
            UIView.CommitAnimations();
        }
        #endregion

        /// <summary>
        /// Buttons the login touch up inside.
        /// </summary>
        /// <param name="sender">Sender.</param>
        partial void BtnLogin_TouchUpInside(UIButton sender)
        {
            FnLogin();
        }

        /// <summary>
        /// Manages the navigation.
        /// </summary>
        /// <param name="tapGesture">Tap gesture.</param>
        public void ManageNavigation(UITapGestureRecognizer tapGesture)
        {
            if (tapGesture.View.Equals(btnLogin))
            {
                this.PerformSegue("testloginsegue", null);
            }
            else
            {

            }
        }

        /// <summary>
        /// Login functionality
        /// </summary>
        public async void FnLogin()
        {
            try
            {
                CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
                //------------- Login Fields Validation check------//
                validationMessage = IsRequiredValidated();
                if (!string.IsNullOrEmpty(validationMessage))
                {
                    Toast.MakeText(validationMessage).SetDuration(Constants.toastDuration).Show();
                    return;
                }
                else
                {
                    if (Reachability.InternetConnectionStatus())
                    {
                        if (objLogin == null)
                        {
                            objLogin = new LoginModels();
                        }
                        if (loadPop == null)
                        {
                            loadPop = new LoadingOverlay(bounds);
                        }
                        View.Add(loadPop);
                        //Parameters 
                        string[] strApps = { NSBundle.MainBundle.GetLocalizedString("shipping", null) };
                        objLogin.ClientID = txtClientId.Text;
                        objLogin.UserName = txtUserName.Text;
                        objLogin.Password = txtPassword.Text;
                        objLogin.FromDevice = NSBundle.MainBundle.GetLocalizedString("iOS", null);
                        objLogin.Apps = strApps;
                        objLogin.IsRemember = rememberMe.On;
                        postData = JsonConvert.SerializeObject(objLogin);
                        //Login
                        isRemember = rememberMe.On;
                        //Save Login Details in local storage
                        NSUserDefaults.StandardUserDefaults.SetString(postData, ConstantsClass.usercredentials);
                        await Task.Delay(1000);
                        isLogin = await FnIsLogin(postData);
                        if (isLogin)
                        {
                            CommanUtil.stopPooling = false;
                            if (loadPop != null)
                            {
                                loadPop.Hide();
                                loadPop = null;
                            }
                            if (!string.IsNullOrEmpty(compositeKey))
                            {
                                RedirectFromLoginToShipmentDetail(compositeKey); //Push Notification
                            }
                            else
                            {
                                this.PerformSegue("SegueFromLoginToHome", null);
                            }
                        }
                        else
                        {
                            this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, strMessage, true, this, "", 1);
                            this.View.Add(this.customAlert);
                            if (loadPop != null)
                            {
                                loadPop.Hide();
                                loadPop = null;
                            }
                        }
                    }
                    else
                    {
                        this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.isOnline, true, this, "", 1);
                        this.View.Add(this.customAlert);
                        if (loadPop != null)
                        {
                            loadPop.Hide();
                            loadPop = null;
                        }
                        return;
                    }
                }
            }
            catch
            {
                if (loadPop != null)
                {
                    loadPop.Hide();
                    loadPop = null;
                }
            }
        }

        /// <summary>
        /// Login Method
        /// </summary>
        /// <param name="loginRequestData">login Request Data</param>
        /// <returns></returns>
        private async Task<bool> FnIsLogin(string loginRequestData)
        {
            try
            {
                objServicehelper = new ServiceHelper();
                var webView = new UIWebView();
                methodName = APIMethods.auth;
                strMessage = Constants.strErrorOccured;
                strResponse = await objServicehelper.PostRequestJson(loginRequestData, methodName, "", false);
                if (!string.IsNullOrEmpty(strResponse))
                {
                    // create json object that holds the api values
                    jobject = JObject.Parse(strResponse);
                    if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
                    {
                        //var versionNumber = NSBundle.MainBundle.InfoDictionary[new NSString("CFBundleShortVersionString")].ToString();
                        //if (FnCompareVersion(Convert.ToString(jobject["MinVersionReq"]), versionNumber))
                        //{
                        strToken = Convert.ToString(jobject["Token"]);
                        //Defining the local storage
                        CommanUtil.tokenNo = strToken;
                        CommanUtil.loginTime = DateTime.Now;
                        CommanUtil.stopPooling = false;
                        //Is push notification enable
                        if (IsPushNotification())
                        {
                            //Checking Account Settings
                            await FnGetAccountsDetail(strToken);
                            if (objAccountSettings != null)
                            {
                                CommanUtil.UserPermissions = objAccountSettings.Permissions;
                                CommanUtil.userID = objAccountSettings.UserID;
                                CommanUtil.ViewAs = objAccountSettings.ClientType;
                                return true;
                            }
                            else
                            {
                                return false;
                            }
                        }
                        else
                        {
                            return false;
                        }
                        //}
                        //else
                        //{
                        //    //Redirect to app store to upgrade the app
                        //    webView.ShouldStartLoad = HandleShouldStartLoad;
                        //    webView.LoadRequest(new NSUrlRequest(new NSUrl(Constants.appStoreURI)));
                        //    return false;
                        //}
                    }
                    else
                    {
                        strMessage = Convert.ToString(jobject[Constants.strErrorMessage]);
                        // Alerts.HideBusyLoader(); //Loader
                        objAccountSettings = null;
                        if (loadPop != null)
                        {
                            loadPop.Hide();
                            loadPop = null;
                        }
                        Toast.MakeText(strMessage).SetDuration(Constants.toastDuration).Show();
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Handles the should start load.
        /// </summary>
        /// <returns><c>true</c>, if should start load was handled, <c>false</c> otherwise.</returns>
        /// <param name="webView">Web view.</param>
        /// <param name="request">Request.</param>
        /// <param name="navigationType">Navigation type.</param>
        bool HandleShouldStartLoad(UIWebView webView, NSUrlRequest request, UIWebViewNavigationType navigationType)
        {
            UIApplication.SharedApplication.OpenUrl(request.Url);
            //SidebarController.CloseMenu();
            return true;
        }

        /// <summary>
        /// Compare app version
        /// </summary>
        /// <param name="strMinVersion">new app version</param>
        /// <param name="versionNumber">installed app version</param>
        private bool FnCompareVersion(string strMinVersion, string versionNumber)
        {
            string[] minVersionReq_Arr = strMinVersion.Split('.');
            int minVersionReq_int = (Convert.ToInt32(minVersionReq_Arr[0] + minVersionReq_Arr[1] + minVersionReq_Arr[2]));
            var appVersion_Arr = versionNumber.Split('.');
            int appVersion = (Convert.ToInt32(appVersion_Arr[0] + appVersion_Arr[1] + appVersion_Arr[2]));
            if (minVersionReq_int <= appVersion)
            {
                return false;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        ///  Method to hide charges when Driver is logged in
        /// </summary>
        /// <param name="loginToken">Token No generated from login API</param>
        /// <returns></returns>
        private async Task FnGetAccountsDetail(string loginToken)
        {
            try
            {
                if (Reachability.InternetConnectionStatus())
                {
                    string searchResult = string.Empty;
                    methodName = APIMethods.getAccountDetails;
                    if (objServicehelper == null)
                    {
                        objServicehelper = new ServiceHelper();
                    }
                    strResponse = await objServicehelper.GetRequest(loginToken, methodName, true);
                    if (strResponse != null)
                    {
                        jobject = JObject.Parse(strResponse);
                        if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
                        {
                            // convert json to own object that holds the api response  
                            objAccountSettings = JsonConvert.DeserializeObject<AccountSettings>(strResponse);
                            List<string> permission = objAccountSettings.Permissions;
                            searchResult = permission.Where(x => x.Equals("DRIVERROLE")).FirstOrDefault();
                            if (!string.IsNullOrEmpty(searchResult))
                            {
                                CommanUtil.isShowCharges = false;
                            }
                            else
                            {
                                CommanUtil.isShowCharges = true;
                            }
                        }
                        else
                        {
                            strMessage = Convert.ToString(jobject[Constants.strErrorMessage]);
                            objAccountSettings = null;
                            await Util.ErrorLog(APIMethods.getAccountDetails, strMessage, loginToken);
                            Toast.MakeText(strMessage).SetDuration(Constants.toastDuration).Show();
                        }
                        strResponse = string.Empty;
                    }
                }
                else
                {
                    Toast.MakeText(Constants.isOnline).SetDuration(Constants.toastDuration).Show();
                    loadPop.Hide();
                    objAccountSettings = null;
                    loadPop = null;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Login Fields Validation check Validate the text fields
        /// </summary>
        /// <returns></returns>
        private string IsRequiredValidated()
        {
            try
            {
                validationMessage = string.Empty;
                //-----ClientID field----//
                if (string.IsNullOrEmpty(txtClientId.Text))
                {
                    validationMessage = Constants.strClientID;
                }
                else if (txtClientId.RetainCount > 50)
                {
                    validationMessage = Constants.strClientIDLength;
                }
                //-----User Name field----//
                else if (string.IsNullOrEmpty(txtUserName.Text))
                {
                    validationMessage = Constants.strUserId;
                }
                else if (txtUserName.RetainCount > 50)
                {
                    validationMessage = Constants.strUserIdLength;
                }
                //-----Password field----//
                else if (string.IsNullOrEmpty(txtPassword.Text))
                {
                    validationMessage = Constants.strPassword;
                }
                return validationMessage;
            }
            catch
            {
                return null;
            }
        }


        /// <summary>
        /// Logout Feature while Remember me true
        /// </summary>
        public async Task FnLogout()
        {
            try
            {
                txtClientId.Text = objLogin.ClientID;
                txtUserName.Text = objLogin.UserName;
                txtPassword.Text = objLogin.Password;
                if (string.IsNullOrEmpty(logOut))
                {
                    CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
                    loadPop = new LoadingOverlay(bounds);
                    View.Add(loadPop);
                    isLogin = await FnIsLogin(postData);
                    if (isLogin)
                    {
                        this.PerformSegue("SegueFromLoginToHome", null);
                    }
                    else
                    {
                        loadPop.Hide();
                        loadPop = null;
                        Toast.MakeText(Constants.strCredentials).SetDuration(Constants.toastDuration).Show();
                    }
                }
                else
                {
                    //If user forefully logged out from application
                   // txtClientId.Text = txtUserName.Text = txtPassword.Text = string.Empty;
                }
            }
            catch
            {
                Toast.MakeText(Constants.strCredentials).SetDuration(Constants.toastDuration).Show();
            }
        }

		#region Push Notification
		/// <summary>
		/// Push Notification
		/// </summary>
		private bool IsPushNotification()
		{
			try
			{
				if (!string.IsNullOrEmpty(strToken))
				{
					AppDelegate objDelegate = new AppDelegate();
					objDelegate.PushRegisterd();
					return true;
				}
				else
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strDeviceReady, true, this, "", 1);
					this.View.Add(this.customAlert);
					return false;
				}
			}
			catch
			{
				throw;
			}
		}

        /// <summary>
        /// When Click on Push Notification Message in App delegate file 
        /// </summary>
        public async Task NotificationClick(string notificationData)
        {
            try
            {
                postData = NSUserDefaults.StandardUserDefaults.StringForKey(ConstantsClass.usercredentials);
                // Alerts.showBusyLoader(this); //Loader
                if (!string.IsNullOrEmpty(notificationData))
                {
                    clientID = notificationData.Split('#')[2];
                    loadNum = notificationData.Split('#')[1];
                    slideNo = notificationData.Split('#')[3];
                    compositeKey = clientID + "|" + loadNum + "|" + ManageNavigationPage(slideNo);
                    if (!string.IsNullOrEmpty(postData))
                    {
                        LoginModels notifyLogin = JsonConvert.DeserializeObject<LoginModels>(postData);
                        if (notifyLogin.IsRemember)
                        {
                            //if (string.IsNullOrEmpty(CommanUtil.tokenNo))
                            //{
                            isLogin = await FnIsPushNotificationLogin(postData);
                            if (isLogin)
                            {
                                RedirectFromLoginToShipmentDetail(compositeKey);
                            }
                            else
                            {
                                this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strCredentials, true, this, "", 1);
                                this.View.Add(this.customAlert);
                            }
                            // }
                            ////If application is in foreground or Active
                            //else if (!string.IsNullOrEmpty(CommanUtil.tokenNo))
                            //{
                            //    RedirectFromLoginToShipmentDetail(compositeKey);
                            //}
                            //else if (!string.IsNullOrEmpty(CommanUtil.tokenNo))
                            //{
                            //    RedirectFromLoginToShipmentDetail(compositeKey);
                            //}
                        }
                        else
                        {
                            //If we get null record from notification stay on the Login page
                        }
                    }
                    else
                    {
                        //If we get null record from notification stay on the Login page
                    }

                }
                else
                {
                    //If we get null record from notification stay on the Login page
                }
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
            }
        }

		/// <summary>
		/// Segues from dashborad to shipment detail page.
		/// </summary>
		/// <param name="compositeValue">Composite key.</param>
		public void RedirectFromLoginToShipmentDetail(string compositeValue)
		{
			try
			{
				UIStoryboard board = UIStoryboard.FromName("Main", null);
				//var login = board.InstantiateInitialViewController();
				var ShipmentDetailController = (ShipmentDetailController)board.InstantiateViewController("ShipmentDetailController");
				ShipmentDetailController.compositeKey = compositeKey;
				AppDelegate.NavigationController.PushViewController(ShipmentDetailController, true);
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Manages the navigation page funcationality for Shipment Detail Page
		/// </summary>
		/// <returns>The navigation page.</returns>
		/// <param name="slideNumber">Slide number.</param>
		public string ManageNavigationPage(string slideNumber)
		{
			string pageDetail = string.Empty;
			try
			{
				if (!string.IsNullOrEmpty(slideNumber))
				{
					if (slideNumber.Trim() == "0")
					{
						pageDetail = ConstantsClass.shipping;
					}
					else if (slideNumber.Trim() == "1")
					{
						pageDetail = ConstantsClass.strSupport;
					}
					else if (slideNumber.Trim() == "2")
					{
						pageDetail = ConstantsClass.strBid;
					}
					else
					{
						pageDetail = ConstantsClass.strReply;
					}
				}
				else
				{
					pageDetail = ConstantsClass.shipping;
				}
				return pageDetail;
			}
			catch
			{
				return pageDetail;
			}
		}

		/// <summary>
        /// Fns the is push notification login.
        /// </summary>
        /// <returns>The is push notification login.</returns>
        /// <param name="strLoginDetails">login details.</param>
        public async Task<bool> FnIsPushNotificationLogin(string strLoginDetails)
		{
			try
			{
				if (Reachability.InternetConnectionStatus())
				{
					objServicehelper = new ServiceHelper();
					//Method Name
					methodName = APIMethods.auth;
                    strResponse = await objServicehelper.PostRequestJson(strLoginDetails, methodName, "", false);
					if (!string.IsNullOrEmpty(strResponse))
					{
						// create json object that holds the api values
						jobject = JObject.Parse(strResponse);
						if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
						{
                            //var versionNumber = NSBundle.MainBundle.InfoDictionary[new NSString("CFBundleVersion")].ToString();
                            //Defining the local storage
                            strToken = CommanUtil.tokenNo = Convert.ToString(jobject["Token"]);
                            CommanUtil.loginTime = DateTime.Now;
                            CommanUtil.stopPooling = false;
							//Checking Account Settings
							string accountresult = await FnGetNotificationAccounts(CommanUtil.tokenNo);
							if (string.IsNullOrEmpty(accountresult))
							{
								return true;
							}
							else
							{
								return false;
							}
						}
						else
						{
                            //await Util.ErrorLog(APIMethods.auth, Convert.ToString(jobject[Constants.strErrorMessage]), strToken);
							this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Convert.ToString(jobject[Constants.strErrorMessage]), true, this, "", 1);
							this.View.Add(this.customAlert);
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.isOnline, true, this, "", 1);
					this.View.Add(this.customAlert);
					return false;
				}
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		///  Method to hide charges when Driver is logged in
		/// </summary>
        /// <param name="strLoginToken">Token No generated from login API</param>
		/// <returns></returns>
		private async Task<string> FnGetNotificationAccounts(string strLoginToken)
		{
			try
			{
				string searchResult = string.Empty;
				if (Reachability.InternetConnectionStatus())
				{
					methodName = APIMethods.getAccountDetails;
                    string strAccountResponse = await objServicehelper.GetRequest(strLoginToken, methodName, true);
					if (strAccountResponse != null)
					{
						jobject = JObject.Parse(strAccountResponse);
						if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
						{
							// convert json to own object that holds the api response  
							objAccountSettings = JsonConvert.DeserializeObject<AccountSettings>(strAccountResponse);
							List<string> permission = objAccountSettings.Permissions;
							searchResult = permission.Where(x => x.Equals("DRIVERROLE")).FirstOrDefault();
							if (!string.IsNullOrEmpty(searchResult))
							{
								CommanUtil.isShowCharges = false;
							}
							else
							{
								CommanUtil.isShowCharges = true;
							}
							CommanUtil.userID = objAccountSettings.UserID;
							CommanUtil.ViewAs = objAccountSettings.ClientType;
                            CommanUtil.UserPermissions = objAccountSettings.Permissions;
							searchResult = string.Empty;
						}
						else
						{
							CommanUtil.userID = string.Empty;
							CommanUtil.ViewAs = string.Empty;
							objAccountSettings = null;
							strMessage = Convert.ToString(jobject[Constants.strErrorMessage]);
							searchResult = strMessage;
                            await Util.ErrorLog(NSBundle.MainBundle.GetLocalizedString("accountDetails", null), strMessage, strLoginToken);
							//Print Message
							this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, strMessage, true, this, "", 1);
							this.View.Add(this.customAlert);
						}
						strAccountResponse = string.Empty;
					}
				}
				else
				{
					objAccountSettings = null;
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.isOnline, true, this, "", 1);
					this.View.Add(this.customAlert);
					return Constants.isOnline;
				}
				return searchResult;
			}
			catch
			{
                return "";
			}
		}

		#endregion
	}

}
