using Foundation;
using System;
using UIKit;

namespace RateLinx.iOS
{
    public partial class CustomAlertPopupController : UIViewController
    {
        public CustomAlertPopupController (IntPtr handle) : base (handle)
        {
        }

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();

			CustomAlertPopup.BackgroundColor = UIColor.Clear;

		}

    }
}