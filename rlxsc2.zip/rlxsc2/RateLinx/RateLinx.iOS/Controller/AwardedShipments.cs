using Foundation;
using System;
using UIKit;

namespace RateLinx.iOS
{
    public partial class AwardedShipments : UITabBarItem
    {
        public AwardedShipments (IntPtr handle) : base (handle)
        {
        }
    }
}