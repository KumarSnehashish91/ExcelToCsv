using Foundation;
using System;
using UIKit;

namespace RateLinx.iOS
{
	public partial class InvoiceWebViewController : UIViewController
	{
		#region Variable Declaration

		public string fileURL;
		UITapGestureRecognizer tapGesture;

		#endregion

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.InvoiceWebViewController"/> class.
		/// </summary>
		/// <param name="handle">Handle.</param>
		public InvoiceWebViewController(IntPtr handle) : base(handle)
		{
		}

		/// <summary>
		/// Views the did load.
		/// </summary>
		public override void ViewDidLoad()
		{
			try
			{
				base.ViewDidLoad();
				invoiceWebView.LoadRequest(new NSUrlRequest(new NSUrl(fileURL)));
				invoiceWebView.ScalesPageToFit = true;
				TapGestureRecognizer();
			}
			catch
			{
				throw;
			}
		}

		public override UIInterfaceOrientationMask GetSupportedInterfaceOrientations()
		{
			return UIInterfaceOrientationMask.Portrait;
		}

		/// <summary>
		/// Taps the gesture recognizer.
		/// </summary>
		void TapGestureRecognizer()
		{

			tapGesture = new UITapGestureRecognizer(ManageNavigation);
			imgBack.AddGestureRecognizer(tapGesture);
		}

		/// <summary>
		/// Manages the navigation.
		/// </summary>
		void ManageNavigation()
		{
			try
			{
				if (tapGesture.View.Equals(imgBack))
				{
					this.NavigationController.PopViewController(true);
				}
				else
				{

				}
			}
			catch
			{
				throw;


			}

		}
	}
}