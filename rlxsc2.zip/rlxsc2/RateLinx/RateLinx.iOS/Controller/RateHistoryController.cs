using Foundation;
using System;
using UIKit;
using CoreGraphics;
using System.Collections.Generic;
using RateLinx.Helper;
using RateLinx.Models;
using System.Threading.Tasks;
using ZXing.Mobile;
using Cirrious.FluentLayouts.Touch;
using System.Globalization;
using System.Drawing;

namespace RateLinx.iOS
{
	public partial class RateHistoryController : UIViewController
	{
		#region Variable Declaration

		UITapGestureRecognizer tapGesture = null;
		PickerDataModel pickerDataModel = null;
		UIPickerView pickerView = null;
		UIButton doneButton = null;
		ModalPickerViewController modalPicker = null;
		MobileBarcodeScanner objScanner = null;
		Filters objFilters = null;
		UIView viewPicker, menuView = null;
		bool redirect;
		CustomPopup customAlert = null;

		private nfloat scroll_amount = 0.0f;    // amount to scroll

		UIToolbar toolbar;

		PlaceholderTextView txtViewClientId = new PlaceholderTextView();

		PlaceholderTextView txtViewLoadNo = new PlaceholderTextView();

		#endregion
		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.RateHistoryController"/> class.
		/// </summary>
		/// <param name="handle">Handle.</param>
		public RateHistoryController (IntPtr handle) : base (handle)
		{
			redirect = true;
		}
		/// <summary>
		/// Views the did load.
		/// </summary>
		public override void ViewDidLoad()
		{
			try
			{
				base.ViewDidLoad();

				lblCopyRight.Text = Util.GetCopyRight();
				//Getting the menu view 
                menuView = new MenuViewController(View).DisplayMenuView(null, null, this, null, null,imgMenu);
				if (!Reachability.InternetConnectionStatus())
				{
					UIView.Animate(0.3,
					() =>
					{
						menuView.Frame = new CGRect(-800, 20, View.Frame.Width, View.Frame.Height - 20);

					});
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
					this.View.Add(this.customAlert);
				}

				txtClientID.Hidden = true;
				txtLoadNo.Hidden = true;
				txtViewClientId.Placeholder = "Client ID";
				txtViewClientId.Text = "Client ID";
				txtViewClientId.Layer.BorderWidth = 0.7f;
				txtViewClientId.Layer.CornerRadius = 5;
				txtViewClientId.Font = UIFont.FromName(Constants.strFontName, 15f);
			

				txtViewLoadNo.Placeholder = "Load Number";
				txtViewLoadNo.Text = "Load Number";
				txtViewLoadNo.Layer.BorderWidth = 0.7f;
				txtViewLoadNo.Layer.CornerRadius = 5;
				txtViewLoadNo.Font = UIFont.FromName(Constants.strFontName, 15f);

				toolbar = new UIToolbar(new CoreGraphics.CGRect(new nfloat(0.0f), new nfloat(0.0f), this.View.Frame.Size.Width, new nfloat(44.0f)));
			    toolbar.TintColor = UIColor.White;
			    toolbar.BarStyle = UIBarStyle.Black;
			    toolbar.Translucent = true;
				toolbar.Items = new UIBarButtonItem[]{
					 new UIBarButtonItem(UIBarButtonSystemItem.FlexibleSpace),
		 			 new UIBarButtonItem(UIBarButtonSystemItem.Done, delegate {
						if(txtViewClientId.IsFirstResponder)
						{
							txtViewClientId.ResignFirstResponder();
						}
						else
						{
							txtViewLoadNo.ResignFirstResponder();
						}
					})
				};
				txtViewClientId.KeyboardAppearance = UIKeyboardAppearance.Default;
				txtViewClientId.InputAccessoryView = toolbar;

				txtViewLoadNo.KeyboardAppearance = UIKeyboardAppearance.Default;
				txtViewLoadNo.InputAccessoryView = toolbar;

				txtOriginDate.Layer.BorderWidth = 0.7f;
				txtEndDate.Layer.BorderWidth = 0.7f;
				txtOriginDate.Layer.CornerRadius = 5;
				txtEndDate.Layer.CornerRadius = 5;
				//txtViewClientId.AllEditingEvents +=delegate {
				//	Console.WriteLine("Editing");
				//	RectangleF frame = (RectangleF)viewRateHistoryParent.Frame;
				//	viewRateHistoryParent.Frame = frame;

				//};

				RateHistoryView.AddSubview(txtViewClientId);
				RateHistoryView.AddSubview(txtViewLoadNo);

				//Hide Popups and Manage Navigation
				FnHidePopupUI();
				//Set border in Action button
				btnSelectAction.Layer.BorderWidth = 1;
				btnSelectAction.Layer.CornerRadius = 4;
				btnSelectAction.Layer.BorderColor = UIColor.LightGray.CGColor;

				btnScan.Layer.CornerRadius = 5;
				btnSearchHistory.Layer.CornerRadius = 5;

				if (CommanUtil.ViewAs.ToUpper() == Constants.strCustomer.ToUpper())
				{
					btnSelectAction.SetTitle("  " + Util.customerAution[1], UIControlState.Normal);
				}
				else
				{
					btnSelectAction.SetTitle("  " + Util.carrierAution[2], UIControlState.Normal);
				}

				string originDate = DateTime.Now.AddDays(-7).ToString(ConstantsClass.dateFormatMMDDYYYY);
				string endDate = DateTime.Now.ToString(ConstantsClass.dateFormatMMDDYYYY);

				txtOriginDate.Text = originDate.Contains("-") ? originDate.Replace('-', '/') : originDate;

				txtEndDate.Text = endDate.Contains("-") ? endDate.Replace('-', '/') : endDate;

				NSNotificationCenter.DefaultCenter.AddObserver
				(UIKeyboard.DidShowNotification, KeyBoardUpNotification);
				// Keyboard Down
				NSNotificationCenter.DefaultCenter.AddObserver
				(UIKeyboard.WillHideNotification, KeyBoardDownNotification);
				
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}

		public override UIInterfaceOrientationMask GetSupportedInterfaceOrientations()
		{
			return UIInterfaceOrientationMask.Portrait;
		}
		public override void DidRotate(UIInterfaceOrientation fromInterfaceOrientation)
		{
			RectangleF frame = (RectangleF)txtClientID.Frame;
			txtViewClientId.Frame = frame;

			RectangleF frameLoadNo = (RectangleF)txtLoadNo.Frame;
			txtViewLoadNo.Frame = frameLoadNo;

			if (Util.isMenuVisible)
			{
				if (menuView != null)
				{
					menuView.RemoveFromSuperview();
					menuView = null;
				}
                menuView = new MenuViewController(View).DisplayMenuView(null, null, this, null,null, imgMenu);
				View.AddSubview(menuView);
				menuView.Frame = new CGRect(0, 0, View.Frame.Width, View.Frame.Height);
			}
		}
		public override void ViewDidAppear(bool animated)
		{
			base.ViewDidAppear(animated);

			RectangleF frame = (RectangleF)txtClientID.Frame;
			txtViewClientId.Frame = frame;

			RectangleF frameLoadNo = (RectangleF)txtLoadNo.Frame;
			txtViewLoadNo.Frame = frameLoadNo;

		}
		private void KeyBoardUpNotification(NSNotification notification)
		{
			nfloat parentViewheight = View.Frame.Height;
			CGRect notificationBounds = UIKeyboard.BoundsFromNotification(notification);
			if (parentViewheight > 400)
			{
				if (txtViewLoadNo.IsFirstResponder)
				{
					if ((viewRateHistoryParent.Frame.Height - txtViewLoadNo.Frame.Y) > (notificationBounds.Height + 50))
					{
						scroll_amount = 0;
					}
					else if ((viewRateHistoryParent.Frame.Height - txtViewLoadNo.Frame.Y) < (notificationBounds.Height + 50))
					{
						scroll_amount = (notificationBounds.Height + 50) - (viewRateHistoryParent.Frame.Height - txtViewLoadNo.Frame.Y);
					}
					else
					{ }
				}
				if (txtViewClientId.IsFirstResponder)
				{
					if ((viewRateHistoryParent.Frame.Height - txtViewClientId.Frame.Y) > (notificationBounds.Height + 50))
					{
						scroll_amount = 0;
					}
					else if ((viewRateHistoryParent.Frame.Height - txtViewClientId.Frame.Y) < (notificationBounds.Height + 50))
					{
						scroll_amount = (notificationBounds.Height + 50) - (viewRateHistoryParent.Frame.Height - txtViewClientId.Frame.Y);
					}
					else
					{ }
				}

				ScrollTheView();

				//if (txtViewLoadNo.IsFirstResponder && scroll_amount == 0)
				//{
				//	moveViewUp = true;
				//	scroll_amount = 100;

				//	ScrollTheView();
				//}
				//else if (txtViewLoadNo.IsFirstResponder && scroll_amount > 0)
				//{

				//}
				//else if (txtViewClientId.IsFirstResponder && scroll_amount == 0)
				//{
				//	scroll_amount = 200;

				//	ScrollTheView();
				//}
				//else if (txtViewClientId.IsFirstResponder && scroll_amount > 0)
				//{
				//	scroll_amount = 100;

				//	ScrollTheView();
				//}
				//else
				//{

				//}
			}

		}


		private void KeyBoardDownNotification(NSNotification notification)
		{
			
			if (scroll_amount > 0)
			{
				viewRateHistoryParent.Frame = new CGRect(0, 20, View.Frame.Width, View.Frame.Height);
			}
			else
			{
				scroll_amount = 0;
			}
			//ScrollTheView();
		}

		public void ScrollTheView()
		{

			UIView.BeginAnimations(string.Empty, System.IntPtr.Zero);
			UIView.SetAnimationDuration(0.3);

			RectangleF frame = (RectangleF)viewRateHistoryParent.Frame;

			frame.Y = 20;
			if (scroll_amount != 0)
			{
				frame.Y = -(float)scroll_amount;
			}
			viewRateHistoryParent.Frame = frame;

			UIView.CommitAnimations();
		}



		/// <summary>
		/// Hide Picker View, Keyboard and navigate to other pages
		/// </summary>
		public void FnHidePopupUI()
		{
			try {
				tapGesture = new UITapGestureRecognizer (() => {
					if (viewPicker != null) {
						viewPicker.Hidden = true;
						pickerView.Hidden = true;
						doneButton.Hidden = true;

					} 
					if(modalPicker !=null)
					{
						DismissViewController(true, null);
					}
					View.EndEditing (true);
				});
				tapGesture.CancelsTouchesInView = false;
				RateHistoryView.AddGestureRecognizer (tapGesture);
				View.AddGestureRecognizer (tapGesture);
				//Navigation
				tapGesture = new UITapGestureRecognizer (ManageNavigation);
				imgMenu.AddGestureRecognizer (tapGesture);
				tapGesture = new UITapGestureRecognizer (ManageNavigation);
				imgHome.AddGestureRecognizer (tapGesture);
				//Select Date for search

			}
			catch {
				throw;
			}

		}
		partial void BtnFromDate_TouchUpInside(UIButton sender)
		{
			OpenCalender(1);
		}


		partial void BtnToDate_TouchUpInside(UIButton sender)
		{
            OpenCalender(2);
		}



		/// <summary>
		/// Manages the navigation.
		/// </summary>
		/// <param name="tapGesture">Tap gesture.</param>
		public void ManageNavigation(UITapGestureRecognizer tapGesture)
		{
			redirect = false;
			if (tapGesture.View.Equals(imgHome))
			{
				this.PerformSegue("RateHistoryToHomeSegue", null);
			}
			else
			{
				Util.isMenuVisible = true;
                menuView = new MenuViewController(View).DisplayMenuView(null, null, this, null, null,imgMenu);
				View.AddSubview(menuView);

				UIView.Animate(0.3,
				() =>
				{
					if (menuView != null)
					{
						menuView.Frame = new CGRect(0, 0, View.Frame.Width, View.Frame.Height - 20);
					}

				});
			}
		}

		/// <summary>
		/// Opens the calender.
		/// </summary>
		/// <param name="type">Type.</param>
		public void OpenCalender(int type)
		{
			try {
				if (redirect)
				{
					modalPicker = new ModalPickerViewController(ModalPickerType.Date, "", this)
					{
						HeaderBackgroundColor = Constants.btnColorRed,
						HeaderTextColor = UIColor.White,
						TransitioningDelegate = new ModalPickerTransitionDelegate(),
						ModalPresentationStyle = UIModalPresentationStyle.Custom
					};

					modalPicker.DatePicker.Mode = UIDatePickerMode.Date;
					modalPicker.OnModalPickerDismissed += (s, ea) =>
					{
						var dateFormatter = new NSDateFormatter()
						{
							DateFormat = ConstantsClass.dateFormatMMDDYYYY
						};
						if (type.Equals(1))
						{
							//DateTime date11 = dateFormatter.Parse(modalPicker.DatePicker.Date);
							txtOriginDate.Text = dateFormatter.ToString(modalPicker.DatePicker.Date);
						}
						else
						{
							txtEndDate.Text = dateFormatter.ToString(modalPicker.DatePicker.Date);
						}
					};
					this.PresentViewController(modalPicker, true, null);
				}
			} catch {
				throw;
			}
		}
		/// <summary>
		/// Scan button event to scan Load Number from Barcode.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnScan_TouchUpInside (UIButton sender)
		{
			try
			{
                if (CommanUtil.IsTimeOut())
                {
                    ScanBarcode();
                }
			}
			catch (Exception ex)
			{
				string message = ex.Message;
				throw ex;
			}
		}

		/// <summary>
		/// Scans the barcode.
		/// </summary>
		/// <returns>The barcode.</returns>
		public async Task ScanBarcode()
		{
			try
			{
				objScanner = new MobileBarcodeScanner(this);
				var result = await objScanner.Scan(true);
				if(result !=null)
				{
					txtViewLoadNo.Text =result.Text;
				}

			}
			catch
			{
				throw;
			}
		}

		//partial void BtnSelectAction_TouchUpInside(UIButton sender)
		//{
		//	throw new NotImplementedException();
		//}

		/// <summary>
		/// Buttons the select action.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnSelectAction_TouchUpInside (UIButton sender)
		{
			try
			{
				UIView pickerParentView = new UIView();
				string selectedValue = string.Empty;
				int yPosition = (int)(View.Frame.Height - 180) / 2;
				viewPicker = new UIView(new CGRect (20, yPosition - 100, View.Frame.Width - 40, 210));
				viewPicker.BackgroundColor = UIColor.White;
				viewPicker.Layer.CornerRadius = 10;
				viewPicker.Layer.BorderWidth = 1;
				viewPicker.Layer.BorderColor = UIColor.Black.CGColor;
				pickerView = new UIPickerView (new CGRect (0, 0, viewPicker.Frame.Width, 180));
				pickerView.BackgroundColor = UIColor.White;

				pickerView.ShowSelectionIndicator = true;
				// create our simple picker model
				if(CommanUtil.ViewAs.ToUpper() ==Constants.strCustomer.ToUpper())
				{
					pickerDataModel = new PickerDataModel (Util.customerAution);
				}
				else
				{
					pickerDataModel = new PickerDataModel (Util.carrierAution);
				}
				// set it on our picker class
				pickerView.Model = pickerDataModel;
				// Create a 'done' button for the toolbar and add it to the toolbar
				doneButton = new UIButton (new CGRect (0, 180, viewPicker.Frame.Width, 30));
				doneButton.BringSubviewToFront (View);
				doneButton.SetTitle (ConstantsClass.strDone, UIControlState.Normal);
				doneButton.BackgroundColor = ConstantsClass.btnColorRed;
				doneButton.Layer.CornerRadius = 10;
				doneButton.UserInteractionEnabled = true;
				viewPicker.AddSubviews (new UIView[]{ doneButton, pickerView });

				pickerDataModel.ValueChanged += (s, e) => {
					selectedValue = "  " + pickerDataModel.SelectedItem;
				};
				//selectedValue = pickerDataModel.SelectedItem;
				View.Add (viewPicker);
				doneButton.TouchUpInside += (s, e) =>
				{
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
					btnSelectAction.SetTitle(selectedValue, UIControlState.Normal);
					if (!string.IsNullOrEmpty(selectedValue))
					{
						btnSelectAction.SetTitle(selectedValue, UIControlState.Normal);
					}
					else
					{
						if (CommanUtil.ViewAs.ToUpper() == Constants.strCustomer.ToUpper())
						{
							btnSelectAction.SetTitle("  " + Util.customerAution[0], UIControlState.Normal);
						}
						else
						{
							btnSelectAction.SetTitle("  " + Util.carrierAution[0], UIControlState.Normal);
						}
					}
				};
				viewPicker.AddSubviews (new UIView[]{ doneButton, pickerView });
				pickerParentView.Frame = View.Frame;
				pickerParentView.BackgroundColor = UIColor.Clear;
				pickerParentView.Add(viewPicker);
				View.Add(pickerParentView);
				var tapGesture = new UITapGestureRecognizer(new Action(delegate
				{
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
				}));
				pickerParentView.AddGestureRecognizer(tapGesture);
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}


		/// <summary>
		/// Filters the rate history.
		/// </summary>
		public void FilterRateHistory()
		{
			try
			{
				objFilters = new Filters();
				objFilters.Action = NSBundle.MainBundle.GetLocalizedString("all", null);

				objFilters.ClientId = txtViewClientId.Text;
				objFilters.LoadNo = txtViewLoadNo.Text;
				var filterQuery = "";
				if (IsValidated())
				{
                    if (Convert.ToString(btnSelectAction.TitleLabel.Text.Trim()) != NSBundle.MainBundle.GetLocalizedString("all", null))
					{
                        if (Convert.ToString(btnSelectAction.TitleLabel.Text.Trim()) == NSBundle.MainBundle.GetLocalizedString("requireConfirmation", null))
						{
							filterQuery = "filters='Auction Status'=NEW|'Rate Status'=AWARDED";
						}
                        else if (Convert.ToString(btnSelectAction.TitleLabel.Text.Trim()) == NSBundle.MainBundle.GetLocalizedString("requireResponse", null))
						{
							filterQuery = "filters='Auction Status'=NEW|'Rate Status':~RATE~AWARDED";
						}
                        else if (Convert.ToString(btnSelectAction.TitleLabel.Text.Trim()) == NSBundle.MainBundle.GetLocalizedString("requireRate", null))
						{
							filterQuery = "filters='Auction Status'=NEW|'Rate Status':~RATE";
						}
                        else if (Convert.ToString(btnSelectAction.TitleLabel.Text.Trim()) == NSBundle.MainBundle.GetLocalizedString("openAuction", null))
						{
							filterQuery = "filters='Auction Status':NEW~AWARDED";
						}
                        else if (Convert.ToString(btnSelectAction.TitleLabel.Text.Trim()) == NSBundle.MainBundle.GetLocalizedString("awardAution", null))
						{
							filterQuery = "filters='Auction Status'=AWARDED|'Auction Status'!=VOID";
						}
                        else if (Convert.ToString(btnSelectAction.TitleLabel.Text.Trim()) == NSBundle.MainBundle.GetLocalizedString("confirmedShipment", null))
						{
							filterQuery = "filters='Auction Status'=CLOSED|'Rate Status'=CONFIRMED";
						}
					}
					if (!string.IsNullOrEmpty(txtOriginDate.Text) && !string.IsNullOrEmpty(txtEndDate.Text))
					{
						if (string.IsNullOrEmpty(filterQuery))
						{
							filterQuery = "filters='Date Opened'>=" + txtOriginDate.Text + "|'Date Opened'<=" + txtEndDate.Text + "";
						}
						else
						{
							filterQuery = filterQuery + "|'Date Opened'>=" + txtOriginDate.Text + "|'Date Opened'<=" + txtEndDate.Text + "";
						}
					}

					if (objFilters.LoadNo != "")
					{
						if (objFilters.LoadNo.ToUpper().Equals("LOAD NUMBER"))
						{
						}
						else
						{
							if (filterQuery == "")
							{
								filterQuery = "filters='Load Num'=" + objFilters.LoadNo + "";
							}
							else
							{
								filterQuery += "|'Load Num'=" + objFilters.LoadNo + "";
							}
						}

					}
					if (objFilters.ClientId != "")
					{

						if (objFilters.ClientId.ToUpper().Equals("CLIENT ID"))
						{
							
						}
						else
						{
							if (filterQuery == "")
							{
								filterQuery = "filters='Client ID'=" + objFilters.ClientId + "";
							}
							else
							{
								filterQuery += "|'Client ID'=" + objFilters.ClientId + "";
							}
						}

					}
					filterQuery = filterQuery == "" ? "#" : filterQuery;
					HistoryResultController objHistoryResultController =
						this.Storyboard.InstantiateViewController
						("HistoryResultController") as HistoryResultController;
					objHistoryResultController.filterQuery = filterQuery;

					this.NavigationController.PushViewController (objHistoryResultController, true);
				}
				else
				{
					redirect = true;
				}
			}
			catch
			{
				redirect = true;
				Console.Write(Constants.strErrorOccured);
			}
		}


		/// <summary>
		/// checks the validation
		/// </summary>
		/// <returns></returns>
		public bool IsValidated()
		{
			try
			{
				if (!string.IsNullOrEmpty(txtOriginDate.Text) && string.IsNullOrEmpty(txtEndDate.Text))
				{
                    this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.enterDate, true, this, "", 1);
					this.View.Add(this.customAlert);
					redirect = true;
					return false;
				}
				if (string.IsNullOrEmpty(txtOriginDate.Text) && !string.IsNullOrEmpty(txtEndDate.Text))
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.enterDate, true, this, "", 1);
					this.View.Add(this.customAlert);
					redirect = true;
					return false;
				}
				DateTime originDate = DateTime.ParseExact(txtOriginDate.Text, "MM/dd/yyyy", null);

				DateTime endDate = DateTime.ParseExact(txtEndDate.Text, "MM/dd/yyyy", null);


				//DateTime originDate = DateTime.Parse(txtOriginDate.Text);

				//DateTime endDate = DateTime.Parse(txtEndDate.Text);

				if (originDate > endDate)
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.fromDate, true, this, "", 1);
					this.View.Add(this.customAlert);
					redirect = true;
					return false;
				}
				if (endDate > DateTime.Now)
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.endDate, true, this, "", 1);
					this.View.Add(this.customAlert);
					redirect = true;
					return false;
				}
				return true;
			}
			catch
			{
				throw;
			}
		}
		/// <summary>
		/// Buttons the search history touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnSearchHistory_TouchUpInside (UIButton sender)
		{
			try
			{
                if (!CommanUtil.IsTimeOut())
                {
                    return;
                }
				if (!Reachability.InternetConnectionStatus())
				{
					UIView.Animate(0.3,
					() =>
					{
						menuView.Frame = new CGRect(-800, 20, View.Frame.Width, View.Frame.Height - 20);

					});
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
					this.View.Add(this.customAlert);
				}

				else
				{
					redirect = false;
                	FilterRateHistory();
				}

			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}
	}

	/// <summary>
	/// A quick subclass of UITextView to enable placeholder text
	/// </summary>
	[Register("PlaceholderTextView")]
	public class PlaceholderTextView : UITextView
	{
		/// <summary>
		/// Gets or sets the placeholder to show prior to editing - doesn't exist on UITextView by default
		/// </summary>
		public string Placeholder { get; set; }

		public PlaceholderTextView()
		{
			Initialize();
		}

		public PlaceholderTextView(CGRect frame)
			: base(frame)
		{
			Initialize();
		}

		public PlaceholderTextView(IntPtr handle)
			: base(handle)
		{
			Initialize();
		}

		void Initialize()
		{
			Placeholder = "Please enter text";

			ShouldBeginEditing = t =>
			{
				if (Text == Placeholder)
					Text = string.Empty;

				return true;
			};
			ShouldEndEditing = t =>
			{
				if (string.IsNullOrEmpty(Text))
					Text = Placeholder;

				return true;
			};
		}
	}
}