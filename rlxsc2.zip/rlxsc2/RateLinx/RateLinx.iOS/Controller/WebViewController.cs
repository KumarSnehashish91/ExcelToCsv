using Foundation;
using System;
using UIKit;
using System.Text;
using RateLinx.Helper;

namespace RateLinx.iOS
{
	public partial class WebViewController : UIViewController
	{
        


		UITapGestureRecognizer tapGesture;
        public string strHeading = String.Empty;
        LoadingOverlay loadPop;
        /// <summary>
        /// Initializes a new instance of the <see cref="T:RateLinx.iOS.InvoiceWebViewController"/> class.
        /// </summary>
        /// <param name="handle">Handle.</param>
        public WebViewController(IntPtr handle) : base(handle)
        {
        }
		/// <summary>
		/// Views the did load.
		/// </summary>
		public override void ViewDidLoad()
		{
			try
			{
				base.ViewDidLoad();
                CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
                if (loadPop == null)
                {
                    loadPop = new LoadingOverlay(bounds);
                }
                View.Add(loadPop);
                fileWebView.ShouldStartLoad = HandleShouldStartLoad;
                fileWebView.LoadFinished += FileWebView_LoadFinished;
                //fileWebView.Nav = new NavigationDelegate();
                fileWebView.LoadRequest(new NSUrlRequest(new NSUrl(CommanUtil.fileURL)));
                //View.AddSubview(fileWebView);
				TapGestureRecognizer();
                lblHeading.Text = strHeading;
			}
			catch
			{
				throw;
			}
		}

        /// <summary>
        /// Files the web view load finished.
        /// </summary>
        /// <param name="sender">Sender.</param>
        /// <param name="e">E.</param>
        void FileWebView_LoadFinished(object sender, EventArgs e)
        {
            if (loadPop != null)
            {
                loadPop.Hide();
                loadPop = null;
            }
        }

        /// <summary>
        /// Gets the supported interface orientations.
        /// </summary>
        /// <returns>The supported interface orientations.</returns>
		public override UIInterfaceOrientationMask GetSupportedInterfaceOrientations()
		{
			return UIInterfaceOrientationMask.Portrait;
		}

        /// <summary>
        /// Handles the should start load.
        /// </summary>
        /// <returns><c>true</c>, if should start load was handled, <c>false</c> otherwise.</returns>
        /// <param name="webView">Web view.</param>
        /// <param name="request">Request.</param>
        /// <param name="navigationType">Navigation type.</param>
        bool HandleShouldStartLoad(UIWebView webView, NSUrlRequest request, UIWebViewNavigationType navigationType)
        {
            if (navigationType == UIWebViewNavigationType.LinkClicked)
            {
                UIApplication.SharedApplication.OpenUrl(request.Url);
                return false;
            }
            return true;
        }

		/// <summary>
		/// Taps the gesture recognizer.
		/// </summary>
		void TapGestureRecognizer()
		{

			tapGesture = new UITapGestureRecognizer(ManageNavigation);
			imgBack.AddGestureRecognizer(tapGesture);
		}

		/// <summary>
		/// Manages the navigation.
		/// </summary>
		void ManageNavigation()
		{
			try
			{
				if (tapGesture.View.Equals(imgBack))
				{
					this.NavigationController.PopViewController(true);
				}
				else
				{

				}
			}
			catch
			{
				throw;

			}
		}

	}
}
