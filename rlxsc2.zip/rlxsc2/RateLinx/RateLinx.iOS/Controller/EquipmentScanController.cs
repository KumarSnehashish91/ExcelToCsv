using Foundation;
using System;
using UIKit;
using CoreGraphics;
using System.Collections.Generic;
using RateLinx.Helper;
using RateLinx.Models;
using System.Threading.Tasks;
using ZXing.Mobile;
using Cirrious.FluentLayouts.Touch;
using Newtonsoft.Json;
using RateLinx.APIs;

namespace RateLinx.iOS
{
	public partial class EquipmentScanController : UIViewController
	{

		#region Variable Declaration

		UITapGestureRecognizer tapGesture;
		List<string> lstOtherScannedNos = new List<string>();
		MobileBarcodeScanner objScanner = null;
		string shipmentDetails = string.Empty;
		CarrierShipmentDetails lstShipmentDetail = null;
		CustomPopup customAlert = null;
		#endregion

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.EquipmentScanController"/> class.
		/// </summary>
		/// <param name="handle">Handle.</param>
		public EquipmentScanController(IntPtr handle) : base(handle)
		{
		}
		/// <summary>
		/// Views the did load.
		/// </summary>
		public override  void ViewDidLoad()
		{
			try
			{
				base.ViewDidLoad();

				lblCopyRight.Text = Util.GetCopyRight();

				tapGesture = new UITapGestureRecognizer(ManageNavigation);
				imgBack.AddGestureRecognizer(tapGesture);

				//OtherEquipmentSection();
				shipmentDetails = NSUserDefaults.StandardUserDefaults.StringForKey("shipmentDetails");
				lstShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(shipmentDetails);
				if (string.IsNullOrEmpty(txtPickupScan.Text))
				{
					btnPickupCros.Hidden = true;
				}
				if (string.IsNullOrEmpty(txtDropScan.Text))
				{
					btnDropCros.Hidden = true;
				}
				if (tblOtherScannedNos == null)
				{
					tblOtherScannedNos.Hidden = true;
				}
				else
				{
					tblOtherScannedNos.Hidden = false;
				}
				btnOtherScan.TouchUpInside +=  delegate
				{
					OpenScanningPopup();
				};

				if (lstOtherScannedNos.Count == 0)
				{
					tblOtherScannedNos.Hidden = true;
				}
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}

		}

		public override UIInterfaceOrientationMask GetSupportedInterfaceOrientations()
		{
			return UIInterfaceOrientationMask.Portrait;
		}

		public override void DidRotate(UIInterfaceOrientation fromInterfaceOrientation)
		{
			base.DidRotate(fromInterfaceOrientation);
			if (!Util.isViewRotated)
			{
				Util.isViewRotated = true;
			}
			else
			{
				Util.isViewRotated = false;
			}
		}

		/// <summary>
		/// Manages the navigation.
		/// </summary>
		/// <param name="tapGesture">Tap gesture.</param>
		private void ManageNavigation(UITapGestureRecognizer tapGesture)
		{
			try
			{
				if (tapGesture.View.Equals(imgBack))
				{
					this.NavigationController.PopViewController(true);
				}
				else
				{

				}
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Opens the scanning popup.
		/// </summary>
		public async void OpenScanningPopup()
		{

			try
			{

				objScanner = new MobileBarcodeScanner(this);
				objScanner.Torch(true);
				var result = await objScanner.Scan(true);
				if (result != null)
				{
					UIView popupView = new UIView();
					popupView.Frame = View.Bounds;
					popupView.BackgroundColor = UIColor.Clear;

					UIView viewBarcodeConfirmation = new UIView(new CGRect(10, 100, View.Frame.Width - 20, 180));
					viewBarcodeConfirmation.BackgroundColor = UIColor.White;
					viewBarcodeConfirmation.Layer.CornerRadius = 5;
					viewBarcodeConfirmation.Layer.BorderWidth = 0.5f;

					UIView viewTopMargin = new UIView(new CGRect(0, 0, viewBarcodeConfirmation.Frame.Width, 10));
					viewTopMargin.BackgroundColor = Constants.conversationHeadClr;
					viewTopMargin.Layer.CornerRadius = 5;

					UIView viewBarcodeConfirmationHead = new UIView(new CGRect(0, 5, viewBarcodeConfirmation.Frame.Width, 40));
					viewBarcodeConfirmationHead.BackgroundColor = Constants.conversationHeadClr;

					UIImageView imageConfirm = new UIImageView(ConstantsClass.imageview);
					imageConfirm.Image = UIImage.FromBundle("Images/warning.png");

					UILabel lblBarcodeHead = new UILabel(ConstantsClass.lblEquipmentFrmae);

					lblBarcodeHead.BackgroundColor = Constants.conversationHeadClr;
					lblBarcodeHead.Font = UIFont.FromName(Constants.strFontName, 15f);
					lblBarcodeHead.Text = NSBundle.MainBundle.LocalizedString("Confirm", null);
					lblBarcodeHead.TextColor = UIColor.White;

					UIButton btnPopupClose = new UIButton(new CGRect(viewBarcodeConfirmation.Frame.Width - 22, 5, 20, 20));
					btnPopupClose.SetTitle(NSBundle.MainBundle.LocalizedString("croxSign", null), UIControlState.Normal);
					btnPopupClose.SetTitleColor(UIColor.White, UIControlState.Normal);

					btnPopupClose.TouchUpInside += delegate
					{
						popupView.Hidden = true;
					};

					viewBarcodeConfirmationHead.AddSubviews(imageConfirm, lblBarcodeHead, btnPopupClose);

					UIView viewBarcodeConfirmationContent = new UIView(new CGRect(0, viewBarcodeConfirmationHead.Frame.Y + viewBarcodeConfirmationHead.Frame.Height, viewBarcodeConfirmation.Frame.Width, 85));
					UILabel lblBarcodeComment = new UILabel(new CGRect(10, 10, viewBarcodeConfirmationContent.Frame.Width - 15, 50));
					lblBarcodeComment.MinimumFontSize = 15f;
					lblBarcodeComment.Lines = 0;

					lblBarcodeComment.Text = "You have scanned  " + result.Text + ". Would you like to keep scanning?";
					//lblBarcodeComment.Text = string.Format(NSBundle.MainBundle.LocalizedString("stryouhaveScanned", null), strBarcode); //"You have scanned " + strBarcode + ". Would you like to keep scanning?";
					viewBarcodeConfirmationContent.AddSubview(lblBarcodeComment);

					UIView viewBottomSeparator = new UIView(new CGRect(0, viewBarcodeConfirmationContent.Frame.Y + viewBarcodeConfirmationContent.Frame.Height, viewBarcodeConfirmation.Frame.Width, 0.5));
					viewBottomSeparator.BackgroundColor = Constants.conversationHeadClr;

					UIButton btnOk = new UIButton(new CGRect(viewBarcodeConfirmation.Frame.Width - 60, viewBarcodeConfirmation.Frame.Height - 40, 50, 30));
					btnOk.SetTitle(NSBundle.MainBundle.LocalizedString("btnYes", null), UIControlState.Normal);
					btnOk.BackgroundColor = Constants.btnColorBlue;
					btnOk.Layer.CornerRadius = 5;


					UIButton btnCancel = new UIButton(new CGRect(viewBarcodeConfirmation.Frame.Width - 120, viewBarcodeConfirmation.Frame.Height - 40, 50, 30));
					btnCancel.SetTitle(NSBundle.MainBundle.LocalizedString("btnNo", null), UIControlState.Normal);
					btnCancel.BackgroundColor = UIColor.White;
					btnCancel.Layer.CornerRadius = 5;
					btnCancel.Layer.BorderWidth = 1;
					btnCancel.SetTitleColor(UIColor.Black, UIControlState.Normal);

					btnOk.TouchUpInside += delegate
					{
						popupView.Hidden = true;

						lstOtherScannedNos.Add(result.Text);
						tblOtherScannedNos.Source = new OtherScannedNumberAdapter(lstOtherScannedNos);
						tblOtherScannedNos.ReloadData();

						OpenScanningPopup();

					};

					btnCancel.TouchUpInside += delegate
					{
						popupView.Hidden = true;

						lstOtherScannedNos.Add(result.Text);
						tblOtherScannedNos.Source = new OtherScannedNumberAdapter(lstOtherScannedNos);
						tblOtherScannedNos.ReloadData();
					};

					View.Add(popupView);
					viewBarcodeConfirmation.AddSubviews(viewTopMargin, viewBarcodeConfirmationHead, viewBarcodeConfirmationContent, viewBottomSeparator, btnOk, btnCancel);
					popupView.AddSubview(viewBarcodeConfirmation);
					popupView.Hidden = false;

				}
				else
				{
					
				}

				if (lstOtherScannedNos.Count > 0)
				{
					tblOtherScannedNos.Hidden = false;
				}

			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}

		}

		/// <summary>
		/// Scans the drop off equip.
		/// </summary>
		private async void ScanDropOffEquip()
		{
			try
			{
				objScanner = new MobileBarcodeScanner(this);
				objScanner.Torch(true);
				var result = await objScanner.Scan(true);
				if (result != null)
				{
					btnDropCros.Hidden = false;
					txtDropScan.Text = string.Empty;
					txtDropScan.Text = result.Text;
					btnDropCros.Hidden = false;
				}
				else
				{
					//txtDropScan.Text = "12345678";
					//btnDropCros.Hidden = false;
				}

			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Scans the pickup equip.
		/// </summary>
		private async void ScanPickupEquip()
 		{
			try
			{
				objScanner = new MobileBarcodeScanner(this);
				objScanner.Torch(true);

				var result = await objScanner.Scan(true);
				if (result != null)
				{
					btnPickupCros.Hidden = false;
					txtPickupScan.Text = string.Empty;
					txtPickupScan.Text = result.Text;
					btnPickupCros.Hidden = false;
				}
				else
				{
					//txtPickupScan.Text = "234544545";
					//btnDropCros.Hidden = false;
				}

			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}
		/// <summary>
		/// Buttons the save touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnSave_TouchUpInside(UIButton sender)
		{
            if (!CommanUtil.IsTimeOut())
            {
                return;
            }
			if (Reachability.InternetConnectionStatus())
			{
				SaveScanCode();
			}
			else
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
				this.View.Add(this.customAlert);
			}
		}

		public async void SaveScanCode()
		{
			string postData = "PickupNum=" + txtPickupScan.Text
							   + "&DropoffNum=" + txtDropScan.Text
							   + "&OnSiteEquipNums=" + lstOtherScannedNos;

			string id = lstShipmentDetail.ClientID + "|" + lstShipmentDetail.LocID + "|" + lstShipmentDetail.BolNum;
			string methodURI = APIMethods.Shipment + "/" + id + "/" + APIMethods.equipnumbers;
			string token = CommanUtil.tokenNo;
			try
			{
				ServiceHelper objServiceHelper = new ServiceHelper();
				//Alerts.showBusyLoader(context); //Loader
				var Result = await objServiceHelper.PostRequest(postData, methodURI, token, true);
				if (Result != null)
				{
					this.NavigationController.PopViewController(true);
				}
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Buttons the cancel touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnCancel_TouchUpInside(UIButton sender)
		{
			this.NavigationController.PopViewController(true);
		}

		partial void BtnPickupScan_TouchUpInside(UIButton sender)
		{
			try
			{
				ScanPickupEquip();
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}
		/// <summary>
		/// Buttons the drop off scan touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnDropOffScan_TouchUpInside(UIButton sender)
		{
			try
			{
				ScanDropOffEquip();
			}
			catch (Exception ex)
			{
				Console.Write(ex.Message);
			}
		}
		/// <summary>
		/// Buttons the pickup cros touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnPickupCros_TouchUpInside(UIButton sender)
		{
			txtPickupScan.Text = "";
			btnPickupCros.Hidden = true;
		}
		/// <summary>
		/// Buttons the drop cros touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnDropCros_TouchUpInside(UIButton sender)
		{
			txtDropScan.Text = "";
			btnDropCros.Hidden = true;
		}

	}
}