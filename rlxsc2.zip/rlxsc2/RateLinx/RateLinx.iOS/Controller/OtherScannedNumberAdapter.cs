using System;
using System.Collections.Generic;
using CoreGraphics;
using Foundation;
using UIKit;

namespace RateLinx.iOS
{
	class OtherScannedNumberAdapter : UITableViewSource
	{
		List<string> lstOtherScannedNos;
		public OtherScannedNumberAdapter(List<string> lstOtherScannedNos)
		{
			this.lstOtherScannedNos = lstOtherScannedNos;
		}

		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			UITableViewCell cellScannedNo = new UITableViewCell(new CGRect(0, 0, tableView.Frame.Width, 25));

			UILabel lblScannedNo = new UILabel(new CGRect(0, 0, 170, 25));

			lblScannedNo.Text = lstOtherScannedNos[indexPath.Row];

			UIButton btnDeleteNo = new UIButton(new CGRect(200, 0, 20, 20));
			btnDeleteNo.SetTitle("X", UIControlState.Normal);
			btnDeleteNo.SetTitleColor(UIColor.FromRGB(137,18,40), UIControlState.Normal);
			btnDeleteNo.UserInteractionEnabled = true;
			btnDeleteNo.Tag = indexPath.Row;

			btnDeleteNo.TouchUpInside +=delegate {
				MaintainOtherScannedBarcode(btnDeleteNo.Tag, tableView);
			};


			cellScannedNo.AddSubviews(lblScannedNo, btnDeleteNo);


			return cellScannedNo;
		}

		void MaintainOtherScannedBarcode(nint tag, UITableView tableView)
		{
			lstOtherScannedNos.RemoveAt(Convert.ToInt32(tag));
			tableView.Source = new OtherScannedNumberAdapter(lstOtherScannedNos);
			tableView.ReloadData();

		}

		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return lstOtherScannedNos.Count;
		}
	}
}