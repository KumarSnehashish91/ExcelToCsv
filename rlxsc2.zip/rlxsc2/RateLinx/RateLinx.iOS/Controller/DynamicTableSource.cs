using System;
using System.Collections.Generic;
using Foundation;
using UIKit;

namespace RateLinx.iOS
{
	class DynamicTableSource : UITableViewSource
	{
		//private string cellIdentifier = "ActiveShipment";
		//List<Bid> lstCarrierBids = null;
		List<EmployeeData> lstEmployeeData = new List<EmployeeData>();  // Declare active shipment lis
		public DynamicTableSource()
		{
			lstEmployeeData.Add(new EmployeeData { Name = "Ravi", Place = "GZB", Description = "You can imagine that as more text is added to the multi-line body label in the example cell above, it will need to grow vertically to fit the text, " });
			lstEmployeeData.Add(new EmployeeData { Name = "Mark", Place = "US", Description = "which will effectively force the cell to grow in height. (Of course, you need to get the constraints right in order for this to work correct" });
			lstEmployeeData.Add(new EmployeeData { Name = "Geeta", Place = "Delhi", Description = "Getting your constraints right is definitely" });
			lstEmployeeData.Add(new EmployeeData { Name = "Ram", Place = "Patna", Description = "which will effectivel" });
			lstEmployeeData.Add(new EmployeeData { Name = "ABC", Place = "ABC", Description = "which will effectivel" });
			lstEmployeeData.Add(new EmployeeData { Name = "XYZ", Place = "XYZ", Description = "which will effectivel111111111111111" });
		}

		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return lstEmployeeData.Count;
		}


		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			try
			{
				TestCell cell = (TestCell)tableView.DequeueReusableCell("TestCell", indexPath);

				EmployeeData objEmployeeData = lstEmployeeData[indexPath.Row];
				//CarrierBidDetail objCarrierBidDetail = (CarrierBidDetail)tableView.DequeueReusableCell("CarrierBidDetails", indexPath);
				if (cell != null)
				{
					objEmployeeData = lstEmployeeData[indexPath.Row];
					cell.UpdateCell(objEmployeeData, indexPath.Row);
					return cell;

				}


				else
				{
					return null;
				}
			}
			catch (Exception ex)
			{
				throw ex;

			}
		}
	}
	}