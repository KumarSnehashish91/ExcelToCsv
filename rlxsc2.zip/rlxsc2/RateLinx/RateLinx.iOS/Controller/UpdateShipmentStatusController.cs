using Foundation;
using System;
using UIKit;
using RateLinx.Models;
using System.Collections.Generic;
using PubnubApi;
using RateLinx.Helper;
using System.Threading;
using Newtonsoft.Json;
using System.Threading.Tasks;
using System.Net;
using RateLinx.GoogleServices;
using CoreLocation;
using Google.Maps;
using CoreGraphics;
using System.Text;
using RateLinx.APIs;
using ToastIOS;
using System.Drawing;
using System.Linq;
using Newtonsoft.Json.Linq;
using System.Collections;

namespace RateLinx.iOS
{
	public partial class UpdateShipmentStatusController : UIViewController
	{
      
		#region variables declaration
		MapView mapView;
		public RecentShipments objRecentShipments;
        Models.Address destinationAddress;
		string originAddress, shipToAddress = string.Empty;
		SubscribeCallbackExt listener;
		static public Pubnub pubnub;
		PNConfiguration config;
		bool isTrackingEnable = false;
		string channel = string.Empty;
		public List<ShipmentActivity> lstShipmentActivity = null;
        List<CountryDetails> lstCountryDetails = null;
		string channelGroup
		{
			get;
			set;
		}
		float currentZoomLevel = 15;
		int hours = 0;
		int minutes = 0;
		int seconds = 0;
		//int count = 0;
		decimal totalDistance = 0;
		string city = string.Empty;
		string state = string.Empty;
		string country = string.Empty;
		bool isAnimateCamera = true;
        //Dictionary<string, string> shipmentStatus, nodeAPIStatus = null;
        Dictionary<string, string> trackingStatus = null;
		//GeoCodeJSONClass objGeoCodeJSONClass;
		public string addressKey;
		string strSource = string.Empty;
		string strDestination = string.Empty;
		//string strGeoCodeURL = string.Empty;
		string strHttpResponse = string.Empty;
		//Code snippet to mark source and destination points
		Location SourceLocation { get; set; }
		Location DestinationLocation { get; set; }
		CLLocationCoordinate2D pevCoordinate = new CLLocationCoordinate2D();
		Marker marker3 = null;
		CLLocation currLocation = null;
		//LatLng StartLatLong = new LatLng(43.030521, -88.114374);
		//string[] latlong = new[] { "43.030521, -88.114374",
		//                           "43.030346, -88.114375",
		//                           "43.030159, -88.114382",
		//                           "43.030145, -88.114149",
		//                           "43.030145, -88.113624",
		//                           "43.030138, -88.113128",
		//"43.030105, -88.112613",
		//"43.030112, -88.111982",
		//"43.030000, -88.111459",
		//"43.029901, -88.110827",
		//"43.029736, -88.110430",};
		//"RateLinx, 4602 S Biltmore Ln 104, Madison, WI 53718";//"Madison, WI 53718";//
		//string address1 = "Chetu A-186/187, A Block, Sector 63, A Block, Sector 63, Noida, Uttar Pradesh 201301";
		//string address2 = "Logix Infotech Park, Plot No: D - 5, Sector 59 D Block, Sector 59 Noida";
		//        string[] latlong = new[] { "43.146405, -89.292878","43.146366, -89.292769","43.146333, -89.292678","43.146290, -89.292564",
		//"43.146279, -89.292523",
		//"43.146272, -89.292507",
		//"43.146267, -89.292489",
		//"43.146263, -89.292475",
		//"43.146260, -89.292461",
		//"43.146254, -89.292450",
		//"43.146249, -89.292428",
		//"43.146247, -89.292412",
		//"43.146256, -89.292449",
		//"43.146244, -89.292408",
		//"43.146231, -89.292361",
		//"43.146222, -89.292323",
		//"43.146216, -89.292297",
		//"43.146208, -89.292267",
		//"43.146202, -89.292238",
		//"43.146198, -89.292211",
		//"43.146190, -89.292186",
		//"43.146177, -89.292120",
		//"43.146164, -89.292062",
		//"43.146152, -89.292000",
		//"43.146141, -89.291957",
		//"43.146125, -89.291887",
		//"43.146115, -89.291835",
		//"43.146105, -89.291778",
		//"43.146095, -89.291733",
		//"43.146087, -89.291698",
		//"43.146082, -89.291674",
		//"43.146078, -89.291660",
		//"43.146078, -89.291651",
		//"43.146085, -89.291647",
		//"43.146101, -89.291639",
		//"43.146114, -89.291633",
		//"43.146132, -89.291628",
		//"43.146145, -89.291622",
		//"43.146159, -89.291618"
		//        };
		string[] latlong = new[]{
			"28.621175 , 77.378779"
			,"28.621170 , 77.378832","28.621166 , 77.378885","28.621165 , 77.378912","28.621164 , 77.378939","28.621162 , 77.379002"
			,"28.621158 , 77.379034","28.621155 , 77.37908","28.621098, 77.379129","28.621104, 77.379074","28.621110, 77.379014"
			,"28.621117, 77.378975","28.621121, 77.378941","28.621121, 77.378904","28.621125, 77.378855","28.621128, 77.378819"
			,"28.621130, 77.378788","28.621130, 77.378749","28.621136, 77.378724","28.621136, 77.378704","28.621136, 77.378670","28.621137, 77.378642"
			,"28.621137, 77.378642",
			"28.621144, 77.378617","28.621143, 77.378594",
			"28.621145, 77.378572",
			"28.621145, 77.378555",
			"28.621147, 77.378536"
			,"28.621150, 77.378515","28.621151, 77.378491","28.621151, 77.378450","28.621154, 77.378422","28.621160, 77.378397","28.621157, 77.378369"
			,"28.621160, 77.378344","28.621162, 77.378316","28.621164, 77.378291","28.621165, 77.378260","28.621168, 77.378232","28.621170, 77.378202"
			,"28.621174, 77.378161","28.621175, 77.378107","28.621177, 77.378083","28.621178, 77.378047","28.621182, 77.378019"
			,"28.621184, 77.377976","28.621187, 77.377941","28.621188, 77.377907","28.621190, 77.377876","28.621194, 77.377836"
			,"28.621231, 77.377209","28.621238, 77.377117","28.621249, 77.377038","28.621251, 77.376968","28.621256, 77.376897","28.621262, 77.376864"
			,"28.621263, 77.376830","28.621271, 77.376778","28.621274, 77.376743","28.621278, 77.376698","28.621280, 77.376644","28.621280, 77.376607"
			,"28.621285, 77.376566","28.621288, 77.376522","28.621291, 77.376485","28.621297, 77.376443","28.621297, 77.376401","28.621301, 77.376359"
			,"28.621305, 77.376322","28.621310, 77.376291","28.621311, 77.376228","28.621316, 77.376181","28.621320, 77.376128"
			,"28.621325, 77.376059","28.621332, 77.375948","28.621339, 77.375847","28.621344, 77.375756","28.621353, 77.375686","28.621363, 77.375584"
			,"28.621371, 77.375466","28.621377, 77.375359","28.621384, 77.375265","28.621391, 77.375167","28.621400, 77.375047","28.621409, 77.374902"
			,"28.621415, 77.374793","28.621423, 77.374693","28.621429, 77.374616","28.621435, 77.374489","28.621441, 77.374365","28.621446, 77.374294"
			,"28.621433, 77.374229"
			,"28.621376, 77.374195","28.621303, 77.374165","28.621190, 77.374124","28.621059, 77.374108","28.620890, 77.374086"
			,"28.620691, 77.374074","28.620496, 77.374051","28.620327, 77.374039","28.620150, 77.374019","28.619954, 77.373997","28.619812, 77.373978"
			,"28.619625, 77.373962","28.619312, 77.373926","28.619118, 77.373907","28.618815, 77.373876","28.618582, 77.373856","28.618353, 77.373833"
			,"28.618182, 77.373820","28.617936, 77.373803","28.617708, 77.373811","28.617492, 77.373837","28.617187, 77.373844","28.616908, 77.373817"
			,"28.616715, 77.373805","28.616381, 77.373751","28.616172, 77.373702","28.615955, 77.373646","28.615780, 77.373598","28.615453, 77.373552"
			,"28.615262, 77.373520","28.615001, 77.373497","28.614790, 77.373477","28.614505, 77.373452","28.614286, 77.373433","28.613748, 77.373366"
			,"28.613265, 77.373323","28.612611, 77.373259","28.612000, 77.373199","28.611562, 77.373151","28.611056, 77.373107","28.610468, 77.373053"
			,"28.610212, 77.373082","28.609644, 77.373018","28.609461, 77.373002","28.609294, 77.372956","28.609103, 77.372933","28.608896, 77.372935"
			,"28.608717, 77.372924","28.608053, 77.372869","28.607925, 77.372837","28.607910, 77.372790","28.607936, 77.372723","28.608126, 77.372673"
			,"28.608255, 77.372590","28.608253, 77.372518","28.608301, 77.372536"
		};
        string statusCode, shipmentStatusValue, liveStatusCode, liveStatusText = string.Empty;//status
		//public CLLocation location = null;
		protected CLLocationManager locMgr;
		MutablePath path = new MutablePath();
		public event EventHandler<LocationUpdatedEventArgs> LocationUpdated = delegate { };
		int statuscount = 0;
		LoadingOverlay loadPop;
		UIView viewShowHide = new UIView();
		#endregion

		public class LocalLog : IPubnubLog
		{
			void IPubnubLog.WriteToLog(string logText)
			{
				System.Diagnostics.Debug.WriteLine(logText);
			}
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.UpdateShipmentStatusController"/> class.
		/// </summary>
		/// <param name="handle">Handle.</param>
		public UpdateShipmentStatusController(IntPtr handle) : base(handle)
		{
			try
			{
				//shipmentStatus = CommanUtil.ShipmentCurrentStatus();
				//nodeAPIStatus = CommanUtil.NodeAPIStatus();
                trackingStatus = CommanUtil.TrackingStatus();
				this.locMgr = new CLLocationManager();
                this.locMgr.PausesLocationUpdatesAutomatically = false;
				// iOS 8 has additional permissions requirements
				if (UIDevice.CurrentDevice.CheckSystemVersion(8, 0))
				{
					locMgr.RequestAlwaysAuthorization(); // works in background
					locMgr.RequestWhenInUseAuthorization(); // only in foreground
				}
				if (UIDevice.CurrentDevice.CheckSystemVersion(9, 0))
				{
					//locMgr.AllowsBackgroundLocationUpdates = true;
				}
				StartLocationUpdates();
				LocationUpdated += PrintLocation;
			}
			catch
			{
				Console.WriteLine(Helper.Constants.strErrorOccured);
			}
		}

		public override void ViewDidAppear(bool animated)
		{
			if (mapView == null)
				mapView = new MapView();
			base.ViewDidAppear(animated);
			mapView.Frame = viewMapControl.Bounds;
			viewMapControl.AddSubview(mapView);
		}

		public override void DidRotate(UIInterfaceOrientation fromInterfaceOrientation)
		{
			base.DidRotate(fromInterfaceOrientation);

			mapView.Frame = viewMapControl.Bounds;
			viewMapControl.AddSubview(mapView);
		}

		/// <summary>
		/// Views the did load.
		/// </summary>
		public override void ViewDidLoad()
		{
			try
			{
				base.ViewDidLoad();
				viewShowHide.Frame = View.Bounds;
				viewShowHide.BackgroundColor = UIColor.White;
				View.AddSubview(viewShowHide);
				#region Bind shipment details in controls
				slider.SetThumbImage(UIImage.FromFile("Images/seekbarthumb.png"), UIControlState.Normal);
                lblShipmentStatus.Text = trackingStatus[Helper.Constants.inTransitkey];
				channel = objRecentShipments.ClientID + objRecentShipments.BolNum;
				lblCopyRight.Text = Util.GetCopyRight();
				originAddress = objRecentShipments.OriginCompany + " "
							+ objRecentShipments.OriginAddress1 + " "
							+ objRecentShipments.OriginAddress2 + " "
							+ objRecentShipments.OriginCity + ", "
							+ objRecentShipments.OriginState + " " + objRecentShipments.OriginZip;
				shipToAddress = objRecentShipments.ShipToCity + ", " + objRecentShipments.ShipToState + " " + objRecentShipments.ShipToZip;
                strDestination = shipToAddress;
                strSource = originAddress;//address1;
				txtSourceAddress.Text = originAddress;
				txtDestinationAddress.Text = shipToAddress;
				lblBolNumber.Text = objRecentShipments.BolNum;
				lblUsername.Text = CommanUtil.userID;
                if(lblShipmentStatus.Text==Helper.Constants.enrouteToPickup)
                {
                    lblCurrentStatus.Text = Helper.Constants.shippingNotStart;
                }
				#endregion
				DrawMap(strSource, strDestination); //Draw map on page
				#region phone call feature 
				btnPhone.TouchUpInside += delegate
				{
                    var Confirm = new UIAlertView("CALL", "\n" + destinationAddress.Phone, null, "No", "Yes");
					Confirm.Show();
					Confirm.Clicked += (object senders, UIButtonEventArgs es) =>
					{
						if (es.ButtonIndex != 0)
						{
                            var url = new NSUrl("tel:" + destinationAddress.Phone);
                            UIApplication.SharedApplication.OpenUrl(url);
						}
					};
				};
				#endregion
				#region  pub nub settings and callback functionality
				PubNubAccountSetting();
				listener = new SubscribeCallbackExt(
				(o, m) =>
				{
					//Publisher Response
					if (m != null)
					{
						//Display(pubnub.JsonPluggableLibrary.SerializeToJsonString(m.Message));
						var demo = pubnub.JsonPluggableLibrary.SerializeToJsonString(m.Message);
						ShipmentStatus objShipmentStatus = JsonConvert.DeserializeObject<ShipmentStatus>(demo);
						// DriverStatus objDriverStatus 
						GetDirectionResponseAsync(objShipmentStatus);
					}
				},
				(o, p) =>
				{
					//Subscriber join or not 
					if (p != null)
					{
						//Display(p.Event);
					}
				},
				(o, s) =>
				{
					//status code of subscriber
					if (s != null)
					{
						//Display(s.Category + " " + s.Operation + " " + s.StatusCode);
					}
				}
				);
				#endregion
			}
			catch
			{
				Console.WriteLine(Helper.Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Images the details touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
        partial void ImgDetails_TouchUpInside(UIButton sender)
		{
			TrackShipDetailsController trackShipDetailsController;
			string shipmentStatus = string.Empty;
			trackShipDetailsController = (TrackShipDetailsController)this.Storyboard.InstantiateViewController("TrackShipDetailsController");
            if (!CommanUtil.IsTimeOut())
            {
                return;
            }
			if (lstShipmentActivity != null && lstShipmentActivity.Count > 0)
			{
                if (!string.IsNullOrEmpty(statusCode))
                {
                    shipmentStatus = trackingStatus[statusCode];
                }
                else
                {
                    shipmentStatus = lstShipmentActivity[lstShipmentActivity.Count - 1].Msg;
                }
			}
			else
			{
                if (!string.IsNullOrEmpty(statusCode))
                {
                    shipmentStatus = trackingStatus[statusCode];
                }
			}
            trackShipDetailsController.compositeKey = objRecentShipments.ClientID + "|" + objRecentShipments.BolNum;
			trackShipDetailsController.shipmentStatus = shipmentStatus;
			this.NavigationController.PushViewController(trackShipDetailsController, true);
		}

		/// <summary>
		/// Draws the map.
		/// </summary>
		/// <param name="originAdd">Origin add.</param>
		/// <param name="destinationAdd">Destination add.</param>
		public async void DrawMap(string originAdd, string destinationAdd)
		{
			try
			{
				CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
				if (loadPop == null)
				{
					loadPop = new LoadingOverlay(bounds);
				}
				View.Add(loadPop);
				//Get Lat and Long from Address
				await GeocodeToConsoleAsync(originAdd, destinationAdd);

				var camera = CameraPosition.FromCamera(latitude: SourceLocation.lat,
					   longitude: SourceLocation.lng,
					   zoom: 14);
				mapView = MapView.FromCamera(CGRect.Empty, camera);
				//mapView.MyLocationEnabled = true;
				//Sourec
				CLLocationCoordinate2D coord1 = new CLLocationCoordinate2D(SourceLocation.lat, SourceLocation.lng);
				var marker1 = Marker.FromPosition(coord1);
				marker1.Title = string.Format(strSource);
				marker1.Icon = UIImage.FromBundle("Images/MarkerSource.png");
				marker1.Map = mapView;
				//Destination
				CLLocationCoordinate2D coord2 = new CLLocationCoordinate2D(DestinationLocation.lat, DestinationLocation.lng);
				var marker2 = Marker.FromPosition(coord2);
				marker2.Title = string.Format(strDestination);
				marker2.Icon = UIImage.FromBundle("Images/MarkerDest.png");
				marker2.Map = mapView;
				mapView.Frame = viewMapControl.Bounds;
				//mapView.MyLocationEnabled = true;
				mapView.Settings.MyLocationButton = true;
				mapView.DidTapMyLocationButton = TapMyLocationButton();
                await BindShipmentDetails();
                await IsTrackingEnable();
                lstCountryDetails = new List<CountryDetails>();
                lstCountryDetails = await Util.GetCountryDetails();
				//View = mapView;
				viewMapControl.AddSubview(mapView);
				loadPop.Hide();
			}
			catch
			{
				Console.WriteLine(Helper.Constants.strErrorOccured);
				loadPop.Hide();
			}
			viewShowHide.Hidden = true;
			viewShowHide.RemoveFromSuperview();
		}

		/// <summary>
		/// Gets the current location.
		/// </summary>
		/// <returns><c>true</c>, if current location was gotten, <c>false</c> otherwise.</returns>
		public bool GetCurrentLocation()
		{
			isAnimateCamera = true;
			return true;
		}

		/// <summary>
		/// Taps my location button.
		/// </summary>
		/// <returns>The my location button.</returns>
		public GMSDidTapMyLocation TapMyLocationButton()
		{
			GMSDidTapMyLocation objGMSDidTapMyLocation = new GMSDidTapMyLocation((MapView mapView) => GetCurrentLocation());
			return objGMSDidTapMyLocation;	
		}

		/// <summary>
		/// Geocodes to console async.
		/// </summary>
		/// <returns>The to console async.</returns>
		/// <param name="originAdd">Origin add.</param>
		/// <param name="destinationAdd">Destination add.</param>
		private async Task GeocodeToConsoleAsync(string originAdd, string destinationAdd)
		{
			try
			{
				//mark source point
				CLLocation originCLlocation = new CLLocation();
				CLLocation destinationCLlocation = new CLLocation();
				var geocoder = new CLGeocoder();
				var placeMarkOrigin = geocoder.GeocodeAddressAsync(originAdd);
				await placeMarkOrigin.ContinueWith((addresses) =>
												{
													foreach (var address in addresses.Result)
													{
														originCLlocation = address.Location;
													}
												});

				if (originCLlocation != null)
				{
					SourceLocation = new Location() { lat = originCLlocation.Coordinate.Latitude, lng = originCLlocation.Coordinate.Longitude };
				}
				var placeMarkDest = geocoder.GeocodeAddressAsync(destinationAdd);
				await placeMarkDest.ContinueWith((addresses) =>
												{
													foreach (var address in addresses.Result)
													{
														destinationCLlocation = address.Location;
													}
												});
				if (destinationCLlocation != null)
				{
					DestinationLocation = new Location() { lat = destinationCLlocation.Coordinate.Latitude, lng = destinationCLlocation.Coordinate.Longitude };
				}
				originCLlocation = null;
				destinationCLlocation = null;
			}
			catch
			{
				Console.WriteLine(Helper.Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Pubs the nub account setting.
		/// </summary>
		public void PubNubAccountSetting()
		{
			try
			{
				config = new PNConfiguration();
				config.SubscribeKey = Helper.Constants.pubnubSubscribeKey;
				config.PublishKey = Helper.Constants.pubnubPublishKey;
				//config.Secure = true;
				config.PubnubLog = new LocalLog();
				config.LogVerbosity = PNLogVerbosity.BODY;
				config.ReconnectionPolicy = PNReconnectionPolicy.LINEAR;
				pubnub = new Pubnub(config);
				Subscribe(channel); //Susbriber for him/her self   
			}
			catch
			{
				Console.WriteLine(Helper.Constants.strErrorOccured);
			}
		}

        /// <summary>
        /// update current status of shipment.
        /// </summary>
        private void UpdateShipmentStatus()
        {
            try
            {
                if (!CommanUtil.IsTimeOut())
                {
                    return;
                }
                if (!Reachability.InternetConnectionStatus()) //Check Internet
                {
                    Toast.MakeText(Helper.Constants.strNoInternet).SetDuration(Helper.Constants.toastDuration).Show();
                    return;
                }
                if (currLocation == null)
                {
                    Toast.MakeText(Helper.Constants.strLocation).SetDuration(Helper.Constants.toastDuration).Show();
                    return;
                }
                if (string.IsNullOrEmpty(objRecentShipments.DriverID))
                {
                    Toast.MakeText(Helper.Constants.strAssignDriver).SetDuration(Helper.Constants.toastDuration).Show();
                    return;
                }
                string messgae = string.Empty;
                bool isAllowUpdate = true;
                statuscount += 1;
                // bool isUpdateTracking = true; //To Allow current Shipment status update
                switch (statuscount)
                {
                    case 1:
                        statusCode = Helper.Constants.inTransitkey;
                        shipmentStatusValue = Helper.Constants.pickedupKey;
                        //lblShipmentStatus.Text = trackingStatus[Helper.Constants.loadingkey];
                        isTrackingEnable = true;
                        break;
                    case 2:
                        statusCode = Helper.Constants.pickedupKey;
                        shipmentStatusValue = Helper.Constants.enRoutekey;
                        isAllowUpdate = false;
                        //lblShipmentStatus.Text = trackingStatus[Helper.Constants.enRoutekey];
                        break;
                    case 3:
                        statusCode = Helper.Constants.enRoutekey;
                        shipmentStatusValue = Helper.Constants.arrivedkey;
                        //lblShipmentStatus.Text = trackingStatus[Helper.Constants.arrivedkey];
                        break;
                    case 4:
                        statusCode = Helper.Constants.arrivedkey;
                        shipmentStatusValue = Helper.Constants.completedkey;
                        isAllowUpdate = false;
                        break;
                    case 5:
                        statusCode = Helper.Constants.completedkey;
                        shipmentStatusValue = Helper.Constants.completedkey;
                        break;
                    default:
                        statusCode = Helper.Constants.completedkey;
                        shipmentStatusValue = trackingStatus[Helper.Constants.completedkey];
                        lblCurrentStatus.Text = trackingStatus[Helper.Constants.completedkey];
                        lblShipmentStatus.Text = trackingStatus[Helper.Constants.completedkey];
                        Toast.MakeText(Helper.Constants.shipmentCompleted).SetDuration(Helper.Constants.toastDuration).Show();
                        return;
                }
                if (statusCode == Helper.Constants.completedkey)
                {
                    messgae = Helper.Constants.updateStatusCompleted;
                }
                else
                {
                    messgae = string.Format(Helper.Constants.updateStatusConfimation, trackingStatus[statusCode], trackingStatus[shipmentStatusValue]);
                }
                UpdateStatusWarningPopup objUpdateStatusWarningPopup
                = new UpdateStatusWarningPopup(this.View, messgae, this, statusCode, shipmentStatusValue, isAllowUpdate);
                View.AddSubview(objUpdateStatusWarningPopup.GetWarningPop());
            }
            catch
            {
                Console.Write(Helper.Constants.ErrorMsg);
            }
        }

        /// <summary>
        /// Distances the confirmation alert.
        /// </summary>
        /// <param name="statusCode">Status code.</param>
        /// <param name="statusValue">Status value.</param>
        public async void DistanceConfirmationAlert(string statusCode, string statusValue)
        {
            try
            {
                string alertMsg = string.Empty;
                CLLocation pointB = new CLLocation(currLocation.Coordinate.Latitude, currLocation.Coordinate.Longitude);
                CLLocation pointA = new CLLocation(SourceLocation.lat, SourceLocation.lng);
                decimal distBtwSrcCurrent = Util.GetDistance(pointA, pointB);
                if (Convert.ToDouble(distBtwSrcCurrent) <= Helper.Constants.distBtwSrcCurrent)
                {
                    //status = "ARRIVED";
                    //this.statusCode = statusCode;
                    //this.shipmentStatusValue = trackingStatus[statusCode];
                    //lblShipmentStatus.Text = trackingStatus[statusValue];
                    //lblCurrentStatus.Text = trackingStatus[statusCode];
                    await UpdateLiveShipmentStatus(statusCode, statusValue, true); //update the status API 
                }
                else
                {
                    //isUpdateTracking = false;
                    //statuscount -= 1;
                    alertMsg = Helper.Constants.strYouAre + distBtwSrcCurrent + Helper.Constants.mile;
                    if (statusCode == Helper.Constants.arrivedkey)
                    {
                        alertMsg += Helper.Constants.strAwayFromDrop;
                    }
                    else
                    {
                        alertMsg += Helper.Constants.strAwayFromPickup;
                    }
                    //Toast.MakeText(Helper.Constants.notNearPickupLocation).SetDuration(Helper.Constants.toastDuration).Show();
                    UpdateStatusWarningPopup objUpdateStatusWarningPopup 
                    = new UpdateStatusWarningPopup(this.View, alertMsg, this, statusCode, statusValue, true);
                    View.AddSubview(objUpdateStatusWarningPopup.GetWarningPop());
                }
            }
            catch
            {
                Toast.MakeText(Helper.Constants.strErrorOccured).SetDuration(Helper.Constants.toastDuration).Show();
            }
        }

		/// <summary>
		/// Updates the live shipment status.
		/// </summary>
		/// <returns>The live shipment status.</returns>
        /// <param name="Code">Status code.</param>
        /// <param name="statusValue">Shipment status value.</param>
        /// <param name="isAllowConfirmation">If set to <c>true</c> is allow.</param>
        public async Task UpdateLiveShipmentStatus(string Code,string statusValue,bool isAllowConfirmation)
		{
			try
			{
                if (isAllowConfirmation)
				{
					#region UpdateShipmentStatus real time status of shipment
					string statusResult = string.Empty;
					//this.status = status;
					
					//isTrackingEnable = true;
					loadPop = null;
					CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
					if (loadPop == null)
					{
						loadPop = new LoadingOverlay(bounds);
					}
					View.Add(loadPop);
                    await Task.Delay(1000);

                    Models.UpdateRealTimeStatus updateRealTimeStatus = new Models.UpdateRealTimeStatus();
                    updateRealTimeStatus.driverID = objRecentShipments.DriverID;
                    updateRealTimeStatus.bolNum = objRecentShipments.BolNum;
                    if ((int)CommanUtil.currLat == 0)
                    {
                        updateRealTimeStatus.lat = Convert.ToString(SourceLocation.lat);
                        updateRealTimeStatus.Long = Convert.ToString(SourceLocation.lng);
                    }
                    else
                    {
                        updateRealTimeStatus.lat = Convert.ToString(CommanUtil.currLat);
                        updateRealTimeStatus.Long = Convert.ToString(CommanUtil.currentLng);
                    }
                    updateRealTimeStatus.status = Code;
                    updateRealTimeStatus.clientID = objRecentShipments.ClientID;
                    statusResult = await Util.UpdateRealTimeStatus(updateRealTimeStatus);
                    //updateRealTimeStatus = null;

                    if (!string.IsNullOrEmpty(statusResult))
                    {
                        await UpdateShipmentStatus(Code, trackingStatus[Code]);//Update status of shipment in RatleLinx-SC2 Tracking API
                        this.statusCode = Code;
                        this.shipmentStatusValue = trackingStatus[Code];
                        //lblShipmentStatus.Text = trackingStatus[this.shipmentStatusValue];//Display Swip button text
                        lblShipmentStatus.Text = trackingStatus[statusValue];
                        lblCurrentStatus.Text = trackingStatus[Code];
                        //Live status
                        liveStatusCode = Code;
                        liveStatusText = trackingStatus[Code]; 
                    }
                    else
                    {
                        statuscount -= 1;
                        Toast.MakeText(statusResult).SetDuration(Helper.Constants.toastDuration).Show();
                    }
                    if (loadPop != null)
					{
						loadPop.Hide();
					}
					Toast.MakeText(statusResult).SetDuration(Helper.Constants.toastDuration).Show();
					#endregion
				}
				else
				{
						statuscount -= 1;
				}
			}
			catch(Exception e)
			{
                loadPop.Hide();
                Toast.MakeText(e.Message).SetDuration(Helper.Constants.toastDuration).Show();
			}
		}



        /// <summary>
        /// Ises the tracking enable.
        /// </summary>
        public async Task IsTrackingEnable()
        {
            try
            {
                //Check the status of shipment
                lstShipmentActivity = await Util.GetRealtimeShipmentStatus(objRecentShipments.ClientID + "/" + objRecentShipments.BolNum);
                if (lstShipmentActivity != null && lstShipmentActivity.Count > 0)
                {
                    isTrackingEnable = true;
                    if (lstShipmentActivity[lstShipmentActivity.Count - 1].Status == Helper.Constants.inTransitkey)
                    {
                        statuscount = 1;
                        statusCode = Helper.Constants.inTransitkey;
                        shipmentStatusValue = trackingStatus[Helper.Constants.inTransitkey];
                        lblCurrentStatus.Text = trackingStatus[Helper.Constants.inTransitkey];
                        lblShipmentStatus.Text = trackingStatus[Helper.Constants.pickedupKey];
                        liveStatusCode=Helper.Constants.inTransitkey;
                        liveStatusText = trackingStatus[Helper.Constants.inTransitkey]; 
                    }
                    else if (lstShipmentActivity[lstShipmentActivity.Count - 1].Status == Helper.Constants.pickedupKey)
                    {
                        statuscount = 2;
                        statusCode = Helper.Constants.pickedupKey;
                        shipmentStatusValue = trackingStatus[Helper.Constants.pickedupKey];
                        lblCurrentStatus.Text = trackingStatus[Helper.Constants.pickedupKey];
                        lblShipmentStatus.Text = trackingStatus[Helper.Constants.enRoutekey];
                        liveStatusCode=Helper.Constants.pickedupKey;
                        liveStatusText = trackingStatus[Helper.Constants.pickedupKey]; 
                    }
                    else if (lstShipmentActivity[lstShipmentActivity.Count - 1].Status == Helper.Constants.enRoutekey)
                    {
                        statuscount = 3;
                        statusCode = Helper.Constants.enRoutekey;
                        shipmentStatusValue = trackingStatus[Helper.Constants.enRoutekey];
                        lblCurrentStatus.Text = trackingStatus[Helper.Constants.enRoutekey];
                        lblShipmentStatus.Text = trackingStatus[Helper.Constants.arrivedkey];
                        liveStatusCode=Helper.Constants.enRoutekey;
                        liveStatusText = trackingStatus[Helper.Constants.enRoutekey]; 
                    }
                    else if (lstShipmentActivity[lstShipmentActivity.Count - 1].Status == Helper.Constants.arrivedkey)
                    {
                        statuscount = 4;
                        statusCode = Helper.Constants.arrivedkey;
                        shipmentStatusValue = trackingStatus[Helper.Constants.arrivedkey];
                        lblCurrentStatus.Text = trackingStatus[Helper.Constants.arrivedkey];
                        lblShipmentStatus.Text = trackingStatus[Helper.Constants.completedkey];
                        liveStatusCode=Helper.Constants.arrivedkey;
                        liveStatusText = trackingStatus[Helper.Constants.arrivedkey]; 
                    }
                    else if (lstShipmentActivity[lstShipmentActivity.Count - 1].Status == Helper.Constants.completedkey)
                    {
                        statuscount = 5;
                        statusCode = Helper.Constants.completedkey;
                        shipmentStatusValue = trackingStatus[Helper.Constants.completedkey];
                        lblCurrentStatus.Text = trackingStatus[Helper.Constants.completedkey];
                        lblShipmentStatus.Text = trackingStatus[Helper.Constants.completedkey];
                        liveStatusCode=Helper.Constants.completedkey;
                        liveStatusText = trackingStatus[Helper.Constants.completedkey]; 
                        ResetTracking(); //Reset tracking details
                    }
                }
            }
            catch
            {
                Console.WriteLine(Helper.Constants.strErrorOccured);
            }
        }

        /// <summary>
        /// Binds the shipment details.
        /// </summary>
        /// <returns>The shipment details.</returns>
        public async Task BindShipmentDetails()
        {
            try
            {
                if (!string.IsNullOrEmpty(CommanUtil.tokenNo))
                {
                    ServiceHelper objServicehelper = new ServiceHelper();
                    //Method Name
                    string methodName = APIMethods.shipmentDetails + "/" + objRecentShipments.ClientID + "|" + objRecentShipments.BolNum + "|" + "";
                    string strResponse = await objServicehelper.GetRequest(CommanUtil.tokenNo, methodName, true);
                    if (!string.IsNullOrEmpty(strResponse))
                    {
                        JObject jobject = JObject.Parse(strResponse);
                        if (string.IsNullOrEmpty(Convert.ToString(jobject["Message"])))
                        {
                            CarrierShipmentDetails carrierShipmentDetails = JsonConvert.DeserializeObject<CarrierShipmentDetails>(strResponse);
                            if(carrierShipmentDetails!=null)
                            {
                                destinationAddress = carrierShipmentDetails.Addresses[1];
                            }
                        }
                        else
                        {
                            strResponse = string.Empty;
                            //Post Error Logger Request 
                            await Util.ErrorLog("API-ShipmentDetail", Convert.ToString(jobject["Message"]), CommanUtil.tokenNo);
                        }
                    }
                    else
                    {
                       
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                //string message = ex.Message;
               // return ex.Message;
            }
        }

        /// <summary>
        /// Updates the shipment status in RateLinx-Sc 2 API
        /// </summary>
        /// <returns>The shipment status.</returns>
        /// <param name="statusCode">Status code.</param>
        /// <param name="shipmentStatus">Shipment status.</param>
        public async Task UpdateShipmentStatus(string statusCode, string shipmentStatus)
        {
            try
            {
                if (!CommanUtil.IsTimeOut())
                {
                    return;
                }
                if (!Reachability.InternetConnectionStatus()) //Check Internet
                {
                    Toast.MakeText(Helper.Constants.strNoInternet).SetDuration(Helper.Constants.toastDuration).Show();
                    return;
                }
                var geoCoder = new CLGeocoder();
                var placemarks = await geoCoder.ReverseGeocodeLocationAsync(currLocation);
                if (placemarks != null)
                {
                    foreach (var placemark in placemarks)
                    {
                        city = placemark.Locality;
                        state = placemark.AdministrativeArea;
                        country = placemark.IsoCountryCode;

                        var code = GetCountry(country, state);
                        var countryCode = code.Item1;
                        var stateCode = code.Item2;

                        string payload_str = "{"
                                + "\"ProNumber\":" + "\"" + objRecentShipments.ProNum + "\","
                                    + "\"ActivityDate\":" + "\"" + DateTime.Now + "\","
                                    + "\"ActivityCode\":" + "\"" + statusCode + "\","
                                    + "\"ActivityDescr\":" + "\"" + shipmentStatus + "\","
                                    + "\"City\":" + "\"" + city + "\","
                                    + "\"State\":" + "\"" + stateCode + "\","   //state  - up
                                    + "\"Country\":" + "\"" + countryCode + "\""
                                    +
                                                                              "}";
                        string methodURI = APIMethods.shipmentDetails + "/" + objRecentShipments.ClientID + "|" + objRecentShipments.LocID + "|" + objRecentShipments.BolNum + "/" + APIMethods.tracking;
                        ServiceHelper objServiceHelper = new ServiceHelper();
                        await objServiceHelper.PostRequestJson(payload_str, methodURI, CommanUtil.tokenNo, true);
                    }
                }
                //else
                //{
                //  //Toast.MakeText(Helper.Constants.strLocation).SetDuration(5 * 1000).Show();
                //}
                geoCoder = null;
            }
            catch
            {
                Console.Write(Helper.Constants.strErrorOccured);
            }
        }



		//int count = 0;
		///// <summary>
		///// Only For Testing purpose
		///// </summary>
		//private async void PublishCountdown()
		//{
		//	try
		//	{
		//		isTrackingEnable = true;
		//		//For Testing
		//		while (isTrackingEnable && latlong.Length > count)
		//		{
		//			Publish(Convert.ToString(latlong[count]), true);
		//			count++;
		//			await Task.Delay(1000);
		//		}
		//	}
		//	catch
		//	{
		//		Console.Write(Helper.Constants.ErrorMsg);
		//	}
		//}


		/// <summary>
		/// Publish the specified latLong.
		/// </summary>
		/// <returns>The publish.</returns>
		/// <param name="latLong">Lat long.</param>
		public async void Publish(string latLong, bool isLocationEnable)
		{
			try
			{
				#region Check internet and GPS connectivity
				if (!Reachability.InternetConnectionStatus())
				{
					Toast.MakeText(Helper.Constants.strNoInternet).SetDuration(Helper.Constants.toastDuration).Show();
					return;
				}
				if (!isLocationEnable)
				{
					Toast.MakeText(Helper.Constants.strLocation).SetDuration(Helper.Constants.toastDuration).Show();
					return;
				}
				#endregion
				if (!string.IsNullOrEmpty(statusCode))
				{
                    if (statusCode != Helper.Constants.completedkey && isTrackingEnable)
					{
						await PublishShipmentStatus(latLong);
					}
					else
					{
                        if (statusCode == Helper.Constants.completedkey && isTrackingEnable)
						{
							await PublishShipmentStatus(latLong);
							ResetTracking();
							//isTrackingEnable = false;
							//Unsub(objRecentShipments.ClientID + objRecentShipments.BolNum.Trim());
							//RemoveChannelFromChannelGroup(objRecentShipments.ClientID + objRecentShipments.BolNum.Trim());
						}
					}
				}
			}
			catch
			{
				Console.WriteLine(Helper.Constants.strErrorMessage);
			}
		}

		/// <summary>
		/// Publishs the shipment status.
		/// </summary>
		/// <param name="latLong">Lat long.</param>
		public async Task PublishShipmentStatus(string latLong)
		{
			try
			{
				#region Assigning Data in model properties 
				//LatLng previousLatLong = new LatLng(0, 0);
				CLLocationCoordinate2D previousLatLong = new CLLocationCoordinate2D(0, 0);
				decimal previousDistance = 0;
				string previousTime = string.Empty;
				decimal currentDistance = 0;
				string shipmentStatusRes = NSUserDefaults.StandardUserDefaults.StringForKey(objRecentShipments.ClientID + objRecentShipments.BolNum);
				if (!string.IsNullOrEmpty(shipmentStatusRes))
				{
					ShipmentStatus objShipmentStatusResponse = JsonConvert.DeserializeObject<ShipmentStatus>(shipmentStatusRes);
					previousLatLong = new CLLocationCoordinate2D(Convert.ToDouble(objShipmentStatusResponse.CurrentLat), Convert.ToDouble(objShipmentStatusResponse.CurrentLong));
					previousDistance = objShipmentStatusResponse.DistanceTravelled;
					previousTime = objShipmentStatusResponse.TimeTaken;
				}
				else
				{
					previousLatLong = new CLLocationCoordinate2D(SourceLocation.lat, SourceLocation.lng);
					previousDistance = 0;
				}
				ShipmentStatus objShipmentStatus = new ShipmentStatus();
				//GPSService objGPSService = new GPSService(this);
				//LatLng currentLatLong = new LatLng(Convert.ToDouble(latLong.Split(',')[0]), Convert.ToDouble(latLong.Split(',')[1]));
				CLLocationCoordinate2D currentLatLong = new CLLocationCoordinate2D(Convert.ToDouble(latLong.Split(',')[0]), Convert.ToDouble(latLong.Split(',')[1]));
				//LatLng currentLatLong = new LatLng(CommanUtil.currLat, CommanUtil.currLong);
				if ((int)currentLatLong.Latitude == 0 && (int)currentLatLong.Longitude == 0)
				{
					currentLatLong = previousLatLong;
				}
				CLLocation pointA = new CLLocation(previousLatLong.Latitude, previousLatLong.Longitude);
				CLLocation pointB = new CLLocation(currentLatLong.Latitude, currentLatLong.Longitude);
				//var distanceToB = pointB.DistanceFrom(pointA);
				currentDistance = previousDistance + Util.GetDistance(pointA, pointB);
				objShipmentStatus.TimeTaken = RunTimer(previousTime);
				objShipmentStatus.CurrentLocation = await GetCurrentAddress(currentLatLong);
				objShipmentStatus.CurrentLat = Convert.ToString(currentLatLong.Latitude);
				objShipmentStatus.CurrentLong = Convert.ToString(currentLatLong.Longitude);
				objShipmentStatus.DistanceTravelled = currentDistance;
				objShipmentStatus.DistanceLeft = Convert.ToDecimal(totalDistance - currentDistance);
				objShipmentStatus.ShipmentCurrStatus = shipmentStatusValue;
				objShipmentStatus.BolNo = objRecentShipments.BolNum.Trim();
				objShipmentStatus.DriverID = objRecentShipments.DriverID;
				NSUserDefaults.StandardUserDefaults.SetString(JsonConvert.SerializeObject(objShipmentStatus), objRecentShipments.ClientID + objRecentShipments.BolNum);
				#endregion
				#region Publish Data in pubNub
				ThreadPool.QueueUserWorkItem(o =>
					 pubnub.Publish()
					 .Channel(objRecentShipments.ClientID + objRecentShipments.BolNum.Trim())
					.Message(objShipmentStatus)
					 .ShouldStore(true)
					 .Async(new DemoPublishResult(Display))
											);
				#endregion
			}
			catch (Exception ex)
			{
				Toast.MakeText(ex.Message).SetDuration(Helper.Constants.toastDuration).Show();
			}
		}

		/// <summary>
		/// Gets the direction response async.
		/// </summary>
		/// <returns>The direction response async.</returns>
		/// <param name="objShipmentStatus">Object shipment status.</param>
		public void GetDirectionResponseAsync(ShipmentStatus objShipmentStatus)
		{
			try
			{
				CLLocationCoordinate2D currentCoordinate = new CLLocationCoordinate2D(Convert.ToDouble(objShipmentStatus.CurrentLat), Convert.ToDouble(objShipmentStatus.CurrentLong));
				if (mapView != null && (int)currentCoordinate.Latitude != 0)
				{
					BeginInvokeOnMainThread(new Action(delegate
					{
						//var bearing = currentCoordinate.
						if ((int)pevCoordinate.Latitude == 0)
						{
							pevCoordinate = currentCoordinate;
						}
						if ((int)currentCoordinate.Latitude != 0 && (int)currentCoordinate.Longitude != 0)
						{
							float bearing = Util.BearingBetweenLocation(pevCoordinate, currentCoordinate);
							if (float.IsNaN(bearing) || (int)bearing == 0)
							{
								bearing = 180;
							}
							if (marker3 != null)
							{
                                
								//marker3.Position = currentCoordinate;
								//marker3.Rotation = bearing;
								//marker3.Flat = true;
								//marker3.GroundAnchor = new CGPoint(0.5f, 0.5f);
								//marker3.AppearAnimation = MarkerAnimation.Pop;apView;
								//marker3.Map = null;
								////marker3 = new Marker();
								//marker3.AppearAnimation = MarkerAnimation.Pop;
								//marker3 = Marker.FromPosition(currentCoordinate);
								//if (!string.IsNullOrEmpty(objShipmentStatus.CurrentLocation))
								//{
								//	marker3.Title = string.Format(objShipmentStatus.CurrentLocation);
								//}
								//marker3.Icon = UIImage.FromBundle("Images/CarTopView2.png");
								////marker3.Draggable = true;
								//marker3.Rotation = bearing;
								//marker3.Flat = true;
								//marker3.GroundAnchor = new CGPoint(0.5f, 0.5f);
								//marker3.Map = mapView;
                                AnimateMarker(pevCoordinate, currentCoordinate, bearing);
							}
							else
							{
								marker3 = new Marker();
								//marker3.AppearAnimation = MarkerAnimation.Pop;
								marker3 = Marker.FromPosition(currentCoordinate);
								if (!string.IsNullOrEmpty(objShipmentStatus.CurrentLocation))
								{
									marker3.Title = string.Format(objShipmentStatus.CurrentLocation);
								}
								marker3.Icon = UIImage.FromBundle("Images/CarTopView2.png");
								//marker3.Draggable = true;
								marker3.Rotation = bearing;
								marker3.Flat = true;
								marker3.GroundAnchor = new CGPoint(0.5f, 0.5f);
								marker3.Map = mapView;
							}

							//Draw line by connecting polyline points

							//GoogleDirectionClass obGoogleDirectionClass = await DrawLineBtwAddress(currentCoordinate, pevCoordinate);
							//////available routes may be more then one
							//if (obGoogleDirectionClass != null && obGoogleDirectionClass.routes.Count > 0)
							//{
							//	var path = Google.Maps.Path.FromEncodedPath(obGoogleDirectionClass.routes[0].overview_polyline.points);
							//	var line = Google.Maps.Polyline.FromPath(path);
							//	line.StrokeWidth = 3f;
							//	line.StrokeColor = UIColor.Black;
							//	line.Geodesic = true; //more curved path
							//	line.Map = mapView;
							//}
							//path.AddCoordinate(pevCoordinate);
							//path.AddCoordinate(currentCoordinate);
							//Google.Maps.Polyline line = Google.Maps.Polyline.FromPath(path);
							//line.StrokeWidth = 1f;
							//line.StrokeColor = UIColor.Black;
							//line.Geodesic = true; //more curved path
							//line.Map = mapView;
							//Set camera position
							var camera = CameraPosition.FromCamera(currentCoordinate.Latitude,
																   currentCoordinate.Longitude,
																   currentZoomLevel);

							//mapView.Camera = camera;
							if (isAnimateCamera)
							{
								mapView.Animate(camera);
							}
							//Assign Old Latitude and Longitude
							pevCoordinate = currentCoordinate;
                            //
                            lblMiles.Text = objShipmentStatus.DistanceTravelled + Helper.Constants.mile; //GetDistance(StartLatLong, currentLatLang) + " Miles";//Calculate time
							lblTotalTime.Text = objShipmentStatus.TimeTaken; // RunTimer(); //calculate time
							//Camera change event 
							mapView.CameraPositionChanged += HandleChangedCameraPosition;

						}
					}));

				}
			}
			catch (Exception ex)
			{
				Console.Write(ex.Message);
			}
		}


        /// <summary>
        /// Animates the marker.
        /// </summary>
        /// <param name="marker">Marker.</param>
        /// <param name="currentLatLong">Current lat long.</param>
        /// <param name="rotation">Rotation.</param>
        public void AnimateMarker(CLLocationCoordinate2D marker, CLLocationCoordinate2D currentLatLong, float rotation)
        {
            try
            {
                float start = 1000 * ((float)NSProcessInfo.ProcessInfo.SystemUptime);
                NSTimer.InvokeInBackground(Run);
                void Run()
                {
                    float elapsed = ((float)NSProcessInfo.ProcessInfo.SystemUptime) * 1000 - start;
                    float t = elapsed / 600;
                    double lng = t * currentLatLong.Longitude + (1 - t)
                                                   * marker.Longitude;
                    double lat = t * currentLatLong.Latitude + (1 - t)
                                                   * marker.Latitude;

                    BeginInvokeOnMainThread(new Action(delegate
                    {
                        if (marker3 != null)
                        {
                            marker3.Map = null;
                        }
                        CLLocationCoordinate2D CurrPOS = new CLLocationCoordinate2D(lat, lng);
                        marker3 = Marker.FromPosition(CurrPOS);
                        marker3.Icon = UIImage.FromBundle("Images/CarTopView2.png");
                    //marker3.Draggable = true;
                    marker3.Rotation = rotation;
                        marker3.Flat = true;
                        marker3.GroundAnchor = new CGPoint(0.5f, 0.5f);
                        marker3.Map = mapView;
                        if (t < 1.0)
                        {
                        // Post again 16ms later.
                        //NSTim
                        Task.Delay(16);
                            NSTimer.InvokeInBackground(Run);
                        }
                        else
                        {
                            path.AddCoordinate(pevCoordinate);
                            path.AddCoordinate(CurrPOS);
                            Google.Maps.Polyline line = Google.Maps.Polyline.FromPath(path);
                            line.StrokeWidth = 1f;
                            line.StrokeColor = UIColor.Black;
                            line.Geodesic = true; //more curved path
                        line.Map = mapView;
                        }

                    }));
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

		/// <summary>
		/// Handles the changed camera position.
		/// </summary>
		/// <param name="sender">Sender.</param>
		/// <param name="e">E.</param>
		void HandleChangedCameraPosition(object sender, GMSCameraEventArgs e)
		{
			if ((int)e.Position.Zoom != (int)currentZoomLevel)
			{
				//Console.WriteLine("Postion: {0}", e.Position.Target);
				currentZoomLevel = e.Position.Zoom;
				isAnimateCamera = false;
			}

		}


		/// <summary>
		/// Gets the current address.
		/// </summary>
		public async Task<string> GetCurrentAddress(CLLocationCoordinate2D location)
		{
			try
			{
				string address = string.Empty;
				CLLocation clLocation = new CLLocation(location.Latitude, location.Longitude);
				var geoCoder = new CLGeocoder();
				var placemarks = await geoCoder.ReverseGeocodeLocationAsync(clLocation);
				foreach (var placemark in placemarks)
				{
					address = placemark.Country + " " + placemark.Locality + " " + placemark.AdministrativeArea;
				}
				clLocation = null;
				geoCoder = null;
				return address;
			}
			catch
			{
				return "";
			}
		}

        /// <summary>
        /// Method to get country and state code
        /// </summary>
        /// <param name="country"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        public (string, string) GetCountry(string country = "", string state = "")
        {
            string countryCode = "";
            string stateCode = "";
            try
            {
                if (lstCountryDetails != null)
                {
                    var lstCountry = lstCountryDetails.Where(m => m.Name.Equals(country.ToUpper())).FirstOrDefault();
                    if (lstCountry != null)
                    {
                        countryCode = lstCountry.Code;
                        if (lstCountry.States != null)
                        {
                            stateCode = lstCountry.States.Where(m => m.Name.Equals(state.ToUpper())).Select(m => m.Code).FirstOrDefault();
                        }
                        if(string.IsNullOrEmpty(stateCode))
                        {
                            stateCode = state;
                        }
                    }
                    else
                    {
                        countryCode = country;
                        stateCode = state;
                    }
                }
            }
            catch
            {
                Toast.MakeText(Helper.Constants.strErrorOccured).SetDuration(Helper.Constants.toastDuration).Show();

                return (countryCode, stateCode);
            }
            return (countryCode, stateCode);
        }

		/// <summary>
		/// Runs the timer.
		/// </summary>
		/// <returns>The timer.</returns>
		/// <param name="previousTime">Previous time.</param>
		public string RunTimer(string previousTime)
		{
			if (!string.IsNullOrEmpty(previousTime))
			{
				string[] strTimer = previousTime.Split(':');
				seconds = Convert.ToInt32(strTimer[2]);
				minutes = Convert.ToInt32(strTimer[1]);
				hours = Convert.ToInt32(strTimer[0]);
			}
			//string result = string.Empty;
			string secs = string.Empty;
			string mins = string.Empty;
			string hrs = string.Empty;
			if (seconds <= 59)
			{
				seconds++;
			}
			if (seconds == 60)
			{
				seconds = 00;
				if (minutes <= 59)
				{
					minutes++;
				}
				if (minutes == 60)
				{
					minutes = 00;
					hours++;
				}
			}
			if (seconds >= 0 && seconds <= 9)
			{
				secs = "0" + Convert.ToString(seconds);
			}
			else
			{
				if (Convert.ToString(seconds) == "60")
				{
					secs = "00";
				}
				else
				{
					secs = Convert.ToString(seconds);
				}
			}

			if (minutes >= 0 && minutes <= 9)
			{
				mins = "0" + Convert.ToString(minutes);
			}
			else
			{
				if (Convert.ToString(minutes) == "60")
				{
					mins = "00";
					minutes = 00;
				}
				else
				{
					mins = Convert.ToString(minutes);
				}

			}
			if (hours >= 0 && hours <= 9)
			{
				hrs = "0" + Convert.ToString(hours);
			}
			else
			{
				if (Convert.ToString(hours) == "60")
				{
					hrs = "00";
				}
				else
				{
					hrs = Convert.ToString(hours);
				}
			}

			return hrs + " : " + mins + " : " + secs;
		}

		/// <summary>
		/// Subscribe the specified subscriber.
		/// </summary>
		/// <returns>The subscribe.</returns>
		/// <param name="subscriber">Subscriber.</param>
		public void Subscribe(string subscriber)
		{
			//Display("Running " + subscriber + "");
			ThreadPool.QueueUserWorkItem(o =>
			{
				pubnub.AddListener(listener);
				pubnub.Subscribe<object>()
						.Channels(new[] { subscriber })
					  .WithPresence().Execute();
			}
			);
		}

		/// <summary>
		/// Unsub the specified channel.
		/// </summary>
		/// <returns>The unsub.</returns>
		/// <param name="channel">Channel.</param>
		private void Unsub(string channel)
		{
			// Display("Running unsubscribe to  " + channel + "");
			ThreadPool.QueueUserWorkItem(o =>
			{
				pubnub.Unsubscribe<string>()
				   .Channels(new[] { channel })
				   .ChannelGroups(new[] { channelGroup }).Execute();
				pubnub.RemoveListener(listener);

			}
			);
		}

		/// <summary>
		/// Remove Channels 
		/// </summary>
		private void RemoveChannelFromChannelGroup(string channel)
		{
			//Display("Running RemoveChannelsFromChannelGroup");
			ThreadPool.QueueUserWorkItem(o =>
				 pubnub.RemoveChannelsFromChannelGroup()
				 .Channels(new[] { channel })
				 .Async(new DemoChannelGroupRemoveChannel(Display))
										);
		}

		/// <summary>
		/// Rest tracking and unsubscribe  
		/// </summary>
		void ResetTracking()
		{
			try
			{
				isTrackingEnable = false;
                Unsub(objRecentShipments.ClientID + objRecentShipments.BolNum.Trim());
                //RemoveChannelFromChannelGroup(objRecentShipments.ClientID + objRecentShipments.BolNum.Trim());
				NSUserDefaults.StandardUserDefaults.RemoveObject(objRecentShipments.ClientID + objRecentShipments.BolNum);
				//Utility.sharedPreferences.Edit().Remove(clientID + txtBolNumber.Text.Trim()).Commit();
			}
			catch
			{
				Console.WriteLine("");
			}
		}

		/// <summary>
		/// Display the specified strText.
		/// </summary>
		/// <returns>The display.</returns>
		/// <param name="strText">String text.</param>
		public void Display(string strText)
		{
			//Console.Write("Tets");
		}

		/// <summary>
		/// Backs the button touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BackButton_TouchUpInside(UIButton sender)
		{
			//NavigationController.PopViewController(true);
            DashboardController dashboardController =
                            this.Storyboard.InstantiateViewController
                            ("DashboardController") as DashboardController;
            this.NavigationController.PushViewController(dashboardController, true);
		}

        /// <summary>
        /// Sliders the touch up inside.
        /// </summary>
        /// <param name="sender">Sender.</param>
        partial void SliderTouchUpInside(UISlider sender)
        {
            if (sender.Value > 0.7)
            {
                BeginInvokeOnMainThread(async delegate
                {
                    UpdateShipmentStatus();
                });
                sender.Value = 0.0f;
            }
            else
            {
                sender.Value = 0.0f;
            }
        }

		/// <summary>
		/// Gets the location mgr.
		/// </summary>
		/// <value>The location mgr.</value>
		public CLLocationManager LocMgr
		{
			get { return this.locMgr; }
		}

		/// <summary>
		/// Starts the location updates.
		/// </summary>
		public void StartLocationUpdates()
		{
			try
			{
				// We need the user's permission for our app to use the GPS in iOS. This is done either by the user accepting
				// the popover when the app is first launched, or by changing the permissions for the app in Settings
				if (CLLocationManager.LocationServicesEnabled)
				{
					//set the desired accuracy, in meters
                    //LocMgr.DesiredAccuracy = CLLocation.AccuracyBest;
                    LocMgr.DesiredAccuracy = 1;
					LocMgr.LocationsUpdated += (object sender, CLLocationsUpdatedEventArgs e) =>
					{
                        // fire our custom Location Updated event
                        LocationUpdated(this, new LocationUpdatedEventArgs(e.Locations[e.Locations.Length - 1]));
					};
					LocMgr.StartUpdatingLocation();
				}
                else
                {
                    Toast.MakeText(Helper.Constants.strLocation).SetDuration(Helper.Constants.toastDuration).Show();
                }
			}
            catch(Exception e)
			{
                Console.WriteLine(e.Message);
			}
		}

        //int count = 0;
        /// <summary>
        /// Prints the location.
        /// </summary>
        /// <param name="sender">Sender.</param>
        /// <param name="e">E.</param>
        public void PrintLocation(object sender, LocationUpdatedEventArgs e)
        {
            try
            {
                currLocation = e.Location;
                //string latLong = currLocation.Coordinate.Latitude + "," + currLocation.Coordinate.Longitude;
                if (isTrackingEnable)
                {
                    Publish(currLocation.Coordinate.Latitude + "," + currLocation.Coordinate.Longitude, true);
                    //count++; && latlong.Length > count
                }
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }
        }

		partial void SliderDragExit(UISlider sender)
		{
			sender.Value = 0.0f;
		}
	}
}
