using Foundation;
using System;
using UIKit;

namespace RateLinx.iOS
{
    public partial class ActiveShipments : UITabBarItem
    {
        public ActiveShipments (IntPtr handle) : base (handle)
        {
        }
    }
}