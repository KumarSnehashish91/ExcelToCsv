﻿using System;
using UIKit;
using CoreGraphics;
using System.Drawing;
using Foundation;

public class LoadingOverlay : UIView
{

	public LoadingOverlay(CGRect frame) : base(frame)
	{
		try
		{
			BackgroundColor = UIColor.LightTextColor;
			Alpha = 0.75f;
			AutoresizingMask = UIViewAutoresizing.All;

				
			var imageView = new UIImageView();

			imageView.Frame = new CoreGraphics.CGRect(UIScreen.MainScreen.Bounds.Width / 2 - 17.5, UIScreen.MainScreen.Bounds.Height / 2 - 17.5, 25, 25);

				imageView.AnimationImages = new UIImage[] {
				  UIImage.FromBundle ("Images/loadingiconNewRed.png")
				, UIImage.FromBundle ("Images/loadingiconGray.png")
				, UIImage.FromBundle ("Images/loadingiconGray.png")
				, UIImage.FromBundle ("Images/loadingiconGray.png")
			};


				var imageView2 = new UIImageView();
				imageView2.Frame = new CoreGraphics.CGRect(UIScreen.MainScreen.Bounds.Width / 2 + 17.5, UIScreen.MainScreen.Bounds.Height / 2 - 17.5, 25, 25);

				imageView2.AnimationImages = new UIImage[] {
				  UIImage.FromBundle ("Images/loadingiconGray.png")
				, UIImage.FromBundle ("Images/loadingiconNewRed.png")
				, UIImage.FromBundle ("Images/loadingiconGray.png")
				, UIImage.FromBundle ("Images/loadingiconGray.png")
			};


				var imageView3 = new UIImageView();
				imageView3.Frame = new CoreGraphics.CGRect(UIScreen.MainScreen.Bounds.Width / 2 - 17.5, UIScreen.MainScreen.Bounds.Height / 2 + 17.5, 25, 25);

				imageView3.AnimationImages = new UIImage[] {
				  UIImage.FromBundle ("Images/loadingiconGray.png")
				, UIImage.FromBundle ("Images/loadingiconGray.png")
				, UIImage.FromBundle ("Images/loadingiconGray.png")
				, UIImage.FromBundle ("Images/loadingiconNewRed.png")
			};


				var imageView4 = new UIImageView();
				imageView4.Frame = new CoreGraphics.CGRect(UIScreen.MainScreen.Bounds.Width / 2 + 17.5, UIScreen.MainScreen.Bounds.Height / 2 + 17.5, 25, 25);

				imageView4.AnimationImages = new UIImage[] {
				  UIImage.FromBundle ("Images/loadingiconGray.png")
				, UIImage.FromBundle ("Images/loadingiconGray.png")
				, UIImage.FromBundle ("Images/loadingiconNewRed.png")
				, UIImage.FromBundle ("Images/loadingiconGray.png")
			};
			AddSubview(imageView);
			AddSubview(imageView2);

			AddSubview(imageView4);
			AddSubview(imageView3);

			imageView.AnimationRepeatCount = 0;
			imageView.AnimationDuration = 0.6;
			imageView.StartAnimating();

			imageView2.AnimationRepeatCount = 0;
			imageView2.AnimationDuration = 0.6;
			imageView2.StartAnimating();

			imageView4.AnimationRepeatCount = 0;
			imageView4.AnimationDuration = 0.6;
			imageView4.StartAnimating();

			imageView3.AnimationRepeatCount = 0;
			imageView3.AnimationDuration = 0.6;
			imageView3.StartAnimating();
		}
		catch (Exception ex)
		{
			throw ex;
		}
	}

	/// <summary>
	/// Fades out the control and then removes it from the super view
	/// </summary>
	public void Hide()
	{
		UIView.Animate(
			0.5, // duration
			() => { Alpha = 0; },
			() => { RemoveFromSuperview(); }
		);
	}
}
