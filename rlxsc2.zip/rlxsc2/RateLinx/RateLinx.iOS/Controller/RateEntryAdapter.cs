using System;
using System.Collections.Generic;
using CoreGraphics;
using Foundation;
using RateLinx.Models;
using UIKit;

namespace RateLinx.iOS
{
	class RateEntryAdapter : UITableViewSource
	{
		List<Entry> entries;
		UIView view;
		UITableView objTableView;
		static nint tabCount = -1;
		static bool isExpanded = false;
		//List<UIButton> lstButtons = new List<UIButton>();

		public RateEntryAdapter(List<Entry> entries, UIView view, nfloat xCordinate)
		{
			this.entries = entries;
			this.view = view;
		}

		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			UITableViewCell objTableCell = new UITableViewCell(new CGRect(0, 0, tableView.Frame.Width, 150));
			objTableView = tableView;
			UIView viewRateEntry = new UIView();
			viewRateEntry.Frame = objTableCell.Bounds;
			viewRateEntry.BackgroundColor = UIColor.Black;
			objTableCell.AddSubview(viewRateEntry);
			return objTableCell;
		}

		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return 1;
		}
		public override nint NumberOfSections(UITableView tableView)
		{
			return 3;
		}
		public override nfloat EstimatedHeightForHeader(UITableView tableView, nint section)
		{
			return 30;
		}
		public override nfloat EstimatedHeightForFooter(UITableView tableView, nint section)
		{
			return 2;
		}
		public override nfloat GetHeightForRow(UITableView tableView, NSIndexPath indexPath )
		{
			if (indexPath.Section == tabCount)
			{
				if (isExpanded == false)
				{
					isExpanded = true;
					return 150;
				}
				else
				{
					isExpanded = false;
					return 0;
				}
			}
			else
			{
				return 0;
			}
		}
		public override UIView GetViewForFooter(UITableView tableView, nint section)
		{
			UIView objUIView = new UIView(new CoreGraphics.CGRect(0, 0, tableView.Frame.Width, 2));
			objUIView.BackgroundColor = UIColor.White;
			return objUIView;
		}
		public override UIView GetViewForHeader(UITableView tableView, nint section )
		{
			
			UIView viewHeader = new UIView(new CGRect(0, 0, tableView.Frame.Width, 30));
			viewHeader.BackgroundColor = UIColor.Red;
			UIButton objButton = new UIButton(new CGRect(10, 5, 100, 20));
			objButton.SetTitle("Details", UIControlState.Normal);
			objButton.BackgroundColor = UIColor.White;
			objButton.SetTitleColor(UIColor.Black, UIControlState.Normal);
			objButton.UserInteractionEnabled = true;
			objButton.Tag = section;
			objButton.TouchUpInside +=delegate {
				ExpandSection(objButton.Tag);
			};

			viewHeader.AddSubview(objButton);

			viewHeader.Tag = section;
			return viewHeader;
		}

		void ShowDetails(nint tag)
		{
			//throw new NotImplementedException();
		}

		public void ExpandSection(nint headerCount)
		{
			tabCount = headerCount;

			objTableView.BeginUpdates();
			objTableView.EndUpdates();
		}
	}
}