// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace RateLinx.iOS
{
    [Register ("TrackingInfoController")]
    partial class TrackingInfoController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnCloseTracking { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblDescriptionLabel { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIScrollView scrollViewTrackingInfo { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField spinnerCountry { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextView spinnerDescription { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField spinnerState { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField txtActivityDate { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField txtActivityTime { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField txtCity { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField txtProNumber { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewAddNewTrack { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewCity { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewDescription { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel viewSeparator { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewTrackingInformation { get; set; }

        [Action ("BtnCloseTracking_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnCloseTracking_TouchUpInside (UIKit.UIButton sender);

        [Action ("txtPronumber_Changed:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void txtPronumber_Changed (UIKit.UITextField sender);

        void ReleaseDesignerOutlets ()
        {
            if (btnCloseTracking != null) {
                btnCloseTracking.Dispose ();
                btnCloseTracking = null;
            }

            if (lblDescriptionLabel != null) {
                lblDescriptionLabel.Dispose ();
                lblDescriptionLabel = null;
            }

            if (scrollViewTrackingInfo != null) {
                scrollViewTrackingInfo.Dispose ();
                scrollViewTrackingInfo = null;
            }

            if (spinnerCountry != null) {
                spinnerCountry.Dispose ();
                spinnerCountry = null;
            }

            if (spinnerDescription != null) {
                spinnerDescription.Dispose ();
                spinnerDescription = null;
            }

            if (spinnerState != null) {
                spinnerState.Dispose ();
                spinnerState = null;
            }

            if (txtActivityDate != null) {
                txtActivityDate.Dispose ();
                txtActivityDate = null;
            }

            if (txtActivityTime != null) {
                txtActivityTime.Dispose ();
                txtActivityTime = null;
            }

            if (txtCity != null) {
                txtCity.Dispose ();
                txtCity = null;
            }

            if (txtProNumber != null) {
                txtProNumber.Dispose ();
                txtProNumber = null;
            }

            if (viewAddNewTrack != null) {
                viewAddNewTrack.Dispose ();
                viewAddNewTrack = null;
            }

            if (viewCity != null) {
                viewCity.Dispose ();
                viewCity = null;
            }

            if (viewDescription != null) {
                viewDescription.Dispose ();
                viewDescription = null;
            }

            if (viewSeparator != null) {
                viewSeparator.Dispose ();
                viewSeparator = null;
            }

            if (viewTrackingInformation != null) {
                viewTrackingInformation.Dispose ();
                viewTrackingInformation = null;
            }
        }
    }
}