using Foundation;
using System;
using UIKit;
using Newtonsoft.Json;
using RateLinx.Models;
using System.Collections.Generic;
using RateLinx.Helper;
using Newtonsoft.Json.Linq;
using RateLinx.APIs;
using CoreLocation;
using System.Threading.Tasks;
using CoreGraphics;
using System.Linq;
using System.Drawing;
using ToastIOS;

namespace RateLinx.iOS
{
	public partial class TrackingInfoController : UIViewController
	{
		#region Global used variable
		ModalPickerViewController modalPicker = null;
		UIPickerView pickerView = null;
		PickerDataModel pickerDataModel = null;
		UIButton doneButton = null;
		UIView viewPicker = null;
		CarrierShipmentDetails lstShipmentDetail = null;
		List<TrackingDesc> lstTrackDescVal = null;
		string trackingDescCode = string.Empty;
		//string AMPM = string.Empty;
		List<CountryDetails> lstCountryDetails = null;
		List<StateDetails> lstStateDetails = null;
		List<string> lstCountries, lstStates = null;
		bool showDescriptionText = false;
		string newActivityDate, stateName, countryName, state, country = string.Empty;
		string TrackId = string.Empty;
		string trackingDescription = string.Empty;
		string activityTime, shipmentDetails = string.Empty;
		string compositeKey, city = string.Empty;
		string countryCode = string.Empty;
		string stateCode = string.Empty;
		LoadingOverlay loadPop = null;
		CustomPopup customAlert = null; 
		List<TrackDetail> lstTrackDetail = null;
        UITextField txtEneterDescription = new UITextField();
		UIView viewDynamicLayout;
		string token = string.Empty;
		UIView viewEnterDescription = null;
		UIToolbar toolbar;
		public LocationManager Manager { get; set; }///location
		UITableView tblTrackingInfo;
		private nfloat amountToScroll = 0.0f;
        string proNumber = string.Empty;
		#endregion

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.TrackingInfoController"/> class.
		/// </summary>
		/// <param name="handle">Handle.</param>
		public TrackingInfoController(IntPtr handle) : base(handle)
		{
			Manager = new LocationManager();
			tblTrackingInfo = new UITableView();
		}
		/// <summary>
		/// Views the did load.
		/// </summary>
		public override void ViewDidLoad()
		{
			try
			{
				if (Reachability.InternetConnectionStatus()) 				{
					base.ViewDidLoad();

					toolbar = new UIToolbar(new CoreGraphics.CGRect(0.0f, 0.0f, 320, 44.0f));
					toolbar.TintColor = UIColor.White;
					toolbar.BarStyle = UIBarStyle.Black;
					toolbar.Translucent = true;
					toolbar.Items = new UIBarButtonItem[]{
					 new UIBarButtonItem(UIBarButtonSystemItem.FlexibleSpace),
		 			 new UIBarButtonItem(UIBarButtonSystemItem.Done, delegate {
						if(txtCity.IsFirstResponder)
						{
							txtCity.ResignFirstResponder();
						}
						else if(txtProNumber.IsFirstResponder)
						{
							txtProNumber.ResignFirstResponder();
						}
						else
						{
							txtEneterDescription.ResignFirstResponder();
						}
					})
				};
					txtCity.KeyboardAppearance = UIKeyboardAppearance.Default;
					txtCity.InputAccessoryView = toolbar;
					txtProNumber.KeyboardAppearance = UIKeyboardAppearance.Default;
					txtProNumber.InputAccessoryView = toolbar;
                    UITextView uITextView = new UITextView();
                    uITextView.Editable = false;

                    txtCity.ShouldChangeCharacters = (UITextField textField, NSRange range, string replacementString) =>
                    {
                        var length = textField.Text.Length - range.Length + replacementString.Length;
                        return length <= 6;
                    };

					var gesture = new UITapGestureRecognizer(() =>
					{
						if (viewPicker != null)
						{
							viewPicker.Hidden = true;
							pickerView.Hidden = true;
							doneButton.Hidden = true;
						}
						if (modalPicker != null)
						{
							DismissViewController(true, null);
						}
						View.EndEditing(true);
                    });
					spinnerDescription.Layer.CornerRadius = 5;
					spinnerDescription.SelectionChanged += delegate
					{
						ManageViewOnCondition(viewDynamicLayout);
					};
					gesture.CancelsTouchesInView = false;
					View.AddGestureRecognizer(gesture);
					CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
					if (loadPop == null)
					{
						loadPop = new LoadingOverlay(bounds);
					}
					View.Add(loadPop);
					//Get Current Location
					viewDynamicLayout = new UIView();
					viewDynamicLayout.Hidden = true;
					GetTrackingShipmentDetails();
					ManageViewOnCondition(viewDynamicLayout);
					NSNotificationCenter.DefaultCenter.AddObserver
					(UIKeyboard.DidShowNotification, KeyBoardUpNotification);
					// Keyboard Down
					NSNotificationCenter.DefaultCenter.AddObserver
					(UIKeyboard.WillHideNotification, KeyBoardDownNotification);
				} 				else 				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1); 					this.View.Add(this.customAlert); 				}
			}
			catch
			{
				if (loadPop != null)
				{
					loadPop.Hide();
				}
			}
		}

		public override UIInterfaceOrientationMask GetSupportedInterfaceOrientations()
		{
			return UIInterfaceOrientationMask.Portrait;
		}

		public override void DidRotate(UIInterfaceOrientation fromInterfaceOrientation)
		{
            ManageViewOnCondition(viewDynamicLayout);
			if (!Util.isViewRotated)
			{
				Util.isViewRotated = true;
			}
			else
			{
				Util.isViewRotated = false;
			}
		}

		private void KeyBoardUpNotification(NSNotification notification)
		{
			nfloat parentViewheight = View.Frame.Height;
			CGRect notificationBounds = UIKeyboard.BoundsFromNotification(notification);
			if (parentViewheight > 400)
			{
				if (txtCity.IsFirstResponder)
				{
					if ((scrollViewTrackingInfo.Frame.Height - viewCity.Frame.Y) > (notificationBounds.Height + 100))
					{
						amountToScroll = 0;
					}
					else if ((scrollViewTrackingInfo.Frame.Height - viewCity.Frame.Y) < (notificationBounds.Height + 100))
					{
						amountToScroll = (notificationBounds.Height + 50) - (scrollViewTrackingInfo.Frame.Height - viewCity.Frame.Y);
						amountToScroll += 50;
					}
					else
					{ }
				}
				else if (txtEneterDescription.IsFirstResponder)
				{
					if ((scrollViewTrackingInfo.Frame.Height - viewDynamicLayout.Frame.Y) > (notificationBounds.Height + 50))
					{
						amountToScroll = 0;
					}
					else if ((scrollViewTrackingInfo.Frame.Height - viewDynamicLayout.Frame.Y) < (notificationBounds.Height + 50))
					{
						amountToScroll = (notificationBounds.Height + 50) - (scrollViewTrackingInfo.Frame.Height - viewDynamicLayout.Frame.Y);
						amountToScroll += 100;
					}
					else
					{ }
				}
				else
				{
					amountToScroll = 0;
				}
				ScrollTheView();
			}
		}

		private void KeyBoardDownNotification(NSNotification notification)
		{
			amountToScroll = 0;
			scrollViewTrackingInfo.Frame = new CGRect(0, 50, View.Frame.Width, View.Frame.Height - 20);
		}

		public void ScrollTheView()
		{

			UIView.BeginAnimations(string.Empty, System.IntPtr.Zero);
			UIView.SetAnimationDuration(0.3);

			RectangleF frame = (RectangleF)scrollViewTrackingInfo.Frame;

			if (amountToScroll != 0)
			{
				frame.Y = -(float)amountToScroll;
			}
			else
			{
				frame.Y = 50;
			}
			amountToScroll = 0.0f;
			scrollViewTrackingInfo.Frame = frame;
			UIView.CommitAnimations();
		}


		public override void ViewDidAppear(bool animated)
		{
			try
			{
				base.ViewDidAppear(animated);

				scrollViewTrackingInfo.ContentSize = new CGSize(View.Frame.Width, viewDynamicLayout.Frame.Bottom);
				scrollViewTrackingInfo.ScrollEnabled = true;
				scrollViewTrackingInfo.AutoresizingMask = UIViewAutoresizing.FlexibleHeight;
			}
			catch
			{
				Console.Write(RateLinx.Helper.Constants.strErrorOccured);
			}
		}

		public void ManageViewOnCondition(UIView viewDynamicLayout)
		{
			foreach (UIView objView in viewDynamicLayout)
			{
				objView.RemoveFromSuperview();
			}

			UIColor color1;
			UIColor color2;

            if (spinnerDescription.Text.ToUpper() == NSBundle.MainBundle.GetLocalizedString("other",null).ToString()
                || spinnerDescription.Text.ToUpper() == NSBundle.MainBundle.GetLocalizedString("exception",null).ToString())
			{

				viewEnterDescription = new UIView(new CGRect(0, 0, viewDescription.Frame.Width, viewDescription.Frame.Height));
				viewEnterDescription.BackgroundColor = Constants.viewClr2;

				UILabel lblEnterDescriptionLabel = new UILabel(new CGRect(lblDescriptionLabel.Frame.X, 0, lblDescriptionLabel.Frame.Width, lblDescriptionLabel.Frame.Height));
				//lblEnterDescriptionLabel.Frame = lblDescriptionLabel.Bounds;
				lblEnterDescriptionLabel.Font = UIFont.FromName(Constants.strFontName, 13f);
				lblEnterDescriptionLabel.Text = NSBundle.MainBundle.GetLocalizedString("enterDesc", null);
				lblEnterDescriptionLabel.TextColor = UIColor.Black;

				txtEneterDescription.Frame =new CGRect(spinnerDescription.Frame.X, 8, spinnerDescription.Frame.Width, spinnerDescription.Frame.Height);
				txtEneterDescription.KeyboardAppearance = UIKeyboardAppearance.Default;
				txtEneterDescription.InputAccessoryView = toolbar;

				//txtEneterDescription.Frame = spinnerDescription.Bounds;
				txtEneterDescription.Layer.CornerRadius = 5;
				//txtEneterDescription.b
				txtEneterDescription.Layer.BorderWidth = 0.2f;
                txtEneterDescription.ShouldChangeCharacters = (UITextField textField, NSRange range, string replacementString) =>
                {
                    var length = textField.Text.Length - range.Length + replacementString.Length;
                    return length <= 30;
                };

				UIView viewSeparator2 = new UIView(new CGRect(viewSeparator.Frame.X, 0, 1, viewEnterDescription.Frame.Height));
				viewSeparator2.BackgroundColor = UIColor.White;

				viewEnterDescription.AddSubviews(lblEnterDescriptionLabel, txtEneterDescription, viewSeparator2);
				viewDynamicLayout.AddSubview(viewEnterDescription);

				color1 = Constants.viewClr1;
				color2 = Constants.viewClr2;
				showDescriptionText = true;

			}
			else
			{
				
				color2 = Constants.viewClr1;
				color1 = Constants.viewClr2;
				showDescriptionText = false;
			}
			UIView viewSaveTrackingInfo = new UIView();

            if (spinnerDescription.Text.ToUpper() == NSBundle.MainBundle.GetLocalizedString("other",null).ToString() || spinnerDescription.Text.ToUpper() == NSBundle.MainBundle.GetLocalizedString("exception",null).ToString())
			{
				viewSaveTrackingInfo.Frame = new CGRect(0, viewEnterDescription.Frame.Bottom, viewDescription.Frame.Width, viewAddNewTrack.Frame.Height);
			}
			else
			{
				if (viewEnterDescription != null)
				{
					foreach (UIView view in viewEnterDescription)
					{
						view.RemoveFromSuperview();
					}
					viewEnterDescription.RemoveFromSuperview();
				}
				viewSaveTrackingInfo.Frame = new CGRect(0, 0, viewDescription.Frame.Width, viewAddNewTrack.Frame.Height);
			}

			viewSaveTrackingInfo.BackgroundColor = color1;

			UIButton btnSaveTrackingInfo = new UIButton(new CGRect(viewSaveTrackingInfo.Frame.Width - 130, 10, 90, viewSaveTrackingInfo.Frame.Height - 20));
			btnSaveTrackingInfo.SetTitle(NSBundle.MainBundle.GetLocalizedString("save",null), UIControlState.Normal);
			btnSaveTrackingInfo.Layer.CornerRadius = 5;
			btnSaveTrackingInfo.BackgroundColor = Constants.saveTrackInfoBGC;
			btnSaveTrackingInfo.Font = UIFont.FromName(Constants.strFontName, 13f);

			btnSaveTrackingInfo.TouchUpInside += delegate
			{
				if (Reachability.InternetConnectionStatus()) 				{
					SaveTrackingDetails1();
				} 				else 				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1); 					this.View.Add(this.customAlert); 				}
			};

			viewSaveTrackingInfo.AddSubview(btnSaveTrackingInfo);

			viewDynamicLayout.AddSubview(viewSaveTrackingInfo);

			UIView viewTrackingDetails = new UIView(new CGRect(0, viewSaveTrackingInfo.Frame.Bottom, viewSaveTrackingInfo.Frame.Width, viewSaveTrackingInfo.Frame.Height));
			viewTrackingDetails.BackgroundColor = color2;

			UILabel lblTrackingDetails = new UILabel(new CGRect(20, 0, 200, viewTrackingDetails.Frame.Height));
			lblTrackingDetails.Font = UIFont.FromName(Constants.strFontName, 14f);
			lblTrackingDetails.Text = NSBundle.MainBundle.GetLocalizedString("trckingDetails", null);

			viewTrackingDetails.AddSubview(lblTrackingDetails);

			//viewDynamicLayout.AddSubview(viewTrackingDetails);

			UIView viewTrackingDetailsHeader = new UIView(new CGRect(0, viewTrackingDetails.Frame.Bottom + 1, viewSaveTrackingInfo.Frame.Width, 25));
			viewTrackingDetailsHeader.BackgroundColor = UIColor.White;

			nfloat labelWidth = (viewTrackingDetailsHeader.Frame.Width - 10) / 5;

			UILabel lblActivity = new UILabel(new CGRect(3, 0, labelWidth, viewTrackingDetailsHeader.Frame.Height));
			lblActivity.BackgroundColor = Constants.fileHeadBGC;
			lblActivity.TextColor = UIColor.White;
			lblActivity.TextAlignment = UITextAlignment.Center;
			lblActivity.Text = NSBundle.MainBundle.GetLocalizedString("activity", null);
			lblActivity.Font = UIFont.FromName(Constants.strFontName, 11f);

			UILabel lblCity = new UILabel(new CGRect(labelWidth + 4, 0, labelWidth, viewTrackingDetailsHeader.Frame.Height));
			lblCity.BackgroundColor = Constants.fileHeadBGC;
			lblCity.TextColor = UIColor.White;
			lblCity.TextAlignment = UITextAlignment.Center;
			lblCity.Text = NSBundle.MainBundle.GetLocalizedString("city", null);
			lblCity.Font = UIFont.FromName(Constants.strFontName, 11f);

			UILabel lblState = new UILabel(new CGRect(labelWidth * 2 + 5, 0, labelWidth, viewTrackingDetailsHeader.Frame.Height));
			lblState.BackgroundColor = Constants.fileHeadBGC;
			lblState.TextColor = UIColor.White;
			lblState.TextAlignment = UITextAlignment.Center;
			lblState.Text = NSBundle.MainBundle.GetLocalizedString("state", null);
			lblState.Font = UIFont.FromName(Constants.strFontName, 11f);

			UILabel lblCountry = new UILabel(new CGRect(labelWidth * 3 + 6, 0, labelWidth, viewTrackingDetailsHeader.Frame.Height));
			lblCountry.BackgroundColor = Constants.fileHeadBGC;
			lblCountry.TextColor = UIColor.White;
			lblCountry.TextAlignment = UITextAlignment.Center;
			lblCountry.Text = NSBundle.MainBundle.GetLocalizedString("country", null);
			lblCountry.Font = UIFont.FromName(Constants.strFontName, 11f);

			UILabel lblDescription = new UILabel(new CGRect(labelWidth * 4 + 7, 0, labelWidth, viewTrackingDetailsHeader.Frame.Height));
			lblDescription.BackgroundColor = Constants.fileHeadBGC;
			lblDescription.TextColor = UIColor.White;
			lblDescription.TextAlignment = UITextAlignment.Center;
			lblDescription.Text = NSBundle.MainBundle.GetLocalizedString("description", null);
			lblDescription.Font = UIFont.FromName(Constants.strFontName, 11f);

			viewTrackingDetailsHeader.AddSubviews(lblActivity, lblCity, lblState, lblCountry, lblDescription);


			//viewDynamicLayout.AddSubview(viewTrackingDetailsHeader);

			//Bind Tracking Information
			if (lstShipmentDetail.TrackDetails != null)
			{
				lstTrackDetail = null;
				lstTrackDetail = lstShipmentDetail.TrackDetails;
			}
			else
			{
				lstTrackDetail = new List<TrackDetail>();
			}


			if (lstTrackDetail != null && lstTrackDetail.Count > 0)
			{
				tblTrackingInfo.Frame =new CGRect(3, viewTrackingDetailsHeader.Frame.Bottom, viewDescription.Frame.Width - 6, lstTrackDetail.Count* 30);
				tblTrackingInfo.Source = new TrackingInfoAdapter(lstTrackDetail, this);
				tblTrackingInfo.ReloadData();

			}
			else
			{
				lblTrackingDetails.Frame = new CGRect(0, 0, 0, 0);
				viewTrackingDetails.Frame = new CGRect(0, viewSaveTrackingInfo.Frame.Bottom, viewSaveTrackingInfo.Frame.Width, 0);
				viewTrackingDetailsHeader.Frame = new CGRect(0, viewTrackingDetails.Frame.Bottom + 1, viewSaveTrackingInfo.Frame.Width, 0);
				tblTrackingInfo.Frame =new CGRect(3, viewTrackingDetailsHeader.Frame.Bottom, viewDescription.Frame.Width - 6, 0);
				foreach (UIView view in viewTrackingDetailsHeader)
				{
					view.RemoveFromSuperview();
				}
			}
			tblTrackingInfo.RowHeight = 30;
			tblTrackingInfo.AllowsSelection = false;
			viewDynamicLayout.AddSubviews(viewTrackingDetails, viewTrackingDetailsHeader, tblTrackingInfo);

			viewDynamicLayout.Frame = new CGRect(0, viewDescription.Frame.Bottom, viewDescription.Frame.Width, tblTrackingInfo.Frame.Bottom);

			scrollViewTrackingInfo.AddSubview(viewDynamicLayout);
			scrollViewTrackingInfo.ContentSize = new CGSize(View.Frame.Width, viewDynamicLayout.Frame.Bottom);


		}

        partial void txtPronumber_Changed(UITextField sender)
        {
            if (txtProNumber.IsEditing)
            {
                txtProNumber.Text = proNumber;
                return;
            }
        }

		void SaveTrackingDetails1()
		{
            try
            {
                scrollViewTrackingInfo.ContentSize = new CGSize(View.Frame.Width, 3000);
                scrollViewTrackingInfo.ScrollEnabled = true;
                scrollViewTrackingInfo.AutoresizingMask = UIViewAutoresizing.FlexibleHeight;
                if (string.IsNullOrEmpty(txtCity.Text))
                {
                    Toast.MakeText(Constants.enterCity).SetDuration(Constants.toastDuration).Show();
                    return;
                }
                if (string.IsNullOrEmpty(txtProNumber.Text))
                {
                    Toast.MakeText(Constants.strEnterProNo).SetDuration(Constants.toastDuration).Show();
                    return;
                }
                else
                {
                    SaveTrackingDetails();
                }
            }
            catch(Exception ex)
            {
                Toast.MakeText(ex.Message).SetDuration(Constants.toastDuration).Show(); 
            }
		}


		/// <summary>
		/// Gets the current address.
		/// </summary>
		public async Task GetCurrentAddress()
		{
			try
			{
                CLLocation location = Manager.LocMgr.Location;
				var geoCoder = new CLGeocoder();
				var placemarks = await geoCoder.ReverseGeocodeLocationAsync(location);
				foreach (var placemark in placemarks)
				{
					if (!string.IsNullOrEmpty(placemark.Locality))
					{
						city = placemark.Locality;
					}
					if (!string.IsNullOrEmpty(placemark.AdministrativeArea))
					{
						state = placemark.AdministrativeArea;
					}
					if (!string.IsNullOrEmpty(placemark.Country))
					{
						country = placemark.Country;
					}
				}
				txtCity.Text = city;

			}
			catch
			{
				loadPop.Hide();

			}
		}

		/// <summary>
		/// Gets the shipment details.
		/// </summary>
		public async void GetTrackingShipmentDetails()
		{
			try
			{
				lstTrackDescVal = new List<TrackingDesc>();
				shipmentDetails = NSUserDefaults.StandardUserDefaults.StringForKey("shipmentDetails");
				lstShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(shipmentDetails);
				compositeKey = lstShipmentDetail.ClientID + "|" + lstShipmentDetail.LocID + "|" + lstShipmentDetail.BolNum;
				bool status = await LoadCountryAndState();
				if (status)
				{
                    txtProNumber.Text = proNumber = lstShipmentDetail.ProNum;
					if (DateTime.Now.Hour < 12)
					{
						//AMPM = " AM";
					}
					else
					{
						//AMPM = " PM";
					}

					string currentDate = DateTime.Now.ToString(ConstantsClass.dateFormatMMDDYYYY);

					txtActivityDate.Text = currentDate.Contains("-") ? currentDate.Replace('-', '/') : currentDate;
					txtActivityTime.Text = DateTime.Now.ToShortTimeString();
					var deliveryDateTap = new UITapGestureRecognizer(DeliveryDatePicker);
					txtActivityDate.AddGestureRecognizer(deliveryDateTap);
					var deliveryTime1Tap = new UITapGestureRecognizer(DeliveryTimePicker);
					txtActivityTime.AddGestureRecognizer(deliveryTime1Tap);
					var stateTap = new UITapGestureRecognizer(BindState);
					spinnerState.AddGestureRecognizer(stateTap);

					var countryTap = new UITapGestureRecognizer(BindCountry);
					spinnerCountry.AddGestureRecognizer(countryTap);
					//Drop Down Description
					lstTrackDescVal = CommanUtil.TrackingDescList();
					spinnerDescription.Text = lstTrackDescVal[0].text;
					spinnerDescription.TextAlignment = UITextAlignment.Natural;
					var spinnerDesTap = new UITapGestureRecognizer(BindDescription);
					spinnerDescription.AddGestureRecognizer(spinnerDesTap);
					if (loadPop != null)
					{
						loadPop.Hide();
						viewDynamicLayout.Hidden = false;
					}
				}
			}
			catch
			{
				if (loadPop != null)
				{
					loadPop.Hide();
				}

			}
		}

		/// <summary>
		/// Opens the calender.
		/// </summary>
		public void DeliveryDatePicker()
		{
			try
			{

				modalPicker = new ModalPickerViewController(ModalPickerType.Date, "", this)
				{
					HeaderBackgroundColor = Constants.btnColorRed,
					HeaderTextColor = UIColor.White,
					TransitioningDelegate = new ModalPickerTransitionDelegate(),
					ModalPresentationStyle = UIModalPresentationStyle.Custom
				};

				modalPicker.DatePicker.Mode = UIDatePickerMode.Date;
				modalPicker.OnModalPickerDismissed += (s, ea) =>
				{
					var dateFormatter = new NSDateFormatter()
					{
						DateFormat = ConstantsClass.dateFormatMMDDYYYY
					};
					txtActivityDate.Text = dateFormatter.ToString(modalPicker.DatePicker.Date);
				};
				this.PresentViewController(modalPicker, true, null);
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Opens the calender.
		/// </summary>
		/// <param name="type">Type.</param>
		public void DeliveryTimePicker(UITapGestureRecognizer tapGesture)
		{
			try
			{

				modalPicker = new ModalPickerViewController(ModalPickerType.Date, "", this)
				{
					HeaderBackgroundColor = Constants.btnColorRed,
					HeaderTextColor = UIColor.White,
					TransitioningDelegate = new ModalPickerTransitionDelegate(),
					ModalPresentationStyle = UIModalPresentationStyle.Custom
				};

				modalPicker.DatePicker.Mode = UIDatePickerMode.Time;
				modalPicker.OnModalPickerDismissed += (s, ea) =>
				{
					var TimeFormatter = new NSDateFormatter()
					{
						TimeStyle = NSDateFormatterStyle.Short
					};
					if (tapGesture.View.Equals(txtActivityTime))
					{
						txtActivityTime.Text = TimeFormatter.ToString(modalPicker.DatePicker.Date);
					}
					else
					{
						txtActivityTime.Text = TimeFormatter.ToString(modalPicker.DatePicker.Date);
					}
				};

				this.PresentViewController(modalPicker, true, null);
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Selects the country.
		/// </summary>
		public void BindCountry(UITapGestureRecognizer tapGesture)
		{
			try
			{
				string selectedValue = string.Empty;

				int yPosition = (int)(View.Frame.Height - 180) / 2;
				UIView pickerParentView = new UIView();
				viewPicker = new UIView(new CGRect(20, yPosition - 100, View.Frame.Width - 40, 210));
				viewPicker.BackgroundColor = UIColor.White;
				viewPicker.Layer.CornerRadius = 10;
				viewPicker.Layer.BorderWidth = 1;
				viewPicker.Layer.BorderColor = UIColor.Black.CGColor;
				pickerView = new UIPickerView(new CGRect(0, 0, viewPicker.Frame.Width, 180));
				pickerView.BackgroundColor = UIColor.White;
				pickerView.ShowSelectionIndicator = true;
				// create our simple picker model
				pickerDataModel = new PickerDataModel(lstCountries);
				// set it on our picker class
				pickerView.Model = pickerDataModel;
				// Create a 'done' button for the toolbar and add it to the toolbar
				doneButton = new UIButton(new CGRect(0, 180, viewPicker.Frame.Width, 30));
				doneButton.BringSubviewToFront(View);
				doneButton.SetTitle(ConstantsClass.strDone, UIControlState.Normal);
				doneButton.BackgroundColor = ConstantsClass.btnColorRed;
				doneButton.Layer.CornerRadius = 10;
				doneButton.UserInteractionEnabled = true;
				viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });
				pickerDataModel.ValueChanged += (s, e) =>
				{
					selectedValue = pickerDataModel.SelectedItem;
				};
				View.Add(viewPicker);
				doneButton.TouchUpInside += (s, e) =>
				{
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
					if (!string.IsNullOrEmpty(selectedValue))
					{
						spinnerCountry.Text = selectedValue;
						CoutryChangeEvent(selectedValue);
					}
					else
					{
						spinnerCountry.Text = lstCountries[0];
						CoutryChangeEvent(lstCountries[0]);
					}
				};
				viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });
			
				pickerParentView.Frame = View.Frame;
				pickerParentView.BackgroundColor = UIColor.Clear;
				pickerParentView.Add(viewPicker);
				View.Add(pickerParentView);
				tapGesture = new UITapGestureRecognizer(new Action(delegate
				{
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
				}));
				pickerParentView.AddGestureRecognizer(tapGesture);
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Selects the BindDescription.
		/// </summary>
		public void BindDescription(UITapGestureRecognizer tapGesture)
		{
			try
			{
				string selectedValue = string.Empty;
				int yPosition = (int)(View.Frame.Height - 180) / 2;
				UIView pickerParentView = new UIView();
				viewPicker = new UIView(new CGRect(20, yPosition - 100, View.Frame.Width - 40, 210));
				viewPicker.BackgroundColor = UIColor.White;
				viewPicker.Layer.CornerRadius = 10;
				viewPicker.Layer.BorderWidth = 1;
				viewPicker.Layer.BorderColor = UIColor.Black.CGColor;
				pickerView = new UIPickerView(new CGRect(0, 0, viewPicker.Frame.Width, 180));
				pickerView.BackgroundColor = UIColor.White;
				pickerView.ShowSelectionIndicator = true;
				// create our simple picker model
				List<string> lstDesc = new List<string>();
				if (lstTrackDescVal != null)
				{
					foreach (var trackingDesc in lstTrackDescVal)
					{
						lstDesc.Add(trackingDesc.text);
					}
				}
				pickerDataModel = new PickerDataModel(lstDesc);
				// set it on our picker class
				pickerView.Model = pickerDataModel;
				// Create a 'done' button for the toolbar and add it to the toolbar
				doneButton = new UIButton(new CGRect(0, 180, viewPicker.Frame.Width, 30));
				doneButton.BringSubviewToFront(View);
				doneButton.SetTitle(ConstantsClass.strDone, UIControlState.Normal);
				doneButton.BackgroundColor = ConstantsClass.btnColorRed;
				doneButton.Layer.CornerRadius = 10;
				doneButton.UserInteractionEnabled = true;
				viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });
				pickerDataModel.ValueChanged += (s, e) =>
				{
					selectedValue = pickerDataModel.SelectedItem;
				};
				View.Add(viewPicker);
				doneButton.TouchUpInside += (s, e) =>
				{
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
					if (!string.IsNullOrEmpty(selectedValue))
					{
						spinnerDescription.Text = selectedValue;
					}
					else
					{
						spinnerDescription.Text = lstDesc[0];
					}
				};
				viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });
				pickerParentView.Frame = View.Frame;
				pickerParentView.BackgroundColor = UIColor.Clear;
				pickerParentView.Add(viewPicker);
				View.Add(pickerParentView);
				tapGesture = new UITapGestureRecognizer(new Action(delegate
				{
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
				}));
				pickerParentView.AddGestureRecognizer(tapGesture);
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Get Country Details
		/// </summary>
		/// <returns></returns>
		public async Task<List<CountryDetails>> GetCountryDetails()
		{
			try
			{

				List<CountryDetails> lstCountryDetails = null;
				//Get the service Helper Object
				ServiceHelper objServicehelper = new ServiceHelper();
				// create json object that holds the api values
				//Method Name
				string methodName = APIMethods.getCountry;
				CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
				//				if (loadPop == null)
				//				{
				//					loadPop = new LoadingOverlay(bounds);
				//				}
				//				View.Add(loadPop);
				//Get the Shipments
				var strResponse = await objServicehelper.GetRequest(CommanUtil.tokenNo, methodName, true);
				//loadPop.Hide();
				lstCountryDetails = new List<CountryDetails>();

				if (strResponse != null)
				{
					lstCountryDetails = (List<CountryDetails>)JsonConvert.DeserializeObject(strResponse, typeof(List<CountryDetails>));
				}
				return lstCountryDetails;
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
				return null;
			}
		}

		/// <summary>
		/// Loading Country According to current Address
		/// </summary>
		public async Task<bool> LoadCountryAndState()
		{
			try
			{
				if (Manager.LocMgr.Location != null)
				{
					//Util.location = Manager.LocMgr.Location;
					await GetCurrentAddress();
				}
				else
				{
                    Toast.MakeText(Helper.Constants.strEnableTracking).SetDuration(Helper.Constants.toastDuration).Show();
				}
				lstCountryDetails = await GetCountryDetails();
				if (lstCountryDetails != null)
				{
					lstCountries = new List<string>();
					foreach (CountryDetails countryDetails in lstCountryDetails)
					{
						lstCountries.Add(countryDetails.Name);
					}
					if (!string.IsNullOrEmpty(country))
					{
						countryName = lstCountries.Where(x => x.ToUpper().Equals(country.ToUpper())).FirstOrDefault();
					}
					if (!string.IsNullOrEmpty(countryName))
					{
						spinnerCountry.Text = countryName;

					}
					else
					{
						spinnerCountry.Text = Constants.strDefaultCountry;
					}

					if (lstCountryDetails != null && lstCountryDetails.Count > 0)
					{
						for (int indexCountry = 0; indexCountry < lstCountryDetails.Count; indexCountry++)
						{
							if (spinnerCountry.Text.Equals(Convert.ToString(lstCountryDetails[indexCountry].Name)))
							{
								lstStateDetails = lstCountryDetails[indexCountry].States;
							}
						}
					}
					lstStates = new List<string>();
					List<string> lstStateCodes = new List<string>();
					foreach (StateDetails stateDetails in lstStateDetails)
					{
						lstStates.Add(stateDetails.Name);
						lstStateCodes.Add(stateDetails.Code);

					}

					//state = "CALIFORNIA";

					string newStateCode = string.Empty;

					if (!string.IsNullOrEmpty(state))
					{
						if (lstStates != null && lstStates.Count > 0)
						{
							stateName = lstStates.Where(x => x.ToUpper().Equals(state.ToUpper())).FirstOrDefault();
						}
						if (lstStateCodes != null && lstStateCodes.Count > 0)
						{
							newStateCode = lstStateCodes.Where(x => x.ToUpper().Equals(state.ToUpper())).FirstOrDefault();
						}
					}
					if (!string.IsNullOrEmpty(stateName))
					{
						spinnerState.Text = stateName;
					}
					else if (!string.IsNullOrEmpty(newStateCode))
					{
						if (lstStateDetails != null && lstStateDetails.Count > 0)
						{
							string newStateName = lstStateDetails.Where(stateDetails => stateDetails.Code.ToUpper()
																		.Equals(newStateCode.ToUpper())).FirstOrDefault().Name;

							if (!string.IsNullOrEmpty(newStateName))
							{
								spinnerState.Text = newStateName;
							}
							else
							{
								spinnerState.Text = lstStates[0];
							}

						}
					}
					else
					{
						spinnerState.Text = lstStates[0];
					}

					return true;
				}
				else
				{
					return false;
				}

			}
			catch
			{
				return false;
			}
		}

		/// <summary>
		/// Coutries the change event.
		/// </summary>
		/// <param name="selectedCountry">Selected country.</param>
		public void CoutryChangeEvent(string selectedCountry)
		{
			try
			{
				for (int indexCountry = 0; indexCountry < lstCountryDetails.Count; indexCountry++)
				{
					if (selectedCountry.Trim().Equals(Convert.ToString(lstCountryDetails[indexCountry].Name)))
					{
						lstStateDetails = lstCountryDetails[indexCountry].States;
					}
				}
				lstStates = new List<string>();
				foreach (StateDetails stateDetails in lstStateDetails)
				{
					lstStates.Add(stateDetails.Name);
				}
				if (lstStates != null)
				{
					spinnerState.Text = lstStates[0];
				}
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Selects the BindState.
		/// </summary>
		public void BindState(UITapGestureRecognizer tapGesture)
		{
			try
			{
				string selectedValue = string.Empty;
				UIView pickerParentView = new UIView();
				int yPosition = (int)(View.Frame.Height - 180) / 2;
				viewPicker = new UIView(new CGRect(20, yPosition - 100, View.Frame.Width - 40, 210));
				viewPicker.BackgroundColor = UIColor.White;
				viewPicker.Layer.CornerRadius = 10;
				viewPicker.Layer.BorderWidth = 1;
				viewPicker.Layer.BorderColor = UIColor.Black.CGColor;
				pickerView = new UIPickerView(new CGRect(0, 0, viewPicker.Frame.Width, 180));
				pickerView.BackgroundColor = UIColor.White;
				pickerView.ShowSelectionIndicator = true;
				pickerDataModel = new PickerDataModel(lstStates);
				// set it on our picker class
				pickerView.Model = pickerDataModel;
				// Create a 'done' button for the toolbar and add it to the toolbar
				doneButton = new UIButton(new CGRect(0, 180, viewPicker.Frame.Width, 30));
				doneButton.BringSubviewToFront(View);
				doneButton.SetTitle(ConstantsClass.strDone, UIControlState.Normal);
				doneButton.BackgroundColor = ConstantsClass.btnColorRed;
				doneButton.Layer.CornerRadius = 10;
				doneButton.UserInteractionEnabled = true;
				viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });
				pickerDataModel.ValueChanged += (s, e) =>
				{
					selectedValue = pickerDataModel.SelectedItem;
				};

				//selectedValue = pickerDataModel.SelectedItem;
				View.Add(viewPicker);
				doneButton.TouchUpInside += (s, e) =>
				{
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
					if (!string.IsNullOrEmpty(selectedValue))
					{
						spinnerState.Text = selectedValue;
					}
					else
					{
						spinnerState.Text = lstStates[0];
					}

				};
				viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });
			
				pickerParentView.Frame = View.Frame;
				pickerParentView.BackgroundColor = UIColor.Clear;
				pickerParentView.Add(viewPicker);
				View.Add(pickerParentView);
				tapGesture = new UITapGestureRecognizer(new Action(delegate
				{
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
				}));
				pickerParentView.AddGestureRecognizer(tapGesture);
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Saves the tracking details.
		/// </summary>
		public async void SaveTrackingDetails()
		{
			try
			{
				CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
				if (loadPop != null)
				{
					loadPop = null;
					loadPop = new LoadingOverlay(bounds);
				}
				View.Add(loadPop);
				TrackId = CommanUtil.CompositeKey(lstShipmentDetail.ClientID, lstShipmentDetail.LocID, lstShipmentDetail.BolNum);
				compositeKey = lstShipmentDetail.ClientID + "|" + lstShipmentDetail.BolNum;
				if (showDescriptionText)
				{
					if (string.IsNullOrEmpty(txtEneterDescription.Text))
					{
						this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strTracking, true, this, "", 1);
						this.View.Add(this.customAlert);
						loadPop.Hide();
						return;
					}
					else
					{
						trackingDescription = txtEneterDescription.Text;
					}
				}
				else
				{
                    if (Convert.ToString(spinnerDescription.Text) == Constants.strDescriptionDefaultText)
                    {
                        Toast.MakeText(Constants.strSelectDescription).Show();
                    }
                    else
                    {
                        trackingDescription = Convert.ToString(spinnerDescription.Text);
                    }
				}
				string methodURI = APIMethods.shipmentDetails + "/" + TrackId + "/" + APIMethods.tracking;
				token = CommanUtil.tokenNo;
				ServiceHelper objServiceHelper = new ServiceHelper();
				var Result = await objServiceHelper.PostRequestJson(GetTrackingPayload(), methodURI, token, true);
				if (!string.IsNullOrEmpty(Result))
				{
					await ResetTrackingInfoScreen();
					loadPop.Hide();

				}
				else
				{
					await Util.ErrorLog(NSBundle.MainBundle.GetLocalizedString("trckingDetails", null), Constants.strTrackingError, CommanUtil.tokenNo);
					CommanErrorPopup objErrorPopup = new CommanErrorPopup(View, Constants.strTrackingError);
					UIView viewErrorpop = objErrorPopup.GetErrorPopup();
					View.Add(viewErrorpop);
					await ResetTrackingInfoScreen();
					loadPop.Hide();
				}
			}
			catch
			{
                throw;
			}
		}

		/// <summary>
		/// Creating Tracking Payload for posting data in API
		/// </summary>
		/// <returns></returns>
		public string GetTrackingPayload()
		{
			try
			{
				GetCountryStateCode();
				string payload_str = string.Empty;
				if (!string.IsNullOrEmpty(txtActivityDate.Text))
				{
					newActivityDate = txtActivityDate.Text.Contains("-") ? txtActivityDate.Text.Replace('-', '/') : txtActivityDate.Text;
				}
				if ((txtActivityTime.Text.Contains("AM")))
				{
					activityTime = txtActivityTime.Text.Replace("AM", "").Trim();
				}
				else
				{
					activityTime = txtActivityTime.Text.Replace("PM", "").Trim();
				}
				payload_str = "{"
					+ "\"ProNumber\":" + "\"" + txtProNumber.Text + "\","
					+ "\"ActivityDate\":" + "\"" + newActivityDate + " " + activityTime + "\","
					+ "\"ActivityCode\":" + "\"" + trackingDescCode + "\","
					+ "\"ActivityDescr\":" + "\"" + trackingDescription + "\","
					+ "\"City\":" + "\"" + txtCity.Text + "\","
					+ "\"State\":" + "\"" + stateCode + "\","
					+ "\"Country\":" + "\"" + countryCode + "\""
					+
					"}";

				return payload_str;
			}
			catch
			{
				return null;
			}

		}

		/// <summary>
		/// Reset Tracking Informations
		/// </summary>
		private async Task ResetTrackingInfoScreen()
		{
			try
			{
				txtActivityDate.Text = DateTime.Now.ToShortDateString();
				txtActivityTime.Text = DateTime.Now.ToShortTimeString();//+ AMPM;
				txtProNumber.Text = string.Empty;
				txtCity.Text = string.Empty;
				string shipment = await Util.BindShipmentDetails(compositeKey);
				if (!string.IsNullOrEmpty(shipment))
				{
					GetTrackingShipmentDetails();
					ManageViewOnCondition(viewDynamicLayout);
				}
				else { 
                    GetTrackingShipmentDetails();
					ManageViewOnCondition(viewDynamicLayout);
				}
				txtCity.Text = city;
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}



		/// <summary>
		/// Gets Country Code and State Code.
		/// </summary>
		public void GetCountryStateCode()
		{
			try
			{
				for (int indexCountry = 0; indexCountry < lstCountryDetails.Count; indexCountry++)
				{
					if (spinnerCountry.Text.Trim().Equals(Convert.ToString(lstCountryDetails[indexCountry].Name)))
					{
						countryCode = lstCountryDetails[indexCountry].Code;
						var stateDetail = lstCountryDetails[indexCountry].States.Where(s => s.Name == spinnerState.Text.Trim()).FirstOrDefault();
						stateCode = stateDetail.Code;
					}
					var trackDesc = lstTrackDescVal.Where(m => m.text == spinnerDescription.Text).FirstOrDefault();
					if (trackDesc != null)
					{
						trackingDescCode = trackDesc.value;
					}
				}
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}


		/// <summary>
		/// Buttons the close tracking touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnCloseTracking_TouchUpInside(UIButton sender)
		{
			this.NavigationController.PopViewController(true);
		}


	}
}