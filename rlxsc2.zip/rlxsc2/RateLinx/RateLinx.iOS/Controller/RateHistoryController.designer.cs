// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace RateLinx.iOS
{
    [Register ("RateHistoryController")]
    partial class RateHistoryController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnFromDate { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnScan { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnSearchHistory { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnSelectAction { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnToDate { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgHome { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgMenu { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblCopyRight { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView RateHistoryView { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField txtClientID { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField txtEndDate { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField txtLoadNo { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField txtOriginDate { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewRateHistoryParent { get; set; }

        [Action ("BtnFromDate_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnFromDate_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnScan_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnScan_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnSearchHistory_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnSearchHistory_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnSelectAction_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnSelectAction_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnToDate_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnToDate_TouchUpInside (UIKit.UIButton sender);

        void ReleaseDesignerOutlets ()
        {
            if (btnFromDate != null) {
                btnFromDate.Dispose ();
                btnFromDate = null;
            }

            if (btnScan != null) {
                btnScan.Dispose ();
                btnScan = null;
            }

            if (btnSearchHistory != null) {
                btnSearchHistory.Dispose ();
                btnSearchHistory = null;
            }

            if (btnSelectAction != null) {
                btnSelectAction.Dispose ();
                btnSelectAction = null;
            }

            if (btnToDate != null) {
                btnToDate.Dispose ();
                btnToDate = null;
            }

            if (imgHome != null) {
                imgHome.Dispose ();
                imgHome = null;
            }

            if (imgMenu != null) {
                imgMenu.Dispose ();
                imgMenu = null;
            }

            if (lblCopyRight != null) {
                lblCopyRight.Dispose ();
                lblCopyRight = null;
            }

            if (RateHistoryView != null) {
                RateHistoryView.Dispose ();
                RateHistoryView = null;
            }

            if (txtClientID != null) {
                txtClientID.Dispose ();
                txtClientID = null;
            }

            if (txtEndDate != null) {
                txtEndDate.Dispose ();
                txtEndDate = null;
            }

            if (txtLoadNo != null) {
                txtLoadNo.Dispose ();
                txtLoadNo = null;
            }

            if (txtOriginDate != null) {
                txtOriginDate.Dispose ();
                txtOriginDate = null;
            }

            if (viewRateHistoryParent != null) {
                viewRateHistoryParent.Dispose ();
                viewRateHistoryParent = null;
            }
        }
    }
}