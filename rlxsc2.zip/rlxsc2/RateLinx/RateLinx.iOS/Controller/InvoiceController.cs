using Foundation;
using System;
using UIKit;
using RateLinx.Helper;
using RateLinx.Models;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using CoreGraphics;
using System.Runtime.InteropServices;
using RateLinx.APIs;
using System.Threading.Tasks;
using System.Drawing;

namespace RateLinx.iOS
{
	public partial class InvoiceController : UIViewController
	{
		#region Global used variable

		ServiceHelper objServiceHelper = null;
		FileUploadHelper objFileUploadHelper = null;
		CarrierShipmentDetails lstShipmentDetail = null;
		List<Charges> listCharges = new List<Charges>();
		string apiMethod = string.Empty;
		List<string> objFileList = null;
		string token = string.Empty;
		string[] fileUri = null;
		List<byte[]> listFileBytes = null;
		JObject jobject = null;
		string jsonFileRequest = string.Empty;
		string jsonCharge = string.Empty;
		ModalPickerViewController modalPicker = null;
		UIPickerView pickerView = null;
		PickerDataModel pickerDataModel = null;
		UIButton doneButton = null;
		UIView viewPicker = null;
		byte[] bytes = null;
		string fileName = null;
		UIImagePickerController imagePicker = null;
		int fileIndex = 0;
		UITableView tblCharges;
		UITableView tblFiles;
		UIView viewChargeTableHeading; //viewInvoiceBottom;
		UILabel lblAddedCharges, lblFileHeading;
		CustomPopup customAlert = null;
		LoadingOverlay loadPop;
		string fileUrl = string.Empty;
		private nfloat scroll_amount = 0.0f;    // amount to scroll
	
		public bool addChargeFlag = false;
		UILabel lblAction, lblCharge, lblAmount;
		UIToolbar toolbar;
		#endregion

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.InvoiceController"/> class.
		/// </summary>
		/// <param name="handle">Handle.</param>
		public InvoiceController(IntPtr handle) : base(handle)
		{
			//viewInvoiceBottom = new UIView();
			lblAddedCharges = new UILabel();
			tblCharges = new UITableView();
			tblFiles = new UITableView();
			lblFileHeading = new UILabel();
			lblAction = new UILabel();
			lblCharge = new UILabel();
			lblAmount = new UILabel();
			viewChargeTableHeading = new UIView();
		}
		/// <summary>
		/// Views the did load.
		/// </summary>
		public override void ViewDidLoad()
		{
			try
			{
				base.ViewDidLoad();

				toolbar = new UIToolbar(new CoreGraphics.CGRect(new nfloat(0.0f), new nfloat(0.0f), this.View.Frame.Size.Width, new nfloat(44.0f)));
			    toolbar.TintColor = UIColor.White;
			    toolbar.BarStyle = UIBarStyle.Black;
			    toolbar.Translucent = true;
				toolbar.Items = new UIBarButtonItem[]{
					 new UIBarButtonItem(UIBarButtonSystemItem.FlexibleSpace),
		 			 new UIBarButtonItem(UIBarButtonSystemItem.Done, delegate {
						if(txtComment.IsFirstResponder)
						{
							txtComment.ResignFirstResponder();
						}
						else
						{
							txtAmount.ResignFirstResponder();
						}
					})
				};
				txtComment.KeyboardAppearance = UIKeyboardAppearance.Default;
				txtComment.InputAccessoryView = toolbar;

                txtComment.ShouldChangeCharacters = (UITextField textField, NSRange range, string replacementString) =>
                {
                    var length = textField.Text.Length - range.Length + replacementString.Length;
                    return length <= 200;
                };

				txtAmount.KeyboardAppearance = UIKeyboardAppearance.Default;
				txtAmount.InputAccessoryView = toolbar;
				txtAmount.Layer.CornerRadius = 5;
				txtAmount.Font = UIFont.FromName(Constants.strFontName, 15f);
				//Hinding Key Board And Popups
				var gesture = new UITapGestureRecognizer(() =>
				{
					if (viewPicker != null)
					{
						viewPicker.Hidden = true;
						pickerView.Hidden = true;
						doneButton.Hidden = true;
					}
					if (modalPicker != null)
					{
						DismissViewController(true, null);
					}
					View.EndEditing(true);
				});
				gesture.CancelsTouchesInView = false;
				View.AddGestureRecognizer(gesture);
				//Fixing file index
				listFileBytes = new List<byte[]>();
				listFileBytes.Add(null);
				listFileBytes.Add(null);
				listFileBytes.Add(null);

				fileUri = new string[3];
				//Get the Detail of invoice
				GetInvoiceDetails();
				//Creating Controls and assigning values
				CreatingControls();


				NSNotificationCenter.DefaultCenter.AddObserver
				(UIKeyboard.DidShowNotification, KeyBoardUpNotification);
				// Keyboard Down
				NSNotificationCenter.DefaultCenter.AddObserver
				(UIKeyboard.WillHideNotification, KeyBoardDownNotification);

			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}

		public override UIInterfaceOrientationMask GetSupportedInterfaceOrientations()
		{
			return UIInterfaceOrientationMask.Portrait;
		}

		public override void DidRotate(UIInterfaceOrientation fromInterfaceOrientation)
		{
			ManageCharges(false);
			if (!Util.isViewRotated)
			{
				Util.isViewRotated = true;
			}
			else
			{
				Util.isViewRotated = false;
			}
		}
		private void KeyBoardUpNotification(NSNotification notification)
		{
			nfloat parentViewheight = View.Frame.Height;
			CGRect notificationBounds = UIKeyboard.BoundsFromNotification(notification);
			if (parentViewheight > 400)
			{
				if (txtAmount.IsFirstResponder)
				{
					if ((viewInvoice.Frame.Height - viewEnterAmount.Frame.Y) > (notificationBounds.Height + 50))
					{
						scroll_amount = 0;
					}
					else if ((viewInvoice.Frame.Height - viewEnterAmount.Frame.Y) < (notificationBounds.Height + 50))
					{
						scroll_amount = (notificationBounds.Height + 50) - (viewInvoice.Frame.Height - viewEnterAmount.Frame.Y);
						scroll_amount += 100;
					}
					else
					{

					}
					ScrollTheView();
				}
				else
				{
					ScrollTheView();
					scroll_amount = 0;
				}
			}
		}
		private void KeyBoardDownNotification(NSNotification notification)
		{
			scroll_amount = 0;
			viewInvoice.Frame = new CGRect(0, 20, View.Frame.Width, View.Frame.Height - 20);
		}




		public void ScrollTheView()
		{

			UIView.BeginAnimations(string.Empty, System.IntPtr.Zero);
			UIView.SetAnimationDuration(0.3);

			RectangleF frame = (RectangleF)viewInvoice.Frame;

			if (scroll_amount != 0)
			{
				frame.Y = -(float)scroll_amount;
			}
			else
			{
				frame.Y = 20;
			}
			scroll_amount = 0.0f;
			viewInvoice.Frame = frame;
			UIView.CommitAnimations();
		}


		/// <summary>
		/// Creatings the controls.
		/// </summary>
		public void CreatingControls()
		{
			try
			{
				//remove table Charge Data
				foreach (UIView objView in viewInvoiceBottom)
				{
					objView.RemoveFromSuperview();
				}
				spinnerCharge.HorizontalAlignment = UIControlContentHorizontalAlignment.Left;

				lblAddedCharges.Frame = new CGRect(0, 0, View.Frame.Width, 0);
				viewChargeTableHeading.Frame = new CGRect(15, lblAddedCharges.Frame.Bottom + 10, View.Frame.Width - 30, 0);

				tblCharges.Frame = new CGRect(15, viewChargeTableHeading.Frame.Bottom, View.Frame.Width - 30, 0);
				tblCharges.Hidden = true;
				tblCharges.ReloadData();
				if (objFileList != null && objFileList.Count > 0)
				{
					lblFileHeading.Frame = new CGRect(15, tblCharges.Frame.Bottom + 10, View.Frame.Width - 30, 35);
					lblFileHeading.BackgroundColor = Constants.fileHeadBGC;
					lblFileHeading.TextColor = UIColor.White;
					lblFileHeading.Font = UIFont.FromName(Constants.strFontName, 15f);
					lblFileHeading.Text = NSBundle.MainBundle.LocalizedString("attached", null);
					tblFiles.Frame = new CGRect(15, lblFileHeading.Frame.Bottom, View.Frame.Width - 30, objFileList.Count * 25);
					tblFiles.Source = new InvoiceFileAdapter(objFileList, this);
					tblFiles.RowHeight = 25;
				}
				else
				{
					lblFileHeading.Frame = new CGRect(15, tblCharges.Frame.Bottom + 10, View.Frame.Width - 30, 0);
					tblFiles.Frame = new CGRect(15, lblFileHeading.Frame.Bottom, View.Frame.Width - 30, 0);
				}


				//viewInvoiceBottom.Frame = new CGRect(0, viewAddCharge.Frame.Bottom + 40, View.Frame.Width, tblFiles.Frame.Bottom);
				tblCharges.Bounces = false;
				tblFiles.Bounces = false;
				viewInvoiceBottom.AddSubviews(lblAddedCharges, viewChargeTableHeading, tblCharges, lblFileHeading, tblFiles);

				scrollViewInvoice.ContentSize = new CGSize(viewInvoice.Frame.Width, viewInvoiceBottom.Frame.Bottom);

				scrollViewInvoice.AutoresizingMask = UIViewAutoresizing.FlexibleHeight;

				scrollViewInvoice.AddSubview(viewInvoiceBottom);

				spinnerCharge.Layer.BorderWidth = 1;
				spinnerCharge.Layer.CornerRadius = 4;
				spinnerCharge.Layer.BorderColor = UIColor.LightGray.CGColor;
				token = CommanUtil.tokenNo;
				btnUpload1.Layer.BorderWidth = 1;
				btnUpload1.BackgroundColor = UIColor.White;

				btnUpload2.Layer.BorderWidth = 1;
				btnUpload2.BackgroundColor = UIColor.White;

				btnUpload3.Layer.BorderWidth = 1;
				btnUpload3.BackgroundColor = UIColor.White;
				//Amount TextField Should be numeric
				txtAmount.KeyboardType = UIKeyboardType.NumberPad;

				//txtAmount.ShouldChangeCharacters = (UITextField textField, NSRange range, String replace) =>
				//{
				//	int dummy;
				//	return replace.Length == 0 || int.TryParse(replace, out dummy);
				//};

			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Get Invoice Details
		/// </summary>
		private void GetInvoiceDetails()
		{
			try
			{
				string shipmentDetails = string.Empty;
				shipmentDetails = NSUserDefaults.StandardUserDefaults.StringForKey("shipmentDetails");
				lstShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(shipmentDetails);
				spinnerCharge.SetTitle("  " + Util.invoiceCharge[0], UIControlState.Normal);
				if (!string.IsNullOrEmpty(lstShipmentDetail.InvoiceCreatedOn))
				{
					txtDialogHeader.Text = Constants.strRecreateInvoice + "\n" + Constants.strCreatedOn + lstShipmentDetail.InvoiceCreatedOn;
				}
				else
				{
					txtDialogHeader.Text = Constants.strCreateInvoice;
				}
				if (lstShipmentDetail.AddlDocs != null)
				{
					objFileList = new List<string>();
					//Assign Files in a List object
					objFileList = lstShipmentDetail.AddlDocs;
				}
				else
				{
					objFileList = new List<string>();
				}
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Binds the Charges drop down.
		/// </summary>
		public void BindCharges()
		{
			try
			{
				string selectedValue = string.Empty;
				UIView pickerParentView = new UIView();
				int yPosition = (int)(View.Frame.Height - 180) / 2;
				viewPicker = new UIView(new CGRect(20, yPosition - 100, View.Frame.Width - 40, 210));
				viewPicker.BackgroundColor = UIColor.White;
				viewPicker.Layer.CornerRadius = 10;
				viewPicker.Layer.BorderWidth = 1;
				viewPicker.Layer.BorderColor = UIColor.Black.CGColor;
				pickerView = new UIPickerView(new CGRect(0, 0, viewPicker.Frame.Width, 180));
				pickerView.BackgroundColor = UIColor.White;
				pickerView.ShowSelectionIndicator = true;
				// create our simple picker model
				pickerDataModel = new PickerDataModel(Util.invoiceCharge);
				// set it on our picker class
				pickerView.Model = pickerDataModel;
				// Create a 'done' button for the toolbar and add it to the toolbar
				doneButton = new UIButton(new CGRect(0, 180, viewPicker.Frame.Width, 30));
				doneButton.BringSubviewToFront(View);
				doneButton.SetTitle(ConstantsClass.strDone, UIControlState.Normal);
				doneButton.BackgroundColor = ConstantsClass.btnColorRed;
				doneButton.Layer.CornerRadius = 10;
				doneButton.UserInteractionEnabled = true;
				viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });
				pickerDataModel.ValueChanged += (s, e) =>
				{
					selectedValue = "  " + pickerDataModel.SelectedItem;
				};
				View.Add(viewPicker);
				doneButton.TouchUpInside += (s, e) =>
				{
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
					if (!string.IsNullOrEmpty(selectedValue))
					{
						spinnerCharge.SetTitle(selectedValue, UIControlState.Normal);
					}
					else
					{
						spinnerCharge.SetTitle("  " + Util.invoiceCharge[0], UIControlState.Normal);
					}
				};
				viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });
				pickerParentView.Frame = View.Frame;
				pickerParentView.BackgroundColor = UIColor.Clear;
				pickerParentView.Add(viewPicker);
				View.Add(pickerParentView);
				var tapGesture = new UITapGestureRecognizer(new Action(delegate
				{
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
				}));
				pickerParentView.AddGestureRecognizer(tapGesture);
			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
				loadPop.Hide();
				return;
			}
		}
		/// <summary>
		/// To close the invoice view
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnClose_TouchUpInside(UIButton sender)
		{
			this.NavigationController.PopViewController(true);
		}

		/// <summary>
		/// Open Selected file or Image.
		/// </summary>
		/// <param name="fileIndex">File index.</param>
		public void RedirectToWebView(int fileIndex)
		{
			try
			{
				fileUrl = objFileList[fileIndex];
				WebViewController objWebViewController =
                    this.Storyboard.InstantiateViewController
                    ("WebViewController") as WebViewController;
                CommanUtil.fileURL = fileUrl;
                objWebViewController.strHeading = Constants.invoiceUploads;
                this.NavigationController.PushViewController(objWebViewController, true);
				//UIWebView webView = new UIWebView();
				//webView.ShouldStartLoad = HandleShouldStartLoad;
				//webView.ScalesPageToFit = true;
				//webView.LoadRequest(new NSUrlRequest(new NSUrl(fileUrl)));
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Spinners the charge touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void SpinnerCharge_TouchUpInside(UIButton sender)
		{
			BindCharges();
		}

		/// <summary>
		/// Buttons the upload1 touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnUpload1_TouchUpInside(UIButton sender)
		{
			fileIndex = 1;
			BrowserFile();
		}

		/// <summary>
		/// Buttons the upload2 touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnUpload2_TouchUpInside(UIButton sender)
		{
			fileIndex = 2;
			BrowserFile();
		}

		/// <summary>
		/// Buttons the upload3 touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnUpload3_TouchUpInside(UIButton sender)
		{
			fileIndex = 3;
			BrowserFile();
		}

		/// <summary>
		/// Buttons the create invoice touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnCreateInvoice_TouchUpInside(UIButton sender)
		{
			try
			{
				if (Reachability.InternetConnectionStatus()) 				{
					jsonCharge = JsonConvert.SerializeObject(listCharges);
					double totalShipCost = 0;
					double totalExtraCharges = 0;
					decimal total = 0;
					for (var entry = 0; entry < lstShipmentDetail.Entries.Count; entry++)
					{
						totalShipCost += lstShipmentDetail.Entries[entry].Price;
					}
					for (var charges = 0; charges < listCharges.Count; charges++)
					{
						totalExtraCharges += Convert.ToDouble(listCharges[charges].Value);
					}
					total = Convert.ToDecimal(totalShipCost + totalExtraCharges);
					string message = Constants.strSubmitInvoice + total + Constants.strWithoutCharges;
					AddInvoicePopup objConfirmPopup = new AddInvoicePopup(View, message, this);
					UIView viewConfirmpop = objConfirmPopup.GetPopupScreen();
					View.Add(viewConfirmpop);
				}
				else 				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
					this.View.Add(this.customAlert);
				}
			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
				loadPop.Hide();
			}
		}

		/// <summary>
		/// Buttons the add charge touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnAddCharge_TouchUpInside(UIButton sender)
		{
			try
			{
				View.EndEditing(true);
				if (!string.IsNullOrEmpty(txtAmount.Text))
				{
					ManageCharges(true);
				}
				else
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strEnterAmount, true, this, "", 1);
					this.View.Add(this.customAlert);
					return;
				}
			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
				loadPop.Hide();
				return;
			}
		}


		public void ManageCharges(bool addChargeFlag)
		{
			nfloat yCordinate = 0;

			if (addChargeFlag)
			{
				Charges objCharge = new Charges();
				objCharge.ID = spinnerCharge.TitleLabel.Text;
				objCharge.Value = txtAmount.Text;

				listCharges.Add(objCharge);
			}
			foreach (UIView objView in viewInvoiceBottom)
			{
				objView.RemoveFromSuperview();
			}
			//viewInvoiceBottom.RemoveFromSuperview();
			if (listCharges != null && listCharges.Count > 0)
			{

				lblAddedCharges.Frame = new CGRect(0, yCordinate, View.Frame.Width, 30);
				lblAddedCharges.BackgroundColor = Constants.tableRowOddColor;

				lblAddedCharges.TextColor = UIColor.Black;
				lblAddedCharges.Font = UIFont.FromName(Constants.strFontName, 15f);
				lblAddedCharges.Text = NSBundle.MainBundle.LocalizedString("addCharge", null);

				viewChargeTableHeading.Frame = new CGRect(15, lblAddedCharges.Frame.Bottom + 10, View.Frame.Width - 30, 25);
				viewChargeTableHeading.BackgroundColor = Constants.fileHeadBGC;

				lblAction.Frame = new CGRect(0, 0, viewChargeTableHeading.Frame.Width / 10 * 3, 25);
				lblAction.TextColor = UIColor.White;
				lblAction.Font = UIFont.FromName(Constants.strFontName, 15f);
				lblAction.Text = NSBundle.MainBundle.LocalizedString("action", null);
				lblAction.TextAlignment = UITextAlignment.Center;

				lblCharge.Frame = new CGRect(viewChargeTableHeading.Frame.Width / 10 * 3, 0, viewChargeTableHeading.Frame.Width / 10 * 3, 25);
				lblCharge.TextColor = UIColor.White;
				lblCharge.Font = UIFont.FromName(Constants.strFontName, 15f);
				lblCharge.Text = NSBundle.MainBundle.LocalizedString("charge", null);
				lblCharge.TextAlignment = UITextAlignment.Center;

				lblAmount.Frame = new CGRect(viewChargeTableHeading.Frame.Width / 10 * 6, 0, viewChargeTableHeading.Frame.Width / 10 * 4, 25);
				lblAmount.TextColor = UIColor.White;
				lblAmount.Font = UIFont.FromName(Constants.strFontName, 15f);
				lblAmount.Text = NSBundle.MainBundle.LocalizedString("amount", null);
				lblAmount.TextAlignment = UITextAlignment.Center;

				viewChargeTableHeading.AddSubviews(lblAction, lblCharge, lblAmount);

				//UITableView tblCharges = new UITableView();
				tblCharges.Frame = new CGRect(15, viewChargeTableHeading.Frame.Bottom, View.Frame.Width - 30, listCharges.Count * 35);
				tblCharges.Hidden = false;
				tblCharges.Source = new InvoiceChargesAdapter(listCharges, viewInvoiceBottom, lblAddedCharges,
					viewChargeTableHeading, lblFileHeading, tblFiles, scrollViewInvoice, objFileList, viewAddCharge);
				tblCharges.RowHeight = 35;
				tblCharges.ReloadData();
			}
			if (objFileList != null && objFileList.Count > 0)
			{
				lblFileHeading.Frame = new CGRect(15, tblCharges.Frame.Y + listCharges.Count * 25 + 20, View.Frame.Width - 30, 30);
				lblFileHeading.BackgroundColor = Constants.fileHeadBGC;
				lblFileHeading.TextColor = UIColor.White;
				lblFileHeading.Font = UIFont.FromName(Constants.strFontName, 15f);
				lblFileHeading.Text = NSBundle.MainBundle.LocalizedString("attached", null);
				tblFiles.Frame = new CGRect(15, lblFileHeading.Frame.Bottom, View.Frame.Width - 30, objFileList.Count * 25);
				tblFiles.Source = new InvoiceFileAdapter(objFileList, this);
				tblFiles.RowHeight = 25;
			}
			else
			{
				lblFileHeading.Frame = new CGRect(15, tblCharges.Frame.Bottom + 10, View.Frame.Width - 30, 0);
				tblFiles.Frame = new CGRect(15, lblFileHeading.Frame.Bottom, View.Frame.Width - 30, 0);
			}

			viewInvoiceBottom.Frame = new CGRect(0, viewAddCharge.Frame.Bottom, View.Frame.Width, tblFiles.Frame.Bottom);

			viewInvoiceBottom.AddSubviews(lblAddedCharges, viewChargeTableHeading, tblCharges, lblFileHeading, tblFiles);

			scrollViewInvoice.ContentSize = new CGSize(View.Frame.Width, viewInvoiceBottom.Frame.Bottom);
			scrollViewInvoice.ScrollEnabled = true;
			scrollViewInvoice.AutoresizingMask = UIViewAutoresizing.FlexibleHeight;

			scrollViewInvoice.AddSubview(viewInvoiceBottom);
			txtAmount.Text = string.Empty;
		}
		/// <summary>
		/// Browsers the file.
		/// </summary>
		public void BrowserFile()
		{
			try
			{
				//UIDocumentPickerViewController documentPicker = new UIDocumentPickerViewController();
				imagePicker = new UIImagePickerController();
				imagePicker.SourceType = UIImagePickerControllerSourceType.PhotoLibrary;
				imagePicker.MediaTypes = UIImagePickerController.AvailableMediaTypes(UIImagePickerControllerSourceType.PhotoLibrary);
				imagePicker.FinishedPickingMedia += Handle_FinishedPickingMedia;
				imagePicker.Canceled += Handle_Canceled;
				NavigationController.PresentModalViewController(imagePicker, true);

			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Handles the finished picking media.
		/// </summary>
		/// <param name="sender">Sender.</param>
		/// <param name="e">E.</param>
		public void Handle_FinishedPickingMedia(object sender, UIImagePickerMediaPickedEventArgs e)
		{
			try
			{
				// determine what was selected, video or image
				bool isImage = false;
				switch (e.Info[UIImagePickerController.MediaType].ToString())
				{
					case "public.image":
						Console.WriteLine(NSBundle.MainBundle.LocalizedString("imageSelected", null));
						isImage = true;
						break;
					case "public.video":
						Console.WriteLine(NSBundle.MainBundle.LocalizedString("videoSeleted", null));
						break;
				}
				// get common info (shared between images and video)
				NSUrl referenceURL = e.Info[new NSString("UIImagePickerControllerReferenceURL")] as NSUrl;
				if (referenceURL != null)
				{
					string fileNm = FileUploadHelper.GetFileName(referenceURL.LastPathComponent.ToString());
					// if it was an image, get the other image info
					if (isImage)
					{
						// get the original image
						UIImage originalImage = e.Info[UIImagePickerController.OriginalImage] as UIImage;
						//MediaFile dsds;
						using (var imageData = originalImage.AsJPEG(0.6f))
						{
							bytes = new byte[imageData.Length];
							if (fileIndex == 1)
							{
								txtFileName1.Text = fileNm;
								fileUri[0] = fileNm;
								listFileBytes[0] = bytes;
							}
							else if (fileIndex == 2)
							{
								txtFileName2.Text = fileNm;
								fileUri[1] = fileNm;
								listFileBytes[1] = bytes;
							}
							else if (fileIndex == 3)
							{
								txtFileName3.Text = fileNm;
								fileUri[2] = fileNm;
								listFileBytes[2] = bytes;
							}
							Marshal.Copy(imageData.Bytes, bytes, 0, Convert.ToInt32(imageData.Length));
						}
					}
					else
					{
						// get video url
						NSUrl mediaURL = e.Info[UIImagePickerController.MediaURL] as NSUrl;
						if (mediaURL != null)
						{

						}
					}
					//FileData filedata = await CrossFilePicker.Current.PickFile();
					// dismiss the picker
					//imagePicker.DismissModalViewControllerAnimated(true);
					imagePicker.DismissModalViewController(true);
				}
			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
				loadPop.Hide();
				return;
			}
		}

		/// <summary>
		/// Handles the canceled.
		/// </summary>
		/// <param name="sender">Sender.</param>
		/// <param name="e">E.</param>
		void Handle_Canceled(object sender, EventArgs e)
		{
			imagePicker.DismissModalViewController(true);
		}

		/// <summary>
		/// Create Invoice If Any File Selected 
		/// </summary>
		/// <returns></returns>
		public async void CreateInvoice()
		{
			try
			{
				CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
				loadPop = null;
                if(!CommanUtil.IsTimeOut())
                {
                    return;
                }
				if (loadPop == null)
				{
					loadPop = new LoadingOverlay(bounds);
				}
				View.Add(loadPop);
				if (listFileBytes != null)
				{
					//File Will be upload
					for (int fileIndex = 0; fileIndex < listFileBytes.Count; fileIndex++)
					{
						if (listFileBytes[fileIndex] != null)
						{
							fileName = fileUri[fileIndex];
							string uploadResult = await UploadBitmapAsync(listFileBytes[fileIndex], fileName);
							if (uploadResult != null)
							{
								jobject = JObject.Parse(uploadResult);
								if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
								{
									jsonFileRequest += FileUploadHelper.UploadsJsonRequest(uploadResult);
									jsonFileRequest += ",";
								}
								else
								{
									await Util.ErrorLog(Constants.invoiceUploads, Convert.ToString(jobject[Constants.strErrorMessage]), CommanUtil.tokenNo);
									this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Convert.ToString(jobject[Constants.strErrorMessage]), true, this, "", 1);
									this.View.Add(this.customAlert);
									loadPop.Hide();
									return;
								}
							}
							else
							{
								this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strNoFile, true, this, "", 1);
								this.View.Add(this.customAlert);
								loadPop.Hide();
								return;
							}
						}
					}
					//Save Invoice with files
					await SaveInvoice();
				}
				else
				{
					//Save Invoice withod files
					await SaveInvoice();
				}
			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
				loadPop.Hide();
				return;
			}
		}

		/// <summary>
		/// Save Invoice with Files and Extra charges
		/// </summary>
		/// <returns></returns>
		private async Task SaveInvoice()
		{
			try
			{
				objServiceHelper = new ServiceHelper();
				apiMethod = APIMethods.shipmentDetails + "/" + lstShipmentDetail.ClientID + "|" + lstShipmentDetail.LocID + "|" + lstShipmentDetail.BolNum + "/" + APIMethods.invoice;
				string requestBody = "{" + "\"Comments\":" + "\"" + txtComment.Text + "\"" + ",";
				requestBody += "\"ExtraCharges\":" + jsonCharge + ",";
				requestBody += "\"Files\":[" + jsonFileRequest + "]";
				requestBody += "}";

				string response = await objServiceHelper.PostRequestJson(requestBody, apiMethod, token, true);
                if (!string.IsNullOrEmpty(response))
                {
                    //var result = JsonConvert.DeserializeObject(response);
                    //if (result.ToString().ToUpper() == Constants.strSuccess.ToUpper())
                    //{
                    await ResetControl();
                    //}
                    //else
                    //{
                    //	await ResetControl();
                    //}
                }
			}
			catch
			{
				loadPop.Hide();
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
				loadPop.Hide();
				return;
			}
		}

		/// <summary>
		/// File upload
		/// </summary>
		/// <param name="bytes">File will be in bytes</param>
		/// <returns></returns>
		public async Task<string> UploadBitmapAsync(byte[] bytes, string fileName)
		{
			try
			{
				objFileUploadHelper = new FileUploadHelper();
				apiMethod = APIMethods.supportfile;
				string response = await objFileUploadHelper.PostFiles(bytes, fileName, apiMethod, token, true);
				return response;
			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
				loadPop.Hide();
				return null;
			}
		}

		/// <summary>
		/// Data refresh and Reset the controls
		/// </summary>
		private async Task ResetControl()
		{
			try
			{
				apiMethod = lstShipmentDetail.ClientID + "|" + lstShipmentDetail.BolNum;
				await Util.BindShipmentDetails(apiMethod);//Bind shipment
				GetInvoiceDetails();//Get Latest changes
				listCharges = new List<Charges>();
				txtFileName1.Text = "";
				txtFileName2.Text = "";
				txtFileName3.Text = "";
				txtComment.Text = "";
				txtAmount.Text = "";
				CreatingControls();
				loadPop.Hide();
			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
				loadPop.Hide();
				return;
			}
		}
	}
}