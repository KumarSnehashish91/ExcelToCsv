using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;
using CoreGraphics;
using SidebarNavigation;
using MonoTouch.Dialog;
using CoreAnimation;
using RateLinx.Models;
using RateLinx.Helper;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Threading.Tasks;
using RateLinx.APIs;
using ZXing.Mobile;
using CoreLocation;
using ToastIOS;
using Plugin.Connectivity;

namespace RateLinx.iOS
{
    /// <summary>
    /// Dashboard controller.
    /// </summary>
	public partial class DashboardController : UIViewController
	{
		#region Global Used variables
		UITapGestureRecognizer tapGesture, tapGestureActiveIcon, tapGestureAwardedIcon, tapGestureRecentIcon, tapGestureBackIcon = null;
		LoadingOverlay loadPop;
		public List<string> lstStrings { get; set; }
		bool isFirstTimeLoad = true;//Flag to avoid Creating Fragments many times
		JObject jobject = null;
		string activeShipments = string.Empty;
		string awardedShipments = string.Empty;
		string recentShipments = string.Empty;
		string methodName = string.Empty;
		string tokenNo = string.Empty;
		private ActiveShipmentAdapter objActiveShipmentAdapter;
		private AwardedShipmentAdapter objAwardedShipmentAdapter;
		private RecentShipmentAdapter objRecentShipmentAdapter;
		List<ActiveShipments> lstActiveShipments = null;  // Declare active shipment list
		List<AwardedShipments> lstAwardedShipents = null;  // Declare active shipment list
		List<RecentShipments> lstRecentShipments = null;  // Declare active shipment list
		//public static LocationManager Manager { get; set; }///location
		CustomPopup customAlert = null;
		ModalPickerViewController modalPicker = null;
		UIPickerView pickerView = null;
		PickerDataModel pickerDataModel = null;
		UIButton doneButton = null;
		UIView viewPicker, menuView = null;
		UIView viewForDriverAwarded = new UIView();
		UIView viewForDriverRecent = new UIView();
		UILabel lblNoAwardedShipments = new UILabel();
		UILabel lblNoRecentShipments = new UILabel();
		UILabel lblNoActiveShipments = new UILabel();
		UIButton ddlDriverList;
		UIButton ddlAwradedDriver;
		string selectedValueAwarded = string.Empty;
		string selectedValue = string.Empty;
		int tabNumber = 1;
        public bool isAllowPooling = true;
		#endregion
        /// <summary>
        /// Initializes a new instance of the <see cref="T:RateLinx.iOS.DashboardController"/> class.
        /// </summary>
        /// <param name="handle">Handle.</param>
		public DashboardController(IntPtr handle) : base(handle)
		{

		}
        /// <summary>
        /// Views the did load.
        /// </summary>
		public override void ViewDidLoad()
		{
			try
			{
				base.ViewDidLoad();
				//Getting menu view on the home page 
                menuView = new MenuViewController(View).DisplayMenuView(null, this, null, null,null, imgMenu);

            
				imgBack.Hidden = true;
				CommanUtil.trackingEnabled = false;

				lblCopyRight.Text = Util.GetCopyRight();
				tblAwardedShipment.Hidden = true;
				tblActiveShipment.RowHeight = UITableView.AutomaticDimension;
				tblActiveShipment.EstimatedRowHeight = 10;
				//tblActiveShipment.ReloadData();
				tblActiveShipment.AllowsSelection = false;
				tapGesture = new UITapGestureRecognizer(MenuImgTapped);
				imgMenu.AddGestureRecognizer(tapGesture);

				tapGestureBackIcon = new UITapGestureRecognizer(MenuImgTapped);
				imgBack.AddGestureRecognizer(tapGestureBackIcon);

				tapGestureActiveIcon = new UITapGestureRecognizer(ShipmentIconTapChange);
				ActiveShipmentVW.AddGestureRecognizer(tapGestureActiveIcon);

				tblActiveShipment.Bounces = false;
				tblAwardedShipment.Bounces = false;
				tblRecentShipment.Bounces = false;

				imgActiveShip.Image = UIImage.FromBundle("Images/active-icon-png.PNG");

				tapGestureAwardedIcon = new UITapGestureRecognizer(ShipmentIconTapChange);
				AwardedShipmentVW.AddGestureRecognizer(tapGestureAwardedIcon);

				tapGestureRecentIcon = new UITapGestureRecognizer(ShipmentIconTapChange);
				RecentShipmentVW.AddGestureRecognizer(tapGestureRecentIcon);
				ShipmentsIconTextChange(UIColor.Red, UIColor.Black, UIColor.Black, "Images/active-hover-icon-png.PNG", "Images/awardedicon.png", "Images/upcomingicon.png");


				UISwipeGestureRecognizer recognizerRightActive = new UISwipeGestureRecognizer(RightToLeftSwipeActive);
				recognizerRightActive.Enabled = true;
				recognizerRightActive.Direction = UISwipeGestureRecognizerDirection.Left;
				viewActiveShipment.AddGestureRecognizer(recognizerRightActive);


				UISwipeGestureRecognizer recognizerLeftAwarded = new UISwipeGestureRecognizer(LeftToRightSwiptAwarded);
				recognizerLeftAwarded.Direction = UISwipeGestureRecognizerDirection.Right;
				viewAwarededShipment.AddGestureRecognizer(recognizerLeftAwarded);


				UISwipeGestureRecognizer recognizerRigthAwarded = new UISwipeGestureRecognizer(RightToLeftSwiptAwarded);
				recognizerRigthAwarded.Direction = UISwipeGestureRecognizerDirection.Left;
				viewAwarededShipment.AddGestureRecognizer(recognizerRigthAwarded);


				UISwipeGestureRecognizer recognizerRightRecent = new UISwipeGestureRecognizer(LeftToRightSwiptRecent);
				recognizerRightRecent.Direction = UISwipeGestureRecognizerDirection.Right;
				viewRecentShipments.AddGestureRecognizer(recognizerRightRecent);

				//Hinding Key Board And Popups
				var gesture = new UITapGestureRecognizer(() =>
				{
					if (viewPicker != null)
					{
						viewPicker.Hidden = true;
						pickerView.Hidden = true;
						doneButton.Hidden = true;
					}
					if (modalPicker != null)
					{
						DismissViewController(true, null);
					}
					View.EndEditing(true);
				});
				gesture.CancelsTouchesInView = false;
				View.AddGestureRecognizer(gesture);
				if (!Reachability.InternetConnectionStatus())
				{
                    UIView.Animate(0.3,
					() =>
					{
						if (menuView != null)
						{
							menuView.Frame = new CGRect(-1000, 0, View.Frame.Width, View.Frame.Height);
						}
					});

					tblActiveShipment.Hidden = true;

					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
					this.View.Add(this.customAlert);
				}
				InvokeOnMainThread(() =>
				{
                    PoolingShipmentInterval();
				});
                
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}

        /// <summary>
        /// Views the did appear.
        /// </summary>
        /// <param name="animated">If set to <c>true</c> animated.</param>
        public override void ViewDidAppear(bool animated)
        {
            base.ViewDidAppear(animated);
            imgMenu.UserInteractionEnabled = true;
            isAllowPooling = true;
            PoolingShipmentInterval();
            BindActiveShipments();
            BindAwardedShipments();
            BindRecentShipments();

        }

        /// <summary>
        /// Views the will appear.
        /// </summary>
        /// <param name="animated">If set to <c>true</c> animated.</param>
        public override void ViewWillAppear(bool animated)
        {
            base.ViewWillAppear(animated);
            BindRecentShipments();
            imgMenu.UserInteractionEnabled = true;
        }
        /// <summary>
        /// Views the did disappear.
        /// </summary>
        /// <param name="animated">If set to <c>true</c> animated.</param>
        public override void ViewDidDisappear(bool animated)
        {
            isAllowPooling = false;
            base.ViewDidDisappear(animated);
        }

        /// <summary>
        /// Dids the rotate.
        /// </summary>
        /// <param name="fromInterfaceOrientation">From interface orientation.</param>
		public override void DidRotate(UIInterfaceOrientation fromInterfaceOrientation)
		{
			if (tabNumber == 1)
			{
				BindActiveShipments();
                BindAwardedShipments();
                BindRecentShipments();
			}
			else if (tabNumber == 2)
			{
                BindActiveShipments();
				BindAwardedShipments();
				BindRecentShipments();
			}
			else
			{
                BindActiveShipments();
				BindAwardedShipments();
				BindRecentShipments();
			}
			if (Util.isMenuVisible)
			{
				if(menuView != null)
				{
					menuView.RemoveFromSuperview();
					menuView = null;
				}
                menuView = new MenuViewController(View).DisplayMenuView(null, this, null, null,null, imgMenu);
				View.AddSubview(menuView);
				menuView.Frame = new CGRect(0, 0, View.Frame.Width, View.Frame.Height);
			}
		}

        /// <summary>
        /// Menus the image tapped.
        /// </summary>
        /// <param name="tapGesture">Tap gesture.</param>
		public void MenuImgTapped(UITapGestureRecognizer tapGesture)
		{
			imgBack.Tag = 2;
			if (tapGesture.View.Equals(imgBack))
			{
				StopTrackingPopup objStopTracking = new StopTrackingPopup(this.View, this, null);
				this.View.Add(objStopTracking.GetPopupScreen(imgBack.Tag));
			}
			else
			{
				//imgMenu.UserInteractionEnabled = false;
				Util.isMenuVisible = true;
                menuView = new MenuViewController(View).DisplayMenuView(null, this, null, null, null,imgMenu);
				View.AddSubview(menuView);

				UIView.Animate(0.3,
				() =>
				{
					if (menuView != null)
					{
						menuView.Frame = new CGRect(0, 0, View.Frame.Width, View.Frame.Height - 20);
					}

				});

			}
		}
        /// <summary>
        /// Dids the receive memory warning.
        /// </summary>
		public override void DidReceiveMemoryWarning()
		{
			base.DidReceiveMemoryWarning();
			// Release any cached data, images, etc that aren't in us
		}
        /// <summary>
        /// Row clicked event arguments.
        /// </summary>
		public class RowClickedEventArgs : EventArgs
		{
			public string item { get; set; }
			public RowClickedEventArgs(string item) : base()
			{
				this.item = item;
			}
		}
        /// <summary>
        /// Rights to left swipe active.
        /// </summary>
		private void RightToLeftSwipeActive()
		{
			tabNumber = 2;
			viewActiveShipment.Hidden = true;
			viewAwarededShipment.Hidden = false;
			viewRecentShipments.Hidden = true;

			ShipmentsIconTextChange(UIColor.Black, UIColor.Red, UIColor.Black, "Images/active-icon-png.PNG", "Images/awardedhovericon.png", "Images/upcomingicon.png");
			viewActiveShipment.Frame = new CGRect(-viewActiveShipment.Frame.Width, viewActiveShipment.Frame.Top, viewActiveShipment.Frame.Width, viewActiveShipment.Frame.Height);
			viewRecentShipments.Frame = new CGRect(viewRecentShipments.Frame.Width, viewRecentShipments.Frame.Top, viewRecentShipments.Frame.Width, viewRecentShipments.Frame.Height);

			UIView.Animate(ConstantsClass.animationDuration,
				() =>
				{
					viewAwarededShipment.Frame = new CGRect(0, viewAwarededShipment.Frame.Top, viewAwarededShipment.Frame.Width, viewAwarededShipment.Frame.Height);

				});
		}
        /// <summary>
        /// Lefts to right swipt awarded.
        /// </summary>
		private void LeftToRightSwiptAwarded()
		{
			tabNumber = 1;
			viewActiveShipment.Hidden = false;
			viewAwarededShipment.Hidden = true;
			viewRecentShipments.Hidden = true;

			ShipmentsIconTextChange(UIColor.Red, UIColor.Black, UIColor.Black, "Images/active-hover-icon-png.PNG", "Images/awardedicon.png", "Images/upcomingicon.png");
			viewAwarededShipment.Frame = new CGRect(viewAwarededShipment.Frame.Width, viewAwarededShipment.Frame.Top, viewAwarededShipment.Frame.Width, viewAwarededShipment.Frame.Height);
			viewRecentShipments.Frame = new CGRect(viewRecentShipments.Frame.Width, viewRecentShipments.Frame.Top, viewRecentShipments.Frame.Width, viewRecentShipments.Frame.Height);

			UIView.Animate(ConstantsClass.animationDuration,
				() =>
				{
					viewActiveShipment.Frame = new CGRect(0, viewActiveShipment.Frame.Top, viewActiveShipment.Frame.Width, viewActiveShipment.Frame.Height);

				});
		}

        /// <summary>
        /// Rights to left swipt awarded.
        /// </summary>
		private void RightToLeftSwiptAwarded()
		{
			tabNumber = 3;
			viewActiveShipment.Hidden = true;
			viewAwarededShipment.Hidden = true;
			viewRecentShipments.Hidden = false;

			ShipmentsIconTextChange(UIColor.Black, UIColor.Black, UIColor.Red, "Images/active-icon-png.PNG", "Images/awardedicon.png", "Images/upcominghovericon.png");
			viewActiveShipment.Frame = new CGRect(-viewActiveShipment.Frame.Width, viewActiveShipment.Frame.Top, viewActiveShipment.Frame.Width, viewActiveShipment.Frame.Height);
			viewAwarededShipment.Frame = new CGRect(-viewAwarededShipment.Frame.Width, viewAwarededShipment.Frame.Top, viewAwarededShipment.Frame.Width, viewAwarededShipment.Frame.Height);

			UIView.Animate(ConstantsClass.animationDuration,
				() =>
				{
					viewRecentShipments.Frame = new CGRect(0, viewRecentShipments.Frame.Top, viewRecentShipments.Frame.Width, viewRecentShipments.Frame.Height);

				});
			imgActiveShip.Image = UIImage.FromBundle("Images/active-icon-png.PNG");
			imgAwardedShip.Image = UIImage.FromBundle("Images/awardedicon.png");
			imgRecentShip.Image = UIImage.FromBundle("Images/upcominghovericon.png");
		}

        /// <summary>
        /// Lefts to right swipt recent.
        /// </summary>
		private void LeftToRightSwiptRecent()
		{
			tabNumber = 2;
			viewActiveShipment.Hidden = true;
			viewAwarededShipment.Hidden = false;
			viewRecentShipments.Hidden = true;

			ShipmentsIconTextChange(UIColor.Black, UIColor.Red, UIColor.Black, "Images/active-icon-png.PNG", "Images/awardedhovericon.png", "Images/upcomingicon.png");
			viewActiveShipment.Frame = new CGRect(-viewActiveShipment.Frame.Width, viewActiveShipment.Frame.Top, viewActiveShipment.Frame.Width, viewActiveShipment.Frame.Height);
			viewRecentShipments.Frame = new CGRect(viewRecentShipments.Frame.Width, viewRecentShipments.Frame.Top, viewRecentShipments.Frame.Width, viewRecentShipments.Frame.Height);

			UIView.Animate(ConstantsClass.animationDuration,
				() =>
				{
					viewAwarededShipment.Frame = new CGRect(0, viewAwarededShipment.Frame.Top, viewAwarededShipment.Frame.Width, viewAwarededShipment.Frame.Height);

				});
		}

        /// <summary>
        /// Shipmentses the icon text change.
        /// </summary>
        /// <param name="lblActive">Lbl active.</param>
        /// <param name="lblAwarded">Lbl awarded.</param>
        /// <param name="lblRecent">Lbl recent.</param>
        /// <param name="pathActive">Path active.</param>
        /// <param name="pathAwarded">Path awarded.</param>
        /// <param name="pathRecent">Path recent.</param>
		public void ShipmentsIconTextChange(UIColor lblActive, UIColor lblAwarded, UIColor lblRecent, string pathActive, string pathAwarded, string pathRecent)
		{
			btnActive.SetTitleColor(lblActive, UIControlState.Normal);
			btnAwareded.SetTitleColor(lblAwarded, UIControlState.Normal);
			btnRecent.SetTitleColor(lblRecent, UIControlState.Normal);

			imgActiveShip.Image = UIImage.FromBundle(pathActive);
			imgAwardedShip.Image = UIImage.FromBundle(pathAwarded);
			imgRecentShip.Image = UIImage.FromBundle(pathRecent);
		}
        /// <summary>
        /// Shipments the icon tap change.
        /// </summary>
        /// <param name="tapGesture">Tap gesture.</param>
		public void ShipmentIconTapChange(UITapGestureRecognizer tapGesture)
		{
			if (tapGesture.View.Equals(ActiveShipmentVW))
			{
				ActiveShipmentSlide();
			}
			else if (tapGesture.View.Equals(AwardedShipmentVW))
			{
				AwardedShipmentSlide();
			}
			else if (tapGesture.View.Equals(RecentShipmentVW))
			{
				RecentShipmentSlide();
			}

		}
        /// <summary>
        /// Actives the shipment slide.
        /// </summary>
		public void ActiveShipmentSlide()
		{
			tabNumber = 1;

			viewActiveShipment.Hidden = false;
			viewAwarededShipment.Hidden = true;
			viewRecentShipments.Hidden = true;

			ShipmentsIconTextChange(UIColor.Red, UIColor.Black, UIColor.Black, "Images/active-hover-icon-png.PNG", "Images/awardedicon.png", "Images/upcomingicon.png");
			viewAwarededShipment.Frame = new CGRect(viewAwarededShipment.Frame.Width, viewAwarededShipment.Frame.Top, viewAwarededShipment.Frame.Width, viewAwarededShipment.Frame.Height);
			viewRecentShipments.Frame = new CGRect(viewRecentShipments.Frame.Width, viewRecentShipments.Frame.Top, viewRecentShipments.Frame.Width, viewRecentShipments.Frame.Height);
			UIView.Animate(ConstantsClass.animationDuration,
				() =>
				{
					viewActiveShipment.Frame = new CGRect(0, viewActiveShipment.Frame.Top, viewActiveShipment.Frame.Width, viewActiveShipment.Frame.Height);

				});
		}
        /// <summary>
        /// Awardeds the shipment slide.
        /// </summary>
		public void AwardedShipmentSlide()
		{
			
			tabNumber = 2;
			viewActiveShipment.Hidden = true;
			viewAwarededShipment.Hidden = false;
			viewRecentShipments.Hidden = true;

			ShipmentsIconTextChange(UIColor.Black, UIColor.Red, UIColor.Black, "Images/active-icon-png.PNG", "Images/awardedhovericon.png", "Images/upcomingicon.png");
			viewActiveShipment.Frame = new CGRect(-viewActiveShipment.Frame.Width, viewActiveShipment.Frame.Top, viewActiveShipment.Frame.Width, viewActiveShipment.Frame.Height);
			viewRecentShipments.Frame = new CGRect(viewRecentShipments.Frame.Width, viewRecentShipments.Frame.Top, viewRecentShipments.Frame.Width, viewRecentShipments.Frame.Height);
			UIView.Animate(ConstantsClass.animationDuration,
				() =>
				{
					viewAwarededShipment.Frame = new CGRect(0, viewAwarededShipment.Frame.Top, viewAwarededShipment.Frame.Width, viewAwarededShipment.Frame.Height);

				});
		}
        /// <summary>
        /// Recents the shipment slide.
        /// </summary>
		public void RecentShipmentSlide()
		{
			tabNumber = 3;
			viewActiveShipment.Hidden = true;
			viewAwarededShipment.Hidden = true;
			viewRecentShipments.Hidden = false;

			ShipmentsIconTextChange(UIColor.Black, UIColor.Black, UIColor.Red, "Images/active-icon-png.PNG", "Images/awardedicon.png", "Images/upcominghovericon.png");
			viewActiveShipment.Frame = new CGRect(-viewActiveShipment.Frame.Width, viewActiveShipment.Frame.Top, viewActiveShipment.Frame.Width, viewActiveShipment.Frame.Height);
			viewAwarededShipment.Frame = new CGRect(-viewAwarededShipment.Frame.Width, viewAwarededShipment.Frame.Top, viewAwarededShipment.Frame.Width, viewAwarededShipment.Frame.Height);
			UIView.Animate(ConstantsClass.animationDuration,
				() =>
				{
					viewRecentShipments.Frame = new CGRect(0, viewRecentShipments.Frame.Top, viewRecentShipments.Frame.Width, viewRecentShipments.Frame.Height);

				});
		}


       /// <summary>
       /// Poolings the shipment in interval.
       /// </summary>
        public async void PoolingShipmentInterval()
        {
            try
            {
                while (!CommanUtil.stopPooling && isAllowPooling)
                {
                    if (!string.IsNullOrEmpty(CommanUtil.tokenNo))
                    {
                        if (Reachability.InternetConnectionStatus())
                        {
                            //if(!CommanUtil.IsTimeOut())
                            //{
                            //    isAllowPooling = false;
                            //}
                            if (!IsTimeOut())
                            {
                                return;
                            }
                            else
                            {
                                await BindShipments();
                            }
                        }
                    }
                    else
                    {
                        CommanUtil.stopPooling = true;
                    }
                    await Task.Delay(ConstantsClass.delay);
                }
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
            }
        }
        /// <summary>
        /// Redirects to login.
        /// </summary>
        /// <param name="navigationController">Navigation controller.</param>
		public void RedirectToLogin(UINavigationController navigationController)
		{
			var loginController = (LoginController)Storyboard.InstantiateViewController("LoginController");

			navigationController.PushViewController(loginController, true);
		}

		/// <summary>
		/// Get the shipments response from API and bind them on page
		/// </summary>
		public async Task BindShipments()
		{
			CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;

			if (loadPop == null)
			{
				loadPop = new LoadingOverlay(bounds);
			}
			try
			{
				tokenNo = CommanUtil.tokenNo;
				if (!string.IsNullOrEmpty(tokenNo))
				{
					if (Reachability.InternetConnectionStatus())
					{
						//Get the service Helper Object
						ServiceHelper objServicehelper = new ServiceHelper();
						// create json object that holds the api values
						//Method Name
						methodName = APIMethods.shipments;
						View.Add(loadPop);
						//Get the Shipments
						string strResponse = string.Empty;
						strResponse = await objServicehelper.GetRequest(tokenNo, methodName, true);
						if (isFirstTimeLoad)
						{
							//Alerts.HideBusyLoader();
						}
						if (!string.IsNullOrEmpty(strResponse))
						{
							loadPop.Hide();
							jobject = JObject.Parse(strResponse);
							CommanUtil.ViewAs = Convert.ToString(jobject["ViewAs"]);
							if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
							{
								CommanUtil.stopPooling = Convert.ToBoolean(Convert.ToString(jobject["StopPolling"]));
								//Active shipments
								activeShipments = Convert.ToString(jobject["ActiveShipments"]);
								//Awarded shipments
								awardedShipments = Convert.ToString(jobject["AwardedShipments"]);
								//Recent Shipments 
								recentShipments = Convert.ToString(jobject["FuturePickups"]);
								BindActiveShipments();
								BindAwardedShipments();
								BindRecentShipments();
							}
							else
							{
								//Post Error Logger Request 
								await Util.ErrorLog(NSBundle.MainBundle.GetLocalizedString("accountDetails", null), Convert.ToString(jobject[Constants.strErrorMessage]), tokenNo);
								//Print Message
								if (!CommanUtil.stopPooling)
								{
									this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Convert.ToString(jobject[Constants.strErrorMessage]), true, this, "", 1);
									this.View.Add(this.customAlert);
								}
							}
							strResponse = null;
							objServicehelper = null;
						}
					}
				}
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}
        /// <summary>
        /// Binds the active shipments.
        /// </summary>
		public void BindActiveShipments()
		{
			try
			{
				lblNoActiveShipments.Frame = new CGRect(10, 10, viewActiveShipment.Frame.Width - 10, 30);
				lblNoActiveShipments.TextColor = UIColor.Red;
				lblNoActiveShipments.Font = UIFont.FromName(Constants.strFontName, 15f);

				viewActiveShipment.AddSubview(lblNoActiveShipments);

				if (!string.IsNullOrEmpty(activeShipments) && activeShipments.Trim() != "[]")
				{
					lblNoActiveShipments.RemoveFromSuperview();
					lblNoActiveShipments.Hidden = true;
					tblActiveShipment.Hidden = false;
					tblActiveShipment.ShowsVerticalScrollIndicator = false;

					lstActiveShipments = JsonConvert.DeserializeObject<List<ActiveShipments>>(activeShipments);

				
					if (tblActiveShipment.Source != null)
					{
						objActiveShipmentAdapter.lstActiveShipments = lstActiveShipments;
						UIView.PerformWithoutAnimation(delegate
						{
							tblActiveShipment.TableFooterView = new UIView(CGRect.Empty);
							tblActiveShipment.BeginUpdates();
							tblActiveShipment.ReloadSections(NSIndexSet.FromIndex(0), UITableViewRowAnimation.None);
							tblActiveShipment.EndUpdates();
						});
					}
					else
					{
						objActiveShipmentAdapter = new ActiveShipmentAdapter(this, lstActiveShipments);
						tblActiveShipment.Source = objActiveShipmentAdapter;
						tblActiveShipment.TableFooterView = new UIView(CGRect.Empty);
						tblActiveShipment.ReloadData();
					}
				}
				else
				{
					tblActiveShipment.Hidden = true;
					lblNoActiveShipments.Hidden = false;
					lblNoActiveShipments.Text = NSBundle.MainBundle.GetLocalizedString("noActiveShipment", null);
					viewActiveShipment.AddSubview(lblNoActiveShipments);
				}
			}
			catch
			{
				tblActiveShipment.TableFooterView = new UIView(CGRect.Empty);
				Console.WriteLine(Constants.strErrorOccured);
			}
		}
        /// <summary>
        /// Binds the awarded shipments.
        /// </summary>
		public void BindAwardedShipments()
		{
			try
			{
				tblAwardedShipment.ShowsVerticalScrollIndicator = false;
				lstAwardedShipents = JsonConvert.DeserializeObject<List<AwardedShipments>>(awardedShipments);
				if (CommanUtil.ViewAs == Constants.strCarrier)
				{
					
					viewForDriverAwarded.Frame = new CGRect(0, 0, viewAwarededShipment.Frame.Width, 100);

					tblAwardedShipment.Frame = new CGRect(0, 50, viewAwarededShipment.Frame.Width, viewAwarededShipment.Frame.Height - 50);


					UILabel lblDriverLabel = new UILabel(new CGRect(20, 0, 80, 50));
					lblDriverLabel.Text = NSBundle.MainBundle.GetLocalizedString("driver", null);
					lblDriverLabel.TextColor = UIColor.Red;
					lblDriverLabel.Font = UIFont.FromName(Constants.strFontName, 14f);
					if (ddlAwradedDriver == null)
					{
						ddlAwradedDriver = new UIButton();
						ddlAwradedDriver.SetTitleColor(UIColor.Black, UIControlState.Normal);
						ddlAwradedDriver.TouchUpInside += delegate
						{
							FilterAwrdedShipment();
						};
						ddlAwradedDriver.Frame = new CGRect(100, 10, 250, 30);
						ddlAwradedDriver.Layer.CornerRadius = 5;
						ddlAwradedDriver.Layer.BorderWidth = 0.5f;
						ddlAwradedDriver.SetTitle("  " + Util.driverList[0], UIControlState.Normal);
					}
					UIImageView imgDownArrow = new UIImageView(new CGRect(330, 18, 15, 15));
					imgDownArrow.Image = new UIImage("Images/DropDown.png");

					viewForDriverAwarded.AddSubviews(lblDriverLabel, ddlAwradedDriver, imgDownArrow);


					lblNoAwardedShipments.Frame = new CGRect(10, 50, viewAwarededShipment.Frame.Width - 10, 30);
					lblNoAwardedShipments.TextColor = UIColor.Red;
					lblNoAwardedShipments.Font = UIFont.FromName(Constants.strFontName, 15f);
					lblNoAwardedShipments.Text = NSBundle.MainBundle.GetLocalizedString("noAwardedShipment", null);
					viewForDriverAwarded.AddSubview(lblNoAwardedShipments);

				}
				else
				{
					
					if (lstAwardedShipents.Count == 0)
					{
						viewForDriverAwarded.Frame = new CGRect(0, 0, viewAwarededShipment.Frame.Width, 50);
						lblNoAwardedShipments.Frame = new CGRect(10, 10, viewAwarededShipment.Frame.Width - 10, 30);
						lblNoAwardedShipments.TextColor = UIColor.Red;
						lblNoAwardedShipments.Font = UIFont.FromName(Constants.strFontName, 15f);
						lblNoAwardedShipments.Text = NSBundle.MainBundle.GetLocalizedString("noAwardedShipment", null);
						viewForDriverAwarded.AddSubview(lblNoAwardedShipments);

						tblAwardedShipment.Frame = new CGRect(0, 50, viewAwarededShipment.Frame.Width, viewAwarededShipment.Frame.Height - viewForDriverAwarded.Frame.Height);
					}
					else
					{
						viewForDriverAwarded.Frame = new CGRect(0, 0, viewAwarededShipment.Frame.Width, 0);
						tblAwardedShipment.Frame = new CGRect(0, 0, viewAwarededShipment.Frame.Width, viewAwarededShipment.Frame.Height);
					}

				}
				viewAwarededShipment.AddSubviews(viewForDriverAwarded, tblAwardedShipment);
				if (!string.IsNullOrEmpty(awardedShipments) && awardedShipments.Trim() != "[]")
				{
					string strUserID = CommanUtil.userID;
					tblAwardedShipment.Hidden = false;
                    if (selectedValueAwarded.Trim() == NSBundle.MainBundle.GetLocalizedString("myself", null))
					{
						List<AwardedShipments> tempAwardedShipments = new List<AwardedShipments>();
						foreach (var awardedShipment in lstAwardedShipents)
						{
							if (awardedShipment.DriverID.ToUpper() == strUserID.ToUpper())
							{
								AwardedShipments objAwarded = new AwardedShipments();
								objAwarded = awardedShipment;
								tempAwardedShipments.Add(objAwarded);
							}
						}
						if (tempAwardedShipments.Count > 0)
						{
							tblAwardedShipment.Hidden = false;
						}
						else
						{
							tblAwardedShipment.Hidden = true;
						}
						if (tblAwardedShipment.Source != null)
						{
							objAwardedShipmentAdapter.lstAwardedShipments = tempAwardedShipments;
							UIView.PerformWithoutAnimation(delegate
							{
								tblAwardedShipment.TableFooterView = new UIView(CGRect.Empty);
								tblAwardedShipment.BeginUpdates();
								tblAwardedShipment.ReloadSections(NSIndexSet.FromIndex(0), UITableViewRowAnimation.None);
								tblAwardedShipment.EndUpdates();
							});

						}
						else
						{
							objAwardedShipmentAdapter = new AwardedShipmentAdapter(tempAwardedShipments, this);
							tblAwardedShipment.Source = objAwardedShipmentAdapter;
							tblAwardedShipment.ReloadData();
							tblAwardedShipment.AllowsSelection = false;
							tblAwardedShipment.TableFooterView = new UIView(CGRect.Empty);
						}
					}
					else
					{
						if (lstAwardedShipents.Count > 0)
						{
							tblAwardedShipment.Hidden = false;
						}
						else
						{
							tblAwardedShipment.Hidden = true;
						}

						if (tblAwardedShipment.Source != null)
						{
							objAwardedShipmentAdapter.lstAwardedShipments = lstAwardedShipents;
							UIView.PerformWithoutAnimation(delegate
							{
								tblAwardedShipment.TableFooterView = new UIView(CGRect.Empty);
								tblAwardedShipment.BeginUpdates();
								tblAwardedShipment.ReloadSections(NSIndexSet.FromIndex(0), UITableViewRowAnimation.None);
								tblAwardedShipment.EndUpdates();
							});

						}
						else
						{
							objAwardedShipmentAdapter = new AwardedShipmentAdapter(lstAwardedShipents, this);
							tblAwardedShipment.Source = objAwardedShipmentAdapter;
							tblAwardedShipment.ReloadData();
							tblAwardedShipment.AllowsSelection = false;

							tblAwardedShipment.TableFooterView = new UIView(CGRect.Empty);
						}

					}
				}
				else
				{
					
					tblAwardedShipment.Hidden = true;
				}
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}


		/// <summary>
		/// Binding Recent Shipments
		/// </summary>
		public void BindRecentShipments()
		{
			try
			{
				tblRecentShipment.ShowsVerticalScrollIndicator = false;
				lstRecentShipments = (List<RecentShipments>)JsonConvert.DeserializeObject(recentShipments, typeof(List<RecentShipments>));

				if (CommanUtil.ViewAs == Constants.strCarrier)
				{
					viewForDriverRecent.Frame = new CGRect(0, 0, viewRecentShipments.Frame.Width, 100);
					tblRecentShipment.Frame = new CGRect(0, 50, viewRecentShipments.Frame.Width, viewRecentShipments.Frame.Height - 50);
					UILabel lblDriverLabel = new UILabel(new CGRect(20, 0, 80, 50));
					lblDriverLabel.Text = NSBundle.MainBundle.GetLocalizedString("driver", null);
					lblDriverLabel.TextColor = UIColor.Red;
					lblDriverLabel.Font = UIFont.FromName(Constants.strFontName, 14f);
					if (ddlDriverList == null)
					{
						ddlDriverList = new UIButton();
						ddlDriverList.UserInteractionEnabled = true;
						ddlDriverList.Enabled = true;
						ddlDriverList.SetTitleColor(UIColor.Black, UIControlState.Normal);
						//Tap Gesture
						ddlDriverList.TouchUpInside += delegate
						{
							FilterRecentShipment();
						};
						ddlDriverList.Frame = new CGRect(100, 10, 250, 30);
						ddlDriverList.Layer.CornerRadius = 5;
						ddlDriverList.Layer.BorderWidth = 0.5f;
						ddlDriverList.SetTitle("  " + Util.driverList[0], UIControlState.Normal);
					}
					UIImageView imgDownArrow = new UIImageView(new CGRect(330, 18, 15, 15));
					imgDownArrow.Image = new UIImage("Images/DropDown.png");
					viewForDriverRecent.AddSubviews(lblDriverLabel, ddlDriverList, imgDownArrow);
					lblNoRecentShipments.Frame = new CGRect(10, 50, viewRecentShipments.Frame.Width - 10, 30);
					lblNoRecentShipments.TextColor = UIColor.Red;
					lblNoRecentShipments.Font = UIFont.FromName(Constants.strFontName, 15f);
					lblNoRecentShipments.Text = NSBundle.MainBundle.GetLocalizedString("noRecentShipment", null);
					viewForDriverRecent.AddSubview(lblNoRecentShipments);
				}
				else
				{
					if (lstRecentShipments.Count == 0)
					{
						viewForDriverRecent.Frame = new CGRect(0, 0, viewRecentShipments.Frame.Width, 50);
						lblNoRecentShipments.Frame = new CGRect(10, 10, viewRecentShipments.Frame.Width - 10, 30);
						lblNoRecentShipments.TextColor = UIColor.Red;
						lblNoRecentShipments.Font = UIFont.FromName(Constants.strFontName, 15f);
						lblNoRecentShipments.Text = NSBundle.MainBundle.GetLocalizedString("noRecentShipment", null);
						viewForDriverRecent.AddSubview(lblNoRecentShipments);
						tblRecentShipment.Frame = new CGRect(0, 50, viewRecentShipments.Frame.Width, viewRecentShipments.Frame.Height - viewForDriverRecent.Frame.Height);
					}
					else
					{
						viewForDriverRecent.Frame = new CGRect(0, 0, viewRecentShipments.Frame.Width, 0);
						tblRecentShipment.Frame = new CGRect(0, 0, viewRecentShipments.Frame.Width, viewRecentShipments.Frame.Height);
					}
				}
				viewRecentShipments.AddSubviews(viewForDriverRecent, tblRecentShipment);
				if (!string.IsNullOrEmpty(recentShipments) && recentShipments.Trim() != "[]")
				{
					string strUserID = CommanUtil.userID;
					tblRecentShipment.Hidden = false;
					//Bind Shipments
					if (selectedValue.Trim() == NSBundle.MainBundle.GetLocalizedString("myself", null))
					{
						List<RecentShipments> tempRecentShipments = new List<RecentShipments>();
						foreach (RecentShipments recentShipment in lstRecentShipments)
						{
							if (recentShipment.DriverID.ToUpper() == strUserID.ToUpper())
							{
								RecentShipments obgRecent = new RecentShipments();
								obgRecent = recentShipment;
								tempRecentShipments.Add(obgRecent);
							}
						}
						if (tempRecentShipments.Count > 0)
						{
							tblRecentShipment.Hidden = false;
						}
						else
						{
							tblRecentShipment.Hidden = true;
						}

						if (tblRecentShipment.Source != null)
						{
							objRecentShipmentAdapter.lstRecentShipments = tempRecentShipments;
							UIView.PerformWithoutAnimation(delegate
							{
								tblRecentShipment.TableFooterView = new UIView(CGRect.Empty);
								tblRecentShipment.BeginUpdates();
								tblRecentShipment.ReloadSections(NSIndexSet.FromIndex(0), UITableViewRowAnimation.None);
								tblRecentShipment.EndUpdates();
							});
						}
						else
						{
							objRecentShipmentAdapter = new RecentShipmentAdapter(this, tempRecentShipments);
							tblRecentShipment.Source = objRecentShipmentAdapter;
							tblRecentShipment.ReloadData();
							tblRecentShipment.AllowsSelection = false;
							tblRecentShipment.TableFooterView = new UIView(CGRect.Empty);
						}
					}
					else
					{
						List<TrackList> lstTrackList = null;
						string recentShipTrackList = NSUserDefaults.StandardUserDefaults.StringForKey("objTrackList");
						if (!string.IsNullOrEmpty(recentShipTrackList))
						{
							lstTrackList = JsonConvert.DeserializeObject<List<TrackList>>(recentShipTrackList);
						}
						if (lstRecentShipments.Count > 0)
						{
							if (lstTrackList != null)
							{
								if (lstTrackList.Count > 0)
								{
									for (int index = 0; index < lstTrackList.Count; index++)
									{
										RecentShipments objRecentShipments = lstRecentShipments.Where(x => x.BolNum == lstTrackList[index].BolNum).FirstOrDefault();
										if (objRecentShipments == null)
										{
											lstTrackList.Remove(lstTrackList[index]);
										}

									}
									NSUserDefaults.StandardUserDefaults.SetString(JsonConvert.SerializeObject(lstTrackList), "objTrackList");
								}
							}

							foreach (RecentShipments objRecentShipment in lstRecentShipments)
							{
								objRecentShipment.SCAC = Constants.strLiveTrack;

								//updating button text for live tracking 
								if (lstTrackList != null && lstTrackList.Count > 0)
								{
									foreach (TrackList objTrackList in lstTrackList)
									{
										if (objTrackList.BolNum == objRecentShipment.BolNum)
										{
											objRecentShipment.SCAC = Constants.strStopTrack;
											if (CommanUtil.ViewAs == Constants.strCarrier)
											{
												imgBack.Hidden = false;
											}
											else
											{
												imgBack.Hidden = true;
											}
										}
									}
								}
							}
							if (lstRecentShipments.Count > 0)
							{
								tblRecentShipment.Hidden = false;
							}
							else
							{
								tblRecentShipment.Hidden = true;
							}

							if (tblRecentShipment.Source != null)
							{
								objRecentShipmentAdapter.lstRecentShipments = lstRecentShipments;
								UIView.PerformWithoutAnimation(delegate
								{
									tblRecentShipment.TableFooterView = new UIView(CGRect.Empty);
									tblRecentShipment.BeginUpdates();
									tblRecentShipment.ReloadSections(NSIndexSet.FromIndex(0), UITableViewRowAnimation.None);
									tblRecentShipment.EndUpdates();
								});
							}
							else
							{
								objRecentShipmentAdapter = new RecentShipmentAdapter(this, lstRecentShipments);
								tblRecentShipment.Source = objRecentShipmentAdapter;
								tblRecentShipment.ReloadData();
								tblRecentShipment.AllowsSelection = false;

								tblRecentShipment.TableFooterView = new UIView(CGRect.Empty);
							}
						}
						else
						{
							tblRecentShipment.Hidden = true;
						}
					}
				}
				else
				{
					tblRecentShipment.Hidden = true;
				}
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}

        /// <summary>
        /// Filters the recent shipment.
        /// </summary>
		void FilterRecentShipment()
		{
			try
			{
				string strUserID = CommanUtil.userID;
				int yPosition = (int)(View.Frame.Height - 180) / 2;
				UIView pickerParentView = new UIView();
				viewPicker = new UIView(new CGRect(20, yPosition - 100, View.Frame.Width - 40, 210));
				viewPicker.BackgroundColor = UIColor.White;
				viewPicker.Layer.CornerRadius = 10;
				viewPicker.Layer.BorderWidth = 1;
				viewPicker.Layer.BorderColor = UIColor.Black.CGColor;
				pickerView = new UIPickerView(new CGRect(0, 0, viewPicker.Frame.Width, 180));
				pickerView.BackgroundColor = UIColor.White;
				pickerView.ShowSelectionIndicator = true;
				// create our simple picker model
				pickerDataModel = new PickerDataModel(Util.driverList);
				// set it on our picker class
				pickerView.Model = pickerDataModel;
				// Create a 'done' button for the toolbar and add it to the toolbar
				doneButton = new UIButton(new CGRect(0, 180, viewPicker.Frame.Width, 30));
				doneButton.BringSubviewToFront(View);
				doneButton.SetTitle(ConstantsClass.strDone, UIControlState.Normal);
				doneButton.BackgroundColor = ConstantsClass.btnColorRed;
				doneButton.Layer.CornerRadius = 10;
				doneButton.UserInteractionEnabled = true;
				viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });
				pickerDataModel.ValueChanged += (s, e) =>
				{
					//selectedValue = "  " + pickerDataModel.SelectedItem;
				};
				View.Add(viewPicker);
				doneButton.TouchUpInside += (s, e) =>
				{
					selectedValue = "  " + pickerDataModel.SelectedItem;
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
					if (!string.IsNullOrEmpty(selectedValue))
					{
						ddlDriverList.SetTitle(string.Empty, UIControlState.Normal);
						ddlDriverList.TitleLabel.Text = "";
						ddlDriverList.SetTitle(selectedValue, UIControlState.Normal);
					}
					else
					{
						ddlDriverList.SetTitle(string.Empty, UIControlState.Normal);
						ddlDriverList.TitleLabel.Text = "";
						ddlDriverList.SetTitle("  " + Util.driverList[0], UIControlState.Normal);
					}
					if (selectedValue.Trim() == NSBundle.MainBundle.GetLocalizedString("myself", null))
					{
						List<RecentShipments> tempRecentShipments = new List<RecentShipments>();
						foreach (RecentShipments recentShipment in lstRecentShipments)
						{
							if (recentShipment.DriverID.ToUpper() == strUserID.ToUpper())
							{
								RecentShipments obgRecent = new RecentShipments();
								obgRecent = recentShipment;
								tempRecentShipments.Add(obgRecent);
							}
						}
						if (tempRecentShipments.Count > 0)
						{
							tblRecentShipment.Hidden = false;
						}
						else
						{
							tblRecentShipment.Hidden = true;
						}
						objRecentShipmentAdapter = new RecentShipmentAdapter(this, tempRecentShipments);
						tblRecentShipment.Source = objRecentShipmentAdapter;
						tblRecentShipment.ReloadData();
						tblRecentShipment.AllowsSelection = false;
					}
					else
					{
						if (lstRecentShipments.Count > 0)
						{
							tblRecentShipment.Hidden = false;
						}
						else
						{
							tblRecentShipment.Hidden = true;
						}
						objRecentShipmentAdapter = new RecentShipmentAdapter(this, lstRecentShipments);
						tblRecentShipment.Source = objRecentShipmentAdapter;
						tblRecentShipment.ReloadData();
						tblRecentShipment.AllowsSelection = false;
					}
				};
				viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });
				pickerParentView.Frame = View.Frame;
				pickerParentView.BackgroundColor = UIColor.Clear;
				pickerParentView.Add(viewPicker);
				View.Add(pickerParentView);
				var tapGesture = new UITapGestureRecognizer(new Action(delegate
				{
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
				}));
				pickerParentView.AddGestureRecognizer(tapGesture);
			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
				loadPop.Hide();
				return;
			}

		}

        /// <summary>
        /// Filters the awrded shipment.
        /// </summary>
		void FilterAwrdedShipment()
		{
			try
			{
				string strUserID = CommanUtil.userID;
				int yPosition = (int)(View.Frame.Height - 180) / 2;
				UIView pickerParentView = new UIView();
				viewPicker = new UIView(new CGRect(20, yPosition - 100, View.Frame.Width - 40, 210));
				viewPicker.BackgroundColor = UIColor.White;
				viewPicker.Layer.CornerRadius = 10;
				viewPicker.Layer.BorderWidth = 1;
				viewPicker.Layer.BorderColor = UIColor.Black.CGColor;
				pickerView = new UIPickerView(new CGRect(0, 0, viewPicker.Frame.Width, 180));
				pickerView.BackgroundColor = UIColor.White;
				pickerView.ShowSelectionIndicator = true;
				// create our simple picker model
				pickerDataModel = new PickerDataModel(Util.driverList);
				// set it on our picker class
				pickerView.Model = pickerDataModel;
				// Create a 'done' button for the toolbar and add it to the toolbar
				doneButton = new UIButton(new CGRect(0, 180, viewPicker.Frame.Width, 30));
				doneButton.BringSubviewToFront(View);
				doneButton.SetTitle(ConstantsClass.strDone, UIControlState.Normal);
				doneButton.BackgroundColor = ConstantsClass.btnColorRed;
				doneButton.Layer.CornerRadius = 10;
				doneButton.UserInteractionEnabled = true;
				viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });
				pickerDataModel.ValueChanged += (s, e) =>
				{
					//selectedValueAwarded = "  " + pickerDataModel.SelectedItem;
				};
				View.Add(viewPicker);
				doneButton.TouchUpInside += (s, e) =>
				{
					selectedValueAwarded = "  " + pickerDataModel.SelectedItem;
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
					if (!string.IsNullOrEmpty(selectedValueAwarded))
					{
						ddlAwradedDriver.SetTitle(string.Empty, UIControlState.Normal);
						ddlAwradedDriver.TitleLabel.Text = "";
						ddlAwradedDriver.SetTitle(selectedValueAwarded, UIControlState.Normal);
					}
					else
					{
						ddlAwradedDriver.SetTitle(string.Empty, UIControlState.Normal);
						ddlAwradedDriver.TitleLabel.Text = "";
						ddlAwradedDriver.SetTitle("  " + Util.driverList[0], UIControlState.Normal);
					}
					if (selectedValueAwarded.Trim() == NSBundle.MainBundle.GetLocalizedString("myself", null))
					{
						List<AwardedShipments> tempAwardedShipments = new List<AwardedShipments>();
                        if (lstAwardedShipents.Count > 0 && lstAwardedShipents != null)
                        {
                            foreach (var awardedShipment in lstAwardedShipents)
                            {
                                if (awardedShipment.DriverID.ToUpper() == strUserID.ToUpper())
                                {
                                    AwardedShipments objAwarded = new AwardedShipments();
                                    objAwarded = awardedShipment;
                                    tempAwardedShipments.Add(objAwarded);
                                }
                            }
                        }

						if (tempAwardedShipments.Count > 0)
						{
							tblAwardedShipment.Hidden = false;
						}
						else
						{
							tblAwardedShipment.Hidden = true;
						}

						objAwardedShipmentAdapter = new AwardedShipmentAdapter(tempAwardedShipments, this);
						tblAwardedShipment.Source = objAwardedShipmentAdapter;
						tblAwardedShipment.ReloadData();
						tblAwardedShipment.AllowsSelection = false;

						tblAwardedShipment.TableFooterView = new UIView(CGRect.Empty);
					}
					else
					{
						if (lstAwardedShipents.Count > 0)
						{
							tblAwardedShipment.Hidden = false;
						}
						else
						{
							tblAwardedShipment.Hidden = true;
						}
						objAwardedShipmentAdapter = new AwardedShipmentAdapter(lstAwardedShipents, this);
						tblAwardedShipment.Source = objAwardedShipmentAdapter;
						tblAwardedShipment.ReloadData();
						tblAwardedShipment.AllowsSelection = false;

						tblAwardedShipment.TableFooterView = new UIView(CGRect.Empty);
					}
				};
				//viewPickerAddSubviews(new UIView[] { doneButton, pickerView });
				pickerParentView.Frame = View.Frame;
				pickerParentView.BackgroundColor = UIColor.Clear;
				pickerParentView.Add(viewPicker);
				View.Add(pickerParentView);
				var tapGesture = new UITapGestureRecognizer(new Action(delegate
				{
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
				}));
				pickerParentView.AddGestureRecognizer(tapGesture);
			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
				loadPop.Hide();
				return;

			}
		}


		/// <summary>
		/// Segues from dashborad to shipment detail page.
		/// </summary>
		/// <param name="compositeKey">Composite key.</param>
		public void SegueFromDashboradToShipmentDetail(string compositeKey)
		{
			try
			{
                if (!CommanUtil.IsTimeOut())
                {
                    return;
                }

				if (Reachability.InternetConnectionStatus())
				{
					ShipmentDetailController objShipmentDetailController =
						this.Storyboard.InstantiateViewController
						("ShipmentDetailController") as ShipmentDetailController;
					objShipmentDetailController.compositeKey = compositeKey;

					this.NavigationController.PushViewController(objShipmentDetailController, true);
				}
				else
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
					this.View.Add(this.customAlert);
				}

			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}

		}

		/// <summary>
		/// Redirects to map.
		/// </summary>
		/// <param name="addressKey">Address key.</param>
		public void RedirectToMap(string addressKey)
		{
			try
			{

				if (Reachability.InternetConnectionStatus())
				{
					MapController objMapController =
										this.Storyboard.InstantiateViewController
										("MapController") as MapController;
					objMapController.addressKey = addressKey;

					this.NavigationController.PushViewController(objMapController, true);
				}
				else
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
					this.View.Add(this.customAlert);
				}
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}

        /// <summary>
        /// Gos to live tracking.
        /// </summary>
        /// <param name="objRecentShipment">Object recent shipment.</param>
        public void GoToLiveTracking(RecentShipments objRecentShipment)
        {
            try
            {
                if (Reachability.InternetConnectionStatus())
                {
                    LiveTrackingController liveTrackingController =
                                        this.Storyboard.InstantiateViewController
                                        ("LiveTrackingController") as LiveTrackingController;

                    liveTrackingController.recentShipmentDetail = objRecentShipment;
                    //objMapController.addressKey = addressKey;

                    this.NavigationController.PushViewController(liveTrackingController, true);
                }
                else
                {
                    this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
                    this.View.Add(this.customAlert);
                }

            }
            catch
            {
                Console.WriteLine(Constants.strErrorOccured);
            }
        }

		/// <summary>
		/// Redirects to map.
		/// </summary>
		/// <param name="addressKey">Address key.</param>
		public void RedirectToCompareRoute(string addressKey)
		{
			try
			{

                if (Reachability.InternetConnectionStatus())
                {
                    CompareRouteController objCompareRouteController =
                        this.Storyboard.InstantiateViewController
                        ("CompareRouteController") as CompareRouteController;
                    objCompareRouteController.addressKey = addressKey;

                    this.NavigationController.PushViewController(objCompareRouteController, true);
                }
				else
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
					this.View.Add(this.customAlert);
				}
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}


		/// <summary>
		/// Redirects to confirmation.
		/// </summary>
		/// <param name="confiramtionKey">Confirmation type.</param>
		public void RedirectToConfirmation(string confiramtionKey, string proNumber)
		{
			try
			{
				if (Reachability.InternetConnectionStatus())
				{
					if (lstRecentShipments != null)
					{
						PickupAndDeliveryController objPickupAndDeliveryController =
							this.Storyboard.InstantiateViewController
						("PickupAndDeliveryController") as PickupAndDeliveryController;
						objPickupAndDeliveryController.compositeKey = confiramtionKey;
						objPickupAndDeliveryController.proNumber = proNumber;

						this.NavigationController.PushViewController(objPickupAndDeliveryController, true);
					}
					else
					{
						this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Convert.ToString(jobject[Constants.RecentShipments]), true, this, "", 1);
						this.View.Add(this.customAlert);
					}
				}
				else
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
					this.View.Add(this.customAlert);
				}
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Redirects to shipment tracking.
		/// </summary>
		public void RedirectToShipmentTracking(string trackingKey)
		{
			try
			{
				if (Reachability.InternetConnectionStatus())
				{
					ShipmentTrackingController objShipmentTrackingController =
						this.Storyboard.InstantiateViewController
						("ShipmentTrackingController") as ShipmentTrackingController;
					objShipmentTrackingController.compositeKey = trackingKey;
					this.NavigationController.PushViewController(objShipmentTrackingController, true);
				}
				else
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
					this.View.Add(this.customAlert);
				}
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}


		/// <summary>
        /// Stops the live tracking.
        /// </summary>
        /// <param name="recentShipments">Recent shipments.</param>
		public void StopLiveTracking(RecentShipments recentShipments)
		{
			try
			{
				List<TrackList> lstNewTrackList = null;

				string recentShipTrackList = NSUserDefaults.StandardUserDefaults.StringForKey("objTrackList");
				if (recentShipTrackList != "null")
				{
					lstNewTrackList = JsonConvert.DeserializeObject<List<TrackList>>(recentShipTrackList);
				}
				if (lstNewTrackList != null)
				{
					for (int index = 0; index < lstNewTrackList.Count; index++)
					{
						if (lstNewTrackList[index].BolNum == recentShipments.BolNum)
						{
							recentShipments.SCAC = Constants.strLiveTrack;
							lstNewTrackList.Remove(lstNewTrackList[index]);
							if (lstNewTrackList.Count == 0)
							{
								imgBack.Hidden = true;
								CommanUtil.isStopAllTracking = true;
							}
							NSUserDefaults.StandardUserDefaults.SetString(JsonConvert.SerializeObject(lstNewTrackList), "objTrackList");
							break;
						}

					}

					BindRecentShipments();
					//RedirectToDashBoard();
				}
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Redirects to DashBoard.
		/// </summary>
		public void RedirectToDashBoard()
		{
			try
			{
				if (Reachability.InternetConnectionStatus())
				{
					DashboardController objDashboardController =
						this.Storyboard.InstantiateViewController
						("DashboardController") as DashboardController;
					this.NavigationController.PushViewController(objDashboardController, true);
				}
				else
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
					this.View.Add(this.customAlert);
				}
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Stops all tracking.
		/// </summary>
		public void StopAllTracking()
		{
			try
			{
				List<TrackList> lstTrackList = new List<TrackList>();
				NSUserDefaults.StandardUserDefaults.SetString(JsonConvert.SerializeObject(lstTrackList), "objTrackList");
				CommanUtil.isStopAllTracking = true;
				CommanUtil.trackingEnabled = false;
				imgBack.Hidden = true;
				BindRecentShipments();
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}

        /// <summary>
        /// Ises the time out.
        /// </summary>
        /// <returns><c>true</c>, if time out was ised, <c>false</c> otherwise.</returns>
        private  bool IsTimeOut()
        {
            try
            {
                DateTime currentTime = DateTime.Now;
                TimeSpan timespan = currentTime - CommanUtil.loginTime;
                if (timespan.TotalMinutes <= 1)
                {
                    return true;
                }
                else
                {
                    //UIStoryboard board = UIStoryboard.FromName("Main", null);
                    //var dashboardController = (DashboardController)board.InstantiateViewController("DashboardController");
                    //dashboardController.isAllowPooling = false;
                    CommanUtil.stopPooling = true;
                    GetAlertView();
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Gets the alert view.
        /// </summary>
        private  void GetAlertView()
        {
#if __IOS__
            UIAlertView stavAlert = new UIAlertView(Constants.tokenExpired, Constants.reLoginText, null, Constants.btnTextYes, Constants.btnTextNo);
            stavAlert.Show();
            stavAlert.Clicked += async (sender, args) =>
            {
                // check if the user NOT pressed the cancel button
                if (args.ButtonIndex == 0)
                {
                    CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
                    loadPop = new LoadingOverlay(bounds);
                    View.Add(loadPop);
                    stavAlert.Dispose();
                    await RefreshLoginToken();
                    PoolingShipmentInterval();
                    loadPop.Hide();
                }
                if (args.ButtonIndex == 1)
                {
                    UIStoryboard board = UIStoryboard.FromName("Main", null);
                    var loginController = (LoginController)board.InstantiateViewController("LoginController");
                    loginController.logOut = Constants.strlogOut;
                    AppDelegate.NavigationController.PushViewController(loginController, true);
                }
            };
#else
            // FYI won't work on devices prior to Gingerbread 2.3
#endif
        }

        /// <summary>
        /// Refreshs the login token.
        /// </summary>
        private  async Task RefreshLoginToken()
        {
            try
            {
#if __IOS__
                string loginDetails = Foundation.NSUserDefaults.StandardUserDefaults.StringForKey(ConstantsClass.usercredentials);
                if (!string.IsNullOrEmpty(loginDetails))
                {
                    LoginModels notifyLogin = Newtonsoft.Json.JsonConvert.DeserializeObject<LoginModels>(loginDetails);
                    if (notifyLogin.IsRemember)
                    {
                        ServiceHelper objServicehelper = new ServiceHelper();
                        string strResponse = await objServicehelper.PostRequestJson(loginDetails, APIMethods.auth, "", false);
                        if (!string.IsNullOrEmpty(strResponse))
                        {
                            // create json object that holds the api values
                            Newtonsoft.Json.Linq.JObject jobject = Newtonsoft.Json.Linq.JObject.Parse(strResponse);
                            if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
                            {
                                //var versionNumber = NSBundle.MainBundle.InfoDictionary[new NSString("CFBundleVersion")].ToString();
                                //Defining the local storage
                                CommanUtil.tokenNo = Convert.ToString(jobject["Token"]);
                                CommanUtil.loginTime = DateTime.Now;
                                CommanUtil.stopPooling = false;

                            }
                            else
                            {
                                //await Util.ErrorLog(APIMethods.auth, Convert.ToString(jobject[Constants.strErrorMessage]), strToken);
                            }
                        }
                        else
                        {

                        }
                        //await loginController.FnIsPushNotificationLogin(loginDetails);
                    }
                }
                else
                {
                    //Logout functionality
                }
#else
                    // FYI won't work on devices prior to Gingerbread 2.3
#endif
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
	}
}
