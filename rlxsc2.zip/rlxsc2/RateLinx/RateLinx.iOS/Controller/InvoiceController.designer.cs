// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace RateLinx.iOS
{
    [Register ("InvoiceController")]
    partial class InvoiceController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnAddCharge { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnClose { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnCreateInvoice { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnUpload1 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnUpload2 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnUpload3 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIScrollView scrollViewInvoice { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton spinnerCharge { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextView txtAmount { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField txtComment { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel txtDialogHeader { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel txtFileName1 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel txtFileName2 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel txtFileName3 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewAddCharge { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewEnterAmount { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewInvoice { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewInvoiceBottom { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewInvoiceHeader { get; set; }

        [Action ("BtnAddCharge_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnAddCharge_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnClose_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnClose_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnCreateInvoice_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnCreateInvoice_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnUpload1_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnUpload1_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnUpload2_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnUpload2_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnUpload3_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnUpload3_TouchUpInside (UIKit.UIButton sender);

        [Action ("SpinnerCharge_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void SpinnerCharge_TouchUpInside (UIKit.UIButton sender);

        void ReleaseDesignerOutlets ()
        {
            if (btnAddCharge != null) {
                btnAddCharge.Dispose ();
                btnAddCharge = null;
            }

            if (btnClose != null) {
                btnClose.Dispose ();
                btnClose = null;
            }

            if (btnCreateInvoice != null) {
                btnCreateInvoice.Dispose ();
                btnCreateInvoice = null;
            }

            if (btnUpload1 != null) {
                btnUpload1.Dispose ();
                btnUpload1 = null;
            }

            if (btnUpload2 != null) {
                btnUpload2.Dispose ();
                btnUpload2 = null;
            }

            if (btnUpload3 != null) {
                btnUpload3.Dispose ();
                btnUpload3 = null;
            }

            if (scrollViewInvoice != null) {
                scrollViewInvoice.Dispose ();
                scrollViewInvoice = null;
            }

            if (spinnerCharge != null) {
                spinnerCharge.Dispose ();
                spinnerCharge = null;
            }

            if (txtAmount != null) {
                txtAmount.Dispose ();
                txtAmount = null;
            }

            if (txtComment != null) {
                txtComment.Dispose ();
                txtComment = null;
            }

            if (txtDialogHeader != null) {
                txtDialogHeader.Dispose ();
                txtDialogHeader = null;
            }

            if (txtFileName1 != null) {
                txtFileName1.Dispose ();
                txtFileName1 = null;
            }

            if (txtFileName2 != null) {
                txtFileName2.Dispose ();
                txtFileName2 = null;
            }

            if (txtFileName3 != null) {
                txtFileName3.Dispose ();
                txtFileName3 = null;
            }

            if (viewAddCharge != null) {
                viewAddCharge.Dispose ();
                viewAddCharge = null;
            }

            if (viewEnterAmount != null) {
                viewEnterAmount.Dispose ();
                viewEnterAmount = null;
            }

            if (viewInvoice != null) {
                viewInvoice.Dispose ();
                viewInvoice = null;
            }

            if (viewInvoiceBottom != null) {
                viewInvoiceBottom.Dispose ();
                viewInvoiceBottom = null;
            }

            if (viewInvoiceHeader != null) {
                viewInvoiceHeader.Dispose ();
                viewInvoiceHeader = null;
            }
        }
    }
}