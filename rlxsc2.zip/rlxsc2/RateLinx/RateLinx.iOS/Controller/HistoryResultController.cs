using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;
using System.Threading.Tasks;
using RateLinx.APIs;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Collections.Generic;
using RateLinx.Helper;
using CoreGraphics;

namespace RateLinx.iOS
{
	public partial class HistoryResultController : UIViewController
	{


		#region Global Variables
		public string filterQuery = string.Empty;
		string strToken = string.Empty;
		List<RateHistoryColumns> lstRateHistoryColumns = null;
		List<RateHistoryResult> lstHistoryResult = null;  // Declare History Result list
		UIScrollView scrollView;
		List<UIButton> buttons;
		UITapGestureRecognizer tapGesture = null;
		LoadingOverlay loadPop;
		CustomPopup customAlert = null;
		UIImageView imgDetailIndicator;
		UIView menuView;
		#endregion

		/// <summary>
		/// Initializes a new instance of the <see cref="T:RateLinx.iOS.HistoryResultController"/> class.
		/// </summary>
		/// <param name="handle">Handle.</param>
		public HistoryResultController(IntPtr handle) : base(handle)
		{
			
		}
		/// <summary>
		/// Views the did load.
		/// </summary>
		public override async void ViewDidLoad()
		{
			try
			{
				base.ViewDidLoad();
				//scrollViewHeader.AutoresizingMask = UIViewAutoresizing.FlexibleWidth;
				tapGesture = new UITapGestureRecognizer(ManageNavigation);
				imgMenu.AddGestureRecognizer(tapGesture);
				tapGesture = new UITapGestureRecognizer(ManageNavigation);
				imgHome.AddGestureRecognizer(tapGesture);
				imgDetailIndicator = new UIImageView(new CGRect(0,0,0,0));
				View.AddSubview(imgDetailIndicator);
				imgDetailIndicator.Hidden = true;
				tblHistoryResult.Hidden = true;
				viewResultStatus.Hidden = true;
				//scrollViewHeader.Hidden = true;
				viewPaging.Hidden = true;
				viewDivider.Hidden = true;
				//lblRateHistoryHead.TextAlignment = UITextAlignment.Left;
				await BindHistoryResult(filterQuery);
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}

		public override void DidRotate(UIInterfaceOrientation fromInterfaceOrientation)
		{
			if (Util.isMenuVisible)
			{
				if (menuView != null)
				{
					menuView.RemoveFromSuperview();
					menuView = null;
				}
                menuView = new MenuViewController(View).DisplayMenuView(null, null, null, this,null, imgMenu);
				View.AddSubview(menuView);
				menuView.Frame = new CGRect(0, 0, View.Frame.Width, View.Frame.Height);
			}
		}
		public override UIInterfaceOrientationMask GetSupportedInterfaceOrientations()
		{
			return UIInterfaceOrientationMask.Portrait;
		}

		/// <summary>
		/// Binds the history result.
		/// </summary>
		/// <returns>The history result.</returns>
		/// <param name="varFilterQuery">Variable filter query.</param>
		private async Task BindHistoryResult(string varFilterQuery)
		{
			int totalResult = await BindHistoryResult1(1, varFilterQuery);
			try
			{
				if (totalResult != 0)
				{
					viewResultStatus.Hidden = false;
					//scrollViewHeader.Hidden = false;
					viewPaging.Hidden = false;
					viewDivider.Hidden = false;
					int pagingCount = totalResult / 20;
					scrollView = new UIScrollView
					{
						Frame = new CGRect(72, 0, viewPaging.Frame.Width - 72, viewPaging.Frame.Height),
						ContentSize = new CGSize((pagingCount * 27), viewPaging.Frame.Height),
						BackgroundColor = UIColor.White,
						AutoresizingMask = UIViewAutoresizing.FlexibleWidth,
						Bounces = false,
						DirectionalLockEnabled = true
					};
					viewPaging.AddSubview(scrollView);
					int margin = 2;
					buttons = new List<UIButton>();
					if (pagingCount == 0)
					{
						var button = UIButton.FromType(UIButtonType.RoundedRect);
						button.SetTitle("1", UIControlState.Normal);
						button.Frame = new CGRect(margin, 5, 28, 28);
						button.BackgroundColor = UIColor.White;
						button.Tag = 1;
						button.SetTitleColor(UIColor.Blue, UIControlState.Normal);
						button.Layer.BorderWidth = 1;
						button.Layer.CornerRadius = 4;
						button.Layer.BorderColor = UIColor.LightGray.CGColor;
						scrollView.AddSubview(button);
						buttons.Add(button);
					}
					else
					{
						for (int i = 1; i <= pagingCount; i++)
						{

							var button = UIButton.FromType(UIButtonType.RoundedRect);
							button.SetTitle(i.ToString(), UIControlState.Normal);
							button.Frame = new CGRect(margin, 5, 28, 28);
							button.BackgroundColor = UIColor.White;
							button.Tag = i;
							button.SetTitleColor(UIColor.Blue, UIControlState.Normal);
							button.Layer.BorderWidth = 1;
							button.Layer.CornerRadius = 4;
							button.Layer.BorderColor = UIColor.LightGray.CGColor;
							scrollView.AddSubview(button);
							buttons.Add(button);
							margin = margin + 32;
						}
					}
					buttons[0].SetTitleColor(UIColor.Red, UIControlState.Normal);
					foreach (UIButton objButtonPaging in buttons)
					{
						objButtonPaging.TouchUpInside += async delegate
						{
							foreach (UIButton pagingButton in buttons)
							{
								pagingButton.SetTitleColor(UIColor.Blue, UIControlState.Normal);
							}
							objButtonPaging.SetTitleColor(UIColor.Red, UIControlState.Normal);
							await BindHistoryResult1(Convert.ToInt32(objButtonPaging.Tag), filterQuery);
						};
					}
				}
				else
				{
					viewResultStatus.Hidden = false;
					//scrollViewHeader.Hidden = true;
					viewPaging.Hidden = true;
					viewDivider.Hidden = true;

					txtHistoryRecords.Text = Convert.ToString(totalResult) + "  " + NSBundle.MainBundle.GetLocalizedString("resultview", null);
				}
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}


        /// <summary>
        /// Binds the history result1.
        /// </summary>
        /// <returns>The history result1.</returns>
        /// <param name="pageNum">Page number.</param>
        /// <param name="filterQuery">Filter query.</param>
        public async Task<int> BindHistoryResult1(int pageNum, string filterQuery)
        {
            imgDetailIndicator.Frame = new CGRect(View.Frame.Width - 150, 200, 140, 60);
            imgDetailIndicator.Image = UIImage.FromBundle("Images/detailIndicator.png");
            loadPop = null;
            try
            {
                int totalResult = 0;
                if (Reachability.InternetConnectionStatus())
                {
                    CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
                    loadPop = new LoadingOverlay(bounds);
                    string query = string.Empty;
                    strToken = CommanUtil.tokenNo;
                    if (filterQuery != "#")
                    {
                        query = "Page=" + pageNum + "&PerPage=" + 20 + "&" + filterQuery;
                    }
                    else
                    {
                        query = "Page=" + pageNum + "&PerPage=" + 20;
                    }
                    //var filterQuery = "Page=" + pageNum + "&PerPage=20";
                    string uriHistoryResult = APIMethods.getHistoryResult + "?" + query;
                    JObject jobject = null;
                    //Get the service Helper Object
                    var objServicehelper = new ServiceHelper();
                    //Method Name
                    //string methodName = APIMethods.getHistoryResult;
                    View.Add(loadPop);
                    var strResponse = await objServicehelper.GetRequest(strToken, uriHistoryResult, true);
                    if (strResponse != null)
                    {
                        loadPop.Hide();
                        jobject = JObject.Parse(strResponse);
                        if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
                        {
                            string historyResult = Convert.ToString(jobject["Results"]);
                            string rateHistoryColumns = Convert.ToString(jobject["Columns"]);
                            totalResult = Convert.ToInt32(Convert.ToString(jobject["Total"]));
                            if (totalResult != 0)
                            {
                                imgDetailIndicator.Hidden = false;
                                tblHistoryResult.Hidden = false;
                                viewResultStatus.Hidden = false;
                                //scrollViewHeader.Hidden = false;
                                viewPaging.Hidden = false;
                                viewDivider.Hidden = false;
                                //int pagingCount = totalResult / 20;
                                int count = 0;
                                lstHistoryResult = (List<RateHistoryResult>)JsonConvert.DeserializeObject(historyResult, typeof(List<RateHistoryResult>));
                                if (count == 0)
                                {
                                    lstRateHistoryColumns = (List<RateHistoryColumns>)JsonConvert.DeserializeObject(rateHistoryColumns, typeof(List<RateHistoryColumns>));
                                    count++;
                                }
                                int marginBtwCol = 2;
                                int XPosition = 0;
                                foreach (RateHistoryColumns objRateHistoryColumn in lstRateHistoryColumns)
                                {
                                    if (!objRateHistoryColumn.Hidden)
                                    {
                                        UILabel objColumnName = new UILabel();

                                        //objColumnName.Frame = new CGRect(XPosition, 1, 120, viewHistoryResultHeader.Frame.Height);
                                        objColumnName.Text = "  " + objRateHistoryColumn.FieldName;
                                        objColumnName.TextColor = UIColor.White;
                                        objColumnName.BackgroundColor = Constants.historyColumnBGC;
                                        objColumnName.Font = UIFont.FromName(Constants.strFontName, 14.0f);
                                        //viewHistoryResultHeader.AddSubview(objColumnName);
                                        XPosition = XPosition + 120 + marginBtwCol;
                                    }
                                }
                                //viewHistoryData.Frame = new CGRect(0, 0, scrollViewHeader.Frame.Width, scrollViewHeader.Frame.Height);
                                tblHistoryResult.Frame = new CGRect(0, 0, XPosition + 120, lstHistoryResult.Count * 44 + 47);
                                //tblHistoryResult.AllowsSelection = false;
                                tblHistoryResult.Bounces = false;
                                //UIView viewDivider1 = new UIView();
                                //viewDivider1.Frame = new CGRect(0, viewHistoryResultHeader.Frame.Height - 2, XPosition, 2);
                                //viewDivider1.BackgroundColor = UIColor.White;
                                //viewHistoryResultHeader.AddSubview(viewDivider1);
                                scrollViewHistoryResult.ContentSize = new CGSize(XPosition, lstHistoryResult.Count * 44 + 50);
                                scrollViewHistoryResult.DirectionalLockEnabled = true;
                                //viewHistoryResultHeader.Frame = new CGRect(0, 0, XPosition, 47);
                                //scrollViewHeader.AddSubview(viewHistoryData);
                                //viewHistoryData.AddSubview(tblHistoryResult);
                                //viewHistoryData.AddSubview(viewHistoryResultHeader);
                                tblHistoryResult.ContentSize = new CoreGraphics.CGSize(XPosition, lstHistoryResult.Count * 44);
                                tblHistoryResult.AutoresizingMask = UIViewAutoresizing.FlexibleWidth;
                                //tblHistoryResult.ho
                                tblHistoryResult.Source = new HistoryResultAdapter(lstHistoryResult, lstRateHistoryColumns, this);
                                tblHistoryResult.TableFooterView = new UIView(CGRect.Empty);
                                tblHistoryResult.ReloadData();
                                txtHistoryRecords.Text = Convert.ToString(totalResult) + "  " + NSBundle.MainBundle.GetLocalizedString("resultview", null);
                            }
                            else
                            {
                                viewResultStatus.Hidden = false;
                                imgDetailIndicator.Hidden = true;
                                tblHistoryResult.Hidden = true;
                                //scrollViewHeader.Hidden = true;
                                viewPaging.Hidden = true;
                                viewDivider.Hidden = true;
                                txtHistoryRecords.Text = Convert.ToString(totalResult) + "  " + NSBundle.MainBundle.GetLocalizedString("resultview", null);
                            }
                        }
                        else
                        {
                            viewResultStatus.Hidden = false;
                            //scrollViewHeader.Hidden = true;
                            viewPaging.Hidden = true;
                            viewDivider.Hidden = true;
                            txtHistoryRecords.Text = Convert.ToString(totalResult) + "  " + NSBundle.MainBundle.GetLocalizedString("resultview", null);
                        }
                    }
                }
                else
                {
                    this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
                    this.View.Add(this.customAlert);
                }
                return totalResult;
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
                txtHistoryRecords.Text = 0 + "  " + NSBundle.MainBundle.GetLocalizedString("resultview", null);
                return 0;
            }

        }



		/// <summary>
		/// Searchs the history results.
		/// </summary>
		/// <returns>The history results.</returns>
		/// <param name="pageNum">Page number.</param>
		public async Task SearchHistoryResults(int pageNum)
		{
			try
			{
				await BindHistoryResult1(pageNum, filterQuery);
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Manages the navigation.
		/// </summary>
		/// <param name="tapGesture">Tap gesture.</param>
		public void ManageNavigation(UITapGestureRecognizer tapGesture)
		{
			if (tapGesture.View.Equals(imgHome))
			{
				this.PerformSegue("RateHistoryResultToHomeSegue", null);
				//this.NavigationController.PopViewController(true);
			}
			else
			{
				Util.isMenuVisible = true;
                menuView = new MenuViewController(View).DisplayMenuView(null, null, null, this, null,imgMenu);
				View.AddSubview(menuView);

				UIView.Animate(0.3,
				() =>
				{
					if (menuView != null)
					{
						menuView.Frame = new CGRect(0, 0, View.Frame.Width, View.Frame.Height - 20);
					}

				});
				//SidebarController.ToggleMenu();
			}
		}

		/// <summary>
		/// Segues from dashborad to shipment detail page.
		/// </summary>
		/// <param name="compositeKey">Composite key.</param>
		public void SegueFromHistoryToShipmentDetail(string compositeKey)
		{
			try
			{
				ShipmentDetailController objShipmentDetailController =
					this.Storyboard.InstantiateViewController
					("ShipmentDetailController") as ShipmentDetailController;
				objShipmentDetailController.compositeKey = compositeKey;

				this.NavigationController.PushViewController(objShipmentDetailController, true);
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}
	}
}
