// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace RateLinx.iOS
{
    [Register ("EquipmentScanController")]
    partial class EquipmentScanController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnCancel { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnDropCros { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnDropOffScan { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnOtherScan { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnPickupCros { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnPickupScan { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnSave { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgBack { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblCopyRight { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblOtherEquipments { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITableView tblOtherScannedNos { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel txtDropScan { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel txtPickupScan { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewDivider1 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewDivider2 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewEquipmentScan { get; set; }

        [Action ("BtnCancel_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnCancel_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnDropCros_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnDropCros_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnDropOffScan_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnDropOffScan_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnPickupCros_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnPickupCros_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnPickupScan_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnPickupScan_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnSave_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnSave_TouchUpInside (UIKit.UIButton sender);

        void ReleaseDesignerOutlets ()
        {
            if (btnCancel != null) {
                btnCancel.Dispose ();
                btnCancel = null;
            }

            if (btnDropCros != null) {
                btnDropCros.Dispose ();
                btnDropCros = null;
            }

            if (btnDropOffScan != null) {
                btnDropOffScan.Dispose ();
                btnDropOffScan = null;
            }

            if (btnOtherScan != null) {
                btnOtherScan.Dispose ();
                btnOtherScan = null;
            }

            if (btnPickupCros != null) {
                btnPickupCros.Dispose ();
                btnPickupCros = null;
            }

            if (btnPickupScan != null) {
                btnPickupScan.Dispose ();
                btnPickupScan = null;
            }

            if (btnSave != null) {
                btnSave.Dispose ();
                btnSave = null;
            }

            if (imgBack != null) {
                imgBack.Dispose ();
                imgBack = null;
            }

            if (lblCopyRight != null) {
                lblCopyRight.Dispose ();
                lblCopyRight = null;
            }

            if (lblOtherEquipments != null) {
                lblOtherEquipments.Dispose ();
                lblOtherEquipments = null;
            }

            if (tblOtherScannedNos != null) {
                tblOtherScannedNos.Dispose ();
                tblOtherScannedNos = null;
            }

            if (txtDropScan != null) {
                txtDropScan.Dispose ();
                txtDropScan = null;
            }

            if (txtPickupScan != null) {
                txtPickupScan.Dispose ();
                txtPickupScan = null;
            }

            if (viewDivider1 != null) {
                viewDivider1.Dispose ();
                viewDivider1 = null;
            }

            if (viewDivider2 != null) {
                viewDivider2.Dispose ();
                viewDivider2 = null;
            }

            if (viewEquipmentScan != null) {
                viewEquipmentScan.Dispose ();
                viewEquipmentScan = null;
            }
        }
    }
}