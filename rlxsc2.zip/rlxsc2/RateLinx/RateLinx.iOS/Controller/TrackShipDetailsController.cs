using Foundation;
using System;
using UIKit;
using RateLinx.APIs;
using RateLinx.Models;
using Newtonsoft.Json;
using RateLinx.Helper;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;

namespace RateLinx.iOS
{
	public partial class TrackShipDetailsController : UIViewController
	{
		CarrierShipmentDetails shipmentDetail = null;
		public string compositeKey = string.Empty;
		LoadingOverlay loadPop;
		public string shipmentStatus = string.Empty;
		UIView viewShowHide = new UIView();
		public TrackShipDetailsController(IntPtr handle) : base(handle)
		{
		}
		public async override void ViewDidLoad()
		{
			try
			{
				base.ViewDidLoad();

				viewShowHide.Frame = View.Bounds;
				viewShowHide.BackgroundColor = UIColor.White;
				View.AddSubview(viewShowHide);
				await GetShipmentDetailsAsync();
				lblCopyRight.Text = Util.GetCopyRight();

			}
			catch
			{
			}
		}


		partial void BtnBack_TouchUpInside(UIButton sender)
		{
			NavigationController.PopViewController(true);
		}


		async Task GetShipmentDetailsAsync()
		{
			try
			{
				CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
				if (loadPop == null)
				{
					loadPop = new LoadingOverlay(bounds);
				}
				View.Add(loadPop);
				//Method Name
				//string methodName = APIMethods.shipmentDetails + "/" + compositeKey;
				//Alerts.showBusyLoader(this);
				string shipmentDetails = await Util.BindShipmentDetails(compositeKey);
				//Alerts.HideBusyLoader();
				if (!string.IsNullOrEmpty(shipmentDetails))
				{
					shipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(shipmentDetails);
					BindAddressDetails();
                    if (!string.IsNullOrEmpty(shipmentStatus))
					{
                        lblCurrentStatus.Text = Constants.strCurrentStatus + shipmentStatus;
					}
					else
					{
						lblCurrentStatus.Text = Constants.strCurrentStatus + Constants.shippingNotStart;
					}
				}
				loadPop.Hide();
				viewShowHide.Hidden = true;
				viewShowHide.RemoveFromSuperview();
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
				loadPop.Hide();
			}
		}

		/// <summary>
		/// Binds the address details.
		/// </summary>
		private void BindAddressDetails()
		{
			try
			{
				List<Address> objAddress = new List<Address>();
				objAddress = shipmentDetail.Addresses.ToList();
                lblShipmentNo.Text = string.Format(Constants.trackDetails, shipmentDetail.BolNum);// "Shipment " + shipmentDetail.BolNum + " Details";
				lblPickupOn.Text = Constants.strPickupOn +shipmentDetail.PickupStr;
				lblDeliveryOn.Text = Constants.strDeliveryOn +shipmentDetail.DeliverOnStr;
				if (objAddress != null)
				{
					foreach (var item in objAddress)
					{
						if (item.Type == Constants.strORIGIN)
						{
                            lblOriginPhone.Text = string.Format(Constants.phone, item.Phone);
                            lblOriginEmail.Text = string.Format(Constants.email, item.Email);
                            lblOriginFax.Text = string.Format(Constants.fax, item.Fax);
							lblOriginAddress.Text = item.Company + " ";
							//if (!string.IsNullOrEmpty(item.Attention))
							//{
							//    txtSourceAddress.Text = item.Attention;
							//}
							//else
							//{
							//    txtSourceAddress.Visibility = ViewStates.Gone;
							//}
							//Address
							if (!string.IsNullOrEmpty(item.Address1))
							{
								lblOriginAddress.Text += item.Address1 + " ";
							}
							if (!string.IsNullOrEmpty(item.Address2))
							{
								lblOriginAddress.Text += item.Address2 + " ";
							}
							if (!string.IsNullOrEmpty(item.Address3))
							{
								lblOriginAddress.Text += item.Address3 + " ";
							}
							if (!string.IsNullOrEmpty(item.Address4))
							{
								lblOriginAddress.Text += item.Address4 + " ";
							}
							if (!string.IsNullOrEmpty(item.City))
							{
								// txtSourceAddress.Text = item.City;
								lblOriginAddress.Text += item.City + ", ";
							}
							if (!string.IsNullOrEmpty(item.State))
							{
								// txtSourceAddress.Text += " " + item.State + " " + item.Zip;
								lblOriginAddress.Text += item.State + " " + item.Zip + " " + item.Country;
							}
							//else
							//{
							//    txtSourceAddress.Visibility = ViewStates.Gone;
							//}
						}
						if (item.Type == Constants.strSHIPTO)
						{
                            lblDestinationPhone.Text = string.Format(Constants.phone, item.Phone);
                            lblDestinationEmail.Text = string.Format(Constants.email, item.Email);
                            lblDestinationFax.Text = string.Format(Constants.fax, item.Fax);

							lblDestinationAddress.Text = item.Company + " ";
							//if (!string.IsNullOrEmpty(item.Attention))
							//{
							//    txtDestinationAddress.Text = item.Attention;
							//}
							//else
							//{
							//    txtDestinationAddress.Visibility = ViewStates.Gone;
							//}
							//Address
							if (!string.IsNullOrEmpty(item.Address1))
							{
								lblDestinationAddress.Text += item.Address1 + " ";
							}
							if (!string.IsNullOrEmpty(item.Address2))
							{
								lblDestinationAddress.Text += item.Address2 + " ";
							}
							if (!string.IsNullOrEmpty(item.Address3))
							{
								lblDestinationAddress.Text += item.Address3 + " ";
							}
							if (!string.IsNullOrEmpty(item.Address4))
							{
								lblDestinationAddress.Text += item.Address4 + " ";
							}
							if (!string.IsNullOrEmpty(item.City))
							{
								//txtDestinationAddress.Text += " To " + item.City;
								lblDestinationAddress.Text += item.City + ", ";
							}
							if (!string.IsNullOrEmpty(item.State))
							{
								// txtDestinationAddress.Text += " " + item.State + " " + item.Zip;
								lblDestinationAddress.Text += item.State + " " + item.Zip + " " + item.Country;
							}
							//else
							//{
							//    txtDestinationAddress.Visibility = ViewStates.Gone;
							//}
						}
					}

				}
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}

		}

	}

}