using Foundation;
using System;
using UIKit;
using Google.Maps;
using CoreGraphics;
using CoreLocation;
using RateLinx.GoogleServices;
using System.Threading.Tasks;
using System.Net;
using Newtonsoft.Json;
using RateLinx.Helper;
using System.Linq;
using System.Text;
using Newtonsoft.Json.Linq;
using RateLinx.APIs;
using ToastIOS;

namespace RateLinx.iOS
{
	partial class CompareRouteController : UIViewController
	{
		#region  Variables
		MapView mapView;
		GoogleDirectionClass objRoutes;
		//GeoCodeJSONClass objGeoCodeJSONClass;
		public string addressKey;
		string strSource = string.Empty;
		string strDestination = string.Empty;
		string strGeoCodeURL = string.Empty;
		string strHttpResponse = string.Empty;
		//Code snippet to mark source and destination points
		Location SourceLocation { get; set; }
		Location DestinationLocation { get; set; }
		UITapGestureRecognizer tapGesture;
		CustomPopup customAlert = null;
        bool isAllowInterval = true;
		#endregion

		public CompareRouteController(IntPtr handle) : base(handle)
		{
		}

		/// <summary>
		/// Loads the view.
		/// </summary>
		public override async void LoadView()
		{
			try
			{
				base.LoadView();
				if (Reachability.InternetConnectionStatus())
				{
					tapGesture = new UITapGestureRecognizer(ManageNavigation);
					imgBack.AddGestureRecognizer(tapGesture);

					// Create a GMSCameraPosition that tells the map to display the
					strSource = addressKey.Split('#')[0];
					strDestination = addressKey.Split('#')[1];
					lblBolNo.Text = addressKey.Split('#')[2];
                    //Get Lat and Long from Address
                    await GeocodeToConsoleAsync(strSource, strDestination);

					var camera = CameraPosition.FromCamera(latitude: SourceLocation.lat,
						longitude: SourceLocation.lng,
						zoom: 6);
					mapView = MapView.FromCamera(CGRect.Empty, camera);
					mapView.MyLocationEnabled = true;
					//Sourec
					CLLocationCoordinate2D coord1 = new CLLocationCoordinate2D(SourceLocation.lat, SourceLocation.lng);
					var marker1 = Marker.FromPosition(coord1);
					marker1.Title = string.Format(strSource);
					marker1.Icon = UIImage.FromBundle("Images/MarkerSource.png");
					marker1.Map = mapView;

					//Destination
					CLLocationCoordinate2D coord2 = new CLLocationCoordinate2D(DestinationLocation.lat, DestinationLocation.lng);
					var marker2 = Marker.FromPosition(coord2);
					marker2.Title = string.Format(strDestination);
					marker2.Icon = UIImage.FromBundle("Images/MarkerDest.png");
					marker2.Map = mapView;

					await DrawLineBtwAddress(strSource, strDestination);

					if (objRoutes != null)
					{
						//Draw line by connecting polyline points
						UIColor pathColor = UIColor.Red;
						int intRoutesCount = objRoutes.routes.Count;
						//available routes may be more then one
						for (int intCounter = 0; intCounter < intRoutesCount; intCounter++)
						{
							var path = Google.Maps.Path.FromEncodedPath(objRoutes.routes[intCounter].overview_polyline.points);
							var line = Google.Maps.Polyline.FromPath(path);
							line.StrokeWidth = 3f;
							line.StrokeColor = UIColor.Red;
							line.Geodesic = true; //more curved path
							line.Map = mapView;
						}
					}
					mapView.Frame = compareMapView.Bounds;
					//View = mapView;
					compareMapView.AddSubview(mapView);
					await TrackingInterval();
				}
				else
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
					this.View.Add(this.customAlert);
					return;
				}
			}
            catch(Exception ex)
			{
                Toast.MakeText(ex.Message).SetDuration(Helper.Constants.toastDuration).Show();
			}
		}

        /// <summary>
        /// Dids the rotate.
        /// </summary>
        /// <param name="fromInterfaceOrientation">From interface orientation.</param>
		public override void DidRotate(UIInterfaceOrientation fromInterfaceOrientation)
		{
			base.DidRotate(fromInterfaceOrientation);
			if (!Util.isViewRotated)
			{
				Util.isViewRotated = true;
			}
			else
			{
				Util.isViewRotated = false;
			}
		}

        /// <summary>
        /// Gets the supported interface orientations.
        /// </summary>
        /// <returns>The supported interface orientations.</returns>
		public override UIInterfaceOrientationMask GetSupportedInterfaceOrientations()
		{
			return UIInterfaceOrientationMask.Portrait;
		}
      
        /// <summary>
        /// Geocodes to console async.
        /// </summary>
        /// <returns>The to console async.</returns>
        /// <param name="originAdd">Origin add.</param>
        /// <param name="destinationAdd">Destination add.</param>
        private async Task GeocodeToConsoleAsync(string originAdd, string destinationAdd)
        {
            try
            {
                //mark source point
                CLLocation originCLlocation = new CLLocation();
                CLLocation destinationCLlocation = new CLLocation();
                var geocoder = new CLGeocoder();
                var placeMarkOrigin = geocoder.GeocodeAddressAsync(originAdd);
                await placeMarkOrigin.ContinueWith((addresses) =>
                {
                    foreach (var address in addresses.Result)
                    {
                        originCLlocation = address.Location;
                    }
                });
                if (originCLlocation != null)
                {
                    SourceLocation = new Location() { lat = originCLlocation.Coordinate.Latitude, lng = originCLlocation.Coordinate.Longitude };
                }
                var placeMarkDest = geocoder.GeocodeAddressAsync(destinationAdd);
                await placeMarkDest.ContinueWith((addresses) =>
                {
                    foreach (var address in addresses.Result)
                    {
                        destinationCLlocation = address.Location;
                    }
                });
                if (destinationCLlocation != null)
                {
                    DestinationLocation = new Location() { lat = destinationCLlocation.Coordinate.Latitude, lng = destinationCLlocation.Coordinate.Longitude };
                }
                originCLlocation = null;
                destinationCLlocation = null;
            }
            catch
            {
                throw;
            }
        }

		/// <summary>
		/// Fns the http request.
		/// </summary>
		/// <returns>The http request.</returns>
		/// <param name="strURL">String URL.</param>
		static async Task<string> FnHttpRequest(string strURL)
		{
			try
			{
				WebClient client = new WebClient();
				string strResult;
				try
				{
					strResult = await client.DownloadStringTaskAsync(new Uri(strURL));
				}
				catch
				{
					strResult = "Exception";
				}
				finally
				{
					client.Dispose();
					client = null;
				}
				return strResult;
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Draws the line btw address.
		/// </summary>
		/// <returns>The line btw address.</returns>
		/// <param name="srcLocation">Source location.</param>
		/// <param name="destination">Destination.</param>
		public async Task DrawLineBtwAddress(string srcLocation, string destination)
		{
			try
			{
				string strGoogleDirectionUrl = string.Format(RateLinx.Helper.Constants.strGoogleDirectionUrl, srcLocation, destination);
				strHttpResponse = await FnHttpRequest(strGoogleDirectionUrl);
                if (!string.IsNullOrEmpty(strHttpResponse))
                {
                    objRoutes = JsonConvert.DeserializeObject<GoogleDirectionClass>(strHttpResponse);
                    if (objRoutes.routes != null && objRoutes.routes.Count() > 0)
                    {
                        //Calculation of kilometer and miles
                        //double mile;
                        string distance = objRoutes.routes.Select(m => m.legs.Select(len => len.distance.text).FirstOrDefault()).FirstOrDefault();
                        //mile = Convert.ToDouble(distance.Split(' ')[0]);
                        lblOptimalRoute.Text = RateLinx.Helper.Constants.strOptimalRout + distance.Split(' ')[0] + RateLinx.Helper.Constants.mile;
                        lblCarrierRoute.Text = RateLinx.Helper.Constants.strCarrierRoute + "0" + RateLinx.Helper.Constants.mile;
                    }
                }
                else
                {
                    lblOptimalRoute.Text = "";//RateLinx.Helper.Constants.strOptimalRout +"0" RateLinx.Helper.Constants.mile;
                    lblCarrierRoute.Text = "";//RateLinx.Helper.Constants.strCarrierRoute + "0" + RateLinx.Helper.Constants.mile;
                }
				//km = mile * 1.609344;
				//string Percentage = Math.Round(km, 1).ToString();

			}
			catch
			{
				throw;
			}
		}

        /// <summary>
        /// Views the did disappear.
        /// </summary>
        /// <param name="animated">If set to <c>true</c> animated.</param>
        public override void ViewDidDisappear(bool animated)
        {
            isAllowInterval = false;
            base.ViewDidDisappear(animated);
        }

        /// <summary>
        /// Trackings the shipment in an interval.
        /// </summary>
        /// <returns>The interval.</returns>
        public async Task TrackingInterval()
		{
            try
            {
                while (isAllowInterval)
                {
                    await CalCarrierRoute();
                    await Task.Delay(ConstantsClass.delay);
                }
            }
            catch(Exception ex)
            {
                isAllowInterval = false;
                Toast.MakeText(ex.Message).SetDuration(Helper.Constants.toastDuration).Show();
            }
		}

        /// <summary>
        /// Calculate the carrier route.
        /// </summary>
        /// <returns>The carrier route.</returns>
		public async Task CalCarrierRoute()
		{
			try
			{
				ServiceHelper objHelper = new ServiceHelper();
				JObject jobject;
				string methodName = "shipment/trackingposition?id=" + lblBolNo.Text;
				string response = await objHelper.GetRequest(CommanUtil.tokenNo, methodName, true);
				if (!string.IsNullOrEmpty(response))
				{
					jobject = JObject.Parse(response);
					if (string.IsNullOrEmpty(Convert.ToString(jobject[RateLinx.Helper.Constants.strErrorMessage])))
					{
						Models.TrackShipment trackingDetail = JsonConvert.DeserializeObject<Models.TrackShipment>(response);
						if (!string.IsNullOrEmpty(trackingDetail.ShipmentPos[0].ErrorMsg))
						{
							//Toast.MakeText(this, trackingDetail.ShipmentPos[0].ErrorMsg, ToastLength.Long).Show();
							return;
						}
						else
						{
							//Get the details of shipment and trying to show in map
							for (int index = 0; index < trackingDetail.ShipmentPos.Count; index++)
							{
								string city, Country, State = string.Empty;
								if (trackingDetail.ShipmentPos[index].Positions[index] != null)
								{
									city = trackingDetail.ShipmentPos[index].Positions[index].City;
									State = trackingDetail.ShipmentPos[index].Positions[index].State;
									Country = trackingDetail.ShipmentPos[index].Positions[index].Country;
									strDestination = city + " " + State + " " + Country;
								}
								else
								{
									strDestination = string.Empty;
								}
								if (strDestination != null)
								{
									string strFullDirectionURL = string.Format(RateLinx.Helper.Constants.strGoogleDirectionUrl, strSource, strDestination);
									string strJSONDirectionResponse = await FnHttpRequest(strFullDirectionURL);
									if (strJSONDirectionResponse != RateLinx.Helper.Constants.strException)
									{
										var objRoutes = JsonConvert.DeserializeObject<GoogleDirectionClass>(strJSONDirectionResponse);
										//objRoutes.routes.Count  --may be more then one 
                                        if (objRoutes.routes !=null && objRoutes.routes.Count > 0)
										{
											//Calculation of miles and Kilometer
											//double mile, km;
											string distance = objRoutes.routes.Select(m => m.legs.Select(len => len.distance.text).FirstOrDefault()).FirstOrDefault();
											//mile = Convert.ToDouble(distance.Split(' ')[0]);
											//km = mile * 1.609344;
											//string optimalRoute = Math.Round(km, 1).ToString();
											lblCarrierRoute.Text = RateLinx.Helper.Constants.strCarrierRoute + distance.Split(' ')[0] + RateLinx.Helper.Constants.mile;
										}
									}
									else
									{
										lblCarrierRoute.Text = RateLinx.Helper.Constants.strCarrierRoute + "0" + RateLinx.Helper.Constants.mile;

										//Toast.MakeText(this, Constants.strUnableToConnect, ToastLength.Short).Show());
									}
								}
								else
								{
									lblCarrierRoute.Text = RateLinx.Helper.Constants.strCarrierRoute + "0" + RateLinx.Helper.Constants.mile;
									//Toast.MakeText(this, GetString(Resource.String.trackLocation), ToastLength.Long).Show();
								}
							}
						}
					}
					else
					{
						lblCarrierRoute.Text = RateLinx.Helper.Constants.strCarrierRoute + "0" + RateLinx.Helper.Constants.mile;
						response = string.Empty;
						//Post Error Logger Request 
						await Util.ErrorLog(RateLinx.Helper.Constants.strLiveTrack, Convert.ToString(jobject[RateLinx.Helper.Constants.strErrorMessage]), CommanUtil.tokenNo);
						//Toast.MakeText(this, Convert.ToString(jobject[Constants.strErrorMessage]), ToastLength.Long).Show();
						return;
					}
				}

			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Manages the navigation.
		/// </summary>
		/// <param name="tapGesture">Tap gesture.</param>
		public void ManageNavigation(UITapGestureRecognizer tapGesture)
		{
			try
			{
				if (tapGesture.View.Equals(imgBack))
				{
					this.NavigationController.PopViewController(true);
					//this.NavigationController.PopViewController(true);
				}
				else
				{

				}
			}
			catch
			{
				throw;
			}
		}
	}
}