// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace RateLinx.iOS
{
    [Register ("OrderHistoryController")]
    partial class OrderHistoryController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnAcceptOrders { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnClear { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnDenyOrders { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnSearchByOrderID { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgHome { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgMenu { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIScrollView scrollViewHistoryResult { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITableView tblHistoryResult { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel txtHistoryRecords { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField txtOrderId { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewDailyOrderSearch { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewLine1 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewLine2 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewPaging { get; set; }

        [Action ("BtnClear_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnClear_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnSearchByOrderID_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnSearchByOrderID_TouchUpInside (UIKit.UIButton sender);

        void ReleaseDesignerOutlets ()
        {
            if (btnAcceptOrders != null) {
                btnAcceptOrders.Dispose ();
                btnAcceptOrders = null;
            }

            if (btnClear != null) {
                btnClear.Dispose ();
                btnClear = null;
            }

            if (btnDenyOrders != null) {
                btnDenyOrders.Dispose ();
                btnDenyOrders = null;
            }

            if (btnSearchByOrderID != null) {
                btnSearchByOrderID.Dispose ();
                btnSearchByOrderID = null;
            }

            if (imgHome != null) {
                imgHome.Dispose ();
                imgHome = null;
            }

            if (imgMenu != null) {
                imgMenu.Dispose ();
                imgMenu = null;
            }

            if (scrollViewHistoryResult != null) {
                scrollViewHistoryResult.Dispose ();
                scrollViewHistoryResult = null;
            }

            if (tblHistoryResult != null) {
                tblHistoryResult.Dispose ();
                tblHistoryResult = null;
            }

            if (txtHistoryRecords != null) {
                txtHistoryRecords.Dispose ();
                txtHistoryRecords = null;
            }

            if (txtOrderId != null) {
                txtOrderId.Dispose ();
                txtOrderId = null;
            }

            if (viewDailyOrderSearch != null) {
                viewDailyOrderSearch.Dispose ();
                viewDailyOrderSearch = null;
            }

            if (viewLine1 != null) {
                viewLine1.Dispose ();
                viewLine1 = null;
            }

            if (viewLine2 != null) {
                viewLine2.Dispose ();
                viewLine2 = null;
            }

            if (viewPaging != null) {
                viewPaging.Dispose ();
                viewPaging = null;
            }
        }
    }
}