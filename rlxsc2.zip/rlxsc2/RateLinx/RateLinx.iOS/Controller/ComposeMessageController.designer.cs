// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace RateLinx.iOS
{
    [Register ("ComposeMessageController")]
    partial class ComposeMessageController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnCancel { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnCloseView { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextView btnSelectedItem { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnSend { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnUpload1 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnUpload2 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnUpload3 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgDropDownicon { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIScrollView scrollViewComposeMsg { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel txtFileName1 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel txtFileName2 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel txtFileName3 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextView txtMessage { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField txtSubject { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewComposeMsgParent { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewMessageContainer { get; set; }

        [Action ("BtnCancel_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnCancel_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnCloseView_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnCloseView_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnSend_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnSend_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnUpload1_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnUpload1_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnUpload2_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnUpload2_TouchUpInside (UIKit.UIButton sender);

        [Action ("BtnUpload3_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnUpload3_TouchUpInside (UIKit.UIButton sender);

        void ReleaseDesignerOutlets ()
        {
            if (btnCancel != null) {
                btnCancel.Dispose ();
                btnCancel = null;
            }

            if (btnCloseView != null) {
                btnCloseView.Dispose ();
                btnCloseView = null;
            }

            if (btnSelectedItem != null) {
                btnSelectedItem.Dispose ();
                btnSelectedItem = null;
            }

            if (btnSend != null) {
                btnSend.Dispose ();
                btnSend = null;
            }

            if (btnUpload1 != null) {
                btnUpload1.Dispose ();
                btnUpload1 = null;
            }

            if (btnUpload2 != null) {
                btnUpload2.Dispose ();
                btnUpload2 = null;
            }

            if (btnUpload3 != null) {
                btnUpload3.Dispose ();
                btnUpload3 = null;
            }

            if (imgDropDownicon != null) {
                imgDropDownicon.Dispose ();
                imgDropDownicon = null;
            }

            if (scrollViewComposeMsg != null) {
                scrollViewComposeMsg.Dispose ();
                scrollViewComposeMsg = null;
            }

            if (txtFileName1 != null) {
                txtFileName1.Dispose ();
                txtFileName1 = null;
            }

            if (txtFileName2 != null) {
                txtFileName2.Dispose ();
                txtFileName2 = null;
            }

            if (txtFileName3 != null) {
                txtFileName3.Dispose ();
                txtFileName3 = null;
            }

            if (txtMessage != null) {
                txtMessage.Dispose ();
                txtMessage = null;
            }

            if (txtSubject != null) {
                txtSubject.Dispose ();
                txtSubject = null;
            }

            if (viewComposeMsgParent != null) {
                viewComposeMsgParent.Dispose ();
                viewComposeMsgParent = null;
            }

            if (viewMessageContainer != null) {
                viewMessageContainer.Dispose ();
                viewMessageContainer = null;
            }
        }
    }
}