// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace RateLinx.iOS
{
    [Register ("LiveTrackingController")]
    partial class LiveTrackingController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnCloseView { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblLiveTrackingText { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewLiveTracking { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewLiveTrackingHeader { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewLiveTrackingOptions { get; set; }

        [Action ("BtnCloseView_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void BtnCloseView_TouchUpInside (UIKit.UIButton sender);

        void ReleaseDesignerOutlets ()
        {
            if (btnCloseView != null) {
                btnCloseView.Dispose ();
                btnCloseView = null;
            }

            if (lblLiveTrackingText != null) {
                lblLiveTrackingText.Dispose ();
                lblLiveTrackingText = null;
            }

            if (viewLiveTracking != null) {
                viewLiveTracking.Dispose ();
                viewLiveTracking = null;
            }

            if (viewLiveTrackingHeader != null) {
                viewLiveTrackingHeader.Dispose ();
                viewLiveTrackingHeader = null;
            }

            if (viewLiveTrackingOptions != null) {
                viewLiveTrackingOptions.Dispose ();
                viewLiveTrackingOptions = null;
            }
        }
    }
}