using Foundation;
using System;
using UIKit;
using CoreGraphics;
using RateLinx.Helper;
using System.Collections.Generic;
using RateLinx.Models;
using Newtonsoft.Json;
using System.Threading.Tasks;
using RateLinx.APIs;
using CoreLocation;
using Newtonsoft.Json.Linq;
using UserNotifications;
using System.Linq;

namespace RateLinx.iOS
{
	public partial class LiveTrackingController : UIViewController
	{

		#region objects and variables declaration
		List<string> liveTrackingElements = null;
		List<string> autoTrackingElements = null;
		public List<TrackList> lstTrackList = null;
		int LiveTracking = 0;
		int AutoTracking = 0;
		RecentShipments objRecentShip = null;
		string recentShipTrackList = string.Empty;
		List<TrackList> lstNewTrackList = null;
		string apiMethod = string.Empty;
		ModalPickerViewController modalPicker = null;
		UIPickerView pickerView = null;
		PickerDataModel pickerDataModel = null;
		UIButton doneButton = null;
		UIView viewPicker = null;
		CustomPopup customAlert = null;
		public RecentShipments recentShipmentDetail;
		UITextView ddlTrackEvery;
		UITextView ddlUpdateEvery;
		UIView viewEnableLiveTracking, viewTrackEvery, viewAutomaticTracking, viewUpdateEvery, viewSaveTracking;
		bool isLiveTracking, isAutomaticUpdate = false;
		UIButton btnCheckLiveTrack, btnCheckTrackUpdate, btnCancel, btnSave;
		UILabel lblEnableTrackText, lblEnableTrackUpdateText, lblTrackEvery, lblUpdateEvery;
		UITapGestureRecognizer tapGestureDDLTrack, tapGestureDDLUpdate;
		string strTrackEvery = string.Empty, strUpdateEvery = string.Empty;
		LoadingOverlay loadPop;
		UIView pickerParentView;
		public CLLocation location = null;
		CLGeocoder geoCoder = null;
		CLPlacemark[] placemarks = null;
		public LocationManager Manager { get; set; }///location

		#endregion

		public LiveTrackingController(IntPtr handle) : base(handle)
		{
			viewEnableLiveTracking = new UIView(CGRect.Empty);
			viewTrackEvery = new UIView(CGRect.Empty);
			viewAutomaticTracking = new UIView(CGRect.Empty);
			viewUpdateEvery = new UIView(CGRect.Empty);
			viewSaveTracking = new UIView(CGRect.Empty);

			btnCheckLiveTrack = new UIButton(CGRect.Empty);
			btnCheckTrackUpdate = new UIButton(CGRect.Empty);
			btnCancel = new UIButton(CGRect.Empty);
			btnSave = new UIButton(CGRect.Empty);
			lblEnableTrackText = new UILabel(CGRect.Empty);
			lblEnableTrackUpdateText = new UILabel(CGRect.Empty);
			lblTrackEvery = new UILabel(CGRect.Empty);
			ddlTrackEvery = new UITextView(CGRect.Empty);
			lblUpdateEvery = new UILabel(CGRect.Empty);
			ddlUpdateEvery = new UITextView(CGRect.Empty);

			Manager = new LocationManager();
		}


		public async override void ViewDidLoad()
		{
			try
			{
				base.ViewDidLoad();

				loadPop = null;
				if (loadPop == null)
				{
					loadPop = new LoadingOverlay(View.Bounds);
				}

				//Hinding Key Board And Popups
				var gesture = new UITapGestureRecognizer(() =>
				{
					if (viewPicker != null)
					{
						viewPicker.Hidden = true;
						pickerView.Hidden = true;
						doneButton.Hidden = true;
					}
					if (modalPicker != null)
					{
						DismissViewController(true, null);
					}
					View.EndEditing(true);
				});
				gesture.CancelsTouchesInView = false;
				View.AddGestureRecognizer(gesture);

				viewLiveTrackingHeader.Frame = new CGRect(0, 0, View.Frame.Width, 50);

				lblLiveTrackingText.Frame = new CGRect(10, 0, View.Frame.Width - 100, 50);
				lblEnableTrackText.Text = "Live Tracking";

				btnCloseView.Frame = new CGRect(View.Frame.Width - 30, 10, 25, 30);

				liveTrackingElements = new List<string>();
				foreach (KeyValuePair<string, string> kvpTrack in CommanUtil.GetLiveTrackingElements())
				{
					liveTrackingElements.Add(kvpTrack.Value);
				}

				autoTrackingElements = new List<string>();
				foreach (KeyValuePair<string, string> kvpTrack in CommanUtil.GetTrackingUpdatesElements())
				{
					autoTrackingElements.Add(kvpTrack.Value);
				}

				if (location == null)
				{
                    location = Manager.LocMgr.Location;
					geoCoder = new CLGeocoder();
					placemarks = await geoCoder.ReverseGeocodeLocationAsync(location);
				}

				CreateLiveTrackingView();
				loadPop.Hide();
				objRecentShip = recentShipmentDetail;

				View.Add(loadPop);
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}


		public override UIInterfaceOrientationMask GetSupportedInterfaceOrientations()
		{
			return UIInterfaceOrientationMask.Portrait;
		}
		public override void DidRotate(UIInterfaceOrientation fromInterfaceOrientation)
		{
			foreach (UIView view in viewLiveTrackingOptions)
			{
				view.RemoveFromSuperview();
			}
            CreateLiveTrackingView();
			if (pickerParentView != null)
			{
				if (!pickerParentView.Hidden)
				{
					pickerParentView.Hidden = true;
					pickerParentView = null;
				}
			}
			//LiveTrackingCheck();
   //         AutomaticTrackingCheck();

		}
		/// <summary>
		/// Bind Live Tracking Spinner or Dropdown
		/// </summary>
		private void FnLiveTrackSpinner(UITextView ddlTrackEvery)
		{
			try
			{

				string selectedValue = string.Empty;
				//int xPosition = (int)(View.Frame.Width - 300) / 2;
				int yPosition = (int)(View.Frame.Height - 180) / 2;
				pickerParentView = new UIView();
				viewPicker = new UIView(new CGRect(20, yPosition - 100, View.Frame.Width - 40, 210));
				viewPicker.BackgroundColor = UIColor.White;
				viewPicker.Layer.CornerRadius = 10;
				viewPicker.Layer.BorderWidth = 1;
				viewPicker.Layer.BorderColor = UIColor.Black.CGColor;
				pickerView = new UIPickerView(new CGRect(0, 0, viewPicker.Frame.Width, 180));
				pickerView.BackgroundColor = UIColor.White;
				pickerView.ShowSelectionIndicator = true;
				// create our simple picker model
				pickerDataModel = new PickerDataModel(liveTrackingElements);
				// set it on our picker class
				pickerView.Model = pickerDataModel;
				// Create a 'done' button for the toolbar and add it to the toolbar
				doneButton = new UIButton(new CGRect(0, 180, viewPicker.Frame.Width, 30));
				doneButton.BringSubviewToFront(View);
				doneButton.SetTitle(ConstantsClass.strDone, UIControlState.Normal);
				doneButton.BackgroundColor = UIColor.FromRGB(137, 18, 50);
				doneButton.Layer.CornerRadius = 10;
				doneButton.UserInteractionEnabled = true;
				viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });
				pickerDataModel.ValueChanged += (s, e) =>
				{
					selectedValue = "  " + pickerDataModel.SelectedItem;
				};
				View.Add(viewPicker);
				doneButton.TouchUpInside += (s, e) =>
				{
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
					if (!string.IsNullOrEmpty(selectedValue))
					{
						ddlTrackEvery.Text = selectedValue;
					}
					else
					{
						ddlTrackEvery.Text = liveTrackingElements[0];
					}
				};
				viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });
				pickerParentView.Frame = View.Frame;
				pickerParentView.BackgroundColor = UIColor.Clear;
				pickerParentView.Add(viewPicker);
				View.Add(pickerParentView);
				var tapGesture = new UITapGestureRecognizer(new Action(delegate
				{
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
				}));
				pickerParentView.AddGestureRecognizer(tapGesture);
			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
			}
		}

		/// <summary>
		/// Binding of Automatic Live Tracking spinner
		/// </summary>
		private void FnAutoTrackSpinner(UITextView ddlUpdateEvery)
		{
			try
			{
				string selectedValue = string.Empty;
				//int xPosition = (int)(View.Frame.Width - 300) / 2;
				int yPosition = (int)(View.Frame.Height - 180) / 2;
				pickerParentView = new UIView();
				viewPicker = new UIView(new CGRect(20, yPosition - 100, View.Frame.Width - 40, 210));
				viewPicker.BackgroundColor = UIColor.White;
				viewPicker.Layer.CornerRadius = 10;
				viewPicker.Layer.BorderWidth = 1;
				viewPicker.Layer.BorderColor = UIColor.Black.CGColor;
				pickerView = new UIPickerView(new CGRect(0, 0, viewPicker.Frame.Width, 180));
				pickerView.BackgroundColor = UIColor.White;
				pickerView.ShowSelectionIndicator = true;
				// create our simple picker mode
				pickerDataModel = new PickerDataModel(autoTrackingElements);
				// set it on our picker class
				pickerView.Model = pickerDataModel;
				// Create a 'done' button for the toolbar and add it to the toolba
				doneButton = new UIButton(new CGRect(0, 180, viewPicker.Frame.Width, 30));
				doneButton.BringSubviewToFront(View);
				doneButton.SetTitle(ConstantsClass.strDone, UIControlState.Normal);
				doneButton.BackgroundColor = ConstantsClass.btnColorRed;
				doneButton.Layer.CornerRadius = 10;
				doneButton.UserInteractionEnabled = true;
				viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });
				pickerDataModel.ValueChanged += (s, e) =>
				{
					selectedValue = "  " + pickerDataModel.SelectedItem;
				};
				View.Add(viewPicker);
				doneButton.TouchUpInside += (s, e) =>
				{
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
					if (!string.IsNullOrEmpty(selectedValue))
					{
						ddlUpdateEvery.Text = selectedValue;
					}
					else
					{
						ddlUpdateEvery.Text = autoTrackingElements[0];
					}
				};
				viewPicker.AddSubviews(new UIView[] { doneButton, pickerView });
				pickerParentView.Frame = View.Frame;
				pickerParentView.BackgroundColor = UIColor.Clear;
				pickerParentView.Add(viewPicker);
				View.Add(pickerParentView);
				var tapGesture = new UITapGestureRecognizer(new Action(delegate
				{
					pickerParentView.Hidden = true;
					pickerParentView.RemoveFromSuperview();
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
				}));
				pickerParentView.AddGestureRecognizer(tapGesture);
			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
			}


		}

		/// <summary>
		/// Buttons the close view touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnCloseView_TouchUpInside(UIButton sender)
		{
			this.NavigationController.PopViewController(true);
		}

		/// <summary>
		/// Creates the live tracking view.
		/// </summary>
		void CreateLiveTrackingView()
		{
			try
			{
				viewEnableLiveTracking = new UIView(CGRect.Empty);
				viewTrackEvery = new UIView(CGRect.Empty);
				viewAutomaticTracking = new UIView(CGRect.Empty);
				viewUpdateEvery = new UIView(CGRect.Empty);
				viewSaveTracking = new UIView(CGRect.Empty);


				viewEnableLiveTracking.Frame = new CGRect(0, 0, View.Frame.Width, 50);
				viewEnableLiveTracking.BackgroundColor = ConstantsClass.viewLiveTracking;
				btnCheckLiveTrack = new UIButton();
				btnCheckLiveTrack.Frame = ConstantsClass.checkLiveTrackingFrmae;
				btnCheckLiveTrack.BackgroundColor = UIColor.White;
				btnCheckLiveTrack.Layer.CornerRadius = 2;
				btnCheckLiveTrack.Layer.BorderWidth = 2;

				btnCheckLiveTrack.TouchUpInside += delegate
							{
								LiveTrackingCheck();
							};

				lblEnableTrackText = new UILabel();

				lblEnableTrackText.Frame = new CGRect(40, 0, View.Frame.Width - 40, 50);
				lblEnableTrackText.Font = UIFont.FromName(Constants.strFontName, 15f);
				lblEnableTrackText.Text = NSBundle.MainBundle.LocalizedString("enbaleTracking", null);

				viewEnableLiveTracking.AddSubviews(btnCheckLiveTrack, lblEnableTrackText);

				viewAutomaticTracking.Frame = new CGRect(0, 50, View.Frame.Width, 50);
				viewAutomaticTracking.BackgroundColor = ConstantsClass.viewAutomaticTracking;

				btnCheckTrackUpdate = new UIButton();

				btnCheckTrackUpdate.Frame = new CGRect(10, 12, 25, 25);
				btnCheckTrackUpdate.BackgroundColor = UIColor.White;
				btnCheckTrackUpdate.Layer.CornerRadius = 2;
				btnCheckTrackUpdate.Layer.BorderWidth = 2;

				btnCheckTrackUpdate.TouchUpInside += delegate
							{
								AutomaticTrackingCheck();
							};

				lblEnableTrackUpdateText = new UILabel();

				lblEnableTrackUpdateText.Frame = new CGRect(40, 0, View.Frame.Width - 40, 50);
				lblEnableTrackUpdateText.Font = UIFont.FromName(Constants.strFontName, 15f);
				lblEnableTrackUpdateText.Text = NSBundle.MainBundle.LocalizedString("enableAutomatic", null);

				viewAutomaticTracking.AddSubviews(btnCheckTrackUpdate, lblEnableTrackUpdateText);

				viewSaveTracking = new UIView();


				viewSaveTracking.Frame = new CGRect(0, 100, View.Frame.Width, 50);
				viewSaveTracking.BackgroundColor = UIColor.FromRGB(216, 215, 215);

				btnCancel = new UIButton();

				btnCancel.Frame = new CGRect(View.Frame.Width - 110, 10, 100, 30);
				btnCancel.SetTitle(NSBundle.MainBundle.LocalizedString("cancel", null), UIControlState.Normal);
				btnCancel.Font = UIFont.FromName(Constants.strFontName, 15f);
				btnCancel.Layer.CornerRadius = 5;
				btnCancel.BackgroundColor = UIColor.FromRGB(137, 18, 50);
				btnCancel.TouchUpInside += delegate
							{
								this.NavigationController.PopViewController(true);
							};
				btnSave = new UIButton();

				btnSave.Frame = new CGRect(View.Frame.Width - 220, 10, 100, 30);
				btnSave.SetTitle(NSBundle.MainBundle.LocalizedString("save", null), UIControlState.Normal);
				btnSave.Font = UIFont.FromName(Constants.strFontName, 15f);
				btnSave.Layer.CornerRadius = 5;
				btnSave.BackgroundColor = UIColor.FromRGB(137, 18, 50);
				btnSave.UserInteractionEnabled = true;
				btnSave.TouchUpInside += delegate
				{
					SaveTrackingInfo();
				};
				viewSaveTracking.AddSubviews(btnCancel, btnSave);
				viewLiveTrackingOptions.AddSubviews(viewEnableLiveTracking, viewAutomaticTracking, viewSaveTracking, viewTrackEvery, viewUpdateEvery);
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
			}
		}

		void LiveTrackingCheck()
		{
			try
			{
				if (!isLiveTracking)
				{
					btnCheckLiveTrack.SetBackgroundImage(new UIImage("Images/CheckMark.png"), UIControlState.Normal);
					isLiveTracking = true;

					viewAutomaticTracking.RemoveFromSuperview();
					viewSaveTracking.RemoveFromSuperview();
					viewTrackEvery.RemoveFromSuperview();
					viewUpdateEvery.RemoveFromSuperview();

					viewTrackEvery = new UIView();

					viewTrackEvery.Frame = new CGRect(0, 50, View.Frame.Width, 50);
					viewTrackEvery.BackgroundColor = UIColor.FromRGB(236, 234, 234);

					lblTrackEvery = new UILabel();

					lblTrackEvery.Frame = new CGRect(20, 0, View.Frame.Width / 10 * 3, 50);
					lblTrackEvery.Font = UIFont.FromName(Constants.strFontName, 15f);
					lblTrackEvery.Text = NSBundle.MainBundle.LocalizedString("trackEvery", null);

					ddlTrackEvery = new UITextView();

					ddlTrackEvery.Frame = new CGRect(View.Frame.Width / 10 * 3 + 20, 10, View.Frame.Width / 10 * 6, 30);
					ddlTrackEvery.Layer.CornerRadius = 5;
					ddlTrackEvery.Layer.BorderWidth = 0.5f;
					ddlTrackEvery.Text = liveTrackingElements[0];
					ddlTrackEvery.Editable = false;
					strTrackEvery = ddlTrackEvery.Text;
					tapGestureDDLTrack = new UITapGestureRecognizer(new Action(delegate
					{

						SelectOptionForTrack(ddlTrackEvery);
					}));
					ddlTrackEvery.AddGestureRecognizer(tapGestureDDLTrack);

					UIImageView imgDownArrow = new UIImageView(new CGRect(ddlTrackEvery.Frame.X + ddlTrackEvery.Frame.Width - 22, 17, 15, 15));
					imgDownArrow.Image = new UIImage("Images/DropDown.png");



					viewTrackEvery.AddSubviews(lblTrackEvery, ddlTrackEvery, imgDownArrow);

					viewAutomaticTracking = new UIView();

					viewAutomaticTracking.Frame = new CGRect(0, 100, View.Frame.Width, 50);
					viewAutomaticTracking.BackgroundColor = UIColor.FromRGB(216, 215, 215);

					btnCheckTrackUpdate = new UIButton();

					btnCheckTrackUpdate.Frame = new CGRect(10, 12, 25, 25);
					btnCheckTrackUpdate.BackgroundColor = UIColor.White;
					btnCheckTrackUpdate.Layer.CornerRadius = 2;
					btnCheckTrackUpdate.Layer.BorderWidth = 2;
					btnCheckTrackUpdate.SetBackgroundImage(new UIImage("Images/CheckMark.png"), UIControlState.Normal);

					btnCheckTrackUpdate.TouchUpInside += delegate
								{
									AutomaticTrackingCheck();
								};

					lblEnableTrackUpdateText = new UILabel();

					lblEnableTrackUpdateText.Frame = new CGRect(40, 0, View.Frame.Width - 40, 50);
					lblEnableTrackUpdateText.Font = UIFont.FromName(Constants.strFontName, 15f);
					lblEnableTrackUpdateText.Text =NSBundle.MainBundle.LocalizedString("enableAutomatic", null);

					viewAutomaticTracking.AddSubviews(btnCheckTrackUpdate, lblEnableTrackUpdateText);
					if (isAutomaticUpdate)
					{
						viewUpdateEvery = new UIView();

						viewUpdateEvery.Frame = new CGRect(0, 150, View.Frame.Width, 50);
						viewUpdateEvery.BackgroundColor = UIColor.FromRGB(236, 234, 234);

						lblUpdateEvery = new UILabel();

						lblUpdateEvery.Frame = new CGRect(20, 0, View.Frame.Width / 10 * 3, 50);
						lblUpdateEvery.Font = UIFont.FromName(Constants.strFontName, 15f);
						lblUpdateEvery.Text = NSBundle.MainBundle.LocalizedString("updateEvery", null);
						ddlUpdateEvery = new UITextView();
						ddlUpdateEvery.Frame = new CGRect(View.Frame.Width / 10 * 3 + 20, 10, View.Frame.Width / 10 * 6, 30);
						ddlUpdateEvery.Layer.CornerRadius = 5;
						ddlUpdateEvery.Layer.BorderWidth = 0.5f;
						ddlUpdateEvery.Text = NSBundle.MainBundle.LocalizedString("sameAsLive", null);
						strUpdateEvery = ddlUpdateEvery.Text;
						ddlUpdateEvery.Editable = false;

						tapGestureDDLUpdate = new UITapGestureRecognizer(new Action(delegate
						{
							SelectOptionForUpdate(ddlUpdateEvery);
						}));
						ddlUpdateEvery.AddGestureRecognizer(tapGestureDDLUpdate);

						UIImageView imgDropDown = new UIImageView(new CGRect(ddlUpdateEvery.Frame.X + ddlUpdateEvery.Frame.Width - 22, 17, 15, 15));
						imgDropDown.Image = new UIImage("Images/DropDown.png");

						viewUpdateEvery.AddSubviews(lblUpdateEvery, ddlUpdateEvery, imgDropDown);

						viewSaveTracking = new UIView();

						viewSaveTracking.Frame = new CGRect(0, 200, View.Frame.Width, 50);
						viewSaveTracking.BackgroundColor = UIColor.FromRGB(216, 215, 215);

						btnCancel = new UIButton();

						btnCancel.Frame = new CGRect(View.Frame.Width - 110, 10, 100, 30);
						btnCancel.SetTitle(NSBundle.MainBundle.LocalizedString("cancel", null), UIControlState.Normal);
						btnCancel.Font = UIFont.FromName(Constants.strFontName, 15f);
						btnCancel.Layer.CornerRadius = 5;
						btnCancel.BackgroundColor = UIColor.FromRGB(137, 18, 50);
						btnCancel.TouchUpInside += delegate
						{
							this.NavigationController.PopViewController(true);
						};
						btnSave = new UIButton();

						btnSave.Frame = new CGRect(View.Frame.Width - 220, 10, 100, 30);
						btnSave.SetTitle(NSBundle.MainBundle.LocalizedString("save", null), UIControlState.Normal);
						btnSave.Font = UIFont.FromName(Constants.strFontName, 15f);
						btnSave.Layer.CornerRadius = 5;
						btnSave.BackgroundColor = UIColor.FromRGB(137, 18, 50);
						btnSave.UserInteractionEnabled = true;
						btnSave.TouchUpInside += delegate
						{
							SaveTrackingInfo();
						};
						viewSaveTracking.AddSubviews(btnCancel, btnSave);

					}
					else
					{
						btnCheckTrackUpdate.SetBackgroundImage(null, UIControlState.Normal);
						viewSaveTracking = new UIView();

						viewSaveTracking.Frame = new CGRect(0, 150, View.Frame.Width, 50);
						viewSaveTracking.BackgroundColor = UIColor.FromRGB(236, 234, 234);

						btnCancel = new UIButton();

						btnCancel.Frame = new CGRect(View.Frame.Width - 110, 10, 100, 30);
						btnCancel.SetTitle(NSBundle.MainBundle.LocalizedString("cancel", null), UIControlState.Normal);
						btnCancel.Font = UIFont.FromName(Constants.strFontName, 15f);
						btnCancel.Layer.CornerRadius = 5;
						btnCancel.BackgroundColor = UIColor.FromRGB(137, 18, 50);
						btnCancel.TouchUpInside += delegate
						{
							this.NavigationController.PopViewController(true);
						};
						btnSave = new UIButton();

						btnSave.Frame = new CGRect(View.Frame.Width - 220, 10, 100, 30);
						btnSave.SetTitle(NSBundle.MainBundle.LocalizedString("save", null), UIControlState.Normal);
						btnSave.Font = UIFont.FromName(Constants.strFontName, 15f);
						btnSave.Layer.CornerRadius = 5;
						btnSave.BackgroundColor = UIColor.FromRGB(137, 18, 50);
						btnSave.UserInteractionEnabled = true;
						btnSave.TouchUpInside += delegate
						{
							SaveTrackingInfo();
						};
						viewSaveTracking.AddSubviews(btnCancel, btnSave);
					}



					viewLiveTrackingOptions.AddSubviews(viewTrackEvery, viewAutomaticTracking, viewSaveTracking, viewUpdateEvery);
				}
				else
				{
					btnCheckLiveTrack.SetBackgroundImage(null, UIControlState.Normal);
					isLiveTracking = false;



					if (isAutomaticUpdate)
					{
						//viewEnableLiveTracking.RemoveFromSuperview();
						viewTrackEvery.RemoveFromSuperview();

						viewAutomaticTracking.RemoveFromSuperview();
						viewUpdateEvery.RemoveFromSuperview();
						viewSaveTracking.RemoveFromSuperview();

						viewAutomaticTracking = new UIView();

						viewAutomaticTracking.Frame = new CGRect(0, 50, View.Frame.Width, 50);
						viewAutomaticTracking.BackgroundColor = UIColor.FromRGB(236, 234, 234);

						btnCheckTrackUpdate = new UIButton();

						btnCheckTrackUpdate.Frame = new CGRect(10, 12, 25, 25);
						btnCheckTrackUpdate.BackgroundColor = UIColor.White;
						btnCheckTrackUpdate.Layer.CornerRadius = 2;
						btnCheckTrackUpdate.Layer.BorderWidth = 2;
						btnCheckTrackUpdate.SetBackgroundImage(new UIImage("Images/CheckMark.png"), UIControlState.Normal);

						btnCheckTrackUpdate.TouchUpInside += delegate
									{
										AutomaticTrackingCheck();
									};

						lblEnableTrackUpdateText = new UILabel();

						lblEnableTrackUpdateText.Frame = new CGRect(40, 0, View.Frame.Width - 40, 50);
						lblEnableTrackUpdateText.Font = UIFont.FromName(Constants.strFontName, 15f);
						lblEnableTrackUpdateText.Text = NSBundle.MainBundle.LocalizedString("enableAutomatic", null);

						viewAutomaticTracking.AddSubviews(btnCheckTrackUpdate, lblEnableTrackUpdateText);

						viewUpdateEvery = new UIView();

						viewUpdateEvery.Frame = new CGRect(0, 100, View.Frame.Width, 50);
						viewUpdateEvery.BackgroundColor = UIColor.FromRGB(216, 215, 215);

						lblUpdateEvery = new UILabel();

						lblUpdateEvery.Frame = new CGRect(20, 0, View.Frame.Width / 10 * 3, 50);
						lblUpdateEvery.Font = UIFont.FromName(Constants.strFontName, 15f);
						lblUpdateEvery.Text = NSBundle.MainBundle.LocalizedString("updateEvery", null);

						ddlUpdateEvery = new UITextView();

						ddlUpdateEvery.Frame = new CGRect(View.Frame.Width / 10 * 3 + 20, 10, View.Frame.Width / 10 * 6, 30);
						ddlUpdateEvery.Layer.CornerRadius = 5;
						ddlUpdateEvery.Layer.BorderWidth = 0.5f;
						ddlUpdateEvery.Text = autoTrackingElements[0];
						ddlUpdateEvery.Editable = false;
						strUpdateEvery = ddlUpdateEvery.Text;
						tapGestureDDLUpdate = new UITapGestureRecognizer(new Action(delegate
						{
							SelectOptionForUpdate(ddlUpdateEvery);
						}));
						ddlUpdateEvery.AddGestureRecognizer(tapGestureDDLUpdate);

						UIImageView imgDropDown = new UIImageView(new CGRect(ddlUpdateEvery.Frame.X + ddlUpdateEvery.Frame.Width - 22, 17, 15, 15));
						imgDropDown.Image = new UIImage("Images/DropDown.png");

						viewUpdateEvery.AddSubviews(lblUpdateEvery, ddlUpdateEvery, imgDropDown);

						viewSaveTracking = new UIView();

						viewSaveTracking.Frame = new CGRect(0, 150, View.Frame.Width, 50);
						viewSaveTracking.BackgroundColor = UIColor.FromRGB(236, 234, 234);

						btnCancel = new UIButton();

						btnCancel.Frame = new CGRect(View.Frame.Width - 110, 10, 100, 30);
						btnCancel.SetTitle(NSBundle.MainBundle.LocalizedString("cancel", null), UIControlState.Normal);
						btnCancel.Font = UIFont.FromName(Constants.strFontName, 15f);
						btnCancel.Layer.CornerRadius = 5;
						btnCancel.BackgroundColor = UIColor.FromRGB(137, 18, 50);
						btnCancel.TouchUpInside += delegate
						{
							this.NavigationController.PopViewController(true);
						};
						btnSave = new UIButton();

						btnSave.Frame = new CGRect(View.Frame.Width - 220, 10, 100, 30);
						btnSave.SetTitle(NSBundle.MainBundle.LocalizedString("save", null), UIControlState.Normal);
						btnSave.Font = UIFont.FromName(Constants.strFontName, 15f);
						btnSave.Layer.CornerRadius = 5;
						btnSave.BackgroundColor = UIColor.FromRGB(137, 18, 50);
						btnSave.UserInteractionEnabled = true;
						btnSave.TouchUpInside += delegate
						{
							SaveTrackingInfo();
						};


						viewSaveTracking.AddSubviews(btnCancel, btnSave);

						viewLiveTrackingOptions.AddSubviews(viewAutomaticTracking, viewUpdateEvery, viewSaveTracking);

					}
					else
					{
						btnCheckTrackUpdate.SetBackgroundImage(new UIImage("Images/CheckMark.png"), UIControlState.Normal);
						viewEnableLiveTracking.RemoveFromSuperview();
						viewTrackEvery.RemoveFromSuperview();
						viewAutomaticTracking.RemoveFromSuperview();
						viewUpdateEvery.RemoveFromSuperview();
						viewSaveTracking.RemoveFromSuperview();
						CreateLiveTrackingView();
					}

				}
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Selects the option for update.
		/// </summary>
		/// <param name="ddlUpdateEvery">Ddl update every.</param>
		void SelectOptionForUpdate(UITextView ddlUpdateEvery)
		{
			strUpdateEvery = ddlUpdateEvery.Text;
			FnAutoTrackSpinner(ddlUpdateEvery);
			//throw new NotImplementedException();
		}

		void SelectOptionForTrack(UITextView ddlTrackEvery)
		{
			FnLiveTrackSpinner(ddlTrackEvery);
			strTrackEvery = ddlTrackEvery.Text;
			//throw new NotImplementedException();
		}

		public async void SaveTrackingInfo()
		{
			if (Reachability.InternetConnectionStatus())
			{
				if (!isAutomaticUpdate)
					strUpdateEvery = string.Empty;
				if (!isLiveTracking)
					strTrackEvery = string.Empty;
				Console.WriteLine(strTrackEvery + strUpdateEvery);
				if (objRecentShip.SCAC.ToUpper() == Constants.strLiveTrack)
				{
					CommanUtil.isTrackingClicked = true;
					await FnSaveTracking();
				}
				else
				{

					StopTracking();
				}
			}
			else
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
				this.View.Add(this.customAlert);
			}
		}



		/// <summary>
		/// Save Data in API
		/// </summary>
		private async Task FnSaveTracking()
		{

			if (placemarks != null && location !=null)
			{
				recentShipTrackList = string.Empty;
				string trackId = CommanUtil.CompositeKey(objRecentShip.ClientID, objRecentShip.LocID, objRecentShip.BolNum);
				string shipToAddress = objRecentShip.ShipToCity + ", " + objRecentShip.ShipToState + ", " + objRecentShip.ShipToZip;
				FnGetSelectedValue(); //Get Values from selected controls

				if (!isLiveTracking && !isAutomaticUpdate)
				{
					return;
				}
				else
				{
					lstTrackList = new List<TrackList>();
					TrackList objTrackList = new TrackList();
					loadPop = null;
					if (loadPop == null)
					{
						loadPop = new LoadingOverlay(View.Bounds);
					}
					View.Add(loadPop);
					try
					{
						lstNewTrackList = new List<TrackList>();
						recentShipTrackList = NSUserDefaults.StandardUserDefaults.StringForKey("objTrackList");
						if (!string.IsNullOrEmpty(recentShipTrackList))
						{
							
							lstNewTrackList = JsonConvert.DeserializeObject<List<TrackList>>(recentShipTrackList);
							if (lstNewTrackList !=null && lstNewTrackList.Count > 0)
							{
								CommanUtil.isStopAllTracking = false;
								lstTrackList.AddRange(lstNewTrackList);
								objTrackList.BolNum = objRecentShip.BolNum;
								objTrackList.LiveTracking = LiveTracking;
								objTrackList.TrackingUpdate = AutoTracking;
								objTrackList.LD = LiveTracking;
								objTrackList.UD = AutoTracking;
								objTrackList.ProNum = objRecentShip.ProNum;
								objTrackList.trackID = trackId;
								objTrackList.shipToAddress = shipToAddress;
								objTrackList.NotifyInRadius = objRecentShip.NotifyInRadius;
								objTrackList.IsNotificationSent = false;
								lstTrackList.Add(objTrackList);
							}
						}
						if (lstNewTrackList ==null || lstNewTrackList.Count == 0)
						{
							CommanUtil.isStopAllTracking = false;
							objTrackList.BolNum = objRecentShip.BolNum;
							objTrackList.LiveTracking = LiveTracking;
							objTrackList.TrackingUpdate = AutoTracking;
							objTrackList.LD = LiveTracking;
							objTrackList.UD = AutoTracking;
							objTrackList.ProNum = objRecentShip.ProNum;
							objTrackList.trackID = trackId;
							objTrackList.shipToAddress = shipToAddress;
							objTrackList.NotifyInRadius = objRecentShip.NotifyInRadius;
							objTrackList.IsNotificationSent = false;
							lstTrackList.Add(objTrackList);
						}
						CommanUtil.isTrackingOn = true;//Tracking on Flag
						await TrackingInterval();
						loadPop.Hide();
					}
					catch
					{
						loadPop.Hide();
					}

				}
			}
			else
			{
				CommanUtil.isTrackingClicked = false;
				lstNewTrackList = null;
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strEnableTracking, true, this, "", 1);
				this.View.Add(this.customAlert);
				loadPop.Hide();
			}
		}

		/// <summary>
		/// Get Country Details
		/// </summary>
		/// <returns></returns>
		public async Task<List<CountryDetails>> GetCountryDetails()
		{
			try
			{

				List<CountryDetails> lstCountryDetails = null;
				//Get the service Helper Object
				ServiceHelper objServicehelper = new ServiceHelper();
				// create json object that holds the api values
				//Method Name
				string methodName = APIMethods.getCountry;
				CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;

				//Get the Shipments
				var strResponse = await objServicehelper.GetRequest(CommanUtil.tokenNo, methodName, true);
				//loadPop.Hide();
				lstCountryDetails = new List<CountryDetails>();

				if (strResponse != null)
				{
					lstCountryDetails = (List<CountryDetails>)JsonConvert.DeserializeObject(strResponse, typeof(List<CountryDetails>));
				}
				return lstCountryDetails;
			}
			catch
			{
				throw;
			}
		}
		/// <summary>
		/// 
		/// </summary>
		private async Task LiveTrackingInterval()
		{
			location = null;
			location = new CLLocation();
			location = Manager.LocMgr.Location;
			geoCoder = new CLGeocoder();
			if (placemarks == null)
			{
				placemarks = new CLPlacemark[10];
				if (location != null)
				{
					placemarks = await geoCoder.ReverseGeocodeLocationAsync(location);
				}
			}
			else
			{
				if (location != null)
				{
					placemarks = await geoCoder.ReverseGeocodeLocationAsync(location);
				}
			}

			if (placemarks != null && location != null)
			{
				ServiceHelper objServiceHelper = new ServiceHelper();
				string replyResult = string.Empty;
				string jsonReplyRequest = string.Empty;
				lstNewTrackList = new List<TrackList>();
				string country = string.Empty; string state = string.Empty; string city = string.Empty;
				foreach (var placemark in placemarks)
				{
					country = placemark.Country;
					state = placemark.AdministrativeArea;
					city = placemark.Locality;
				}

				List<CountryDetails> lstCountryDetails = new List<CountryDetails>();
				List<StateDetails> lstStateDetails = new List<StateDetails>();

				lstCountryDetails = await GetCountryDetails();

				List<string> lstCountries = new List<string>();
				List<string> lstStates = new List<string>();
				//List<string> lstCountryCodes = new List<string>();
				List<string> lstStateCodes = new List<string>();
				string countryName = string.Empty;
				string stateCode = string.Empty;
				string countryCode = string.Empty;
				string stateName = string.Empty;

				if (lstCountryDetails != null)
				{
					lstCountries = new List<string>();
					foreach (CountryDetails countryDetails in lstCountryDetails)
					{
						lstCountries.Add(countryDetails.Name);
					}
					if (!string.IsNullOrEmpty(country))
					{
						if (lstCountryDetails != null && lstCountryDetails.Count > 0)
						{
							CountryDetails countryDetail = lstCountryDetails.Where(CountryDetails => CountryDetails.Name.ToUpper()
																  .Equals(country.ToUpper())).FirstOrDefault();
							if (countryDetail != null)
							{
								countryName = countryDetail.Code;
							}

						}
					}
					if (!string.IsNullOrEmpty(countryName))
					{
						countryCode = countryName;
					}

					if (!string.IsNullOrEmpty(countryCode))
					{
						country = countryCode;

						for (int indexCountry = 0; indexCountry < lstCountryDetails.Count; indexCountry++)
						{
							if (countryCode.ToUpper().Equals(Convert.ToString(lstCountryDetails[indexCountry].Code.ToUpper())))
							{
								lstStateDetails = lstCountryDetails[indexCountry].States;
							}
						}
					}

					if (lstStateDetails != null && lstStateDetails.Count > 0)
					{
						foreach (StateDetails stateDetails in lstStateDetails)
						{
							lstStates.Add(stateDetails.Name);
							lstStateCodes.Add(stateDetails.Code);

						}
					}

					if (!string.IsNullOrEmpty(state))
					{
						if (lstStates != null && lstStates.Count > 0)
						{
							stateName = lstStates.Where(x => x.ToUpper().Equals(state.ToUpper())).FirstOrDefault();
						}

						if (lstStateCodes != null && lstStateCodes.Count > 0)
						{
							stateCode = lstStateCodes.Where(x => x.ToUpper().Equals(state.ToUpper())).FirstOrDefault();
						}
					}
					if (!string.IsNullOrEmpty(stateCode))
					{
						state = stateCode;
					}
					else
					{ 
						if (!string.IsNullOrEmpty(stateName))
						{
							state = stateName;
						}
					}

				}
				else
				{
					
				}



				if (lstTrackList != null)
				{
					
					lstNewTrackList = lstTrackList;
				}
				try
				{
					if (lstNewTrackList != null && lstNewTrackList.Count > 0 && CommanUtil.ViewAs.ToUpper() == Constants.strCarrier)
					{
						for (int index = 0; index < lstNewTrackList.Count; index++)
						{
							string shipToAddress = lstNewTrackList[index].shipToAddress;
							string shipmentId = lstNewTrackList[index].trackID;
							int notifyInRadius = lstNewTrackList[index].NotifyInRadius;
							bool isNoficationSent = lstNewTrackList[index].IsNotificationSent;

							if (lstNewTrackList[index].LiveTracking != 0)
							{
								lstNewTrackList[index].LD = lstNewTrackList[index].LD - 5;
								if (lstNewTrackList[index].LD == 0)
								{
									lstNewTrackList[index].LD = lstNewTrackList[index].LiveTracking;

									if (location != null)
									{
										apiMethod = APIMethods.Shipment + "/" + lstNewTrackList[index].trackID + "/" + APIMethods.gpsLocation;
										jsonReplyRequest = "{"
											+ "\"Latitude\":" + "\"" + location.Coordinate.Latitude + "\","
											   + "\"Longitude\":" + "\"" + location.Coordinate.Longitude + "\","
											   + "\"Interval\":" + "\"" + lstNewTrackList[index].LiveTracking + "\""
											   + "}";

										replyResult = await objServiceHelper.PostRequestJson(jsonReplyRequest, apiMethod, CommanUtil.tokenNo, true);
										if (replyResult != null)
										{
											var Jobject = JsonConvert.DeserializeObject(replyResult);
											if (Jobject.ToString().ToUpper() == Constants.strSuccess.ToUpper())
											{
												replyResult = Constants.strSuccess;
											}
											else
											{
												CommanUtil.isTrackingClicked = false;
												replyResult = Constants.strException;
												lstNewTrackList = null;
												await Util.ErrorLog(replyResult, replyResult, CommanUtil.tokenNo);
											}
										}
									}
									else
									{
										CommanUtil.isTrackingClicked = false;
										lstNewTrackList = null;
										this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strEnableTracking, true, this, "", 1);
										this.View.Add(this.customAlert);
									}
								}
								if (lstNewTrackList[index].TrackingUpdate != 0)
								{
									lstNewTrackList[index].UD = lstNewTrackList[index].UD - 5;
									if (lstNewTrackList[index].UD == 0)
									{
										lstNewTrackList[index].UD = lstNewTrackList[index].TrackingUpdate;

										if (location != null)
										{
											apiMethod = APIMethods.shipmentDetails + "/" + lstNewTrackList[index].trackID + "/" + APIMethods.tracking;

											//string datetime = DateTime.Now.ToString().Contains("-") ? DateTime.Now.ToString().Replace('-', '/') : DateTime.Now.ToString();

											string date = Convert.ToDateTime(DateTime.Now.ToShortDateString()).ToString("MM/dd/yyyy");

											string newDate = date.Contains("-") ? date.Replace('-', '/') : date;

											string time = DateTime.Now.ToShortTimeString();

											if (state.ToUpper() == "UTTAR PRADESH")
											{
												state = "UP";

											}
											if (country.ToUpper() == "INDIA")
											{
												country = "IN";
											}

											jsonReplyRequest = "{"
												   + "\"ProNumber\":" + "\"" + lstNewTrackList[index].ProNum + "\","
											       + "\"ActivityDate\":" + "\"" + newDate +" " +time + "\","
												   + "\"ActivityCode\":" + "\"" + "X6" + "\","
												   + "\"ActivityDescr\":" + "\"" + "En Route" + "\","
												   + "\"City\":" + "\"" + city + "\","
											       + "\"State\":" + "\"" + state + "\","
												   + "\"Country\":" + "\"" + country
												+ "\"" + "}";
											replyResult = await objServiceHelper.PostRequestJson(jsonReplyRequest, apiMethod, CommanUtil.tokenNo, true);
											if (!string.IsNullOrEmpty(replyResult))
											{
												List<LiveTrack> lstLiveTrack = JsonConvert.DeserializeObject<List<LiveTrack>>(replyResult);
												if (lstLiveTrack[0].Message == null)
												{
													if (loadPop != null)
													{
														loadPop.Hide();
													}
													replyResult = Constants.strSuccess;



														if (UIDevice.CurrentDevice.CheckSystemVersion(10, 0))
														{
															//TODO: Check if this will only work on 10 and up
															UNUserNotificationCenter.Current.RemoveAllDeliveredNotifications();
														}
														else
														{
															UIApplication.SharedApplication.CancelAllLocalNotifications();
														}
														var notification = new UILocalNotification();

														// set the fire date (the date time in which it will fire)
														notification.FireDate = NSDate.Now;

														// configure the alert
														notification.AlertAction = "Alert";
														notification.AlertBody = "You have currently live Tracking enabled!";

														// modify the badge
														notification.ApplicationIconBadgeNumber = 1;

														// set the sound to be the default sound
														notification.SoundName = UILocalNotification.DefaultSoundName;

														// schedule it
														UIApplication.SharedApplication.ScheduleLocalNotification(notification);


												}
												else
												{
													CommanUtil.isTrackingClicked = false;
													replyResult = Constants.strException;
													await Util.ErrorLog(replyResult, replyResult, CommanUtil.tokenNo);
													loadPop.Hide();
												}

											}
										}
										else
										{
											CommanUtil.isTrackingClicked = false;
											lstNewTrackList = null;
											NSUserDefaults.StandardUserDefaults.SetString(JsonConvert.SerializeObject(null), "objTrackList");
											this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strEnableTracking, true, this, "", 1);
											this.View.Add(this.customAlert);
											loadPop.Hide();
										}
									}

								}
							}
						}
						if (CommanUtil.isTrackingClicked == true)
						{
							NSUserDefaults.StandardUserDefaults.SetString(JsonConvert.SerializeObject(lstTrackList), "objTrackList");
							loadPop.Hide();
							lstNewTrackList = null;
							CommanUtil.isTrackingClicked = false;
							RedirectToDashBoard();
						}
					}
					if (loadPop != null)
					{
						loadPop.Hide();
					}
				}
				catch
				{
					if (loadPop != null)
					{
						loadPop.Hide();
					}
				}
			}
			else
			{
				CommanUtil.isTrackingClicked = false;
				lstNewTrackList = null;
				//NSUserDefaults.StandardUserDefaults.SetString(JsonConvert.SerializeObject(null), "objTrackList");

				if (!CommanUtil.trackingEnableFromLogin)
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strEnableTracking, true, this, "", 1);
					this.View.Add(this.customAlert);

					if (loadPop != null)
					{

						loadPop.Hide();
					}
				}


			}
		}

		/// <summary>
		/// To initiate Live Tracking interval
		/// </summary>
		public async Task TrackingInterval()
		{
			try
			{
				bool trackInterval = true;
				while (trackInterval)
				{
					if (Reachability.InternetConnectionStatus())
					{
						if (!CommanUtil.isStopAllTracking)
						{
							trackInterval = true;
							await LiveTrackingInterval();
							await Task.Delay(ConstantsClass.trackingDelay);
						}
						else
						{
							trackInterval = false;
						}
					}
				}
			}
			catch
			{
				Console.WriteLine(Constants.strErrorOccured);
			}
		}

		/// <summary>
		/// Redirects to DashBoard.
		/// </summary>
		public void RedirectToDashBoard()
		{
			try
			{
				CommanUtil.trackingEnabled = true;
				this.NavigationController.PopViewController(false);
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Stop Tracking
		/// </summary>
		/// <returns></returns>
		private void StopTracking()
		{
			recentShipTrackList = NSUserDefaults.StandardUserDefaults.StringForKey("objTrackList");

			if (recentShipTrackList != "null" || !string.IsNullOrEmpty(recentShipTrackList))
			{
				lstNewTrackList = JsonConvert.DeserializeObject<List<TrackList>>(recentShipTrackList);
			}
			try
			{
				if (lstNewTrackList != null)
				{
					for (int index = 0; index < lstNewTrackList.Count; index++)
					{
						if (lstNewTrackList[index].BolNum == objRecentShip.BolNum)
						{
							lstNewTrackList.Remove(lstNewTrackList[index]);
							if (lstNewTrackList.Count == 0)
							{
								CommanUtil.isStopAllTracking = true;
								lstNewTrackList = null;
							}
							NSUserDefaults.StandardUserDefaults.SetString(JsonConvert.SerializeObject(lstNewTrackList), "objTrackList");

							break;
						}

					}
				}
			}
			catch
			{
				throw;
			}
		}


		/// <summary>
		/// Get Selected Tracking Details for saving the details
		/// </summary>
		private void FnGetSelectedValue()
		{
			try
			{
				if (!isLiveTracking && !isAutomaticUpdate)
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strTracking, true, this, "", 2);
					this.View.Add(this.customAlert);
					return;
				}
				if (isLiveTracking)
				{
					foreach (KeyValuePair<string, string> kvpLiveTrack in CommanUtil.GetLiveTrackingElements())
					{
						if (strTrackEvery.ToUpper() == kvpLiveTrack.Value.ToUpper())
						{
							LiveTracking = Convert.ToInt32(kvpLiveTrack.Key);
						}
					}
				}
				else
				{
					LiveTracking = 0;
				}
				if (isAutomaticUpdate)
				{
					if (strUpdateEvery.ToUpper() == Constants.strSameTacking.ToUpper())
					{
						AutoTracking = LiveTracking;
					}
					else
					{
						foreach (KeyValuePair<string, string> kvpAutoTrack in CommanUtil.GetLiveTrackingElements())
						{
							if (strUpdateEvery.ToUpper() == kvpAutoTrack.Value.ToUpper())
							{
								AutoTracking = Convert.ToInt32(kvpAutoTrack.Key);
							}
						}
					}
				}
				else
				{
					AutoTracking = 0;
				}
			}
			catch
			{
				throw;
			}
		}

		/// <summary>
		/// Automatics the tracking check.
		/// </summary>
		void AutomaticTrackingCheck()
		{
			try
			{
				if (!isAutomaticUpdate)
				{
					btnCheckTrackUpdate.SetBackgroundImage(new UIImage("Images/CheckMark.png"), UIControlState.Normal);
					isAutomaticUpdate = true;

					if (isLiveTracking)
					{
						viewUpdateEvery.RemoveFromSuperview();
						viewSaveTracking.RemoveFromSuperview();

						viewUpdateEvery = new UIView();

						viewUpdateEvery.Frame = new CGRect(0, 150, View.Frame.Width, 50);
						viewUpdateEvery.BackgroundColor = UIColor.FromRGB(236, 234, 234);

						lblUpdateEvery = new UILabel();

						lblUpdateEvery.Frame = new CGRect(20, 0, View.Frame.Width / 10 * 3, 50);
						lblUpdateEvery.Font = UIFont.FromName(Constants.strFontName, 15f);
						lblUpdateEvery.Text = NSBundle.MainBundle.LocalizedString("updateEvery", null);

						ddlUpdateEvery = new UITextView();

						ddlUpdateEvery.Frame = new CGRect(View.Frame.Width / 10 * 3 + 20, 10, View.Frame.Width / 10 * 6, 30);
						ddlUpdateEvery.Layer.CornerRadius = 5;
						ddlUpdateEvery.Layer.BorderWidth = 0.5f;
						ddlUpdateEvery.Text = NSBundle.MainBundle.LocalizedString("sameAsLive", null);
						strUpdateEvery = ddlUpdateEvery.Text;

						ddlUpdateEvery.Editable = false;

						tapGestureDDLUpdate = new UITapGestureRecognizer(new Action(delegate
						{

							SelectOptionForUpdate(ddlUpdateEvery);
						}));
						ddlUpdateEvery.AddGestureRecognizer(tapGestureDDLUpdate);

						UIImageView imgDropDown = new UIImageView(new CGRect(ddlUpdateEvery.Frame.X + ddlUpdateEvery.Frame.Width - 22, 17, 15, 15));
						imgDropDown.Image = new UIImage("Images/DropDown.png");

						viewUpdateEvery.AddSubviews(lblUpdateEvery, ddlUpdateEvery, imgDropDown);

						viewSaveTracking = new UIView();

						viewSaveTracking.Frame = new CGRect(0, 200, View.Frame.Width, 50);
						viewSaveTracking.BackgroundColor = UIColor.FromRGB(216, 215, 215);

						btnCancel = new UIButton();

						btnCancel.Frame = new CGRect(View.Frame.Width - 110, 10, 100, 30);
						btnCancel.SetTitle(NSBundle.MainBundle.LocalizedString("cancel", null), UIControlState.Normal);
						btnCancel.Font = UIFont.FromName(Constants.strFontName, 15f);
						btnCancel.Layer.CornerRadius = 5;
						btnCancel.BackgroundColor = UIColor.FromRGB(137, 18, 50);
						btnCancel.TouchUpInside += delegate
						{
							this.NavigationController.PopViewController(true);
						};
						btnSave = new UIButton();

						btnSave.Frame = new CGRect(View.Frame.Width - 220, 10, 100, 30);
						btnSave.SetTitle(NSBundle.MainBundle.LocalizedString("save", null), UIControlState.Normal);
						btnSave.Font = UIFont.FromName(Constants.strFontName, 15f);
						btnSave.Layer.CornerRadius = 5;
						btnSave.BackgroundColor = UIColor.FromRGB(137, 18, 50);
						btnSave.UserInteractionEnabled = true;
						btnSave.TouchUpInside += delegate
						{
							SaveTrackingInfo();
						};


						viewSaveTracking.AddSubviews(btnCancel, btnSave);

						viewLiveTrackingOptions.AddSubviews(viewUpdateEvery, viewSaveTracking);

					}
					else
					{
						//viewEnableLiveTracking.RemoveFromSuperview();
						viewTrackEvery.RemoveFromSuperview();
						//viewAutomaticTracking.RemoveFromSuperview();
						viewUpdateEvery.RemoveFromSuperview();
						viewSaveTracking.RemoveFromSuperview();

						viewUpdateEvery = new UIView();

						viewUpdateEvery.Frame = new CGRect(0, 100, View.Frame.Width, 50);
						viewUpdateEvery.BackgroundColor = UIColor.FromRGB(216, 215, 215);

						lblUpdateEvery = new UILabel();

						lblUpdateEvery.Frame = new CGRect(20, 0, View.Frame.Width / 10 * 3, 50);
						lblUpdateEvery.Font = UIFont.FromName(Constants.strFontName, 15f);
						lblUpdateEvery.Text =NSBundle.MainBundle.LocalizedString("updateEvery", null);

						ddlUpdateEvery = new UITextView();

						ddlUpdateEvery.Frame = new CGRect(View.Frame.Width / 10 * 3 + 20, 10, View.Frame.Width / 10 * 6, 30);
						ddlUpdateEvery.Layer.CornerRadius = 5;
						ddlUpdateEvery.Layer.BorderWidth = 0.5f;
						ddlUpdateEvery.Text = autoTrackingElements[0];
						strUpdateEvery = ddlUpdateEvery.Text;

						ddlUpdateEvery.Editable = false;

						tapGestureDDLUpdate = new UITapGestureRecognizer(new Action(delegate
						{
							SelectOptionForUpdate(ddlUpdateEvery);
						}));
						ddlUpdateEvery.AddGestureRecognizer(tapGestureDDLUpdate);

						UIImageView imgDropDown = new UIImageView(new CGRect(ddlUpdateEvery.Frame.X + ddlUpdateEvery.Frame.Width - 22, 17, 15, 15));
						imgDropDown.Image = new UIImage("Images/DropDown.png");

						viewUpdateEvery.AddSubviews(lblUpdateEvery, ddlUpdateEvery, imgDropDown);

						viewSaveTracking = new UIView();

						viewSaveTracking.Frame = new CGRect(0, 150, View.Frame.Width, 50);
						viewSaveTracking.BackgroundColor = UIColor.FromRGB(236, 234, 234);

						btnCancel = new UIButton();

						btnCancel.Frame = new CGRect(View.Frame.Width - 110, 10, 100, 30);
						btnCancel.SetTitle(NSBundle.MainBundle.LocalizedString("cancel", null), UIControlState.Normal);
						btnCancel.Font = UIFont.FromName(Constants.strFontName, 15f);
						btnCancel.Layer.CornerRadius = 5;
						btnCancel.BackgroundColor = UIColor.FromRGB(137, 18, 50);
						btnCancel.TouchUpInside += delegate
						{
							this.NavigationController.PopViewController(true);
						};
						btnSave = new UIButton();

						btnSave.Frame = new CGRect(View.Frame.Width - 220, 10, 100, 30);
						btnSave.SetTitle(NSBundle.MainBundle.LocalizedString("save", null), UIControlState.Normal);
						btnSave.Font = UIFont.FromName(Constants.strFontName, 15f);
						btnSave.Layer.CornerRadius = 5;
						btnSave.BackgroundColor = UIColor.FromRGB(137, 18, 50);

						btnSave.UserInteractionEnabled = true;
						btnSave.TouchUpInside += delegate
						{
							SaveTrackingInfo();
						};

						viewSaveTracking.AddSubviews(btnCancel, btnSave);

						viewLiveTrackingOptions.AddSubviews(viewUpdateEvery, viewSaveTracking);

					}

				}
				else
				{
					btnCheckTrackUpdate.SetBackgroundImage(null, UIControlState.Normal);
					isAutomaticUpdate = false;

					if (isLiveTracking)
					{
						viewUpdateEvery.RemoveFromSuperview();
						viewSaveTracking.RemoveFromSuperview();

						viewSaveTracking = new UIView();

						viewSaveTracking.Frame = new CGRect(0, 150, View.Frame.Width, 50);
						viewSaveTracking.BackgroundColor = UIColor.FromRGB(236, 234, 234);

						btnCancel = new UIButton();

						btnCancel.Frame = new CGRect(View.Frame.Width - 110, 10, 100, 30);
						btnCancel.SetTitle(NSBundle.MainBundle.LocalizedString("cancel", null), UIControlState.Normal);
						btnCancel.Font = UIFont.FromName(Constants.strFontName, 15f);
						btnCancel.Layer.CornerRadius = 5;
						btnCancel.BackgroundColor = UIColor.FromRGB(137, 18, 50);
						btnCancel.TouchUpInside += delegate
						{
							this.NavigationController.PopViewController(true);
						};
						btnSave = new UIButton();

						btnSave.Frame = new CGRect(View.Frame.Width - 220, 10, 100, 30);
						btnSave.SetTitle(NSBundle.MainBundle.LocalizedString("save", null), UIControlState.Normal);
						btnSave.Font = UIFont.FromName(Constants.strFontName, 15f);
						btnSave.Layer.CornerRadius = 5;
						btnSave.BackgroundColor = UIColor.FromRGB(137, 18, 50);

						btnSave.UserInteractionEnabled = true;
						btnSave.TouchUpInside += delegate
						{
							SaveTrackingInfo();
						};

						viewSaveTracking.AddSubviews(btnCancel, btnSave);

						viewLiveTrackingOptions.AddSubviews(viewSaveTracking);

					}
					else
					{
						//viewEnableLiveTracking.RemoveFromSuperview();
						viewTrackEvery.RemoveFromSuperview();
						viewAutomaticTracking.RemoveFromSuperview();
						viewUpdateEvery.RemoveFromSuperview();
						viewSaveTracking.RemoveFromSuperview();
						CreateLiveTrackingView();
					}

				}
			}
			catch
			{
				throw;

			}
		}
	}

}