// WARNING
//
// This file has been generated automatically by Xamarin Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace myapp
{
	[Register ("TeamListController")]
	partial class TeamListController
	{
		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UIButton btnmenu { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblHeader { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITableView tblvwTeamList { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UIView vwHeader { get; set; }

		[Action ("Btnmenu_TouchUpInside:")]
		[GeneratedCode ("iOS Designer", "1.0")]
		partial void Btnmenu_TouchUpInside (UIButton sender);

		void ReleaseDesignerOutlets ()
		{
			if (btnmenu != null) {
				btnmenu.Dispose ();
				btnmenu = null;
			}
			if (lblHeader != null) {
				lblHeader.Dispose ();
				lblHeader = null;
			}
			if (tblvwTeamList != null) {
				tblvwTeamList.Dispose ();
				tblvwTeamList = null;
			}
			if (vwHeader != null) {
				vwHeader.Dispose ();
				vwHeader = null;
			}
		}
	}
}
