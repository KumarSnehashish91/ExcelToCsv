using Foundation;
using System;
using UIKit;
using RateLinx.Helper;
using RateLinx.Models;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using RateLinx.APIs;
using Newtonsoft.Json;
using CoreGraphics;
using System.Linq;
using System.Drawing;

namespace RateLinx.iOS
{
	public partial class ComposeMessageController : UIViewController
	{
		#region Global Variables
		ModalPickerViewController modalPicker = null;
		UIPickerView pickerView = null;
		UIButton doneButton = null;
		UIView viewPicker = null;
		CustomPopup customAlert = null;
		LoadingOverlay loadPop;
		UIImagePickerController imagePicker = null;
		ServiceHelper objServiceHelper = null;
		FileUploadHelper objFileUploadHelper = null;
		CarrierShipmentDetails lstShipmentDetail = null;
		string apiMethod = string.Empty;
		string token = string.Empty;
		string[] fileUri = null;
		List<byte[]> listFileBytes = null;
		JObject jobject = null;
		string jsonFileRequest = string.Empty;
		byte[] bytes = null;
		string fileName = null;
		int fileIndex = 0;
		List<AllowedConversationToList> AllowedConversationToList = null;
		List<ComposeMessage> lstConposeMsg = null;
		int itemCount = 0;
		List<string> composeTo = null;
		string composeToJson = string.Empty;
		string strMessage = string.Empty;
		bool isValidated = true;
		UITapGestureRecognizer tapGestureComposeTo;
		UIToolbar toolbar;
		private nfloat scroll_amount = 0.0f;    // amount to scroll
		#endregion

		public ComposeMessageController(IntPtr handle) : base(handle)
		{

		}

		/// <summary>
		/// Views the did load.
		/// </summary>
		public override void ViewDidLoad()
		{
			try
			{
				base.ViewDidLoad();

				//toolbar to add done button in the keyboard when focusing on text fields

				toolbar = new UIToolbar(new CoreGraphics.CGRect(new nfloat(0.0f), new nfloat(0.0f), this.View.Frame.Size.Width, new nfloat(44.0f)));
			    toolbar.TintColor = UIColor.White;
			    toolbar.BarStyle = UIBarStyle.Black;
			    toolbar.Translucent = true;
				toolbar.Items = new UIBarButtonItem[]{
					 new UIBarButtonItem(UIBarButtonSystemItem.FlexibleSpace),
		 			 new UIBarButtonItem(UIBarButtonSystemItem.Done, delegate {
						if(txtSubject.IsFirstResponder)
						{
							txtSubject.ResignFirstResponder();
						}

						else
						{
							txtMessage.ResignFirstResponder();
						}
					})
				};
				txtSubject.KeyboardAppearance = UIKeyboardAppearance.Default;
				txtSubject.InputAccessoryView = toolbar;

                txtSubject.ShouldChangeCharacters = (UITextField textField, NSRange range, string replacementString) =>
                {
                    var length = textField.Text.Length - range.Length + replacementString.Length;
                    return length <= 200;
                };

				txtSubject.AttributedPlaceholder = new NSAttributedString(
					NSBundle.MainBundle.GetLocalizedString("Subject", null),
					font: UIFont.FromName(Constants.strFontName, 14.0f),
					foregroundColor: UIColor.DarkGray
				);

				txtMessage.KeyboardAppearance = UIKeyboardAppearance.Default;
				txtMessage.InputAccessoryView = toolbar;

               
				DidLoadActivity();
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
				throw;
			}
		}


		public override UIInterfaceOrientationMask GetSupportedInterfaceOrientations()
		{
			return UIInterfaceOrientationMask.Portrait;
		}

		public override void DidRotate(UIInterfaceOrientation fromInterfaceOrientation)
		{
			base.DidRotate(fromInterfaceOrientation);
			if (!Util.isViewRotated)
			{
				Util.isViewRotated = true;
			}
			else
			{
				Util.isViewRotated = false;
			}
		}
		/// <summary>
		/// Dids the load activity.
		/// </summary>
		public void DidLoadActivity()
		{
			try
			{
				btnSelectedItem.Layer.BorderWidth = 0.5f;
				btnSelectedItem.Layer.BorderColor = new CGColor(0, 0, 0);

				txtSubject.Layer.CornerRadius = 5;
				txtSubject.Layer.BorderWidth = 0.5f;
				txtSubject.Layer.BorderColor = new CGColor(0, 0, 0);
				txtSubject.BackgroundColor = UIColor.White;


				txtMessage.Layer.CornerRadius = 5;
				txtMessage.Layer.BorderWidth = 0.5f;
				txtMessage.Layer.BorderColor = new CGColor(0, 0, 0);
				txtMessage.BackgroundColor = UIColor.White;

				btnUpload1.Layer.BorderWidth = 1;
				btnUpload1.Layer.BorderColor = UIColor.Black.CGColor;

				btnUpload2.Layer.BorderWidth = 1;
				btnUpload2.Layer.BorderColor = UIColor.Black.CGColor;

				btnUpload3.Layer.BorderWidth = 1;
				btnUpload3.Layer.BorderColor = UIColor.Black.CGColor;
				listFileBytes = new List<byte[]>();
				listFileBytes.Add(null);
				listFileBytes.Add(null);
				listFileBytes.Add(null);

				fileUri = new string[3];
				token = CommanUtil.tokenNo; //Token No
				composeTo = new List<string>();
				lstConposeMsg = new List<ComposeMessage>();
				FnBindDrivers();
				//Hinding Key Board And Popups
				var gesture = new UITapGestureRecognizer(() =>
				{
					if (viewPicker != null)
					{
						viewPicker.Hidden = true;
						pickerView.Hidden = true;
						doneButton.Hidden = true;
					}
					if (modalPicker != null)
					{
						DismissViewController(true, null);
					}
					View.EndEditing(true);
				});
				gesture.CancelsTouchesInView = false;
				View.AddGestureRecognizer(gesture);
				btnSelectedItem.Layer.CornerRadius = 5;

				NSNotificationCenter.DefaultCenter.AddObserver
				(UIKeyboard.DidShowNotification, KeyBoardUpNotification);
				// Keyboard Down
				NSNotificationCenter.DefaultCenter.AddObserver
				(UIKeyboard.WillHideNotification, KeyBoardDownNotification);

			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
				throw;

			}
		}
		/// <summary>
		/// Function when keyboard is visible
		/// </summary>
		/// <param name="notification">Notification.</param>
		private void KeyBoardUpNotification(NSNotification notification)
		{
			nfloat parentViewheight = View.Frame.Height;
			CGRect notificationBounds = UIKeyboard.BoundsFromNotification(notification);
			if (parentViewheight > 400)
			{
				if (txtMessage.IsFirstResponder)
				{
					if ((viewComposeMsgParent.Frame.Height - viewMessageContainer.Frame.Y) > (notificationBounds.Height + 50))
					{
						scroll_amount = 0;
					}
					else if ((viewComposeMsgParent.Frame.Height - viewMessageContainer.Frame.Y) < (notificationBounds.Height + 50))
					{
						scroll_amount = (notificationBounds.Height + 50) - (viewComposeMsgParent.Frame.Height - viewMessageContainer.Frame.Y);
						scroll_amount += 100;
					}
					else
					{

					}
					ScrollTheView();
				}
				else
				{
					ScrollTheView();
					scroll_amount = 0;
				}
			}

		}
		/// <summary>
		/// Fires when keyboard is dismissed
		/// </summary>
		/// <param name="notification">Notification.</param>
		private void KeyBoardDownNotification(NSNotification notification)
		{
			scroll_amount = 0;
			scrollViewComposeMsg.Frame = new CGRect(0, 20, View.Frame.Width, View.Frame.Height - 20);
		}
		/// <summary>
		/// Function to scroll the view according to the requirement.
		/// </summary>
		public void ScrollTheView()
		{

			UIView.BeginAnimations(string.Empty, System.IntPtr.Zero);
			UIView.SetAnimationDuration(0.3);

			RectangleF frame = (RectangleF)scrollViewComposeMsg.Frame;

			if (scroll_amount != 0)
			{
				frame.Y = -(float)scroll_amount;
			}
			else
			{
				frame.Y = 20;
			}
			scroll_amount = 0.0f;
			scrollViewComposeMsg.Frame = frame;
			UIView.CommitAnimations();
		}
		/// <summary>

		/// Binding drivers list for compose message 
		/// </summary>
		private void FnBindDrivers()
		{
			try
			{
				string shipmentDetails = string.Empty;
				shipmentDetails = NSUserDefaults.StandardUserDefaults.StringForKey("shipmentDetails");
				lstShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(shipmentDetails);
				AllowedConversationToList = lstShipmentDetail.AllowedConversationToList;
				//Carrier
				if (lstShipmentDetail.ViewAs == Constants.strCarrier)
				{
					composeTo.Add(AllowedConversationToList[0].Value);
					btnSelectedItem.Text = AllowedConversationToList[0].Value;
					imgDropDownicon.Hidden = true;
				}
				else
				{ //Customer Login
					btnSelectedItem.Text = NSBundle.MainBundle.LocalizedString("defaultSelection", null);
					imgDropDownicon.Hidden = false;
					tapGestureComposeTo = new UITapGestureRecognizer(new Action(delegate
				{
					BindDriverPopup(AllowedConversationToList);
				}));
					btnSelectedItem.AddGestureRecognizer(tapGestureComposeTo);
				}
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
				throw;
			}
		}

		/// <summary>
		/// Binds the driver popup.
		/// </summary>
		public void BindDriverPopup(List<AllowedConversationToList> AllowedConversationToList)
		{
			try
			{
				ComposeToPopup objComposeToPopup = new ComposeToPopup(View, AllowedConversationToList, btnSelectedItem);

				View.AddSubview(objComposeToPopup.GetPopupScreen());

			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
				throw;
			}
		}

		/// <summary>
		/// Browsers the file.
		/// </summary>
		public void BrowserFile()
		{
			try
			{
				//UIDocumentPickerViewController documentPicker = new UIDocumentPickerViewController();
				imagePicker = new UIImagePickerController();
				imagePicker.SourceType = UIImagePickerControllerSourceType.PhotoLibrary;
				imagePicker.MediaTypes = UIImagePickerController.AvailableMediaTypes(UIImagePickerControllerSourceType.PhotoLibrary);
				imagePicker.FinishedPickingMedia += Handle_FinishedPickingMedia;
				imagePicker.Canceled += Handle_Canceled;
				NavigationController.PresentModalViewController(imagePicker, true);

			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
				throw;
			}
		}

		/// <summary>
		/// Handles the finished picking media.
		/// </summary>
		/// <param name="sender">Sender.</param>
		/// <param name="e">E.</param>
		public void Handle_FinishedPickingMedia(object sender, UIImagePickerMediaPickedEventArgs e)
		{
			try
			{
				if (viewPicker != null)
				{
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
				}
				// determine what was selected, video or image
				bool isImage = false;
				switch (e.Info[UIImagePickerController.MediaType].ToString())
				{
					case "public.image":
						Console.WriteLine(NSBundle.MainBundle.LocalizedString("imageSelected", null));
						isImage = true;
						break;
					case "public.video":
						Console.WriteLine(NSBundle.MainBundle.LocalizedString("videoSelected", null));
						break;
				}
				// get common info (shared between images and video)
				NSUrl referenceURL = e.Info[new NSString("UIImagePickerControllerReferenceURL")] as NSUrl;
				if (referenceURL != null)
				{
					string fileNm = FileUploadHelper.GetFileName(referenceURL.LastPathComponent.ToString());
					// if it was an image, get the other image info
					if (isImage)
					{
						// get the original image
						UIImage originalImage = e.Info[UIImagePickerController.OriginalImage] as UIImage;
						//MediaFile dsds;
						using (var imageData = originalImage.AsJPEG(0.6f))
						{

							bytes = new byte[imageData.Length];
							if (fileIndex == 1)
							{
								txtFileName1.Text = fileNm;
								fileUri[0] = fileNm;
								listFileBytes[0] = bytes;
							}
							else if (fileIndex == 2)
							{
								txtFileName2.Text = fileNm;
								fileUri[1] = fileNm;
								listFileBytes[1] = bytes;
							}
							else if (fileIndex == 3)
							{
								txtFileName3.Text = fileNm;
								fileUri[2] = fileNm;
								listFileBytes[2] = bytes;
							}
							Marshal.Copy(imageData.Bytes, bytes, 0, Convert.ToInt32(imageData.Length));
						}
					}
					else
					{
						// get video url
						NSUrl mediaURL = e.Info[UIImagePickerController.MediaURL] as NSUrl;
						if (mediaURL != null)
						{

						}
					}
					//FileData filedata = await CrossFilePicker.Current.PickFile();
					// dismiss the picker
					//imagePicker.DismissModalViewControllerAnimated(true);
					imagePicker.DismissModalViewController(true);
				}
			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
				loadPop.Hide();
				return;
			}
		}

		/// <summary>
		/// Handles the canceled.
		/// </summary>
		/// <param name="sender">Sender.</param>
		/// <param name="e">E.</param>
		void Handle_Canceled(object sender, EventArgs e)
		{
			imagePicker.DismissModalViewController(true);
		}

		/// <summary>
		/// Buttons the close view touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnCloseView_TouchUpInside(UIButton sender)
		{
			//ConstantsClass.currentTab = 4;
			this.NavigationController.PopViewController(true);
		}

		/// <summary>
		/// Buttons the upload1 touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnUpload1_TouchUpInside(UIButton sender)
		{
			try
			{
				if (viewPicker != null)
				{
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
				}
				fileIndex = 1;
				BrowserFile();
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
				throw;
			}
		}

		/// <summary>
		/// Buttons the upload2 touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnUpload2_TouchUpInside(UIButton sender)
		{
			try
			{
				if (viewPicker != null)
				{
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
				}
				fileIndex = 2;
				BrowserFile();
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
				throw;
			}
		}

		/// <summary>
		/// Buttons the upload3 touch up inside.
		/// </summary>
		/// <param name="sender">Sender.</param>
		partial void BtnUpload3_TouchUpInside(UIButton sender)
		{
			try
			{
				if (viewPicker != null)
				{
					pickerView.Hidden = true;
					pickerView.RemoveFromSuperview();
					doneButton.Hidden = true;
					viewPicker.Hidden = true;
				}
				fileIndex = 3;
				BrowserFile();
			}
			catch
			{
				Console.Write(Constants.strErrorOccured);
				throw;
			}
		}

		/// <summary>
		/// Compose Message
		/// </summary>
		private async void FnsaveComposeMessage()
		{
			try
			{
				CoreGraphics.CGRect bounds = UIScreen.MainScreen.Bounds;
				loadPop = null;
				if (loadPop == null)
				{
					loadPop = new LoadingOverlay(bounds);
				}
				View.Add(loadPop);
				itemCount = AllowedConversationToList.Where(m => m.Action.Equals(true)).Count();
				isValidated = FnIsValidate(); //Validations 
				if (isValidated)
				{
					//  
					if (lstShipmentDetail.ViewAs == Constants.strCustomer && itemCount != 0)
					{
						foreach (AllowedConversationToList item in AllowedConversationToList.Where(m => m.Action.Equals(true)))
						{
							composeTo.Add(item.Key);
						}
					}
					else
					{
						composeTo.RemoveAt(0);
						composeTo.Add(AllowedConversationToList[0].Key);
					}
					composeToJson = JsonConvert.SerializeObject(composeTo);
					await FnSaveFiles();
				}
				else
				{
					this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, strMessage, true, this, "", 1);
					this.View.Add(this.customAlert);
					loadPop.Hide();
				}
				loadPop.Hide();
			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
				loadPop.Hide();
			}
		}

		/// <summary>
		/// Validate Required Fields
		/// </summary>
		/// <returns></returns>
		private bool FnIsValidate()
		{
			try
			{
				isValidated = true;
				if (lstShipmentDetail.ViewAs == Constants.strCustomer && itemCount == 0)
				{
					strMessage = Constants.strBroadCastMsg;
					isValidated = false;
				}
				else if (string.IsNullOrEmpty(txtSubject.Text))
				{
					strMessage = Constants.strSubject;
					isValidated = false;
				}
				else if (string.IsNullOrEmpty(txtMessage.Text))
				{
					strMessage = Constants.strMessage;
					isValidated = false;
				}
				return isValidated;
			}
			catch
			{
				strMessage = Constants.strErrorOccured;
				return false;
			}
		}

		/// <summary>
		/// Save Files If Any File Selected 
		/// </summary>
		/// <returns></returns>
		private async Task FnSaveFiles()
		{
			try
			{
				if (listFileBytes != null)
				{
					//File Will be upload
					for (int fileIndex = 0; fileIndex < listFileBytes.Count; fileIndex++)
					{
						if (listFileBytes[fileIndex] != null)
						{
							fileName = fileUri[fileIndex];
							string uploadResult = await UploadBitmapAsync(listFileBytes[fileIndex], fileName);
							if (uploadResult != null)
							{
								jobject = JObject.Parse(uploadResult);
								if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
								{
									jsonFileRequest += FileUploadHelper.UploadsJsonRequest(uploadResult);
									jsonFileRequest += ",";
								}
								else
								{
									await Util.ErrorLog(Constants.strComposeMessage, Convert.ToString(jobject[Constants.strErrorMessage]), token);
									this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Convert.ToString(jobject[Constants.strErrorMessage]), true, this, "", 1);
									this.View.Add(this.customAlert);
									loadPop.Hide();
								}
							}
							else
							{
								this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strNoFile, true, this, "", 1);
								this.View.Add(this.customAlert);
								loadPop.Hide();
							}
						}
					}
					//Save Compose File And Data
					await FnsaveComposeData();
				}
				else
				{
					//Save Compose File And Data
					await FnsaveComposeData();
				}
			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
				loadPop.Hide();
			}
		}

		/// <summary>
		/// Compose Selected Details
		/// </summary>
		/// <returns></returns>
		private async Task FnsaveComposeData()
		{
			try
			{
				objServiceHelper = new ServiceHelper();
				apiMethod = APIMethods.shipmentDetails + "/" + lstShipmentDetail.ClientID + "|" + lstShipmentDetail.LocID + "|" + lstShipmentDetail.BolNum + "/" + APIMethods.msg;
				string requestBody = "{" + "\"ReplyToID\":" + "\"0\"" + ",";
				requestBody += "\"To\":" + composeToJson + ",";
				requestBody += "\"Subject\":" + "\"" + txtSubject.Text + "\"" + ",";
				requestBody += "\"Message\":" + "\"" + txtMessage.Text + "\"" + ",";
				requestBody += "\"Files\":[" + jsonFileRequest + "]";
				requestBody += "}";

				string response = await objServiceHelper.PostRequestJson(requestBody, apiMethod, token, true);
				if (!string.IsNullOrEmpty(response))
				{
					lstConposeMsg = (List<ComposeMessage>)JsonConvert.DeserializeObject(response, typeof(List<ComposeMessage>));
					FnResetControl();
					if (!string.IsNullOrEmpty(lstConposeMsg[0].ErrorMessage))
					{
						await Util.ErrorLog(Constants.strComposeMessage, Convert.ToString(jobject[Constants.strErrorMessage]), token);
						this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Convert.ToString(jobject[Constants.strErrorMessage]), true, this, "", 1);
						this.View.Add(this.customAlert);
					}
					else
					{
						//Save And Refresh The New Message
						string value = lstShipmentDetail.ClientID + "|" + lstShipmentDetail.BolNum + "|" + ConstantsClass.strCompose;
						CommanUtil.isReply = true;
						RedirectToConversation(value);
					}
				}
			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
				loadPop.Hide();
			}
		}

		/// <summary>
		/// File upload
		/// </summary>
		/// <param name="bytes">File will be in bytes</param>
		/// <returns></returns>
		public async Task<string> UploadBitmapAsync(byte[] bytes, string fileName)
		{
			try
			{
				objFileUploadHelper = new FileUploadHelper();
				apiMethod = APIMethods.composeDocs;
				string response = await objFileUploadHelper.PostFiles(bytes, fileName, apiMethod, token, true);
				return response;
			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
				loadPop.Hide();
				return null;
			}
		}

		/// <summary>
		/// Reset Controls
		/// </summary>
		private void FnResetControl()
		{
			try
			{
				txtMessage.Text = string.Empty;
				txtSubject.Text = string.Empty;
				txtFileName1.Text = string.Empty;
				txtFileName2.Text = string.Empty;
				txtFileName3.Text = string.Empty;
				if (lstShipmentDetail.ViewAs == Constants.strCustomer)
				{
					//Reset CheckBox
					foreach (var item in AllowedConversationToList)
					{
						item.Action = false;
					}
					btnSelectedItem.Text = Constants.strNoSelected;
				}
			}
			catch
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Constants.strErrorOccured, true, this, "", 1);
				this.View.Add(this.customAlert);
				loadPop.Hide();
			}
		}

		partial void BtnSend_TouchUpInside(UIButton sender)
		{
            if (!CommanUtil.IsTimeOut())
            {
                return;
            }
			if (Reachability.InternetConnectionStatus())
			{
				FnsaveComposeMessage();
			}
			else
			{
				this.customAlert = new CustomPopup(UIScreen.MainScreen.Bounds, Helper.Constants.isOnline, true, this, "", 1);
				this.View.Add(this.customAlert);
				return;
			}

		}

		partial void BtnCancel_TouchUpInside(UIButton sender)
		{
			//ConstantsClass.currentTab = 4;
			this.NavigationController.PopViewController(true);
		}


		/// <summary>
		/// Redirects to conversation Screen.
		/// </summary>
		public void RedirectToConversation(string compositeKey)
		{
			try
			{
				ShipmentDetailController objShipmentDetailController =
					this.Storyboard.InstantiateViewController
					("ShipmentDetailController") as ShipmentDetailController;
				objShipmentDetailController.compositeKey = compositeKey;
				objShipmentDetailController.tabNumber = 4;
				Util.currentTabAssigned = 4;
				this.NavigationController.PushViewController(objShipmentDetailController, true);
			}
			catch
			{
				throw;
			}

		}
	}
}