﻿using System;
using Foundation;
using UIKit;

namespace myapp
{
	public partial class MainController : BaseController
	{
		public TeamList teamMember { get; set; }
		public MainController  (IntPtr handle) : base (handle)
		{
		}

		public override void ViewDidLoad ()
		{
			base.ViewDidLoad ();
			// Perform any additional setup after loading the view, typically from a nib.
			SetUI();
			if (!string.IsNullOrEmpty(NSUserDefaults.StandardUserDefaults.StringForKey ("UserEmail"))) {
				lblUserInfo.Text = "Welcome: " + NSUserDefaults.StandardUserDefaults.StringForKey ("UserEmail");
			}

			if (teamMember != null) {
				lblIdVal.Text = teamMember.Empid.ToString ();
				lblNameVal.Text = teamMember.Name;
				lblEmailVal.Text = teamMember.Email;
			}
		}

		private void SetUI()
		{
			//Setting backgroung color
			vwHeader.BackgroundColor =  UIColor.FromRGB ((int)ConfigEntity.EPColorHeader.Red, (int)ConfigEntity.EPColorHeader.Green, (int)ConfigEntity.EPColorHeader.Blue);
//			//setting custom font family
			lblUserInfo.Font = UIFont.FromName (MyResource.OpenSansRegularFont, 20);
			lblLogOut.Font = UIFont.FromName (MyResource.OpenSansRegularFont, 12);

			lblId.Font = UIFont.FromName (MyResource.OpenSansRegularFont, 16);
			lblName.Font = UIFont.FromName (MyResource.OpenSansRegularFont, 16);
			lblEmail.Font = UIFont.FromName (MyResource.OpenSansRegularFont, 16);
			lblIdVal.Font = UIFont.FromName (MyResource.OpenSansRegularFont, 16);
			lblNameVal.Font = UIFont.FromName (MyResource.OpenSansRegularFont, 16);
			lblEmailVal.Font = UIFont.FromName (MyResource.OpenSansRegularFont, 16);

			//setting underline
			var attrString = new NSAttributedString("Logout",
				underlineStyle: NSUnderlineStyle.Single);
			lblLogOut.AttributedText = attrString;

			//crearting gesture 
			UITapGestureRecognizer lblLogoutGesture = new UITapGestureRecognizer (() => {
				if (NSUserDefaults.StandardUserDefaults.StringForKey ("isLogin") != null) {
					NSUserDefaults.StandardUserDefaults.RemoveObject ("isLogin");
				}
				this.PerformSegue("SegueToHome",null);
			});
			//appling gesture on lable
			lblLogOut.UserInteractionEnabled = true;
			lblLogOut.AddGestureRecognizer (lblLogoutGesture);
		}

		public override void DidReceiveMemoryWarning ()
		{
			base.DidReceiveMemoryWarning ();
			// Release any cached data, images, etc that aren't in use.
		}

		partial void Btnmenu_TouchUpInside (UIButton sender)
		{
			SidebarController.ToggleMenu ();
		}
	}
}


