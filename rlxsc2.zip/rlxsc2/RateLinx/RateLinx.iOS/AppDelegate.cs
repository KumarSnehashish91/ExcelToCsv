﻿using Foundation;
using UIKit;
using Helper = RateLinx.Helper;
using Google.Maps;
using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using UserNotifications;
using ToastIOS;
using RateLinx.Helper;
using Newtonsoft.Json;
using HockeyApp.iOS;

namespace RateLinx.iOS
{
	// The UIApplicationDelegate for the application. This class is responsible for launching the
	// User Interface of the application, as well as listening (and optionally responding) to application events from iOS.
	[Register("AppDelegate")]
	public class AppDelegate : UIApplicationDelegate
	{
		// class-level declarations
		public static UINavigationController NavigationController;
		const string MapsApiKey = Helper.Constants.strGoogleServerKey;
        public static bool disableAllOrientation = false;
		public override UIWindow Window
		{
			get;
			set;
		}
        public override UIInterfaceOrientationMask GetSupportedInterfaceOrientations(UIApplication application, UIWindow forWindow)
        {
            if (disableAllOrientation == true)
            {
                return UIInterfaceOrientationMask.Portrait;
            }
            return UIInterfaceOrientationMask.All;
        }
		public override bool FinishedLaunching(UIApplication application, NSDictionary launchOptions)
		{           
            var manager = BITHockeyManager.SharedHockeyManager;             manager.Configure("4e29c0cbc9a346d484f40136aef81090");             manager.StartManager();             manager.Authenticator.AuthenticateInstallation(); // This line is obsolete in crash only builds
			// Override point for customization after application launch.
			// If not required for your application you can safely delete this method
			// Override point for customization after application launch.
			// If not required for your application you can safely delete this method
			//// create a new window instance based on the screen size
			//Window = new UIWindow(UIScreen.MainScreen.Bounds);

			//////// If you have defined a root view controller, set it here:
			//Window.RootViewController = new UINavigationController();

			////var cntrl = new ShipmentDetailController(Handle);
			////var navController = new UINavigationController(cntrl);
			////Window.RootViewController = navController;
			//////// make the window visible
			//Window.MakeKeyAndVisible();

			if (UIDevice.CurrentDevice.CheckSystemVersion(8, 0))
			{
				var notificationSettings = UIUserNotificationSettings.GetSettingsForTypes(
					UIUserNotificationType.Alert | UIUserNotificationType.Badge | UIUserNotificationType.Sound, null
				);

				application.RegisterUserNotificationSettings(notificationSettings);
			}

			//if (launchOptions != null)
			//{
			//	// check for a local notification
			//	if (launchOptions.ContainsKey(UIApplication.LaunchOptionsLocalNotificationKey))
			//	{
			//		var localNotification = launchOptions[UIApplication.LaunchOptionsLocalNotificationKey] as UILocalNotification;
			//		if (localNotification != null)
			//		{
			//			UIAlertController okayAlertController = UIAlertController.Create(localNotification.AlertAction, localNotification.AlertBody, UIAlertControllerStyle.Alert);
			//			okayAlertController.AddAction(UIAlertAction.Create("OK", UIAlertActionStyle.Default, null));

			//			Window.RootViewController.PresentViewController(okayAlertController, true, null);

			//			// reset our badge
			//			UIApplication.SharedApplication.ApplicationIconBadgeNumber = 0;
			//		}
			//	}
			//}
			MapServices.ProvideAPIKey(MapsApiKey);


			return true;
		}

		public override void OnResignActivation(UIApplication application)
		{
			// Invoked when the application is about to move from active to inactive state.
			// This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) 
			// or when the user quits the application and it begins the transition to the background state.
			// Games should use this method to pause the game.
		}

		public override void DidEnterBackground(UIApplication application)
		{
			//ConstantsClass.appInBackGround = true;
			// Use this method to release shared resources, save user data, invalidate timers and store the application state.
			// If your application supports background exection this method is called instead of WillTerminate when the user quits.
		}

		public override void WillEnterForeground(UIApplication application)
		{

			UIApplication.SharedApplication.ApplicationIconBadgeNumber = 0;
			//ConstantsClass.appInBackGround = false;
			// Called as part of the transiton from background to active state.
			// Here you can undo many of the changes made on entering the background.
		}

		public override void OnActivated(UIApplication application)
		{

			//while (!CommanUtil.isStopAllTracking)
			//{

			//	await Task.Delay(ConstantsClass.trackingDelay);

			//	if (UIDevice.CurrentDevice.CheckSystemVersion(10, 0))
			//	{
			//		//TODO: Check if this will only work on 10 and up
			//		UNUserNotificationCenter.Current.RemoveAllDeliveredNotifications();
			//	}
			//	else
			//	{
			//		UIApplication.SharedApplication.CancelAllLocalNotifications();
			//	}
			//	var notification = new UILocalNotification();

			//	// set the fire date (the date time in which it will fire)
			//	notification.FireDate = NSDate.Now;

			//	// configure the alert
			//	notification.AlertAction = "Alert";
			//	notification.AlertBody = "You have currently live Tracking enabled!";

			//	// modify the badge
			//	notification.ApplicationIconBadgeNumber = 1;

			//	notification.

			//	// set the sound to be the default sound
			//	notification.SoundName = UILocalNotification.DefaultSoundName;

			//	// schedule it
			//	UIApplication.SharedApplication.ScheduleLocalNotification(notification);


			//}
			// Restart any tasks that were paused (or not yet started) while the application was inactive. 
			// If the application was previously in the background, optionally refresh the user interface.
		}

		public override void WillTerminate(UIApplication application)
		{
			NSUserDefaults.StandardUserDefaults.SetString(JsonConvert.SerializeObject(null), "objTrackList");
			CommanUtil.isStopAllTracking = true;
			CommanUtil.stopPooling = true;
			CommanUtil.isTrackingEnable = false;
			// Called when the application is about to terminate. Save data, if needed. See also DidEnterBackground.
		}

		/// <summary>
		/// used for push noti registration
		/// </summary>
		/// <returns></returns>
		public string PushRegisterd()
		{
			try
			{
				if (UIDevice.CurrentDevice.CheckSystemVersion(8, 0))
				{
					var pushSettings = UIUserNotificationSettings.GetSettingsForTypes(
									   UIUserNotificationType.Alert | UIUserNotificationType.Badge | UIUserNotificationType.Sound,
									   new NSSet());

					UIApplication.SharedApplication.RegisterUserNotificationSettings(pushSettings);
					UIApplication.SharedApplication.RegisterForRemoteNotifications();
				}
				else
				{
					UIRemoteNotificationType notificationTypes = UIRemoteNotificationType.Alert | UIRemoteNotificationType.Badge | UIRemoteNotificationType.Sound;
					UIApplication.SharedApplication.RegisterForRemoteNotificationTypes(notificationTypes);
				}

				//if (Convert.ToInt16(UIDevice.CurrentDevice.SystemVersion.Split('.')[0].ToString()) < 8)
				//{
				//	UIRemoteNotificationType notificationTypes = UIRemoteNotificationType.Alert | UIRemoteNotificationType.Badge | UIRemoteNotificationType.Sound;
				//	UIApplication.SharedApplication.RegisterForRemoteNotificationTypes(notificationTypes);
				//}
				//else
				//{
				//	UIUserNotificationType notificationTypes = UIUserNotificationType.Alert | UIUserNotificationType.Badge | UIUserNotificationType.Sound;
				//	var settings = UIUserNotificationSettings.GetSettingsForTypes(notificationTypes, new NSSet(new string[] { }));
				//	UIApplication.SharedApplication.RegisterUserNotificationSettings(settings);
				//	UIApplication.SharedApplication.RegisterForRemoteNotifications();
				//}

                return Helper.Constants.strSuccess.ToUpper();
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message.ToString());
                return Helper.Constants.strErrorMessage;
			}
		}

		/// <summary>
		///  Something went wrong while registering!
		/// </summary>
		/// <param name="application"></param>
		/// <param name="error"></param>
		public override void FailedToRegisterForRemoteNotifications(UIApplication application, NSError error)
		{
			new UIAlertView("Error registering push notifications", error.LocalizedDescription, null, "OK", null).Show();
		}
		public override void ReceivedLocalNotification(UIApplication application, UILocalNotification notification)
		{
			UNUserNotificationCenter.Current.RemoveAllPendingNotificationRequests();
			UNUserNotificationCenter.Current.RemoveAllDeliveredNotifications(); 
			// show an alert


			UIAlertController okayAlertController = UIAlertController.Create(notification.AlertAction, notification.AlertBody, UIAlertControllerStyle.Alert);
            okayAlertController.AddAction(UIAlertAction.Create(Helper.Constants.btnTextOk, UIAlertActionStyle.Default, null));


			//Window.RootViewController.PresentViewController(okayAlertController, true, null);

			// reset our badge
			UIApplication.SharedApplication.ApplicationIconBadgeNumber = 0;

		}


		/// <summary>
		///   We've received a notification, yay!
		/// </summary>
		/// <param name="application"></param>
		/// <param name="userInfo"></param>
		/// <param name="completionHandler"></param>
		public override void DidReceiveRemoteNotification(UIApplication application, NSDictionary userInfo, Action<UIBackgroundFetchResult> completionHandler)
		{
			bool fromFinishedLaunching = false;
			if (application.ApplicationState == UIApplicationState.Active)
			{
				fromFinishedLaunching = true;
			}

			ProcessNotification(userInfo, fromFinishedLaunching);
		}

		/// <summary>
		/// for push notification
		/// </summary>
		/// <param name="options"></param>
		/// <param name="fromFinishedLaunching"></param>
		public void ProcessNotification(NSDictionary options, bool fromFinishedLaunching)
		{
			try
			{
				// string claimNumber = string.Empty;
				// Check to see if the dictionary has the aps key.  This is the notification payload you would have sent
				if (options != null && options.ContainsKey(new NSString("aps")))
				{
					var uri = options.ContainsKey(new NSString("url"));
					// Get the aps dictionary
					NSDictionary aps = options.ObjectForKey(new NSString("aps")) as NSDictionary;

					// NSDictionary InsuredName = options.ObjectForKey(new NSString("InsuredName")) as NSDictionary;
					string alert = string.Empty;
					//string sound = string.Empty;
					string url = string.Empty;
					int badge = -1;
					if (uri)
					{
						url = options["url"].ToString();
					}
					// Extract the alert text
					// NOTE: If you're using the simple alert by just specifying "  aps:{alert:"alert msg here"}  "
					// this will work fine.  But if you're using a complex alert with Localization keys, etc., your "alert" object from the aps dictionary
					// will be another NSDictionary... Basically the json gets dumped right into a NSDictionary, so keep that in mind
					if (aps.ContainsKey(new NSString("alert")))
					{
						alert = (aps[new NSString("alert")] as NSString).ToString();
					}
					// Extract the sound string
					//if (aps.ContainsKey(new NSString("sound")))
					//{
					//	sound = (aps[new NSString("sound")] as NSString).ToString();
					//}
					//loadPop
					// Extract the badge
					if (aps.ContainsKey(new NSString("badge")))
					{
						string badgeStr = (aps[new NSString("badge")] as NSObject).ToString();
						int.TryParse(badgeStr, out badge);
					}
					UIStoryboard board = UIStoryboard.FromName("Main", null);
					var loginController = (LoginController)board.InstantiateViewController("LoginController");

					// If this came from the ReceivedRemoteNotification while the app was running,
					// we of course need to manually process things like the sound, badge, and alert.
					if (fromFinishedLaunching)
					{
						// Manually set the badge in case this came from a remote notification sent while the app was open
						if (badge >= 0)
						{
							UIApplication.SharedApplication.ApplicationIconBadgeNumber = badge;
						}
						// Manually play the sound
						// if (!string.IsNullOrEmpty(sound))
						// {
						// This assumes that in your json payload you sent the sound filename (like sound.caf)
						// and that you've included it in your project directory as a Content Build type.
						// var soundObj = AudioToolbox.SystemSound.FromFile(sound);
						// soundObj.PlaySystemSound();
						// }
						// Manually show an alert
						if (!string.IsNullOrEmpty(alert))
						{
							
							UIAlertView stavAlert = new UIAlertView(alert, alert, null, "View", "Cancel");
							stavAlert.Show();
							stavAlert.Clicked += async (sender, args) =>
							   {
								   // check if the user NOT pressed the cancel button
								   // var index = args.ButtonIndex;
								   if (args.ButtonIndex == 0)
								   {

									   await loginController.NotificationClick(url);
								   }
							   };
						}
					}
					else
					{
						// Manually set the badge in case this came from a remote notification sent while the app was open
						if (badge >= 0)
						{
							UIApplication.SharedApplication.ApplicationIconBadgeNumber = badge;
						}
						// Manually show an alert
						if (!string.IsNullOrEmpty(alert))
						{
							UIAlertView stavAlert = new UIAlertView(alert, alert, null, "View", "Cancel");
							stavAlert.Show();
							stavAlert.Clicked += async (sender, args) =>
							  {
								  // check if the user NOT pressed the cancel button
								  // var index = args.ButtonIndex;
								  if (args.ButtonIndex == 0)
								  {
									  try
									  {
										  await loginController.NotificationClick(url);
									  }
									  catch
									  {
										  Console.Write(Helper.Constants.strErrorOccured);
									  }
								  }
							  };
						}
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message.ToString());
			}
		}

		/// <summary>
		///  used for setting for registration for remote notification
		/// </summary>
		/// <param name="application"></param>
		/// <param name="notificationSettings"></param>
		public override void DidRegisterUserNotificationSettings(UIApplication application, UIUserNotificationSettings notificationSettings)
		{
			application.RegisterForRemoteNotifications();
		}

		/// <summary>
		/// used for registration for remote notification
		/// </summary>
		/// <param name="application"></param>
		/// <param name="deviceToken"></param>
		public override void RegisteredForRemoteNotifications(UIApplication application, NSData deviceToken)
		{
			var userDeviceToken = deviceToken.Description;
			if (!string.IsNullOrWhiteSpace(userDeviceToken))
			{
				userDeviceToken = deviceToken.ToString().Replace("<", string.Empty).Replace(">", string.Empty).Replace(" ", string.Empty);
			}
			// Get previous device token
			var oldDeviceToken = NSUserDefaults.StandardUserDefaults.StringForKey("PushDeviceToken");

			// Has the token changed?
			if (string.IsNullOrEmpty(oldDeviceToken) || !oldDeviceToken.Equals(userDeviceToken))
			{
				// TODO: Put your own logic here to notify your server that the device token has changed/been created!
			}
			// Save new device token 
			NSUserDefaults.StandardUserDefaults.SetString(userDeviceToken, "PushDeviceToken");
			if (!string.IsNullOrEmpty(userDeviceToken))
			{
				// save and send to service side token
				FileUploadHelper.FnRegisterDevice(true, userDeviceToken);
				if (!Util.isPushRegisterd)
				{
					//new UIAlertView(Helper.Constants.isOnline, Helper.Constants.isOnline, null, "OK", null).Show();
				}
			}
		}
	}
}


