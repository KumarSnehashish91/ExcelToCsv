using System;
using System.Collections.Generic;
using Android.App;
using Android.OS;
using Android.Views;
using Android.Widget;
using V4App = Android.Support.V4.App;
using RateLinx.Droid.Utilities;
using RateLinx.Models;
using Newtonsoft.Json;
using System.Linq;
using RateLinx.Droid.Adapters;
using RateLinx.Helper;
using System.Threading.Tasks;
using Java.Lang;
using Exception = System.Exception;

namespace RateLinx.Droid.Fragments
{
    /// <summary>
    /// Meta Tag of the Class
    /// </summary>
    public class AwardedShipmentFragment : V4App.Fragment
    {
        #region Declaration of controls instances and variables 
        View view = null;
        Activity context = null;
        string awardedShipments = string.Empty;
        ListView lstViewAwardedShipments = null;
        AwardedShipmentAdapter.AdapterAwardedShipments adptrAwardedShipments = null;  //adapter for Awarded Shipment
        List<AwardedShipments> lstAwardedShipments = null;
        TextView txtAwardedMsg = null;
        Spinner spinner = null;
        string filterOption = string.Empty;
        LinearLayout lnrLayoutSearch;
        bool isAwardIntervalAllow = true;
        /// <summary>
        /// 
        /// </summary>
        public System.Timers.Timer _timer = new System.Timers.Timer();
        /// <summary>
        /// 
        /// </summary>
        public bool isFocused = true;
        #endregion

        /// <summary>
        /// Assining Activity 
        /// </summary>
        /// <param name="context"></param>
        public AwardedShipmentFragment(Activity context)
        {
            this.context = context;
            lstAwardedShipments = new List<AwardedShipments>();
        }

        /// <summary>
        /// AwardedShipmentFragment : Page Load event
        /// </summary>
        /// <param name="inflater"></param>
        /// <param name="container"></param>
        /// <param name="savedInstanceState"></param>
        /// <returns></returns>
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                base.OnCreateView(inflater, container, savedInstanceState);
                view = inflater.Inflate(Resource.Layout.AwardedFragment, null);
                //Spinner
                spinner = view.FindViewById<Spinner>(Resource.Id.spinnerDriver);
                lnrLayoutSearch = view.FindViewById<LinearLayout>(Resource.Id.lnrLayoutSearch);
                spinner.ItemSelected += new EventHandler<AdapterView.ItemSelectedEventArgs>(spinner_ItemSelected);
                var adapter = ArrayAdapter.CreateFromResource(
                        context, Resource.Array.driver_array, Resource.Drawable.SpinnerCustomDesign);
                adapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
                spinner.Adapter = adapter;
                //Get the Shipments List
                lstViewAwardedShipments = view.FindViewById<ListView>(Resource.Id.lstViewAwardedShipments);
                txtAwardedMsg = view.FindViewById<TextView>(Resource.Id.txtAwardedMsg);
                adptrAwardedShipments = null;
                //Run count Down Time in evry second
                _timer = new System.Timers.Timer();
                _timer.Interval = 6000;
                _timer.Elapsed += delegate
                {
                    context.RunOnUiThread(() =>
                    {
                        OnTimedEvent();
                    });
                };
                return view;
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                return view;
            }
        }       
        /// <summary>
        /// 
        /// </summary>
        public void OnTimedEvent()
        {
            try
            {
                if (isAwardIntervalAllow && isFocused)
                {
                    if (filterOption.ToUpper() != Constants.filterBy.ToUpper())
                    {
                        BindAwardedShipments();
                    }
                }
                else
                {
                    _timer.Stop();
                }
            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
            }
        }

        /// <summary>
        /// OnResume get start the interval
        /// </summary>
        public override void OnResume()
        {
            isAwardIntervalAllow = true;
            isFocused = true;
            _timer.Start();
            _timer.Enabled = true;
            OnTimedEvent();
            base.OnResume();
        }

        /// <summary>
        /// Stop the interval
        /// </summary>
        public override void OnPause()
        {
            isAwardIntervalAllow = false;
            isFocused = false;
            _timer.Stop();
            _timer.Enabled = false;
            base.OnPause();
        }

        /// <summary>
        /// spinner or Dropdownlist ItemSelected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void spinner_ItemSelected(object sender, AdapterView.ItemSelectedEventArgs e)
        {
            try
            {
                if (lstAwardedShipments != null && lstAwardedShipments.Count > 0)
                {
                    Spinner spinner = (Spinner)sender;
                    string strUserID = CommanUtil.userID;
                    filterOption = spinner.GetItemAtPosition(e.Position).ToString();
                    if (filterOption.ToUpper() == Constants.filterBy.ToUpper())
                    {
                        List<AwardedShipments> tempAwardedShipments = new List<AwardedShipments>();
                        foreach (var awardedShipment in lstAwardedShipments)
                        {
                            if (awardedShipment.DriverID.ToUpper() == strUserID.ToUpper())
                            {
                                AwardedShipments objAwarded = new AwardedShipments();
                                objAwarded = awardedShipment;
                                tempAwardedShipments.Add(objAwarded);
                            }
                        }
                        if (tempAwardedShipments != null && tempAwardedShipments.Count > 0)
                        {
                            adptrAwardedShipments = new AwardedShipmentAdapter.AdapterAwardedShipments(context, tempAwardedShipments);
                            txtAwardedMsg.Visibility = ViewStates.Gone;
                            lstViewAwardedShipments.Visibility = ViewStates.Visible;
                            lstViewAwardedShipments.Adapter = adptrAwardedShipments;
                        }
                        else
                        {
                            txtAwardedMsg.Visibility = ViewStates.Visible;
                            lstViewAwardedShipments.Visibility = ViewStates.Gone;
                            txtAwardedMsg.Text = Constants.AwardedShipments;
                        }
                    }
                    else
                    {
                        if (lstAwardedShipments != null && lstAwardedShipments.Count > 0)
                        {
                            adptrAwardedShipments = new AwardedShipmentAdapter.AdapterAwardedShipments(context, lstAwardedShipments);
                            txtAwardedMsg.Visibility = ViewStates.Gone;
                            lstViewAwardedShipments.Visibility = ViewStates.Visible;
                            lstViewAwardedShipments.Adapter = adptrAwardedShipments;
                        }
                        else
                        {
                            txtAwardedMsg.Visibility = ViewStates.Visible;
                            lstViewAwardedShipments.Visibility = ViewStates.Gone;
                            txtAwardedMsg.Text = Constants.AwardedShipments;
                        }
                    }
                }
                else
                {
                    txtAwardedMsg.Text = GetString(Resource.String.AwardedShipments);
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// string Awarded Shipments
        /// </summary>
        public void BindAwardedShipments()
        {
            try
            {
                bool isShowCharges = CommanUtil.isShowCharges;
                if (CommanUtil.ViewAs == Constants.strCarrier)
                {
                    lnrLayoutSearch.Visibility = ViewStates.Visible;
                }
                else
                {
                    lnrLayoutSearch.Visibility = ViewStates.Gone;
                }
                awardedShipments = Constants.awardedShipmentsList;
                if (!string.IsNullOrEmpty(awardedShipments) && isShowCharges)
                {
                    lstAwardedShipments.Clear();
                    lstAwardedShipments = (List<AwardedShipments>)JsonConvert.DeserializeObject(awardedShipments, typeof(List<AwardedShipments>));
                    if (lstAwardedShipments != null && lstAwardedShipments.Count > 0)
                    {
                        if (adptrAwardedShipments == null)
                        {
                            adptrAwardedShipments = new AwardedShipmentAdapter.AdapterAwardedShipments(context, lstAwardedShipments);
                            lstViewAwardedShipments.Adapter = adptrAwardedShipments;
                        }
                        else
                        {
                            adptrAwardedShipments.context = context;
                            adptrAwardedShipments.lstAwardedShipments.Clear();
                            adptrAwardedShipments.lstAwardedShipments.AddRange(lstAwardedShipments); //lstActiveShipments;
                            adptrAwardedShipments.NotifyDataSetChanged();
                        }
                        txtAwardedMsg.Visibility = ViewStates.Gone;
                        lstViewAwardedShipments.Visibility = ViewStates.Visible;
                    }
                    else
                    {
                        txtAwardedMsg.Visibility = ViewStates.Visible;
                        lstViewAwardedShipments.Visibility = ViewStates.Gone;
                        txtAwardedMsg.Text = Constants.AwardedShipments;
                    }
                }
                else
                {
                    txtAwardedMsg.Visibility = ViewStates.Visible;
                    lstViewAwardedShipments.Visibility = ViewStates.Gone;
                    txtAwardedMsg.Text = Constants.AwardedShipments;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}