using System;
using System.Collections.Generic;
using System.Linq;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Views;
using Android.Widget;
using V4App = Android.Support.V4.App;
using URI = Android.Net;
using RateLinx.Models;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;
using Newtonsoft.Json;
using RateLinx.Droid.Adapters;
using RateLinx.Droid.Activities;
using System.Threading.Tasks;
using RateLinx.APIs;
using JavaFile = Java.IO.File;
using Newtonsoft.Json.Linq;
using RateLinx.Droid.FileHelper;
using Android.Support.V4.Content;
using Android;
using Android.Content.PM;

namespace RateLinx.Droid.Fragments
{
    /// <summary>
    /// Supporting Fragment
    /// </summary>
    public class SupportingFragment : V4App.Fragment
    {
        #region Declared Variables,Controls,object
        JavaFile file = null;
        string apiMethod = string.Empty;
        Activity context;
        Button fileUpload, btnUploadFile = null;
        Intent imageIntent = null;
        View supportFragment = null;
        CarrierShipmentDetails lstShipmentDetail = null;
        ServiceHelper objServiceHelper = null;
        List<string> objFileList = null;
        string fileUrl = string.Empty;
        string token = string.Empty;
        byte[] bytes = null;
        int index = 0;
        FileListAdapter.FileListAdapterShipments FileListAdapter = null;
        ListView lstViewFiles = null;
        TextView textFileName = null;
        URI.Uri selectedURI = null;
        JObject jobject = null;
        FileUploadHelper objFileHelper = null;
        Utility objUtility;
        readonly string[] PermissionsLocation =
                         {
         Manifest.Permission.WriteExternalStorage };

        #endregion

        /// <summary>
        /// Supporting Fragment As Acivity
        /// </summary>
        /// <param name="context"></param>
        public SupportingFragment(Activity context)
        {
            this.context = context;
            objUtility = new Utility();
        }

        /// <summary>
        /// Get Fragment
        /// </summary>
        /// <param name="inflater"></param>
        /// <param name="container"></param>
        /// <param name="savedInstanceState"></param>
        /// <returns></returns>
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                // Use this to return your custom view for this Fragment
                supportFragment = inflater.Inflate(Resource.Layout.SupportingFragment, container, false);
                token = CommanUtil.tokenNo;
                fileUpload = supportFragment.FindViewById<Button>(Resource.Id.fileUpload);
                lstViewFiles = supportFragment.FindViewById<ListView>(Resource.Id.lstViewFiles);
                fileUpload.Click += FileUpload_Click;
                btnUploadFile = supportFragment.FindViewById<Button>(Resource.Id.btnUploadFile);
                btnUploadFile.Click += BtnUploadFile_Click;
                textFileName = supportFragment.FindViewById<TextView>(Resource.Id.textFileName);
                //List View ItemClick Event
                lstViewFiles.ItemClick += LstViewFiles_ItemClick;
                return supportFragment;
            }
            catch (Exception ex)
            {
                Toast.MakeText(context, ex.Message, ToastLength.Long).Show();
                context.StartActivity(typeof(HomeActivity));
                return supportFragment;
            }
        }

        /// <summary>
        /// Get shipment detail data from shared preference
        /// </summary>
        private void GetShipmentDetailFromSharedPref()
        {
            try
            {
                string shipmentResponse = Utility.sharedPreferences.GetString(Constants.shipmentDetails, null);
                if (!string.IsNullOrEmpty(shipmentResponse))
                {
                    lstShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(shipmentResponse);
                    objFileList = new List<string>();
                    if (lstShipmentDetail.SupportFiles != null)
                    {
                        lstViewFiles.Visibility = ViewStates.Visible;
                        objFileList = lstShipmentDetail.SupportFiles.ToList();
                        BindFiles(objFileList);
                    }
                    else
                    {
                        lstViewFiles.Visibility = ViewStates.Gone;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// List View Selected Item Event And dispalying file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LstViewFiles_ItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            try
            {
                //Get position
                index = e.Position;
                fileUrl = objFileList[index];
                Utility.ViewUploadedFile(fileUrl, context);
            }
            catch
            {
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Call back method to get the selected file url from device
        /// </summary>
        /// <param name="requestCode"></param>
        /// <param name="resultCode"></param>
        /// <param name="data"></param>
        public override void OnActivityResult(int requestCode, int resultCode, Intent data)
        {
            try
            {
                base.OnActivityResult(requestCode, resultCode, data);
                if (resultCode == -1)
                {
                    selectedURI = data.Data;
                    string filePath = FileUploadHelper.GetFilePath(selectedURI, context);
                    if (!string.IsNullOrEmpty(filePath))
                    {
                        string fileName = FileUploadHelper.GetFileName(filePath);
                        if (fileName.Contains(".pdf") || fileName.Contains(".doc") || fileName.Contains(".docx") || fileName.Contains(".xls") ||
                            fileName.Contains(".xlsx") || fileName.Contains(".png") || fileName.Contains(".jpg") || fileName.Contains(".gif") ||
                            fileName.Contains(".tif") || fileName.Contains(".bmp"))
                        {
                            file = new JavaFile(filePath);
                            textFileName.Text = fileName;
                            // Conversion of selected file into bytes
                            bytes = FileUploadHelper.ConvertFileIntoByte(filePath);
                        }
                        else
                        {
                            Toast.MakeText(context, Constants.fileNotSupported, ToastLength.Long).Show();
                        }
                    }
                    else
                    {
                        textFileName.Text = "";
                        Toast.MakeText(context, Constants.fileError, ToastLength.Long).Show();
                    }
                }
            }
            catch (Exception ex)
            {
                textFileName.Text = "";
                Toast.MakeText(context, ex.Message, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Browser button for selecting file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FileUpload_Click(object sender, EventArgs e)
        {
            try
            {
                //Enable Gps Setting and Get Current Location
                if ((ContextCompat.CheckSelfPermission(context, Manifest.Permission.WriteExternalStorage) == (int)Permission.Granted))
                {
                    imageIntent = new Intent(Intent.ActionPick, Android.Provider.MediaStore.Images.Media.ExternalContentUri);
                    imageIntent.SetType("*/*");
                    imageIntent.PutExtra("return-data", true);
                    imageIntent.SetAction(Intent.ActionGetContent);
                    StartActivityForResult(
                        Intent.CreateChooser(imageIntent, Constants.strSelectFile), 0);
                }
                else
                {
                    V4App.ActivityCompat.RequestPermissions(context, PermissionsLocation, 0);
                }
            }
            catch
            {
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// File Upload Button Posting File in API
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void BtnUploadFile_Click(object sender, EventArgs e)
        {
            try
            {
                if (CommanUtil.IsTimeOut())
                {
                    if (bytes != null)
                    {
                        Alerts.showBusyLoader(context);
                        string jsonRequest = string.Empty;
                        objServiceHelper = new ServiceHelper();
                        string uploadResult = await UploadBitmapAsync(bytes);
                        if (uploadResult != null)
                        {
                            jobject = JObject.Parse(uploadResult);
                            if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
                            {
                                //File Response will post in another API
                                jsonRequest = FileUploadHelper.UploadsJsonRequest(uploadResult);
                                apiMethod = APIMethods.shipmentDetails + "/" + lstShipmentDetail.ClientID + "|" + lstShipmentDetail.LocID + "|" + lstShipmentDetail.BolNum + "/supportfile";
                                //Requesting To Other API
                                jsonRequest = "{\"Files\":[" + jsonRequest + "]}";
                                string fileResult = await objServiceHelper.PostRequestJson(jsonRequest, apiMethod, token, true);
                                if (fileResult != null)
                                {
                                    objFileList = JsonConvert.DeserializeObject<List<string>>(fileResult);
                                    apiMethod = APIMethods.shipmentDetails + "/" + lstShipmentDetail.ClientID + "|" + lstShipmentDetail.BolNum;
                                    await objUtility.BindShipmentDetail(apiMethod, context);//Refresh shipment detail data
                                    //BindFiles(objFileList);
                                    GetShipmentDetailFromSharedPref(); //Re-binding List of files
                                    textFileName.Text = "";
                                    bytes = null;
                                    Alerts.HideBusyLoader();
                                }
                                else
                                {
                                    Alerts.HideBusyLoader();
                                    Toast.MakeText(context, Constants.strNoFile, ToastLength.Long).Show();
                                }
                            }
                            else
                            {
                                Alerts.HideBusyLoader();
                                Toast.MakeText(context, Convert.ToString(jobject[Constants.strErrorMessage]), ToastLength.Long).Show();
                                Utility.ErrorLog(Constants.strSupporting, Convert.ToString(jobject[Constants.strErrorMessage]), CommanUtil.tokenNo, context);
                            }
                        }
                        else
                        {
                            Alerts.HideBusyLoader();
                            Toast.MakeText(context, Constants.strFileLength, ToastLength.Long).Show();
                        }
                    }
                    else
                    {
                        Alerts.HideBusyLoader();
                        Toast.MakeText(context, Resources.GetString(Resource.String.choosFile), ToastLength.Long).Show();
                    }
                }
                else
                {
                    //Token Exired 
                    Utility.ExpireSession(context);
                }
            }
            catch
            {
                Alerts.HideBusyLoader();
                Toast.MakeText(context, Resources.GetString(Resource.String.choosFile), ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Bind Supporting Files 
        /// </summary>
        private void BindFiles(List<string> objFiles)
        {
            try
            {
                if (objFiles != null)
                {
                    //Calling Adapter and binding data into list view
                    lstViewFiles.Visibility = ViewStates.Visible;
                    FileListAdapter = new FileListAdapter.FileListAdapterShipments(context, objFiles);
                    lstViewFiles.Adapter = FileListAdapter;
                }
                else
                {
                    lstViewFiles.Visibility = ViewStates.Gone;
                }
                Alerts.HideBusyLoader();
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
            }
        }

        /// <summary>
        /// File upload
        /// </summary>
        /// <param name="bytes">File will be in bytes</param>
        /// <returns></returns>
        public async Task<string> UploadBitmapAsync(byte[] bytes)
        {
            try
            {
                objFileHelper = new FileUploadHelper();
                apiMethod = APIMethods.supportfile;
                var response = await objFileHelper.PostFiles(bytes, file, apiMethod, token, true);
                return response;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Handle uploaded files 
        /// </summary>
        public override void OnResume()
        {
            GetShipmentDetailFromSharedPref();
            base.OnResume();
        }
    }
}