using System;
using System.Collections.Generic;
using System.Linq;
using Android.App;
using Android.OS;
using Android.Views;
using Android.Widget;
using V4App = Android.Support.V4.App;
using ZXing.Mobile;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;
using RateLinx.Models;
using Newtonsoft.Json;
using RateLinx.APIs;
using Android;
using Android.Support.V4.Content;
using Android.Content.PM;

namespace RateLinx.Droid.Fragments
{
    /// <summary>
    /// Equipment Scanning Fragment
    /// </summary>
    public class EquipmentScanningFragment : V4App.Fragment
    {
        #region Declaration of controls instances and variables 
        View viewEquipmentScanning = null;
        Activity context= null;
        TextView txtPickupScan, txtPickupCancel, txtDropScan, txtDropoffCancel, txtDialogHeader, editTextCross
            , txtDialogBody, tvBarcode , tvCancel= null;
        Button btnScanPickup, btnScanDrop, btnScanOthers, btnSaveDetails, btnCancel, btnProceed = null;
        LinearLayout lnrOtherEquipScans= null;
        List<TextView> lstTvOthersCancel = new List<TextView>();
        List<TextView> lstTvOthersScanNo = new List<TextView>();
        List<string> lstOtherEquipNo = new List<string>();
        string shipmentDetails = string.Empty;
        CarrierShipmentDetails lstShipmentDetail = null;
        Dialog dialog;
        int idTvOtherCancel;
        int idCount = 1;
        AlertDialog.Builder alert = null;
        MobileBarcodeScanner scanner = null;

        readonly string[] PermissionsLocation =
                         {
         Manifest.Permission.Camera };
        #endregion

        /// <summary>
        /// EquipmentScanningFragment Activity
        /// </summary>
        /// <param name="context"></param>
        public EquipmentScanningFragment(Activity context)
        {
            this.context = context;
        }

        /// <summary>
        /// Equipment Scanning Fragment 
        /// </summary>
        /// <param name="inflater"></param>
        /// <param name="container"></param>
        /// <param name="savedInstanceState"></param>
        /// <returns></returns>
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                // Use this to return your custom view for this Fragment
                viewEquipmentScanning = inflater.Inflate(Resource.Layout.EquipmentScanning, container, false);
                GetControlById();
                return viewEquipmentScanning;
            }
            catch(Exception ex)
            {
                context.Finish();
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                return viewEquipmentScanning;
            }
        }

        /// <summary>
        /// Get Control By Id And Creating Events
        /// </summary>
        public void GetControlById()
        {
            try
            {
                shipmentDetails = Utility.sharedPreferences.GetString(Constants.shipmentDetails, null);
                lstShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(shipmentDetails);
                MobileBarcodeScanner.Initialize(this.context.Application);
                txtPickupScan = viewEquipmentScanning.FindViewById<TextView>(Resource.Id.txtPickupScan);
                txtPickupCancel = viewEquipmentScanning.FindViewById<TextView>(Resource.Id.txtPickupCancel);
                txtDropScan = viewEquipmentScanning.FindViewById<TextView>(Resource.Id.txtDropScan);
                txtDropoffCancel = viewEquipmentScanning.FindViewById<TextView>(Resource.Id.txtDropoffCancel);
                lnrOtherEquipScans = viewEquipmentScanning.FindViewById<LinearLayout>(Resource.Id.lnrOtherEquipScans);
                btnScanPickup = viewEquipmentScanning.FindViewById<Button>(Resource.Id.btnScanPickup);
                btnScanDrop = viewEquipmentScanning.FindViewById<Button>(Resource.Id.btnScanDrop);
                btnScanOthers = viewEquipmentScanning.FindViewById<Button>(Resource.Id.btnScanOthers);
                btnSaveDetails = viewEquipmentScanning.FindViewById<Button>(Resource.Id.btnSaveDetails);
                btnCancel = viewEquipmentScanning.FindViewById<Button>(Resource.Id.btnCancel);
                btnScanPickup.Click += delegate
                {
                    if ((ContextCompat.CheckSelfPermission(context, Manifest.Permission.Camera) == (int)Permission.Granted))
                    {
                        ScanPickupEquip();
                    }
                    else
                    {
                        V4App.ActivityCompat.RequestPermissions(context, PermissionsLocation, 0);
                    }
                    
                };
                btnScanDrop.Click += delegate
                {
                    if ((ContextCompat.CheckSelfPermission(context, Manifest.Permission.Camera) == (int)Permission.Granted))
                    {
                        ScanDropOffEquip();
                    }
                    else
                    {
                        V4App.ActivityCompat.RequestPermissions(context, PermissionsLocation, 0);
                    }
                    
                };
                btnScanOthers.Click += delegate
                {
                    if ((ContextCompat.CheckSelfPermission(context, Manifest.Permission.Camera) == (int)Permission.Granted))
                    {
                        ScanOtherEquipments();
                    }
                    else
                    {
                        V4App.ActivityCompat.RequestPermissions(context, PermissionsLocation, 0);
                    }
                    
                };
                btnSaveDetails.Click += BtnSaveDetails_Click;
                btnCancel.Click += BtnCancel_Click;
                txtPickupCancel.Click += TxtPickupCancel_Click;
                txtDropoffCancel.Click += TxtDropoffCancel_Click;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Scan DropOff Equip
        /// </summary>
        private async void ScanDropOffEquip()
        {
            try
            {
                scanner = new MobileBarcodeScanner();
                var result = await scanner.Scan();
                if (result != null)
                {
                    txtDropScan.Text = string.Empty;
                    txtDropScan.Text = result.Text;
                    txtDropoffCancel.Visibility = ViewStates.Visible;
                }
            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Scaning of Pickup Equipments
        /// </summary>
        private async void ScanPickupEquip()
        {
            try
            {
                scanner = new MobileBarcodeScanner();
                var result = await scanner.Scan();
                if (result != null)
                {
                    txtPickupScan.Text = string.Empty;
                    txtPickupScan.Text = result.Text;
                    txtPickupCancel.Visibility = ViewStates.Visible;
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Function for scanning other equipments 
        /// </summary>
        private async void ScanOtherEquipments()
        {
            try
            {
                if (lstTvOthersScanNo.Count > 0)
                {
                    lnrOtherEquipScans.RemoveAllViews();
                    for (int indexEqipScan = 0; indexEqipScan < lstTvOthersCancel.Count; indexEqipScan++)
                    {
                        lnrOtherEquipScans.AddView(lstTvOthersScanNo[indexEqipScan]);
                        lnrOtherEquipScans.AddView(lstTvOthersCancel[indexEqipScan]);
                    }
                }
                alert = new AlertDialog.Builder(context);
                alert.SetView(Resource.Layout.dialog);
                dialog = alert.Create();
                scanner = new MobileBarcodeScanner();
                var result = await scanner.Scan();
                if (result != null)
                {
                    dialog.Show();
                    txtDialogHeader = dialog.FindViewById<TextView>(Resource.Id.txtDialogHeader);
                    editTextCross = dialog.FindViewById<TextView>(Resource.Id.editTextCross);
                    txtDialogBody = dialog.FindViewById<TextView>(Resource.Id.txtDialogBody);
                    btnProceed = dialog.FindViewById<Button>(Resource.Id.btnProceed);
                    btnProceed.Text = Constants.strkeepScanning;
                    btnCancel = dialog.FindViewById<Button>(Resource.Id.btnCancel);
                    btnCancel.Text = Constants.strDoneBtn;
                    dialog.SetCancelable(false);
                    txtDialogHeader.Text = Constants.strOtherScan;
                    txtDialogBody.Text = Constants.strYouscanned + result.Text + Constants.strWouldScan;
                    btnProceed.Click += delegate
                    {
                        if (lstTvOthersScanNo.Count > 0)
                        {
                            lnrOtherEquipScans.RemoveAllViews();
                            for (int indexOtherScan = 0; indexOtherScan < lstTvOthersCancel.Count; indexOtherScan++)
                            {
                                lnrOtherEquipScans.AddView(lstTvOthersScanNo[indexOtherScan]);
                                lnrOtherEquipScans.AddView(lstTvOthersCancel[indexOtherScan]);
                            }
                        }
                        dialog.Hide();
                        TextView txtViewOthers = new TextView(context);
                        txtViewOthers.Id = 100 + lstTvOthersCancel.Count;
                        txtViewOthers.Text = result.Text;
                        txtViewOthers.SetTextColor(Android.Graphics.Color.Black);
                        lstTvOthersScanNo.Add(txtViewOthers);
                        TextView txtViewOthersCancel = new TextView(context);
                        txtViewOthersCancel.Id = 100 + lstTvOthersCancel.Count;
                        txtViewOthersCancel.Text = " X ";
                        txtViewOthersCancel.SetTextColor(Android.Graphics.Color.Red);
                        lstTvOthersCancel.Add(txtViewOthersCancel);
                        lnrOtherEquipScans.AddView(txtViewOthers);
                        lnrOtherEquipScans.AddView(txtViewOthersCancel);
                        idCount++;
                        ScanOtherEquipments();
                    };
                    editTextCross.Click += delegate
                    {
                        dialog.Hide();
                        TextView txtViewOthers = new TextView(context);
                        txtViewOthers.Id = 100 + lstTvOthersCancel.Count;
                        txtViewOthers.Text = result.Text;
                        txtViewOthers.SetTextColor(Android.Graphics.Color.Black);

                        lstTvOthersScanNo.Add(txtViewOthers);
                        TextView txtViewOthersCancel = new TextView(context);
                        txtViewOthersCancel.Id = 100 + lstTvOthersCancel.Count;
                        txtViewOthersCancel.Text = " X ";
                        txtViewOthersCancel.SetTextColor(Android.Graphics.Color.Red);
                        lstTvOthersCancel.Add(txtViewOthersCancel);
                        lnrOtherEquipScans.AddView(txtViewOthers);
                        lnrOtherEquipScans.AddView(txtViewOthersCancel);
                        AddEventToButtonsAtRunTime();
                        dialog.Hide();
                    };
                    btnCancel.Click += delegate
                    {
                        dialog.Hide();
                        TextView txtViewOthers = new TextView(context);
                        txtViewOthers.Id = 100 + lstTvOthersCancel.Count;
                        txtViewOthers.Text = result.Text;
                        txtViewOthers.SetTextColor(Android.Graphics.Color.Black);

                        lstTvOthersScanNo.Add(txtViewOthers);
                        TextView txtViewOthersCancel = new TextView(context);
                        txtViewOthersCancel.Id = 100 + lstTvOthersCancel.Count;
                        txtViewOthersCancel.Text = " X ";
                        txtViewOthersCancel.SetTextColor(Android.Graphics.Color.Red);
                        lstTvOthersCancel.Add(txtViewOthersCancel);
                        lnrOtherEquipScans.AddView(txtViewOthers);
                        lnrOtherEquipScans.AddView(txtViewOthersCancel);
                        AddEventToButtonsAtRunTime();
                        dialog.Hide();
                    };
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Add Event To Buttons At RunTime
        /// </summary>
        private void AddEventToButtonsAtRunTime()
        {
            try
            {
                for (int index = 0; index < lstTvOthersCancel.Count; index++)
                {
                    idTvOtherCancel = lstTvOthersCancel[index].Id;
                    int barcodePosition = idTvOtherCancel - 100;
                    lstTvOthersCancel[barcodePosition].Click += delegate
                    {
                        RemoveBarcodeFromList(barcodePosition);
                    };
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Remove Barcode FromList
        /// </summary>
        /// <param name="txtViewId"></param>
        private void RemoveBarcodeFromList(int txtViewId)
        {
            try
            {
                if (lstTvOthersScanNo.Count > 0)
                {
                    tvBarcode = lstTvOthersScanNo.Where(x => x.Id == 100 + txtViewId).FirstOrDefault();
                    tvCancel = lstTvOthersCancel.Where(x => x.Id == 100 + txtViewId).FirstOrDefault();
                    lstTvOthersScanNo.Remove(tvBarcode);
                    lstTvOthersCancel.Remove(tvCancel);
                    lnrOtherEquipScans.RemoveAllViews();
                    for (int indexScan = 0; indexScan < lstTvOthersCancel.Count; indexScan++)
                    {
                        lnrOtherEquipScans.AddView(lstTvOthersScanNo[indexScan]);
                        lnrOtherEquipScans.AddView(lstTvOthersCancel[indexScan]);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// TxtDropoff Cancel Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TxtDropoffCancel_Click(object sender, EventArgs e)
        {
            try
            {
                txtDropScan.Text = "";
                txtDropoffCancel.Visibility = ViewStates.Gone;
            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                context.Finish();
            }
        }

        /// <summary>
        /// TxtPickup Cancel Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TxtPickupCancel_Click(object sender, EventArgs e)
        {
            try
            {
                txtPickupScan.Text = "";
                txtPickupCancel.Visibility = ViewStates.Gone;
            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                context.Finish();
            }
        }

        /// <summary>
        /// Button Cancel Click Event Redirecting to previous activity
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnCancel_Click(object sender, EventArgs e)
        {
            context.Finish();
        }

        /// <summary>
        /// Button SaveDetails Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void BtnSaveDetails_Click(object sender, EventArgs e)
        {
            try
            {
                if (CommanUtil.IsTimeOut())
                {
                    if (!string.IsNullOrEmpty(txtPickupScan.Text) && !string.IsNullOrEmpty(txtDropScan.Text))
                    {
                        if (lstOtherEquipNo != null)
                        {
                            lstOtherEquipNo.Clear();
                        }
                        foreach (TextView tvBarcode in lstTvOthersScanNo)
                        {
                            lstOtherEquipNo.Add(tvBarcode.Text);
                        }
                        string postData = "PickupNum=" + txtPickupScan.Text
                                           + "&DropoffNum=" + txtDropScan.Text
                                           + "&OnSiteEquipNums=" + lstOtherEquipNo;

                        string requestData = lstShipmentDetail.ClientID + "|" + lstShipmentDetail.LocID + "|" + lstShipmentDetail.BolNum;
                        string methodURI = APIMethods.Shipment + "/" + requestData + "/" + APIMethods.equipnumbers;
                        string token = CommanUtil.tokenNo;
                        ServiceHelper objServiceHelper = new ServiceHelper();
                        Alerts.showBusyLoader(context); //Loader
                        string Result = await objServiceHelper.PostRequest(postData, methodURI, token, true);
                        if (Result != null)
                        {
                            var Jobject = JsonConvert.DeserializeObject(Result);
                            if (Jobject.ToString().ToUpper() == Constants.strSuccess.ToUpper())
                            {
                                Result = Constants.strSuccess;
                            }
                            else
                            {
                                CommanUtil.isTrackingClicked = false;
                                Result = Constants.strException;
                                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Short).Show();
                                Utility.ErrorLog(Result, Result, CommanUtil.tokenNo, context);
                            }
                            Alerts.HideBusyLoader(); //Loader
                            context.Finish();
                        }
                    }
                    else
                    {
                        Toast.MakeText(context, Constants.strPickupDropOffEquipNoReq, ToastLength.Short).Show();
                    }
                }
                else
                {
                    //Token Exired
                    Utility.ExpireSession(context);
                }
            }
            catch(Exception ex)
            {                
                Alerts.HideBusyLoader(); //Loader
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                context.Finish();
            }
        }

        /// <summary>
        /// Button Other Sacn Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnScanOthers_Click(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
        }
    }
}