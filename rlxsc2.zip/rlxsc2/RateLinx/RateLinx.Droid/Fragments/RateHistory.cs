using System;
using V4App = Android.Support.V4.App;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Views;
using Android.Widget;
using ZXing.Mobile;
using RateLinx.Models;
using RateLinx.Helper;
using Android.Content.PM;
using Android;
using Android.Support.V4.Content;
using RateLinx.Droid.Utilities;

namespace RateLinx.Droid.Fragments
{
    /// <summary>
    /// RateHistory 
    /// </summary>
    public class RateHistory : V4App.Fragment
    {
        #region Declaration of controls instances and variables 
        Filters objFilters = null;
        View viewRateHistory = null;
        Activity context;
        EditText txtOriginDate, txtEndDate = null;
        Button btnScan, btnSearch = null;
        EditText txtLoadNo = null;
        EditText txtClientID = null;
        MobileBarcodeScanner scanner = null;
        Spinner spinnerAuction, ddlAuction = null;
        int rateHistoryActions = 0;
        TextView TvHeaderTitle;
        readonly string[] PermissionsLocation =
                          {
         Manifest.Permission.Camera };
        #endregion

        /// <summary>
        /// Initializing constrctor for activity
        /// </summary>
        /// <param name="context">Activity</param>
        public RateHistory(Activity context)
        {
            this.context = context;
        }

        /// <summary>
        /// RateHistory Layout Load Event
        /// </summary>
        /// <param name="inflater"></param>
        /// <param name="container"></param>
        /// <param name="savedInstanceState"></param>
        /// <returns></returns>
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                if (viewRateHistory == null)
                {
                    //Getting RateHistory Layout and other controls from the RateHistory layout
                    viewRateHistory = inflater.Inflate(Resource.Layout.RateHistory, null);
                    var toolbar = context.FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.app_bar);
                    TvHeaderTitle = toolbar.FindViewById<TextView>(Resource.Id.toolbar_title);
                    toolbar.FindViewById<ImageView>(Resource.Id.imgBack).Visibility = ViewStates.Invisible;
                    btnScan = viewRateHistory.FindViewById<Button>(Resource.Id.btnScan);
                    btnSearch = viewRateHistory.FindViewById<Button>(Resource.Id.btnSearch);
                    txtLoadNo = viewRateHistory.FindViewById<EditText>(Resource.Id.txtLoadNo);
                    txtClientID = viewRateHistory.FindViewById<EditText>(Resource.Id.txtClientID);
                    spinnerAuction = viewRateHistory.FindViewById<Spinner>(Resource.Id.ddlAction);
                    MobileBarcodeScanner.Initialize(this.context.Application);
                    //Scan button click event
                    btnScan.Click += BtnScan_Click;
                    //search button click event
                    btnSearch.Click += BtnSearch_Click;
                    ddlAuction = viewRateHistory.FindViewById<Spinner>(Resource.Id.ddlAction);
                    //
                    int auctionIndex = 0;
                    if (CommanUtil.ViewAs.ToUpper() == Constants.strCarrier)
                    {
                        auctionIndex = 2;
                        rateHistoryActions = Resource.Array.RateHistoryActionsCarrier;
                    }
                    else
                    {
                        auctionIndex = 1;
                        rateHistoryActions = Resource.Array.RateHistoryActionsCustomer;
                    }
                    ddlAuction.ItemSelected += new EventHandler<AdapterView.ItemSelectedEventArgs>(spinner_ItemSelected);
                    var adapter = ArrayAdapter.CreateFromResource(
                            context, rateHistoryActions, Resource.Drawable.SpinnerCustomDesign);
                    adapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
                    ddlAuction.Adapter = adapter;

                    ddlAuction.SetSelection(auctionIndex);
                    
                    txtOriginDate = viewRateHistory.FindViewById<EditText>(Resource.Id.txtOriginDate);
                    txtOriginDate.Click += (sender, e) =>
                    {
                        DateTime today = DateTime.Today;
                        DatePickerDialog dialog = new DatePickerDialog(context, StartDate, today.Year, today.Month - 1, today.Day);
                        dialog.DatePicker.MinDate = today.Millisecond;
                        dialog.Show();
                    };
                    txtEndDate = viewRateHistory.FindViewById<EditText>(Resource.Id.txtEndDate);
                    txtEndDate.Click += (sender, e) =>
                    {
                        DateTime today = DateTime.Today;
                        DatePickerDialog dialog = new DatePickerDialog(context, EndDate, today.Year, today.Month - 1, today.Day);
                        dialog.DatePicker.MinDate = today.Millisecond;
                        dialog.Show();
                    };
                    StartAndEndDate();
                }
                return viewRateHistory;
            }
            catch(Exception e)
            {
                Toast.MakeText(context, e.Message, ToastLength.Long).Show();
                return viewRateHistory;
            }
        }

        /// <summary>
        /// Handle Header text
        /// </summary>
        public override void OnResume()
        {
            TvHeaderTitle.Text = Constants.strRateHistory;
            base.OnResume();
        }

        /// <summary>
        /// Setting up Start and End date for filtering history records
        /// </summary>
        private void StartAndEndDate()
        {
            try
            {
                string originDate = DateTime.Now.AddDays(-7).ToString(Constants.dateFormatMMDDYYYY);//Origin date should be 7 days less than current date
                string endDate = DateTime.Now.ToString(Constants.dateFormatMMDDYYYY);//setting date format to MMDDYYYY
                txtOriginDate.Text = originDate.Contains("-") ? originDate.Replace('-', '/') : originDate;//replacing "-" from "/" in the date
                txtEndDate.Text = endDate.Contains("-") ? endDate.Replace('-', '/') : endDate;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Search Button Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Utility.FnIsOnline(context))
                {
                    Toast.MakeText(context, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                else
                {
                    if (CommanUtil.IsTimeOut())
                    {
                        objFilters = new Filters();
                        string endDate = string.Empty;
                        string originDate = string.Empty;
                        objFilters.Action = Constants.strALL;

                        objFilters.ClientId = txtClientID.Text;
                        objFilters.LoadNo = txtLoadNo.Text;

                        var filterQuery = "";//variable for holding history filter query
                        if (IsValidated())
                        {
                            if (Convert.ToString(spinnerAuction.SelectedItem) != Constants.strALL)
                            {
                                if (Convert.ToString(spinnerAuction.SelectedItem) == Constants.strReqConfirm)
                                {
                                    filterQuery = "filters='Auction Status'=NEW|'Rate Status'=AWARDED";
                                }
                                else if (Convert.ToString(spinnerAuction.SelectedItem) == Constants.strReqResponse)
                                {
                                    filterQuery = "filters='Auction Status'=NEW|'Rate Status':~RATE~AWARDED";
                                }
                                else if (Convert.ToString(spinnerAuction.SelectedItem) == Constants.strReqRate)
                                {
                                    filterQuery = "filters='Auction Status'=NEW|'Rate Status':~RATE";
                                }
                                else if (Convert.ToString(spinnerAuction.SelectedItem) == Constants.strOpenAc)
                                {
                                    filterQuery = "filters='Auction Status':NEW~AWARDED";
                                }
                                else if (Convert.ToString(spinnerAuction.SelectedItem) == Constants.strAwardAc)
                                {
                                    filterQuery = "filters='Auction Status'=AWARDED|'Auction Status'!=VOID";
                                }
                                else if (Convert.ToString(spinnerAuction.SelectedItem) == Constants.strConShip)
                                {
                                    filterQuery = "filters='Auction Status'=CLOSED|'Rate Status'=CONFIRMED";
                                }
                            }

                            if (!string.IsNullOrEmpty(txtOriginDate.Text) && !string.IsNullOrEmpty(txtEndDate.Text))
                            {
                                if (string.IsNullOrEmpty(filterQuery))
                                {
                                    filterQuery = "filters='Date Opened'>=" + txtOriginDate.Text + "|'Date Opened'<=" + txtEndDate.Text + "";
                                }
                                else
                                {
                                    filterQuery = filterQuery + "|'Date Opened'>=" + txtOriginDate.Text + "|'Date Opened'<=" + txtEndDate.Text + "";
                                }
                            }
                            if (objFilters.LoadNo != "")
                            {
                                if (filterQuery == "")
                                {
                                    filterQuery = "filters='Load Num'=" + objFilters.LoadNo + "";
                                }
                                else
                                {
                                    filterQuery += "|'Load Num'=" + objFilters.LoadNo + "";
                                }
                            }
                            if (objFilters.ClientId != "")
                            {
                                if (filterQuery == "")
                                {
                                    filterQuery = "filters='Client ID'=" + objFilters.ClientId + "";
                                }
                                else
                                {
                                    filterQuery += "|'Client ID'=" + objFilters.ClientId + "";
                                }
                            }

                            filterQuery = filterQuery == "" ? "#" : filterQuery;

                            SearchShipment(null, filterQuery);
                        }
                        else
                        {

                        }
                    }
                    else
                    {
                        //Toekn Exired
                        Utility.ExpireSession(context);
                    }
                }
            }
            catch
            {
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Scan button click event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnScan_Click(object sender, EventArgs e)
        {
            
            try
            {
                if ((ContextCompat.CheckSelfPermission(context, Manifest.Permission.Camera) == (int)Permission.Granted))
                {
                    SearchScannedShip();
                }
                else
                {
                    V4App.ActivityCompat.RequestPermissions(context, PermissionsLocation, 0);
                }
            }
            catch
            {
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }
       
        /// <summary>
        /// Search Scanned Shipment
        /// </summary>
        public async void SearchScannedShip()
        {
            try
            {
                Dialog dialog;
                AlertDialog.Builder alert = new AlertDialog.Builder(context);
                //To open barcode scanner and scan barcode
                scanner = new MobileBarcodeScanner();
                //var scanner = new ZXing.Mobile.MobileBarcodeScanner();
                var result = await scanner.Scan();
                var filterQuery = "";
                if (result != null)
                {
                    alert.SetView(Resource.Layout.dialog);
                    dialog = alert.Create();
                    dialog.Show();

                    dialog.SetCancelable(false);

                    TextView txtDialogHeader = dialog.FindViewById<TextView>(Resource.Id.txtDialogHeader);
                    TextView txtDialogBody = dialog.FindViewById<TextView>(Resource.Id.txtDialogBody);
                    Button btnProceed = dialog.FindViewById<Button>(Resource.Id.btnProceed);
                    Button btnCancel = dialog.FindViewById<Button>(Resource.Id.btnCancel);
                    TextView editTextCross = dialog.FindViewById<TextView>(Resource.Id.editTextCross);

                    txtDialogHeader.Text = Constants.strScanConf;
                    txtDialogBody.Text = Constants.strYouScan + Convert.ToString(result) + Constants.strWouldLike;
                    filterQuery = "filters='Load Num'=" + Convert.ToString(result) + "";
                    btnProceed.Click += delegate
                    {
                        SearchShipment(dialog, filterQuery);
                    };
                    btnCancel.Click += delegate
                    {
                        HideDialog(dialog);
                    };
                    editTextCross.Click += delegate
                    {
                        HideDialog(dialog);
                    };
                }
            }
            catch
            {
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Hide Dialog
        /// </summary>
        /// <param name="dialog"></param>
        private void HideDialog(Dialog dialog)
        {
            dialog.Hide();
        }

        /// <summary>
        /// Search Shipment
        /// </summary>
        /// <param name="dialog"></param>
        /// <param name="filterQuery"></param>
        private void SearchShipment(Dialog dialog, string filterQuery)
        {
            try
            {
                HistoryResultFragment objHistoryResultFragment = new HistoryResultFragment(context, filterQuery);
                V4App.FragmentManager objFragmentManager = Activity.SupportFragmentManager;
                V4App.FragmentTransaction objFragmentTrans = objFragmentManager.BeginTransaction();
                objFragmentTrans.Replace(Resource.Id.fragment_container, objHistoryResultFragment, "HistoryResultFragment").AddToBackStack("HistoryResultFragment");
                objFragmentTrans.Commit();
                if (dialog != null)
                {
                    dialog.Hide();
                }
            }
            catch(Exception e)
            {
                Console.Write(e.Message);
            }
        }

        /// <summary>
        /// Buton Cancel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnCancel_Click(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
        }

        /// <summary>
        /// Proceed Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnProceed_Click(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
        }

        /// <summary>
        /// Start Date Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StartDate(object sender, DatePickerDialog.DateSetEventArgs e)
        {
            try
            {
                txtOriginDate.Text = e.Date.ToString(Constants.dateFormatMMDDYYYY);
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
            }
        }

        /// <summary>
        /// EndDate
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EndDate(object sender, DatePickerDialog.DateSetEventArgs e)
        {
            try
            {
                txtEndDate.Text = e.Date.ToString(Constants.dateFormatMMDDYYYY);
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
            }
        }

        /// <summary>
        /// spinner_ItemSelected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void spinner_ItemSelected(object sender, AdapterView.ItemSelectedEventArgs e)
        {

        }

        /// <summary>
        /// IsValidated
        /// </summary>
        /// <returns></returns>
        public bool IsValidated()
        {
            try
            {
                if (!string.IsNullOrEmpty(txtOriginDate.Text) && string.IsNullOrEmpty(txtEndDate.Text))
                {
                    Toast.MakeText(Context, Constants.enterDate, ToastLength.Long).Show();
                    return false;
                }
                if (string.IsNullOrEmpty(txtOriginDate.Text) && !string.IsNullOrEmpty(txtEndDate.Text))
                {
                    Toast.MakeText(Context, Constants.fromDate, ToastLength.Long).Show();
                    return false;
                }
                DateTime originDate = DateTime.ParseExact(txtOriginDate.Text, Constants.dateFormatMMDDYYYY, null);

                DateTime endDate = DateTime.ParseExact(txtEndDate.Text, Constants.dateFormatMMDDYYYY, null);

                if (originDate > endDate)
                {
                    Toast.MakeText(Context, Constants.fromDate, ToastLength.Long).Show();
                    return false;
                }
                return true;
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
                return false;
            }
        }
    }
}