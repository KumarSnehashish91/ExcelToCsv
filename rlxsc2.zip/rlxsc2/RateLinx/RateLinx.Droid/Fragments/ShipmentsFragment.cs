using System;
using Android.OS;
using Android.Views;
using Android.Widget;
using Android.Support.Design.Widget;
using Android.Support.V4.View;
using RateLinx.Droid.Adapters;
using RateLinx.Droid.Utilities;
using RateLinx.APIs;
using Newtonsoft.Json.Linq;
using RateLinx.Helper;
using System.Threading.Tasks;
using Android.Support.V7.App;
using V4App = Android.Support.V4.App;
using RateLinx.Models;
using Newtonsoft.Json;
using Android.App;

namespace RateLinx.Droid.Fragments
{
    /// <summary>
    /// Meta Class
    /// </summary>
    public class ShipmentsFragment : V4App.Fragment, ViewPager.IOnPageChangeListener
    {
        #region Global Used variables
        TabLayout _tabs = null;
        ViewPager _pager = null;
        //bool isFirstTimeLoad = true;//Flag to avoid Creating Fragments many times
        private ActiveShipmentFragment ActiveShipment = null;
        private AwardedShipmentFragment AwardedShipment = null;
        private RecentShipmentFragment RecentShipment = null;
        Activity context = null;
        View view = null;
        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        public ShipmentsFragment(Activity context)
        {
            this.context = context;
        }

        /// <summary>
        /// Default constructor
        /// </summary>
        public ShipmentsFragment()
        { }

        /// <summary>
        /// Shipment details Fragment
        /// </summary>
        /// <param name="inflater"></param>
        /// <param name="container"></param>
        /// <param name="savedInstanceState"></param>
        /// <returns></returns>
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                // Use this to return your custom view for this Fragment
                view = inflater.Inflate(Resource.Layout.ShipmentsFragmentLayout, null);
                _pager = view.FindViewById<ViewPager>(Resource.Id.pager);
                _tabs = view.FindViewById<TabLayout>(Resource.Id.sliding_tabs);
                BindFragments();
                //if (!string.IsNullOrEmpty(CommanUtil.tokenNo))
                //{
                //    poolingInterval();
                //}
                return view;
            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                context.Finish();
                return view;
            }
        }

        /// <summary>
        /// Binding of Fragments
        /// </summary>
        private void BindFragments()
        {
            try
            {
                SetupViewPager(_pager);
                _tabs.SetupWithViewPager(_pager);
                setupTabIcons();
                _pager.AddOnPageChangeListener(this);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Set View Pager
        /// </summary>
        /// <param name="viewPager"></param>
        private void SetupViewPager(ViewPager viewPager)
        {
            try
            {
                InitFragment();
                //ShipmentPagerAdapter mPagerAdapter = new ShipmentPagerAdapter(ChildFragmentManager, context);
                //_pager.Adapter = mPagerAdapter;
                var toolbar = context.FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.app_bar);
                TextView TvHeaderTitle = toolbar.FindViewById<TextView>(Resource.Id.toolbar_title);
                toolbar.FindViewById<ImageView>(Resource.Id.imgBack).Visibility = ViewStates.Invisible;
                TvHeaderTitle.Text = Constants.strHomeTitle;
                ShipmentDetailedAdapter adapter = new ShipmentDetailedAdapter(ChildFragmentManager);
                adapter.AddFragment(ActiveShipment, Constants.strActive);
                adapter.AddFragment(AwardedShipment, Constants.strAwarded);
                adapter.AddFragment(RecentShipment, Constants.strRecent);
                viewPager.Adapter = adapter;
                viewPager.OffscreenPageLimit = 3;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Taba Icon
        /// </summary>
        private int[] tabIcons = {
            Resource.Drawable.activeiconpng,
            Resource.Drawable.awardedicon,
            Resource.Drawable.upcomingicon,
        };

        /// <summary>
        /// Set a position to tabicon
        /// </summary>
        private void setupTabIcons()
        {
            try
            {
                _tabs.GetTabAt(0).SetIcon(tabIcons[0]);
                _tabs.GetTabAt(1).SetIcon(tabIcons[1]);
                _tabs.GetTabAt(2).SetIcon(tabIcons[2]);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// assining all the fragments
        /// </summary>
        private void InitFragment()
        {
            try
            {
                ActiveShipment = new ActiveShipmentFragment(context);// new ActiveShipmentFragment(context);
                AwardedShipment = new AwardedShipmentFragment(context);// new AwardedShipmentFragment(context);
                RecentShipment = new RecentShipmentFragment(context);// new RecentShipmentFragment(context);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="state"></param>
        public void OnPageScrollStateChanged(int state)
        {
            //throw new NotImplementedException();
        }

        /// <summary>
        /// On Scroll View
        /// </summary>
        /// <param name="position"></param>
        /// <param name="positionOffset"></param>
        /// <param name="positionOffsetPixels"></param>
        public void OnPageScrolled(int position, float positionOffset, int positionOffsetPixels)
        {
            try
            {
                //ViewPagerAdapter adapter = new ViewPagerAdapter(context.SupportFragmentManager);
                if (position == 0)
                {
                    _tabs.GetTabAt(0).SetIcon(Resource.Drawable.activehovericonpng);
                    _tabs.GetTabAt(1).SetIcon(Resource.Drawable.awardedicon);
                    _tabs.GetTabAt(2).SetIcon(Resource.Drawable.upcomingicon);
                    //Constants.focusedFragment = Resource.Layout.ActiveFragment;
                    ActiveShipment.isFocused = true;
                    AwardedShipment.isFocused = false;
                    RecentShipment.isFocused = false;
                    ActiveShipment._timer.Start();
                    AwardedShipment._timer.Stop();
                    RecentShipment._timer.Stop();
                    ActiveShipment.OnTimedEvent();
                    ActiveShipment._timer.Enabled = true;
                    AwardedShipment._timer.Enabled = false;
                    RecentShipment._timer.Enabled = false;
                }
                else if (position == 1)
                {
                    _tabs.GetTabAt(1).SetIcon(Resource.Drawable.awardedhovericon);
                    _tabs.GetTabAt(0).SetIcon(Resource.Drawable.activeiconpng);
                    _tabs.GetTabAt(2).SetIcon(Resource.Drawable.upcomingicon);
                    //Constants.focusedFragment = Resource.Layout.AwardedFragment;
                    ActiveShipment.isFocused = false;
                    AwardedShipment.isFocused = true;
                    RecentShipment.isFocused = false;
                    ActiveShipment._timer.Stop();
                    AwardedShipment._timer.Start();
                    RecentShipment._timer.Stop();
                    AwardedShipment.OnTimedEvent();
                    ActiveShipment._timer.Enabled = false;
                    AwardedShipment._timer.Enabled = true;
                    RecentShipment._timer.Enabled = false;

                }
                else
                {
                    _tabs.GetTabAt(2).SetIcon(Resource.Drawable.upcominghovericon);
                    _tabs.GetTabAt(0).SetIcon(Resource.Drawable.activeiconpng);
                    _tabs.GetTabAt(1).SetIcon(Resource.Drawable.awardedicon);
                    //Constants.focusedFragment = Resource.Layout.RecentFragment;
                    ActiveShipment.isFocused = false;
                    AwardedShipment.isFocused = false;
                    RecentShipment.isFocused = true;
                    ActiveShipment._timer.Stop();
                    AwardedShipment._timer.Stop();
                    RecentShipment._timer.Start();
                    RecentShipment.OnTimedEvent();
                    ActiveShipment._timer.Enabled = false;
                    AwardedShipment._timer.Enabled = false;
                    RecentShipment._timer.Enabled = true;
                }
                //throw new NotImplementedException();
            }
            catch(Exception ex)
            {
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);                
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="position"></param>
        public void OnPageSelected(int position)
        {
            //throw new NotImplementedException();
        }       
    }
}