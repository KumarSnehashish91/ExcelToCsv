using System;
using System.Collections.Generic;
using V4App = Android.Support.V4.App;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Views;
using Android.Widget;
using RateLinx.APIs;
using RateLinx.Droid.Utilities;
using Newtonsoft.Json.Linq;
using RateLinx.Helper;
using RateLinx.Droid.Adapters;
using Newtonsoft.Json;
using Android.Graphics;
using System.Threading.Tasks;
using RateLinx.Droid.Activities;
using Com.Bumptech.Glide;
using RateLinx.Droid.ServiceModels;
using Java.Lang;

namespace RateLinx.Droid.Fragments
{
    /// <summary>
    /// History Result Fragment
    /// </summary>
    public class HistoryResultFragment : V4App.Fragment
    {

        #region Declaration of controls instances and variables 
        string varFilterQuery = string.Empty;
        string strToken = string.Empty;
        View historyResultView, viewLine = null;
        Activity context;
        View pagingLayoutView = null;
        LinearLayout lnrLayoutPaging = null;
        TextView pagingNumber = null;
        RelativeLayout lnrHistoryData = null;
        ListView lstViewHistoryResult = null;
        List<TextView> pagingTextViewArr = new List<TextView>();
        TextView TvHeaderTitle;
        ImageView imgHome;
        List <RateHistoryColumns> lstRateHistoryColumns = null;
        List<RateHistoryResult> lstHistoryResult = null;  // Declare History Result list
        TextView txtClientID, txtLocID, txtMode, txtRateType, txtLoadNo, txtAuctionStatus, txtRateStatus,
            txtDateOpened, txtRateDeadLine, txtShipFrom, txtShipTo, txtPickUp, txtReference, txtUserCreated, txtNoHistoryData, lblViewDetailsText;
        #endregion

        /// <summary>
        /// History Result Fragment
        /// </summary>
        /// <param name="context"></param>
        /// /// <param name="filterQuery"></param>
        public HistoryResultFragment(Activity context, string filterQuery)
        {
            this.context = context;
            varFilterQuery = filterQuery;
        }

        /// <summary>
        /// History Result Fragment : Layout Load Event
        /// </summary>
        /// <param name="inflater"></param>
        /// <param name="container"></param>
        /// <param name="savedInstanceState"></param>
        /// <returns></returns>
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                if (historyResultView == null)
                {
                    // Use this to return your custom view for this Fragment
                    historyResultView = inflater.Inflate(Resource.Layout.HistoryResult, container, false);
                    //Replace header text on home activity
                    var toolbar = context.FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.app_bar);
                    TvHeaderTitle = toolbar.FindViewById<TextView>(Resource.Id.toolbar_title);
                    toolbar.FindViewById<ImageView>(Resource.Id.imgBack).Visibility = ViewStates.Visible;
                    imgHome = toolbar.FindViewById<ImageView>(Resource.Id.imgBack);
                    imgHome.SetImageResource(Resource.Drawable.home);
                    imgHome.Click += ImgHome_Click;
                    GetControlsById();
                }
                return historyResultView;
            }
            catch
            {
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                return historyResultView;
            }
        }

        private void ImgHome_Click(object sender, EventArgs e)
        {
           
            Intent intent=new Intent(context, typeof(HomeActivity));
            //intent.AddFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
            // intent.AddFlags(ActivityFlags.NoAnimation);
            context.Finish();
            context.StartActivity(intent);
           // context.Finish();

        }

        /// <summary>
        /// Find Controls by id and generating controls
        /// </summary>
        public async void GetControlsById()
        {
            try
            {
                strToken = CommanUtil.tokenNo;
                lstViewHistoryResult = historyResultView.FindViewById<ListView>(Resource.Id.lstHistoryResult);
                lblViewDetailsText= historyResultView.FindViewById<TextView>(Resource.Id.lblViewDetailsText);
                viewLine = historyResultView.FindViewById<View>(Resource.Id.viewLine);
                lnrLayoutPaging = historyResultView.FindViewById<LinearLayout>(Resource.Id.lnrLayoutPaging);
                lnrHistoryData = historyResultView.FindViewById<RelativeLayout>(Resource.Id.lnrHistoryData);
                txtNoHistoryData = historyResultView.FindViewById<TextView>(Resource.Id.txtNoHistoryData);
                txtClientID = historyResultView.FindViewById<TextView>(Resource.Id.txtClientID);
                txtLocID = historyResultView.FindViewById<TextView>(Resource.Id.txtLocID);
                txtMode = historyResultView.FindViewById<TextView>(Resource.Id.txtMode);
                txtRateType = historyResultView.FindViewById<TextView>(Resource.Id.txtRateType);
                txtLoadNo = historyResultView.FindViewById<TextView>(Resource.Id.txtLoadNo);
                txtAuctionStatus = historyResultView.FindViewById<TextView>(Resource.Id.txtAuctionStatus);
                txtRateStatus = historyResultView.FindViewById<TextView>(Resource.Id.txtRateStatus);
                txtDateOpened = historyResultView.FindViewById<TextView>(Resource.Id.txtDateOpened);
                txtRateDeadLine = historyResultView.FindViewById<TextView>(Resource.Id.txtRateDeadLine);
                txtShipFrom = historyResultView.FindViewById<TextView>(Resource.Id.txtShipFrom);
                txtShipTo = historyResultView.FindViewById<TextView>(Resource.Id.txtShipTo);
                txtPickUp = historyResultView.FindViewById<TextView>(Resource.Id.txtPickUp);
                txtReference = historyResultView.FindViewById<TextView>(Resource.Id.txtReference);
                txtUserCreated = historyResultView.FindViewById<TextView>(Resource.Id.txtUserCreated);
                ImageView imgSeeDetails = historyResultView.FindViewById<ImageView>(Resource.Id.imgSeeDetails);
                Glide.With(context).Load(Resource.Drawable.detailIndicator).Into(imgSeeDetails);
                imgSeeDetails.SetBackgroundColor(Android.Graphics.Color.Transparent);
               
                await BindHistoryResult(varFilterQuery);
                Alerts.HideBusyLoader();
                lstViewHistoryResult.ItemClick += LstViewHistoryResult_ItemClick;
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
            }
        }

        /// <summary>
        /// Handle Header text
        /// </summary>
        public override void OnResume()
        {
            TvHeaderTitle.Text = Constants.strHistory;
            base.OnResume();
        }

        /// <summary>
        /// ListViewHistoryResult ItemClick Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LstViewHistoryResult_ItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            try
            {
                //Get position
                if (!Utility.FnIsOnline(context))
                {
                    Toast.MakeText(context, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                else
                {
                    if (CommanUtil.IsTimeOut())
                    {
                        int index = e.Position;
                        Intent redirectTo = new Intent(context, typeof(ShipmentsDetailedActivity));
                        redirectTo.PutExtra("compositeKey", Convert.ToString(lstHistoryResult[index].ClientID + "|" + lstHistoryResult[index].LoadNum + "|#"));
                        context.StartActivity(redirectTo);
                    }
                    else
                    {
                        //Toekn Exired
                        Utility.ExpireSession(context);
                    }
                }
            }
            catch
            {
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Bind History Result
        /// </summary>
        private async Task BindHistoryResult(string varFilterQuery)
        {
            try
            {
                int totalResult = await BindHistoryResult1(1, varFilterQuery);
                int pagingCount = totalResult / 20;
                if(totalResult>0 && pagingCount==0)
                {
                    pagingCount = 1;
                }
              
                for (int indexCount = 1; indexCount <= pagingCount; indexCount++)
                {
                    pagingLayoutView = context.LayoutInflater.Inflate(Resource.Layout.PagingLayout, null);
                    pagingNumber = pagingLayoutView.FindViewById<TextView>(Resource.Id.txtPagingNum);
                    pagingNumber.Text = Convert.ToString(indexCount);
                    pagingNumber.Tag = indexCount;
                    pagingNumber.PaintFlags = PaintFlags.UnderlineText;
                    pagingTextViewArr.Add(pagingNumber);
                    lnrLayoutPaging.AddView(pagingLayoutView);
                    if (pagingTextViewArr.Count != 0)
                    {
                        pagingTextViewArr[0].SetTextColor(Android.Graphics.Color.Red);
                    }
                }
                foreach (TextView Tv in pagingTextViewArr)
                {
                    int pageNum = Convert.ToInt32(Tv.Text);
                    Tv.Click += async delegate
                    {
                        if (!Utility.FnIsOnline(context))
                        {
                            Toast.MakeText(context, Constants.strNoInternet, ToastLength.Short).Show();
                            return;
                        }
                        await BindHistoryResult1(pageNum, varFilterQuery);
                    };
                }
               
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
            }
        }

        /// <summary>
        /// Bind History Result
        /// </summary>
        /// <param name="pageNum"></param>
        /// <param name="filterQuery"></param>
        public async Task<int> BindHistoryResult1(int pageNum, string filterQuery)
        {
            try
            {
                lnrLayoutPaging.Visibility = ViewStates.Invisible;
                lnrHistoryData.Visibility = ViewStates.Invisible;
                txtNoHistoryData.Visibility = ViewStates.Invisible;
                lblViewDetailsText.Visibility = ViewStates.Invisible;
                viewLine.Visibility = ViewStates.Invisible;
                int totalResult = 0;
                string query = string.Empty;
                if (filterQuery != "#")
                {
                    query = "Page=" + pageNum + "&PerPage=" + 20 + "&" + filterQuery;
                }
                else
                {
                    query = "Page=" + pageNum + "&PerPage=" + 20;
                }
                string uriHistoryResult = APIMethods.getHistoryResult + "?" + query;
                JObject jobject = null;
                //Get the service Helper Object
                var objServicehelper = new ServiceHelper();
                // create json object that holds the api values
                //Method Name
                string methodName = APIMethods.getHistoryResult;
                Alerts.showBusyLoader(context);
                //Get the Shipments
                var strResponse = await objServicehelper.GetRequest(strToken, uriHistoryResult, true);
                //Alerts.HideBusyLoader();
                if (strResponse != null)
                {
                    jobject = JObject.Parse(strResponse);
                    string historyResult = Convert.ToString(jobject["Results"]);
                    string rateHistoryColumns = Convert.ToString(jobject["Columns"]);
                    totalResult = Convert.ToInt32(Convert.ToString(jobject["Total"]));
                    if (totalResult != 0)
                    {
                        int pagingCount = totalResult / 20;
                        int count = 0;
                        lstHistoryResult = (List<RateHistoryResult>)JsonConvert.DeserializeObject(historyResult, typeof(List<RateHistoryResult>));
                        if (count == 0)
                        {
                            lstRateHistoryColumns = (List<RateHistoryColumns>)JsonConvert.DeserializeObject(rateHistoryColumns, typeof(List<RateHistoryColumns>));
                            count++;
                        }
                        txtClientID.Text = lstRateHistoryColumns[0].Label;
                        txtLocID.Text = lstRateHistoryColumns[1].Label;
                        txtMode.Text = lstRateHistoryColumns[2].Label;
                        txtRateType.Text = lstRateHistoryColumns[3].Label;
                        txtLoadNo.Text = lstRateHistoryColumns[4].Label;
                        txtAuctionStatus.Text = lstRateHistoryColumns[5].Label;
                        if (CommanUtil.ViewAs.ToUpper() == Constants.strCustomer.ToUpper())
                        {
                            txtRateStatus.Visibility = ViewStates.Gone;
                            txtRateStatus.Text = "";
                            txtDateOpened.Text = lstRateHistoryColumns[6].Label;
                            txtRateDeadLine.Text = lstRateHistoryColumns[7].Label;
                            txtShipFrom.Text = lstRateHistoryColumns[8].Label;
                            txtShipTo.Text = lstRateHistoryColumns[9].Label;
                            txtPickUp.Text = lstRateHistoryColumns[10].Label;
                            txtReference.Text = lstRateHistoryColumns[11].Label;
                            txtUserCreated.Text = lstRateHistoryColumns[12].Label;

                        }
                        else
                        {
                            txtRateStatus.Text = lstRateHistoryColumns[6].Label;
                            txtDateOpened.Text = lstRateHistoryColumns[7].Label;
                            txtRateDeadLine.Text = lstRateHistoryColumns[8].Label;
                            txtShipFrom.Text = lstRateHistoryColumns[9].Label;
                            txtShipTo.Text = lstRateHistoryColumns[10].Label;
                            txtPickUp.Text = lstRateHistoryColumns[11].Label;
                            txtReference.Text = lstRateHistoryColumns[12].Label;
                            txtUserCreated.Text = lstRateHistoryColumns[13].Label;
                        }
                        HistoryResultAdapter objHistoryResultAdapter = new HistoryResultAdapter(context, lstHistoryResult, lstRateHistoryColumns);
                        lstViewHistoryResult.Adapter = objHistoryResultAdapter;
                        if (totalResult != 0)
                        {
                            if (totalResult < 21)
                            {
                                lnrLayoutPaging.Visibility = ViewStates.Visible;
                                viewLine.Visibility = ViewStates.Visible;
                            }
                            else
                            {
                                viewLine.Visibility = ViewStates.Visible;
                                lnrLayoutPaging.Visibility = ViewStates.Visible;
                                if (pagingTextViewArr.Count != 0)
                                {
                                    foreach (TextView Tv in pagingTextViewArr)
                                    {
                                        Tv.SetTextColor(Android.Graphics.Color.White);
                                    }
                                    //setting selected paging number to red
                                    if (pageNum == 1)
                                    {
                                        pagingTextViewArr[0].SetTextColor(Android.Graphics.Color.Red);
                                    }
                                    else
                                    {
                                        pagingTextViewArr[pageNum - 1].SetTextColor(Android.Graphics.Color.Red);
                                    }
                                }
                            }
                            txtNoHistoryData.Visibility = ViewStates.Visible;
                            lnrHistoryData.Visibility = ViewStates.Visible;
                            lblViewDetailsText.Visibility = ViewStates.Visible;
                            lblViewDetailsText.Text = "(Tap on any row for details)";
                            txtNoHistoryData.Text = Convert.ToString(totalResult) + " " + Constants.strHistoryResult;
                        }
                        else
                        {

                        }
                    }
                    else
                    {
                        viewLine.Visibility = ViewStates.Gone;
                        lnrLayoutPaging.Visibility = ViewStates.Gone;
                        lnrHistoryData.Visibility = ViewStates.Gone;
                        txtNoHistoryData.Visibility = ViewStates.Visible;
                        lblViewDetailsText.Visibility = ViewStates.Visible;
                        lblViewDetailsText.Text = "";
                        txtNoHistoryData.Text = "0 " + Constants.strHistoryResult;
                    }
                }
                return totalResult;
            }
            catch
            {
                Alerts.HideBusyLoader();
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                return 0;
            }
        }

    }

}