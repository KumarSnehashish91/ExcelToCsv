using System;
using System.Collections.Generic;
using System.Linq;
using Android.App;
using Android.OS;
using Android.Views;
using Android.Widget;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;
using RateLinx.Models;
using Newtonsoft.Json;
using V4App = Android.Support.V4.App;
using RateLinx.Droid.Adapters;
using System.Threading.Tasks;
using System.Security;


namespace RateLinx.Droid.Fragments
{
    /// <summary>
    /// Meta Tag Recent Fragment
    /// </summary>
    public class RecentShipmentFragment : V4App.Fragment
    {
        #region Declaration of controls,variable,objects
        ListView lstViewRecentShipments = null;  //ListView for the recent shipment
        Activity context = null;
        string recentShipments = string.Empty;
        //int shipmentCount = 0;
        RecentShipmentAdapter.AdapterRecentShipments adptrRecentShipments = null;  //adapter for Recent Shipment
        List<RecentShipments> lstRecentShipments = null;
        // List<TrackList> lstTrackList = null;
        TextView txtRecentMsg = null;
        Spinner spinner = null;
        ArrayAdapter adapter = null;
        View view;
        LinearLayout lnrfilterLayout = null;
        bool isRecentIntervalAllow = true;
        public System.Timers.Timer _timer = new System.Timers.Timer();
        public bool isFocused = true;
        #endregion

        /// <summary>
        /// Initializing constrctor for activity
        /// </summary>
        /// <param name="context">Activity</param>
        public RecentShipmentFragment(Activity context)
        {
            this.context = context;
            lstRecentShipments = new List<RecentShipments>();
        }

        /// <summary>
        /// Recent Fragment View
        /// </summary>
        /// <param name="inflater"></param>
        /// <param name="container"></param>
        /// <param name="savedInstanceState"></param>
        /// <returns></returns>
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                base.OnCreateView(inflater, container, savedInstanceState);
                view = inflater.Inflate(Resource.Layout.RecentFragment, null);
                //Spinner
                spinner = view.FindViewById<Spinner>(Resource.Id.spinnerDriver);
                spinner.ItemSelected += new EventHandler<AdapterView.ItemSelectedEventArgs>(spinner_ItemSelected);
                adapter = ArrayAdapter.CreateFromResource(
                        context, Resource.Array.driver_array, Resource.Drawable.SpinnerCustomDesign);
                adapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
                spinner.Adapter = adapter;
                //Get the Recent Shipments List
                lstViewRecentShipments = view.FindViewById<ListView>(Resource.Id.lstViewRecentShipments);
                txtRecentMsg = view.FindViewById<TextView>(Resource.Id.txtRecentMsg);
                lnrfilterLayout = view.FindViewById<LinearLayout>(Resource.Id.lnrfilterLayout);
                adptrRecentShipments = null;
                _timer = new System.Timers.Timer();
                _timer.Interval = 6000;
                _timer.Elapsed += delegate
                {
                    context.RunOnUiThread(() =>
                    {
                        OnTimedEvent();
                    });
                };

                //_timer.Enabled = true;
                //RecentShipmentInterval();
                return view;
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                //Redirect To Login Page
                // Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                return view;
            }
        }

        /// <summary>
        /// Refresh the recent shipment data.
        /// </summary>
        /// <returns></returns>
        public async void RecentShipmentInterval()
        {
            try
            {
                while (isRecentIntervalAllow)
                {
                    BindRecentShipments();
                    await Task.Delay(6000);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public void OnTimedEvent()
        {
            if (isRecentIntervalAllow && isFocused)
            {
                BindRecentShipments();
                CommanUtil.stopThread();
            }
            else
            {
                _timer.Stop();
            }
        }

        /// <summary>
        /// Binding Recent Shipments
        /// </summary>
        public void BindRecentShipments()
        {
            try
            {
                //If Costomer Login Then Filter will be invisible
                if (CommanUtil.ViewAs == Constants.strCarrier)
                {
                    lnrfilterLayout.Visibility = ViewStates.Visible;
                }
                else
                {
                    lnrfilterLayout.Visibility = ViewStates.Gone;
                }
                //Bind Shipments
                //recentShipments = Utility.sharedPreferences.GetString("recentShipments", null);
                recentShipments = Constants.recentShipmentsList;
                if (!string.IsNullOrEmpty(recentShipments))
                {
                    lstRecentShipments.Clear();
                    lstRecentShipments = (List<RecentShipments>)JsonConvert.DeserializeObject(recentShipments, typeof(List<RecentShipments>));
                    if (lstRecentShipments != null && lstRecentShipments.Count > 0)
                    {
                        if (adptrRecentShipments == null)
                        {
                            adptrRecentShipments = new RecentShipmentAdapter.AdapterRecentShipments(context, lstRecentShipments, Activity);
                            lstViewRecentShipments.Adapter = adptrRecentShipments;
                        }
                        else
                        {
                            string strUserID = CommanUtil.userID;
                            if (filterOption == Constants.filterBy)
                            {
                                List<RecentShipments> tempRecentShipments = new List<RecentShipments>();
                                foreach (RecentShipments recentShipment in lstRecentShipments)
                                {
                                    if (recentShipment.DriverID.ToUpper() == strUserID.ToUpper())
                                    {
                                        RecentShipments obgRecent = new RecentShipments();
                                        obgRecent = recentShipment;
                                        tempRecentShipments.Add(obgRecent);
                                    }
                                }
                                if (tempRecentShipments != null && tempRecentShipments.Count > 0)
                                {
                                    lstRecentShipments = tempRecentShipments;
                                }
                                else
                                {
                                    txtRecentMsg.Visibility = ViewStates.Visible;
                                    lstViewRecentShipments.Visibility = ViewStates.Gone;
                                    txtRecentMsg.Text = Constants.RecentShipments;
                                    return;
                                }
                            }
                            adptrRecentShipments.context = context;
                            adptrRecentShipments.lstRecentShipments.Clear();
                            adptrRecentShipments.lstRecentShipments.AddRange(lstRecentShipments); //lstActiveShipments;
                            lstViewRecentShipments.Visibility = ViewStates.Visible;
                            txtRecentMsg.Visibility = ViewStates.Gone;
                            lstViewRecentShipments.Visibility = ViewStates.Visible;
                            adptrRecentShipments.NotifyDataSetChanged();
                        }
                    }
                    else
                    {
                        txtRecentMsg.Visibility = ViewStates.Visible;
                        lstViewRecentShipments.Visibility = ViewStates.Gone;
                        txtRecentMsg.Text = Constants.RecentShipments;
                    }
                }
                else
                {
                    txtRecentMsg.Visibility = ViewStates.Visible;
                    lstViewRecentShipments.Visibility = ViewStates.Gone;
                    txtRecentMsg.Text = Constants.RecentShipments;
                }
            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
            }
        }
        string filterOption = "";
        /// <summary>
        /// spinner or Dropdown list calling on change of driver
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void spinner_ItemSelected(object sender, AdapterView.ItemSelectedEventArgs e)
        {
            try
            {
                if (lstRecentShipments != null && lstRecentShipments.Count > 0)
                {
                    spinner = (Spinner)sender;
                    string strUserID = CommanUtil.userID;
                    filterOption = spinner.GetItemAtPosition(e.Position).ToString();
                    //BindFilteredShipment(filterOption);
                    BindRecentShipments();
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }
        /// <summary>
        /// Bind shipment according to filter
        /// </summary>
        public void BindFilteredShipment(string filterOption)
        {
            string strUserID = CommanUtil.userID;
            if (filterOption == Constants.filterBy)
            {
                List<RecentShipments> tempRecentShipments = new List<RecentShipments>();
                foreach (RecentShipments recentShipment in lstRecentShipments)
                {
                    if (recentShipment.DriverID.ToUpper() == strUserID.ToUpper())
                    {
                        RecentShipments obgRecent = new RecentShipments();
                        obgRecent = recentShipment;
                        tempRecentShipments.Add(obgRecent);
                    }
                }
                if (tempRecentShipments != null && tempRecentShipments.Count > 0)
                {
                    txtRecentMsg.Visibility = ViewStates.Gone;
                    lstViewRecentShipments.Visibility = ViewStates.Visible;
                    adptrRecentShipments = new RecentShipmentAdapter.AdapterRecentShipments(context, tempRecentShipments, Activity);
                }
                else
                {
                    txtRecentMsg.Visibility = ViewStates.Visible;
                    lstViewRecentShipments.Visibility = ViewStates.Gone;
                    txtRecentMsg.Text = Constants.RecentShipments;
                }
            }
            else
            {
                if (lstRecentShipments != null && lstRecentShipments.Count > 0)
                {
                    txtRecentMsg.Visibility = ViewStates.Gone;
                    lstViewRecentShipments.Visibility = ViewStates.Visible;
                    adptrRecentShipments = new RecentShipmentAdapter.AdapterRecentShipments(context, lstRecentShipments, Activity);
                }
                else
                {
                    txtRecentMsg.Visibility = ViewStates.Visible;
                    lstViewRecentShipments.Visibility = ViewStates.Gone;
                    txtRecentMsg.Text = Constants.RecentShipments;
                }
            }
            if (adptrRecentShipments != null)
            {
                lstViewRecentShipments.Adapter = adptrRecentShipments;
            }

            else
            {
                txtRecentMsg.Text = GetString(Resource.String.RecentShipments);
            }

        }

        /// <summary>
        /// OnResume get start the interval
        /// </summary>
        public override void OnResume()
        {
            if (isRecentIntervalAllow)
            {

            }
            else
            {
                isRecentIntervalAllow = true;
                //RecentShipmentInterval();
                _timer.Enabled = true;
                isFocused = true;
                _timer.Start();
                OnTimedEvent();
            }
            base.OnResume();
        }

        /// <summary>
        /// Stop the interval
        /// </summary>
        public override void OnPause()
        {
            if (isRecentIntervalAllow)
            {
                isRecentIntervalAllow = false;
                isFocused = false;
                _timer.Stop();
                _timer.Enabled = false;

            }
            else
            {
                //isRecentIntervalAllow = true;
                //RecentShipmentInterval();
            }
            base.OnPause();
        }

    }
}