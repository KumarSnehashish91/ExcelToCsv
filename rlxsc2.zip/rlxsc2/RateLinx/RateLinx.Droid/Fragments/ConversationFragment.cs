using System;
using System.Collections.Generic;
using System.Linq;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Views;
using Android.Widget;
using V4App = Android.Support.V4.App;
using RateLinx.Droid.Activities;
using RateLinx.Droid.Utilities;
using Newtonsoft.Json;
using RateLinx.Models;
using RateLinx.Helper;
using URI = Android.Net;
using JavaFile = Java.IO.File;
using System.Threading.Tasks;
using RateLinx.APIs;
using Newtonsoft.Json.Linq;
using Android.Content.Res;
using Com.Bumptech.Glide;
using RateLinx.Droid.FileHelper;
using Android.Support.V4.Content;
using Android;
using Android.Content.PM;

namespace RateLinx.Droid.Fragments
{
    /// <summary>
    /// Conversation Fragment 
    /// </summary>
    public class ConversationFragment : V4App.Fragment
    {
        #region Declaration of controls instances and variables 
        static bool showHideTabIndicator = true;
        Activity context;
        ImageView imgComposeMsg, upDownImage = null;
        CarrierShipmentDetails carrierShipmentDetail = null;
        string shipmentDetails = string.Empty;
        LinearLayout lnrConversations, lnrConversChildContainer = null;
        Intent imageIntent = null;
        URI.Uri selectedURI = null;
        LinearLayout lnrReplaySectionHeader;
        JavaFile file = null;
        bool closeReplySection = false;
        byte[] bytes = null;
        JObject jobject = null;
        CommanUtil objUtility = null;
        string apiMethod = string.Empty;
        string shipmentId = string.Empty;
        ServiceHelper objServiceHelper = null;
        View viewConversationHeading, conversationFragment = null;
        List<Conversation> lstConversation, lstConverHead, tempListConversation, templist = null;
        List<RelativeLayout> lstHeadingLayouts, lstReplies = null;
        List<LinearLayout> lstChildLayouts, lstReplySections, lstTabIndicator = null;
        LinearLayout lnrLinearLayoutMsgReply;
        LayoutInflater inflater = null;
        ImageView btnCloseReply;
        bool isGalaryOpened = false;
        TextView txtIndicator;
        readonly string[] PermissionsLocation =
                        {
         Manifest.Permission.WriteExternalStorage };
        TextView lblFile_Name, txtFileName;
        #endregion

        /// <summary>
        /// Conversation Fragment
        /// </summary>
        /// <param name="context"></param>
        public ConversationFragment(Activity context)
        {
            this.context = context;
        }

        /// <summary>
        /// creating view through fragment for Conversation fragment
        /// </summary>
        /// <param name="inflater"></param>
        /// <param name="container"></param>
        /// <param name="savedInstanceState"></param>
        /// <returns></returns>
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                // Use this to return your custom view for this Fragment
                conversationFragment = inflater.Inflate(Resource.Layout.ConversationFragment, container, false);
                viewConversationHeading = inflater.Inflate(Resource.Layout.ConversationHeading, container, false);
                TextView txtConversationMaster = conversationFragment.FindViewById<TextView>(Resource.Id.txtConversationMaster);
                imgComposeMsg = conversationFragment.FindViewById<ImageView>(Resource.Id.imgComposeMsg);
                lnrConversations = conversationFragment.FindViewById<LinearLayout>(Resource.Id.lnrConversations);
                shipmentDetails = Utility.sharedPreferences.GetString(Constants.shipmentDetails, null);
                if (!string.IsNullOrEmpty(shipmentDetails))
                {
                    carrierShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(shipmentDetails);
                }
                lstConversation = carrierShipmentDetail.Conversations;
                if (lstConversation != null)
                {
                    txtConversationMaster.Text = Constants.ConversationHeader;
                    BindConversations(lstConversation);//Binding conversation list to the conversation layout
                }
                else
                {
                    txtConversationMaster.Text = Constants.NoMsgFound;
                }
                imgComposeMsg.Click += ImgComposeMsg_Click;

                return conversationFragment;
            }
            catch
            {
                return conversationFragment;
            }
        }



        /// <summary>
        /// Binding of Conversation
        /// </summary>
        /// <param name="lstConversation"></param>
        private void BindConversations(List<Conversation> lstConversation)
        {
            try
            {
                lstHeadingLayouts = new List<RelativeLayout>();//list of heading relative layouts
                lstChildLayouts = new List<LinearLayout>();//list of child linear layouts
                lstReplySections = new List<LinearLayout>();//list of reply section layouts
                lstConverHead = new List<Conversation>();//list of head of conversation from list conversation
                lstTabIndicator = new List<LinearLayout>();//list of tab indicatory linear layouts
                lstReplies = new List<RelativeLayout>();//list of reply section relative layouts

                foreach (Conversation objConversation in lstConversation)
                {
                    if (objConversation.Level == 0)
                    {
                        lstConverHead.Add(objConversation);
                    }
                }
                //creating new object of LayoutInflater class
                inflater = (LayoutInflater)context.GetSystemService(Context.LayoutInflaterService);
                tempListConversation = lstConversation;// storing list of conversation to a temparory list
                // adding a new conversation object without data in the temp list of conversation to break when there is nothing in the list
                tempListConversation.Add(new Conversation());
                //temparory conversation list to contain iterated conversation  list for one heading
                templist = new List<Conversation>();
                int count = 1;// variable declaration for assigning dynamic id to dynamically generated controls 
                for (int indexTemp = 0; indexTemp < lstConverHead.Count; indexTemp++)
                {
                    if (templist.Count > 0)
                    {
                        tempListConversation.RemoveRange(0, templist.Count); //removing iterated conversation list from temp list for one heading
                    }
                    templist.Clear();//clearing temp list to keep next list of conversation for next heading.
                    int indexLabel = 0;//variable declaration to check the conversation list for level 0 or more 
                    viewConversationHeading = inflater.Inflate(Resource.Layout.ConversationHeading, null, false);
                    LinearLayout lnrHeading = new LinearLayout(context);// New linear layout for containing dyanamically created heading
                    TextView txtSubject = viewConversationHeading.FindViewById<TextView>(Resource.Id.txtSubject);
                    TextView txtDateTime = viewConversationHeading.FindViewById<TextView>(Resource.Id.txtDateTime);
                    TextView txtFromTo = viewConversationHeading.FindViewById<TextView>(Resource.Id.txtFromTo);
                    RelativeLayout relConversationHead = viewConversationHeading.FindViewById<RelativeLayout>(Resource.Id.relConversationHead);
                    LinearLayout lnrReplySection = viewConversationHeading.FindViewById<LinearLayout>(Resource.Id.lnrReplySection);
                    btnCloseReply = viewConversationHeading.FindViewById<ImageView>(Resource.Id.btnCloseReply);
                    lnrReplaySectionHeader = viewConversationHeading.FindViewById<LinearLayout>(Resource.Id.lnrReplaySectionHeader);
                    upDownImage = viewConversationHeading.FindViewById<ImageView>(Resource.Id.upDownImage);
                    lstReplySections.Add(lnrReplySection);
                    relConversationHead.Id = 1000 + count;
                    lnrConversChildContainer = viewConversationHeading.FindViewById<LinearLayout>(Resource.Id.lnrConversChildContainer);
                    lnrConversChildContainer.Id = 10000 + count;
                    txtSubject.Text = lstConverHead[indexTemp].Subject;

                    txtDateTime.Text = lstConverHead[indexTemp].TimeStamp.Remove(18, 3);
                    txtDateTime.Text = txtDateTime.Text.Remove(10, 2);
                    txtDateTime.Text = txtDateTime.Text.Insert(10, " at ");
                    if (txtDateTime.Text.Length > 21)
                    {
                        txtDateTime.Text = txtDateTime.Text.Remove(21, 1);
                    }
                    txtFromTo.Text = "From: " + lstConverHead[indexTemp].FromClient + "(" + lstConverHead[indexTemp].FromUser + ") To:" + lstConverHead[indexTemp].ToList;
                    relConversationHead.SetBackgroundResource(Resource.Color.accordion_heading);
                    lstHeadingLayouts.Add(relConversationHead);
                    lstChildLayouts.Add(lnrConversChildContainer);
                    relConversationHead.Click += delegate
                    {
                        ShowHideConversation(lstHeadingLayouts, lstChildLayouts, relConversationHead.Id, lstReplySections, lstReplies);
                    };
                    foreach (Conversation conversation in tempListConversation)
                    {
                        if (indexLabel == 0 && conversation.Level == 0)
                        {
                            CreateChildConversation(conversation, lnrReplySection);
                        }
                        else if (conversation.Level != 0)
                        {
                            CreateChildConversation(conversation, lnrReplySection);
                        }
                        else
                        {
                            lnrHeading.AddView(viewConversationHeading);
                            lnrConversations.AddView(lnrHeading);
                            count++;
                            break;
                        }
                        indexLabel++;
                    }

                }
                if (Utility.ActiveConversationHeader != 0 && Utility.isReplied)
                {
                    ShowHideConversation(lstHeadingLayouts, lstChildLayouts, Utility.ActiveConversationHeader, lstReplySections, lstReplies);
                    Utility.ActiveConversationHeader = 0;
                    Utility.isReplied = false;
                }
                else
                {
                    Utility.ActiveConversationHeader = 0;
                    Utility.isReplied = false;
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Creating Child Conversation list
        /// </summary>
        /// <param name="conversation"></param>
        /// <param name="lnrReplySection"></param>
        private void CreateChildConversation(Conversation conversation, LinearLayout lnrReplySection)
        {
            try
            {
                View viewConversationChild = inflater.Inflate(Resource.Layout.ConversationChild, null, false);
                LinearLayout linLayout = new LinearLayout(context);
                TextView txtAttachment = viewConversationChild.FindViewById<TextView>(Resource.Id.txtAttachment);
                TextView txtAttachment2 = viewConversationChild.FindViewById<TextView>(Resource.Id.txtAttachment2);
                TextView txtAttachment3 = viewConversationChild.FindViewById<TextView>(Resource.Id.txtAttachment3);
                TextView txtMessage = viewConversationChild.FindViewById<TextView>(Resource.Id.txtMessage);
                TextView txtDateTimeStamp = viewConversationChild.FindViewById<TextView>(Resource.Id.txtDateTimeStamp);
                TextView txtFrom = viewConversationChild.FindViewById<TextView>(Resource.Id.txtFrom);
                RelativeLayout replyLayout = viewConversationChild.FindViewById<RelativeLayout>(Resource.Id.replyLayout);
                RelativeLayout relrepliesLayout = viewConversationChild.FindViewById<RelativeLayout>(Resource.Id.relrepliesLayout);
                LinearLayout lnrTabIndicator = viewConversationChild.FindViewById<LinearLayout>(Resource.Id.lnrTabIndicator);
                RelativeLayout.LayoutParams layoutParamschat = (RelativeLayout.LayoutParams)relrepliesLayout.LayoutParameters;
                RelativeLayout.LayoutParams layoutParamstabIndicator = (RelativeLayout.LayoutParams)lnrTabIndicator.LayoutParameters;
                ImageView imgChat = viewConversationChild.FindViewById<ImageView>(Resource.Id.imgChat);
                txtIndicator = viewConversationChild.FindViewById<TextView>(Resource.Id.txtIndicator);

                lnrLinearLayoutMsgReply = viewConversationChild.FindViewById<LinearLayout>(Resource.Id.lnrLinearLayoutMsgReply);
                lstTabIndicator.Add(lnrTabIndicator);
                if (conversation.ClientType.ToUpper().Trim() == Constants.strCustomer)
                {
                    imgChat.SetImageResource(Resource.Drawable.building_icon);
                }
                else
                {
                    imgChat.SetImageResource(Resource.Drawable.truck_icon);
                }
                if (conversation.ClientType == CommanUtil.ViewAs)
                {
                    layoutParamschat.RemoveRule(LayoutRules.AlignParentRight);
                    layoutParamschat.AddRule(LayoutRules.AlignParentRight);

                    layoutParamstabIndicator.RemoveRule(LayoutRules.AlignParentLeft);
                    layoutParamstabIndicator.AddRule(LayoutRules.AlignParentLeft);
                    relrepliesLayout.SetBackgroundResource(Resource.Drawable.red);
                    lnrTabIndicator.Visibility = ViewStates.Gone;
                }
                else
                {
                    layoutParamschat.AddRule(LayoutRules.AlignParentLeft);
                    relrepliesLayout.SetBackgroundResource(Resource.Drawable.grey);
                    lstReplies.Add(relrepliesLayout);
                    if (showHideTabIndicator)
                    {
                        lnrTabIndicator.Visibility = ViewStates.Visible;
                    }
                    layoutParamstabIndicator.AddRule(LayoutRules.AlignParentRight);
                }
                txtMessage.Text = conversation.Message;
                txtDateTimeStamp.Text = conversation.TimeStamp.Remove(18, 3);
                txtDateTimeStamp.Text = txtDateTimeStamp.Text.Remove(10, 2);
                txtDateTimeStamp.Text = txtDateTimeStamp.Text.Insert(10, " at ");
                if (txtDateTimeStamp.Text.Length > 21)
                {
                    txtDateTimeStamp.Text = txtDateTimeStamp.Text.Remove(21, 1);
                }
                txtFrom.Text = "From: " + conversation.FromClient + "(" + conversation.FromUser + ")";

                txtAttachment.Visibility = ViewStates.Gone;
                txtAttachment2.Visibility = ViewStates.Gone;
                txtAttachment3.Visibility = ViewStates.Gone;
                if (conversation.Attachments != null && conversation.Attachments.Count > 0)
                {
                    for (int attachmentCount = 0; attachmentCount < conversation.Attachments.Count; attachmentCount++)
                    {
                        string strAttachment = conversation.Attachments[attachmentCount].Split('/').Last();
                        if (attachmentCount == 0)
                        {
                            if (!string.IsNullOrEmpty(strAttachment))
                            {
                                txtAttachment.Text = strAttachment;
                            }
                            txtAttachment.Visibility = ViewStates.Visible;
                            txtAttachment.Click += delegate
                            {
                                OpenFileInWebView(conversation.Attachments[0]);
                            };

                        }
                        else if (attachmentCount == 1)
                        {
                            if (!string.IsNullOrEmpty(strAttachment))
                            {
                                txtAttachment2.Text = strAttachment;
                            }
                            txtAttachment2.Visibility = ViewStates.Visible;
                            txtAttachment2.Click += delegate
                            {
                                OpenFileInWebView(conversation.Attachments[1]);
                            };

                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(strAttachment))
                            {
                                txtAttachment3.Text = strAttachment;
                            }
                            txtAttachment3.Visibility = ViewStates.Visible;
                            txtAttachment3.Click += delegate
                            {
                                OpenFileInWebView(conversation.Attachments[2]);
                            };

                        }
                    }

                }
                relrepliesLayout.Click += delegate
                {
                    if (conversation.ClientType != CommanUtil.ViewAs)
                    {
                        if (Utility.replySectionIsClosed == true)
                        {
                            Utility.replySectionIsClosed = false;
                            ShowHideReplySection(relrepliesLayout, lnrReplySection, conversation, lstTabIndicator, lstReplies);
                        }
                        else
                        {
                            Utility.replySectionIsClosed = true;
                            ShowHideReplySection(relrepliesLayout, lnrReplySection, conversation, lstTabIndicator, lstReplies);
                        }
                    }
                };

                btnCloseReply.Click += delegate
                 {
                     if (conversation.ClientType != CommanUtil.ViewAs)
                     {
                         if (Utility.replySectionIsClosed == false)
                         {
                             Utility.replySectionIsClosed = true;
                             lnrReplySection.Visibility = ViewStates.Gone;
                             lnrReplaySectionHeader.Visibility = ViewStates.Gone;
                             relrepliesLayout.SetBackgroundResource(Resource.Drawable.grey);
                         }
                     }
                     txtFileName.Text = string.Empty;
                     lblFile_Name.Visibility = ViewStates.Gone;

                 };
                lnrConversChildContainer.AddView(viewConversationChild);
                templist.Add(conversation);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        /// <summary>
        /// Open uploaded Files In WebView
        /// </summary>
        /// <param name="attachmentUrl"></param>
        private void OpenFileInWebView(string attachmentUrl)
        {
            try
            {
                Utility.ViewUploadedFile(attachmentUrl, context);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Show And Hide With Reply Section
        /// </summary>
        /// <param name="lnrLayoutClicked"></param>
        /// <param name="lnrReplySection"></param>
        /// <param name="conversation"></param>
        /// <param name="lstTabIndicators"></param>
        /// <param name="lstReplies"></param>
        private void ShowHideReplySection(RelativeLayout lnrLayoutClicked, LinearLayout lnrReplySection, Conversation conversation, List<LinearLayout> lstTabIndicators, List<RelativeLayout> lstReplies)
        {
            try
            {
                ImageView imgFileUpload = lnrReplySection.FindViewById<ImageView>(Resource.Id.imgFileUpload);
                ImageView imgSendReply = lnrReplySection.FindViewById<ImageView>(Resource.Id.imgSendReply);
                EditText txtReplyMsg = lnrReplySection.FindViewById<EditText>(Resource.Id.txtReplyMsg);
                txtFileName= lnrReplySection.FindViewById<TextView>(Resource.Id.txtFileName);
                lblFile_Name = lnrReplySection.FindViewById<TextView>(Resource.Id.lblFile_Name);
                foreach (RelativeLayout replyLayout in lstReplies)
                {
                    if (conversation.ClientType != CommanUtil.ViewAs)
                    {
                        if (Utility.replySectionIsClosed == true)
                        {
                            lnrLayoutClicked.SetBackgroundResource(Resource.Drawable.grey);
                        }
                        else
                        {
                            lnrLayoutClicked.SetBackgroundResource(Resource.Drawable.blue);
                        }
                    }
                }
                if (lnrReplySection.Visibility == ViewStates.Visible)
                {
                    lnrReplySection.Visibility = ViewStates.Gone;
                    lnrReplaySectionHeader.Visibility = ViewStates.Gone;
                }
                else
                {
                    if (CommanUtil.ViewAs != conversation.ClientType)
                    {
                        lnrReplySection.Visibility = ViewStates.Visible;
                        lnrReplaySectionHeader.Visibility = ViewStates.Visible;
                    }
                }
                imgFileUpload.Click += delegate
                {
                    if (CommanUtil.IsTimeOut())
                    {
                        SelectFileToUpload(imgFileUpload);
                    }
                    else
                    {
                        Utility.ExpireSession(context);
                    }
                };

                imgSendReply.Click += delegate
                {
                    if (CommanUtil.IsTimeOut())
                    {
                        if (Utility.isReplied == false)
                        {
                            SendReply(txtReplyMsg.Text, conversation);
                        }
                        Utility.isReplied = true;
                    }
                    else
                    {
                        Utility.ExpireSession(context);
                    }
                };
            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// Select Files To Upload the contents
        /// </summary>
        /// <param name="imgFileUpload"></param>
        private void SelectFileToUpload(ImageView imgFileUpload)
        {
            try
            {
                //Enable Gps Setting and Get Current Location

                if ((ContextCompat.CheckSelfPermission(context, Manifest.Permission.WriteExternalStorage) == (int)Permission.Granted))
                {
                    if (!isGalaryOpened)
                    {
                        isGalaryOpened = true;
                        imageIntent = new Intent(Intent.ActionPick, Android.Provider.MediaStore.Images.Media.ExternalContentUri);
                        imageIntent.SetType("*/*");
                        imageIntent.PutExtra("return-data", true);
                        imageIntent.SetAction(Intent.ActionGetContent);
                        StartActivityForResult(
                            Intent.CreateChooser(imageIntent, Constants.strSelectFile), 0);
                        Alerts.HideBusyLoader();
                        imgFileUpload.Enabled = true;
                        imgFileUpload.Clickable = true;
                    }
                }
                else
                {
                    V4App.ActivityCompat.RequestPermissions(context, PermissionsLocation, 0);
                }



            }
            catch
            {
                isGalaryOpened = false;
            }
        }

        /// <summary>
        /// Send And Reply 
        /// </summary>
        /// <param name="txtMessage"></param>
        /// <param name="conversation"></param>
        private async void SendReply(string txtMessage, Conversation conversation)
        {
            try
            {
                string ChatReplyText = Resources.GetString(Resource.String.ChatReplyText);
                if (string.IsNullOrEmpty(txtMessage.Trim()))
                {
                    Toast.MakeText(context, ChatReplyText, ToastLength.Long).Show();
                }
                else
                {
                    shipmentId = CommanUtil.CompositeKey(carrierShipmentDetail.ClientID, carrierShipmentDetail.LocID, carrierShipmentDetail.BolNum);
                    apiMethod = APIMethods.shipmentDetails + "/" + shipmentId + "/" + APIMethods.msg;
                    objUtility = new CommanUtil();
                    string jsonRequest = string.Empty;
                    string jsonReplyRequest = string.Empty;
                    if (bytes != null)
                    {
                        Alerts.showBusyLoader(context);
                        string uploadResult = await UploadBitmapAsync(bytes);
                        if (!string.IsNullOrEmpty(uploadResult))
                        {
                            jobject = JObject.Parse(uploadResult);
                            if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
                            {
                                jsonRequest = FileUploadHelper.UploadsJsonRequest(uploadResult);
                                SaveReplyMessage(conversation, txtMessage, jsonRequest);
                            }
                            else
                            {
                                Alerts.HideBusyLoader();
                                Toast.MakeText(context, Convert.ToString(jobject[Constants.strErrorMessage]), ToastLength.Long).Show();
                                Utility.ErrorLog(Constants.strConversation, Convert.ToString(jobject[Constants.strErrorMessage]), CommanUtil.tokenNo, context);
                            }
                        }
                        else
                        {
                            Alerts.HideBusyLoader();
                            Toast.MakeText(context, Resources.GetString(Resource.String.choosFile), ToastLength.Long).Show();
                        }

                    }
                    else
                    {
                        Alerts.showBusyLoader(context);
                        SaveReplyMessage(conversation, txtMessage, string.Empty);
                    }
                }
            }
            catch
            {
                Alerts.HideBusyLoader();
                throw;
            }
        }

        /// <summary>
        /// Save Reply Message
        /// </summary>
        /// <param name="conversation"></param>
        /// <param name="txtMessage"></param>
        /// <param name="jsonRequest"></param>
        private async void SaveReplyMessage(Conversation conversation, string txtMessage, string jsonRequest)
        {
            try
            {
                string jsonReplyRequest = "{"
                                               + "\"ReplyToID\":" + "\"" + conversation.ID + "\","
                                               + "\"Message\":" + "\"" + txtMessage + "\","
                                               + "\"Files\":[" + jsonRequest
                                               + "]}";
                objServiceHelper = new ServiceHelper();
                string replyResult = await objServiceHelper.PostRequestJson(jsonReplyRequest, apiMethod, CommanUtil.tokenNo, true);
                if (replyResult != null)
                {
                    List<Conversation> lstConversation = (List<Conversation>)JsonConvert.DeserializeObject(replyResult, typeof(List<Conversation>));
                    CommanUtil.isReply = true;
                    bytes = null;
                    string value = carrierShipmentDetail.ClientID + "|" + carrierShipmentDetail.BolNum + "|" + "";
                    context.Finish();
                    Intent objIntent = Utility.RedirectTo(context, typeof(ShipmentsDetailedActivity), "compositeKey", value);
                    context.StartActivity(objIntent);
                    Alerts.HideBusyLoader();
                }
                else
                {
                    Alerts.HideBusyLoader();
                    Toast.MakeText(context, Constants.strReplyError, ToastLength.Long).Show();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Call back method to get the selected file url from device
        /// </summary>
        /// <param name="requestCode"></param>
        /// <param name="resultCode"></param>
        /// <param name="data"></param>
        public override void OnActivityResult(int requestCode, int resultCode, Intent data)
        {
            base.OnActivityResult(requestCode, resultCode, data);
            isGalaryOpened = false;
            try
            {
                if (resultCode == -1)
                {
                    selectedURI = data.Data;
                    string filePath = FileUploadHelper.GetFilePath(selectedURI, context);
                    if (!string.IsNullOrEmpty(filePath))
                    {
                        file = new JavaFile(filePath);
                        string fileName = FileUploadHelper.GetFileName(filePath);
                        txtFileName.Text = fileName;
                        lblFile_Name.Visibility = ViewStates.Visible;
                        // Conversion of selected file into bitmap and bytes
                        bytes = FileUploadHelper.ConvertFileIntoByte(filePath);
                    }
                    else
                    {
                        Toast.MakeText(context, Constants.strErrorFile, ToastLength.Long).Show();
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorFile, ToastLength.Long).Show();
            }

        }

        /// <summary>
        /// Upload Data in Bitmap 
        /// </summary>
        /// <param name="bytes"></param>
        /// <returns></returns>
        public async Task<string> UploadBitmapAsync(byte[] bytes)
        {
            try
            {
                FileUploadHelper objUploadHelper = null;
                string apiMethod = string.Empty;
                string token = CommanUtil.tokenNo;
                objUploadHelper = new FileUploadHelper();
                apiMethod = APIMethods.composeDocs;
                var response = await objUploadHelper.PostFiles(bytes, file, apiMethod, token, true);
                return response;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Show Hide Conversation List
        /// </summary>
        /// <param name="lstHeadingLayouts"></param>
        /// <param name="lstChildLayouts"></param>
        /// <param name="headerId"></param>
        /// <param name="lstReplySection"></param>
        /// <param name="lstReplies"></param>
        private void ShowHideConversation(List<RelativeLayout> lstHeadingLayouts, List<LinearLayout> lstChildLayouts, int headerId, List<LinearLayout> lstReplySection, List<RelativeLayout> lstReplies)
        {
            try
            {
                Utility.ActiveConversationHeader = headerId;
                foreach (LinearLayout lnrReply in lstReplySection)
                {
                    lnrReply.Visibility = ViewStates.Gone;
                }

                ExpandChildLayout(lstChildLayouts, headerId);
                ChangeHeadingBackground(lstHeadingLayouts, headerId);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Expand Child Layout
        /// </summary>
        /// <param name="lstChildLayouts"></param>
        /// <param name="headerId"></param>
        private void ExpandChildLayout(List<LinearLayout> lstChildLayouts, int headerId)
        {
            try
            {
                foreach (LinearLayout lnrchildLayout in lstChildLayouts)
                {
                    if (lnrchildLayout.Id == (10000 + (headerId - 1000)))
                    {
                        if (lnrchildLayout.Visibility == ViewStates.Visible)
                        {
                            lnrchildLayout.Visibility = ViewStates.Gone;
                        }
                        else
                        {
                            lnrchildLayout.Visibility = ViewStates.Visible;
                            lnrchildLayout.StartAnimation(new ScaleAnimToShow(1.0f, 1.0f, 1.0f, 0.0f, 500, lnrchildLayout, true));
                        }
                    }
                    else
                    {
                        lnrchildLayout.Visibility = ViewStates.Gone;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Changing Heading Background
        /// </summary>
        /// <param name="lstHeadingLayouts"></param>
        /// <param name="headerId"></param>
        private void ChangeHeadingBackground(List<RelativeLayout> lstHeadingLayouts, int headerId)
        {
            try
            {
                for (int indexHeader = 0; indexHeader < lstHeadingLayouts.Count; indexHeader++)
                {
                    if (lstHeadingLayouts[indexHeader].Id == headerId)
                    {
                        lstHeadingLayouts[indexHeader].SetBackgroundResource(Resource.Color.accordion_heading_hover);
                    }
                    else
                    {
                        lstHeadingLayouts[indexHeader].SetBackgroundResource(Resource.Color.accordion_heading);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Imgage Compose Msg Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgComposeMsg_Click(object sender, EventArgs e)
        {
            try
            {
                if (CommanUtil.IsTimeOut())
                {
                    Intent slideactivity = new Intent(context, typeof(ComposeMessageActivity));
                    Bundle bndlanimation = ActivityOptions.MakeCustomAnimation(context, Resource.Animation.abc_slide_in_bottom, Resource.Animation.abc_slide_out_bottom).ToBundle();
                    StartActivity(slideactivity, bndlanimation);
                }
                else
                {
                    Utility.ExpireSession(context);
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }
    }

}
