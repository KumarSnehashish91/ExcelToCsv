using System;
using System.Collections.Generic;
using System.Linq;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Views;
using Android.Widget;
using V4App = Android.Support.V4.App;
using RateLinx.Droid.Adapters;
using RateLinx.APIs;
using RateLinx.Droid.Utilities;
using Newtonsoft.Json.Linq;
using RateLinx.Models;
using Newtonsoft.Json;
using Android.Views.Animations;
using RateLinx.Droid.Activities;
using RateLinx.Helper;
using System.Threading.Tasks;
using Android;
using Android.Support.V4.Content;
using Android.Content.PM;

namespace RateLinx.Droid.Fragments
{
    /// <summary>
    /// Rate Detail Fragment
    /// </summary>
    public class RateDetailFragment : V4App.Fragment
    {
        #region Declaration of controls instances and variables 
        int visibility = 0;
        CarrierShipmentDetails lstShipmentDetail = null;
        ServiceHelper objServiceHelper = null;
        List<Address> objAddress = null;
        List<LineDetail> objDetails = null;
        List<Content> objCommodities = null;
        List<SS> objOptions = null;
        ListView lstViewOptions, lstViewAttribute = null;
        Spinner spinnerDrivers = null;
        Button btnAssignDriver, btnVoid, btnBlock, btnYes,btnNo = null;
        List<AssignableDriver> objAssignableDriver = null;
        OptionAdapter.OptionAdapterShipments OptionAdapterShipments = null;
        //Linear Layouts
        LinearLayout lnrTruckLoadDetails, linearAddressDetails, linrDetailsLayout, linrCommoditiesLayout,
            linrOptionLayout, linrAssignLayout, linrAttributesLayout, linrConfirmationLayout, lntlayoutReason = null;
        //ImageView
        ImageView imgZoomDetails, ImgDownIcon1, ImgDownIcon2, ImgDownIcon3, ImgDownIcon4, ImgDownIcon5,
            ImgDownIcon6, ImgDownIcon7, ImgDownIconAttribute, imgheader = null;
        //Relative Layouts
        RelativeLayout rlativeTruckHdr, rlativeAddressHdr, rlativeDetailHdr,
            rlativeCommoditiesHdr, rlativeOptionsHdr,
            rlativeAssignHdr, rlativeAttributeHdr, rlativeConfirmationHdr = null;
        TextView txtDialogHeader, txtMessage, txtAttributeHead, txtPickupDeliveryText = null;
        Dialog dialog = null;
        AlertDialog.Builder alert = null;
        Utility objUtility = null;
        string method = string.Empty;
        string data = string.Empty;
        string token = string.Empty;
        string destinationHeaderAddress = string.Empty;
        EditText txtEnterReason = null;
        bool forConfirmation = false;
        List<Entry> entries = null;
        Activity context;
        View RateDetails;
        LinearLayout lnrConfirmationButton;
        Intent slideactivity = null;
        Bundle bndlanimation = null;
        readonly string[] PermissionsLocation =
                       {
         Manifest.Permission.AccessCoarseLocation,
         Manifest.Permission.AccessFineLocation
        };
        #endregion

        /// <summary>
        /// Activity Context
        /// </summary>
        /// <param name="context"></param>
        public RateDetailFragment(Activity context)
        {
            this.context = context;
        }

        /// <summary>
        /// Rate Details Fragment
        /// </summary>
        /// <param name="inflater"></param>
        /// <param name="container"></param>
        /// <param name="savedInstanceState"></param>
        /// <returns></returns>
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                // Use this to return your custom view for this Fragment
                RateDetails = inflater.Inflate(Resource.Layout.RateDetailFragment, container, false);
                token = CommanUtil.tokenNo;
                //Find Controls
                FindControls();
                //Get Shipment detail and binding of data
                BindShipmentDetails();
                return RateDetails;
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, ex.Message, ToastLength.Long).Show();
                context.Finish();
                return RateDetails;
            }
        }

        /// <summary>
        /// Finding Contros Id And creating there click events
        /// </summary>
        private void FindControls()
        {
            #region Finding Controls Id And creating there click events
            //Get The Relative layout and change color dynamically
            rlativeTruckHdr = RateDetails.FindViewById<RelativeLayout>(Resource.Id.rlativeTruckHdr);
            rlativeAddressHdr = RateDetails.FindViewById<RelativeLayout>(Resource.Id.rlativeAddressHdr);
            rlativeDetailHdr = RateDetails.FindViewById<RelativeLayout>(Resource.Id.rlativeDetailHdr);
            rlativeOptionsHdr = RateDetails.FindViewById<RelativeLayout>(Resource.Id.rlativeOptionsHdr);
            rlativeAssignHdr = RateDetails.FindViewById<RelativeLayout>(Resource.Id.rlativeAssignHdr);
            rlativeCommoditiesHdr = RateDetails.FindViewById<RelativeLayout>(Resource.Id.rlativeCommoditiesHdr);
            rlativeConfirmationHdr = RateDetails.FindViewById<RelativeLayout>(Resource.Id.rlativeConfirmationHdr);
            txtPickupDeliveryText = RateDetails.FindViewById<TextView>(Resource.Id.txtPickupDeliveryText);
            lnrConfirmationButton = RateDetails.FindViewById<LinearLayout>(Resource.Id.lnrConfirmationButton);
            rlativeAttributeHdr = RateDetails.FindViewById<RelativeLayout>(Resource.Id.rlativeAttributeHdr);
            linrAttributesLayout = RateDetails.FindViewById<LinearLayout>(Resource.Id.linrAttributesLayout);
            lstViewAttribute = RateDetails.FindViewById<ListView>(Resource.Id.lstViewAttribute);
            txtAttributeHead = RateDetails.FindViewById<TextView>(Resource.Id.txtAttributeHead);
            //Finding Down Icon Control Id
            ImgDownIcon1 = RateDetails.FindViewById<ImageView>(Resource.Id.ImgDownIcon1);
            ImgDownIcon2 = RateDetails.FindViewById<ImageView>(Resource.Id.ImgDownIcon2);
            ImgDownIcon3 = RateDetails.FindViewById<ImageView>(Resource.Id.ImgDownIcon3);
            ImgDownIcon4 = RateDetails.FindViewById<ImageView>(Resource.Id.ImgDownIcon4);
            ImgDownIcon5 = RateDetails.FindViewById<ImageView>(Resource.Id.ImgDownIcon5);
            ImgDownIcon6 = RateDetails.FindViewById<ImageView>(Resource.Id.ImgDownIcon6);
            ImgDownIcon7 = RateDetails.FindViewById<ImageView>(Resource.Id.ImgDownIcon7);
            ImgDownIconAttribute = RateDetails.FindViewById<ImageView>(Resource.Id.ImgDownIconAttribute);
            //Get The Linear layout and change color dynamically
            lnrTruckLoadDetails = RateDetails.FindViewById<LinearLayout>(Resource.Id.linear_truck_load_details); //Truck Load Section
            btnVoid = RateDetails.FindViewById<Button>(Resource.Id.btnVoid);
            btnVoid.Click += BtnVoid_Click;
            btnBlock = RateDetails.FindViewById<Button>(Resource.Id.btnBlock);
            btnBlock.Click += BtnBlock_Click;
            linearAddressDetails = RateDetails.FindViewById<LinearLayout>(Resource.Id.linearAddressDetails); //Address
                                                                                                             //Detail Section
            linrDetailsLayout = RateDetails.FindViewById<LinearLayout>(Resource.Id.linrDetailsLayout);
            imgZoomDetails = RateDetails.FindViewById<ImageView>(Resource.Id.imgZoomDetails);
            imgZoomDetails.Click += ImgZoomDetails_Click;
            //Commodities Section
            linrCommoditiesLayout = RateDetails.FindViewById<LinearLayout>(Resource.Id.linrCommoditiesLayout);
            //option Section
            linrOptionLayout = RateDetails.FindViewById<LinearLayout>(Resource.Id.linrOptionLayout);
            //Assign Driver
            linrAssignLayout = RateDetails.FindViewById<LinearLayout>(Resource.Id.linrAssignLayout);
            //Confirmation
            linrConfirmationLayout = RateDetails.FindViewById<LinearLayout>(Resource.Id.linrConfirmationLayout);
            //Click events
            rlativeTruckHdr.Click += delegate
            {
                ShowExpandableLayout(rlativeTruckHdr, lnrTruckLoadDetails, ImgDownIcon1);
            };
            rlativeAddressHdr.Click += delegate
            {
                ShowExpandableLayout(rlativeAddressHdr, linearAddressDetails, ImgDownIcon2);
            };
            rlativeDetailHdr.Click += delegate
            {
                ShowExpandableLayout(rlativeDetailHdr, linrDetailsLayout, ImgDownIcon3);
            };
            rlativeOptionsHdr.Click += delegate
            {
                ShowExpandableLayout(rlativeOptionsHdr, linrOptionLayout, ImgDownIcon4);
            };
            rlativeAssignHdr.Click += delegate
            {
                ShowExpandableLayout(rlativeAssignHdr, linrAssignLayout, ImgDownIcon5);
            };
            rlativeConfirmationHdr.Click += delegate
            {
                ShowExpandableLayout(rlativeConfirmationHdr, linrConfirmationLayout, ImgDownIcon6);
            };
            rlativeCommoditiesHdr.Click += delegate
            {
                ShowExpandableLayout(rlativeCommoditiesHdr, linrCommoditiesLayout, ImgDownIcon7);
            };
            rlativeAttributeHdr.Click += delegate
             {
                 ShowExpandableLayout(rlativeAttributeHdr, linrAttributesLayout, ImgDownIconAttribute);
             };
            #endregion
        }

        /// <summary>
        /// Zoom button click event fro showing details in Popup
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgZoomDetails_Click(object sender, EventArgs e)
        {
            try
            {
                alert = new AlertDialog.Builder(context);
                alert.SetView(Resource.Layout.DetailsLayoutPopup);
                dialog = alert.Create();
                dialog.Show();
                Button btnOK = dialog.FindViewById<Button>(Resource.Id.btnOk);
                TextView editTextCross = dialog.FindViewById<TextView>(Resource.Id.editTextCross);
                BindPopDetails(dialog);
                btnOK.Click += delegate
                {
                    dialog.Hide();
                };
                editTextCross.Click += delegate
                {
                    dialog.Hide();
                };
                dialog.SetCancelable(false);
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Close Expanded Tab
        /// </summary>
        private void HideExpandableLayout()
        {
            #region Hide All Expandable layout
            lnrTruckLoadDetails.Visibility = ViewStates.Gone;
            rlativeTruckHdr.SetBackgroundResource(Resource.Color.accordion_heading);
            linearAddressDetails.Visibility = ViewStates.Gone;
            rlativeAddressHdr.SetBackgroundResource(Resource.Color.accordion_heading);
            linrDetailsLayout.Visibility = ViewStates.Gone;
            rlativeDetailHdr.SetBackgroundResource(Resource.Color.accordion_heading);
            linrOptionLayout.Visibility = ViewStates.Gone;
            rlativeOptionsHdr.SetBackgroundResource(Resource.Color.accordion_heading);
            linrAssignLayout.Visibility = ViewStates.Gone;
            rlativeAssignHdr.SetBackgroundResource(Resource.Color.accordion_heading);
            linrConfirmationLayout.Visibility = ViewStates.Gone;
            rlativeConfirmationHdr.SetBackgroundResource(Resource.Color.accordion_heading);
            linrCommoditiesLayout.Visibility = ViewStates.Gone;
            rlativeAttributeHdr.SetBackgroundResource(Resource.Color.accordion_heading);
            linrAttributesLayout.Visibility = ViewStates.Gone;
            rlativeCommoditiesHdr.SetBackgroundResource(Resource.Color.accordion_heading);
            ImgDownIcon1.SetImageResource(Resource.Drawable.tab_down);
            ImgDownIcon2.SetImageResource(Resource.Drawable.tab_down);
            ImgDownIcon3.SetImageResource(Resource.Drawable.tab_down);
            ImgDownIcon4.SetImageResource(Resource.Drawable.tab_down);
            ImgDownIcon5.SetImageResource(Resource.Drawable.tab_down);
            ImgDownIcon6.SetImageResource(Resource.Drawable.tab_down);
            ImgDownIcon7.SetImageResource(Resource.Drawable.tab_down);
            ImgDownIconAttribute.SetImageResource(Resource.Drawable.tab_down);
            #endregion
        }

        /// <summary>
        /// Show Expandable Layout on click of Layout Header
        /// </summary>
        /// <param name="rlvLayout">Header Relative Layout ID</param>
        /// <param name="lnrLayout">Content container Linear Layout</param>
        /// <param name="imgIcon">Image Icon ID </param>
        private void ShowExpandableLayout(RelativeLayout rlvLayout, LinearLayout lnrLayout, ImageView imgIcon)
        {
            try
            {
                visibility = Convert.ToInt32(lnrLayout.Visibility);
                if (visibility != Convert.ToInt32(ViewStates.Visible))
                {
                    HideExpandableLayout();
                    rlvLayout.SetBackgroundResource(Resource.Color.accordion_heading_hover);
                    imgIcon.SetImageResource(Resource.Drawable.tab_down2);
                    lnrLayout.Visibility = ViewStates.Visible;
                    lnrLayout.StartAnimation(new ScaleAnimToShow(1.0f, 1.0f, 1.0f, 0.0f, 500, lnrLayout, true));
                }
                else
                {
                    lnrLayout.Visibility = ViewStates.Gone;
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Binding Shipement Details
        /// </summary>
        private void BindShipmentDetails()
        {

            string shipmentDetails = string.Empty;
            shipmentDetails = Utility.sharedPreferences.GetString(Constants.shipmentDetails, null);

            if (string.IsNullOrEmpty(shipmentDetails))
            {
                return;
            }
            lstShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(shipmentDetails);
            if (lstShipmentDetail != null)
            {
                BindTruckDetails(); //Truck Load Details 
                BindAddressDetails(); //Address Details
                BindDetails(RateDetails); //Details section
                BindOptions(); //Option section
                BindAttributes(); //Option section
                                  //Manage Confirmation Pickup / Delivery
                if (lstShipmentDetail.Status.ToUpper() == Constants.strClosed.ToUpper())
                {
                    entries = new List<Entry>();
                    entries = lstShipmentDetail.Entries;
                    forConfirmation = entries.Count(entry => entry.Status == Constants.strCONFIRMED) > 0;
                }
                if (forConfirmation)
                {
                    if (lstShipmentDetail.DispatchFlag)
                    {
                        CommanUtil.shipmentType = Constants.dispatcher;
                    }
                    else
                    {
                        CommanUtil.shipmentType = Constants.strCustomer;
                    }
                    rlativeConfirmationHdr.Visibility = ViewStates.Visible;
                    BindConfirmation();
                }
                else
                {
                    rlativeConfirmationHdr.Visibility = ViewStates.Gone;
                }
                rlativeAssignHdr.Visibility = ViewStates.Gone;
                //Commodities Section
                if (lstShipmentDetail.Contents != null && lstShipmentDetail.Contents.Count > 0)
                {
                    rlativeCommoditiesHdr.Visibility = ViewStates.Visible;
                    BindCommodities(RateDetails);
                }
                else
                {
                    rlativeCommoditiesHdr.Visibility = ViewStates.Gone;
                }
            }
            else
            {
                Toast.MakeText(context, Constants.NoMsgFound, ToastLength.Short).Show();
            }

        }

        /// <summary>
        /// Binding Trcuk Details in Trck Detail Accordian
        /// </summary>
        private void BindTruckDetails()
        {
            if (lstShipmentDetail != null)
            {
                if (!string.IsNullOrEmpty(lstShipmentDetail.BolNum))
                {
                    bool isShowCharges = CommanUtil.isShowCharges;
                    #region Finding Controls
                    TextView txtTruckLoadReq = RateDetails.FindViewById<TextView>(Resource.Id.txtTruckLoadReq);
                    TextView txtTruckLowestPrice = RateDetails.FindViewById<TextView>(Resource.Id.txtTruckLowestPrice);
                    TextView txtloadNoVal = RateDetails.FindViewById<TextView>(Resource.Id.txtloadNoVal);
                    TextView txtPickUpNoVal = RateDetails.FindViewById<TextView>(Resource.Id.txtPickUpNoVal);
                    TextView txtStatusVal = RateDetails.FindViewById<TextView>(Resource.Id.txtStatusVal);
                    TextView txtDateopenVal = RateDetails.FindViewById<TextView>(Resource.Id.txtDateopenVal);
                    TextView txtStartingPriceVal = RateDetails.FindViewById<TextView>(Resource.Id.txtStartingPriceVal);
                    LinearLayout lntlayoutStartingPrice = RateDetails.FindViewById<LinearLayout>(Resource.Id.lntlayoutStartingPrice);
                    TextView txtUserCreatedVal = RateDetails.FindViewById<TextView>(Resource.Id.txtUserCreatedVal);
                    TextView txtDateAwardedVal = RateDetails.FindViewById<TextView>(Resource.Id.txtDateAwardedVal);
                    LinearLayout lntlayoutSentCarriers = RateDetails.FindViewById<LinearLayout>(Resource.Id.lntlayoutSentCarriers);

                    TextView txtSentCarriersVal = RateDetails.FindViewById<TextView>(Resource.Id.txtSentCarriersVal);
                    TextView txtSentCarriers = RateDetails.FindViewById<TextView>(Resource.Id.txtSentCarriers);
                    LinearLayout lntlayoutInvoiceCreatedOn = RateDetails.FindViewById<LinearLayout>(Resource.Id.lntlayoutInvoiceCreatedOn);
                    TextView txtInvoiceCreatedOn = RateDetails.FindViewById<TextView>(Resource.Id.txtInvoiceCreatedOn);
                    TextView txtInvoiceCreatedOnVal = RateDetails.FindViewById<TextView>(Resource.Id.txtInvoiceCreatedOnVal);
                    LinearLayout lntlayoutLwPrice = RateDetails.FindViewById<LinearLayout>(Resource.Id.lntlayoutLwPrice);
                    TextView txtlowestPrice = RateDetails.FindViewById<TextView>(Resource.Id.txtlowestPrice);
                    TextView txtRateVal = RateDetails.FindViewById<TextView>(Resource.Id.txtRateVal);
                    TextView txtRateDeadVal = RateDetails.FindViewById<TextView>(Resource.Id.txtRateDeadVal);
                    TextView txtPickOnVal = RateDetails.FindViewById<TextView>(Resource.Id.txtPickOnVal);
                    TextView txtDeliverOnVal = RateDetails.FindViewById<TextView>(Resource.Id.txtDeliverOnVal);
                    TextView txtDriverVal = RateDetails.FindViewById<TextView>(Resource.Id.txtDriverVal);
                    TextView txtReference = RateDetails.FindViewById<TextView>(Resource.Id.txtReference);
                    TextView txtReferenceVal = RateDetails.FindViewById<TextView>(Resource.Id.txtReferenceVal);
                    TextView txtCommentVal = RateDetails.FindViewById<TextView>(Resource.Id.txtCommentVal);
                    TextView txtClientStmtVal = RateDetails.FindViewById<TextView>(Resource.Id.txtClientStmtVal);
                    //LinearLayout 
                    #endregion
                    txtTruckLoadReq.Text = lstShipmentDetail.Mode + Constants.strREQUEST;
                    if (isShowCharges)
                    {
                        if (lstShipmentDetail.LowestPrice > 0)
                        {
                            txtTruckLowestPrice.Text = lstShipmentDetail.LowestPriceLbl + " : $" + lstShipmentDetail.LowestPrice;
                            lntlayoutLwPrice.Visibility = ViewStates.Visible;
                            txtlowestPrice.Text = lstShipmentDetail.LowestPriceLbl + " : $" + lstShipmentDetail.LowestPrice;
                        }
                        else
                        {
                            txtTruckLowestPrice.Visibility = ViewStates.Gone;
                            lntlayoutLwPrice.Visibility = ViewStates.Gone;
                            txtlowestPrice.Visibility = ViewStates.Gone;
                        }
                    }
                    else
                    {
                        txtTruckLowestPrice.Visibility = ViewStates.Gone;
                        lntlayoutLwPrice.Visibility = ViewStates.Gone;
                        txtlowestPrice.Visibility = ViewStates.Gone;
                    }
                    TextView txtTruckPickOnDate = RateDetails.FindViewById<TextView>(Resource.Id.txtTruckPickOnDate);
                    txtTruckPickOnDate.Text = Constants.strPick + lstShipmentDetail.PickupStr;
                    txtloadNoVal.Text = lstShipmentDetail.BolNum;
                    txtPickUpNoVal.Text = lstShipmentDetail.ClientBolNum;
                    txtStatusVal.Text = lstShipmentDetail.Status;
                    txtDateopenVal.Text = lstShipmentDetail.DateOpenedStr;
                    if (lstShipmentDetail.StartingPrice > 0)
                    {
                        lntlayoutStartingPrice.Visibility = ViewStates.Visible;
                        txtStartingPriceVal.Text = "$" + Convert.ToString(lstShipmentDetail.StartingPrice);
                    }
                    else
                    {
                        lntlayoutStartingPrice.Visibility = ViewStates.Gone;
                    }
                    txtUserCreatedVal.Text = lstShipmentDetail.UserCreated;
                    txtDateAwardedVal.Text = lstShipmentDetail.DateAwardedStr;
                    if (lstShipmentDetail.ViewAs == Constants.strCustomer)
                    {
                        lntlayoutSentCarriers.Visibility = ViewStates.Visible;
                        txtSentCarriersVal.Text = lstShipmentDetail.SentCarriers;
                    }
                    else
                    {
                        lntlayoutSentCarriers.Visibility = ViewStates.Gone;
                    }
                    if (!string.IsNullOrEmpty(lstShipmentDetail.InvoiceCreatedOn))
                    {
                        lntlayoutInvoiceCreatedOn.Visibility = ViewStates.Visible;
                        txtInvoiceCreatedOnVal.Text = lstShipmentDetail.InvoiceCreatedOn;
                    }
                    else
                    {
                        lntlayoutInvoiceCreatedOn.Visibility = ViewStates.Gone;
                    }
                    txtRateVal.Text = lstShipmentDetail.BidType;
                    txtRateDeadVal.Text = lstShipmentDetail.DeadLineUTC;
                    txtPickOnVal.Text = lstShipmentDetail.PickupStr;
                    txtDeliverOnVal.Text = lstShipmentDetail.DeliverOnStr;
                    txtDriverVal.Text = lstShipmentDetail.DriverID;
                    txtReference.Text = lstShipmentDetail.ReferenceLbl;
                    txtReferenceVal.Text = lstShipmentDetail.Reference;
                    txtCommentVal.Text = lstShipmentDetail.Comments;
                    if (!string.IsNullOrEmpty(lstShipmentDetail.SCACStatement))
                    {
                        txtClientStmtVal.Text = lstShipmentDetail.SCACStatement;
                    }
                    if (lstShipmentDetail.ViewAs == Constants.strCustomer && lstShipmentDetail.CanVoid)
                    {
                        btnBlock.Visibility = ViewStates.Gone;
                        btnVoid.Visibility = ViewStates.Visible;
                    }
                    else
                    {
                        btnVoid.Visibility = ViewStates.Gone;
                    }
                    if (lstShipmentDetail.CanBlock)
                    {
                        btnBlock.Visibility = ViewStates.Visible;
                        btnVoid.Visibility = ViewStates.Gone;
                    }
                    else
                    {
                        btnBlock.Visibility = ViewStates.Gone;
                    }
                }
                else
                {
                    Toast.MakeText(context, 1, ToastLength.Short).Show();
                }
            }

        }
        List<string> destinationAddress = null;
        Spinner spinnerDestinationAddress;
        TextView txtDestAdd1, txtDestAdd2, txtDestAdd3, txtDestAdd4, txtDestAdd5, txtDestAdd6, txtDestinationAddress, txtAddHeadText;
        string destination = string.Empty;
        /// <summary>
        /// Bind The Address Details In Address panel
        /// </summary>
        private void BindAddressDetails()
        {
            destinationAddress = new List<string>();
            objAddress = new List<Address>();
            objAddress = lstShipmentDetail.Addresses.ToList();
            if (objAddress != null)
            {
                #region Finding Address Controls
                string origin = string.Empty;

                string value = string.Empty;
                txtAddHeadText = RateDetails.FindViewById<TextView>(Resource.Id.txtAddHeadText);
                TextView txtOrgAdd1 = RateDetails.FindViewById<TextView>(Resource.Id.txtOrgAdd1);
                TextView txtOrgAdd2 = RateDetails.FindViewById<TextView>(Resource.Id.txtOrgAdd2);
                TextView txtOrgAdd3 = RateDetails.FindViewById<TextView>(Resource.Id.txtOrgAdd3);
                TextView txtOrgAdd4 = RateDetails.FindViewById<TextView>(Resource.Id.txtOrgAdd4);
                TextView txtOrgAdd5 = RateDetails.FindViewById<TextView>(Resource.Id.txtOrgAdd5);
                TextView txtOrgAdd6 = RateDetails.FindViewById<TextView>(Resource.Id.txtOrgAdd6);
                txtDestAdd1 = RateDetails.FindViewById<TextView>(Resource.Id.txtDestAdd1);
                txtDestAdd2 = RateDetails.FindViewById<TextView>(Resource.Id.txtDestAdd2);
                txtDestAdd3 = RateDetails.FindViewById<TextView>(Resource.Id.txtDestAdd3);
                txtDestAdd4 = RateDetails.FindViewById<TextView>(Resource.Id.txtDestAdd4);
                txtDestAdd5 = RateDetails.FindViewById<TextView>(Resource.Id.txtDestAdd5);
                txtDestAdd6 = RateDetails.FindViewById<TextView>(Resource.Id.txtDestAdd6);
                txtDestinationAddress = RateDetails.FindViewById<TextView>(Resource.Id.txtDestinationAddress);

                spinnerDestinationAddress = RateDetails.FindViewById<Spinner>(Resource.Id.spinnerDestinationAddress);
                spinnerDestinationAddress.ItemSelected += SpinnerDestinationAddress_ItemSelected;
               


                #endregion
                foreach (var item in objAddress)
                {
                    if (item.Type == Constants.strORIGIN)
                    {
                        txtOrgAdd1.Text = item.Company;
                        if (!string.IsNullOrEmpty(item.Attention))
                        {
                            txtOrgAdd2.Text = item.Attention;
                        }
                        else
                        {
                            txtOrgAdd2.Visibility = ViewStates.Gone;
                        }
                        //Address
                        if (!string.IsNullOrEmpty(item.Address1))
                        {
                            txtOrgAdd3.Text = item.Address1 + "\n";
                        }
                        if (!string.IsNullOrEmpty(item.Address2))
                        {
                            txtOrgAdd3.Text += item.Address2 + "\n";
                        }
                        if (!string.IsNullOrEmpty(item.Address3))
                        {
                            txtOrgAdd3.Text += item.Address3 + "\n";
                        }
                        if (!string.IsNullOrEmpty(item.Address4))
                        {
                            txtOrgAdd3.Text += item.Address4 + "\n";
                        }
                        if (!string.IsNullOrEmpty(item.City))
                        {
                            txtAddHeadText.Text = item.City;
                            txtOrgAdd3.Text += item.City + ", ";
                        }
                        if (!string.IsNullOrEmpty(item.State))
                        {
                            txtAddHeadText.Text += " " + item.State + " " + item.Zip;
                            txtOrgAdd3.Text += item.State + " " + item.Zip + "\n" + item.Country;
                        }
                        else
                        {
                            txtOrgAdd3.Visibility = ViewStates.Gone;
                        }
                        txtOrgAdd4.Text = "Phone: " + item.Phone;
                        txtOrgAdd5.Text = "Email: " + item.Email;
                        txtOrgAdd6.Text = "Fax: " + item.Fax;
                        origin = item.City + ", " + item.State + ", " + item.Zip + ", " + item.Country;
                    }
                    //if (item.Type == Constants.strSHIPTO)
                    //{
                    //    txtDestAdd1.Text = item.Company;
                    //    if (!string.IsNullOrEmpty(item.Attention))
                    //    {
                    //        txtDestAdd2.Text = item.Attention;
                    //    }
                    //    else
                    //    {
                    //        txtDestAdd2.Visibility = ViewStates.Gone;
                    //    }
                    //    //Address
                    //    if (!string.IsNullOrEmpty(item.Address1))
                    //    {
                    //        txtDestAdd3.Text = item.Address1 + "\n";
                    //    }
                    //    if (!string.IsNullOrEmpty(item.Address2))
                    //    {
                    //        txtDestAdd3.Text += item.Address2 + "\n";
                    //    }
                    //    if (!string.IsNullOrEmpty(item.Address3))
                    //    {
                    //        txtDestAdd3.Text += item.Address3 + "\n";
                    //    }
                    //    if (!string.IsNullOrEmpty(item.Address4))
                    //    {
                    //        txtDestAdd3.Text += item.Address4 + "\n";
                    //    }
                    //    if (!string.IsNullOrEmpty(item.City))
                    //    {
                    //        txtAddHeadText.Text += " To " + item.City;
                    //        txtDestAdd3.Text += item.City + ", ";
                    //    }
                    //    if (!string.IsNullOrEmpty(item.State))
                    //    {
                    //        txtAddHeadText.Text += " " + item.State + " " + item.Zip;
                    //        txtDestAdd3.Text += item.State + " " + item.Zip + "\n" + item.Country;
                    //    }
                    //    else
                    //    {
                    //        txtDestAdd3.Visibility = ViewStates.Gone;
                    //    }
                    //    txtDestAdd4.Text = "Phone: " + item.Phone;
                    //    txtDestAdd5.Text = "Email: " + item.Email;
                    //    txtDestAdd6.Text = "Fax: " + item.Fax;
                    //    destination = item.City + ", " + item.State + ", " + item.Zip + ", " + item.Country;
                    //}

                    else
                    {
                        if (lstShipmentDetail.IsMultiStop)
                        {
                            spinnerDestinationAddress.Visibility = ViewStates.Visible;
                            txtDestinationAddress.Visibility = ViewStates.Gone;
                            //if (item.Type == "SHIPTO")
                            //{
                            //    destinationAddress.Add("Dest Address");
                            //}
                            if (item.Type != "BILLTO"  )
                            {
                                if (item.Type != "SHIPTO")
                                {
                                    if(item.Type!= Constants.strORIGIN)
                                        
                                    destinationAddress.Add(item.Type);
                                }
                            }

                        }
                        else
                        {
                            spinnerDestinationAddress.Visibility = ViewStates.Gone;
                            txtDestinationAddress.Visibility = ViewStates.Visible;
                            if (item.Type == Constants.strSHIPTO)
                            {
                                txtDestAdd1.Text = item.Company;
                                if (!string.IsNullOrEmpty(item.Attention))
                                {
                                    txtDestAdd2.Text = item.Attention;
                                }
                                else
                                {
                                    txtDestAdd2.Visibility = ViewStates.Gone;
                                }
                                //Address
                                if (!string.IsNullOrEmpty(item.Address1))
                                {
                                    txtDestAdd3.Text = item.Address1 + "\n";
                                }
                                if (!string.IsNullOrEmpty(item.Address2))
                                {
                                    txtDestAdd3.Text += item.Address2 + "\n";
                                }
                                if (!string.IsNullOrEmpty(item.Address3))
                                {
                                    txtDestAdd3.Text += item.Address3 + "\n";
                                }
                                if (!string.IsNullOrEmpty(item.Address4))
                                {
                                    txtDestAdd3.Text += item.Address4 + "\n";
                                }
                                if (!string.IsNullOrEmpty(item.City))
                                {
                                    txtAddHeadText.Text += " To " + item.City;
                                    txtDestAdd3.Text += item.City + ", ";
                                }
                                if (!string.IsNullOrEmpty(item.State))
                                {
                                    txtAddHeadText.Text += " " + item.State + " " + item.Zip;
                                    txtDestAdd3.Text += item.State + " " + item.Zip + "\n" + item.Country;
                                }
                                else
                                {
                                    txtDestAdd3.Visibility = ViewStates.Gone;
                                }
                                txtDestAdd4.Text = "Phone: " + item.Phone;
                                txtDestAdd5.Text = "Email: " + item.Email;
                                txtDestAdd6.Text = "Fax: " + item.Fax;
                                destination = item.City + ", " + item.State + ", " + item.Zip + ", " + item.Country;
                            }
                        }
                    }
                }
                List<string> lstStops = new List<string>();
               
                foreach (var stops in destinationAddress)
                {
                    if (stops != "SHIPTO" || stops != "Dest Address")
                    {
                        lstStops.Add(stops);
                    }
                }
                lstStops.Add("Dest Address");
                ArrayAdapter spinnerArrayAdapter = new ArrayAdapter<string>(context, Resource.Drawable.spinnerAddressesCustomDesign, lstStops);
                spinnerArrayAdapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
                spinnerDestinationAddress.Adapter = spinnerArrayAdapter;
                spinnerDestinationAddress.SetSelection(lstStops.Count-1);

                //Redirect to Shipment Address Activity
                value = origin + "#" + destination + "#" + lstShipmentDetail.BolNum;
                Intent objIntent = Utility.RedirectTo(context, typeof(ShipmentsAddressActivity), "location", value);
                txtOrgAdd3.Click += (sender, e) =>
                {
                    context.StartActivity(objIntent);
                };
                txtDestAdd3.Click += (sender, e) =>
                {
                    context.StartActivity(objIntent);
                };
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SpinnerDestinationAddress_ItemSelected(object sender, AdapterView.ItemSelectedEventArgs e)
        {
            string Address;
            try
            {
               // txtDestAdd3.Text = string.Empty;
                //txtAddHeadText.Text = string.Empty;
                for (int indexAddress = 0; indexAddress < lstShipmentDetail.Addresses.Count; indexAddress++)
                {
                    if (spinnerDestinationAddress.SelectedItem.Equals(Convert.ToString(lstShipmentDetail.Addresses[indexAddress].Type.ToUpper())) || Convert.ToString(lstShipmentDetail.Addresses[indexAddress].Type.ToUpper())=="SHIPTO")
                    {
                        Address = string.Empty;
                        Address = string.Format($"{lstShipmentDetail.Addresses[indexAddress].Company}{lstShipmentDetail.Addresses[indexAddress].Address1} {lstShipmentDetail.Addresses[indexAddress].Address2} {lstShipmentDetail.Addresses[indexAddress].City} {lstShipmentDetail.Addresses[indexAddress].State} {lstShipmentDetail.Addresses[indexAddress].Zip}");

                        txtDestAdd1.Text = lstShipmentDetail.Addresses[indexAddress].Company;
                        if (!string.IsNullOrEmpty(lstShipmentDetail.Addresses[indexAddress].Attention))
                        {
                            txtDestAdd2.Text = lstShipmentDetail.Addresses[indexAddress].Attention;
                        }
                        else
                        {
                            txtDestAdd2.Visibility = ViewStates.Gone;
                        }
                        //Address
                        if (!string.IsNullOrEmpty(lstShipmentDetail.Addresses[indexAddress].Address1))
                        {
                            txtDestAdd3.Text = lstShipmentDetail.Addresses[indexAddress].Address1 + "\n";
                        }
                        if (!string.IsNullOrEmpty(lstShipmentDetail.Addresses[indexAddress].Address2))
                        {
                            txtDestAdd3.Text += lstShipmentDetail.Addresses[indexAddress].Address2 + "\n";
                        }
                        if (!string.IsNullOrEmpty(lstShipmentDetail.Addresses[indexAddress].Address3))
                        {
                            txtDestAdd3.Text += lstShipmentDetail.Addresses[indexAddress].Address3 + "\n";
                        }
                        if (!string.IsNullOrEmpty(lstShipmentDetail.Addresses[indexAddress].Address4))
                        {
                            txtDestAdd3.Text += lstShipmentDetail.Addresses[indexAddress].Address4 + "\n";
                        }
                        if (!string.IsNullOrEmpty(lstShipmentDetail.Addresses[indexAddress].City))
                        {
                            txtAddHeadText.Text += " To " + lstShipmentDetail.Addresses[indexAddress].City;
                           
                            txtDestAdd3.Text += lstShipmentDetail.Addresses[indexAddress].City + ", ";
                        }
                        if (!string.IsNullOrEmpty(lstShipmentDetail.Addresses[indexAddress].State))
                        {
                            txtAddHeadText.Text += " " + lstShipmentDetail.Addresses[indexAddress].State + " " + lstShipmentDetail.Addresses[indexAddress].Zip;
                            txtDestAdd3.Text += lstShipmentDetail.Addresses[indexAddress].State + " " + lstShipmentDetail.Addresses[indexAddress].Zip + "\n" + lstShipmentDetail.Addresses[indexAddress].Country;
                        }
                        else
                        {
                            txtDestAdd3.Visibility = ViewStates.Gone;
                        }
                        
                        if(string.IsNullOrEmpty(destinationHeaderAddress))
                        {
                            destinationHeaderAddress = txtAddHeadText.Text;                           
                        }
                        else
                        {
                            txtAddHeadText.Text = destinationHeaderAddress;
                        }
                        txtDestAdd4.Text = "Phone: " + lstShipmentDetail.Addresses[indexAddress].Phone;
                        txtDestAdd5.Text = "Email: " + lstShipmentDetail.Addresses[indexAddress].Email;
                        txtDestAdd6.Text = "Fax: " + lstShipmentDetail.Addresses[indexAddress].Fax;
                        destination = lstShipmentDetail.Addresses[indexAddress].City + ", " + lstShipmentDetail.Addresses[indexAddress].State + ", " + lstShipmentDetail.Addresses[indexAddress].Zip + ", " + lstShipmentDetail.Addresses[indexAddress].Country;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        /// <summary>
        /// Detail(s) Binding
        /// </summary>
        private void BindDetails(View detailLayout)
        {

            decimal weight = 0;
            decimal pallets = 0;
            decimal pieces = 0;
            objDetails = new List<LineDetail>();
            objDetails = lstShipmentDetail.LineDetails;
            if (objDetails != null)
            {
                #region Find Details Layout Controls 
                TextView txtDetailsHead = detailLayout.FindViewById<TextView>(Resource.Id.txtDetailsHead);
                TextView txtDetailsChild = detailLayout.FindViewById<TextView>(Resource.Id.txtDetailsChild);
                ListView lstViewDetails = detailLayout.FindViewById<ListView>(Resource.Id.lstViewDetails);
                TextView txtClassHead = detailLayout.FindViewById<TextView>(Resource.Id.txtClassHead);
                TextView txtPUStopHead = detailLayout.FindViewById<TextView>(Resource.Id.txtPUStopHead);
                TextView txtDOStopHead = detailLayout.FindViewById<TextView>(Resource.Id.txtDOStopHead);
                #endregion
                if (lstShipmentDetail.IsTest)
                {
                    txtDetailsHead.Text = Constants.strDetail;
                }
                else
                {
                    txtDetailsHead.Text = Constants.strDetailHead;
                }

                for (int count = 0; count <= objDetails.Count - 1; count++)
                {
                    weight += Convert.ToDecimal(objDetails[count].Weight);

                    pallets += Convert.ToDecimal(objDetails[count].Pallets);

                    pieces += Convert.ToDecimal(objDetails[count].Pieces);
                }
                txtDetailsChild.Text = Math.Round(weight, 2).ToString() + Constants.strlbs + pallets + Constants.strPallets + pieces + Constants.strPieces;
                DetailsShipment detailsShipmentAdapter = new DetailsShipment(context, lstShipmentDetail);
                lstViewDetails.Adapter = detailsShipmentAdapter;
                if (lstShipmentDetail.Mode == Constants.strTRUCKLOAD)
                {
                    txtClassHead.Visibility = ViewStates.Visible;
                }
                else
                {
                    txtClassHead.Visibility = ViewStates.Gone;
                }
                if (lstShipmentDetail.IsMultiStop)
                {
                    txtPUStopHead.Visibility = ViewStates.Visible;
                    txtDOStopHead.Visibility = ViewStates.Visible;
                }
                else
                {
                    txtPUStopHead.Visibility = ViewStates.Gone;
                    txtDOStopHead.Visibility = ViewStates.Gone;
                }
            }


        }

        /// <summary>
        /// Commodities Binding
        /// </summary>
        private void BindCommodities(View detailLayout)
        {
            objCommodities = new List<Content>();
            objCommodities = lstShipmentDetail.Contents;
            if (objCommodities != null)
            {
                #region Find Commodities Layout Controls
                TextView txtCommoCountry = detailLayout.FindViewById<TextView>(Resource.Id.txtCommoCountry);
                TextView txtCommoCode = detailLayout.FindViewById<TextView>(Resource.Id.txtCommoCode);
                TextView txtCommoNumber = detailLayout.FindViewById<TextView>(Resource.Id.txtCommoNumber);
                TextView txtCommoDescription = detailLayout.FindViewById<TextView>(Resource.Id.txtCommoDescription);
                TextView txtCommoQty = detailLayout.FindViewById<TextView>(Resource.Id.txtCommoQty);
                TextView txtCommoUOM = detailLayout.FindViewById<TextView>(Resource.Id.txtCommoUOM);
                TextView txtCommoPrice = detailLayout.FindViewById<TextView>(Resource.Id.txtCommoPrice);
                TextView txtCommoValue = detailLayout.FindViewById<TextView>(Resource.Id.txtCommoValue);
                TextView txtCommoWeight = detailLayout.FindViewById<TextView>(Resource.Id.txtCommoWeight);
                #endregion
                foreach (var item in objCommodities)
                {
                    txtCommoCountry.Text = item.ProducerCountry;
                    txtCommoCode.Text = item.ItemCode;
                    txtCommoNumber.Text = item.ItemNumber;
                    txtCommoDescription.Text = item.Description;
                    txtCommoQty.Text = item.Qty;
                    txtCommoUOM.Text = item.UOM;
                    txtCommoPrice.Text = item.UnitValue;
                    txtCommoValue.Text = item.DeclaredValue;
                    txtCommoWeight.Text = item.Weight;
                }
            }

        }

        /// <summary>
        /// Bind Pop for Line Details
        /// </summary>
        /// <param name="detailLayout"></param>
        private void BindPopDetails(Dialog detailLayout)
        {

            if (objDetails != null)
            {
                #region Find PopDetails Controls
                TextView txtLine = detailLayout.FindViewById<TextView>(Resource.Id.txtLine);
                TextView txtPallets = detailLayout.FindViewById<TextView>(Resource.Id.txtPallets);
                TextView txtPieces = detailLayout.FindViewById<TextView>(Resource.Id.txtPieces);
                TextView txtUOM = detailLayout.FindViewById<TextView>(Resource.Id.txtUOM);
                TextView txtItem = detailLayout.FindViewById<TextView>(Resource.Id.txtItem);
                TextView txtDescription = detailLayout.FindViewById<TextView>(Resource.Id.txtDescription);
                TextView txtDimension = detailLayout.FindViewById<TextView>(Resource.Id.txtDimension);
                TextView txtClassHead = detailLayout.FindViewById<TextView>(Resource.Id.txtClassHead);
                TextView txtClass = detailLayout.FindViewById<TextView>(Resource.Id.txtClass);
                TextView txtFAK = detailLayout.FindViewById<TextView>(Resource.Id.txtFAK);
                TextView txtWeight = detailLayout.FindViewById<TextView>(Resource.Id.txtWeight);
                TextView txtPUStop = detailLayout.FindViewById<TextView>(Resource.Id.txtPUStop);
                TextView txtPUStopHead = detailLayout.FindViewById<TextView>(Resource.Id.txtPUStopHead);
                TextView txtDOStop = detailLayout.FindViewById<TextView>(Resource.Id.txtDOStop);
                TextView txtDOStopHead = detailLayout.FindViewById<TextView>(Resource.Id.txtDOStopHead);
                #endregion
                foreach (var item in objDetails)
                {
                    txtLine.Text = Convert.ToString(item.LineNum);
                    txtPallets.Text = Convert.ToString(item.Pallets);
                    txtPieces.Text = Convert.ToString(item.Pieces);
                    txtUOM.Text = item.UOM;
                    txtItem.Text = item.Item;
                    txtDescription.Text = item.Descr;
                    decimal dimension = Convert.ToDecimal(item.Length * item.Width * item.Height);
                    txtDimension.Text = Convert.ToString(dimension);
                    if (lstShipmentDetail.Mode == Constants.strTRUCKLOAD)
                    {
                        txtClassHead.Visibility = ViewStates.Visible;
                        txtClass.Visibility = ViewStates.Visible;
                        txtClass.Text = Convert.ToString(item.Class);
                    }
                    else
                    {
                        txtClassHead.Visibility = ViewStates.Gone;
                        txtClass.Visibility = ViewStates.Gone;
                    }
                    txtFAK.Text = Convert.ToString(item.FAK);
                    txtWeight.Text = Convert.ToString(item.Weight);
                    if (lstShipmentDetail.IsMultiStop)
                    {
                        txtPUStop.Visibility = ViewStates.Visible;
                        txtPUStopHead.Visibility = ViewStates.Visible;
                        txtDOStop.Visibility = ViewStates.Visible;
                        txtDOStopHead.Visibility = ViewStates.Visible;
                        txtPUStopHead.Text = Convert.ToString(item.PUStop);
                        txtDOStopHead.Text = Convert.ToString(item.DOStop);
                    }
                    else
                    {
                        txtPUStop.Visibility = ViewStates.Gone;
                        txtPUStopHead.Visibility = ViewStates.Gone;
                        txtDOStop.Visibility = ViewStates.Gone;
                        txtDOStopHead.Visibility = ViewStates.Gone;
                    }
                }
            }

        }

        /// <summary>
        /// Bind Options 
        /// </summary>
        private void BindOptions()
        {
            objOptions = new List<SS>();
            if (lstShipmentDetail.SSes != null)
            {
                objOptions = lstShipmentDetail.SSes.ToList();
                //Finding Control
                TextView txtOptionsHead = RateDetails.FindViewById<TextView>(Resource.Id.txtOptionsHead);
                lstViewOptions = RateDetails.FindViewById<ListView>(Resource.Id.lstViewOptions);
                //Assigning Data into control
                txtOptionsHead.Text = Convert.ToString(objOptions.Count()) + Constants.strDetailHead;
                //Calling Adapter and binding data into list view
                OptionAdapterShipments = new OptionAdapter.OptionAdapterShipments(context, objOptions);
                lstViewOptions.Adapter = OptionAdapterShipments;
            }

        }

        /// <summary>
        /// Binding Attribute Data
        /// </summary>
        private void BindAttributes()
        {
            List<Models.Attribute> lstAttibutes = new List<Models.Attribute>();
            if (lstShipmentDetail.Attributes != null && lstShipmentDetail.Attributes.Count > 0)
            {
                lstAttibutes = lstShipmentDetail.Attributes.ToList();
                //Assigning Data into control
                txtAttributeHead.Text = Constants.attributes + lstAttibutes.Count();
                //Calling Adapter and binding data into list view
                ScannedAttributeAdapter scannedAttributeAdapter = new ScannedAttributeAdapter(context, lstAttibutes);
                lstViewAttribute.Adapter = scannedAttributeAdapter;
            }

        }

        /// <summary>
        /// Confirmation Pannel It will work While click Recent shipments
        /// </summary>
        private void BindConfirmation()
        {
            rlativeConfirmationHdr.Visibility = ViewStates.Visible;
            Button btnPickup = RateDetails.FindViewById<Button>(Resource.Id.btnPickup);
            Button btnDelivery = RateDetails.FindViewById<Button>(Resource.Id.btnDelivery);
            Button btnFindCurrent = RateDetails.FindViewById<Button>(Resource.Id.btnFindCurrent);
            Button btnEquipment = RateDetails.FindViewById<Button>(Resource.Id.btnEquipment);
            LinearLayout lnrFindCurrentLocation = RateDetails.FindViewById<LinearLayout>(Resource.Id.lnrFindCurrentLocation);
            if (lstShipmentDetail.ViewAs == Constants.strCustomer)
            {
                btnFindCurrent.Visibility = ViewStates.Visible;
                lnrFindCurrentLocation.Visibility = ViewStates.Visible;
                lnrConfirmationButton.Visibility = ViewStates.Gone;
                txtPickupDeliveryText.Visibility = ViewStates.Gone;
                btnEquipment.Visibility = ViewStates.Gone;

            }
            else
            {
                btnFindCurrent.Visibility = ViewStates.Gone;
                lnrFindCurrentLocation.Visibility = ViewStates.Gone;
                lnrConfirmationButton.Visibility = ViewStates.Visible;
                txtPickupDeliveryText.Visibility = ViewStates.Visible;
            }


            //Click Event 
            btnPickup.Click += BtnPickup_Click;
            btnDelivery.Click += BtnDelivery_Click;
            btnEquipment.Click += BtnEquipment_Click;
            btnFindCurrent.Click += BtnFindCurrent_Click;

        }

        /// <summary>
        /// Eqipment Scan Button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnEquipment_Click(object sender, EventArgs e)
        {
            try
            {
                if ((ContextCompat.CheckSelfPermission(context, Manifest.Permission.Camera) == (int)Permission.Granted))
                {
                    Utility.ActiveConversationHeader = 0;
                    slideactivity = new Intent(context, typeof(EquipmentScanningActivity));
                    bndlanimation = ActivityOptions.MakeCustomAnimation(context, Resource.Animation.abc_slide_in_bottom, Resource.Animation.abc_slide_out_bottom).ToBundle();
                    StartActivity(slideactivity, bndlanimation);
                    slideactivity = null;
                    bndlanimation = null;
                }
                else
                {
                    V4App.ActivityCompat.RequestPermissions(context, PermissionsLocation, 0);
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Find Current Location stil pending
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnFindCurrent_Click(object sender, EventArgs e)
        {
            if (CommanUtil.IsTimeOut())
            {
                Intent intentRealTimeTracking = Utility.RedirectTo(context, typeof(RealTimeTrackingActivity), "location", Constants.loc_SourceDest);
                context.StartActivity(intentRealTimeTracking);
            }
            else
            {
                //Token Exired
                Utility.ExpireSession(context);
            }
        }

        /// <summary>
        /// Get Delivery Details
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnDelivery_Click(object sender, EventArgs e)
        {
            try
            {
                RedirectToConfirmation(lstShipmentDetail.ClientID + "|" + lstShipmentDetail.LocID + "|" + lstShipmentDetail.BolNum + "|" + Constants.strDeliveryConf);
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Pickup Details
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnPickup_Click(object sender, EventArgs e)
        {
            try
            {
                RedirectToConfirmation(lstShipmentDetail.ClientID + "|" + lstShipmentDetail.LocID + "|" + lstShipmentDetail.BolNum + "|" + Constants.strPickConf);
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Redirect to confirmation screen
        /// </summary>
        /// <param name="strConfValue"></param>
        private void RedirectToConfirmation(string strConfValue)
        {
            if ((ContextCompat.CheckSelfPermission(context, Manifest.Permission.AccessFineLocation) == (int)Permission.Granted) &&
               (ContextCompat.CheckSelfPermission(context, Manifest.Permission.AccessCoarseLocation) == (int)Permission.Granted))
            {
                Utility.ActiveConversationHeader = 0;
                slideactivity = new Intent(context, typeof(ConfirmationDetailActivity));
                slideactivity.PutExtra("PickupConf", strConfValue);
                bndlanimation = ActivityOptions.MakeCustomAnimation(context, Resource.Animation.abc_slide_in_bottom, Resource.Animation.abc_slide_out_bottom).ToBundle();
                StartActivity(slideactivity, bndlanimation);
                slideactivity = null;
                bndlanimation = null;
            }
            else
            {
                V4App.ActivityCompat.RequestPermissions(context, PermissionsLocation, 0);
            }
        }

        /// <summary>
        /// Customer can Block the shipment And the option is in Truck Load section
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnBlock_Click(object sender, EventArgs e)
        {
            try
            {
                objUtility = new Utility();
                //Generate Confirmation Alert Box
                dialog = objUtility.ConfirmationAlert(context);
                btnYes = dialog.FindViewById<Button>(Resource.Id.btnYes);
                txtMessage = dialog.FindViewById<TextView>(Resource.Id.txtMessage);
                txtMessage.Text = Resources.GetString(Resource.String.BlockShipments);
                txtDialogHeader = dialog.FindViewById<TextView>(Resource.Id.txtDialogHeader);
                lntlayoutReason = dialog.FindViewById<LinearLayout>(Resource.Id.lntlayoutReason);
                imgheader = dialog.FindViewById<ImageView>(Resource.Id.imgheader);
                txtEnterReason = dialog.FindViewById<EditText>(Resource.Id.txtEnterReason);
                //If Click On Yes 
                btnYes.Click += async delegate
                 {
                     await BlockShipment();
                 };
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Block Shipment on Click of Block Button under truck load section
        /// </summary>
        private async Task BlockShipment()
        {
            try
            {
                if (!Utility.FnIsOnline(context))
                {
                    Alerts.HideBusyLoader();
                    Toast.MakeText(context, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                JObject jsonResponse = null;
                string message = string.Empty;
                ShipmentsDetailedActivity objShipmentsDetailedActivity = null;
                lntlayoutReason.Visibility = ViewStates.Visible;
                imgheader.Visibility = ViewStates.Gone;
                txtMessage.Text = Resources.GetString(Resource.String.ReasonForBlock);
                txtDialogHeader.Text = Resources.GetString(Resource.String.blockHeader);
                if (txtEnterReason.Text != "")
                {
                    Alerts.showBusyLoader(context); //Start Loader
                    method = APIMethods.shipmentDetails + "/" + lstShipmentDetail.ClientID + "|" + lstShipmentDetail.LocID + "|" + lstShipmentDetail.BolNum + "/" + APIMethods.Block;
                    data = "Reason=" + txtEnterReason.Text;
                    objServiceHelper = new ServiceHelper();
                    var response = await objServiceHelper.PostRequest(data, method, token, true);
                    if (response != null)
                    {
                        if (response.Replace("\"", " ").Trim().ToUpper() == Constants.strBlockMsg.ToUpper())
                        {
                            dialog.Hide();//hide Dialog or confirmation 
                            objShipmentsDetailedActivity = new ShipmentsDetailedActivity();
                            method = APIMethods.shipmentDetails + "/" + lstShipmentDetail.ClientID + "|" + lstShipmentDetail.BolNum;
                            await objUtility.BindShipmentDetail(method, context);//Bind shipment
                            Alerts.HideBusyLoader(); //Hide Loader
                        }
                        else
                        {
                            jsonResponse = JObject.Parse(response);
                            message = Convert.ToString(jsonResponse[Constants.strErrorMessage]);
                            dialog.Hide();//hide Dialog or confirmation Box
                            //Post Error Logger Request 
                            Utility.ErrorLog(lstShipmentDetail.BolNum, Constants.strBlock + message, token, context);
                            Alerts.HideBusyLoader(); //Hide Loader
                            //Print Message
                            Toast.MakeText(context, message, ToastLength.Long).Show();
                            //Redirect To Login Page
                            context.StartActivity(typeof(HomeActivity));
                        }
                        response = null;
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                Alerts.HideBusyLoader(); //Hide Loader
                dialog.Hide();
            }
        }

        /// <summary>
        /// Void Shipment under the truckload section
        /// </summary>
        private async Task VoidShipment()
        {
            try
            {
                if (!Utility.FnIsOnline(context))
                {
                    Alerts.HideBusyLoader();
                    Toast.MakeText(context, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                JObject jsonResponse = null;
                Alerts.showBusyLoader(context); //Start Loader
                objServiceHelper = new ServiceHelper();
                method = APIMethods.shipmentDetails + "/" + lstShipmentDetail.ClientID + "|" + lstShipmentDetail.LocID + "|" + lstShipmentDetail.BolNum + "/" + APIMethods.Void;
                data = string.Empty;
                var response = await objServiceHelper.PostRequest(data, method, token, true);
                if (response != null)
                {
                    if (response.Replace("\"", " ").Trim().ToUpper() == Constants.strVoidMsg.ToUpper())
                    {
                        Alerts.HideBusyLoader(); //Hide Loader
                        dialog.Hide();//hide Dialog or confirmation 
                        context.StartActivity(typeof(HomeActivity));
                    }
                    else
                    {
                        dialog.Hide();//hide Dialog or confirmation Box
                        //Post Error Logger Request 
                        jsonResponse = JObject.Parse(response);
                        string message = Convert.ToString(jsonResponse[Constants.strErrorMessage]);
                        Utility.ErrorLog(lstShipmentDetail.BolNum, Constants.strVoid + message, token, context);
                        Alerts.HideBusyLoader(); //Hide Loader
                        //Print Message
                        Toast.MakeText(context, message, ToastLength.Long).Show();
                        //Redirect To Login Page
                        context.StartActivity(typeof(HomeActivity));
                    }
                    response = null;
                }
                else
                {
                    if (objUtility ==null)
                    {
                        objUtility = new Utility();
                    }
                    dialog.Hide();
                    dialog = objUtility.ConfirmationAlert(context);//Generate Confirmation Alert Box
                    btnYes = dialog.FindViewById<Button>(Resource.Id.btnYes);
                    btnNo= dialog.FindViewById<Button>(Resource.Id.btnNo);
                    txtDialogHeader= dialog.FindViewById<TextView>(Resource.Id.txtDialogHeader);
                    txtMessage = dialog.FindViewById<TextView>(Resource.Id.txtMessage);
                    txtDialogHeader.Text= Constants.ErrorAlert;
                    txtMessage.Text = Constants.strServerError;
                    btnYes.Text = "OK";
                    txtEnterReason = dialog.FindViewById<EditText>(Resource.Id.txtEnterReason);
                    TextView txtReason = dialog.FindViewById<TextView>(Resource.Id.txtReason);
                    btnNo.Visibility = ViewStates.Gone;
                    txtReason.Visibility = ViewStates.Gone;
                    txtEnterReason.Visibility = ViewStates.Gone;
                    btnYes.Click += async delegate
                    {
                        dialog.Hide();
                    };
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                Alerts.HideBusyLoader(); //Hide Loader
            }
            finally
            {
                Alerts.HideBusyLoader(); //Hide Loader
            }
        }

        /// <summary>
        /// Customer can Void the shipment And the option is in Truck Load section
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnVoid_Click(object sender, EventArgs e)
        {
            try
            {
                objUtility = new Utility();
                dialog = objUtility.ConfirmationAlert(context);//Generate Confirmation Alert Box
                btnYes = dialog.FindViewById<Button>(Resource.Id.btnYes);
                txtMessage = dialog.FindViewById<TextView>(Resource.Id.txtMessage);
                txtMessage.Text = Resources.GetString(Resource.String.VoidShipments);
                txtEnterReason = dialog.FindViewById<EditText>(Resource.Id.txtEnterReason);
                TextView txtReason = dialog.FindViewById<TextView>(Resource.Id.txtReason);
                txtReason.Visibility = ViewStates.Gone;
                txtEnterReason.Visibility = ViewStates.Gone;
                btnYes.Click += async delegate
                {
                    await VoidShipment();
                };
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

    }
    /// <summary>
    /// According Theme Designing
    /// </summary>
    public class ScaleAnimToHide : ScaleAnimation
    {
        private bool mVanishAfter = false;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fromX"></param>
        /// <param name="toX"></param>
        /// <param name="fromY"></param>
        /// <param name="toY"></param>
        /// <param name="duration"></param>
        /// <param name="view"></param>
        /// <param name="vanishAfter"></param>
        public ScaleAnimToHide(float fromX, float toX, float fromY, float toY, int duration, View view, bool vanishAfter) : base(fromX, toX, fromY, toY)
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="interpolatedTime"></param>
        /// <param name="t"></param>
        protected void applyTransformation(float interpolatedTime, Transformation t)
        {
            base.ApplyTransformation(interpolatedTime, t);
            if (interpolatedTime < 1.0f)
            {
            }
            else if (mVanishAfter)
            {

            }
        }
    }
    /// <summary>
    /// 
    /// </summary>
    public class ScaleAnimToShow : ScaleAnimation
    {
        View openLayout;
        private View mView;

        private LinearLayout.LayoutParams mLayoutParams;

        private int mMarginBottomFromY, mMarginBottomToY;

        private bool mVanishAfter = false;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="toX"></param>
        /// <param name="fromX"></param>
        /// <param name="toY"></param>
        /// <param name="fromY"></param>
        /// <param name="duration"></param>
        /// <param name="view"></param>
        /// <param name="vanishAfter"></param>
        public ScaleAnimToShow(float toX, float fromX, float toY, float fromY, int duration, View view, bool vanishAfter) : base(fromX, toX, fromY, toY)
        {

            openLayout = view;
            Duration = duration;
            mView = view;
            mVanishAfter = vanishAfter;
            mLayoutParams = (LinearLayout.LayoutParams)view.LayoutParameters;
            mView.Visibility = ViewStates.Visible;
            int height = mView.Height;
            mMarginBottomFromY = 0;
            mMarginBottomToY = height;

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="interpolatedTime"></param>
        /// <param name="t"></param>
        protected void applyTransformation(float interpolatedTime, Transformation t)
        {
            base.ApplyTransformation(interpolatedTime, t);
            if (interpolatedTime < 1.0f)
            {
                int newMarginBottom = (int)((mMarginBottomToY - mMarginBottomFromY) * interpolatedTime) - mMarginBottomToY;
                mLayoutParams.SetMargins(mLayoutParams.LeftMargin, mLayoutParams.TopMargin, mLayoutParams.RightMargin, newMarginBottom);
                mView.Parent.RequestLayout();
            }
        }
    }
}