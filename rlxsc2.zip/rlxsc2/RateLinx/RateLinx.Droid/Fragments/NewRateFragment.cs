using System;
using System.Collections.Generic;
using Android.App;
using Android.OS;
using Android.Util;
using Android.Views;
using Android.Widget;
using V4App = Android.Support.V4.App;
using RateLinx.Droid.Utilities;
using Newtonsoft.Json;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using RateLinx.Models;
using RateLinx.Helper;
using RateLinx.APIs;
using RateLinx.Droid.Adapters;
using RateLinx.Droid.Activities;
using System.Globalization;

namespace RateLinx.Droid.Fragments
{
    /// <summary>
    /// NewRateFragment for placing new bid Rate for the shipment
    /// </summary>
    public class NewRateFragment : V4App.Fragment
    {
        #region Declaration of controls instances and variables 
        CarrierShipmentDetails carrierShipmentDetail = null;
        ImageButton imgButtonRate;
        Activity context;
        TextView txtBaseCharge, txtAccessCharge, txtFuelCharge, txtComments, txtTotal, txtDeliveryDate, txtDelTime1, txtDelTime2 = null;
        RelativeLayout lnrAcceptedSSes, lnrBaseChg, lnrAccessChg, lnrFuelChg, lnrFuelChg2,
            lnrTotalChg, lnrAcceptTerms, lnrComments;
        LinearLayout parentLayout, lnrPlaceNewRate, lnrBidWithDelDate, lnrBidDescription = null;
        View newRateFragment;
        Dialog dialog = null;
        Button btnConfirm, btnSubmitRate, btnReSubmit, btnUnAwardShip, btnRateHistory;//btnCancel
        bool isReviewedNdAck = false;
        bool isAlteredTerms = false;
        string rateComments = string.Empty;
        string AccessorialCharge = string.Empty;
        string FuelCharge = string.Empty;
        string BaseCharge = string.Empty;
        string delDate = string.Empty;
        string delTime1 = string.Empty;
        string delTime2 = string.Empty;
        string payload_str = string.Empty;
        string compositeKey = string.Empty;
        string[] activityDate = new string[2];
        string newDelDate = string.Empty;
        static string id = string.Empty;
        string methodURI, ratePayload, pickupDtTm_str, splittedPickup = string.Empty;
        string token, shipmentDetails, ActivityDate = string.Empty;
        Utility objUtility = null;
        CheckBox chkNewRateAlter;
        DateTime pickupDate_dt, dateTime2 = DateTime.Today;
        DatePickerDialog dialogDatePicker = null;
        TimePickerDialog timePick = null;
        string[] strArrayDelDate = null;
        string strToken = string.Empty;
        RelativeLayout relCustomerControls;
        ListView lstViewRateEntries = null;
        #endregion

        /// <summary>
        /// Constructor to initialize Activity
        /// </summary>
        /// <param name="context"></param>
        public NewRateFragment(Activity context)
        {
            this.context = context;
        }

        /// <summary>
        /// Function which is called first when the fragment loads
        /// </summary>
        /// <param name="inflater"></param>
        /// <param name="container"></param>
        /// <param name="savedInstanceState"></param>
        /// <returns></returns>
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                // retrieving the layout of NewRateFragment
                newRateFragment = inflater.Inflate(Resource.Layout.NewRateFragment, container, false);
                if (!Utility.FnIsOnline(context))
                {
                    Toast.MakeText(context, Constants.strNoInternet, ToastLength.Short).Show();
                }
                GetControlsById();
                return newRateFragment;
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                return newRateFragment;
            }
        }

        /// <summary>
        /// Find Controls by id and creating events
        /// </summary>
        public void GetControlsById()
        {
            try
            {
                //Getting shipment details from sharedPreferences
                shipmentDetails = Utility.sharedPreferences.GetString(Constants.shipmentDetails, null);
                if (!string.IsNullOrEmpty(shipmentDetails))
                {
                    carrierShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(shipmentDetails);
                }
                id = CommanUtil.CompositeKey(carrierShipmentDetail.ClientID, carrierShipmentDetail.LocID, carrierShipmentDetail.BolNum);
                token = CommanUtil.tokenNo;
                objUtility = new Utility();
                //Finding all the controls from the view
                txtBaseCharge = newRateFragment.FindViewById<TextView>(Resource.Id.txtBaseCharge);
                txtAccessCharge = newRateFragment.FindViewById<TextView>(Resource.Id.txtAccessCharge);
                txtFuelCharge = newRateFragment.FindViewById<TextView>(Resource.Id.txtFuelCharge);
                txtComments = newRateFragment.FindViewById<TextView>(Resource.Id.txtComments);
                chkNewRateAlter = newRateFragment.FindViewById<CheckBox>(Resource.Id.chkNewRateAlter);
                txtTotal = newRateFragment.FindViewById<TextView>(Resource.Id.txtTotal);
                //txtDeliveryDate, txtDelTime1, txtDelTime2;
                txtDeliveryDate = newRateFragment.FindViewById<TextView>(Resource.Id.txtDeliveryDate);
                txtDelTime1 = newRateFragment.FindViewById<TextView>(Resource.Id.txtDelTime1);
                txtDelTime2 = newRateFragment.FindViewById<TextView>(Resource.Id.txtDelTime2);
                lstViewRateEntries = newRateFragment.FindViewById<ListView>(Resource.Id.lstRateEntries);
                imgButtonRate = newRateFragment.FindViewById<ImageButton>(Resource.Id.imgShowRate);
                imgButtonRate.Click += ImgButtonRate_Click;
                relCustomerControls = newRateFragment.FindViewById<RelativeLayout>(Resource.Id.relCustomerControls);
                lnrPlaceNewRate = newRateFragment.FindViewById<LinearLayout>(Resource.Id.lnrPlaceNewRate);
                txtDeliveryDate.Click += (sender, e) =>
                {
                    context.Window.SetSoftInputMode(SoftInput.StateAlwaysHidden);
                    dialogDatePicker = new DatePickerDialog(context, ActivityDatePicker, DateTime.Today.Year, DateTime.Today.Month - 1, DateTime.Today.Day);
                    dialogDatePicker.DatePicker.MinDate = DateTime.Today.Millisecond;
                    dialogDatePicker.Show();
                };
                txtDelTime1.Click += (sender, e) =>
                {
                    context.Window.SetSoftInputMode(SoftInput.StateAlwaysHidden);
                    timePick = new TimePickerDialog(context, DelTime1Picker, DateTime.Now.Hour, DateTime.Now.Hour, true);
                    timePick.Show();
                };
                txtDelTime2.Click += (sender, e) =>
                {
                    context.Window.SetSoftInputMode(SoftInput.StateAlwaysHidden);
                    timePick = new TimePickerDialog(context, DelTime2Picker, DateTime.Now.Hour, DateTime.Now.Hour, true);
                    timePick.Show();
                };
                btnSubmitRate = newRateFragment.FindViewById<Button>(Resource.Id.btnSubmitRate);
                btnUnAwardShip = newRateFragment.FindViewById<Button>(Resource.Id.btnUnAwardShip);
                btnRateHistory = newRateFragment.FindViewById<Button>(Resource.Id.btnRateHistory);
                btnReSubmit = newRateFragment.FindViewById<Button>(Resource.Id.btnReSubmit);
                parentLayout = newRateFragment.FindViewById<LinearLayout>(Resource.Id.parentLayout);
                lnrAcceptedSSes = newRateFragment.FindViewById<RelativeLayout>(Resource.Id.lnrAcceptedSSes);
                lnrBaseChg = newRateFragment.FindViewById<RelativeLayout>(Resource.Id.lnrBaseChg);
                lnrAccessChg = newRateFragment.FindViewById<RelativeLayout>(Resource.Id.lnrAccessChg);
                lnrFuelChg = newRateFragment.FindViewById<RelativeLayout>(Resource.Id.lnrFuelChg);
                lnrFuelChg2 = newRateFragment.FindViewById<RelativeLayout>(Resource.Id.lnrFuelChg2);
                lnrTotalChg = newRateFragment.FindViewById<RelativeLayout>(Resource.Id.lnrTotalChg);
                lnrAcceptTerms = newRateFragment.FindViewById<RelativeLayout>(Resource.Id.lnrAcceptTerms);
                lnrComments = newRateFragment.FindViewById<RelativeLayout>(Resource.Id.lnrComments);
                lnrBidWithDelDate = newRateFragment.FindViewById<LinearLayout>(Resource.Id.lnrBidWithDelDate);
                lnrBidDescription = newRateFragment.FindViewById<LinearLayout>(Resource.Id.lnrBidDescription);
                ShowHideLayoutOnConditn();
                parentLayout.Touch += ParentLayout_Touch;
                parentLayout.Click += ParentLayout_Click;
                BindRateEntryData(carrierShipmentDetail);
                txtBaseCharge.TextChanged += TxtBaseCharge_TextChanged;
                txtAccessCharge.TextChanged += TxtAccessCharge_TextChanged;
                txtFuelCharge.TextChanged += TxtFuelCharge_TextChanged;
                btnSubmitRate.Click += async delegate
                {
                    if (CommanUtil.IsTimeOut())
                    {
                        CalTotalCharge(txtBaseCharge.Text, txtAccessCharge.Text, txtFuelCharge.Text);
                        await SubmitNewRate();
                    }
                    else
                    {
                        Utility.ExpireSession(context);
                    }
                };
                btnUnAwardShip.Click += delegate
                {
                    if (CommanUtil.IsTimeOut())
                    {
                        UnAwardShipment();
                    }
                    else
                    {
                        Utility.ExpireSession(context);
                    }
                };
                btnRateHistory.Click += delegate
                {
                    ShowRateHistory();
                };
                btnReSubmit.Click += delegate
                {
                    if (CommanUtil.IsTimeOut())
                    {
                        ReSubmitShipment(carrierShipmentDetail);
                    }
                    else
                    {
                        Utility.ExpireSession(context);
                    }
                };
                ResetRateEntries();
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        private void TxtFuelCharge_TextChanged(object sender, Android.Text.TextChangedEventArgs e)
        {
            CalTotalCharge(txtBaseCharge.Text, txtAccessCharge.Text, txtFuelCharge.Text);
        }

        private void TxtAccessCharge_TextChanged(object sender, Android.Text.TextChangedEventArgs e)
        {
            CalTotalCharge(txtBaseCharge.Text, txtAccessCharge.Text, txtFuelCharge.Text);
        }

        private void TxtBaseCharge_TextChanged(object sender, Android.Text.TextChangedEventArgs e)
        {
            CalTotalCharge(txtBaseCharge.Text, txtAccessCharge.Text, txtFuelCharge.Text);
        }

        /// <summary>
        /// Re-Submit Shipment
        /// </summary>
        private void ReSubmitShipment(CarrierShipmentDetails carrierShipmentDetail)
        {
            try
            {
                if (!Utility.FnIsOnline(context))
                {
                    Alerts.HideBusyLoader();
                    Toast.MakeText(context, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                string ReSubmitShipmentConfirm = Resources.GetString(Resource.String.ReSubmitShipmentConfirm);
                string ReSubmitShipment = Resources.GetString(Resource.String.ReSubmitShipment);
                Dialog unAwardDialog = objUtility.GetDialog(context, Constants.strConfirmation, ReSubmitShipment, Constants.btnTextYes, Constants.btnTextNo, "", ViewStates.Gone, ViewStates.Visible, ViewStates.Visible, ViewStates.Visible, ViewStates.Visible, ViewStates.Gone);
                btnConfirm = unAwardDialog.FindViewById<Button>(Resource.Id.btnYes);
                btnConfirm.Click += async delegate
                {
                    unAwardDialog.Hide();
                    await ResubmitShipment(ReSubmitShipmentConfirm);
                };
            }
            catch
            {
                Alerts.HideBusyLoader();
                //throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task ResubmitShipment(string ReSubmitShipmentConfirm)
        {
            try
            {
                ServiceHelper objServiceHelper = new ServiceHelper();
                id = CommanUtil.CompositeKey(carrierShipmentDetail.ClientID, carrierShipmentDetail.LocID, carrierShipmentDetail.BolNum);
                //string methodURL = APIMethods.shipmentDetails + "/" + id + "/" + APIMethods.reSubmitShipment;
                string methodURL = APIMethods.shipmentDetails + "/" + APIMethods.reSubmitShipment;

                Alerts.showBusyLoader(context);
                var Result = await objServiceHelper.PostRequest("", methodURL, token, true);
                Alerts.HideBusyLoader();
                //unAwardDialog.Hide();
                await RefreshShipmentData();
                if (Result != null && Result.Replace("\"", " ").Trim() == Constants.strSuccess)
                {
                    objUtility.GetDialog(context, Constants.strConfirmation, ReSubmitShipmentConfirm, Constants.btnTextYes, Constants.btnTextOk, "", ViewStates.Gone, ViewStates.Visible, ViewStates.Gone, ViewStates.Visible, ViewStates.Visible, ViewStates.Gone);
                }
                else if (Result != null)
                {
                    JObject response = JObject.Parse(Result);
                    string Message = Convert.ToString(response[Constants.strErrorMessage]);
                    if (!string.IsNullOrEmpty(Message))
                    {
                        Utility.ErrorLog(carrierShipmentDetail.BolNum, APIMethods.reSubmitShipment + Message, token, context);
                        objUtility.GetDialog(context, Constants.ErrorAlert, Message, Constants.btnTextYes, Constants.btnTextOk, "", ViewStates.Gone, ViewStates.Visible, ViewStates.Gone, ViewStates.Visible, ViewStates.Gone, ViewStates.Visible);
                    }
                }
                else
                {
                    Utility.ErrorLog(carrierShipmentDetail.BolNum, Constants.strServerError, token, context);
                    objUtility.GetDialog(context, Constants.ErrorAlert, Constants.strServerError, Constants.btnTextYes, Constants.btnTextOk, "", ViewStates.Gone, ViewStates.Visible, ViewStates.Gone, ViewStates.Visible, ViewStates.Gone, ViewStates.Visible);
                }
            }
            catch(Exception ex)
            {
                Alerts.HideBusyLoader();
            }
            finally
            {
                Alerts.HideBusyLoader();
            }
        }

        /// <summary>
        /// Show RateHistory Details
        /// </summary>
        private void ShowRateHistory()
        {
            try
            {
                Dialog unAwardDialog = objUtility.GetDialog(context, Constants.strRateHistory, "", Constants.btnTextYes, Constants.btnTextOk, "", ViewStates.Gone, ViewStates.Gone, ViewStates.Gone, ViewStates.Visible, ViewStates.Gone, ViewStates.Gone);
                LinearLayout lnlayoutRateHistoryHeading = unAwardDialog.FindViewById<LinearLayout>(Resource.Id.lnlayoutRateHistoryHeading);
                ListView lstRateHistory = unAwardDialog.FindViewById<ListView>(Resource.Id.lstRateHistory);
                lnlayoutRateHistoryHeading.Visibility = ViewStates.Visible;
                List<OldEntry> lstOldEntries = carrierShipmentDetail.OldEntries;
                if (lstOldEntries != null)
                {
                    RateHistoryEntriesAdapter objRateHistoryEntriesAdapter = new RateHistoryEntriesAdapter(context, lstOldEntries);
                    lstRateHistory.Adapter = objRateHistoryEntriesAdapter;
                }
            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
            }
        }

        /// <summary>
        /// Un-AwardShipment
        /// </summary>
        private void UnAwardShipment()
        {
            try
            {
                if (!Utility.FnIsOnline(context))
                {
                    Alerts.HideBusyLoader();
                    Toast.MakeText(context, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                id = CommanUtil.CompositeKey(carrierShipmentDetail.ClientID, carrierShipmentDetail.LocID, carrierShipmentDetail.BolNum);
                methodURI = APIMethods.shipmentDetails + "/" + id + "/" + APIMethods.unAward;
                string comment = carrierShipmentDetail.Entries[0].Comments;
                string unAwardShipment = Resources.GetString(Resource.String.UnAwardShipment);
                Dialog unAwardDialog = objUtility.GetDialog(context, Constants.strConfirmation, unAwardShipment, Constants.btnTextYes, Constants.btnTextNo, "", ViewStates.Gone, ViewStates.Visible, ViewStates.Visible, ViewStates.Visible, ViewStates.Visible, ViewStates.Gone);
                btnConfirm = unAwardDialog.FindViewById<Button>(Resource.Id.btnYes);
                btnConfirm.Click += async delegate
                {
                    unAwardDialog.Hide();
                    ServiceHelper objServiceHelper = new ServiceHelper();
                    Alerts.showBusyLoader(context);
                    var Result = await objServiceHelper.PostRequest("", methodURI, token, true);
                    await RefreshShipmentData();//Refresh List
                    if (Result != null && Result.Replace("\"", " ").Trim().ToUpper() == Constants.strSuccess.ToUpper())
                    {
                        btnUnAwardShip.Visibility = ViewStates.Gone;
                        btnReSubmit.Visibility = ViewStates.Visible;

                    }
                    else
                    {
                        JObject response = JObject.Parse(Result);
                        string Message = Convert.ToString(response[Constants.strErrorMessage]);
                        if (!string.IsNullOrEmpty(Message))
                        {
                            Utility.ErrorLog(carrierShipmentDetail.BolNum, APIMethods.unAward + Message, token, context);
                            unAwardDialog.Hide();
                            objUtility.GetDialog(context, Constants.ErrorAlert, Message, Constants.btnTextYes, Constants.btnTextOk, "", ViewStates.Gone, ViewStates.Visible, ViewStates.Gone, ViewStates.Visible, ViewStates.Gone, ViewStates.Visible);
                            Alerts.HideBusyLoader();
                        }
                        btnUnAwardShip.Visibility = ViewStates.Gone;
                        btnReSubmit.Visibility = ViewStates.Visible;
                    }
                    Alerts.HideBusyLoader();
                };
            }
            catch (Exception ex)
            {
                Alerts.HideBusyLoader();
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Function to assign date to the Date textview from calendar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ActivityDatePicker(object sender, DatePickerDialog.DateSetEventArgs e)
        {
            try
            {
                int datediff = 0;
                string currTime = DateTime.Now.ToString("MM/dd/yyyy");

                //Toast.MakeText(context, "ActivityDate" + e.Date.ToString("MM/dd/yyyy") + "datetimenow" + currTime, ToastLength.Long).Show();

                // datediff = DateTime.Compare(Convert.ToDateTime(e.Date.ToString("MM/dd/yyyy")), Convert.ToDateTime(DateTime.Now.ToString("MM/dd/yyyy")));
                //if (datediff <= 0)
                if ((Convert.ToDateTime(e.Date)) <= DateTime.Now.Date)

                {
                    Toast.MakeText(context, "Delivery date should be greater than current date", ToastLength.Long).Show();
                    return ;
                }

                //txtDeliveryDate.Text = e.Date.ToString("MM/dd/yyyy");
                txtDeliveryDate.Text = e.Date.ToShortDateString();
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Function to add AM or PM based on current time
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DelTime1Picker(object sender, TimePickerDialog.TimeSetEventArgs e)
        {
            try
            {
                txtDelTime1.Text = e.HourOfDay.ToString() + ":" + e.Minute.ToString() + " " + Utility.CheckAMPM(e);
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Function to add AM or PM based on current time
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DelTime2Picker(object sender, TimePickerDialog.TimeSetEventArgs e)
        {
            try
            {
                txtDelTime2.Text = e.HourOfDay.ToString() + ":" + e.Minute.ToString() + " " + Utility.CheckAMPM(e);
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Function to show or hide controls in the layout on condition
        /// </summary>
        private void ShowHideLayoutOnConditn()
        {
            // relCustomerControls
            if (carrierShipmentDetail.ViewAs.ToUpper() == Constants.strCustomer.ToUpper())
            {
                relCustomerControls.Visibility = ViewStates.Visible;
            }
            else
            {
                relCustomerControls.Visibility = ViewStates.Gone;
            }
            if (carrierShipmentDetail.CanResubmit)
            {
                btnReSubmit.Visibility = ViewStates.Visible;
            }
            else
            {
                btnReSubmit.Visibility = ViewStates.Gone;
            }

            if (carrierShipmentDetail.CanUnAward)
            {
                btnUnAwardShip.Visibility = ViewStates.Visible;
            }
            else
            {
                btnUnAwardShip.Visibility = ViewStates.Gone;
            }
            if (carrierShipmentDetail.CanBid)
            {
                lnrPlaceNewRate.Visibility = ViewStates.Visible;
            }
            else
            {
                lnrPlaceNewRate.Visibility = ViewStates.Gone;
            }
            if (carrierShipmentDetail.AcceptedSSes != null)
            {
                lnrAcceptedSSes.Visibility = ViewStates.Visible;
            }
            else
            {
                lnrAcceptedSSes.Visibility = ViewStates.Gone;
            }
            if (carrierShipmentDetail.UsesBTFuel == false && carrierShipmentDetail.HideFuel == false)
            {
                lnrFuelChg.Visibility = ViewStates.Visible;
            }
            else
            {
                lnrFuelChg.Visibility = ViewStates.Gone;
            }
            if (carrierShipmentDetail.UsesBTFuel == true && carrierShipmentDetail.HideFuel == false)
            {
                lnrFuelChg2.Visibility = ViewStates.Visible;
            }
            else
            {
                lnrFuelChg2.Visibility = ViewStates.Gone;
            }
            if (carrierShipmentDetail.CanBidAlterTerms)
            {
                lnrAcceptTerms.Visibility = ViewStates.Visible;
            }
            else
            {
                lnrAcceptTerms.Visibility = ViewStates.Gone;
            }
            if (carrierShipmentDetail.BidWithDelDate)
            {
                lnrBidWithDelDate.Visibility = ViewStates.Visible;
            }
            else
            {
                lnrBidWithDelDate.Visibility = ViewStates.Gone;
            }

        }

        /// <summary>
        /// Function to submit new rate bid for the shipment
        /// </summary>
        /// <returns></returns>
        private async Task<bool> SubmitNewRate()
        {
           
            try
            {
                if (carrierShipmentDetail.BidWithDelDate)
                {
                    if (txtDeliveryDate.Text != "")
                    {
                        ActivityDate = Convert.ToDateTime(txtDeliveryDate.Text).ToString("MM/dd/yyyy");
                        
                        activityDate = CommanUtil.FormatDate(ActivityDate);
                        delDate = activityDate[2] + "-" + activityDate[0] + "-" + activityDate[1];
                       // Toast.MakeText(context, delDate, ToastLength.Long).Show();
                    }
                    else
                    {
                        Toast.MakeText(context, "Please enter a valid date", ToastLength.Long).Show();
                        return false;
                    }

                    if (!string.IsNullOrEmpty(txtDelTime1.Text))
                    {
                        if ((txtDelTime1.Text.Contains("AM")))
                        {
                            delTime1 = txtDelTime1.Text.Replace("AM", "").Trim();
                        }
                        else
                        {
                            delTime1 = txtDelTime1.Text.Replace("PM", "").Trim();
                        }
                    }
                    else
                    {
                        Toast.MakeText(context, "Please enter a valid time", ToastLength.Long).Show();
                        return false;
                    }
                    if (!string.IsNullOrEmpty(txtDelTime2.Text))
                    {
                        if ((txtDelTime2.Text.Contains("AM")))
                        {
                            delTime2 = txtDelTime2.Text.Replace("AM", "").Trim();
                        }
                        else
                        {
                            delTime2 = txtDelTime2.Text.Replace("PM", "").Trim();
                        }
                    }
                    else
                    {
                        Toast.MakeText(context, "Please enter a valid time", ToastLength.Long).Show();
                        return false;
                    }
                }
                
                if (carrierShipmentDetail.AcceptedSSes != null)
                {
                    if (isReviewedNdAck != true)
                    {
                        Toast.MakeText(context, Constants.strAcknowledge, ToastLength.Short).Show();
                        return false;
                    }
                }
                if (string.IsNullOrEmpty(txtBaseCharge.Text) || txtBaseCharge.Text == ".")
                {
                    Toast.MakeText(context, Constants.strBaseCharge, ToastLength.Short).Show();
                    return false;
                }
                if (carrierShipmentDetail.UsesBTFuel == true || carrierShipmentDetail.HideFuel == true)
                {
                    txtFuelCharge.Text = "0.00";
                }
                else
                {
                    if (string.IsNullOrEmpty(txtFuelCharge.Text) || txtFuelCharge.Text == ".")
                    {
                        Alerts.HideBusyLoader();
                        Toast.MakeText(context, Constants.strFuelCharge, ToastLength.Short).Show();
                        return false;
                    }
                }
                if (carrierShipmentDetail.CanBidAlterTerms && chkNewRateAlter.Checked)
                {
                    isAlteredTerms = true;
                    if (string.IsNullOrEmpty(txtComments.Text.Trim()))
                    {
                        isAlteredTerms = false;
                        Alerts.HideBusyLoader();
                        Toast.MakeText(context, Constants.strComments, ToastLength.Short).Show();
                        return false;
                    }
                }
                else
                {
                    isAlteredTerms = false;
                }
                if (!Utility.FnIsOnline(context))
                {
                    Alerts.HideBusyLoader();
                    Toast.MakeText(context, Constants.strNoInternet, ToastLength.Short).Show();
                    return false;
                }
                Alerts.showBusyLoader(context);
                await Task.Delay(500);
                CalTotalCharge(txtBaseCharge.Text, txtAccessCharge.Text, txtFuelCharge.Text);
                txtBaseCharge.ClearFocus();
                txtAccessCharge.ClearFocus();
                txtFuelCharge.ClearFocus();
                methodURI = APIMethods.shipmentDetails + "/" + id + "/" + APIMethods.bid;
                ratePayload = GetRatePayload();
                ServiceHelper objServiceHelper = new ServiceHelper();
                string Result = await objServiceHelper.PostRequestJson(ratePayload, methodURI, token, true);
               // Toast.MakeText(context, Result, ToastLength.Long).Show();
                //string Result = "test";
                if (Result != null)
                {
                    await RefreshShipmentData();//Refresh List
                    ResetRateEntries();   // Reset controls values
                    if (Result.Replace("\"", " ").Trim().ToUpper() == Constants.strSuccess.ToUpper())
                    {
                        Alerts.HideBusyLoader();
                    }
                    else
                    {
                        JObject response = JObject.Parse(Result);
                        string Message = Convert.ToString(response[Constants.strErrorMessage]);
                        Utility.ErrorLog(carrierShipmentDetail.BolNum, APIMethods.bid + Message, token, context);
                        Alerts.HideBusyLoader();
                        string dialogHeader = Resources.GetString(Resource.String.ErrorAlert);
                        dialog = objUtility.GetDialog(context, dialogHeader, Message, Constants.btnTextOk, Constants.btnTextNo, string.Empty, ViewStates.Gone, ViewStates.Visible, ViewStates.Visible, ViewStates.Gone, ViewStates.Gone, ViewStates.Visible);
                        btnConfirm = dialog.FindViewById<Button>(Resource.Id.btnYes);
                        btnConfirm.Click += delegate
                        {
                            dialog.Hide();
                        };
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                Alerts.HideBusyLoader();
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                ResetRateEntries();
                return false;
            }
           
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task RefreshShipmentData()
        {
            try
            {
                string methodName = APIMethods.shipmentDetails + "/" + carrierShipmentDetail.ClientID + "|" + carrierShipmentDetail.BolNum;
                string response = await objUtility.BindShipmentDetail(methodName, context);//Refresh shipment detail data
                if (!string.IsNullOrEmpty(response))
                {
                    carrierShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(response);
                    shipmentDetails = response;
                }
                BindRateEntryData(carrierShipmentDetail);
            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
            }
        }

        /// <summary>
        /// Function to reset all the fields for Rate Entry
        /// </summary>
        public void ResetRateEntries()
        {
            try
            {
                isReviewedNdAck = carrierShipmentDetail.AcceptedSSes == null ? false : Convert.ToBoolean(carrierShipmentDetail.AcceptedSSes);
                pickupDtTm_str = carrierShipmentDetail.PickupStr;
                string[] pickupDate_str = (pickupDtTm_str.Split(' ')[0]).Split('/');
                pickupDate_dt = new DateTime(Convert.ToInt32(pickupDate_str[2]), Convert.ToInt32(pickupDate_str[0]), Convert.ToInt32(pickupDate_str[1]));
                //pickupDate_dt = DateTime.Now;
                pickupDate_dt = pickupDate_dt.AddDays(1);

                string pickUpMonth = (pickupDate_dt.Month) < 10 ? "0" + (pickupDate_dt.Month) : Convert.ToString(pickupDate_dt.Month + 1);
                string pickUpDate = pickupDate_dt.Day < 10 ? "0" + Convert.ToString(pickupDate_dt.Day) : Convert.ToString(pickupDate_dt.Day);
                string pickUpYear = Convert.ToString(pickupDate_dt.Year);
                strArrayDelDate = new string[] { pickUpYear, pickUpMonth, pickUpDate };
                delDate = string.Join("-", strArrayDelDate);
                string[] splittedPickup = pickupDtTm_str.Split('-');
                string[] splitDate = splittedPickup[0].Split('/');

                isAlteredTerms = false;
                txtComments.Text = string.Empty;
                chkNewRateAlter.Checked = false;
                txtBaseCharge.Text = string.Empty;
                txtFuelCharge.Text = string.Empty;
                txtAccessCharge.Text = string.Empty;
                txtTotal.Text = "0.00";
                rateComments = "";
                AccessorialCharge = "";
                FuelCharge = "";
                BaseCharge = "";
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Function to prepare the payload for the API while submitting new rate
        /// </summary>
        /// <returns></returns>
        public string GetRatePayload()
        {
            try
            {
                payload_str = "\"BaseCharge\"" + ":" + "\"" + txtBaseCharge.Text + "\"";
                payload_str += "," + "\"FuelCharge\"" + ":" + "\"" + txtFuelCharge.Text + "\"";
                payload_str += "," + "\"SSCharge\"" + ":" + "\"" + txtAccessCharge.Text + "\"";
                if (carrierShipmentDetail.BidWithDelDate)
                {
                    payload_str += "," + "\"DeliveryDateStart\"" + ":" + "\"" + delDate + " " + delTime1 + "\"";
                    payload_str += "," + "\"DeliveryDateEnd\"" + ":" + "\"" + delDate + " " + delTime2 + "\"";
                }
                if (carrierShipmentDetail.CanBidAlterTerms)
                {
                    payload_str += "," + "\"AlteredTerms\"" + ":" + "\"" + isAlteredTerms + "\"";
                }
                if (carrierShipmentDetail.AcceptedSSes != null)
                {
                    payload_str += "," + "\"AcceptSSes\"" + ":" + "\"" + true + "\"";
                }
                payload_str += "," + "\"Comments\"" + ":" + "\"" + txtComments.Text + "\"";
                payload_str = "{" + payload_str + "}";
                return payload_str;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Function to calculate total charge when tapped on the screen anywhere
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ParentLayout_Click(object sender, EventArgs e)
        {
            try
            {
                CalTotalCharge(txtBaseCharge.Text, txtAccessCharge.Text, txtFuelCharge.Text);
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Parent Layout Touch
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ParentLayout_Touch(object sender, View.TouchEventArgs e)
        {
            try
            {
                CalTotalCharge(txtBaseCharge.Text, txtAccessCharge.Text, txtFuelCharge.Text);
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Function to bind the Rate entry data to the rate entry section
        /// </summary>
        /// <param name="carrierShipmentDetail"></param>
        private void BindRateEntryData(CarrierShipmentDetails carrierShipmentDetail)
        {
            List<Entry> lstRateEntries = carrierShipmentDetail.Entries;
            if (lstRateEntries != null && lstRateEntries.Count > 0)
            {
                RateEntriesAdapter objRateEntriesAdapter = new RateEntriesAdapter(context, lstRateEntries, carrierShipmentDetail);
                lstViewRateEntries.Adapter = objRateEntriesAdapter;
                lstViewRateEntries.Visibility = ViewStates.Visible;

            }
            else
            {
                lstViewRateEntries.Visibility = ViewStates.Gone;
            }

        }


        /// <summary>
        /// Calculate Total Charge
        /// </summary>
        /// <param name="baseCharge"></param>
        /// <param name="accessoCharge"></param>
        /// <param name="fuelCharge"></param>
        /// <returns></returns>
        private double CalTotalCharge(string baseCharge, string accessoCharge, string fuelCharge)
        {
            try
            {
                bool isvalidated = IsValidated(carrierShipmentDetail);
                double BaseCharge = 0.00;
                double AccessoCharge = 0.00;
                double FuelCharge = 0.00;
                if (!string.IsNullOrEmpty(baseCharge) && baseCharge != ".")
                {
                    BaseCharge = Convert.ToDouble(baseCharge);
                }
                if (!string.IsNullOrEmpty(accessoCharge) && accessoCharge != ".")
                {
                    AccessoCharge = Convert.ToDouble(accessoCharge);
                }
                if (!string.IsNullOrEmpty(fuelCharge) && fuelCharge != ".")
                {
                    FuelCharge = Convert.ToDouble(fuelCharge);
                }
                double TotalCharge = BaseCharge + AccessoCharge + FuelCharge;
                txtTotal.Text = " " + Convert.ToString(TotalCharge);
                return TotalCharge;
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                return 0.0;
            }
        }

        /// <summary>
        /// IsValidated
        /// </summary>
        /// <param name="lstShipmentDetail"></param>
        /// <returns></returns>
        private bool IsValidated(CarrierShipmentDetails lstShipmentDetail)
        {
            return true;
        }

        /// <summary>
        /// Image Button Rate_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgButtonRate_Click(object sender, EventArgs e)
        {
            try
            {
                Dialog dialog;
                AlertDialog.Builder alert = new AlertDialog.Builder(context);
                alert.SetView(Resource.Layout.RateEntriesLayout);
                dialog = alert.Create();
                dialog.Show();
                dialog.SetCancelable(false);
                Button btnOK = dialog.FindViewById<Button>(Resource.Id.btnCancel);
                TextView txtShipCost = dialog.FindViewById<TextView>(Resource.Id.txtShipCost);
                btnOK.Click += delegate
                {
                    HidePopup(dialog);
                };
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Hide Popup
        /// </summary>
        /// <param name="dialog"></param>
        private void HidePopup(Dialog dialog)
        {
            dialog.Hide();
        }

    }
}