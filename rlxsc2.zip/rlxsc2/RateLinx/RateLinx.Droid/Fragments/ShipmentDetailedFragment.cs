using System;
using Android.OS;
using Android.Views;
using Android.Widget;
using V4App = Android.Support.V4.App;
using Android.Support.Design.Widget;
using Android.Support.V4.View;
using RateLinx.Droid.Adapters;
using RateLinx.Models;
using Newtonsoft.Json;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;
using RateLinx.Droid.Activities;
using RateLinx.APIs;
using Android.App;

namespace RateLinx.Droid.Fragments
{
    /// <summary>
    /// Shipment Details Fragment
    /// </summary>
    public class ShipmentDetailedFragment : V4App.Fragment, ViewPager.IOnPageChangeListener
    {
        #region Global variables
        Utility objUtility = null;
        View ShipmentDetailed = null;        
        TabLayout _tabs = null;
        ViewPager _pager = null;
        string[] bidNow = null;
        private RateDetailFragment RateDetailFragment = null;
        private SupportingFragment SupportingFragment = null;
        private NewRateFragment NewRateFragment = null;
        private ConversationFragment ConversationFragment = null;
        string NewRate = string.Empty;
        CarrierShipmentDetails lstShipmentDetail = null;
        Activity context;

        ImageView ImgRefreshIcon;
        #endregion

        /// <summary>
        /// Creating context
        /// </summary>
        /// <param name="context"></param>
        public ShipmentDetailedFragment(Activity context)
        {
            this.context = context;

        }

        /// <summary>
        /// Creating The Fragments for Shipment Details
        /// </summary>
        /// <param name="inflater"></param>
        /// <param name="container"></param>
        /// <param name="savedInstanceState"></param>
        /// <returns></returns>
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                // Use this to return your custom view for this Fragment
                ShipmentDetailed = inflater.Inflate(Resource.Layout.ShipmentDetailedFragment, container, false);
                ImgRefreshIcon = context.FindViewById<ImageView>(Resource.Id.ImgRefreshIcon);
                ImgRefreshIcon.Click += async delegate
                {
                    if (CommanUtil.IsTimeOut())
                    {
                        Utility.ActiveConversationHeader = 0;
                        Alerts.showBusyLoader(context);
                        if (!Utility.FnIsOnline(context))
                        {
                            Alerts.HideBusyLoader();
                            Toast.MakeText(context, Constants.strNoInternet, ToastLength.Short).Show();
                            return;
                        }
                        objUtility = new Utility();
                        string[] compositeKey = context.Intent.GetStringExtra("compositeKey").Split('|');
                        string methodName = APIMethods.shipmentDetails + "/" + compositeKey[0] + "|" + compositeKey[1];
                        string response = await objUtility.BindShipmentDetail(methodName, context);
                        if (!string.IsNullOrEmpty(response))
                        {
                            lstShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(response);
                        }
                        BindSliderFragments();
                        Alerts.HideBusyLoader();
                    }
                    else
                    {
                        //Token Exired
                        Utility.ExpireSession(context);
                    }
                };
                string notification_compositekey = Utility.sharedPreferences.GetString("notification_compositekey", null);
                if (!string.IsNullOrEmpty(notification_compositekey))
                {
                    bidNow = notification_compositekey.Split('|');
                    Utility.sharedPreferences.Edit().Remove("notification_compositekey").Commit();
                }
                else
                {
                    if (context.Intent.GetStringExtra("compositeKey") != null)
                    {
                        bidNow = context.Intent.GetStringExtra("compositeKey").Split('|');
                    }
                    else if (!string.IsNullOrEmpty(CommanUtil.shipClientIdBolNo))
                    {
                        bidNow = CommanUtil.shipClientIdBolNo.Split('|');
                    }
                }
                //Slider Layout
                _pager = ShipmentDetailed.FindViewById<ViewPager>(Resource.Id.pager);
                _tabs = ShipmentDetailed.FindViewById<TabLayout>(Resource.Id.sliding_tabs);
                //Binding Slider Fragments
                BindSliderFragments();

                if (!string.IsNullOrEmpty(bidNow[2]) && bidNow[2] != "#")
                {
                    _pager.SetCurrentItem(Convert.ToInt32(bidNow[2]), true); //When Click Bid Now icon From Active Shipment
                }
                if(CommanUtil.isReply == true)
                {
                    _pager.SetCurrentItem(3, true);
                    CommanUtil.isReply = false;
                }
                return ShipmentDetailed;
            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                //Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();               
                return null;
            }
        }

        /// <summary>
        /// Tabbed Layout Binding from four fragments
        /// </summary>
        private void BindSliderFragments()
        {
            try
            {
                SetupViewPager(_pager);
                _tabs.SetupWithViewPager(_pager);
                setupTabIcons();
                _pager.AddOnPageChangeListener(this);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Init Fragment
        /// </summary>
        private void InitFragment()
        {
            try
            {
                RateDetailFragment = new RateDetailFragment(context);// new ActiveShipmentFragment(context);
                SupportingFragment = new SupportingFragment(context);// new AwardedShipmentFragment(context);
                NewRateFragment = new NewRateFragment(context);// new RecentShipmentFragment(context);
                ConversationFragment = new ConversationFragment(context);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Initializing Tabbed Icons
        /// </summary>
        private int[] tabIcons = {
            Resource.Drawable.rate_entry,
            Resource.Drawable.supporting,
            Resource.Drawable.new_rate,
            Resource.Drawable.conversation
        };

        /// <summary>
        /// Setup tab Icon In a Manner
        /// </summary>
        private void setupTabIcons()
        {
            try
            {
                _tabs.GetTabAt(0).SetIcon(tabIcons[0]);
                _tabs.GetTabAt(1).SetIcon(tabIcons[1]);
                _tabs.GetTabAt(2).SetIcon(tabIcons[2]);
                _tabs.GetTabAt(3).SetIcon(tabIcons[2]);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Assigning the layout in View Pager
        /// </summary>
        /// <param name="viewPager"></param>
        private void SetupViewPager(ViewPager viewPager)
        {
            try
            {
                string NewRate = string.Empty;
                lstShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(Utility.sharedPreferences.GetString(Constants.shipmentDetails, null));
                if(lstShipmentDetail.ViewAs == Constants.strCarrier)
                {
                    NewRate = Constants.strNewRate;
                }
                else
                {
                    NewRate = Constants.strRate;
                }
                InitFragment();
                ShipmentDetailedAdapter adapter = new ShipmentDetailedAdapter(ChildFragmentManager);
                adapter.AddFragment(RateDetailFragment, Constants.strRateDetail);
                adapter.AddFragment(SupportingFragment, Constants.strSupporting);
                adapter.AddFragment(NewRateFragment, NewRate);
                adapter.AddFragment(ConversationFragment, Constants.strConversation);
                viewPager.Adapter = adapter;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Interface need to implement
        /// </summary>
        /// <param name="state"></param>
        public void OnPageScrollStateChanged(int state)
        {
            //throw new NotImplementedException();
        }

        /// <summary>
        /// on Change of tab image icon change functionality 
        /// </summary>
        /// <param name="position"></param>
        /// <param name="positionOffset"></param>
        /// <param name="positionOffsetPixels"></param>
        public void OnPageScrolled(int position, float positionOffset, int positionOffsetPixels)
        {
            try
            {
                switch (position)
                {
                    case 0:
                        _tabs.GetTabAt(0).SetIcon(Resource.Drawable.rate_entry_hover);
                        _tabs.GetTabAt(1).SetIcon(Resource.Drawable.supporting);
                        _tabs.GetTabAt(2).SetIcon(Resource.Drawable.new_rate);
                        _tabs.GetTabAt(3).SetIcon(Resource.Drawable.conversation);
                        break;
                    case 1:
                        _tabs.GetTabAt(1).SetIcon(Resource.Drawable.supporting_hover);
                        _tabs.GetTabAt(0).SetIcon(Resource.Drawable.rate_entry);
                        _tabs.GetTabAt(2).SetIcon(Resource.Drawable.new_rate);
                        _tabs.GetTabAt(3).SetIcon(Resource.Drawable.conversation);
                        break;
                    case 2:
                        _tabs.GetTabAt(2).SetIcon(Resource.Drawable.new_rate_hover);
                        _tabs.GetTabAt(0).SetIcon(Resource.Drawable.rate_entry);
                        _tabs.GetTabAt(1).SetIcon(Resource.Drawable.supporting);
                        _tabs.GetTabAt(3).SetIcon(Resource.Drawable.conversation);
                        break;

                    default:
                        _tabs.GetTabAt(3).SetIcon(Resource.Drawable.conversation_hover);
                        _tabs.GetTabAt(0).SetIcon(Resource.Drawable.rate_entry);
                        _tabs.GetTabAt(1).SetIcon(Resource.Drawable.supporting);
                        _tabs.GetTabAt(2).SetIcon(Resource.Drawable.new_rate);
                        break;
                }               
            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Unused but can't deleted it
        /// </summary>
        /// <param name="position"></param>
        public void OnPageSelected(int position)
        {
            // throw new NotImplementedException();
        }
    }
}