using System;
using System.Collections.Generic;
using Android.App;
using Android.OS;
using Android.Views;
using Android.Widget;
using RateLinx.Droid.Utilities;
using RateLinx.Models;
using Newtonsoft.Json;
using V4App = Android.Support.V4.App;
using System.Threading.Tasks;
using RateLinx.Droid.Adapters;
using RateLinx.Helper;
using RateLinx.APIs;
using Newtonsoft.Json.Linq;
using System.Threading;
using Android.Support.V7.Widget;
using RateLinx.Droid.Activities;
using Android.Content;

namespace RateLinx.Droid.Fragments
{
    /// <summary>
    /// Meta Tag of the ActiveShipmentFragment
    /// </summary>
    public class ActiveShipmentFragment : V4App.Fragment
    {
        #region Declaration of controls instances and variables  
        RecyclerView lstViewActiveShipments = null;
        //string activeShipments = string.Empty;
        View view = null;
        Intent objIntent = null;
        //int shipmentCount = 0;
        readonly Activity context = null;
        TextView txtActiveMsg = null;
        List<ActiveShipments> lstActiveShipments = null;  // Declare active shipment list
        AdapterActiveShipments adptrActiveShipments = null;
        bool isActiveIntervalAllow = false;
        RemainingTime objRemainingTime;
        /// <summary>
        /// 
        /// </summary>
        public int remainingTime = 0;
        string[] bidDeadLine = null;
        string[] year = null;
        string[] time = null;
        DateTime bidDateTime;
        DateTime currentTime;
        decimal span;
        double diffInMili;
        int diffDays;
        int hours;
        string minutes;
        string seconds;
        /// <summary>
        /// 
        /// </summary>
        public System.Timers.Timer _timer = new System.Timers.Timer();
        /// <summary>
        /// 
        /// </summary>
        public bool isFocused = true;
        string timerMessage = string.Empty;
        #endregion

        /// <summary>
        /// Activity Initialization
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public ActiveShipmentFragment(Activity context)
        {
            this.context = context;
            lstActiveShipments = new List<ActiveShipments>();
        }

        /// <summary>
        /// ActiveShipmentFragment : Page Load event
        /// </summary>
        /// <param name="inflater"></param>
        /// <param name="container"></param>
        /// <param name="savedInstanceState"></param>
        /// <returns></returns>
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                base.OnCreateView(inflater, container, savedInstanceState);
                view = inflater.Inflate(Resource.Layout.ActiveFragment, null);
                lstViewActiveShipments = view.FindViewById<RecyclerView>(Resource.Id.lstViewActiveShipments);
                lstViewActiveShipments.SetLayoutManager(new LinearLayoutManager(Activity));
                txtActiveMsg = view.FindViewById<TextView>(Resource.Id.txtActiveMsg);
                adptrActiveShipments = null;
                _timer = new System.Timers.Timer();
                _timer.Interval = 1000;
                _timer.Elapsed += delegate
                {
                    context.RunOnUiThread(() =>
                    {
                        OnTimedEvent();
                    });
                };

                return view;
            }
            catch
            {
                Utility.ErrorLog(Constants.shipmentDetail, Constants.updateShipmentStatus, CommanUtil.tokenNo, context);
                return view;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void OnTimedEvent()
        {
            try
            {
                if (isActiveIntervalAllow && isFocused)
                {
                    BindActiveShipments();
                    CommanUtil.stopThread();
                }
                else
                {
                    _timer.Stop();
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
            }
        }

        /// <summary>
        /// Bind Active Shipment Data
        /// </summary>
        public void BindActiveShipments()
        {
            try
            {
                if (!string.IsNullOrEmpty(Constants.activeShipmentsList) && CommanUtil.isShowCharges)
                {
                    lstActiveShipments.Clear();
                    lstActiveShipments = (List<ActiveShipments>)JsonConvert.DeserializeObject(Constants.activeShipmentsList, typeof(List<ActiveShipments>));
                    if (lstActiveShipments != null && lstActiveShipments.Count > 0)
                    {
                        for (int lstCount = 0; lstCount <= lstActiveShipments.Count - 1; lstCount++)
                        {
                            lstActiveShipments[lstCount].ShipTime = CountDown(lstActiveShipments[lstCount].DeadLineUTC);
                        }
                        if (adptrActiveShipments == null)
                        {
                            adptrActiveShipments = new AdapterActiveShipments(context, lstActiveShipments);
                            adptrActiveShipments.ItemClick += AdptrActiveShipments_ItemClick;
                            lstViewActiveShipments.SetAdapter(adptrActiveShipments);
                        }
                        else
                        {
                            adptrActiveShipments.context = context;
                            adptrActiveShipments.lstActiveShipments.Clear();
                            adptrActiveShipments.lstActiveShipments.AddRange(lstActiveShipments); //lstActiveShipments;
                            adptrActiveShipments.NotifyDataSetChanged();
                        }
                        txtActiveMsg.Visibility = ViewStates.Gone;
                        lstViewActiveShipments.Visibility = ViewStates.Visible;
                    }
                    else
                    {
                        txtActiveMsg.Visibility = ViewStates.Visible;
                        lstViewActiveShipments.Visibility = ViewStates.Gone;
                        txtActiveMsg.Text = Constants.ActiveShipments;
                    }
                }
                else
                {
                    txtActiveMsg.Visibility = ViewStates.Visible;
                    lstViewActiveShipments.Visibility = ViewStates.Gone;
                    txtActiveMsg.Text = Constants.ActiveShipments;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void AdptrActiveShipments_ItemClick(object sender, int e)
        {
            int Position = e;

            if (CommanUtil.IsTimeOut())
            {
                var value = CommanUtil.lstRecyclerActiveShipments[Position].ClientID + "|" + CommanUtil.lstRecyclerActiveShipments[Position].BolNum + "|" + "";
                objIntent = Utility.RedirectTo(context, typeof(ShipmentsDetailedActivity), "compositeKey", value);
                context.StartActivity(objIntent);
            }
            else
            {
                //Token Exired
                Utility.ExpireSession(context);
            }
        }

        /// <summary>
        /// OnResume get start the interval
        /// </summary>
        public override void OnResume()
        {
            isActiveIntervalAllow = true;
            _timer.Enabled = true;
            isFocused = true;
            _timer.Start();
            OnTimedEvent();
            base.OnResume();
        }

        /// <summary>
        /// Stop the interval
        /// </summary>
        public override void OnPause()
        {
            isActiveIntervalAllow = false;
            isFocused = false;
            _timer.Stop();
            _timer.Enabled = false;
            base.OnPause();
        }

        /// <summary>
        /// Count Down Timer
        /// </summary>
        /// <param name="DeadLineUTC"></param>
        /// <returns></returns>
        public string CountDown(string DeadLineUTC)
        {
            try
            {
                if (!string.IsNullOrEmpty(CommanUtil.tokenNo))
                {
                    //Remove slashes from date time string
                    bidDeadLine = DeadLineUTC.Split('/');
                    year = bidDeadLine[2].Split(' '); //Remove space between year and time
                    time = year[1].Split(':');  //split hours and time
                    if (year[2] == "PM")
                    {
                        int hour = Convert.ToInt32(time[0]);
                        time[0] = Convert.ToString(hour + 12);
                    }
                    bidDateTime = new DateTime(Convert.ToInt32(year[0]), Convert.ToInt32(bidDeadLine[0]), Convert.ToInt32(bidDeadLine[1]), Convert.ToInt32(time[0]), Convert.ToInt32(time[1]), Convert.ToInt32(time[2]));
                    currentTime = TimeZoneInfo.ConvertTime(DateTime.Now, TimeZoneInfo.FindSystemTimeZoneById("UTC"));
                    span = Convert.ToDecimal(bidDateTime.Subtract(currentTime).TotalMilliseconds);
                    diffInMili = (double)span;
                    diffDays = (int)Math.Floor(span / (1000 * 3600 * 24));
                    hours = (int)Math.Floor(span / 3600000); // 1 Hour = 36000 Milliseconds
                    minutes = Convert.ToString((int)Math.Floor((span % 3600000) / 60000)); // 1 Minutes = 60000 Milliseconds
                    seconds = Convert.ToString((int)Math.Floor(((span % 360000) % 60000) / 1000));// 1 Second = 1000 Milliseconds

                    objRemainingTime = new RemainingTime
                    {
                        Days = diffDays,
                        Hours = hours,
                        Minutes = Convert.ToInt32(minutes),
                        Seconds = Convert.ToInt32(seconds)
                    };
                    var clock = hours + ":" + minutes + ":" + seconds;

                    remainingTime = objRemainingTime.Hours;
                    if (remainingTime < 0)
                    {
                        remainingTime = 0;
                    }
                    if (objRemainingTime.Minutes < 10)
                    {
                        minutes = "0" + minutes;
                    }
                    if (objRemainingTime.Seconds < 10)
                    {
                        seconds = "0" + seconds;
                    }
                    if (remainingTime < 48 && remainingTime >= 5)
                    {
                        clock = hours + ":" + minutes;
                    }
                    else
                    {
                        clock = hours + ":" + minutes + ":" + seconds;
                    }
                    if (bidDateTime > currentTime)
                    {
                        if (objRemainingTime.Hours > 48)
                        {
                            timerMessage = objRemainingTime.Days + " " + Constants.daysLeft;
                        }
                        else if (objRemainingTime.Hours == 0 && objRemainingTime.Minutes == 0 && objRemainingTime.Seconds == 0)
                        {
                            timerMessage = Constants.timerMsg;
                        }
                        else
                        {
                            timerMessage = clock + " hours left";
                        }
                    }
                    else
                    {
                        timerMessage = Constants.timerMsg;
                    }
                }
                return timerMessage;
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        protected void ClearControls()
        {
            try
            {
                if (adptrActiveShipments != null)
                {
                    adptrActiveShipments = null;
                    adptrActiveShipments.Dispose();
                }
                if (lstViewActiveShipments != null)
                {
                    lstViewActiveShipments = null;
                    lstViewActiveShipments.Dispose();
                }
                if (lstActiveShipments != null)
                {
                    lstActiveShipments = null;
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
            }
            finally
            {
                GC.Collect(GC.MaxGeneration);
            }
        }
    }
}