﻿using System;
using System.Collections.Generic;
using V4App = Android.Support.V4.App;
using Android.App;
using Android.OS;
using Android.Views;
using Android.Widget;
using RateLinx.APIs;
using RateLinx.Droid.Utilities;
using Newtonsoft.Json.Linq;
using RateLinx.Helper;
using RateLinx.Droid.Adapters;
using Newtonsoft.Json;
using Android.Graphics;
using System.Threading.Tasks;
using RateLinx.Droid.ServiceModels;
using Exception = System.Exception;
using System.Linq;
using Android.Util;
using Android.Views.Animations;
using Math = System.Math;
using RateLinx.Models;

namespace RateLinx.Droid.Fragments
{

    /// <summary>
    /// Order History Fragment
    /// </summary>
    public class OrderHistoryFragment : V4App.Fragment
    {
        #region Declaration of controls instances and variables 
        List<string> lstSelectedOrder = null;
        ServiceHelper objServicehelper = null;
        string varFilterQuery = string.Empty;
        string strToken = string.Empty;
        string postData = string.Empty;
        View orderHistoryView, viewLine, viewLine1 = null;
        string postAcceptedOrder = string.Empty;
        Activity context;
        View lnrLayoutHRF;
        View pagingLayoutView = null;
        LinearLayout lnrLayoutPaging, lnrHeaderLayout, linearLayout2, linearLayout4 = null;//lnrMainLayout
        TextView pagingNumber = null;
        RelativeLayout lnrOrderHistoryData = null;
        int pageCount = 0;
        ListView lstViewOrderHistoryResult = null;
        List<TextView> pagingTextViewArr = new List<TextView>();
        List<OrderHistory> lstOrderHistoryResult = null;
        TextView txtNoHistoryData, txtOrderID;
        CheckBox chkSelectAll;
        Button btnAcceptOrder, btnDenyorder, btnSearchByOrderID, btnclearSearch = null;
        HorizontalScrollView horizontalScrollView;
        string strOrderID = "";
        #endregion

        /// <summary>
        /// Initializing constrctor for activity
        /// </summary>
        /// <param name="context">Activity</param>
        public OrderHistoryFragment(Activity context)
        {
            this.context = context;
            objServicehelper = new ServiceHelper();
        }

        /// <summary>
        /// Layout load event
        /// </summary>
        /// <param name="inflater"></param>
        /// <param name="container"></param>
        /// <param name="savedInstanceState"></param>
        /// <returns></returns>
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                if (orderHistoryView == null)
                {
                    // Use this to return your custom view for this Fragment
                    orderHistoryView = inflater.Inflate(Resource.Layout.OrderHistory, container, false);
                    GetControlsById();
                }
                return orderHistoryView;
            }
            catch
            {
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                return orderHistoryView;
            }
        }

        /// <summary>
        /// Find Controls by id and generating controls
        /// </summary>
        public async void GetControlsById()
        {
            try
            {
                strToken = CommanUtil.tokenNo;
                lstViewOrderHistoryResult = orderHistoryView.FindViewById<ListView>(Resource.Id.lstHistoryResult);
                viewLine = orderHistoryView.FindViewById<View>(Resource.Id.viewLine);
                viewLine1 = orderHistoryView.FindViewById<View>(Resource.Id.viewLine1);
                lnrLayoutPaging = orderHistoryView.FindViewById<LinearLayout>(Resource.Id.lnrLayoutPaging);
                lnrOrderHistoryData = orderHistoryView.FindViewById<RelativeLayout>(Resource.Id.lnrHistoryData);
                txtNoHistoryData = orderHistoryView.FindViewById<TextView>(Resource.Id.txtNoHistoryData);
                txtOrderID = orderHistoryView.FindViewById<TextView>(Resource.Id.txtOrderID);
                btnSearchByOrderID = orderHistoryView.FindViewById<Button>(Resource.Id.btnSearch);
                btnclearSearch = orderHistoryView.FindViewById<Button>(Resource.Id.btnClear);
                btnAcceptOrder = orderHistoryView.FindViewById<Button>(Resource.Id.btnAccept);
                btnDenyorder = orderHistoryView.FindViewById<Button>(Resource.Id.btnDeny);
                btnSearchByOrderID.Click += BtnSearchByOrderID_Click;
                btnclearSearch.Click += BtnclearSearch_Click;
                btnAcceptOrder.Click += BtnAcceptOrder_Click;
                btnDenyorder.Click += BtnDenyorder_Click;
                context.LayoutInflater.Inflate(Resource.Layout.PagingLayout, null);
                lnrLayoutHRF = context.LayoutInflater.Inflate(Resource.Layout.OrderHistoryLayout, null);
                chkSelectAll = orderHistoryView.FindViewById<CheckBox>(Resource.Id.chkSelectAll);
                lnrHeaderLayout = orderHistoryView.FindViewById<LinearLayout>(Resource.Id.lnrHeaderLayout);
                linearLayout2 = orderHistoryView.FindViewById<LinearLayout>(Resource.Id.linearLayout2);
                linearLayout4 = orderHistoryView.FindViewById<LinearLayout>(Resource.Id.linearLayout4);
                horizontalScrollView = orderHistoryView.FindViewById<HorizontalScrollView>(Resource.Id.horizontalScrollView1);
                chkSelectAll.CheckedChange += ChkSelectAll_CheckedChange;
                await BindHistoryResult();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Clear search filter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void BtnclearSearch_Click(object sender, EventArgs e)
        {
            try
            {
                if (CommanUtil.IsTimeOut())
                {
                    strOrderID = "";
                    await BindHistoryResult1(1, APIMethods.getOrders);
                }
                else
                {
                    //Toekn Exired
                    Utility.ExpireSession(context);
                }
            }
            catch (Exception ex)
            {
                Toast.MakeText(context, ex.Message, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Search Order by ID
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void BtnSearchByOrderID_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Utility.FnIsOnline(context))
                {
                    Toast.MakeText(context, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                else
                {
                    if (txtOrderID.Text.Trim() != "")
                    {
                        if (CommanUtil.IsTimeOut())
                        {
                            strOrderID = txtOrderID.Text;
                            string strSearchOrderByID = string.Format(APIMethods.getIDWiseOrders, txtOrderID.Text.Trim());
                            txtOrderID.Text = "";
                            await BindHistoryResult1(1, strSearchOrderByID);
                        }
                        else
                        {
                            //Toekn Exired
                            Utility.ExpireSession(context);
                        }
                    }
                    else
                    {
                        Toast.MakeText(context, Constants.strEnterOrderID, ToastLength.Long).Show();
                    }
                }
            }
            catch
            {
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Deny selected orders
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnDenyorder_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Utility.FnIsOnline(context))
                {
                    Toast.MakeText(context, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                else
                {
                    if (lstOrderHistoryResult != null && lstOrderHistoryResult.Count > 0)
                    {
                        lstSelectedOrder = lstOrderHistoryResult.Where(m => m.isCheckBoxChecked == true).Select(m => m.OrderID).ToList();
                        if (lstSelectedOrder != null && lstSelectedOrder.Count > 0)
                        {
                            Utility objUtility = new Utility();
                            string dialogHeader = Constants.strConfirm;
                            Dialog dialog = objUtility.GetDialog(context, dialogHeader, string.Format(Constants.strWantToDenyOrder, lstSelectedOrder.Count),
                                Constants.btnTextYes, Constants.btnTextNo, string.Empty,
                                ViewStates.Gone, ViewStates.Visible, ViewStates.Visible,
                                ViewStates.Visible, ViewStates.Visible, ViewStates.Gone);

                            Button btnConfirm = dialog.FindViewById<Button>(Resource.Id.btnYes);
                            Button btnCancel = dialog.FindViewById<Button>(Resource.Id.btnNo);
                            btnConfirm.Click += async delegate
                            {
                                if (CommanUtil.IsTimeOut())
                                {
                                    foreach (var orderId in lstSelectedOrder)
                                    {
                                        postAcceptedOrder = string.Format(APIMethods.denyOrders, orderId);

                                        await postOrders(postAcceptedOrder);
                                    }
                                    dialog.Hide();
                                    //await BindHistoryResult(varFilterQuery);
                                    if (chkSelectAll.Checked == true)
                                    {
                                        chkSelectAll.Checked = false;
                                    }
                                    if (strOrderID.Trim() == "")
                                    {
                                        await BindHistoryResult1(pageCount, APIMethods.getOrders);
                                    }
                                    else
                                    {
                                        await BindHistoryResult1(pageCount, string.Format(APIMethods.getIDWiseOrders, strOrderID.Trim()));
                                    }
                                }
                                else
                                {
                                    //Toekn Exired
                                    Utility.ExpireSession(context);
                                }

                            };
                        }
                        else
                        {
                            Toast.MakeText(context, Constants.strSelectOrder, ToastLength.Long).Show();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Toast.MakeText(context, ex.Message, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Accept selected orders
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnAcceptOrder_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Utility.FnIsOnline(context))
                {
                    Toast.MakeText(context, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                if (lstOrderHistoryResult != null && lstOrderHistoryResult.Count > 0)
                {
                    lstSelectedOrder = lstOrderHistoryResult.Where(m => m.isCheckBoxChecked == true).Select(m => m.OrderID).ToList();
                    if (lstSelectedOrder != null && lstSelectedOrder.Count > 0)
                    {

                        //Toast.MakeText(context, "Are you sure to accept " + count + " Orders", ToastLength.Long).Show();
                        Utility objUtility = new Utility();
                        string dialogHeader = Constants.strConfirm;
                        //string confirmationMsg = Constants.strYouAre + "1 miles" + Constants.strAwayFromPickup;
                        Dialog dialog = objUtility.GetDialog(context, dialogHeader, string.Format(Constants.strWantToAcceptOrder, lstSelectedOrder.Count),
                            Constants.btnTextYes, Constants.btnTextNo, string.Empty,
                            ViewStates.Gone, ViewStates.Visible, ViewStates.Visible,
                            ViewStates.Visible, ViewStates.Visible, ViewStates.Gone);
                        Button btnConfirm = dialog.FindViewById<Button>(Resource.Id.btnYes);
                        Button btnCancel = dialog.FindViewById<Button>(Resource.Id.btnNo);
                        btnConfirm.Click += async delegate
                        {
                            if (CommanUtil.IsTimeOut())
                            {
                                foreach (var orderId in lstSelectedOrder)
                                {
                                    postAcceptedOrder = string.Format(APIMethods.approveOrders, orderId);

                                    await postOrders(postAcceptedOrder);
                                }
                                dialog.Hide();
                                //await BindHistoryResult(varFilterQuery);
                                if (chkSelectAll.Checked == true)
                                {
                                    chkSelectAll.Checked = false;
                                }
                                if (strOrderID.Trim() == "")
                                {
                                    await BindHistoryResult1(pageCount, APIMethods.getOrders);
                                }
                                else
                                {
                                    await BindHistoryResult1(pageCount, string.Format(APIMethods.getIDWiseOrders, strOrderID.Trim()));
                                }
                            }
                            else
                            {
                                //Toekn Exired
                                Utility.ExpireSession(context);
                            }
                        };
                    }
                    else
                    {
                        Toast.MakeText(context, Constants.strSelectOrder, ToastLength.Long).Show();
                    }
                }
            }
            catch (Exception ex)
            {
                Toast.MakeText(context, ex.Message, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// post Orders
        /// </summary>
        /// <param name="requestedData"></param>
        /// <returns></returns>
        private async Task<bool> postOrders(string requestedData)
        {
            try
            {
                string strResponse = await objServicehelper.PostRequestJson("", requestedData, CommanUtil.tokenNo, true);
                if (!string.IsNullOrEmpty(strResponse))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// On change event of select all checkbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChkSelectAll_CheckedChange(object sender, CompoundButton.CheckedChangeEventArgs e)
        {
            try
            {
                bool isCheckBoxChecked = false;
                if (chkSelectAll.Checked == true)
                {
                    isCheckBoxChecked = true;
                }
                else
                {
                    isCheckBoxChecked = false;
                }
                if (lstOrderHistoryResult != null && lstOrderHistoryResult.Count > 0)
                {
                    lststring(lstOrderHistoryResult, pageCount - 1, 20).ForEach(m => m.isCheckBoxChecked = isCheckBoxChecked);
                    //lstOrderHistoryResult.IndexOf();

                    OrderHistoryAdapter objHistoryResultAdapter = new OrderHistoryAdapter(context, lststring(lstOrderHistoryResult, pageCount - 1, 20));
                    lstViewOrderHistoryResult.Adapter = objHistoryResultAdapter;
                }
            }
            catch (Exception ex)
            {
                Toast.MakeText(context, ex.Message, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Bind order history data
        /// </summary>
        /// <returns></returns>
        private async Task BindHistoryResult()
        {
            try
            {
                int totalResult = await BindHistoryResult1(1, APIMethods.getOrders);
                int pagingCount = totalResult / 50;
                if (totalResult % 50 > 0)
                {
                    pagingCount = pagingCount + 1;
                }
                for (int indexCount = 1; indexCount <= pagingCount; indexCount++)
                {
                    pagingLayoutView = context.LayoutInflater.Inflate(Resource.Layout.PagingLayout, null);
                    pagingNumber = pagingLayoutView.FindViewById<TextView>(Resource.Id.txtPagingNum);
                    pagingNumber.Text = Convert.ToString(indexCount);
                    pagingNumber.Tag = indexCount;
                    pagingNumber.PaintFlags = PaintFlags.UnderlineText;
                    pagingTextViewArr.Add(pagingNumber);
                    lnrLayoutPaging.AddView(pagingLayoutView);
                    if (pagingTextViewArr.Count != 0)
                    {
                        pagingTextViewArr[0].SetTextColor(Android.Graphics.Color.Red);
                    }
                }
                foreach (TextView Tv in pagingTextViewArr)
                {
                    int pageNum = Convert.ToInt32(Tv.Text);
                    Tv.Click += async delegate
                    {
                        if (!Utility.FnIsOnline(context))
                        {
                            Toast.MakeText(context, Constants.strNoInternet, ToastLength.Short).Show();
                            return;
                        }
                        await BindHistoryResult1(pageNum, APIMethods.getOrders);
                    };
                }
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
            }
        }

        /// <summary>
        /// Bind order history data
        /// </summary>
        /// <param name="pageNum"></param>
        /// <param name="method"></param>
        /// <returns></returns>
        public async Task<int> BindHistoryResult1(int pageNum, string method)
        {
            try
            {
                pageCount = pageNum;
                lnrLayoutPaging.Visibility = ViewStates.Invisible;
                lnrOrderHistoryData.Visibility = ViewStates.Invisible;
                btnAcceptOrder.Visibility = ViewStates.Invisible;
                btnDenyorder.Visibility = ViewStates.Invisible;
                txtNoHistoryData.Visibility = ViewStates.Invisible;
                lnrHeaderLayout.Visibility = ViewStates.Gone;
                viewLine.Visibility = ViewStates.Invisible;
                viewLine1.Visibility = ViewStates.Invisible;
                //int totalResult = 0;
                int resultCount = 0;
                Alerts.showBusyLoader(context);
                //Get the Orders
                string strResponse = await objServicehelper.GetRequest(strToken, method, true);
                Alerts.HideBusyLoader();
                if (!string.IsNullOrEmpty(strResponse))
                {
                    lstOrderHistoryResult = (List<OrderHistory>)JsonConvert.DeserializeObject(strResponse, typeof(List<OrderHistory>));
                    resultCount = lstOrderHistoryResult.Count;
                    OrderHistoryAdapter objHistoryResultAdapter = new OrderHistoryAdapter(context, lststring(lstOrderHistoryResult, pageNum - 1, 50));
                    lstViewOrderHistoryResult.Adapter = objHistoryResultAdapter;
                    if (resultCount != 0)
                    {
                        if (resultCount < 51)
                        {
                            viewLine.Visibility = ViewStates.Visible;
                            viewLine1.Visibility = ViewStates.Visible;
                            lnrLayoutPaging.Visibility = ViewStates.Visible;
                        }
                        else
                        {
                            viewLine.Visibility = ViewStates.Visible;
                            viewLine1.Visibility = ViewStates.Visible;
                            lnrLayoutPaging.Visibility = ViewStates.Visible;
                            if (pagingTextViewArr.Count != 0)
                            {
                                foreach (TextView Tv in pagingTextViewArr)
                                {
                                    Tv.SetTextColor(Android.Graphics.Color.White);
                                }
                                //setting selected paging number to red
                                if (pageNum == 1)
                                {
                                    pagingTextViewArr[0].SetTextColor(Android.Graphics.Color.Red);
                                }
                                else
                                {
                                    pagingTextViewArr[pageNum - 1].SetTextColor(Android.Graphics.Color.Red);
                                }
                            }
                        }
                        txtNoHistoryData.Visibility = ViewStates.Visible;
                        lnrOrderHistoryData.Visibility = ViewStates.Visible;
                        btnAcceptOrder.Visibility = ViewStates.Visible;
                        lnrHeaderLayout.Visibility = ViewStates.Visible;
                        btnDenyorder.Visibility = ViewStates.Visible;
                        txtNoHistoryData.Text = Convert.ToString(resultCount) + " " + Constants.strHistoryResult;
                    }
                    else
                    {
                        viewLine.Visibility = ViewStates.Gone;
                        viewLine1.Visibility = ViewStates.Gone;
                        lnrLayoutPaging.Visibility = ViewStates.Gone;
                        lnrOrderHistoryData.Visibility = ViewStates.Gone;
                        lnrHeaderLayout.Visibility = ViewStates.Gone;
                        btnAcceptOrder.Visibility = ViewStates.Gone;
                        btnDenyorder.Visibility = ViewStates.Gone;
                        txtNoHistoryData.Visibility = ViewStates.Visible;
                        txtNoHistoryData.Text = "0 " + Constants.strHistoryResult;
                    }
                }
                else
                {
                    Toast.MakeText(context, Constants.strUnableToConnect, ToastLength.Long).Show();
                }
                return resultCount;
            }
            catch
            {
                Alerts.HideBusyLoader();
                return 0;
            }
        }

        /// <summary>
        /// Method to get list according to pagination
        /// </summary>
        /// <param name="lstOrderHistoryResult"></param>
        /// <param name="page"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        static List<OrderHistory> lststring(List<OrderHistory> lstOrderHistoryResult, int page, int pageSize)
        {
            return lstOrderHistoryResult.Skip(page * pageSize).Take(pageSize).ToList();
        }
    }
}