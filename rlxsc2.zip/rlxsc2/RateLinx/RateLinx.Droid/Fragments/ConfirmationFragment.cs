using System;
using System.Collections.Generic;
using System.Linq;
using Android.App;
using Android.OS;
using Android.Views;
using Android.Widget;
using V4App = Android.Support.V4.App;
using Android.Graphics;
using System.IO;
using RateLinx.Droid.Utilities;
using Newtonsoft.Json.Linq;
using RateLinx.Helper;
using RateLinx.Models;
using Android.Locations;
using Newtonsoft.Json;
using RateLinx.APIs;
using RateLinx.Droid.GoogleMapServices;
using System.Threading.Tasks;
using Xamarin.Controls;
using RateLinx.Droid.Activities;
using Android.Content;
using Android.Provider;
using Android.Support.V4.Content;
using Android;
using Android.Content.PM;
using URI = Android.Net;
using Android.Runtime;
using RateLinx.Droid.FileHelper;
using JavaFile = Java.IO.File;
using Android.Support.V4.App;

namespace RateLinx.Droid.Fragments
{
    /// <summary>
    /// Confirmation Fragment Meta Class
    /// </summary>
    public class ConfirmationFragment : V4App.Fragment
    {
        #region Declaration of controls instances and variables 
        //JavaFile file = null;
        byte[] bytes = null;
        CarrierShipmentDetails carrierShipmentDetails;
        List<CountryDetails> lstCountryDetails = null;
        List<StateDetails> lstStateDetails = null;
        View viewPickupConfirmation;
        EditText txtActivityDate, txtActivityTime, txtProNumber, txtCity;
        Activity context;
        Intent imageIntent = null;
        CheckBox chkTrackDetails;
        LinearLayout lnrTrackDetails, lnrCheckBoxLayout, linearLayout1, linearLayout3, lnrRadio;
        SignaturePadView objSignaturePadView;
        Button btnSubmitDetails, btnResetSign;
        Spinner spinnerState, spinnerCountry, spinnerDescription;
        List<string> lstStates = null;
        List<string> lstStateCodes = null;
        List<string> lstCountries = null;
        List<string> lstCountryCodes = null;
        List<TrackingDesc> lstTrackingDesc = null;
        int descriptionIndex = 0;
        double currentLat = 0.00;
        double currentLong = 0.00;
        JObject jobject = null;
        CommanUtil commanUtil;
        TimePickerDialog timePick = null;
        string[] activityDate = null;
        string ConfirmationType, navigateFrom;
        string newActivityDate, ActivityDate, activityTime, ConfType
           , shipmentID, strBase64String, payload_str, countryName,
            postDataJson, payloadReturn, AMPM, parameters
            = string.Empty;
        DateTime today = DateTime.Now;
        TextView textFileName;
        DatePickerDialog dialog = null;
        ArrayAdapter adapter = null;
        Bitmap objBitmap = null;
        string shipmentDetails = string.Empty;
        string country = string.Empty;
        string state, response = string.Empty;
        TextView TvHeaderTitle;
        GPSServiceSettings objGPSServiceSettings = null;
        ImageView imgBack, imgViewCamera;
        string[] confirmationType;
        string shipmentType = string.Empty;
        RadioButton rdbtn_Signature, rdbtn_Picture;
        TextView txtHeaderLabel;
        Utility objUtility;
        int uploadIdentifier = 0;
        readonly string[] cameraPermission =
                        {
         Manifest.Permission.WriteExternalStorage,
         Manifest.Permission.Camera};
        URI.Uri selectedURI = null;
        Bitmap bitmapImage = null;
        string requiredMessage = string.Empty;
        string stopCountForConfirmtion = string.Empty;
        #endregion

        /// <summary>
        /// Assign Data
        /// </summary>
        /// <param name="context"></param>
        /// <param name="PickupConf"></param>
        /// <param name="shipType"></param>
        public ConfirmationFragment(Activity context, string[] PickupConf, string shipType)
        {
            try
            {
                commanUtil = new CommanUtil();
                this.context = context;
                requiredMessage = Constants.signatureRequired;
                ConfirmationType = PickupConf[0];
                confirmationType = PickupConf;
                if (PickupConf[0].ToUpper() == Constants.strPickConf.ToUpper())
                {
                    ConfType = Constants.strpickup;

                }
                else
                {
                    ConfType = Constants.strdelivery;

                }
                shipmentType = shipType;
                shipmentID = PickupConf[1];
                navigateFrom = PickupConf[2];
                objGPSServiceSettings = new GPSServiceSettings();
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public static V4App.FragmentManager fragmentActivity;

        /// <summary>
        /// creating view through fragment for confirmation fragment
        /// </summary>
        /// <param name="inflater"></param>
        /// <param name="container"></param>
        /// <param name="savedInstanceState"></param>
        /// <returns></returns>
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                if (viewPickupConfirmation == null)
                {
                    // Use this to return your custom view for this Fragment
                    viewPickupConfirmation = inflater.Inflate(Resource.Layout.Confirmation, container, false);
                    if (!Utility.FnIsOnline(context))
                    {
                        Toast.MakeText(context, Constants.strNoInternet, ToastLength.Short).Show();
                    }
                    //Replace header text on home activity
                    TvHeaderTitle = context.FindViewById<TextView>(Resource.Id.toolbar_title);
                    imgBack = context.FindViewById<ImageView>(Resource.Id.imgBack);
                    imgBack.Visibility = ViewStates.Visible;
                    imgBack.Click -= ImgBack_Click;
                    imgBack.Click += ImgBack_Click;
                    TvHeaderTitle.Text = ConfirmationType;
                    GetControlById();
                    GetShipmentDetails();
                    if (ConfType == Constants.strpickup)
                    {
                        lnrRadio.Visibility = ViewStates.Gone;
                    }
                    else
                    {
                        lnrRadio.Visibility = ViewStates.Visible;
                    }
                }
                return viewPickupConfirmation;
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                return viewPickupConfirmation;
            }
        }

        /// <summary>
        /// Back image button click event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgBack_Click(object sender, EventArgs e)
        {
            try
            {
                if (CommanUtil.IsTimeOut())
                {
                    if (Activity != null)
                    {
                        if (Activity.SupportFragmentManager != null)
                        {
                            fragmentActivity = Activity.SupportFragmentManager;
                            Activity.SupportFragmentManager.PopBackStack();
                        }
                    }
                    else
                    {
                        if (fragmentActivity != null)
                        {
                            fragmentActivity.PopBackStack();
                        }
                    }
                }
                else
                {
                    Utility.ExpireSession(context);
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public override void OnDestroy()
        {
            base.OnDestroy();
            stopCountForConfirmtion = string.Empty;
        }

        /// <summary>
        /// Handle Header text
        /// </summary>
        public override void OnResume()
        {
            try
            {
                base.OnResume();
                if (TvHeaderTitle != null)
                {
                    TvHeaderTitle.Text = ConfirmationType;
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Get Controls By Element Id and controls Event
        /// </summary>
        public async void GetControlById()
        {
            try
            {
                lnrRadio = viewPickupConfirmation.FindViewById<LinearLayout>(Resource.Id.lnrRadio);
                txtHeaderLabel = viewPickupConfirmation.FindViewById<TextView>(Resource.Id.textView1);
                linearLayout1 = viewPickupConfirmation.FindViewById<LinearLayout>(Resource.Id.linearLayout1);
                linearLayout3 = viewPickupConfirmation.FindViewById<LinearLayout>(Resource.Id.linearLayout3);
                imgViewCamera = viewPickupConfirmation.FindViewById<ImageView>(Resource.Id.imgViewCamera);
                rdbtn_Picture = viewPickupConfirmation.FindViewById<RadioButton>(Resource.Id.rdbtn_Picture);
                rdbtn_Signature = viewPickupConfirmation.FindViewById<RadioButton>(Resource.Id.rdbtn_Signature);
                chkTrackDetails = viewPickupConfirmation.FindViewById<CheckBox>(Resource.Id.chkTrackDetails);
                lnrTrackDetails = viewPickupConfirmation.FindViewById<LinearLayout>(Resource.Id.lnrTrackDetails);
                lnrCheckBoxLayout = viewPickupConfirmation.FindViewById<LinearLayout>(Resource.Id.lnrCheckBoxLayout);
                btnSubmitDetails = viewPickupConfirmation.FindViewById<Button>(Resource.Id.btnSubmitDetails);
                btnResetSign = viewPickupConfirmation.FindViewById<Button>(Resource.Id.btnResetSign);
                objSignaturePadView = viewPickupConfirmation.FindViewById<SignaturePadView>(Resource.Id.signaturePadView1);
                objSignaturePadView.SignaturePromptText = "";
                spinnerState = viewPickupConfirmation.FindViewById<Spinner>(Resource.Id.spinnerState);
                spinnerCountry = viewPickupConfirmation.FindViewById<Spinner>(Resource.Id.spinnerCountry);
                spinnerDescription = viewPickupConfirmation.FindViewById<Spinner>(Resource.Id.spinnerDescription);
                spinnerDescription.Enabled = false;
                spinnerDescription.Clickable = false;
                txtActivityDate = viewPickupConfirmation.FindViewById<EditText>(Resource.Id.txtActivityDate);
                txtActivityTime = viewPickupConfirmation.FindViewById<EditText>(Resource.Id.txtActivityTime);
                txtProNumber = viewPickupConfirmation.FindViewById<EditText>(Resource.Id.txtProNumber);
                txtCity = viewPickupConfirmation.FindViewById<EditText>(Resource.Id.txtCity);
                txtProNumber.Text = confirmationType[3];
                txtActivityTime.Click += (sender, e) =>
                {
                    context.Window.SetSoftInputMode(SoftInput.StateAlwaysHidden);
                    timePick = new TimePickerDialog(context, ActivityTimePicker, DateTime.Now.Hour, DateTime.Now.Hour, true);
                    timePick.Show();
                };
                txtActivityDate.Click += (sender, e) =>
                {
                    context.Window.SetSoftInputMode(SoftInput.StateAlwaysHidden);
                    today = DateTime.Today;
                    dialog = new DatePickerDialog(context, ActivityDatePicker, today.Year, today.Month - 1, today.Day);
                    dialog.DatePicker.MinDate = today.Millisecond;
                    dialog.Show();
                };
                btnResetSign.Click += delegate
                {
                    objSignaturePadView.Clear();
                    imgViewCamera.SetImageResource(Resource.Drawable.img_camera);
                    bitmapImage = null;
                };
                btnSubmitDetails.Click += delegate
                {
                    if (CommanUtil.IsTimeOut())
                    {
                        if (shipmentType == Constants.dispatcher)
                        {
                            SubmitSignOnly();
                        }
                        else
                        {
                            if (chkTrackDetails.Checked == false)
                            {
                                SubmitSignOnly();
                            }
                            else
                            {
                                SubmitSignWithDetails();
                            }
                        }
                    }
                    else
                    {
                        Utility.ExpireSession(context);
                    }
                };
                rdbtn_Signature.Click += rdbtn_Signature_Click;
                if (rdbtn_Signature.Checked == true)
                {
                    txtHeaderLabel.Text = "Sign Here:";

                }
                imgViewCamera.Click += imgViewCamera_Click;
                rdbtn_Picture.Click += rdbtn_Picture_Click;
                lnrTrackDetails.Visibility = ViewStates.Gone;
                chkTrackDetails.CheckedChange += ChkTrackDetails_CheckedChange;
                //Hide Details part id shipment is dispatcher
                if (shipmentType == Constants.dispatcher)
                {
                    lnrCheckBoxLayout.Visibility = ViewStates.Gone;
                }
                else
                {
                    lnrCheckBoxLayout.Visibility = ViewStates.Visible;
                }
                lstTrackingDesc = CommanUtil.TrackingDescList();
                spinnerDescription.SetBackgroundColor(Color.Gray);
                await InitializeLocationManager();
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }
        /// <summary>
        /// Get Shipment Details
        /// </summary>
        /// <returns></returns>
        public async Task GetShipmentDetails()
        {
            try
            {
                objUtility = new Utility();
                string[] shipDetail = shipmentID.Split('|');
                string response = await objUtility.BindShipmentDetail(APIMethods.shipmentDetails + "/" + shipDetail[0] + "|" + shipDetail[2], context);
                if (!string.IsNullOrEmpty(response))
                {
                    Alerts.HideBusyLoader();
                    carrierShipmentDetails = JsonConvert.DeserializeObject<CarrierShipmentDetails>(response);
                    if (carrierShipmentDetails != null && carrierShipmentDetails.TrackDetails.Count > 0)
                    {
                        if (carrierShipmentDetails.IsMultiStop)
                        {
                            stopCountForConfirmtion = commanUtil.multiStopTracking(carrierShipmentDetails);
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void rdbtn_Picture_Click(object sender, EventArgs e)
        {
            try
            {
                objSignaturePadView.Clear();
                requiredMessage = "Please upload image";
                txtHeaderLabel.Text = "Upload Picture:";
                imgViewCamera.Visibility = ViewStates.Visible;
                objSignaturePadView.Visibility = ViewStates.Gone;
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void imgViewCamera_Click(object sender, EventArgs e)
        {
            try
            {
                if ((ContextCompat.CheckSelfPermission(context, Manifest.Permission.Camera) == (int)Permission.Granted) &&
                       (ContextCompat.CheckSelfPermission(context, Manifest.Permission.WriteExternalStorage) == (int)Permission.Granted))
                {
                    ConfirmationAlert("What you want to do?");
                }
                else
                {
                    //ActivityCompat.RequestPermissions(context, cameraPermission, 0);

                    AlertDialog.Builder alert = new AlertDialog.Builder(context);
                    alert.SetTitle("Warning");
                    alert.SetMessage("Allow Ratelinx to use your camera");
                    alert.SetPositiveButton("Go to Setting", (senderAlert, args) =>
                    {
                        StartActivity(new Intent(Android.Provider.Settings.ActionApplicationDetailsSettings, Android.Net.Uri.Parse("package:" + Android.App.Application.Context.PackageName)));
                    });
                    alert.SetNegativeButton("Cancel", (senderAlert, args) =>
                    {
                    });
                    Dialog dialog = alert.Create();
                    dialog.Show();
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="confirmationMsg"></param>
        public void ConfirmationAlert(string confirmationMsg)
        {
            try
            {
                objUtility = new Utility();
                string dialogHeader = Constants.strUploadImage;
                Dialog dialogUpload = objUtility.GetUploadDialog(context, dialogHeader, "Upload Picture",
               Constants.btnTextTakePicture, Constants.btnTextCancel, ViewStates.Visible,
              ViewStates.Gone, ViewStates.Visible,
               ViewStates.Visible, ViewStates.Gone);

                Button btnTakePicture = dialogUpload.FindViewById<Button>(Resource.Id.btnTakePicture);
                Button btnUploadImage = dialogUpload.FindViewById<Button>(Resource.Id.btnUpload);

                TextView txtViewClose = dialogUpload.FindViewById<TextView>(Resource.Id.txtViewClose);
                btnTakePicture.Click += delegate
                {
                    dialogUpload.Hide();
                    TakePhotoByCamera();
                };
                btnUploadImage.Click += delegate
                {
                    dialogUpload.Hide();
                    ConfirmationUploadDialog();

                };
                txtViewClose.Click += delegate
                {

                    dialogUpload.Hide();
                    return;
                };

                objUtility = null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void TakePhotoByCamera()
        {
            uploadIdentifier = 1;
            try
            {
                string timeStamp = "1221221";
                StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
                StrictMode.SetVmPolicy(builder.Build());
                Java.IO.File dir = new Java.IO.File(Android.OS.Environment
                  .GetExternalStoragePublicDirectory(Android.OS.Environment.DirectoryPictures), "photo_" + timeStamp + ".png");
                selectedURI = Android.Net.Uri.FromFile(dir);
                Intent i = new Intent(MediaStore.ActionImageCapture);
                i.PutExtra(MediaStore.ExtraOutput, selectedURI);
                StartActivityForResult(i, 1);
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Short).Show();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="requestCode"></param>
        /// <param name="resultCode"></param>
        /// <param name="data"></param>
        public override void OnActivityResult(int requestCode, int resultCode, Intent data)
        {
            base.OnActivityResult(requestCode, resultCode, data);
            try
            {
                base.OnActivityResult(requestCode, resultCode, data);
                if (resultCode == 0)
                    return;
                if (resultCode == -1)
                {

                    if (uploadIdentifier == Constants.int1)
                    {
                        ContextWrapper wrapper = new ContextWrapper(context);
                        bitmapImage = MediaStore.Images.Media.GetBitmap(wrapper.ContentResolver, selectedURI);
                    }
                    else
                    {
                        selectedURI = data.Data;
                        string filePath = FileUploadHelper.GetFilePath(selectedURI, context);
                        textFileName.Text = FileUploadHelper.GetFileName(filePath);
                        // Conversion of selected file into bytes
                        bytes = FileUploadHelper.ConvertFileIntoByte(filePath);
                        bitmapImage = BitmapFactory.DecodeByteArray(bytes, 0, bytes.Length);
                    }

                    string imgaeURL = string.Empty;
                    imgaeURL = FileUploadHelper.GetFilePath(selectedURI, context);


                    BitmapFactory.Options bounds = new BitmapFactory.Options();
                    bounds.InJustDecodeBounds = true;
                    BitmapFactory.DecodeFile(imgaeURL, bounds);

                    BitmapFactory.Options opts = new BitmapFactory.Options();
                    Bitmap bm = BitmapFactory.DecodeFile(imgaeURL, opts);
                    Android.Media.ExifInterface exif = new Android.Media.ExifInterface(imgaeURL);
                    // get the initial orientation of image
                    string orientString = exif.GetAttribute(Android.Media.ExifInterface.TagOrientation);
                    int orientation = orientString != null ? Convert.ToInt32(orientString) : Constants.int0;
                    int rotationAngle = Constants.int0;
                    if (orientation == Constants.int6) rotationAngle = Constants.int90;
                    if (orientation == Constants.int3) rotationAngle = Constants.int180;
                    if (orientation == Constants.int20) rotationAngle = Constants.int270;
                    if (orientation != Constants.int0)
                    {
                        int maxHeight = 1200;
                        int maxWidth = 1200;
                        // Setting pre rotate
                        Matrix matrix = new Matrix();
                        matrix.SetRotate(rotationAngle, (float)bm.Width / 2, (float)bm.Height / 2);
                        float scale = Math.Min(((float)maxHeight / bm.Width), ((float)maxWidth / bm.Height));

                        matrix.PostScale(scale, scale);
                        bitmapImage = Bitmap.CreateBitmap(bm, Constants.int0, Constants.int0, bounds.OutWidth, bounds.OutHeight, matrix, true);
                        bitmapImage = bitmapImage.Copy(Bitmap.Config.Argb8888, true);

                    }
                    if (bounds.OutWidth > 4500)
                    {
                        imgViewCamera.SetImageResource(Resource.Drawable.img_camera);
                        Toast.MakeText(context, Constants.strLargeFile, ToastLength.Short).Show();
                    }
                    else
                    {
                        imgViewCamera.SetImageBitmap(bitmapImage);
                    }

                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }

        }

        /// <summary>
        /// ConfirmationUploadDialog
        /// </summary>
        protected void ConfirmationUploadDialog()
        {
            try
            {
                uploadIdentifier = 2;
                objUtility = new Utility();
                string dialogHeader = Constants.strUploadImage;
                Dialog dialogUpload = objUtility.GetUploadDialog(context, dialogHeader, "Upload Picture",
                    Constants.btnTextTakePicture, Constants.btnTextCancel, ViewStates.Gone,
                   ViewStates.Gone, ViewStates.Visible,
                    ViewStates.Visible, ViewStates.Visible);
                Button fileUpload = dialogUpload.FindViewById<Button>(Resource.Id.fileUpload);
                Button btnUploadFile = dialogUpload.FindViewById<Button>(Resource.Id.btnUploadFile);
                TextView txtViewClose = dialogUpload.FindViewById<TextView>(Resource.Id.txtViewClose);
                textFileName = dialogUpload.FindViewById<TextView>(Resource.Id.textFileName);
                fileUpload.Click += delegate
                {
                    dialogUpload.Hide();
                    FileUpload_Click();
                };
                txtViewClose.Click += delegate
                {
                    dialogUpload.Hide();
                    return;
                };

                objUtility = null;
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        private void FileUpload_Click()
        {
            try
            {
                imageIntent = new Intent(Intent.ActionPick, Android.Provider.MediaStore.Images.Media.ExternalContentUri);
                imageIntent.SetType("*/*");
                imageIntent.PutExtra("return-data", true);
                imageIntent.SetAction(Intent.ActionGetContent);
                StartActivityForResult(
                    Intent.CreateChooser(imageIntent, Constants.strSelectFile), 0);
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void rdbtn_Signature_Click(object sender, EventArgs e)
        {
            try
            {
                bitmapImage = null;
                txtHeaderLabel.Text = "Sign Here:";
                requiredMessage = Constants.signatureRequired;
                imgViewCamera.Visibility = ViewStates.Gone;
                objSignaturePadView.Visibility = ViewStates.Visible;
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Preparing payload for hitting API
        /// </summary>
        public string GetTrackingPayload()
        {
            try
            {
                activityDate = new string[2];
                if (txtActivityDate.Text != "")
                {
                    ActivityDate = Convert.ToDateTime(txtActivityDate.Text).ToString("MM/dd/yyyy");
                    activityDate = CommanUtil.FormatDate(ActivityDate);
                    newActivityDate = activityDate[2] + "-" + activityDate[0] + "-" + activityDate[1];
                }
                if ((txtActivityTime.Text.Contains("AM")))
                {
                    activityTime = txtActivityTime.Text.Replace("AM", "").Trim();
                }
                else
                {
                    activityTime = txtActivityTime.Text.Replace("PM", "").Trim();
                }
                string Cstatus = string.Empty;
                if (ConfType != Constants.strPickConf)
                {
                    Cstatus = "Delivered_";
                }
                else
                {
                    Cstatus = "Not Delivered";
                    stopCountForConfirmtion = string.Empty;
                }
                payload_str = "{"
                                + "\"ProNumber\":" + "\"" + txtProNumber.Text + "\","
                                + "\"ActivityDate\":" + "\"" + newActivityDate + " " + activityTime + "\","
                                + "\"ActivityCode\":" + "\"" + lstTrackingDesc[descriptionIndex].value + "\","
                                + "\"ActivityDescr\":" + "\"" + Convert.ToString(spinnerDescription.SelectedItem) + "\","
                                + "\"City\":" + "\"" + txtCity.Text + "\","
                                + "\"State\":" + "\"" + lstStateCodes[spinnerState.SelectedItemPosition] + "\","
                                + "\"Country\":" + "\"" + lstCountryCodes[spinnerCountry.SelectedItemPosition] + "\""
                                  + "," + "\"Stop\":" + "\"" + stopCountForConfirmtion + "\","
                                 + "\"CurrentStatus\":" + "\"" + Cstatus + stopCountForConfirmtion + "\""
                                +
                                "}";

                return payload_str;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Activity Time Picker
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ActivityTimePicker(object sender, TimePickerDialog.TimeSetEventArgs e)
        {
            AMPM = Utility.CheckAMPM(e);
            txtActivityTime.Text = e.HourOfDay.ToString() + ":" + e.Minute.ToString() + " " + AMPM;
        }

        /// <summary>
        /// Activity Date Picker
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ActivityDatePicker(object sender, DatePickerDialog.DateSetEventArgs e)
        {
            txtActivityDate.Text = e.Date.ToShortDateString();
        }

        /// <summary>
        /// Getting Current Location
        /// </summary>
        private async Task InitializeLocationManager()
        {

            response = objGPSServiceSettings.StartLocationUpdates(null);
            if (!string.IsNullOrEmpty(response) && !response.Equals("passive")) // && response.Equals("network")
            {
                currentLat = CommanUtil.currLat;//37.089984; //
                currentLong = CommanUtil.currLong;//-95.715063;//
                if (currentLat != 0)
                {
                    await ConvertLatLongToAddress(currentLat, currentLong);
                }
                else
                {
                    Toast.MakeText(context, Constants.strLocation, ToastLength.Long).Show();
                }
            }
            else
            {
                txtCity.Text = string.Empty;
                state = string.Empty;
                country = string.Empty;
                Toast.MakeText(context, Constants.strEnableTracking, ToastLength.Long).Show();
            }


        }

        /// <summary>
        /// Submit Sign With Details
        /// </summary>
        private async void SubmitSignWithDetails()
        {
            try
            {
                objBitmap = null;
                if (!Utility.FnIsOnline(context))
                {
                    Toast.MakeText(context, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                if (objSignaturePadView.GetImage() == null && bitmapImage == null)
                {
                    if (ConfType == Constants.strpickup)
                    {
                        Toast.MakeText(context, requiredMessage, ToastLength.Short).Show();
                        return;
                    }
                    else
                    {
                        Toast.MakeText(context, requiredMessage, ToastLength.Short).Show();
                        return;
                    }
                }
                if (string.IsNullOrEmpty(txtProNumber.Text))
                {
                    Toast.MakeText(context, Constants.strEnterProNo, ToastLength.Short).Show();
                    return;
                }
                if (string.IsNullOrEmpty(txtCity.Text))
                {
                    Toast.MakeText(context, Constants.enterCity, ToastLength.Long).Show();
                    return;
                }
                else
                {
                    Alerts.showBusyLoader(context);
                    await Task.Delay(500);
                    ServiceHelper objServiceHelper = new ServiceHelper();
                    Utility objUtility = new Utility();
                    string Result = string.Empty;
                    string methodURI = APIMethods.shipmentDetails + "/" + shipmentID.Split('#')[0] + "/" + APIMethods.signature;
                    string token = CommanUtil.tokenNo;

                    if (objSignaturePadView.GetImage() != null)
                    {
                        objBitmap = objSignaturePadView.GetImage(Color.Black, Color.White, false);
                    }
                    else
                    {
                        objBitmap = bitmapImage;
                    }
                    using (var stream = new MemoryStream())
                    {
                        objBitmap.Compress(Bitmap.CompressFormat.Png, 50, stream);
                        var bytes = stream.ToArray();
                        strBase64String = Convert.ToBase64String(bytes);
                    }

                    if (!string.IsNullOrEmpty(GetTrackingPayload()))
                    {
                        payloadReturn = GetTrackingPayload();
                    }
                    else
                    {
                        payloadReturn = "{" + "}";
                    }
                    if (ConfType != Constants.strpickup && carrierShipmentDetails.Addresses.Count > 3)
                    {
                        //ConfType = Constants.stopCountForConfirmtion;
                        ConfType = "STOP";
                    }
                    postDataJson = "{"
                                        + "\"Signature64\":" + "\"" + strBase64String + "\","
                                        + "\"SignatureImageType\":" + "\"png\","
                                        + "\"SignatureType\":" + "\"" + ConfType + "\","
                                         + "\"Tracking\":" + payloadReturn
                                        + "}";
                    Result = await objServiceHelper.PostRequestJson(postDataJson, methodURI, token, true);
                    if (Result != null && Result.Replace("\"", " ").Trim() == "Success")
                    {
                        Alerts.HideBusyLoader();
                        Toast.MakeText(context, Constants.signatureSaved, ToastLength.Long).Show();
                        if (Activity != null)
                        {
                            if (Activity.SupportFragmentManager != null)
                            {
                                fragmentActivity = Activity.SupportFragmentManager;
                                Activity.SupportFragmentManager.PopBackStack();
                            }
                        }
                        else
                        {
                            if (fragmentActivity != null)
                            {
                                fragmentActivity.PopBackStack();
                            }
                        }
                    }
                    else
                    {
                        jobject = JObject.Parse(Result);
                        string message = Convert.ToString(jobject[Constants.strErrorMessage]);
                        Toast.MakeText(context, message, ToastLength.Long).Show();
                        Alerts.HideBusyLoader();
                        Utility.ErrorLog(APIMethods.signature, message, token, context);
                    }
                    objSignaturePadView.Clear();
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                Alerts.HideBusyLoader();
            }
            finally
            {
                Alerts.HideBusyLoader();
            }
        }

        /// <summary>
        /// Submit Sign With Details
        /// </summary>
        private async void SubmitSignOnly()
        {
            try
            {
                if (!Utility.FnIsOnline(context))
                {
                    Toast.MakeText(context, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                if (objSignaturePadView.GetImage() == null && bitmapImage == null)
                {
                    if (ConfType == Constants.strpickup)
                    {
                        Toast.MakeText(context, requiredMessage, ToastLength.Short).Show();
                        return;
                    }
                    else
                    {
                        Toast.MakeText(context, requiredMessage, ToastLength.Short).Show();
                        return;
                    }                  
                }
                else
                {
                    Alerts.showBusyLoader(context);
                    await Task.Delay(500);
                    ServiceHelper objServiceHelper = new ServiceHelper();
                    Utility objUtility = new Utility();
                    string Result = string.Empty;
                    string methodURI = APIMethods.shipmentDetails + "/" + shipmentID.Split('#')[0] + "/" + APIMethods.signature;
                    string token = CommanUtil.tokenNo;
                    if (objSignaturePadView.GetImage() != null)
                    {
                        objBitmap = objSignaturePadView.GetImage(Color.Black, Color.White, false);
                    }
                    else
                    {
                        objBitmap = bitmapImage;
                    }
                    using (var stream = new MemoryStream())
                    {
                        objBitmap.Compress(Bitmap.CompressFormat.Png, 50, stream);
                        var bytes = stream.ToArray();
                        strBase64String = Convert.ToBase64String(bytes);
                    }

                    if (ConfType != Constants.strpickup && carrierShipmentDetails.Addresses.Count > 3)
                    {
                        string payload_str = "{"
                                + "\"Stop\":" + "\"" + stopCountForConfirmtion + "\","
                                 + "\"CurrentStatus\":" + "\"" + stopCountForConfirmtion + "\""
                                +
                                "}";
                        //ConfType = Constants.stopCountForConfirmtion;
                        ConfType = "STOP";
                        postDataJson = "{"
                                       + "\"Signature64\":" + "\"" + strBase64String + "\","
                                       + "\"SignatureImageType\":" + "\"png\","
                                       + "\"SignatureType\":" + "\"" + ConfType + "\","
                                       + "\"Tracking\":" + payload_str
                                       + "}";
                    }
                    else
                    {
                        postDataJson = "{"
                                       + "\"Signature64\":" + "\"" + strBase64String + "\","
                                       + "\"SignatureImageType\":" + "\"png\","
                                       + "\"SignatureType\":" + "\"" + ConfType + "\""
                                       // + "\"Tracking\":" + payloadReturn
                                       + "}";
                    }
                    Result = await objServiceHelper.PostRequestJson(postDataJson, methodURI, token, true);
                    if (Result != null && Result.Replace("\"", " ").Trim() == "Success")
                    {
                        Toast.MakeText(context, Constants.signatureSaved, ToastLength.Long).Show();
                        if (Activity != null)
                        {
                            if (Activity.SupportFragmentManager != null)
                            {
                                fragmentActivity = Activity.SupportFragmentManager;
                                Activity.SupportFragmentManager.PopBackStack();
                            }
                        }
                        else
                        {
                            if (fragmentActivity != null)
                            {
                                fragmentActivity.PopBackStack();
                            }
                        }
                    }
                    else
                    {
                        jobject = JObject.Parse(Result);
                        string message = Convert.ToString(jobject[Constants.strErrorMessage]);
                        Toast.MakeText(context, message, ToastLength.Long).Show();
                        Utility.ErrorLog(APIMethods.signature, message, token, context);
                    }
                    objSignaturePadView.Clear();
                }
            }
            catch (Exception ex)
            {
                Alerts.HideBusyLoader();
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
            finally
            {
                Alerts.HideBusyLoader();
            }
        }

        /// <summary>
        /// Convert LatLong To Address
        /// </summary>
        /// <returns></returns>
        public async Task ConvertLatLongToAddress(double Lat, double Long)
        {
            try
            {
                if (!Utility.FnIsOnline(context))
                {
                    Alerts.HideBusyLoader();
                    Toast.MakeText(context, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                var geocoder = new Geocoder(context);
                IList<Android.Locations.Address> addressList = await geocoder.GetFromLocationAsync(Lat, Long, 10);
                if (addressList != null && addressList.Count > 0)
                {
                    Android.Locations.Address addressCurrent = addressList.FirstOrDefault();
                    if (addressCurrent != null)
                    {
                        txtCity.Text = addressCurrent.Locality;
                        state = addressCurrent.AdminArea;
                        country = addressCurrent.CountryName;
                    }
                }
                else
                {
                    txtCity.Text = string.Empty;
                    state = string.Empty;
                    country = string.Empty;
                    Toast.MakeText(context, Constants.strLocation, ToastLength.Long).Show();
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// CheckBox TrackDetails CheckedChange Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ChkTrackDetails_CheckedChange(object sender, CompoundButton.CheckedChangeEventArgs e)
        {
            try
            {
                if (CommanUtil.IsTimeOut())
                {
                    if (chkTrackDetails.Checked)
                    {
                        await Task.WhenAll(InitializeLocationManager(), LoadCountry());
                        txtActivityDate.Text = DateTime.Now.ToShortDateString();
                        txtActivityTime.Text = DateTime.Now.ToShortTimeString();
                        lnrTrackDetails.Visibility = ViewStates.Visible;
                        BindDescription();
                    }
                    else
                    {
                        lnrTrackDetails.Visibility = ViewStates.Gone;
                    }
                }
                else
                {
                    Utility.ExpireSession(context);
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Loading Country According to current Address
        /// </summary>
        public async Task LoadCountry()
        {
            lstCountryDetails = await Utility.GetCountryDetails(context);
            if (lstCountryDetails != null && lstCountryDetails.Count > 0)
            {
                lstCountries = new List<string>();
                lstCountryCodes = new List<string>();
                foreach (CountryDetails countryDetails in lstCountryDetails)
                {
                    lstCountries.Add(countryDetails.Name);
                    lstCountryCodes.Add(countryDetails.Code);
                }
                if (!string.IsNullOrEmpty(country))
                {
                    countryName = lstCountries.Where(x => x.Equals(country.ToUpper())).FirstOrDefault();
                }
                else
                {
                    countryName = lstCountries.Where(x => x.Equals(Constants.strDefaultState)).FirstOrDefault();
                }
                if (string.IsNullOrEmpty(countryName))
                {
                    countryName = Constants.strDefaultState;
                }
                ArrayAdapter adapter = new ArrayAdapter(context, Resource.Drawable.SpinnerCustomDesign, lstCountries);
                adapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
                spinnerCountry.Adapter = adapter;
                for (int indexCountry = 0; indexCountry < spinnerCountry.Count; indexCountry++)
                {
                    if (spinnerCountry.GetItemAtPosition(indexCountry).Equals(countryName.ToUpper()))
                    {
                        spinnerCountry.SetSelection(indexCountry);

                    }
                }
                spinnerCountry.ItemSelected += SpinnerCountry_ItemSelected;
            }
            else
            {
                Toast.MakeText(context, Constants.strUnableToConnect, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Spinner Country ItemSelected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SpinnerCountry_ItemSelected(object sender, AdapterView.ItemSelectedEventArgs e)
        {
            try
            {
                for (int indexCountry = 0; indexCountry < spinnerCountry.Count; indexCountry++)
                {
                    if (spinnerCountry.SelectedItem.Equals(Convert.ToString(lstCountryDetails[indexCountry].Name.ToUpper())))
                    {
                        lstStateDetails = lstCountryDetails[indexCountry].States;
                    }
                }
                //GetItemAtPosition  ///state
                lstStates = new List<string>();
                lstStateCodes = new List<string>();
                foreach (StateDetails stateDetails in lstStateDetails)
                {
                    lstStateCodes.Add(stateDetails.Code);
                    lstStates.Add(stateDetails.Name);
                }
                adapter = new ArrayAdapter(context, Resource.Drawable.SpinnerCustomDesign, lstStates);
                adapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
                spinnerState.Adapter = adapter;
                if (!string.IsNullOrEmpty(state))
                {
                    if (lstStateCodes != null && lstStateCodes.Count > 0)
                    {
                        for (int indexState = 0; indexState < spinnerState.Count; indexState++)
                        {
                            if (state.ToUpper().Equals(Convert.ToString(lstStateCodes[indexState].ToUpper())))
                            {
                                spinnerState.SetSelection(indexState);
                            }
                            else if (state.ToUpper().Equals(Convert.ToString(lstStates[indexState].ToUpper())))
                            {
                                spinnerState.SetSelection(indexState);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Funciton to bind data in the description spinner
        /// </summary>
        public void BindDescription()
        {
            adapter = Utility.DescriptionAdapter(context);
            adapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
            spinnerDescription.Adapter = adapter;
            if (ConfType == Constants.strpickup)
            {

                spinnerDescription.SetSelection(1);
                descriptionIndex = 1;
            }
            else
            {
                spinnerDescription.SetSelection(4);
                descriptionIndex = 4;
            }
        }
    }
}