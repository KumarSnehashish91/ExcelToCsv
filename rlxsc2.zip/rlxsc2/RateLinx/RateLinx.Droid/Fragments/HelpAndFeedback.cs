using System;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Views;
using Android.Widget;
using V4App = Android.Support.V4.App;
using RateLinx.Helper;

namespace RateLinx.Droid.Fragments
{
    /// <summary>
    /// HelpAndFeedback 
    /// </summary>
    public class HelpAndFeedback : V4App.Fragment
    {
        #region Declaration of controls instances and variables 
        View view = null;
        Activity context = null;
        EditText txtSubject, txtMessage = null;
        Button btnFeedback = null;
        Intent email = null;
        TextView TvHeaderTitle;
        #endregion

        /// <summary>
        /// HelpAndFeedback 
        /// </summary>
        /// <param name="context"></param>
        public HelpAndFeedback(Activity context)
        {
            this.context = context;
        }

        /// <summary>
        /// HelpAndFeedback Fragment : Load Event
        /// </summary>
        /// <param name="inflater"></param>
        /// <param name="container"></param>
        /// <param name="savedInstanceState"></param>
        /// <returns></returns>
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                view = inflater.Inflate(Resource.Layout.HelpAndFeedback, null);
                btnFeedback = view.FindViewById<Button>(Resource.Id.btnFeedback);
                var toolbar = context.FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.app_bar);
                TvHeaderTitle = toolbar.FindViewById<TextView>(Resource.Id.toolbar_title);
                toolbar.FindViewById<ImageView>(Resource.Id.imgBack).Visibility = ViewStates.Invisible;
                TvHeaderTitle.Text = Constants.strHelpFeedback;
                //Login button click event
                btnFeedback.Click += BtnFeedback_Click;
                return view;
            }
            catch
            {
                //context.Finish();
                return view;
            }
        }

        /// <summary>
        /// Handle Header text
        /// </summary>
        public override void OnResume()
        {
            TvHeaderTitle.Text = Constants.strHelpFeedback;
            base.OnResume();
        }

        /// <summary>
        /// Button Feedback Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnFeedback_Click(object sender, EventArgs e)
        {
            try
            {
                txtSubject = view.FindViewById<EditText>(Resource.Id.txtSubject);
                txtMessage = view.FindViewById<EditText>(Resource.Id.txtMessage);
                email = new Intent(Intent.ActionSend);
                if (!string.IsNullOrEmpty(IsRequiredValidated()))
                {
                    Toast.MakeText(context, IsRequiredValidated(), ToastLength.Long).Show();
                }
                else
                {
                    email.PutExtra(Intent.ExtraEmail, new string[] { "issuetracker@ratelinx.com" });
                    email.PutExtra(Intent.ExtraSubject, txtSubject.Text.ToString());
                    email.PutExtra(Intent.ExtraText, txtMessage.Text.ToString());
                    email.SetType("message/rfc822");
                    StartActivity(email);
                }
            }
            catch
            {
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                context.Finish();
            }
        }

        /// <summary>
        /// Validation Checks
        /// </summary>
        /// <returns></returns>
        public string IsRequiredValidated()
        {
            try
            {
                // Get our UI controls from the loaded layout:
                string validationMessage = string.Empty;
                txtSubject = view.FindViewById<EditText>(Resource.Id.txtSubject);
                txtMessage = view.FindViewById<EditText>(Resource.Id.txtMessage);
                //-----txtSubject field----//
                if (string.IsNullOrEmpty(txtSubject.Text))
                {
                    validationMessage = Constants.enterSubject;
                }
                //-----txtMessage field----//
                else if (string.IsNullOrEmpty(txtMessage.Text))
                {
                    validationMessage = Constants.enterMessage;
                }
                return validationMessage;
            }
            catch
            {
                 Console.Write(Constants.strErrorOccured);
                return null;
            }
        }
    }
}