using Android;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Gms.Maps;
using Android.Gms.Maps.Model;
using Android.Graphics;
using Android.Locations;
using Android.OS;
using Android.Support.V4.App;
using Android.Support.V4.Content;
using Android.Views;
using Android.Views.Animations;
using Android.Widget;
using Newtonsoft.Json;
using PubnubApi;
using RateLinx.APIs;
using RateLinx.Droid.GoogleMapServices;
using RateLinx.Droid.ServiceModels;
using RateLinx.Droid.Utilities;
using RateLinx.GoogleServices;
using RateLinx.Helper;
using RateLinx.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Address = Android.Locations.Address;
using LatLng = Android.Gms.Maps.Model.LatLng;
using V4App = Android.Support.V4.App;

namespace RateLinx.Droid.Activities
{
    /// <summary>
    /// , ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize
    /// </summary>
    [Activity(Label = Constants.appName, Icon = "@drawable/icon", Theme = "@style/Theme.AppCompat.NoActionBar", ConfigurationChanges = ConfigChanges.Orientation | ConfigChanges.ScreenSize, LaunchMode = LaunchMode.SingleTop)]
    public class UpdateShipmentStatusActivity : HeaderActivity
    {
        #region variables declaration
        List<CountryDetails> lstCountryDetails = null;
        //List<string> lstCountries, lstStates = null;
        string currentStopStatus = string.Empty;
        //string countryName, stateName;
        SubscribeCallbackExt listener;
        /// <summary>
        /// 
        /// </summary>
        public static string place = string.Empty;
        /// <summary>
        /// Pub nub 
        /// </summary>
        static public Pubnub pubnub;
        static bool isStatusUpdate = false;
        static int countNotification = 0;
        static string NOTIFICATION_CHANNEL_ID = "10001";
        PNConfiguration config;
        TextView txtViewUpdatedStatus, txtAddressFrom, txtAddressTo, txtBolNumber, txtmiles, txtTotalTime, txtUsername, txtCurrentStatus, txtStopCount, txtViewCopyRight = null;
        Button btnSeekBarOverlay, btnException, btnPickup, btnDelivery, btnEquipmentScan;
        SeekBar seekbarUpdateStatus;
        LinearLayout lnrUpdateStatus;
        int statuscount = 0;
        CarrierShipmentDetails carrierShipmentDetails = null;
        ImageButton imgDispatchShipDetails, imgCallDriver, imgException, imgBack = null;
        GoogleMap map = null;
        bool isForeGround;
        MapFragment mapFrag = null;
        Dialog dialog = null;
        LatLng latLngSource, latLngStop;
        LatLng destinationLatLng;
        LatLng latLngDestination;
        ScrollView mainScrollView;
        LatLng lastSecodLatLong = null;
        Marker objMarker = null;
        PolylineOptions polylineoption = null;
        CameraPosition.Builder builder = null;
        CameraPosition cameraPosition = null;
        CameraUpdate cameraUpdate = null;
        static NotificationManager manager;
        bool isPublishEnable = true;
        float currentZoomLevel = 14;
        GPSServiceSettings objGPSServiceSettings = null;
        Models.Address address;
        string proNumber;
        Utility objUtility = null;
        int hours = 0;
        string selectedVal = string.Empty;
        int minutes = 0;
        int seconds = 0;
        string status_Code = string.Empty;
        decimal totalDistance = 0;
        string shipmentDetails, shipmentExceptionStatus = string.Empty;
        string city, state, country, liveStatusCode, liveStatusText = string.Empty;
        //Dictionary<string, string> shipmentStatus, nodeAPIStatus = null;
        Dictionary<string, string> trackingStatus = null;
        string[] addresses = null;
        string shipmentStatusValue, statusCode = string.Empty;
        ImageView imViewDestination, imViewSource;
        //bool isUpdateShipmentStatus = true;//update shipment
        bool isAnimate = true;
        string StatusMsg = string.Empty;
        List<TrackingDesc> lstTrackingVal;
        /// <summary>
        /// 
        /// </summary>
        public string ShipmentActivity = string.Empty;
        /// <summary>
        /// 
        /// </summary>
        public string currentStop = string.Empty;
        /// <summary>
        /// 
        /// </summary>
        public string Cstatus = string.Empty;

        List<TrackingDesc> lstTrackingExceptionVal;
        //"RateLinx, 4602 S Biltmore Ln 104, Madison, WI 53718";//"Madison, WI 53718";//
        string address1 = "RateLinx, 4602 S Biltmore Ln 104, Madison, WI 53718";//"Chetu A-186/187, A Block, Sector 63, A Block, Sector 63, Noida, Uttar Pradesh 201301";
        string address2 = "Madison, WI 53718";//"Logix Infotech Park, Plot No: D - 5, Sector 59 D Block, Sector 59 Noida";
        List<string> shipmentAddress = null;
        /// <summary>
        /// 
        /// </summary>
        public string ShipConfReason = string.Empty;
        bool isTimerStarted = false;
        string[] latlong = new[]{
            "28.621175 , 77.378779"
            ,"28.621170 , 77.378832","28.621166 , 77.378885","28.621165 , 77.378912","28.621164 , 77.378939","28.621162 , 77.379002"
            ,"28.621158 , 77.379034","28.621155 , 77.37908","28.621098, 77.379129","28.621104, 77.379074","28.621110, 77.379014"
            ,"28.621117, 77.378975","28.621121, 77.378941","28.621121, 77.378904","28.621125, 77.378855","28.621128, 77.378819"
            ,"28.621130, 77.378788","28.621130, 77.378749","28.621136, 77.378724","28.621136, 77.378704","28.621136, 77.378670","28.621137, 77.378642"
            ,"28.621137, 77.378642",
            "28.621144, 77.378617","28.621143, 77.378594",
            "28.621145, 77.378572",
            "28.621145, 77.378555",
            "28.621147, 77.378536"
            ,"28.621150, 77.378515","28.621151, 77.378491","28.621151, 77.378450","28.621154, 77.378422","28.621160, 77.378397","28.621157, 77.378369"
            ,"28.621160, 77.378344","28.621162, 77.378316","28.621164, 77.378291","28.621165, 77.378260","28.621168, 77.378232","28.621170, 77.378202"
            ,"28.621174, 77.378161","28.621175, 77.378107","28.621177, 77.378083","28.621178, 77.378047","28.621182, 77.378019"
            ,"28.621184, 77.377976","28.621187, 77.377941","28.621188, 77.377907","28.621190, 77.377876","28.621194, 77.377836"
            ,"28.621231, 77.377209","28.621238, 77.377117","28.621249, 77.377038","28.621251, 77.376968","28.621256, 77.376897","28.621262, 77.376864"
            ,"28.621263, 77.376830","28.621271, 77.376778","28.621274, 77.376743","28.621278, 77.376698","28.621280, 77.376644","28.621280, 77.376607"
            ,"28.621285, 77.376566","28.621288, 77.376522","28.621291, 77.376485","28.621297, 77.376443","28.621297, 77.376401","28.621301, 77.376359"
            ,"28.621305, 77.376322","28.621310, 77.376291","28.621311, 77.376228","28.621316, 77.376181","28.621320, 77.376128"
            ,"28.621325, 77.376059","28.621332, 77.375948","28.621339, 77.375847","28.621344, 77.375756","28.621353, 77.375686","28.621363, 77.375584"
            ,"28.621371, 77.375466","28.621377, 77.375359","28.621384, 77.375265","28.621391, 77.375167","28.621400, 77.375047","28.621409, 77.374902"
            ,"28.621415, 77.374793","28.621423, 77.374693","28.621429, 77.374616","28.621435, 77.374489","28.621441, 77.374365","28.621446, 77.374294"
            ,"28.621433, 77.374229"
            ,"28.621376, 77.374195","28.621303, 77.374165","28.621190, 77.374124","28.621059, 77.374108","28.620890, 77.374086"
            ,"28.620691, 77.374074","28.620496, 77.374051","28.620327, 77.374039","28.620150, 77.374019","28.619954, 77.373997","28.619812, 77.373978"
            ,"28.619625, 77.373962","28.619312, 77.373926","28.619118, 77.373907","28.618815, 77.373876","28.618582, 77.373856","28.618353, 77.373833"
            ,"28.618182, 77.373820","28.617936, 77.373803","28.617708, 77.373811","28.617492, 77.373837","28.617187, 77.373844","28.616908, 77.373817"
            ,"28.616715, 77.373805","28.616381, 77.373751","28.616172, 77.373702","28.615955, 77.373646","28.615780, 77.373598","28.615453, 77.373552"
            ,"28.615262, 77.373520","28.615001, 77.373497","28.614790, 77.373477","28.614505, 77.373452","28.614286, 77.373433","28.613748, 77.373366"
            ,"28.613265, 77.373323","28.612611, 77.373259","28.612000, 77.373199","28.611562, 77.373151","28.611056, 77.373107","28.610468, 77.373053"
            ,"28.610212, 77.373082","28.609644, 77.373018","28.609461, 77.373002","28.609294, 77.372956","28.609103, 77.372933","28.608896, 77.372935"
            ,"28.608717, 77.372924","28.608053, 77.372869","28.607925, 77.372837","28.607910, 77.372790","28.607936, 77.372723","28.608126, 77.372673"
            ,"28.608255, 77.372590","28.608253, 77.372518","28.608301, 77.372536"
        };
        readonly string[] PermissionsLocation =
                        {
         Manifest.Permission.AccessCoarseLocation,
         Manifest.Permission.AccessFineLocation
        };
        string channelGroup
        {
            get;
            set;
        }
        string compositeKey, clientID, driverID = string.Empty;//status
        #endregion

        /// <summary>
        /// 
        /// </summary>
        public UpdateShipmentStatusActivity()
        {
            try
            {
                shipmentAddress = new List<string>();
                objGPSServiceSettings = new GPSServiceSettings();
                objGPSServiceSettings.StartLocationUpdates(this);//this
                trackingStatus = CommanUtil.TrackingStatus();

            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public class LocalLog : IPubnubLog
        {
            void IPubnubLog.WriteToLog(string logText)
            {
                System.Diagnostics.Debug.WriteLine(logText);
            }
        }

        /// <summary>
        /// OnCreate event on page
        /// </summary>
        /// <param name="savedInstanceState"></param>
        async protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);
                if (string.IsNullOrEmpty(CommanUtil.tokenNo))
                {
                    Utility.Logout(this);
                }
                PubNubAccountSetting();
                lstTrackingVal = CommanUtil.TrackingValue();
                RequestWindowFeature(WindowFeatures.NoTitle);
                SetContentView(Resource.Layout.UpdateShipmentStatusLayout);
                txtViewCopyRight = FindViewById<TextView>(Resource.Id.txtViewCopyRight);
                txtViewCopyRight.Text = CommanUtil.PrintYear();//Printc Current Year in Page Footer 
                #region Check internet connectivity
                if (!Utility.FnIsOnline(this))
                {
                    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                #endregion
                mainScrollView = FindViewById<ScrollView>(Resource.Id.mainScrollView);
                btnDelivery = FindViewById<Button>(Resource.Id.btnDelivery);
                btnEquipmentScan = FindViewById<Button>(Resource.Id.btnEquipmentScan);
                btnPickup = FindViewById<Button>(Resource.Id.btnPickup);
                imViewSource = FindViewById<ImageView>(Resource.Id.imViewSource);
                imViewDestination = FindViewById<ImageView>(Resource.Id.imViewDest);
                txtViewUpdatedStatus = FindViewById<TextView>(Resource.Id.txtViewUpdatedStatus);
                btnException = FindViewById<Button>(Resource.Id.btnException);
                txtCurrentStatus = FindViewById<TextView>(Resource.Id.txtCurrentStatus);
                txtAddressFrom = FindViewById<TextView>(Resource.Id.txtAddressFrom);
                txtAddressTo = FindViewById<TextView>(Resource.Id.txtAddressTo);
                txtBolNumber = FindViewById<TextView>(Resource.Id.txtBolNumber);
                txtmiles = FindViewById<TextView>(Resource.Id.txtMiles);
                txtTotalTime = FindViewById<TextView>(Resource.Id.txtTotalTime);
                txtUsername = FindViewById<TextView>(Resource.Id.txtUserName);
                seekbarUpdateStatus = FindViewById<SeekBar>(Resource.Id.seekbarUpdateStatus);
                mapFrag = (MapFragment)FragmentManager.FindFragmentById(Resource.Id.map);
                imgDispatchShipDetails = FindViewById<ImageButton>(Resource.Id.imgDispatchShipDetails);
                imgCallDriver = FindViewById<ImageButton>(Resource.Id.imgCallDriver);
                imgException = FindViewById<ImageButton>(Resource.Id.imgException);
                imgBack = FindViewById<ImageButton>(Resource.Id.imgBack);
                lnrUpdateStatus = FindViewById<LinearLayout>(Resource.Id.lnrUpdateStatus);
                txtStopCount = FindViewById<TextView>(Resource.Id.txtStopCount);
                if (IsTablet(this))
                {
                    mapFrag.View.LayoutParameters.Height = 750; //The size you decide
                }

                if (txtViewUpdatedStatus.Text == Constants.enrouteToPickup)
                {
                    txtCurrentStatus.Text = Constants.shippingNotStart;
                }
                imgBack.Click += delegate
                {
                    Constants.stopIncrement = 0;
                    Constants.currentShipStatus = string.Empty;
                    Finish();
                };
                CommanUtil.isAccuracyFine = true;
                place = Intent.GetStringExtra("shipmentDetails");
                if (Intent.GetStringExtra("shipmentDetails") == null)
                {
                    Alerts.HideBusyLoader();
                    place = Utility.sharedPreferences.GetString("DispatchData", null);
                }
                addresses = place.Split('#');
                txtAddressFrom.Text = addresses[0];//address1
                address1 = addresses[0];
                txtAddressTo.Text = addresses[1];//address2
                address2 = addresses[1];
                txtBolNumber.Text = addresses[2];
                txtUsername.Text = CommanUtil.userID;
                compositeKey = CommanUtil.CompositeKey(addresses[4], Convert.ToInt32(addresses[3]), addresses[2]);
                clientID = addresses[4];
                driverID = addresses[5];
                await GetShipmentDetails();
                #region Calling functionality
                imgCallDriver.Click += delegate
                {
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);

                    builder.SetTitle("Call");
                    builder.SetMessage("\n" + " " + address.Phone);

                    builder.SetPositiveButton("YES", delegate
                    {
                        var uri = Android.Net.Uri.Parse("tel:" + address.Phone);
                        var intent = new Intent(Intent.ActionDial, uri);
                        StartActivity(intent);
                    });
                    builder.SetNegativeButton("No", delegate
                    {

                    });
                    AlertDialog alert = builder.Create();
                    alert.SetCancelable(false);
                    alert.Show();
                };
                #endregion
                #region Detail icon click
                imgDispatchShipDetails.Click += delegate
                {
                    string composite_Key = compositeKey;
                    if (string.IsNullOrEmpty(statusCode))
                    {
                        composite_Key += "|" + "";
                    }
                    else
                    {
                        if (statusCode == Constants.exceptionkey)
                        {
                            composite_Key += "|" + shipmentStatusValue;
                        }
                        else
                        {
                            composite_Key += "|" + trackingStatus[statusCode];
                        }
                    }
                    Intent intentDispatchDetails = Utility.RedirectTo(this, typeof(DispatchShipDetailsActivity), "compositeKey", composite_Key);
                    StartActivity(intentDispatchDetails);
                };
                #endregion               

                btnEquipmentScan.Click += delegate
                {
                    if ((ContextCompat.CheckSelfPermission(this, Manifest.Permission.Camera) == (int)Permission.Granted))
                    {
                        //Constants.stopCountForConfirmtion = currentStopStatus;
                        Intent equipmentScan = new Intent(this, typeof(EquipmentScanningActivity));
                        Constants.methodNmaeForEquipmentScanning = APIMethods.shipmentDetails + "/" + carrierShipmentDetails.ClientID + "|" + carrierShipmentDetails.BolNum;
                        StartActivity(equipmentScan);
                    }
                    else
                    {
                        V4App.ActivityCompat.RequestPermissions(this, PermissionsLocation, 0);
                    }
                };
                btnPickup.Click += delegate
                {
                    if ((ContextCompat.CheckSelfPermission(this, Manifest.Permission.AccessFineLocation) == (int)Permission.Granted) &&
                 (ContextCompat.CheckSelfPermission(this, Manifest.Permission.AccessCoarseLocation) == (int)Permission.Granted))
                    {
                        GotoShipConfirmation(Constants.strPickConf);
                    }
                    else
                    {
                        V4App.ActivityCompat.RequestPermissions(this, PermissionsLocation, 0);
                    }
                };
                btnDelivery.Click += delegate
                {
                    if ((ContextCompat.CheckSelfPermission(this, Manifest.Permission.AccessFineLocation) == (int)Permission.Granted) &&
                 (ContextCompat.CheckSelfPermission(this, Manifest.Permission.AccessCoarseLocation) == (int)Permission.Granted))
                    {
                        GotoShipConfirmation(Constants.strDeliveryConf);
                    }
                    else
                    {
                        V4App.ActivityCompat.RequestPermissions(this, PermissionsLocation, 0);
                    }
                };
                btnSeekBarOverlay = FindViewById<Button>(Resource.Id.btnSeekBarOverlay);
                seekbarUpdateStatus.StopTrackingTouch += async delegate
                {
                    await SeekBarStatusChangedAsync(seekbarUpdateStatus, btnSeekBarOverlay);
                };

                seekbarUpdateStatus.StartTrackingTouch += delegate
                {
                    ShowHideButtonOverlay(btnSeekBarOverlay);
                };
                imgException.Click += delegate
                {
                    if (statuscount >= 7)
                    {
                        Toast.MakeText(this, Constants.shippingCompleted, ToastLength.Short).Show();
                        return;
                    }

                    AlertDialog.Builder alert = null;
                    alert = new AlertDialog.Builder(this);
                    alert.SetView(Resource.Layout.AssignDriverPopupLayout);
                    dialog = alert.Create();
                    dialog.Show();
                    Button btnSubmit = dialog.FindViewById<Button>(Resource.Id.btnNo);
                    btnSubmit.Text = "Submit";
                    Button btnNo = dialog.FindViewById<Button>(Resource.Id.btnYes);
                    btnNo.Text = "Cancel";
                    TextView txtHeaderText = dialog.FindViewById<TextView>(Resource.Id.txtDialogHeader);
                    txtHeaderText.Text = "Select your reason";
                    TextView txtReason = dialog.FindViewById<TextView>(Resource.Id.txtReason);
                    txtReason.Text = "Reason";
                    TextView txtViewClose = dialog.FindViewById<TextView>(Resource.Id.txtViewClose);
                    Spinner spinnerExceptionDesc = dialog.FindViewById<Spinner>(Resource.Id.spinnerDriver);
                    ArrayAdapter driverAdapter = Utility.ExceptionAdapter(this);
                    driverAdapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
                    spinnerExceptionDesc.Adapter = driverAdapter;
                    Alerts.HideBusyLoader();
                    driverAdapter = null;
                    btnNo.Click += delegate
                    {
                        //dialog.Hide();
                        dialog.Dismiss();
                    };
                    txtViewClose.Click += delegate
                    {
                        dialog.Hide();
                    };
                    btnSubmit.Click += async delegate
                    {
                        selectedVal = Convert.ToString(spinnerExceptionDesc.SelectedItem);
                        if (!Utility.FnIsOnline(this))
                        {
                            Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                            return;
                        }
                        if (selectedVal != "Select")
                        {
                            dialog.Hide();
                            status_Code = CommanUtil.ExceptionDescList().Where(m => m.text == selectedVal).Select(m => m.value).FirstOrDefault();
                            StatusMsg = selectedVal;
                            await UpdateShipmentStatus(status_Code, selectedVal);
                        }
                        else
                        {
                            Toast.MakeText(this, Constants.strSelectReason, ToastLength.Long).Show();
                        }
                    };
                    dialog.SetCancelable(false);

                };
                var mapReadyCallback = new OnMapReadyClass();
                mapReadyCallback.MapReadyAction += async delegate (GoogleMap objMap)
                {
                    map = objMap;
                    await FnplotMap(map); //Plot Map
                };
                mapFrag.GetMapAsync(mapReadyCallback);
                #region Checking callback Response 
                listener = new SubscribeCallbackExt(
                    (o, m) =>
                    {
                        //Publisher Response
                        if (m != null)
                        {
                            //Display(pubnub.JsonPluggableLibrary.SerializeToJsonString(m.Message));
                            var demo = pubnub.JsonPluggableLibrary.SerializeToJsonString(m.Message);
                            ShipmentStatus objShipmentStatus = JsonConvert.DeserializeObject<ShipmentStatus>(demo);
                            // DriverStatus objDriverStatus 
                            GetDirectionResponseAsync(objShipmentStatus);
                        }
                    },
                    (o, p) =>
                    {
                        //Subscriber join or not 
                        if (p != null)
                        {
                            //Display(p.Event);
                        }
                    },
                    (o, s) =>
                    {
                        //status code of subscriber
                        if (s != null)
                        {
                            //Display(s.Category + " " + s.Operation + " " + s.StatusCode);
                        }
                    }
                    );
                Subscribe(clientID + txtBolNumber.Text.Trim());
                await StartTimer();
                #endregion

            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
            }
            finally
            {
                Alerts.HideBusyLoader();
            }
        }
        /// <summary>
        /// Disable scrollview scrolling on Map touch event
        /// </summary>
        /// <param name="e"></param>
        /// <returns></returns>
        public override bool DispatchTouchEvent(MotionEvent e)
        {
            var action = e.Action;
            switch (action)
            {
                case MotionEventActions.Down:
                    // Disallow ScrollView to intercept touch events.
                    mainScrollView.RequestDisallowInterceptTouchEvent(true);
                    // Disable touch on transparent view
                    break;
                case MotionEventActions.Up:
                    // Allow ScrollView to intercept touch events.
                    mainScrollView.RequestDisallowInterceptTouchEvent(false);
                    break;

                case MotionEventActions.Move:
                    mainScrollView.RequestDisallowInterceptTouchEvent(true);
                    break;
            }
            return base.DispatchTouchEvent(e);
        }
        /// <summary>
        /// 
        /// </summary>
        protected override void OnDestroy()
        {
            base.OnDestroy();
            Constants.stopIncrement = 0;
        }
        /// <summary>
        /// Redirect to confirmation screen
        /// </summary>
        /// <param name="confirmationType"></param>
        private void GotoShipConfirmation(string confirmationType)
        {
            try
            {
                // Constants.stopCountForConfirmtion = currentStopStatus;
                string[] arrPickupConf = new string[4];
                if (confirmationType == Constants.strDeliveryConf)
                {
                    arrPickupConf[0] = Constants.strDeliveryConf;
                }
                else
                {
                    arrPickupConf[0] = Constants.strPickConf;
                }
                arrPickupConf[1] = carrierShipmentDetails.ClientID + "|" + carrierShipmentDetails.LocID + "|" + carrierShipmentDetails.BolNum;
                arrPickupConf[2] = "1";
                arrPickupConf[3] = proNumber;
                if (carrierShipmentDetails.DispatchFlag)
                {
                    CommanUtil.shipmentType = Constants.dispatcher;
                }
                else
                {
                    CommanUtil.shipmentType = Constants.strCustomer;
                }
                Intent confirmationScreen = new Intent(this, typeof(ConfirmationDetailActivity));
                confirmationScreen.PutExtra("PickupConf", carrierShipmentDetails.ClientID + "|" + carrierShipmentDetails.LocID + "|" + carrierShipmentDetails.BolNum + "|" + confirmationType);
                StartActivity(confirmationScreen);
            }
            catch (Exception ex)
            {
                Toast.MakeText(this, ex.Message, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        protected override void OnPause()
        {
            base.OnPause();
            if (Constants.isEnrouteToDelivery)
            {
                string notificationMsg = Constants.enrouteToDelivery;
                string notificationTitle = Constants.strShipmentEnrouteText;

                SendNotification(notificationMsg, notificationTitle);
            }
        }

        /// <summary>
        /// Function to handle notifications
        /// </summary>
        /// <param name="notificationMsg">Message for the notification</param>
        /// <param name="notificationTitle">Title for the notification</param>
        public void SendNotification(string notificationMsg, string notificationTitle)
        {
            try
            {

                Bundle bundle = new Bundle();

                bundle.PutString("message", place);
                Intent intent = new Intent();

                intent.AddFlags(ActivityFlags.ClearTop);
                intent.PutExtra("data", bundle);
                Utility.sharedPreferences.Edit().PutString("DispatchData", place).Commit();
                intent = new Intent(this, typeof(UpdateShipmentStatusActivity));
                var pendingIntent = PendingIntent.GetActivity(this, 0, intent, PendingIntentFlags.OneShot);

                var notificationBuilder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
                .SetSmallIcon(GetNotificationIcon())
                .SetStyle(new NotificationCompat.BigTextStyle().BigText(notificationMsg))
                .SetContentTitle(notificationTitle)
                .SetAutoCancel(true)
                // .AddAction()
                .SetContentIntent(pendingIntent);
                var notificationManager = (NotificationManager)GetSystemService(NotificationService);
                manager = notificationManager;
                if (((int)Build.VERSION.SdkInt) >= 26)
                {
                    var importance = NotificationImportance.High;
                    NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, "NOTIFICATION_CHANNEL_NAME", importance);
                    notificationChannel.EnableLights(true);
                    notificationChannel.LightColor = Color.Red;
                    if (notificationManager != null)
                    {
                        notificationBuilder.SetChannelId(NOTIFICATION_CHANNEL_ID);
                        notificationBuilder.SetOngoing(true);
                        notificationBuilder.SetOnlyAlertOnce(true);
                    }
                    notificationManager.CreateNotificationChannel(notificationChannel);
                }
                notificationManager.Notify(countNotification, notificationBuilder.Build());

            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Set Account setting of pubnub
        /// </summary>
        async void PubNubAccountSetting()
        {
            try
            {
                lstCountryDetails = new List<CountryDetails>();
                lstCountryDetails = await Utility.GetCountryDetails(this);
                //Pub Nub Details
                config = new PNConfiguration
                {
                    SubscribeKey = Constants.pubnubSubscribeKey,
                    PublishKey = Constants.pubnubPublishKey,
                    //config.Secure = true;
                    PubnubLog = new LocalLog(),
                    LogVerbosity = PNLogVerbosity.BODY,
                    ReconnectionPolicy = PNReconnectionPolicy.LINEAR
                };
                pubnub = new Pubnub(config);
                //Unsub(clientID + txtBolNumber.Text.Trim());
                Subscribe(clientID + txtBolNumber.Text.Trim()); //Susbriber for him/her self
                //Start Location Service
                GPSServiceSettings objGPSServiceSettings = new GPSServiceSettings();
                objGPSServiceSettings.StartLocationUpdates(this);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// IsTrackingEnableAsync will call on oncreate event
        /// </summary>
        public async Task IsTrackingEnableAsync()
        {
            string shipStatus = string.Empty;
            try
            {
                if (carrierShipmentDetails != null && carrierShipmentDetails.TrackDetails.Count > 0)
                {
                    CommanUtil.isTrackingEnable = true;
                    shipStatus = trackingStatus.Where(x => x.Value == carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 1].ActivityDescr).Select(x => x.Key).FirstOrDefault();

                    for (int trackDetailsCount = carrierShipmentDetails.TrackDetails.Count; trackDetailsCount > 0; trackDetailsCount--)
                    {
                        string trackInfo = carrierShipmentDetails.TrackDetails[trackDetailsCount - 1].ActivityDescr;
                        if (!CommanUtil.ExceptionTextList.Contains(trackInfo))
                        {
                            status_Code = trackingStatus.Where(x => x.Value == carrierShipmentDetails.TrackDetails[trackDetailsCount - 1].ActivityDescr).Select(x => x.Key).FirstOrDefault();
                            break;
                        }
                    }

                    shipStatus = status_Code;
                }
                switch (shipStatus)
                {
                    case Constants.inTransitkey:
                        Constants.isEnrouteToDelivery = false;
                        statuscount = 1;
                        //statusCode = "IT";
                        statusCode = Constants.inTransitkey;
                        shipmentStatusValue = trackingStatus[Constants.inTransitkey];
                        txtCurrentStatus.Text = trackingStatus[Constants.inTransitkey];
                        txtViewUpdatedStatus.Text = trackingStatus[Constants.arrivedAtPickupKey]; //loadingkey
                        liveStatusCode = Constants.inTransitkey;
                        liveStatusText = trackingStatus[Constants.inTransitkey];
                        StatusMsg = txtViewUpdatedStatus.Text;
                        break;
                    case Constants.arrivedAtPickupKey:
                        Constants.isEnrouteToDelivery = false;
                        statuscount = 2;
                        //statusCode = "IT";
                        statusCode = Constants.arrivedAtPickupKey;
                        shipmentStatusValue = trackingStatus[Constants.arrivedAtPickupKey];
                        txtCurrentStatus.Text = trackingStatus[Constants.arrivedAtPickupKey];
                        txtViewUpdatedStatus.Text = trackingStatus[Constants.pickedupKey]; //loadingkey
                        liveStatusCode = Constants.arrivedAtPickupKey;
                        liveStatusText = trackingStatus[Constants.arrivedAtPickupKey];
                        StatusMsg = txtViewUpdatedStatus.Text;
                        break;
                    case Constants.pickedupKey:
                        Constants.isEnrouteToDelivery = false;
                        statuscount = 3;
                        statusCode = Constants.pickedupKey;
                        shipmentStatusValue = trackingStatus[Constants.pickedupKey];
                        txtCurrentStatus.Text = trackingStatus[Constants.pickedupKey];
                        txtViewUpdatedStatus.Text = trackingStatus[Constants.enRoutekey];
                        liveStatusCode = Constants.pickedupKey;
                        liveStatusText = trackingStatus[Constants.pickedupKey];
                        StatusMsg = txtViewUpdatedStatus.Text;
                        break;

                    case Constants.enRoutekey:
                        Constants.isEnrouteToDelivery = true;
                        statuscount = 4;
                        statusCode = Constants.enRoutekey;
                        shipmentStatusValue = trackingStatus[Constants.enRoutekey];
                        txtCurrentStatus.Text = trackingStatus[Constants.enRoutekey];
                        txtViewUpdatedStatus.Text = trackingStatus[Constants.arrivedkey];
                        liveStatusCode = Constants.enRoutekey;
                        liveStatusText = trackingStatus[Constants.enRoutekey];
                        StatusMsg = txtViewUpdatedStatus.Text;
                        while (Constants.isEnrouteToDelivery)
                        {
                            Alerts.HideBusyLoader();
                            isForeGround = AppInForeground();
                            if (!isForeGround)
                            {
                                await UpdateShipmentStatus(Constants.enRoutekey, trackingStatus[Constants.enRoutekey]);
                            }
                            else
                            {
                                //no implementation needed
                            }
                            await Task.Delay(900000);
                        }
                        break;

                    case Constants.arrivedkey:
                        Constants.isEnrouteToDelivery = false;
                        statuscount = 5;
                        statusCode = Constants.arrivedkey;
                        shipmentStatusValue = trackingStatus[Constants.arrivedkey];
                        txtCurrentStatus.Text = trackingStatus[Constants.arrivedkey];
                        txtViewUpdatedStatus.Text = trackingStatus[Constants.completedkey];
                        liveStatusCode = Constants.arrivedkey;
                        liveStatusText = trackingStatus[Constants.arrivedkey];
                        StatusMsg = txtViewUpdatedStatus.Text;
                        break;

                    case Constants.completedkey:
                        Constants.isEnrouteToDelivery = false;
                        statuscount = 6;
                        statusCode = Constants.completedkey;
                        shipmentStatusValue = trackingStatus[Constants.completedkey];
                        txtCurrentStatus.Text = trackingStatus[Constants.completedkey];
                        txtViewUpdatedStatus.Text = trackingStatus[Constants.completedkey];
                        liveStatusCode = Constants.completedkey;
                        liveStatusText = trackingStatus[Constants.completedkey];
                        StatusMsg = txtViewUpdatedStatus.Text;
                        ResetTracking(); //Reset tracking details
                        break;

                    case Constants.exceptionkey1:
                        Constants.isEnrouteToDelivery = false;
                        statuscount = 7;
                        statusCode = Constants.exceptionkey1;
                        shipmentStatusValue = trackingStatus[shipStatus];
                        txtCurrentStatus.Text = trackingStatus[shipStatus];
                        txtViewUpdatedStatus.Text = trackingStatus[shipStatus];
                        liveStatusCode = Constants.exceptionkey1;
                        liveStatusText = trackingStatus[shipStatus];
                        StatusMsg = txtViewUpdatedStatus.Text;
                        //ResetTracking(); //Reset tracking details
                        break;

                    case Constants.exceptionkey2:
                        Constants.isEnrouteToDelivery = false;
                        statuscount = 7;
                        statusCode = Constants.exceptionkey2;
                        shipmentStatusValue = trackingStatus[shipStatus];
                        txtCurrentStatus.Text = trackingStatus[shipStatus];
                        txtViewUpdatedStatus.Text = trackingStatus[shipStatus];
                        liveStatusCode = Constants.exceptionkey2;
                        liveStatusText = trackingStatus[shipStatus];
                        StatusMsg = txtViewUpdatedStatus.Text;
                        //ResetTracking(); //Reset tracking details
                        break;

                    case Constants.exceptionkey3:
                        Constants.isEnrouteToDelivery = false;
                        statuscount = 7;
                        statusCode = Constants.exceptionkey3;
                        shipmentStatusValue = trackingStatus[shipStatus];
                        txtCurrentStatus.Text = trackingStatus[shipStatus];
                        txtViewUpdatedStatus.Text = trackingStatus[shipStatus];
                        liveStatusCode = Constants.exceptionkey3;
                        liveStatusText = trackingStatus[shipStatus];
                        StatusMsg = txtViewUpdatedStatus.Text;
                        //ResetTracking(); //Reset tracking details
                        break;

                    case Constants.exceptionkey4:
                        Constants.isEnrouteToDelivery = false;
                        statuscount = 7;
                        statusCode = Constants.exceptionkey4;
                        shipmentStatusValue = trackingStatus[shipStatus];
                        txtCurrentStatus.Text = trackingStatus[shipStatus];
                        txtViewUpdatedStatus.Text = trackingStatus[shipStatus];
                        liveStatusCode = Constants.exceptionkey4;
                        liveStatusText = trackingStatus[shipStatus];
                        StatusMsg = txtViewUpdatedStatus.Text;
                        //ResetTracking(); //Reset tracking details
                        break;

                    case Constants.exceptionkey5:
                        Constants.isEnrouteToDelivery = false;
                        statuscount = 7;
                        statusCode = Constants.exceptionkey5;
                        shipmentStatusValue = trackingStatus[shipStatus];
                        txtCurrentStatus.Text = trackingStatus[shipStatus];
                        txtViewUpdatedStatus.Text = trackingStatus[shipStatus];
                        liveStatusCode = Constants.exceptionkey5;
                        liveStatusText = trackingStatus[shipStatus];
                        StatusMsg = txtViewUpdatedStatus.Text;
                        //ResetTracking(); //Reset tracking details
                        break;
                    default:
                        txtCurrentStatus.Text = Constants.shippingNotStart;
                        txtViewUpdatedStatus.Text = Constants.enrouteToPickup;
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Application is in Background or in ForGround
        /// </summary>
        /// <returns></returns>
        public bool AppInForeground()
        {
            try
            {
                ArrayList runningactivities = new ArrayList();
                Context context = Application.Context;
                ActivityManager activityManager = (ActivityManager)context.GetSystemService(ActivityService);

                IList<ActivityManager.RunningAppProcessInfo> appProcesses = activityManager.RunningAppProcesses;
                if (appProcesses == null)
                {
                    return false;
                }
                string packageName = context.PackageName;
                foreach (ActivityManager.RunningAppProcessInfo appProcess in appProcesses)
                {
                    if (appProcess.Importance == Importance.Foreground && appProcess.ProcessName == packageName)
                    {
                        return true;
                    }
                }
                return false;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Get the shipment detail
        /// </summary>
        public async Task GetShipmentDetails()
        {
            string shipStatus = string.Empty;
            try
            {
                isStatusUpdate = true;
                objUtility = new Utility();
                string response = await objUtility.BindShipmentDetail(APIMethods.shipmentDetails + "/" + addresses[4] + "|" + addresses[2], this);
                if (!string.IsNullOrEmpty(response))
                {
                    carrierShipmentDetails = JsonConvert.DeserializeObject<CarrierShipmentDetails>(response);
                    address = carrierShipmentDetails.Addresses[1];
                    proNumber = carrierShipmentDetails.ProNum;
                    if (carrierShipmentDetails.TrackDetails != null && carrierShipmentDetails.TrackDetails.Count > 0)
                    {
                        shipStatus = carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 1].ActivityDescr.ToString();
                        //txtCurrentStatus.Text = shipStatus;
                        if (shipStatus == Constants.strCompletedDeliveryText2 || shipStatus == "Delivery" || shipStatus == Constants.strCompletedDeliveryText)
                        {
                            txtCurrentStatus.Text = Constants.strCompletedDeliveryText;

                            imgException.Visibility = ViewStates.Gone;
                            lnrUpdateStatus.Visibility = ViewStates.Gone;
                        }
                        if (!string.IsNullOrEmpty(carrierShipmentDetails.TrackDetails.Where(m => m.ActivityDescr.Equals("En Route")).Select(m => m.Activity).LastOrDefault()))
                        {
                            if (shipStatus == Constants.strTruckBrokeDown || shipStatus == Constants.strTrafficDelay
                                || shipStatus == Constants.strWeatherDelay || shipStatus == Constants.strDockClosed
                                || shipStatus == Constants.strOtherText || shipStatus == Constants.strExceptionText)
                            {
                                Constants.shipStartTime = string.Empty;
                            }
                            else
                            {
                                Constants.shipStartTime = carrierShipmentDetails.TrackDetails.Where(m => m.ActivityDescr.Equals("En Route")).Select(m => m.Activity).LastOrDefault();
                            }
                        }
                        else
                        {
                            if (shipStatus == Constants.strTruckBrokeDown || shipStatus == Constants.strTrafficDelay
                                || shipStatus == Constants.strWeatherDelay || shipStatus == Constants.strDockClosed
                                || shipStatus == Constants.strOtherText || shipStatus == Constants.strExceptionText)
                            {
                                Constants.shipStartTime = string.Empty;
                            }
                            else
                            {
                                Constants.shipStartTime = carrierShipmentDetails.TrackDetails.Where(m => m.ActivityDescr == Constants.strIntransit || m.ActivityDescr == Constants.enrouteToPickup).Select(m => m.Activity).LastOrDefault();
                            }
                        }


                    }
                    else
                    {
                        Constants.shipStartTime = string.Empty;
                        Constants.isEnroute = false;
                    }
                    foreach (var address in carrierShipmentDetails.Addresses)
                    {
                        shipmentAddress.Add(string.Format($"{address.Address1} {address.Address2} {address.City} {address.State} {address.Zip}"));
                    }
                    if (!string.IsNullOrEmpty(Constants.shipStartTime))
                    {
                        if (shipStatus == Constants.strCompletedDeliveryText || statuscount >= 7 || shipStatus == Constants.strCompletedDeliveryText2 || shipStatus == Constants.strdelivery)
                        {
                            Constants.isEnroute = false;
                            isTimerStarted = true;
                        }
                        else
                        {
                            Constants.isEnroute = true;
                            if (statuscount <= 1)
                            {
                                isTimerStarted = true;
                            }
                            else
                            {
                                var exceptionText = carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 2].ActivityDescr.ToString();
                                if (exceptionText == Constants.strTruckBrokeDown || exceptionText == Constants.strTrafficDelay
                               || exceptionText == Constants.strWeatherDelay || exceptionText == Constants.strDockClosed
                               || exceptionText == Constants.strOtherText || exceptionText == Constants.strExceptionText)
                                {
                                    isTimerStarted = true;
                                }
                                else
                                {
                                    isTimerStarted = false;
                                }
                            }
                        }
                    }
                    else
                    {
                        Constants.isEnroute = false;
                    }
                    //await StartTimer();
                }


            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to get country and state code
        /// </summary>
        /// <param name="country"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        public (string, string) GetCountry(string country = "", string state = "")
        {
            string countryCode = string.Empty;
            string stateCode = string.Empty;
            try
            {
                if (lstCountryDetails != null)
                {
                    var lstCountry = lstCountryDetails.Where(countryDetails => countryDetails.Name.Equals(country.ToUpper())).FirstOrDefault();
                    if (lstCountry != null)
                    {
                        countryCode = lstCountry.Code;
                        if (lstCountry.States != null)
                        {
                            stateCode = lstCountry.States.Where(countryState => countryState.Name.Equals(state.ToUpper())).Select(countryState => countryState.Code).FirstOrDefault();
                        }
                        if (string.IsNullOrEmpty(stateCode))
                        {
                            stateCode = state;
                        }
                    }
                    else
                    {
                        countryCode = country;
                        stateCode = state;
                    }
                }
                return (countryCode, stateCode);
            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// Update Shipment Tracking Status in RateLinx API
        /// </summary>
        /// <returns></returns>
        public async Task<string> UpdateShipmentTrackingStatus(string statusCode, string shipmentStatus)
        {
            try
            {
                string result = string.Empty;
                if (!Utility.FnIsOnline(this))
                {
                    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    return result;
                }
                double currentLat = CommanUtil.currLat;//37.089984;
                double currentLong = CommanUtil.currLong;//-95.715063;

                var geocoder = new Geocoder(this);
                IList<Address> addressList = await geocoder.GetFromLocationAsync(currentLat, currentLong, 10);
                if (addressList != null && addressList.Count > 0)
                {
                    Address addressCurrent = addressList.FirstOrDefault();
                    if (addressCurrent != null)
                    {
                        city = addressCurrent.Locality;
                        state = addressCurrent.AdminArea;//"UP";
                        country = addressCurrent.CountryName;
                        if (addressCurrent.AdminArea.ToUpper() == "UTTAR PRADESH")
                        {
                            state = "UP";
                        }
                        var code = GetCountry(country, state);
                        var countryCode = code.Item1;
                        if (statusCode == Constants.exceptionkey1 || statusCode == Constants.exceptionkey2 || statusCode == Constants.exceptionkey3 || statusCode == Constants.exceptionkey4 || statusCode == Constants.exceptionkey5)
                        {
                            statusCode = Constants.exceptionkey;
                        }
                        var stateCode = code.Item2;

                        string payload_str = "{"
                                + "\"ProNumber\":" + "\"" + addresses[6] + "\","
                                + "\"ActivityDate\":" + "\"" + DateTime.Now.ToString(Constants.dateFormatMMDDYYYYHHMMSS) + "\","
                                + "\"ActivityCode\":" + "\"" + statusCode + "\","
                                + "\"ActivityDescr\":" + "\"" + shipmentStatus + "\","
                                + "\"City\":" + "\"" + city + "\","
                                + "\"State\":" + "\"" + stateCode + "\","   //state
                                 + "\"Country\":" + "\"" + countryCode + "\","
                                + "\"Stop\":" + "\"" + currentStop + "\","
                                + "\"CurrentStatus\":" + "\"" + Cstatus + "\""
                                +
                                "}";

                        string methodURI = APIMethods.shipmentDetails + "/" + compositeKey + "/" + APIMethods.tracking;
                        ServiceHelper objServiceHelper = new ServiceHelper();
                        return await objServiceHelper.PostRequestJson(payload_str, methodURI, CommanUtil.tokenNo, true);
                    }
                    else
                    {
                        Toast.MakeText(this, Constants.strLocation, ToastLength.Long).Show();
                        return result;
                    }
                }
                else
                {
                    Toast.MakeText(this, Constants.strLocation, ToastLength.Long).Show();
                    return result;
                }
            }
            catch
            {
                Alerts.HideBusyLoader();
                throw;
                //Console.Write(Constants.strErrorOccured);
            }
        }

        /// <summary>
        /// Show Hide Button
        /// </summary>
        /// <param name="button"></param>
        private void ShowHideButtonOverlay(Button button)
        {
            button.Visibility = ViewStates.Gone;
        }

        /// <summary>
        /// Seek Bar Status Changed Event
        /// </summary>
        /// <param name="seekbar"></param>
        /// <param name="button"></param>
        private async Task SeekBarStatusChangedAsync(SeekBar seekbar, Button button)
        {
            try
            {
                button.Visibility = ViewStates.Visible;
                bool isAllowUpdate = true;
                string alertMsg = string.Empty;
                if (seekbar.Progress < 70)
                {
                    seekbar.Progress = 0;
                }
                else
                {
                    seekbar.Progress = 0;
                    if (!Utility.FnIsOnline(this))
                    {
                        Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                        return;
                    }
                    else
                    {
                        //Nothing to do
                    }
                    if (!ISGPSConnected())// Check If GPS is Conncted or not
                    {
                        Toast.MakeText(this, Constants.strEnableTracking, ToastLength.Short).Show();
                        return;
                    }
                    if (CommanUtil.currLat == 0)
                    {
                        objGPSServiceSettings = new GPSServiceSettings();
                        objGPSServiceSettings.StartLocationUpdates(this);//this
                    }
                    if (string.IsNullOrEmpty(driverID))
                    {
                        Toast.MakeText(this, Constants.strAssignDriver, ToastLength.Long).Show();
                        return;
                    }
                    if (!CommanUtil.IsTimeOut())
                    {
                        Utility.ExpireSession(this);
                        return;
                    }
                    statuscount += 1;

                    if (carrierShipmentDetails.IsMultiStop && statuscount > 5)
                    {
                        statuscount -= 1;
                    }
                    else if (carrierShipmentDetails.IsMultiStop && statuscount == 5)
                    {
                        Cstatus = "Delivered";
                    }


                    switch (statuscount)
                    {
                        case 1:
                            statusCode = Constants.inTransitkey;
                            shipmentStatusValue = Constants.arrivedAtPickupKey;
                            StatusMsg = trackingStatus[statusCode];
                            break;
                        case 2:
                            statusCode = Constants.arrivedAtPickupKey;
                            shipmentStatusValue = Constants.pickedupKey;
                            break;
                        case 3:
                            statusCode = Constants.pickedupKey;
                            shipmentStatusValue = Constants.enRoutekey;
                            //isAllowUpdate = false;
                            break;
                        case 4:
                            statusCode = Constants.enRoutekey;
                            shipmentStatusValue = Constants.arrivedkey;
                            break;
                        case 5:
                            statusCode = Constants.arrivedkey;
                            shipmentStatusValue = Constants.completedkey;
                            isAllowUpdate = false;
                            break;
                        case 6:
                            statusCode = Constants.completedkey;
                            shipmentStatusValue = Constants.completedkey;
                            break;
                        default:
                            statusCode = Constants.completedkey;
                            shipmentStatusValue = trackingStatus[Constants.completedkey];
                            Toast.MakeText(this, Constants.shippingCompleted, ToastLength.Short).Show();
                            seekbarUpdateStatus.Enabled = false;
                            return;
                    }
                    if (status_Code == Constants.exceptionkey1 || status_Code == Constants.exceptionkey2 || status_Code == Constants.exceptionkey3
                        || status_Code == Constants.exceptionkey4 || status_Code == Constants.exceptionkey5)
                    {
                        Toast.MakeText(this, Constants.shippingCompletedWithException, ToastLength.Short).Show();
                        return;
                    }
                    if (carrierShipmentDetails.IsMultiStop && statuscount == 5)
                    {
                        DistanceConfimationAlert(statusCode, shipmentStatusValue);
                    }
                    else if (statusCode == Constants.inTransitkey)
                    {
                        DistanceConfimationAlert(statusCode, shipmentStatusValue);
                    }
                    else if (statusCode == Constants.completedkey)
                    {
                        DistanceConfimationAlert(statusCode, shipmentStatusValue);
                    }
                    else
                    {
                        await UpdateShipmentStatus(statusCode, shipmentStatusValue);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
            }
            finally
            {
                Alerts.HideBusyLoader();
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        async public Task<LatLng> GetDestinationLatLng()
        {
            var geo = new Geocoder(this);
            List<string> destinationAddress = null;
            destinationAddress = new List<string>();
            destinationAddress.Add(string.Format($"{carrierShipmentDetails.Addresses[carrierShipmentDetails.Addresses.Count - 2].Address1} {carrierShipmentDetails.Addresses[carrierShipmentDetails.Addresses.Count - 2].Address2} {carrierShipmentDetails.Addresses[carrierShipmentDetails.Addresses.Count - 2].City} {carrierShipmentDetails.Addresses[carrierShipmentDetails.Addresses.Count - 2].State} {carrierShipmentDetails.Addresses[carrierShipmentDetails.Addresses.Count - 2].Zip}"));

            var currentDestinationAddress = await geo.GetFromLocationNameAsync(destinationAddress[0], 1);

            currentDestinationAddress.ToList().ForEach((addr) =>
            {
                destinationLatLng = new LatLng(addr.Latitude, addr.Longitude);
            });
            return destinationLatLng;
        }
        /// <summary>
        /// Distance Confimation
        /// </summary>
        async void DistanceConfimationAlert(string code, string lblCode)
        {
            #region variableDeclaration
            List<string> stopAddress = null;

            string alertMsg = string.Empty;
            decimal distBtwSrcCurrent;
            var geo = new Geocoder(this);

            LatLng currentLatLong = new LatLng(0, 0)
            {
                Latitude = CommanUtil.currLat,
                Longitude = CommanUtil.currLong
            };
            #endregion

            if (carrierShipmentDetails.IsMultiStop)
            {
                if (Constants.stopCount == "SHIPTO")
                {
                    //alertMsg += Constants.strAwayFromDrop;
                    #region calculate distance from destination

                    distBtwSrcCurrent = GPSService.GetDistance(currentLatLong, await GetDestinationLatLng());

                    #endregion

                    if (Convert.ToDouble(distBtwSrcCurrent) <= Constants.distBtwSrcCurrent)
                    {
                        await UpdateShipmentStatus(code, lblCode);
                    }
                    else
                    {
                        alertMsg = Constants.strYouAre + distBtwSrcCurrent + Constants.mile;
                        alertMsg += Constants.strAwayFromDrop;
                        ConfirmationAlert(alertMsg, code, lblCode, true);
                    }

                }
                else if (statuscount == 5)
                {
                    foreach (var stops in carrierShipmentDetails.Addresses)
                    {
                        if (stops.Type == Constants.stopCount)
                        {
                            stopAddress = new List<string>();
                            stopAddress.Add(string.Format($"{stops.Address1} {stops.Address2} {stops.City} {stops.State} {stops.Zip}"));

                            var currentstopAddress = await geo.GetFromLocationNameAsync(stopAddress[0], 1);

                            currentstopAddress.ToList().ForEach((addr) =>
                            {
                                latLngStop = new LatLng(addr.Latitude, addr.Longitude);
                            });

                        }
                    }
                    alertMsg = string.Empty;
                    distBtwSrcCurrent = GPSService.GetDistance(currentLatLong, latLngStop);

                    if (Convert.ToDouble(distBtwSrcCurrent) <= Constants.distBtwSrcCurrent)
                    {
                        await UpdateShipmentStatus(code, lblCode);
                    }
                    else
                    {
                        alertMsg = Constants.strYouAre + distBtwSrcCurrent + Constants.mile;
                        alertMsg += string.Format(Constants.strAwayFromStop, Constants.stopCount);
                        ConfirmationAlert(alertMsg, code, lblCode, true);
                    }
                }
                else
                {
                    distBtwSrcCurrent = GPSService.GetDistance(currentLatLong, latLngSource);

                    if (Convert.ToDouble(distBtwSrcCurrent) <= Constants.distBtwSrcCurrent)
                    {
                        await UpdateShipmentStatus(code, lblCode);
                    }
                    else
                    {
                        alertMsg = Constants.strYouAre + distBtwSrcCurrent + Constants.mile;
                        alertMsg += Constants.strAwayFromPickup;
                        ConfirmationAlert(alertMsg, code, lblCode, true);
                    }
                }

            }
            else
            {

                if (code == Constants.completedkey)
                {
                    distBtwSrcCurrent = GPSService.GetDistance(currentLatLong, await GetDestinationLatLng());
                    alertMsg = Constants.strYouAre + distBtwSrcCurrent + Constants.mile;
                    alertMsg += Constants.strAwayFromDrop;
                    if (Convert.ToDouble(distBtwSrcCurrent) <= Constants.distBtwSrcCurrent)
                    {
                        await UpdateShipmentStatus(code, lblCode);
                    }
                    else
                    {
                        ConfirmationAlert(alertMsg, code, lblCode, true);
                    }
                }
                else
                {
                    distBtwSrcCurrent = GPSService.GetDistance(currentLatLong, latLngSource);
                    alertMsg = Constants.strYouAre + distBtwSrcCurrent + Constants.mile;
                    if (Convert.ToDouble(distBtwSrcCurrent) <= Constants.distBtwSrcCurrent)
                    {
                        await UpdateShipmentStatus(code, lblCode);
                    }
                    else
                    {
                        alertMsg += Constants.strAwayFromPickup;
                        ConfirmationAlert(alertMsg, code, lblCode, true);
                    }
                }
            }
        }

        /// <summary>
        /// UpdateShipmentStatus in Node API also in RateLinx API
        /// </summary>
        /// <returns></returns>
        private async Task UpdateShipmentStatus(string code, string lblCode)
        {
            try
            {
                #region UpdateShipmentStatus real time status of shipment
                Alerts.showBusyLoader(this);
                CommanUtil.isTrackingEnable = true;
                string statusResult = string.Empty;
                UpdateRealTimeStatus updateRealTimeStatus = new UpdateRealTimeStatus
                {
                    driverID = driverID,
                    bolNum = txtBolNumber.Text
                };
                if (CommanUtil.currLat == 0)
                {
                    updateRealTimeStatus.lat = Convert.ToString(latLngSource.Latitude);
                    updateRealTimeStatus.Long = Convert.ToString(latLngSource.Longitude);
                }
                else
                {
                    updateRealTimeStatus.lat = Convert.ToString(CommanUtil.currLat);
                    updateRealTimeStatus.Long = Convert.ToString(CommanUtil.currLong);
                }
                updateRealTimeStatus.status = code;
                updateRealTimeStatus.clientID = clientID;
                updateRealTimeStatus.ShipConfReason = ShipConfReason;
                updateRealTimeStatus.Msg = StatusMsg;
                if (carrierShipmentDetails.IsMultiStop)
                {
                    updateRealTimeStatus.ISMultistop = true;
                    updateRealTimeStatus.MultistopCode = code;
                }
                else
                {
                    updateRealTimeStatus.ISMultistop = false;
                    updateRealTimeStatus.MultistopCode = "";
                }
                if (carrierShipmentDetails.DispatchFlag)
                {
                    statusResult = await Utility.UpdateRealTimeStatus(updateRealTimeStatus);
                }
                else
                {
                    statusResult = "Non-Dispatch";
                }


                shipmentExceptionStatus = statusResult;
                if (!string.IsNullOrEmpty(statusResult))
                {
                    if (code == Constants.inTransitkey)
                    {
                        Utility.sharedPreferences.Edit().PutString(Constants.Client_Id + "/" + Constants.BolNO, DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")).Commit();
                    }
                    string shipmentStatus = string.Empty;
                    string statusCode = string.Empty;
                    if (code == Constants.exceptionkey)
                    {
                        shipmentStatus = lblCode;
                        statusCode = code;
                    }
                    else
                    {
                        shipmentStatus = trackingStatus[code];
                    }

                    string result = await UpdateShipmentTrackingStatus(code, shipmentStatus);//Update status of shipment in RatleLinx-SC2 Tracking API
                    if (!string.IsNullOrEmpty(result))
                    {
                        Alerts.HideBusyLoader();
                        await GetShipmentDetails();
                        if (carrierShipmentDetails.IsMultiStop)
                        {
                            if (code == Constants.exceptionkey1 || code == Constants.exceptionkey2 || code == Constants.exceptionkey3 ||
                                code == Constants.exceptionkey4 || code == Constants.exceptionkey5)
                            {
                                statuscount = 7;
                                statusCode = code;
                                txtCurrentStatus.Text = shipmentStatus;
                                liveStatusText = Constants.strCompletedDeliveryText;
                                liveStatusCode = code;
                                imgException.Visibility = ViewStates.Gone;
                                lnrUpdateStatus.Visibility = ViewStates.Gone;
                                if (manager != null)
                                {
                                    manager.CancelAll();
                                }
                                Constants.isEnrouteToDelivery = false;
                                Constants.isEnroute = false;
                            }
                            else
                            {

                                multiStopTracking();
                            }
                        }
                        else
                        {
                            if (code == Constants.exceptionkey1 || code == Constants.exceptionkey2 || code == Constants.exceptionkey3 ||
                                code == Constants.exceptionkey4 || code == Constants.exceptionkey5)
                            {
                                statuscount = 7;
                                statusCode = code;
                                Constants.isEnroute = false;
                                txtCurrentStatus.Text = shipmentStatus;
                                imgException.Visibility = ViewStates.Gone;
                                lnrUpdateStatus.Visibility = ViewStates.Gone;
                                liveStatusCode = code;
                                if (manager != null)
                                {
                                    manager.CancelAll();
                                }
                                Constants.isEnrouteToDelivery = false;
                            }

                            else
                            {
                                statusCode = code;
                                shipmentStatusValue = trackingStatus[code];
                                txtCurrentStatus.Text = trackingStatus[code];
                                txtViewUpdatedStatus.Text = trackingStatus[lblCode];
                                liveStatusCode = code;
                                liveStatusText = trackingStatus[lblCode];
                                if (txtCurrentStatus.Text != Constants.enrouteToDelivery)
                                {
                                    if (manager != null)
                                    {
                                        manager.CancelAll();
                                    }

                                    Constants.isEnrouteToDelivery = false;
                                }
                                else
                                {
                                    Constants.isEnrouteToDelivery = true;
                                }
                                if (trackingStatus[code] == Constants.strCompletedDeliveryText)
                                {
                                    lnrUpdateStatus.Visibility = ViewStates.Gone;
                                    imgException.Visibility = ViewStates.Gone;
                                    Constants.isEnroute = false;
                                }
                            }
                        }
                    }
                    else
                    {
                        //Post Error Logger Request 
                        Utility.ErrorLog(Constants.shipmentDetail, Constants.updateShipmentStatus, CommanUtil.tokenNo, this);
                        statuscount -= 1;
                    }
                }
                else
                {
                    statuscount -= 1;
                }
                Alerts.HideBusyLoader();
                if ((statusCode == Constants.exceptionkey1
                    || statusCode == Constants.exceptionkey2
                    || statusCode == Constants.exceptionkey3
                    || statusCode == Constants.exceptionkey4
                    || statusCode == Constants.exceptionkey5)
                    && statusResult == Constants.strOK)
                {
                    Toast.MakeText(this, Constants.strStatusUpdated, ToastLength.Long).Show();
                }
                else
                {
                    Toast.MakeText(this, Constants.strStatusUpdated, ToastLength.Long).Show();
                }
                if (!carrierShipmentDetails.IsMultiStop)
                {
                    //await GetShipmentDetails();
                    await IsTrackingEnableAsync();
                }
                #endregion
                if (isTimerStarted == true)
                {
                    isTimerStarted = false;
                    await StartTimer();
                }
            }
            catch (Exception ex)
            {
                Alerts.HideBusyLoader();
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
            }

        }

        /// <summary>
        /// Confirmation Alert
        /// </summary>
        /// <param name="confirmationMsg"></param>
        /// <param name="code"></param>
        /// <param name="lblCode"></param>
        /// <param name="isAllowUpdate"></param>
        public void ConfirmationAlert(string confirmationMsg, string code, string lblCode, bool isAllowUpdate)
        {
            try
            {
                objUtility = new Utility();
                string dialogHeader = Constants.strConfirm;
                Dialog dialog;
                if (code == Constants.completedkey)
                {
                    dialog = objUtility.GetDialog(this, dialogHeader, confirmationMsg,
                Constants.btnTextYes, Constants.btnTextNo, "Enter Reason",
                ViewStates.Visible, ViewStates.Visible, ViewStates.Visible,
                ViewStates.Visible, ViewStates.Visible, ViewStates.Gone);
                }
                else
                {
                    dialog = objUtility.GetDialog(this, dialogHeader, confirmationMsg,
                   Constants.btnTextYes, Constants.btnTextNo, string.Empty,
                   ViewStates.Gone, ViewStates.Visible, ViewStates.Visible,
                   ViewStates.Visible, ViewStates.Visible, ViewStates.Gone);
                }
                EditText txtEnterReason = dialog.FindViewById<EditText>(Resource.Id.txtEnterReason);
                Button btnConfirm = dialog.FindViewById<Button>(Resource.Id.btnYes);
                Button btnCancel = dialog.FindViewById<Button>(Resource.Id.btnNo);

                TextView txtViewClose = dialog.FindViewById<TextView>(Resource.Id.txtViewClose);
                btnConfirm.Click += async delegate
                {
                    if (string.IsNullOrEmpty(txtEnterReason.Text) && code == Constants.completedkey)
                    {
                        Toast.MakeText(this, "Please Enter Reason", ToastLength.Long).Show();
                        statuscount -= 1;
                    }
                    else
                    {
                        if (isAllowUpdate)
                        {
                            dialog.Hide();
                            ShipConfReason = txtEnterReason.Text;
                            await UpdateShipmentStatus(code, lblCode);
                        }
                        else
                        {
                            DistanceConfimationAlert(code, lblCode);
                        }
                    }
                    dialog.Hide();
                };
                txtViewClose.Click += delegate
                {
                    statuscount -= 1;
                    dialog.Hide();
                    return;
                };
                btnCancel.Click += delegate
                {
                    statuscount -= 1;
                    dialog.Hide();
                    return;
                };
                objUtility = null;
            }
            catch
            {
                //throw;
            }
        }

        /// <summary>
        /// Check is GPS connected 
        /// </summary>
        public bool ISGPSConnected()
        {
            try
            {
                LocationManager manager = (LocationManager)this.GetSystemService(Context.LocationService);
                if (!manager.IsProviderEnabled(LocationManager.GpsProvider))
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// On Map ready
        /// </summary>
        /// <param name="googleMap"></param>
        public async Task FnplotMap(GoogleMap googleMap)
        {
            try
            {
                Alerts.showBusyLoader(this);
                this.map = googleMap;
                Constants.showSourceMarker = true;
                //Get Lat Long 
                var i = 0;
                bool result = false;
                for (i = 0; i <= shipmentAddress.Count - 2; i++)
                {
                    result = await FnLocationToLatLng(shipmentAddress[i], shipmentAddress[i + 1]);
                    if (result)
                    {
                        //Set Camera Position

                        if (latLngSource != null && latLngDestination != null)
                        {
                            if (i == shipmentAddress.Count - 2)
                            {
                                Constants.showDestinationMarker = true;
                            }
                            await FnDrawPathAsync(shipmentAddress[i], shipmentAddress[i + 1]);
                        }
                        Alerts.HideBusyLoader();
                    }
                    else
                    {
                        Alerts.HideBusyLoader();
                        Toast.MakeText(this, Constants.strLocation, ToastLength.Long).Show();
                    }
                    //}

                }
                if (latLngSource != null)
                {
                    FnUpdateCameraPosition(latLngSource);
                }
                if (carrierShipmentDetails != null)
                {

                    if (carrierShipmentDetails.IsMultiStop)
                    {
                        txtStopCount.Text = carrierShipmentDetails.Addresses.Count - 2 + " Stops";
                        multiStopTracking();
                    }
                    else
                    {
                        txtStopCount.Visibility = ViewStates.Gone;
                        await IsTrackingEnableAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                Alerts.HideBusyLoader();
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
            }
            finally
            {
                Alerts.HideBusyLoader();
            }
        }

        /// <summary>
        /// FnDrawPathAsync of origin and source
        /// </summary>
        /// <param name="strSource"></param>
        /// <param name="strDestination"></param>
        /// <returns></returns>
        async Task FnDrawPathAsync(string strSource, string strDestination)
        {
            try
            {
                string strFullDirectionURL = string.Format(Constants.strGoogleDirectionUrl, strSource, strDestination);
                string strJSONDirectionResponse = await FnHttpRequest(strFullDirectionURL);
                if (strJSONDirectionResponse != Constants.strException)
                {
                    RunOnUiThread(() =>
                    {
                        if (map != null)
                        {
                            if (Constants.showSourceMarker)
                            {
                                MarkOnMap(/*Constants.strTextSource*/"Origin", strSource, latLngSource, Resource.Drawable.MarkerSource);
                                if (shipmentAddress.Count > 2)
                                {
                                    Constants.showSourceMarker = false;
                                }
                            }
                            if (Constants.showDestinationMarker)
                            {
                                MarkOnMap(Constants.strTextDestination, strDestination, latLngDestination, Resource.Drawable.MarkerDest);
                                Constants.showDestinationMarker = false;
                            }
                            else
                            {
                                Constants.stopIncrement += 1;
                                MarkOnMap("Stop" + Constants.stopIncrement, strDestination, latLngDestination, Resource.Drawable.imgstop);
                            }
                        }
                    });
                    FnSetDirectionQuery(strJSONDirectionResponse, false);
                }
                else
                {

                    Toast.MakeText(this, Constants.strUnableToConnect, ToastLength.Short).Show();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Get the response of pubnub and draw on map
        /// </summary>
        /// <param name="objShipmentStatus"></param>
        public void GetDirectionResponseAsync(ShipmentStatus objShipmentStatus)
        {
            try
            {
                LatLng currentLatLang = new LatLng(Convert.ToDouble(objShipmentStatus.CurrentLat), Convert.ToDouble(objShipmentStatus.CurrentLong));
                // string currentLoc = string.Empty;
                if (map != null && currentLatLang.Latitude != 0.0)
                {
                    RunOnUiThread(() =>
                    {
                        try
                        {
                            if (lastSecodLatLong == null)
                            {
                                lastSecodLatLong = currentLatLang;
                            }
                            float bearing = GPSService.bearingBetweenLocations(lastSecodLatLong, currentLatLang);
                            if (float.IsNaN(bearing) || bearing == 0)
                            {
                                bearing = 180;
                            }
                            else
                            {
                                if (objMarker != null)
                                {
                                    CommanUtil.isAccuracyFine = false;
                                    AnimateMarker(objMarker, currentLatLang, bearing);
                                }
                                else
                                {
                                    MarkerOptions options = new MarkerOptions()
                                             .SetPosition(currentLatLang)
                                             .SetTitle(objShipmentStatus.CurrentLocation)
                                             .Flat(true)
                                             .Anchor(0.5f, 0.5f)
                                             .SetIcon(BitmapDescriptorFactory.FromResource(Resource.Drawable.CarTopView2));
                                    objMarker = map.AddMarker(options);
                                }
                                txtmiles.Text = objShipmentStatus.DistanceTravelled + Helper.Constants.mile;
                                CameraPosition.Builder builder = CameraPosition.InvokeBuilder();
                                builder.Target(currentLatLang); // Sets the center of the map to Mountain View
                                builder.Zoom(currentZoomLevel);// Sets the zoom                                                              
                                cameraPosition = builder.Build();
                                cameraUpdate = CameraUpdateFactory.NewCameraPosition(cameraPosition);
                                if (isAnimate == true)
                                {
                                    map.AnimateCamera(cameraUpdate);
                                }
                                //Assign Old Latitude and Longitude
                                lastSecodLatLong = currentLatLang;
                            }
                        }
                        catch
                        {
                            throw;
                        }
                    });
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// AnimateMarker
        /// </summary>
        /// <param name="marker"></param>
        /// <param name="toPosition"></param>
        /// <param name="rotation"></param>
        public void AnimateMarker(Marker marker, LatLng toPosition, float rotation)
        {
            try
            {
                Handler handler = new Handler();
                long start = SystemClock.UptimeMillis();
                Projection proj = map.Projection;
                Point startPoint = proj.ToScreenLocation(marker.Position);
                LatLng startLatLng = proj.FromScreenLocation(startPoint);
                long duration = 600;
                LinearInterpolator interpolator = new LinearInterpolator();

                handler.Post(Run);
                void Run()
                {

                    long elapsed = SystemClock.UptimeMillis() - start;
                    float t = interpolator.GetInterpolation((float)elapsed
                             / duration);
                    double lng = t * toPosition.Longitude + (1 - t)
                            * startLatLng.Longitude;
                    double lat = t * toPosition.Latitude + (1 - t)
                            * startLatLng.Latitude;
                    RunOnUiThread(() =>
                    {
                        try
                        {
                            marker.Position = new LatLng(lat, lng);
                            marker.Rotation = rotation;
                            marker.SetAnchor(0.5f, 0.5f);
                            marker.SetIcon(BitmapDescriptorFactory.FromResource(Resource.Drawable.CarTopView2));
                        }
                        catch
                        {
                            MarkerOptions options = new MarkerOptions()
                                    .SetPosition(new LatLng(lat, lng))
                                    .SetRotation(rotation)
                                    .Flat(true)
                                    .Anchor(0.5f, 0.5f)
                                    .SetIcon(BitmapDescriptorFactory.FromResource(Resource.Drawable.CarTopView2));
                            objMarker = map.AddMarker(options);
                        }
                    });
                    if (t < 1.0)
                    {
                        // Post again 16ms later.
                        handler.PostDelayed(Run, 16);
                        // Task.Delay(1);
                    }
                    else
                    {
                        if (polylineoption == null)
                        {
                            polylineoption = new PolylineOptions();
                            polylineoption.InvokeColor(Color.Black);
                            polylineoption.Geodesic(true);
                            polylineoption.InvokeWidth(4);

                        }
                        polylineoption.Add(lastSecodLatLong, new LatLng(lat, lng));
                        map.AddPolyline(polylineoption);
                    }

                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// RunTimer of driver while driving vehicle
        /// </summary>
        /// <returns></returns>
        public string RunTimer(string previousTime)
        {
            try
            {
                if (!string.IsNullOrEmpty(previousTime))
                {
                    string[] strTimer = previousTime.Split(':');
                    seconds = Convert.ToInt32(strTimer[2]);
                    minutes = Convert.ToInt32(strTimer[1]);
                    hours = Convert.ToInt32(strTimer[0]);
                }
                string result = string.Empty;
                string secs = string.Empty;
                string mins = string.Empty;
                string hrs = string.Empty;
                if (seconds <= 59)
                {
                    seconds++;
                }
                if (seconds == 60)
                {
                    seconds = 00;
                    if (minutes <= 59)
                    {
                        minutes++;
                    }
                    if (minutes == 60)
                    {
                        minutes = 00;
                        hours++;
                    }
                }
                if (seconds >= 0 && seconds <= 9)
                {
                    secs = "0" + Convert.ToString(seconds);
                }
                else
                {
                    if (Convert.ToString(seconds) == "60")
                    {
                        secs = "00";
                    }
                    else
                    {
                        secs = Convert.ToString(seconds);
                    }
                }

                if (minutes >= 0 && minutes <= 9)
                {
                    mins = "0" + Convert.ToString(minutes);
                }
                else
                {
                    if (Convert.ToString(minutes) == "60")
                    {
                        mins = "00";
                        minutes = 00;
                    }
                    else
                    {
                        mins = Convert.ToString(minutes);
                    }

                }
                if (hours >= 0 && hours <= 9)
                {
                    hrs = "0" + Convert.ToString(hours);
                }
                else
                {
                    if (Convert.ToString(hours) == "60")
                    {
                        hrs = "00";
                    }
                    else
                    {
                        hrs = Convert.ToString(hours);
                    }
                }
                return result = hrs + " : " + mins + " : " + secs;
            }
            catch
            {
                return "00";
            }

        }


        /// <summary>
        /// FnSetDirectionQuery
        /// </summary>
        /// <param name="strJSONDirectionResponse"></param>
        /// <param name="isCalculate"></param>
        private void FnSetDirectionQuery(string strJSONDirectionResponse, bool isCalculate = true)
        {
            try
            {
                var objRoutes = JsonConvert.DeserializeObject<GoogleDirectionClass>(strJSONDirectionResponse);
                //objRoutes.routes.Count  --may be more then one 
                if (objRoutes.routes.Count > 0)
                {
                    if (isCalculate)
                    {
                        totalDistance = GPSService.CalculateDistance(objRoutes); //Get Distance
                    }
                    else
                    {
                        string encodedPoints = objRoutes.routes[0].overview_polyline.points;
                        var lstDecodedPoints = FnDecodePolylinePoints(encodedPoints);
                        //convert list of location point to array of latlng type
                        var latLngPoints = new LatLng[lstDecodedPoints.Count];
                        int index = 0;
                        foreach (GoogleServices.Location loc in lstDecodedPoints)
                        {
                            latLngPoints[index++] = new LatLng(loc.lat, loc.lng);
                        }
                        var polylineoption = new PolylineOptions();
                        polylineoption.InvokeColor(Color.Red);
                        polylineoption.Geodesic(true);
                        polylineoption.InvokeWidth(6);
                        polylineoption.Add(latLngPoints);
                        RunOnUiThread(() =>
                        {
                            map.AddPolyline(polylineoption);
                        });
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// FnDecodePolylinePoints
        /// </summary>
        /// <param name="encodedPoints"></param>
        /// <returns></returns>
        List<GoogleServices.Location> FnDecodePolylinePoints(string encodedPoints)
        {
            if (string.IsNullOrEmpty(encodedPoints))
                return null;
            var poly = new List<GoogleServices.Location>();
            char[] polylinechars = encodedPoints.ToCharArray();
            int index = 0;
            int currentLat = 0;
            int currentLng = 0;
            int next5bits;
            int sum;
            int shifter;
            try
            {
                while (index < polylinechars.Length)
                {
                    // calculate next latitude
                    sum = 0;
                    shifter = 0;
                    do
                    {
                        next5bits = (int)polylinechars[index++] - 63;
                        sum |= (next5bits & 31) << shifter;
                        shifter += 5;
                    } while (next5bits >= 32 && index < polylinechars.Length);

                    if (index >= polylinechars.Length)
                        break;

                    currentLat += (sum & 1) == 1 ? ~(sum >> 1) : (sum >> 1);

                    //calculate next longitude
                    sum = 0;
                    shifter = 0;
                    do
                    {
                        next5bits = (int)polylinechars[index++] - 63;
                        sum |= (next5bits & 31) << shifter;
                        shifter += 5;
                    } while (next5bits >= 32 && index < polylinechars.Length);

                    if (index >= polylinechars.Length && next5bits >= 32)
                        break;

                    currentLng += (sum & 1) == 1 ? ~(sum >> 1) : (sum >> 1);
                    GoogleServices.Location p = new GoogleServices.Location();
                    p.lat = Convert.ToDouble(currentLat) / 100000.0;
                    p.lng = Convert.ToDouble(currentLng) / 100000.0;
                    poly.Add(p);
                }
                return poly;
            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// FnUpdateCameraPosition
        /// </summary>
        /// <param name="pos"></param>
        async private void FnUpdateCameraPosition(LatLng pos)
        {
            try
            {
                var geo = new Geocoder(this);
                #region Enable UI Settings for map for map
                map.UiSettings.MyLocationButtonEnabled = true;
                map.MyLocationEnabled = true;
                map.UiSettings.RotateGesturesEnabled = true;
                map.UiSettings.ZoomGesturesEnabled = true;
                #endregion

                double PickUpCenterlat = (Convert.ToDouble(latLngSource.Latitude) + Convert.ToDouble(latLngDestination.Latitude)) / 2;
                double PickUpCenterlong = (Convert.ToDouble(latLngSource.Longitude) + Convert.ToDouble(latLngDestination.Longitude)) / 2;

                LatLng Centerlatlong = new LatLng(PickUpCenterlat, PickUpCenterlong);

                LatLng latlngPU;
                LatLng latlngDO;
                LatLngBounds.Builder builder1 = new LatLngBounds.Builder();

                latlngPU = new LatLng(Convert.ToDouble(latLngSource.Latitude), Convert.ToDouble(latLngSource.Longitude));
                latlngDO = new LatLng(Convert.ToDouble(latLngDestination.Latitude), Convert.ToDouble(latLngDestination.Longitude));
                List<LatLng> markers = new List<LatLng>();
                foreach (var stops in carrierShipmentDetails.Addresses)
                {
                    List<string> stopAddress = new List<string>();
                    stopAddress.Add(string.Format($"{stops.Address1} {stops.Address2} {stops.City} {stops.State} {stops.Zip}"));

                    var currentstopAddress = await geo.GetFromLocationNameAsync(stopAddress[0], 1);

                    currentstopAddress.ToList().ForEach((addr) =>
                    {
                        latLngStop = new LatLng(addr.Latitude, addr.Longitude);
                    });

                    markers.Add(latLngStop);
                }
                markers.Add(latlngPU);
                markers.Add(latlngDO);

                foreach (LatLng item in markers)
                {
                    builder1.Include(item);
                }

                var metrics = Resources.DisplayMetrics;

                int height = metrics.HeightPixels;
                int width = metrics.WidthPixels;
                int padding = (int)(width * 0.20); // offset from edges of the map 10% of screen

                LatLngBounds bounds = builder1.Build();
                map.AnimateCamera(CameraUpdateFactory.NewLatLngBounds(bounds, padding));
                //Camera change listener to manage the map zoom level
                map.CameraChange += delegate (object sender, GoogleMap.CameraChangeEventArgs e)
                {
                    if ((int)e.Position.Zoom != (int)currentZoomLevel)
                    {
                        currentZoomLevel = e.Position.Zoom;
                        isAnimate = false;
                    }
                };
                map.MyLocationButtonClick += Map_MyLocationButtonClick;
            }
            catch
            {

            }
        }
        /// <summary>
        /// Check whether the login device is tablet or not
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public static bool IsTablet(Context context)
        {
            Display display = ((Activity)context).WindowManager.DefaultDisplay;
            Android.Util.DisplayMetrics displayMetrics = new Android.Util.DisplayMetrics();
            display.GetMetrics(displayMetrics);

            var wInches = displayMetrics.WidthPixels / (double)displayMetrics.DensityDpi;
            var hInches = displayMetrics.HeightPixels / (double)displayMetrics.DensityDpi;

            double screenDiagonal = Math.Sqrt(Math.Pow(wInches, 2) + Math.Pow(hInches, 2));
            return (screenDiagonal >= 7.0);
        }

        /// <summary>
        /// Map_MyLocationButtonClick
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Map_MyLocationButtonClick(object sender, GoogleMap.MyLocationButtonClickEventArgs e)
        {
            isAnimate = true;
        }

        /// <summary>
        /// FnLocationToLatLng to get the lat and log of origin and source
        /// </summary>
        /// <param name="strSource"></param>
        /// <param name="strDestination"></param>
        /// <returns></returns>
        async Task<bool> FnLocationToLatLng(string strSource, string strDestination)
        {
            try
            {
                var geo = new Geocoder(this);
                var sourceAddress = await geo.GetFromLocationNameAsync(strSource, 1);
                if (sourceAddress != null)
                {
                    sourceAddress.ToList().ForEach((addr) =>
                    {
                        latLngSource = new LatLng(addr.Latitude, addr.Longitude);
                    });
                    var destAddress = await geo.GetFromLocationNameAsync(strDestination, 1);
                    if (destAddress != null)
                    {
                        destAddress.ToList().ForEach((addr) =>
                        {
                            latLngDestination = new LatLng(addr.Latitude, addr.Longitude);
                        });
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// MarkOnMap of source and destination
        /// </summary>
        /// <param name="title"></param>
        /// <param name="address"></param>
        /// <param name="pos"></param>
        /// <param name="resourceId"></param>
        private void MarkOnMap(string title, string address, LatLng pos, int resourceId)
        {

            RunOnUiThread(() =>
            {
                try
                {
                    var marker = new MarkerOptions();
                    marker.SetTitle(title);
                    marker.SetPosition(pos); //Resource.Drawable.BlueDot
                    marker.SetSnippet(address);
                    marker.SetIcon(BitmapDescriptorFactory.FromResource(resourceId));
                    map.AddMarker(marker);
                }
                catch
                {
                    throw;
                }
            });
        }


        /// <summary>
        /// Publish Data to pubnub
        /// </summary>
        /// <param name="latLong"></param>
        /// <param name="isLocationEnable"></param>
        public void Publish(string latLong, bool isLocationEnable)
        {
            try
            {
                #region Check internet and GPS connectivity
                if (!Utility.FnIsOnline(this))
                {
                    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                if (!isLocationEnable)
                {
                    Toast.MakeText(this, Constants.strLocation, ToastLength.Short).Show();
                    return;
                }
                #endregion
                if (!string.IsNullOrEmpty(liveStatusCode))
                {
                    if (liveStatusCode != Constants.completedkey && isPublishEnable)
                    {
                        PublishShipmentStatus(latLong);
                    }
                    else
                    {
                        if (liveStatusCode == Constants.completedkey && isPublishEnable)
                        {
                            PublishShipmentStatus(latLong);
                            ResetTracking();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                // Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// PublishShipmentStatus
        /// </summary>
        /// <param name="latLong"></param>
        public void PublishShipmentStatus(string latLong)
        {
            try
            {
                #region Assigning Data in model properties 
                LatLng previousLatLong = new LatLng(0, 0);
                decimal previousDistance = 0;
                string previousTime = string.Empty;
                decimal currentDistance = 0;
                string shipmentStatusRes = Utility.sharedPreferences.GetString(clientID + txtBolNumber.Text.Trim(), null);
                if (!string.IsNullOrEmpty(shipmentStatusRes))
                {
                    ShipmentStatus objShipmentStatusResponse = JsonConvert.DeserializeObject<ShipmentStatus>(shipmentStatusRes);
                    previousLatLong = new LatLng(Convert.ToDouble(objShipmentStatusResponse.CurrentLat)
                        , Convert.ToDouble(objShipmentStatusResponse.CurrentLong));
                    previousDistance = objShipmentStatusResponse.DistanceTravelled;
                    previousTime = objShipmentStatusResponse.TimeTaken;
                }
                else
                {
                    previousLatLong = latLngSource;
                    previousDistance = 0;
                }
                ShipmentStatus objShipmentStatus = new ShipmentStatus();
                GPSService objGPSService = new GPSService(this);
                LatLng currentLatLong = new LatLng(Convert.ToDouble(latLong.Split(',')[0]), Convert.ToDouble(latLong.Split(',')[1]));
                //LatLng currentLatLong = new LatLng(CommanUtil.currLat, CommanUtil.currLong);
                if (currentLatLong.Latitude == 0.0 && currentLatLong.Longitude == 0.0)
                {
                    currentLatLong = previousLatLong;
                }
                currentDistance = previousDistance + GPSService.GetDistance(previousLatLong, currentLatLong);
                //objShipmentStatus.TimeTaken = RunTimer(previousTime);
                objShipmentStatus.CurrentLocation = objGPSService.GetCurrentAddress(currentLatLong);
                objShipmentStatus.CurrentLat = Convert.ToString(currentLatLong.Latitude);
                objShipmentStatus.CurrentLong = Convert.ToString(currentLatLong.Longitude);
                objShipmentStatus.DistanceTravelled = currentDistance;
                objShipmentStatus.DistanceLeft = Convert.ToDecimal(totalDistance - currentDistance);
                objShipmentStatus.ShipmentCurrStatus = liveStatusText;
                objShipmentStatus.BolNo = txtBolNumber.Text.Trim();
                objShipmentStatus.DriverID = string.IsNullOrEmpty(driverID) ? clientID : driverID;
                Constants.Client_Id = objShipmentStatus.DriverID;
                Constants.BolNO = objShipmentStatus.BolNo;
                string appClosedTime = Utility.sharedPreferences.GetString(objShipmentStatus.DriverID + "/" + objShipmentStatus.BolNo, null);
                var timeDiff = string.Empty;
                int loginTime = 0;
                if (!string.IsNullOrEmpty(appClosedTime))
                {
                    var date = appClosedTime;
                    IFormatProvider culture = new CultureInfo("en-US", true);
                    var dateOne = DateTime.ParseExact(date, Constants.dateFormatDDMMYYYYHHMMSS, culture);
                    DateTime dateTwo = DateTime.Now;
                    TimeSpan diff = dateTwo.Subtract(dateOne);


                    timeDiff = String.Format("{0}:{1}:{2}", diff.Hours, diff.Minutes, diff.Seconds);
                    loginTime = diff.Minutes;
                }
                if (loginTime >= 5)
                {
                    //SendNotification(loginTime);
                }
                objShipmentStatus.TimeTaken = timeDiff;
                Utility.sharedPreferences.Edit().PutString(clientID + txtBolNumber.Text.Trim(), JsonConvert.SerializeObject(objShipmentStatus)).Commit();

                #endregion
                #region Publish Data in pubNub
                ThreadPool.QueueUserWorkItem(o =>
                     pubnub.Publish()
                     .Channel(clientID + txtBolNumber.Text.Trim())
                    .Message(objShipmentStatus)
                     .ShouldStore(true)
                     .Async(new DemoPublishResult(Display))
                );
                #endregion
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Function to start timer functionality
        /// </summary>
        public async Task StartTimer()
        {
            string time = "00:00:00";
            string timeDiff = string.Empty;
            string newTime = string.Empty;
            DateTime completedTime = new DateTime();
            DateTime currentTime = new DateTime();
            TimeSpan timeSpan = new TimeSpan();
            try
            {

                if (!string.IsNullOrEmpty(Constants.shipStartTime))
                {
                    IFormatProvider culture = new CultureInfo("en-US", true);
                    DateTime shipStartTime = new DateTime();
                    shipStartTime = Convert.ToDateTime(Constants.shipStartTime, culture);

                    if (txtCurrentStatus.Text == Constants.strCompletedDeliveryText || txtCurrentStatus.Text == Constants.strCompletedDeliveryText2 || txtCurrentStatus.Text == trackingStatus[Constants.exceptionkey1] || txtCurrentStatus.Text == trackingStatus[Constants.exceptionkey2] || txtCurrentStatus.Text == trackingStatus[Constants.exceptionkey3] || txtCurrentStatus.Text == trackingStatus[Constants.exceptionkey4] || txtCurrentStatus.Text == trackingStatus[Constants.exceptionkey5])
                    {
                        var shipCompletedTime = carrierShipmentDetails.TrackDetails.Where(m => m.ActivityDescr == Constants.strCompletedDeliveryText || m.ActivityDescr == Constants.strCompletedDeliveryText2 || m.ActivityDescr == "Delivery").Select(m => m.Activity).FirstOrDefault();
                        completedTime = Convert.ToDateTime(shipCompletedTime, culture);

                        timeSpan = completedTime.Subtract(shipStartTime);
                    }
                    else
                    {
                        currentTime = DateTime.Now;
                        timeSpan = currentTime.Subtract(shipStartTime);
                    }

                    timeDiff = String.Format("{0}:{1}:{2}", timeSpan.Hours, timeSpan.Minutes, timeSpan.Seconds);
                    if (txtCurrentStatus.Text == Constants.strCompletedDeliveryText || txtCurrentStatus.Text == Constants.strCompletedDeliveryText2 || txtCurrentStatus.Text == trackingStatus[Constants.exceptionkey1] || txtCurrentStatus.Text == trackingStatus[Constants.exceptionkey2] || txtCurrentStatus.Text == trackingStatus[Constants.exceptionkey3] || txtCurrentStatus.Text == trackingStatus[Constants.exceptionkey4] || txtCurrentStatus.Text == trackingStatus[Constants.exceptionkey5])
                    {
                        var newHrs = string.Empty;
                        var newMinutes = string.Empty;
                        var newSeconds = string.Empty;
                        if (timeSpan.Seconds >= 0 && timeSpan.Seconds <= 9)
                        {
                            newSeconds = "0" + Convert.ToString(timeSpan.Seconds);
                        }
                        else
                        {
                            newSeconds = timeSpan.Seconds.ToString();
                        }
                        if (timeSpan.Minutes >= 0 && timeSpan.Minutes <= 9)
                        {
                            newMinutes = "0" + Convert.ToString(timeSpan.Minutes);
                        }
                        else
                        {
                            newMinutes = timeSpan.Minutes.ToString();
                        }
                        if (timeSpan.Hours >= 0 && timeSpan.Hours <= 9)
                        {
                            newHrs = "0" + Convert.ToString(timeSpan.Hours);
                        }
                        else
                        {
                            newHrs = timeSpan.Hours.ToString();
                        }
                        txtTotalTime.Text = String.Format("{0}:{1}:{2}", newHrs, newMinutes, newSeconds);
                    }
                }
                while (Constants.isEnroute)
                {
                    RunOnUiThread(() =>
                    {
                        if (string.IsNullOrEmpty(Constants.shipStartTime))
                        {
                            newTime = RunTimer(time);
                        }
                        else
                        {
                            newTime = RunTimer(newTime);
                        }
                        if (!string.IsNullOrEmpty(timeDiff))
                        {
                            newTime = RunTimer(timeDiff);
                            timeDiff = string.Empty;
                        }
                        txtTotalTime.Text = newTime;
                    });
                    await Task.Delay(1000);
                }
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public int GetNotificationIcon()
        {
            Boolean useWhiteIcon = (10 >= 20);
            return useWhiteIcon ? Droid.Resource.Drawable.Icon : Droid.Resource.Drawable.Icon;
        }
        /// <summary>
        /// Rest tracking and unsubscribe  
        /// </summary>
        void ResetTracking()
        {
            try
            {
                Task.Delay(10000);
                CommanUtil.isTrackingEnable = false;
                isPublishEnable = false;
                Unsub(clientID + txtBolNumber.Text.Trim());
                //RemoveChannelFromChannelGroup(clientID + txtBolNumber.Text.Trim());
                Utility.sharedPreferences.Edit().Remove(clientID + txtBolNumber.Text.Trim()).Commit();
            }
            catch
            {
                throw;
            }
        }


        /// <summary>
        /// Method to bind Multiple stops
        /// </summary>
        public void multiStopTracking()
        {
            try
            {
                int stopCount = 1;

                if (carrierShipmentDetails.TrackDetails != null && carrierShipmentDetails.TrackDetails.Count > 0)
                {
                    if (txtCurrentStatus.Text == "Pickup")
                    {
                        statusCode = trackingStatus.Where(x => x.Value == carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 2].ActivityDescr).Select(x => x.Key).FirstOrDefault();
                        ShipmentActivity = statusCode;
                    }
                    else
                    {
                        foreach (var stop in carrierShipmentDetails.Addresses)
                        {
                            if (Convert.ToString(carrierShipmentDetails.Addresses[stopCount].CurrentStatus) != "Delivered")
                            {

                                string shipmentCurrentText = carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 1].ActivityDescr;
                                lstTrackingExceptionVal = CommanUtil.ExceptionDescList();
                                statusCode = lstTrackingExceptionVal.Where(x => x.text == shipmentCurrentText).Select(x => x.value).FirstOrDefault();
                                if (statusCode == Constants.exceptionkey1 || statusCode == Constants.exceptionkey2 || statusCode == Constants.exceptionkey3
                                    || statusCode == Constants.exceptionkey4 || statusCode == Constants.exceptionkey5)
                                {

                                    for (int trackDetailsCount = carrierShipmentDetails.TrackDetails.Count; trackDetailsCount > 0; trackDetailsCount--)
                                    {
                                        string trackInfo = carrierShipmentDetails.TrackDetails[trackDetailsCount - 1].ActivityDescr;
                                        if (!CommanUtil.ExceptionTextList.Contains(trackInfo))
                                        {
                                            status_Code = trackingStatus.Where(x => x.Value == carrierShipmentDetails.TrackDetails[trackDetailsCount - 1].ActivityDescr).Select(x => x.Key).FirstOrDefault();
                                            break;
                                        }
                                    }

                                    ShipmentActivity = status_Code;
                                    statusCode = status_Code;
                                    txtAddressTo.Text = string.Format($"{carrierShipmentDetails.Addresses[1].Address1} {carrierShipmentDetails.Addresses[1].Address2} {carrierShipmentDetails.Addresses[1].City} {carrierShipmentDetails.Addresses[1].State} {carrierShipmentDetails.Addresses[1].Zip}");
                                    txtAddressFrom.Text = string.Format($"{carrierShipmentDetails.Addresses[0].Address1} {carrierShipmentDetails.Addresses[0].Address2} {carrierShipmentDetails.Addresses[0].City} {carrierShipmentDetails.Addresses[0].State} {carrierShipmentDetails.Addresses[0].Zip}");
                                }

                                if (carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 1].ActivityDescr == Constants.strIntransit)
                                {
                                    statusCode = Constants.inTransitkey;
                                }
                                if (carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 1].ActivityDescr == Constants.enrouteToDeliveryLocation)
                                {
                                    statusCode = Constants.enRoutekey;
                                }
                                if (carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 1].ActivityDescr == Constants.strCarrierDeparted)
                                {
                                    statusCode = Constants.pickedupKey;
                                }
                                else
                                {
                                    if (statusCode == string.Empty || statusCode == null)
                                    {
                                        statusCode = trackingStatus.Where(x => x.Value == carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 1].ActivityDescr).Select(x => x.Key).FirstOrDefault();

                                    }
                                }

                                if (statusCode == Constants.arrivedkey)
                                {
                                    if (carrierShipmentDetails.Addresses[stopCount].Type == "BILLTO")
                                    {
                                        ShipmentActivity = Constants.completedkey;
                                    }
                                    else
                                    {
                                        statuscount = 3;
                                        ShipmentActivity = "enrouteToNextStop";
                                    }
                                }
                                else
                                {
                                    if (statusCode == null)
                                    {
                                        ShipmentActivity = string.Empty;
                                    }
                                    else
                                    {
                                        ShipmentActivity = statusCode;
                                    }
                                }
                                currentStop = carrierShipmentDetails.Addresses[stopCount].Type;
                                break;
                            }
                            else
                            {
                                stopCount += 1;
                            }
                            txtAddressTo.Text = string.Format($"{carrierShipmentDetails.Addresses[stopCount].Address1} {carrierShipmentDetails.Addresses[stopCount].Address2} {carrierShipmentDetails.Addresses[stopCount].City} {carrierShipmentDetails.Addresses[stopCount].State} {carrierShipmentDetails.Addresses[stopCount].Zip}");
                            txtAddressFrom.Text = string.Format($"{carrierShipmentDetails.Addresses[stopCount - 1].Address1} {carrierShipmentDetails.Addresses[stopCount - 1].Address2} {carrierShipmentDetails.Addresses[stopCount - 1].City} {carrierShipmentDetails.Addresses[stopCount - 1].State} {carrierShipmentDetails.Addresses[stopCount - 1].Zip}");
                        }
                    }
                }
                else
                {
                    txtAddressTo.Text = string.Format($"{carrierShipmentDetails.Addresses[1].Address1} {carrierShipmentDetails.Addresses[1].Address2} {carrierShipmentDetails.Addresses[1].City} {carrierShipmentDetails.Addresses[1].State} {carrierShipmentDetails.Addresses[1].Zip}");
                    txtAddressFrom.Text = string.Format($"{carrierShipmentDetails.Addresses[0].Company} {carrierShipmentDetails.Addresses[0].Address1} {carrierShipmentDetails.Addresses[0].Address2} {carrierShipmentDetails.Addresses[0].City} {carrierShipmentDetails.Addresses[0].State} {carrierShipmentDetails.Addresses[0].Zip}");
                    imViewSource.SetImageResource(Resource.Drawable.imgSource);
                    imViewDestination.SetBackgroundResource(0);
                    imViewDestination.SetImageResource(Resource.Drawable.imgstop);
                }
                Constants.stopCount = currentStop;
                switch (ShipmentActivity)
                {
                    case Constants.inTransitkey:
                        statuscount = 1;
                        statusCode = Helper.Constants.inTransitkey;
                        shipmentStatusValue = Constants.enrouteToPickup;
                        txtCurrentStatus.Text = Constants.enrouteToPickup;
                        txtViewUpdatedStatus.Text = Constants.arrivedATPickupLocation;
                        liveStatusCode = Helper.Constants.inTransitkey;
                        liveStatusText = Constants.enrouteToPickup;
                        imViewSource.SetImageResource(Resource.Drawable.imgSource);
                        imViewDestination.SetBackgroundResource(0);
                        imViewDestination.SetImageResource(Resource.Drawable.imgstop);
                        Cstatus = Constants.strNotDelivered;
                        StatusMsg = txtViewUpdatedStatus.Text;
                        break;
                    case Constants.arrivedAtPickupKey:
                        statuscount = 2;
                        statusCode = Helper.Constants.arrivedAtPickupKey;
                        shipmentStatusValue = Constants.arrivedATPickupLocation;
                        txtCurrentStatus.Text = Constants.arrivedATPickupLocation;
                        txtViewUpdatedStatus.Text = Constants.completedPickup;
                        liveStatusCode = Helper.Constants.arrivedAtPickupKey;
                        liveStatusText = Constants.arrivedATPickupLocation;
                        imViewSource.SetImageResource(Resource.Drawable.imgSource);
                        imViewDestination.SetBackgroundResource(0);
                        imViewDestination.SetImageResource(Resource.Drawable.imgstop);
                        Cstatus = Constants.strNotDelivered;
                        StatusMsg = txtViewUpdatedStatus.Text;
                        break;

                    case Constants.pickedupKey:
                        statuscount = 3;
                        statusCode = Helper.Constants.pickedupKey;
                        shipmentStatusValue = Constants.completedPickup;
                        txtCurrentStatus.Text = Constants.completedPickup;
                        txtViewUpdatedStatus.Text = "Enroute to " + carrierShipmentDetails.Addresses[stopCount].Type; //trackingStatus[Helper.Constants.pickedupKey];
                        liveStatusCode = Helper.Constants.pickedupKey;
                        liveStatusText = Constants.completedPickup;
                        StatusMsg = txtViewUpdatedStatus.Text;
                        imViewSource.SetImageResource(Resource.Drawable.imgSource);
                        imViewDestination.SetBackgroundResource(0);
                        imViewDestination.SetImageResource(Resource.Drawable.imgstop);
                        Cstatus = Constants.strNotDelivered;
                        break;

                    case Constants.enRoutekey:
                        statuscount = 4;
                        statusCode = Helper.Constants.enRoutekey;
                        if (carrierShipmentDetails.Addresses[stopCount].Type == "SHIPTO")
                        {
                            shipmentStatusValue = Constants.strEnrouteToDestination;
                            txtCurrentStatus.Text = Constants.strEnrouteToDestination;
                            txtViewUpdatedStatus.Text = Constants.strArrivedAtDestination;
                            liveStatusCode = Helper.Constants.enRoutekey;
                            imViewSource.SetImageResource(Resource.Drawable.imgstop);
                            imViewDestination.SetBackgroundResource(0);
                            imViewDestination.SetImageResource(Resource.Drawable.imgDestination);
                            liveStatusText = Constants.strEnrouteToDestination;
                            StatusMsg = txtViewUpdatedStatus.Text;
                        }
                        else
                        {
                            shipmentStatusValue = "Enroute to " + carrierShipmentDetails.Addresses[stopCount].Type;//trackingStatus
                            txtCurrentStatus.Text = "Enroute to " + carrierShipmentDetails.Addresses[stopCount].Type;//trackingStatus
                            txtViewUpdatedStatus.Text = "Arrived at " + carrierShipmentDetails.Addresses[stopCount].Type; //trackingStatus
                            liveStatusCode = Helper.Constants.enRoutekey;
                            StatusMsg = txtViewUpdatedStatus.Text;
                            if (stopCount - 1 >= 1)
                            {
                                imViewSource.SetImageResource(Resource.Drawable.imgstop);
                                imViewDestination.SetBackgroundResource(0);
                                imViewDestination.SetImageResource(Resource.Drawable.imgstop);
                            }
                            else
                            {
                                imViewSource.SetImageResource(Resource.Drawable.imgSource);
                                imViewDestination.SetBackgroundResource(0);
                                imViewDestination.SetImageResource(Resource.Drawable.imgstop);
                            }
                            liveStatusText = "Enroute to " + carrierShipmentDetails.Addresses[stopCount].Type; //trackingStatus
                        }
                        if (stopCount - 1 >= 1)
                        {
                            Constants.stopCountForConfirmtion = "STOP" + (stopCount - 1);
                            currentStopStatus = "STOP" + (stopCount - 1);
                        }
                        Cstatus = Constants.strNotDelivered;
                        break;
                    case "enrouteToNextStop":
                        statuscount = 3;
                        statusCode = Helper.Constants.enRoutekey;
                        if (carrierShipmentDetails.Addresses[stopCount].Type == "SHIPTO")
                        {
                            txtViewUpdatedStatus.Text = Constants.strEnrouteToDestination;
                            imViewDestination.SetBackgroundResource(0);
                            imViewSource.SetImageResource(Resource.Drawable.imgstop);
                            imViewDestination.SetImageResource(Resource.Drawable.imgDestination);
                        }
                        else
                        {
                            imViewDestination.SetBackgroundResource(0);
                            imViewSource.SetImageResource(Resource.Drawable.imgstop);
                            imViewDestination.SetImageResource(Resource.Drawable.imgstop);
                            txtViewUpdatedStatus.Text = "Enroute to " + carrierShipmentDetails.Addresses[stopCount].Type; //trackingStatus
                        }
                        StatusMsg = txtViewUpdatedStatus.Text;
                        shipmentStatusValue = "Completed Delivery of " + carrierShipmentDetails.Addresses[stopCount - 1].Type;//trackingStatus
                        txtCurrentStatus.Text = "Completed Delivery of " + carrierShipmentDetails.Addresses[stopCount - 1].Type;//trackingStatus
                        if (stopCount - 1 >= 1)
                        {
                            Constants.stopCountForConfirmtion = "STOP" + (stopCount - 1);
                            currentStopStatus = "STOP" + (stopCount - 1);
                        }
                        liveStatusCode = Helper.Constants.enRoutekey;
                        liveStatusText = "Completed Delivery of " + carrierShipmentDetails.Addresses[stopCount - 1].Type; //trackingStatus
                        Cstatus = "Not Delivered";
                        break;
                    case Constants.arrivedkey:
                        statuscount = 5;
                        statusCode = Helper.Constants.arrivedkey;
                        if (carrierShipmentDetails.Addresses[stopCount].Type == "SHIPTO")
                        {
                            shipmentStatusValue = Constants.strArrivedAtDestination;
                            txtCurrentStatus.Text = Constants.strArrivedAtDestination;
                            txtViewUpdatedStatus.Text = Constants.completedDeliveryOfDestination;
                            liveStatusCode = Helper.Constants.arrivedkey;
                            liveStatusText = Constants.strArrivedAtDestination;
                            imViewSource.SetImageResource(Resource.Drawable.imgstop);
                            imViewDestination.SetImageResource(Resource.Drawable.imgDestination);
                            Cstatus = Constants.strNotDelivered;
                        }
                        else
                        {
                            shipmentStatusValue = "Arrived at " + carrierShipmentDetails.Addresses[stopCount].Type;//trackingStatus[Helper.Constants.inTransitkey];
                            txtCurrentStatus.Text = "Arrived at " + carrierShipmentDetails.Addresses[stopCount].Type;//trackingStatus[Helper.Constants.inTransitkey];
                            txtViewUpdatedStatus.Text = "Complete Delivery of " + carrierShipmentDetails.Addresses[stopCount].Type; //trackingStatus[Helper.Constants.pickedupKey];
                            liveStatusCode = Helper.Constants.arrivedkey;
                            imViewSource.SetImageResource(Resource.Drawable.imgstop);
                            imViewDestination.SetBackgroundResource(0);
                            imViewDestination.SetImageResource(Resource.Drawable.imgstop);
                            liveStatusText = "Arrived at " + carrierShipmentDetails.Addresses[stopCount].Type; //trackingStatus[Helper.Constants.inTransitkey];
                            Cstatus = "Delivered";
                        }
                        Constants.stopCountForConfirmtion = "STOP" + stopCount;
                        currentStopStatus = "STOP" + stopCount;
                        StatusMsg = txtViewUpdatedStatus.Text;
                        break;
                    case Constants.completedkey:
                        statuscount = 6;
                        statusCode = Helper.Constants.completedkey;
                        if (carrierShipmentDetails.Addresses[stopCount].Type == "SHIPTO")
                        {
                            if (lnrUpdateStatus.Visibility == ViewStates.Visible)
                            {
                                shipmentStatusValue = Constants.strArrivedAtDestination;
                                txtCurrentStatus.Text = Constants.strArrivedAtDestination;
                                txtViewUpdatedStatus.Text = Constants.strCompletedDeliveryText;
                                liveStatusCode = Helper.Constants.completedkey;
                                liveStatusText = Constants.strArrivedAtDestination;
                                Cstatus = "Delivered";
                                imViewSource.SetImageResource(Resource.Drawable.imgstop);
                                imViewDestination.SetImageResource(Resource.Drawable.imgDestination);
                            }
                        }
                        else if (carrierShipmentDetails.Addresses[stopCount].Type == "BILLTO")
                        {
                            if (carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 1].ActivityDescr == Constants.strCompletedDeliveryText)
                            {
                                shipmentStatusValue = Constants.strCompletedDeliveryText;
                                txtCurrentStatus.Text = Constants.strCompletedDeliveryText;
                                txtViewUpdatedStatus.Text = Constants.strCompletedDeliveryText;
                                liveStatusCode = Helper.Constants.completedkey;
                                liveStatusText = Constants.strCompletedDeliveryText;
                            }
                            else
                            {
                                shipmentStatusValue = Constants.strArrivedAtDestination;
                                txtCurrentStatus.Text = Constants.strArrivedAtDestination;
                                txtViewUpdatedStatus.Text = Constants.strCompletedDeliveryText;
                                liveStatusCode = Helper.Constants.completedkey;
                                liveStatusText = Constants.strArrivedAtDestination;
                            }
                            Cstatus = "Delivered";
                            imViewSource.SetImageResource(Resource.Drawable.imgstop);
                            imViewDestination.SetImageResource(Resource.Drawable.imgDestination);
                        }
                        else
                        {
                            shipmentStatusValue = "Completed Delivery of " + carrierShipmentDetails.Addresses[stopCount - 1].Type;
                            txtCurrentStatus.Text = "Completed Delivery of " + carrierShipmentDetails.Addresses[stopCount - 1].Type;
                            txtViewUpdatedStatus.Text = "Completed Delivery";
                            liveStatusCode = Helper.Constants.completedkey;
                            liveStatusText = "Completed Delivery of " + carrierShipmentDetails.Addresses[stopCount - 1].Type;
                            Cstatus = "Delivered";
                            imViewSource.SetImageResource(Resource.Drawable.imgstop);
                            imViewDestination.SetImageResource(Resource.Drawable.imgDestination);
                        }
                        StatusMsg = txtViewUpdatedStatus.Text;
                        Constants.stopCountForConfirmtion = "STOP" + (stopCount - 1);
                        currentStopStatus = "STOP" + (stopCount - 1);
                        //ResetTracking(); //Reset tracking details
                        break;
                    case "Shipment Completed":
                        statuscount = 7;
                        statusCode = Helper.Constants.completedkey;
                        shipmentStatusValue = Constants.strCompletedDeliveryText;
                        txtCurrentStatus.Text = Constants.strCompletedDeliveryText;
                        txtViewUpdatedStatus.Text = Constants.strCompletedDeliveryText;
                        liveStatusCode = Helper.Constants.completedkey;
                        liveStatusText = Constants.strCompletedDeliveryText;
                        imViewSource.SetImageResource(Resource.Drawable.imgstop);
                        imViewDestination.SetImageResource(Resource.Drawable.imgDestination);
                        lnrUpdateStatus.Visibility = ViewStates.Gone;
                        StatusMsg = txtViewUpdatedStatus.Text;
                        ResetTracking(); //Reset tracking details
                        break;
                    case Constants.exceptionkey1:
                        //statuscount = 7;
                        statusCode = Helper.Constants.exceptionkey1;
                        shipmentStatusValue = trackingStatus[ShipmentActivity];
                        txtCurrentStatus.Text = trackingStatus[ShipmentActivity];
                        //txtViewUpdatedStatus.Text = Constants.strCompletedDeliveryText;
                        liveStatusCode = Helper.Constants.exceptionkey1;
                        liveStatusText = trackingStatus[ShipmentActivity];
                        StatusMsg = txtCurrentStatus.Text;
                        //ResetTracking(); //Reset tracking details
                        break;
                    case Constants.exceptionkey2:
                        //statuscount = 7;
                        statusCode = Helper.Constants.exceptionkey2;
                        shipmentStatusValue = trackingStatus[ShipmentActivity];
                        txtCurrentStatus.Text = trackingStatus[ShipmentActivity];
                        //txtViewUpdatedStatus.Text = Constants.strCompletedDeliveryText;
                        liveStatusCode = Helper.Constants.exceptionkey2;
                        liveStatusText = trackingStatus[ShipmentActivity];
                        StatusMsg = txtCurrentStatus.Text;
                        // ResetTracking(); //Reset tracking details
                        break;
                    case Constants.exceptionkey3:
                        //statuscount = 7;
                        statusCode = Helper.Constants.exceptionkey3;
                        shipmentStatusValue = trackingStatus[ShipmentActivity];
                        txtCurrentStatus.Text = trackingStatus[ShipmentActivity];
                        //txtViewUpdatedStatus.Text = Constants.strCompletedDeliveryText;
                        liveStatusCode = Helper.Constants.exceptionkey3;
                        liveStatusText = trackingStatus[ShipmentActivity];
                        StatusMsg = txtCurrentStatus.Text;
                        //ResetTracking(); //Reset tracking details
                        break;
                    case Constants.exceptionkey4:
                        //statuscount = 7;
                        statusCode = Helper.Constants.exceptionkey4;
                        shipmentStatusValue = trackingStatus[ShipmentActivity];
                        txtCurrentStatus.Text = trackingStatus[ShipmentActivity];
                        //txtViewUpdatedStatus.Text = Constants.strCompletedDeliveryText;
                        liveStatusCode = Helper.Constants.exceptionkey4;
                        liveStatusText = trackingStatus[ShipmentActivity];
                        StatusMsg = txtCurrentStatus.Text;
                        //ResetTracking(); //Reset tracking details
                        break;
                    case Constants.exceptionkey5:
                        //statuscount = 7;
                        statusCode = Helper.Constants.exceptionkey5;
                        shipmentStatusValue = trackingStatus[ShipmentActivity];
                        txtCurrentStatus.Text = trackingStatus[ShipmentActivity];
                        //txtViewUpdatedStatus.Text = Constants.strCompletedDeliveryText;
                        liveStatusCode = Helper.Constants.exceptionkey5;
                        liveStatusText = trackingStatus[ShipmentActivity];
                        StatusMsg = txtCurrentStatus.Text;
                        //ResetTracking(); //Reset tracking details
                        break;
                    default:
                        txtCurrentStatus.Text = Constants.shippingNotStart;
                        txtViewUpdatedStatus.Text = Constants.enrouteToPickup;
                        break;
                }
                if (ShipmentActivity == Constants.completedkey)
                {
                    txtAddressTo.Text = string.Format($"{carrierShipmentDetails.Addresses[stopCount - 1].Company}{carrierShipmentDetails.Addresses[stopCount - 1].Address1} {carrierShipmentDetails.Addresses[stopCount - 1].Address2} {carrierShipmentDetails.Addresses[stopCount - 1].City} {carrierShipmentDetails.Addresses[stopCount - 1].State} {carrierShipmentDetails.Addresses[stopCount - 1].Zip}");
                    txtAddressFrom.Text = string.Format($"{carrierShipmentDetails.Addresses[stopCount - 2].Company} {carrierShipmentDetails.Addresses[stopCount - 2].Address1} {carrierShipmentDetails.Addresses[stopCount - 2].Address2} {carrierShipmentDetails.Addresses[stopCount - 2].City} {carrierShipmentDetails.Addresses[stopCount - 2].State} {carrierShipmentDetails.Addresses[stopCount - 2].Zip}");
                }
                else
                {
                    txtAddressTo.Text = string.Format($"{carrierShipmentDetails.Addresses[stopCount].Company} {carrierShipmentDetails.Addresses[stopCount].Address1} {carrierShipmentDetails.Addresses[stopCount].Address2} {carrierShipmentDetails.Addresses[stopCount].City} {carrierShipmentDetails.Addresses[stopCount].State} {carrierShipmentDetails.Addresses[stopCount].Zip}");
                    txtAddressFrom.Text = string.Format($"{carrierShipmentDetails.Addresses[stopCount - 1].Company} {carrierShipmentDetails.Addresses[stopCount - 1].Address1} {carrierShipmentDetails.Addresses[stopCount - 1].Address2} {carrierShipmentDetails.Addresses[stopCount - 1].City} {carrierShipmentDetails.Addresses[stopCount - 1].State} {carrierShipmentDetails.Addresses[stopCount - 1].Zip}");
                }
                Constants.currentShipStatus = txtCurrentStatus.Text;
                //}
            }
            catch
            {
                throw;
            }
        }



        /// <summary>
        /// Subscribe from pub nub channel
        /// </summary>
        /// <param name="subscriber"></param>
        public void Subscribe(string subscriber)
        {
            try
            {
                //Display("Running " + subscriber + "");
                ThreadPool.QueueUserWorkItem(o =>
                {
                    pubnub.AddListener(listener);
                    pubnub.Subscribe<object>()
                            .Channels(new[] { subscriber })
                          .WithPresence().Execute();
                }
                );
            }
            catch
            {
                //throw;
            }
        }

        /// <summary>
        /// Unsub from pubnub channel
        /// </summary>
        /// <param name="channel"></param>
        private void Unsub(string channel)
        {
            try
            {
                // Display("Running unsubscribe to  " + channel + "");
                ThreadPool.QueueUserWorkItem(o =>
                {
                    pubnub.Unsubscribe<string>()
                       .Channels(new[] { channel }) //.Execute()
                       .ChannelGroups(new[] { channelGroup }).Execute();
                    pubnub.RemoveListener(listener);

                }
                );
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Remove Channels 
        /// </summary>
        private void RemoveChannelFromChannelGroup(string channel)
        {
            try
            {
                //Display("Running RemoveChannelsFromChannelGroup");
                ThreadPool.QueueUserWorkItem(o =>
                     pubnub.RemoveChannelsFromChannelGroup()
                     .Channels(new[] { channel })
                     .Async(new DemoChannelGroupRemoveChannel(Display))
                );
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Display used for testing in pubnub
        /// </summary>
        /// <param name="strText"></param>
        public void Display(string strText)
        {
            Console.Write("Tets");
        }

        /// <summary>
        /// FnHttpRequest
        /// </summary>
        WebClient webclient;
        async Task<string> FnHttpRequest(string strUri)
        {
            webclient = new WebClient();
            string strResultData;
            try
            {
                strResultData = await webclient.DownloadStringTaskAsync(new Uri(strUri));
                Console.WriteLine(strResultData);
            }
            catch
            {
                strResultData = Constants.strException;
            }
            finally
            {
                if (webclient != null)
                {
                    webclient.Dispose();
                    webclient = null;
                }
            }
            return strResultData;
        }

    }

    /// <summary>
    ///PublishResult of pubnub
    /// </summary>
    public class DemoPublishResult : PNCallback<PNPublishResult>
    {
        readonly Action<string> callback;
        readonly Pubnub pubnub = new Pubnub(null);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="displayCallback"></param>
        public DemoPublishResult(Action<string> displayCallback)
        {
            callback = displayCallback;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="result"></param>
        /// <param name="status"></param>
        public override void OnResponse(PNPublishResult result, PNStatus status)
        {
            if (result != null)
            {
                callback(pubnub.JsonPluggableLibrary.SerializeToJsonString(result));
            }
            else if (status != null)
            {
                callback(pubnub.JsonPluggableLibrary.SerializeToJsonString(status));
            }
        }
    };


    /// <summary>
    /// SubscribeCallback of pubnub
    /// </summary>
    public class DemoSubscribeCallback : SubscribeCallback
    {
        readonly Action<string> callback;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="displayCallback"></param>
        public DemoSubscribeCallback(Action<string> displayCallback)
        {
            callback = displayCallback;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="pubnub"></param>
        /// <param name="fileEvent"></param>
        public override void File(Pubnub pubnub, PNFileEventResult fileEvent)
        {

        }

        /// <summary>
        /// PubNum message result
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="pubnub"></param>
        /// <param name="messageResult"></param>
        public override void Message<T>(Pubnub pubnub, PNMessageResult<T> messageResult)
        {
            if (messageResult != null)
            {
                callback(pubnub.JsonPluggableLibrary.SerializeToJsonString(messageResult));
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="pubnub"></param>
        /// <param name="messageAction"></param>
        public override void MessageAction(Pubnub pubnub, PNMessageActionEventResult messageAction)
        {

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="pubnub"></param>
        /// <param name="objectEvent"></param>
        public override void ObjectEvent(Pubnub pubnub, PNObjectEventResult objectEvent)
        {

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pubnub"></param>
        /// <param name="presenceResult"></param>
        public override void Presence(Pubnub pubnub, PNPresenceEventResult presenceResult)
        {
            if (presenceResult != null)
            {
                callback(pubnub.JsonPluggableLibrary.SerializeToJsonString(presenceResult));
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="pubnub"></param>
        /// <param name="signal"></param>
        public override void Signal<T>(Pubnub pubnub, PNSignalResult<T> signal)
        {

        }

        /// <summary>
        /// PubNub connection status
        /// </summary>
        /// <param name="pubnub"></param>
        /// <param name="statusObj"></param>
        public override void Status(Pubnub pubnub, PNStatus statusObj)
        {
            string msg = string.Format("Operation: {0}; Category: {1};  StatusCode: {2}", statusObj.Operation, statusObj.Category, statusObj.StatusCode);
            callback(msg);

            if (statusObj.Category == PNStatusCategory.PNUnexpectedDisconnectCategory)
            {
                // This event happens when radio / connectivity is lost
                System.Diagnostics.Debug.WriteLine("PNUnexpectedDisconnectCategory");
            }
            else if (statusObj.Category == PNStatusCategory.PNConnectedCategory)
            {
                //Console.WriteLine("CONNECTED {0} Channels = {1}, ChannelGroups = {2}", status.StatusCode, string.Join(",", status.AffectedChannels), string.Join(",", status.AffectedChannelGroups));
                // Connect event. You can do stuff like publish, and know you'll get it.
                // Or just use the connected event to confirm you are subscribed for
                // UI / internal notifications, etc
                System.Diagnostics.Debug.WriteLine("PNConnectedCategory");
            }
            else if (statusObj.Category == PNStatusCategory.PNReconnectedCategory)
            {
                //Console.WriteLine("RE-CONNECTED {0} Channels = {1}, ChannelGroups = {2}", status.StatusCode, string.Join(",", status.AffectedChannels), string.Join(",", status.AffectedChannelGroups));
                // Happens as part of our regular operation. This event happens when
                // radio / connectivity is lost, then regained.
                System.Diagnostics.Debug.WriteLine("PNReconnectedCategory");
            }
            else if (statusObj.Category == PNStatusCategory.PNDecryptionErrorCategory)
            {
                // Handle messsage decryption error. Probably client configured to
                // encrypt messages and on live data feed it received plain text.
                System.Diagnostics.Debug.WriteLine("PNDecryptionErrorCategory");
            }
        }
    }
    /// <summary>
    /// ChannelGroupRemoveChannel of pubnub
    /// </summary>
    public class DemoChannelGroupRemoveChannel : PNCallback<PNChannelGroupsRemoveChannelResult>
    {
        readonly Action<string> callback;
        readonly Pubnub pubnub = new Pubnub(null);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="displayCallback"></param>
        public DemoChannelGroupRemoveChannel(Action<string> displayCallback)
        {
            this.callback = displayCallback;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="result"></param>
        /// <param name="status"></param>
        public override void OnResponse(PNChannelGroupsRemoveChannelResult result, PNStatus status)
        {
            if (result != null)
            {
                this.callback(pubnub.JsonPluggableLibrary.SerializeToJsonString(result));
            }
            else if (status != null)
            {
                this.callback(pubnub.JsonPluggableLibrary.SerializeToJsonString(status));
            }
        }
    }

}