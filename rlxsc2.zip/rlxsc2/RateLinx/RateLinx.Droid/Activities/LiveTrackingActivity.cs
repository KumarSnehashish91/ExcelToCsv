using System;
using System.Collections.Generic;
using System.Linq;
using Android.App;
using Android.OS;
using Android.Widget;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;
using Android.Views;
using Newtonsoft.Json;
using RateLinx.Models;
using System.Threading.Tasks;
using RateLinx.APIs;
using System.Security;
using Android.Locations;
using TaskStackBuilder = Android.Support.V4.App.TaskStackBuilder;
using Android.Content;
using Android.Preferences;
using RateLinx.Droid.GoogleMapServices;
using Android.Support.V4.Content;
using Android;
using Android.Content.PM;
using Android.Support.V4.App;

namespace RateLinx.Droid.Activities
{
    /// <summary>
    /// LiveTrackingActivity
    /// </summary>
    [Activity(Label = "RateLinx", Icon = "@drawable/icon", Theme = "@style/Theme.AppCompat.NoActionBar", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class LiveTrackingActivity : HeaderActivity
    {
        #region objects and variables declaration
        TextView editTextCross;
        Button btnCancel, btnSaveTracking;
        Spinner spinnerLiveTrack, spinnerAutoTrack;
        CheckBox chkLiveTrack, chkAutoTrack;
        LinearLayout lnrUpdateEvry, lnrTrackEvry, lnrLiveTrackingChk, lnrTrackingUpdateChk;
        RelativeLayout layoutSaveCancel;
        List<string> liveTrackingElements = null;
        List<string> autoTrackingElements = null;
        RecentShipments lstRecentShipments = null;
        //GPSSettings objGPSService = null;
        List<CountryDetails> lstCountryDetails = null;
        int LiveTracking = 0;
        int AutoTracking = 0;
        string trackID = string.Empty;
        string strBolNum = string.Empty;
        ArrayAdapter liveAdapter = null;
        ArrayAdapter AutoAdapter = null;
        Dialog denyDialog = null;
        Utility objUtility = null;
        string strProNum = string.Empty;
        int strNotifyInRadius = 0;
        string ShipmentTrackingList = string.Empty;
        RecentShipments objRecentShip = null;
        string recentShipTrackList = string.Empty;
        List<TrackList> lstNewTrackList = null;
        string apiMethod = string.Empty;
        List<TrackList> lstTrackList = null;
        Android.Locations.Address objGPSData = null;
        TrackList objTrackList = null;
        ISharedPreferences localStorage = null;
        Android.Graphics.Color brownColor, lightBrownColor;

        readonly string[] PermissionsLocation =
                         {
         Manifest.Permission.AccessCoarseLocation,
         Manifest.Permission.AccessFineLocation
        };
        #endregion

        /// <summary>
        /// Layout On Load Method
        /// </summary>
        /// <param name="savedInstanceState"></param>
       
        protected async override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);
                if (string.IsNullOrEmpty(CommanUtil.tokenNo))
                {
                    Utility.Logout(this);
                }
                brownColor = new Android.Graphics.Color(224, 223, 223);
                lightBrownColor = new Android.Graphics.Color(240, 239, 239);

                //Remove Header Title
                RequestWindowFeature(WindowFeatures.NoTitle);
                SetContentView(Resource.Layout.ShipmentLiveTracking);
                localStorage = PreferenceManager.GetDefaultSharedPreferences(this);
                string recentShipmentDetail = Intent.GetStringExtra("recentShipment");
                objRecentShip = JsonConvert.DeserializeObject<RecentShipments>(recentShipmentDetail);
                await FnSetUpControls();

            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
                Finish();
            }
        }


        /// <summary>
        /// Get All the Controls and assign values in dropdowns
        /// </summary>
        private async Task FnSetUpControls()
        {
            try
            {
                editTextCross = FindViewById<TextView>(Resource.Id.editTextCross);
                btnCancel = FindViewById<Button>(Resource.Id.btnCancel);
                spinnerLiveTrack = FindViewById<Spinner>(Resource.Id.spinnerLiveTrack);
                spinnerAutoTrack = FindViewById<Spinner>(Resource.Id.spinnerAutoTrack);
                lnrLiveTrackingChk = FindViewById<LinearLayout>(Resource.Id.lnrLiveTrackingChk);
                lnrTrackingUpdateChk = FindViewById<LinearLayout>(Resource.Id.lnrTrackingUpdateChk);
                layoutSaveCancel = FindViewById<RelativeLayout>(Resource.Id.layoutSaveCancel);
                lnrTrackEvry = FindViewById<LinearLayout>(Resource.Id.lnrTrackEvry);
                lnrUpdateEvry = FindViewById<LinearLayout>(Resource.Id.lnrUpdateEvry);
                chkLiveTrack = FindViewById<CheckBox>(Resource.Id.chkLiveTrack);
                chkAutoTrack = FindViewById<CheckBox>(Resource.Id.chkAutoTrack);
                btnSaveTracking = FindViewById<Button>(Resource.Id.btnSaveTracking);
                //Manage Visibility of controls
                lnrTrackEvry.Visibility = ViewStates.Gone;
                lnrUpdateEvry.Visibility = ViewStates.Gone;

                lnrLiveTrackingChk.SetBackgroundColor(brownColor);
                lnrTrackingUpdateChk.SetBackgroundColor(lightBrownColor);
                layoutSaveCancel.SetBackgroundColor(brownColor);


                //Creating Event
                chkLiveTrack.Click += delegate
                {
                    FnDisplayTracking("Live");
                };
                chkAutoTrack.Click += delegate
                {
                    FnDisplayTracking("Auto");
                };
                editTextCross.Click += EditTextCross_Click;
                btnCancel.Click += BtnCancel_Click;
                btnSaveTracking.Click += BtnSaveTracking_Click;
                //Get shipment Track details
                lstRecentShipments = JsonConvert.DeserializeObject<RecentShipments>(Intent.GetStringExtra("recentShipment"));
                trackID = lstRecentShipments.ClientID + "|" + lstRecentShipments.LocID + "|" + lstRecentShipments.BolNum;
                strBolNum = lstRecentShipments.BolNum;
                strProNum = lstRecentShipments.ProNum;
                strNotifyInRadius = lstRecentShipments.NotifyInRadius;
                //Bind values of Dropdowns
                FnLiveTrackSpinner();//Live Tracking Spinner
                FnAutoTrackSpinner(true);//Automatic Tracking Spinner
                //await TrackingInterval();
                lstCountryDetails = await Utility.GetCountryDetails(this);
                // objGPSData = await InitializeLocationManager();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Save Tracking Information Button Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void BtnSaveTracking_Click(object sender, EventArgs e)
        {
            try
            {
                if (objRecentShip.SCAC.ToUpper() == Constants.strLiveTrack)
                {
                    if ((ContextCompat.CheckSelfPermission(this, Manifest.Permission.AccessFineLocation) == (int)Permission.Granted) &&
                  (ContextCompat.CheckSelfPermission(this, Manifest.Permission.AccessCoarseLocation) == (int)Permission.Granted))
                    {
                        await FnSaveTracking();
                    }
                    else
                    {
                        ActivityCompat.RequestPermissions(this, PermissionsLocation, 0);
                    }

                }
                else
                {
                    StopTracking();
                }
            }
            catch(Exception ex)
            {
                Alerts.HideBusyLoader();
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Display Tracking Info.
        /// </summary>
        /// <param name="type">Type of Tracking</param>
        private void FnDisplayTracking(string type)
        {
            try
            {
                if (type == Constants.strLive)
                {
                    if (chkLiveTrack.Checked)
                    {
                        lnrTrackEvry.Visibility = ViewStates.Visible;
                        if (autoTrackingElements.Count > 3)
                        {
                            autoTrackingElements[3] = (CommanUtil.AutoTracking);
                        }
                        else
                        {
                            autoTrackingElements.Add(CommanUtil.AutoTracking);
                        }
                        FnAutoTrackSpinner(false);
                    }
                    else
                    {
                        lnrTrackEvry.Visibility = ViewStates.Gone;
                        if (autoTrackingElements.Count > 3)
                        {
                            autoTrackingElements.RemoveAt(3);
                        }
                        FnAutoTrackSpinner(false);
                    }
                }
                else
                {
                    if (chkAutoTrack.Checked)
                    {
                        lnrUpdateEvry.Visibility = ViewStates.Visible;
                    }
                    else
                    {
                        lnrUpdateEvry.Visibility = ViewStates.Gone;
                    }
                }
            }
            catch
            {
                throw;
            }
            if (lnrTrackEvry.Visibility == ViewStates.Visible && lnrUpdateEvry.Visibility == ViewStates.Visible)
            {
                lnrLiveTrackingChk.SetBackgroundColor(brownColor);
                lnrTrackEvry.SetBackgroundColor(lightBrownColor);
                lnrTrackingUpdateChk.SetBackgroundColor(brownColor);
                lnrUpdateEvry.SetBackgroundColor(lightBrownColor);
                layoutSaveCancel.SetBackgroundColor(brownColor);

            }
            else if (lnrTrackEvry.Visibility == ViewStates.Visible && lnrUpdateEvry.Visibility == ViewStates.Gone)
            {
                lnrLiveTrackingChk.SetBackgroundColor(brownColor);
                lnrTrackEvry.SetBackgroundColor(lightBrownColor);
                lnrTrackingUpdateChk.SetBackgroundColor(brownColor);
                layoutSaveCancel.SetBackgroundColor(lightBrownColor);

            }
            else if (lnrTrackEvry.Visibility == ViewStates.Gone && lnrUpdateEvry.Visibility == ViewStates.Visible)
            {
                lnrLiveTrackingChk.SetBackgroundColor(brownColor);
                lnrTrackingUpdateChk.SetBackgroundColor(lightBrownColor);
                lnrUpdateEvry.SetBackgroundColor(brownColor);
                layoutSaveCancel.SetBackgroundColor(lightBrownColor);
            }
            else
            {
                lnrLiveTrackingChk.SetBackgroundColor(brownColor);
                lnrTrackingUpdateChk.SetBackgroundColor(lightBrownColor);
                layoutSaveCancel.SetBackgroundColor(brownColor);
            }


        }

        /// <summary>
        /// Bind Live Tracking Spinner or Dropdown
        /// </summary>
        private void FnLiveTrackSpinner()
        {
            try
            {
                liveTrackingElements = new List<string>();
                foreach (KeyValuePair<string, string> kvpTrack in CommanUtil.GetLiveTrackingElements())
                {
                    liveTrackingElements.Add(kvpTrack.Value);
                }
                liveAdapter = new ArrayAdapter(this, Android.Resource.Layout.SimpleSpinnerItem, liveTrackingElements);
                liveAdapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
                spinnerLiveTrack.Adapter = liveAdapter;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Binding of Automatic Live Tracking spinner
        /// </summary>
        private void FnAutoTrackSpinner(bool enable)
        {
            try
            {
                if (enable)
                {
                    autoTrackingElements = new List<string>();
                    foreach (KeyValuePair<string, string> kvpTrack in CommanUtil.GetTrackingUpdatesElements())
                    {
                        autoTrackingElements.Add(kvpTrack.Value);
                    }
                }
                AutoAdapter = new ArrayAdapter(this, Android.Resource.Layout.SimpleSpinnerItem, autoTrackingElements);
                AutoAdapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
                spinnerAutoTrack.Adapter = AutoAdapter;
                if (autoTrackingElements.Count > 3)
                {
                    spinnerAutoTrack.SetSelection(3);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Finshing activity on cancel button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                Finish();
            }
            catch
            {
                Finish();
            }
        }

        /// <summary>
        /// Finshing activity on cross button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EditTextCross_Click(object sender, EventArgs e)
        {
            try
            {
                Finish();
            }
            catch
            {
                Finish();
            }
        }
        /// <summary>
        /// Request Permission Result
        /// </summary>
        /// <param name="requestCode"></param>
        /// <param name="permissions"></param>
        /// <param name="grantResults"></param>
        public override async void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
        {
            try
            {
                if (grantResults[0] == Permission.Granted)
                {
                    await InitializeLocationManager();
                }
                else
                {
                    
                }

            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Save Data in API
        /// </summary>
        private async Task FnSaveTracking()
        {
            try
            {
                Alerts.showBusyLoader(this); //Loader
                objGPSData = await InitializeLocationManager();
                if (objGPSData != null)
                {
                    recentShipTrackList = string.Empty;
                    string trackId = CommanUtil.CompositeKey(objRecentShip.ClientID, objRecentShip.LocID, objRecentShip.BolNum);
                    string shipToAddress = objRecentShip.ShipToCity + ", " + objRecentShip.ShipToState + ", " + objRecentShip.ShipToZip;
                    FnGetSelectedValue(); //Get Values from selected controls
                    lstTrackList = new List<TrackList>();
                    lstNewTrackList = new List<TrackList>();
                    objTrackList = new TrackList();
                    recentShipTrackList = localStorage.GetString("objTrackList", null);
                    if (!string.IsNullOrEmpty(recentShipTrackList))
                    {
                        lstNewTrackList = JsonConvert.DeserializeObject<List<TrackList>>(recentShipTrackList);
                        if (lstNewTrackList.Count > 0)
                        {
                            lstTrackList.AddRange(lstNewTrackList);
                            objTrackList.BolNum = objRecentShip.BolNum;
                            objTrackList.LiveTracking = LiveTracking;
                            objTrackList.TrackingUpdate = AutoTracking;
                            objTrackList.LD = LiveTracking;
                            objTrackList.UD = AutoTracking;
                            objTrackList.ProNum = objRecentShip.ProNum;
                            objTrackList.trackID = trackId;
                            objTrackList.shipToAddress = shipToAddress;
                            objTrackList.NotifyInRadius = objRecentShip.NotifyInRadius;
                            objTrackList.IsNotificationSent = false;
                            lstTrackList.Add(objTrackList);
                        }
                    }
                    if (lstNewTrackList == null || lstNewTrackList.Count == 0)
                    {
                        objTrackList.BolNum = objRecentShip.BolNum;
                        objTrackList.LiveTracking = LiveTracking;
                        objTrackList.TrackingUpdate = AutoTracking;
                        objTrackList.LD = LiveTracking;
                        objTrackList.UD = AutoTracking;
                        objTrackList.ProNum = objRecentShip.ProNum;
                        objTrackList.trackID = trackId;
                        objTrackList.shipToAddress = shipToAddress;
                        objTrackList.NotifyInRadius = objRecentShip.NotifyInRadius;
                        objTrackList.IsNotificationSent = false;
                        lstTrackList.Add(objTrackList);
                    }
                    CommanUtil.isTrackingClicked = false;
                    CommanUtil.isTrackingOn = false;
                    await TrackingInterval();
                    Alerts.HideBusyLoader();
                }
                else
                {
                    Alerts.HideBusyLoader();
                    CommanUtil.isTrackingClicked = false;
                    Toast.MakeText(this, Constants.strEnableTracking, ToastLength.Long).Show();
                }
            }
            catch
            {
                Alerts.HideBusyLoader();
                throw;
            }
        }

        /// <summary>
        /// Getting Current Location
        /// </summary>
        private async Task<Android.Locations.Address> InitializeLocationManager()
        {
            try
            {
                if (!Utility.FnIsOnline(this))
                {
                    Alerts.HideBusyLoader();
                    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    return null;
                }
                Android.Locations.Address addressCurrent = null;

                //Enable Gps Setting and Get Current Location

                GPSServiceSettings objGPSServiceSettings = new GPSServiceSettings();
                string response = objGPSServiceSettings.StartLocationUpdates(null);
                if (!string.IsNullOrEmpty(response) && response.Equals("network"))
                {
                    double lat = CommanUtil.currLat;//37.089984;//
                    double lng = CommanUtil.currLong;//-95.715063;//
                    Geocoder geocoder;
                    IList<Android.Locations.Address> addresses;
                    geocoder = new Geocoder(this);
                    addresses = await geocoder.GetFromLocationAsync(CommanUtil.currLat, CommanUtil.currLong, 10); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
                    if (addresses != null && addresses.Count > 0)
                    {
                        addressCurrent = addresses.FirstOrDefault();
                    }
                }
                else
                {
                    addressCurrent = null;
                    Toast.MakeText(this, Constants.strEnableTracking, ToastLength.Long).Show();
                }
                return addressCurrent;
            }
            catch(Exception ex)
            {
                Alerts.HideBusyLoader();
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private async Task LiveTrackingInterval()
        {
            string newCountryCode, newStateCode = string.Empty;
            objGPSData = await InitializeLocationManager();
            if (objGPSData != null)
            {
                GetCountryStateCode(objGPSData.CountryName, objGPSData.AdminArea, out newCountryCode, out newStateCode);
                if (string.IsNullOrEmpty(newCountryCode) || string.IsNullOrEmpty(newStateCode))
                {
                    newCountryCode = objGPSData.CountryCode;
                    newStateCode = objGPSData.AdminArea;
                }
                if (lstTrackList != null)
                {
                    ServiceHelper objServiceHelper = new ServiceHelper();
                    string replyResult = string.Empty;
                    string jsonReplyRequest = string.Empty;
                    lstNewTrackList = null;
                    if (lstTrackList != null)
                    {
                        lstNewTrackList = lstTrackList;
                    }
                    string date = Convert.ToDateTime(DateTime.Now.ToShortDateString()).ToString(Constants.dateFormatMMDDYYYY);
                    string newDate = date.Contains("-") ? date.Replace('-', '/') : date;
                    string time = DateTime.Now.ToShortTimeString();
                    try
                    {
                        if (lstNewTrackList != null && lstNewTrackList.Count > 0 && CommanUtil.ViewAs.ToUpper() == Constants.strCarrier)
                        {
                            for (int index = 0; index < lstNewTrackList.Count; index++)
                            {
                                string shipToAddress = lstNewTrackList[index].shipToAddress;
                                string shipmentId = lstNewTrackList[index].trackID;
                                int notifyInRadius = lstNewTrackList[index].NotifyInRadius;
                                bool isNoficationSent = lstNewTrackList[index].IsNotificationSent;

                                if (lstNewTrackList[index].LiveTracking != 0)
                                {
                                    lstNewTrackList[index].LD = lstNewTrackList[index].LD - 5;
                                    if (lstNewTrackList[index].LD == 0)
                                    {
                                        lstNewTrackList[index].LD = lstNewTrackList[index].LiveTracking;

                                        if (objGPSData != null)
                                        {
                                            apiMethod = "shipment" + "/" + lstNewTrackList[index].trackID + "/" + APIMethods.gpsLocation;
                                            jsonReplyRequest = "{"
                                                   + "\"Latitude\":" + "\"" + objGPSData.Latitude + "\","
                                                   + "\"Longitude\":" + "\"" + objGPSData.Longitude + "\","
                                                   + "\"Interval\":" + "\"" + lstNewTrackList[index].LiveTracking + "\""
                                                   + "}";
                                            replyResult = await objServiceHelper.PostRequestJson(jsonReplyRequest, apiMethod, CommanUtil.tokenNo, true);
                                            if (replyResult != null)
                                            {
                                                var Jobject = JsonConvert.DeserializeObject(replyResult);
                                                if (Jobject.ToString().ToUpper() == Constants.strSuccess.ToUpper())
                                                {
                                                    replyResult = Constants.strSuccess;
                                                }
                                                else
                                                {
                                                    CommanUtil.isTrackingClicked = false;
                                                    replyResult = Constants.strException;
                                                    Utility.ErrorLog(replyResult, replyResult, CommanUtil.tokenNo, this);
                                                }
                                            }
                                        }
                                        else
                                        {
                                            CommanUtil.isTrackingClicked = false;
                                            Toast.MakeText(this, Constants.strEnableTracking, ToastLength.Long).Show();
                                        }
                                    }
                                    if (lstNewTrackList[index].TrackingUpdate != 0)
                                    {
                                        lstNewTrackList[index].UD = lstNewTrackList[index].UD - 5;
                                        if (lstNewTrackList[index].UD == 0)
                                        {
                                            lstNewTrackList[index].UD = lstNewTrackList[index].TrackingUpdate;

                                            if (objGPSData != null)
                                            {
                                                if (newStateCode == "Uttar Pradesh")
                                                {
                                                    newStateCode = "UP";
                                                }
                                                else
                                                {

                                                }
                                                //string stateCode, countryCode = string.Empty;
                                                apiMethod = "shipmentrequests" + "/" + lstNewTrackList[index].trackID + "/" + APIMethods.tracking;
                                                jsonReplyRequest = "{"
                                                       + "\"ProNumber\":" + "\"" + lstNewTrackList[index].ProNum + "\","
                                                       + "\"ActivityDate\":" + "\"" + newDate + " " + time + "\","
                                                       + "\"ActivityCode\":" + "\"" + "X6" + "\","
                                                       + "\"ActivityDescr\":" + "\"" + "En Route" + "\","
                                                       + "\"City\":" + "\"" + objGPSData.Locality + "\","
                                                       + "\"State\":" + "\"" + newStateCode + "\","   //objGPSData.AdminArea
                                                       + "\"Country\":" + "\"" + newCountryCode
                                                       + "\"" + "}";
                                                replyResult = await objServiceHelper.PostRequestJson(jsonReplyRequest, apiMethod, CommanUtil.tokenNo, true);
                                                if (replyResult != null)
                                                {
                                                    List<LiveTrack> lstLiveTrack = JsonConvert.DeserializeObject<List<LiveTrack>>(replyResult);
                                                    if (lstLiveTrack[0].Message == null)
                                                    {
                                                        Alerts.HideBusyLoader();
                                                        // lstTrackList = null;
                                                        replyResult = Constants.strSuccess;
                                                        LiveTrackingNotification();
                                                    }
                                                    else
                                                    {
                                                        CommanUtil.isTrackingClicked = false;
                                                        // lstTrackList = null;
                                                        replyResult = Constants.strException;
                                                        Utility.ErrorLog(replyResult, replyResult, CommanUtil.tokenNo, this);
                                                        //Alerts.HideBusyLoader();
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                CommanUtil.isTrackingClicked = false;
                                                Toast.MakeText(this, Constants.strEnableTracking, ToastLength.Long).Show();
                                            }
                                        }
                                    }
                                }
                                if (!CommanUtil.isTrackingClicked)
                                {
                                    localStorage.Edit().PutString("objTrackList", JsonConvert.SerializeObject(lstNewTrackList)).Commit();
                                    CommanUtil.isTrackingClicked = true;
                                    StartActivity(typeof(HomeActivity));
                                }
                            }
                        }
                        else
                        {
                            lstTrackList = null;
                        }
                    }
                    catch
                    {
                        Alerts.HideBusyLoader();
                        lstTrackList = null;
                        Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
                    }
                }
                else
                {
                    lstTrackList = null;
                }
            }
            else
            {
                CommanUtil.isTrackingClicked = false;
                Toast.MakeText(this, Constants.strEnableTracking, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// To initiate Live Tracking interval
        /// </summary>
        public async Task TrackingInterval()
        {
            bool taskEnable = true;
            while (taskEnable)
            {
                if (lstTrackList != null && !CommanUtil.isTrackingOn)
                {
                    await LiveTrackingInterval();
                    await Task.Delay(Constants.TrackingDelay); //Constants.TrackingDelay
                }
                else
                {
                    taskEnable = false;
                }

            }
        }

        /// <summary>
        /// Load Country Details
        /// </summary>
        public void GetCountryStateCode(string countryName, string stateName, out string newCountryCode, out string newStateCode)
        {
            newCountryCode = string.Empty;
            newStateCode = string.Empty;
            try
            {
                string countryCode = string.Empty;
                string stateCode = string.Empty;
                if (lstCountryDetails != null && lstCountryDetails.Count > 0)
                {
                    foreach (CountryDetails countryDetails in lstCountryDetails)
                    {
                        if (countryName.ToUpper().Equals(countryDetails.Name.ToUpper()))
                        {
                            countryCode = countryDetails.Code;
                        }
                        else if (countryName.ToUpper().Equals(countryDetails.Code.ToUpper()))
                        {
                            countryCode = countryDetails.Code;
                        }
                    }
                    //State
                    List<StateDetails> lstStateDetails = new List<StateDetails>();
                    for (int indexCountry = 0; indexCountry < lstCountryDetails.Count; indexCountry++)
                    {
                        if (countryCode.Equals(Convert.ToString(lstCountryDetails[indexCountry].Code)))
                        {
                            lstStateDetails = lstCountryDetails[indexCountry].States;
                        }
                    }
                    if (lstStateDetails != null && lstStateDetails.Count > 0)
                    {
                        foreach (StateDetails stateDetails in lstStateDetails)
                        {
                            if (stateName.ToUpper().Equals(Convert.ToString(stateDetails.Name.ToUpper())))
                            {
                                stateCode = stateDetails.Code;
                            }
                            else if (stateName.ToUpper().Equals(Convert.ToString(stateDetails.Code.ToUpper())))
                            {
                                stateCode = stateDetails.Code;
                            }
                        }
                    }
                    newCountryCode = countryCode;
                    newStateCode = stateCode;
                }
                else
                {
                    newCountryCode = countryCode;
                    newStateCode = stateCode;
                }
            }
            catch
            {
                Alerts.HideBusyLoader();
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
                Finish();
            }
        }

        /// <summary>
        /// Stop Tracking
        /// </summary>
        /// <returns></returns>
        private void StopTracking()
        {
            try
            {
                recentShipTrackList = localStorage.GetString("objTrackList", null);
                if (!string.IsNullOrEmpty(recentShipTrackList))
                {
                    lstNewTrackList = JsonConvert.DeserializeObject<List<TrackList>>(recentShipTrackList);
                }
                if (lstNewTrackList != null)
                {
                    for (int index = 0; index < lstNewTrackList.Count; index++)
                    {
                        if (lstNewTrackList[index].BolNum == objRecentShip.BolNum)
                        {
                            lstNewTrackList.Remove(lstNewTrackList[index]);
                            if (lstNewTrackList.Count == 0)
                            {
                                lstNewTrackList = null;
                            }
                            localStorage.Edit().PutString("objTrackList", JsonConvert.SerializeObject(lstNewTrackList)).Commit();
                            break;
                        }

                    }
                }
                objUtility = new Utility();
                denyDialog = objUtility.GetDialog(this, Constants.strDialogHdr, Constants.strStopTracking, Constants.btnTextYes, Constants.btnTextNo, string.Empty, ViewStates.Gone, ViewStates.Visible, ViewStates.Visible, ViewStates.Visible, ViewStates.Visible, ViewStates.Gone);
                StartActivity(typeof(HomeActivity));
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Get Selected Tracking Details for saving the details
        /// </summary>
        private void FnGetSelectedValue()
        {
            try
            {
                if (!chkLiveTrack.Checked && !chkAutoTrack.Checked)
                {
                    Toast.MakeText(this, Constants.strTracking, ToastLength.Long).Show();
                    return;
                }
                if (chkLiveTrack.Checked)
                {
                    foreach (KeyValuePair<string, string> kvpLiveTrack in CommanUtil.GetLiveTrackingElements())
                    {
                        if (spinnerLiveTrack.SelectedItem.ToString() == kvpLiveTrack.Value)
                        {
                            LiveTracking = Convert.ToInt32(kvpLiveTrack.Key);
                        }
                    }
                }
                else
                {
                    LiveTracking = 0;
                }
                if (chkAutoTrack.Checked)
                {
                    if (spinnerAutoTrack.SelectedItem.ToString().ToUpper() == Constants.strSameTacking.ToUpper())
                    {
                        AutoTracking = LiveTracking;
                    }
                    else
                    {
                        foreach (KeyValuePair<string, string> kvpAutoTrack in CommanUtil.GetLiveTrackingElements())
                        {
                            if (spinnerAutoTrack.SelectedItem.ToString() == kvpAutoTrack.Value)
                            {
                                AutoTracking = Convert.ToInt32(kvpAutoTrack.Key);
                            }
                        }
                    }
                }
                else
                {
                    AutoTracking = 0;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void LiveTrackingNotification()
        {
            // Pass the current button press count value to the next activity:
            Bundle valuesForActivity = new Bundle();
            valuesForActivity.PutInt("count", 1);

            // When the user clicks the notification, SecondActivity will start up.
            Intent resultIntent = new Intent(this, typeof(HomeActivity));

            // Pass some values to SecondActivity:
            resultIntent.PutExtras(valuesForActivity);

            // Construct a back stack for cross-task navigation:
            TaskStackBuilder stackBuilder = TaskStackBuilder.Create(this);
            stackBuilder.AddParentStack(Java.Lang.Class.FromType(typeof(HomeActivity)));
            stackBuilder.AddNextIntent(resultIntent);

            // Create the PendingIntent with the back stack:            
            PendingIntent resultPendingIntent =
                stackBuilder.GetPendingIntent(0, (int)PendingIntentFlags.UpdateCurrent);

            // Finally, publish the notification:
            // Build the notification:
            var notificationManager = (NotificationManager)GetSystemService(NotificationService);
        }
    }
}