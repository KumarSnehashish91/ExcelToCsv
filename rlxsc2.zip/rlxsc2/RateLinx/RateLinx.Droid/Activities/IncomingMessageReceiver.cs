using System;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Views;
using Android.Widget;
using Newtonsoft.Json;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;
using RateLinx.Models;

namespace RateLinx.Droid.Activities
{
    /// <summary>
    /// Sending message in a popup while application is in ForeGround
    /// </summary>
    [BroadcastReceiver(Enabled = true, Exported = false)]
    public class IncomingMessageReceiver : BroadcastReceiver
    {
        #region declaration of objects
        Activity activity;
        Utility objUtil;
        Dialog dialog;
        LoginModels objLogin;
        #endregion

        /// <summary>
        /// Calls when notification receives
        /// </summary>
        /// <param name="context"></param>
        /// <param name="intent"></param>
        public override void OnReceive(Context context, Intent intent)
        {
            try
            {
                if (intent.Action == Constants.strMessageReceiver)
                {
                    Bundle message = intent.GetBundleExtra("message");
                    //var data = intent.GetStringExtra("message").ToString();
                    activity = Utility.activity;
                    ShowPopup(message, activity);
                }
            }
            catch
            {
                 //Console.Write(Constants.strErrorOccured);
            }
        }

        /// <summary>
        /// Creating Dialog Or PopUp
        /// </summary>
        /// <param name="message"></param>
        /// <param name="context"></param>
        public void ShowPopup(Bundle message, Activity context)
        {
            try
            {
                if (Utility.notificationCount == 0)
                {
                    Utility.notificationCount = 1;
                    //using BrodCast = Android.Support.V4.Content;
                    objUtil = new Utility();
                    // Activity context;
                    dialog = objUtil.ConfirmationAlert(context);
                    Button btnYes = dialog.FindViewById<Button>(Resource.Id.btnYes);
                    Button btnNo = dialog.FindViewById<Button>(Resource.Id.btnNo);
                    LinearLayout lntlayoutReason = dialog.FindViewById<LinearLayout>(Resource.Id.lntlayoutReason);
                    btnYes.Text = Constants.btnTextYes;
                    btnNo.Text = /*Constants.btnTextCancel*/"No";
                    lntlayoutReason.Visibility = ViewStates.Gone;
                    TextView txtMessage = dialog.FindViewById<TextView>(Resource.Id.txtMessage);
                    //Fill All The Details
                    string clientID = string.Empty;
                    string loadNum = string.Empty;
                    string slideNo = string.Empty;
                    string url = string.Empty;

                    if(!string.IsNullOrEmpty(Constants.notificationMsg))
                    {
                        txtMessage.Text = Constants.notificationMsg;


                        //if(txtMessage.Text.Contains("award") || txtMessage.Text.Contains("unaward") || txtMessage.Text.Contains("assined as the driver"))
                        //{
                        //    btnYes.Text = "OK";
                        //    btnNo.Visibility = ViewStates.Gone;
                        //}
                        if(txtMessage.Text.Contains("New TRUCKLOAD"))
                        {
                            txtMessage.Text += "." + "\n" + "Do you wish to go to shipment detail screen? ";
                            btnYes.Text = "Yes";
                        }
                        else
                        {
                            btnYes.Text = "OK";
                            btnNo.Visibility = ViewStates.Gone;
                        }
                    }

                    if(message !=null)
                    {
                        url= message.GetString("url");
                    }
                    if (!string.IsNullOrEmpty(url))
                    {
                        txtMessage.Text = message.GetString("message"); //message
                        if (txtMessage.Text.Contains("New TRUCKLOAD"))
                        {
                            txtMessage.Text += "." + "\n" + "Do you wish to go to shipment detail screen? ";
                            btnYes.Text = "Yes";
                        }
                        else
                        {
                            btnYes.Text = "OK";
                            btnNo.Visibility = ViewStates.Gone;
                        }
                        clientID = url.Split('#')[2];
                        loadNum = url.Split('#')[1];
                        slideNo = url.Split('#')[3];
                    }
                    //If Click on Yes
                    btnYes.Click += delegate
                    {
                        if (btnYes.Text == "OK")
                        {
                            dialog.Hide();
                        }
                        else
                        {

                            string compositValue = clientID + "|" + loadNum + "|" + slideNo;
                            string compositekey = "compositeKey";
                            string isLogin = CommanUtil.tokenNo;
                            string postData = Utility.sharedPreferences.GetString(Constants.userCredential, null);
                            if (!string.IsNullOrEmpty(postData))
                            {
                                Utility.sharedPreferences.Edit().PutString("notification_compositekey", compositValue).Commit();
                                objLogin = JsonConvert.DeserializeObject<LoginModels>(postData);
                                if (objLogin != null && objLogin.IsRemember)
                                {
                                    Intent objIntent = new Intent(context, typeof(ShipmentsDetailedActivity));
                                    objIntent.PutExtra(compositekey, compositValue);
                                    context.StartActivity(objIntent);
                                }
                                else
                                {
                                    
                                    if (objLogin != null && !string.IsNullOrEmpty(CommanUtil.ViewAs))
                                    {
                                        Intent objIntent = new Intent(context, typeof(ShipmentsDetailedActivity));
                                        objIntent.PutExtra(compositekey, compositValue);
                                        context.StartActivity(objIntent);
                                    }
                                    //context.Finish();
                                    //Intent objIntent = new Intent(context, typeof(LoginActivity));
                                    //objIntent.PutExtra(compositekey, compositValue);
                                    //context.StartActivity(objIntent);
                                    //Toast.MakeText(context, compositValue, ToastLength.Long).Show();

                                }
                                dialog.Hide();

                            }


                            //        if (!string.IsNullOrEmpty(isLogin))
                            //{
                               
                            //}
                            
                        }
                    };

                    btnNo.Click += delegate
                    {
                        dialog.Hide();
                    };
                }
            }
            catch
            {
                //Console.Write(Constants.strErrorOccured);
            }
        }
    }
}