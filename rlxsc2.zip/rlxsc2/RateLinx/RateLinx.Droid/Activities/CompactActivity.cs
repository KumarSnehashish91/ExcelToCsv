using System;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Support.V7.App;
using RateLinx.Droid.Utilities;
using BrodCast = Android.Support.V4.Content;
using RateLinx.Helper;
using Android.Support.V4.Content;
using System.Security;
using Android.Widget;

namespace RateLinx.Droid.Activities
{
    /// <summary>
    /// Meta tag of the class
    /// </summary>
    [SecurityCritical]
    [Activity(Label = "AppCompactActivity")]
    public class CompactActivity : AppCompatActivity
    {
        /// <summary>
        /// 
        /// </summary>
        public static AppCompatActivity activity;
        IncomingMessageReceiver receiver;

        /// <summary>
        /// On Ready Method
        /// </summary>
        /// <param name="savedInstanceState"></param>
        [SecurityCritical]
        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);
                Utility.activity = this;
                Utility.ExpireSession(this);
                receiver = new IncomingMessageReceiver();
                LocalBroadcastManager.GetInstance(this).RegisterReceiver(receiver, new IntentFilter(Constants.strMessageReceiver));
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Destroy the Page instance
        /// </summary>
        [SecurityCritical]
        protected override void OnDestroy()
        {
            try
            {
                base.OnDestroy();
                BrodCast.LocalBroadcastManager.GetInstance(this).UnregisterReceiver(receiver);
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }
    }
}