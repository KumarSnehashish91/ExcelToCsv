using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Views;
using Android.Widget;
using Android.Gms.Maps;
using Android.Gms.Maps.Model;
using Android.Locations;
using System.Threading.Tasks;
using RateLinx.Helper;
using RateLinx.APIs;
using Newtonsoft.Json;
using RateLinx.Models;
using RateLinx.Droid.Utilities;
using RateLinx.Droid.GoogleMapServices;
using Newtonsoft.Json.Linq;

namespace RateLinx.Droid.Activities
{
    /// <summary>
    /// Shipment Tracking While click on find Current Location of shipment
    /// </summary>
    [Activity(Label = "ShipmentTracking", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class ShipmentTracking : HeaderActivity
    {
        #region Global Used variables
        GoogleMap map = null;
        Geocoder geocoder = null;
        MapFragment mapFrag = null;
        string _address = string.Empty;
        string compositeKey = string.Empty;
        string tokenNo = string.Empty;
        string methodName = string.Empty;
        string response = string.Empty;
        TrackShipment trackingDetail = null;
        string[] trackingId = null;
        ServiceHelper objHelper = null;
        TrackLocation objLocation = null;
        string bolNum = string.Empty;
        string ReportedBy = string.Empty;
        string ReportedAt = string.Empty;
        string addressType = string.Empty;
        double lati = 28.6214277;
        double longi = 77.378962;
        IList<Android.Locations.Address> addressList = null;
        Android.Locations.Address addressCurrent = null;
        StringBuilder deviceAddress = null;
        JObject jobject = null;
        #endregion

        /// <summary>
        /// On Load Event of Shipment Tracking Layout
        /// </summary>
        /// <param name="savedInstanceState"></param>
        protected override async void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);
                //Remove Header Title
                if (string.IsNullOrEmpty(CommanUtil.tokenNo))
                {
                    Utility.Logout(this);
                }
                RequestWindowFeature(WindowFeatures.NoTitle);
                SetContentView(Resource.Layout.ShipmentTracking);//Designed Layou
                // Create your application here
                mapFrag = (MapFragment)FragmentManager.FindFragmentById(Resource.Id.map);
                LinearLayout lnrLayoutBackIcon = FindViewById<LinearLayout>(Resource.Id.lnrLayoutBackIcon);
                lnrLayoutBackIcon.Click += LnrLayoutBackIcon_Click;
                ImageView ImgBackIcon = FindViewById<ImageView>(Resource.Id.imgBackIcon);
                ImgBackIcon.Click += ImgBackIcon_Click;
                //Test Internet Connection
                if (!Utility.FnIsOnline(this))
                {
                    Alerts.HideBusyLoader();
                    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                else
                {
                    //First Get the shipment details 
                    if (CommanUtil.IsTimeOut())
                    {
                        await TrackShipment();
                    }
                    else
                    {
                        //Toekn Exired
                        Utility.ExpireSession(this);
                    }
                }
            }
            catch
            {
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Short).Show();
            }
        }

        /// <summary>
        /// Back Icon
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgBackIcon_Click(object sender, EventArgs e)
        {
            Finish();
        }

        /// <summary>
        /// Back Button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LnrLayoutBackIcon_Click(object sender, EventArgs e)
        {
            Finish();
        }

        /// <summary>
        /// On Map Ready Pass respective Latitude and Langitude
        /// </summary>
        /// <param name="googleMap"></param>
        public void plotMap(GoogleMap googleMap)
        {
            try
            {
                if (!Utility.FnIsOnline(this))
                {
                    Alerts.HideBusyLoader();
                    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                this.map = googleMap;
                map.MyLocationEnabled = true;
                map.UiSettings.ZoomControlsEnabled = true;
                map.UiSettings.MyLocationButtonEnabled = true;
                map.UiSettings.RotateGesturesEnabled = true;
                map.UiSettings.ZoomGesturesEnabled = true;
                Android.Gms.Maps.Model.LatLng srcLatlng = new Android.Gms.Maps.Model.LatLng(lati, longi);
                CameraUpdate camera = CameraUpdateFactory.NewLatLngZoom(srcLatlng, 5);
                map.MoveCamera(camera);
                //Marker options
                MarkerOptions source = new MarkerOptions().SetPosition(srcLatlng).SetTitle(objLocation.addressType);
                source.SetSnippet(objLocation.address);
                map.AddMarker(source);

            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Track shipment Address
        /// </summary>
        /// <returns></returns>
        private async Task TrackShipment()
        {
            try
            {
                Alerts.showBusyLoader(this);
                compositeKey = Intent.GetStringExtra("compositeKey");
                trackingId = compositeKey.Split('#');
                string routeFrom = trackingId[1];
                tokenNo = CommanUtil.tokenNo;
                if (routeFrom == Constants.strTrackAll)
                {
                    await GetTrackingPositions();
                }
                else
                {
                    response = await GetSpecTrackingPosition();
                    if (string.IsNullOrEmpty(response))
                    {
                        Alerts.HideBusyLoader();
                        return;
                    }
                }
                //Displaying Map after getting the details
                var mapReadyCallback = new OnMapReadyClass();
                mapReadyCallback.MapReadyAction += delegate (GoogleMap objMap)
                {
                    map = objMap;
                    plotMap(map); //Plot Map
                };
                mapFrag.GetMapAsync(mapReadyCallback);
                Alerts.HideBusyLoader();
            }
            catch
            {
                Alerts.HideBusyLoader();
                throw;
            }
        }

        /// <summary>
        /// Date And Time And Days Calculation
        /// </summary>
        /// <param name="reportedAtDate"></param>
        /// <returns></returns>
        private string getDateTime(string reportedAtDate)
        {
            try
            {
                string[] bidDeadLine = reportedAtDate.Split('T');
                DateTime currentDate = DateTime.Parse(bidDeadLine[0] + " " + bidDeadLine[1]);
                string currMonth = (currentDate.Month + 1) < 10 ? "0" + Convert.ToString(currentDate.Month + 1) : Convert.ToString(currentDate.Month + 1);  //((currentDate.GetMonth() + 1)) < 10 ? "0" + (currentDate.getMonth() + 1) : (currentDate.getMonth() + 1);
                string currDate = (currentDate.Day) < 10 ? "0" + Convert.ToString(currentDate.Day) : Convert.ToString(currentDate.Day);
                string ActiveDate = currMonth + '-' + currDate + '-' + currentDate.Year;
                string hours = (currentDate.Hour) < 10 ? "0" + Convert.ToString(currentDate.Hour) : Convert.ToString(currentDate.Hour);
                string min = (currentDate.Minute) < 10 ? "0" + Convert.ToString(currentDate.Minute) : Convert.ToString(currentDate.Minute);
                string ActiveTime = hours + ":" + min;
                return ActiveDate + " " + ActiveTime;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Track All Shipment
        /// </summary>
        /// <returns></returns>
        private async Task GetTrackingPositions()
        {
            try
            {
                if (!Utility.FnIsOnline(this))
                {
                    Alerts.HideBusyLoader();
                    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                methodName = APIMethods.trackingPositions;
                objHelper = new ServiceHelper();
                response = await objHelper.GetRequest(tokenNo, methodName, true);
                if (!string.IsNullOrEmpty(response))
                {
                    jobject = JObject.Parse(response);
                    if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
                    {
                        trackingDetail = JsonConvert.DeserializeObject<TrackShipment>(response);
                        //Get the details of shipment and trying to show in map
                        string city = string.Empty;
                        string state = string.Empty;
                        string country = string.Empty;
                        string activityDescr = string.Empty;
                        objLocation = new TrackLocation();
                        for (int index = 0; index < trackingDetail.ShipmentPos.Count; index++)
                        {
                            city = trackingDetail.ShipmentPos[index].Positions[0].City;
                            state = trackingDetail.ShipmentPos[index].Positions[0].State;
                            country = trackingDetail.ShipmentPos[index].Positions[0].Country;
                            bolNum = trackingDetail.ShipmentPos[index].BolNum;
                            ReportedBy = trackingDetail.ShipmentPos[index].Positions[index].ReportedBy;
                            ReportedAt = getDateTime(trackingDetail.ShipmentPos[index].Positions[index].ReportedAt);
                            activityDescr = trackingDetail.ShipmentPos[index].Positions[index].ActivityDescr;
                            addressType = bolNum + "~" + ReportedBy + "~" + ReportedAt + "~" + activityDescr;
                            objLocation.address = city + " " + state + " " + country;//Update Address
                            geocoder = new Geocoder(this);
                            //Get Lat And Long from Address
                            var orgAddress = geocoder.GetFromLocationName(objLocation.address, 5);
                            foreach (var location in orgAddress)
                            {
                                lati = location.Latitude;
                                longi = location.Longitude;
                            }
                            //Get the Address Details from Lat And Long
                            addressList = geocoder.GetFromLocation(lati, longi, 5);
                            addressCurrent = addressList.FirstOrDefault();
                            if (addressCurrent != null)
                            {
                                deviceAddress = new StringBuilder();
                                for (int addIndex = 0; addIndex < addressCurrent.MaxAddressLineIndex; addIndex++)
                                    deviceAddress.Append(addressCurrent.GetAddressLine(addIndex))
                                        .AppendLine(",");
                                _address = deviceAddress.ToString();//Get Address 
                                objLocation.addressType = _address;
                            }
                            else
                            {
                                Toast.MakeText(this, GetString(Resource.String.trackLocation), ToastLength.Long).Show();
                            }
                        }
                    }
                    else
                    {
                        response = string.Empty;
                        Toast.MakeText(this, Convert.ToString(jobject[Constants.strErrorMessage]), ToastLength.Long).Show();
                        //Post Error Logger Request 
                        Utility.ErrorLog(Constants.strLiveTrack, Convert.ToString(jobject[Constants.strErrorMessage]), CommanUtil.tokenNo, this);
                    }
                }
                else
                {
                    Toast.MakeText(this, GetString(Resource.String.trackShipment), ToastLength.Long).Show();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Track Perticular Shipment
        /// </summary>
        /// <returns></returns>
        private async Task<string> GetSpecTrackingPosition()
        {
            string result = string.Empty;
            try
            {
                if (!Utility.FnIsOnline(this))
                {
                    Alerts.HideBusyLoader();
                    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    return result;
                }
                methodName = APIMethods.specTrackingPosition + trackingId[0];
                objHelper = new ServiceHelper();
                response = await objHelper.GetRequest(tokenNo, methodName, true);
                if (!string.IsNullOrEmpty(response))
                {
                    jobject = JObject.Parse(response);
                    if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
                    {
                        trackingDetail = JsonConvert.DeserializeObject<TrackShipment>(response);
                        if (!string.IsNullOrEmpty(trackingDetail.ShipmentPos[0].ErrorMsg))
                        {
                            Toast.MakeText(this, trackingDetail.ShipmentPos[0].ErrorMsg, ToastLength.Long).Show();
                            return result;
                        }
                        else
                        {
                            //Get the details of shipment and trying to show in map
                            objLocation = new TrackLocation();
                            for (int index = 0; index < trackingDetail.ShipmentPos.Count; index++)
                            {
                                string city, Country, State = string.Empty;
                                bolNum = trackingDetail.ShipmentPos[index].BolNum;
                                if (trackingDetail.ShipmentPos[index].Positions[index] != null)
                                {
                                    ReportedBy = trackingDetail.ShipmentPos[index].Positions[index].ReportedBy;
                                    ReportedAt = getDateTime(trackingDetail.ShipmentPos[index].Positions[index].ReportedAt);
                                    lati = trackingDetail.ShipmentPos[index].Positions[index].Latitude;
                                    longi = trackingDetail.ShipmentPos[index].Positions[index].Longitude;
                                    city = trackingDetail.ShipmentPos[index].Positions[index].City;
                                    State = trackingDetail.ShipmentPos[index].Positions[index].State;
                                    Country = trackingDetail.ShipmentPos[index].Positions[index].Country;
                                    addressType = city + " " + State + " " + Country;
                                }
                                else
                                {
                                    addressType = "United State Denver";
                                }
                                objLocation.addressType = addressType;
                                //Find Location Details from Lat And Long
                                geocoder = new Geocoder(this);
                                Android.Gms.Maps.Model.LatLng latLng = null;
                                var sourceAddress = await geocoder.GetFromLocationNameAsync(addressType, 1);
                                sourceAddress.ToList().ForEach((addr) =>
                                {
                                    latLng = new Android.Gms.Maps.Model.LatLng(addr.Latitude, addr.Longitude);
                                    lati = addr.Latitude;
                                    longi = addr.Longitude;
                                });
                                addressList = geocoder.GetFromLocation(latLng.Latitude, latLng.Longitude, 5);
                                addressCurrent = addressList.FirstOrDefault();
                                if (addressCurrent != null)
                                {
                                    deviceAddress = new StringBuilder();
                                    for (int addIndex = 0; addIndex < addressCurrent.MaxAddressLineIndex; addIndex++)
                                        deviceAddress.Append(addressCurrent.GetAddressLine(addIndex))
                                            .AppendLine(",");
                                    _address = deviceAddress.ToString();//Get Address 
                                    string strAddress = _address.Replace('\n', ' ');
                                    objLocation.address = strAddress;//Update Address in List for further use
                                }
                                else
                                {
                                    Toast.MakeText(this, GetString(Resource.String.trackLocation), ToastLength.Long).Show();
                                }
                            }
                            return bolNum;
                        }
                    }
                    else
                    {
                        response = string.Empty;
                        Toast.MakeText(this, Convert.ToString(jobject[Constants.strErrorMessage]), ToastLength.Long).Show();
                        //Post Error Logger Request 
                        Utility.ErrorLog(Constants.strLiveTrack, Convert.ToString(jobject[Constants.strErrorMessage]), CommanUtil.tokenNo, this);
                        return result;
                    }
                }
                else
                {
                    Toast.MakeText(this, GetString(Resource.String.trackShipment), ToastLength.Long).Show();
                    return result;
                }
            }
            catch
            {
                Toast.MakeText(this, GetString(Resource.String.trackShipment), ToastLength.Long).Show();
                return result;
            }
        }
    }
}
