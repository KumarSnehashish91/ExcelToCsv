﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Android;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Graphics;
using Android.Locations;
using Android.OS;
using Android.Provider;
using Android.Runtime;
using Android.Support.V4.Content;
using Android.Views;
using Android.Widget;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RateLinx.APIs;
using RateLinx.Droid.FileHelper;
using RateLinx.Droid.GoogleMapServices;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;
using RateLinx.Models;
using Xamarin.Controls;
using URI = Android.Net;


using Android.Support.V4.App;

namespace RateLinx.Droid.Activities
{
    /// <summary>
    /// Meta Tab of Confiration Activity
    /// </summary>
    [Activity(Label = "ConfirmationDetailActivity", Theme = "@style/Theme.AppCompat.NoActionBar", ConfigurationChanges = ConfigChanges.Orientation | ConfigChanges.ScreenSize)]
    public class ConfirmationDetailActivity : HeaderActivity
    {
        #region Declaration of controls instances and variables 
        //JavaFile file = null;
        byte[] bytes = null;
        string stopCountForConfirmtion = string.Empty;
        ServiceHelper objServiceHelper = null;
        List<CountryDetails> lstCountryDetails = null;
        List<StateDetails> lstStateDetails = null;
        EditText txtActivityDate, txtActivityTime, txtProNumber, txtCity;
        TextView textFileName;
        CheckBox chkTrackDetails;
        LinearLayout lnrTrackDetails, lnrCheckBoxLayout, linearLayout1, linearLayout3, lnrRadio;
        SignaturePadView objSignaturePadView;
        Button btnSubmitDetails, btnResetSign;
        Spinner spinnerState, spinnerCountry, spinnerDescription;

        List<string> lstStates = null;
        List<string> lstStateCodes = null;
        List<string> lstCountries = null;
        List<string> lstCountryCodes = null;
        List<TrackingDesc> lstTrackingDesc = null;
        int descriptionIndex = 0;
        double currentLat = 0.00;
        double currentLong = 0.00;
        string token = string.Empty;
        JObject jobject = null;
        TimePickerDialog timePick = null;
        string[] activityDate = null;
        string newActivityDate, ActivityDate, activityTime
           , strBase64String, payload_str, countryName,
            postDataJson, payloadReturn, AMPM, parameters
            = string.Empty;
        DateTime today = DateTime.Now;
        DatePickerDialog dialog = null;
        ArrayAdapter adapter = null;
        string apiMethod = string.Empty;
        Bitmap objBitmap = null;
        string shipmentDetails = string.Empty;
        string country = string.Empty;
        //ListView lstViewFiles = null;
        string state, response, ConfType, strConfValue = string.Empty;
        CarrierShipmentDetails carrierShipmentDetail = null;
        GPSServiceSettings objGPSServiceSettings = null;
        Utility objUtility;
        ImageView imgClosePage, imgViewCamera;
        TextView txtHeaderLabel;
        RadioButton rdbtn_Signature, rdbtn_Picture;
        TextView txtDialogHeader;
        FileUploadHelper objFileHelper = null;
        List<string> objFileList = null;
        Intent imageIntent = null;
        string requiredMessage = string.Empty;
        int uploadIdentifier = 0;
        CarrierShipmentDetails lstShipmentDetail = null;
        readonly string[] cameraPermission =
                        {
         Manifest.Permission.WriteExternalStorage,
         Manifest.Permission.Camera};
        URI.Uri selectedURI = null;
        Bitmap bitmapImage = null;
        CommanUtil commanUtil;

        #endregion

        /// <summary>
        /// On Create method to get all the details of layout page
        /// </summary>
        /// <param name="savedInstanceState"></param>
        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);
                commanUtil = new CommanUtil();
                requiredMessage = Constants.signatureRequired;
                // Create your application here
                // Set our view from the "Startup Page" layout resource
                SetContentView(Resource.Layout.ConfirmationForDetails);
                if (string.IsNullOrEmpty(CommanUtil.tokenNo))
                {
                    Utility.Logout(this);
                }
                this.Window.SetSoftInputMode(SoftInput.StateAlwaysHidden);
                objGPSServiceSettings = new GPSServiceSettings();
                objUtility = new Utility();
                token = CommanUtil.tokenNo;
                GetControlById();
                GetShipmentDetailFromSharedPref();

            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, ex.Message, ToastLength.Long).Show();
            }
        }
        /// <summary>
        /// 
        /// </summary>
        protected override void OnDestroy()
        {
            base.OnDestroy();
            stopCountForConfirmtion = string.Empty;
        }
        /// <summary>
        /// Get Controls By Element Id and controls Event
        /// </summary>
        public async Task GetControlById()
        {
            try
            {
                shipmentDetails = Utility.sharedPreferences.GetString(Constants.shipmentDetails, null);
                if (!string.IsNullOrEmpty(shipmentDetails))
                {
                    carrierShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(shipmentDetails);
                }
                lnrRadio = FindViewById<LinearLayout>(Resource.Id.lnrRadio);
                linearLayout1 = FindViewById<LinearLayout>(Resource.Id.linearLayout1);
                linearLayout3 = FindViewById<LinearLayout>(Resource.Id.linearLayout3);
                imgViewCamera = FindViewById<ImageView>(Resource.Id.imgViewCamera);
                rdbtn_Picture = FindViewById<RadioButton>(Resource.Id.rdbtn_Picture);
                rdbtn_Signature = FindViewById<RadioButton>(Resource.Id.rdbtn_Signature);
                txtHeaderLabel = FindViewById<TextView>(Resource.Id.txtHeaderLabel);
                imgClosePage = FindViewById<ImageView>(Resource.Id.imgClosePage);
                txtDialogHeader = FindViewById<TextView>(Resource.Id.txtDialogHeader);
                chkTrackDetails = FindViewById<CheckBox>(Resource.Id.chkTrackDetails);
                lnrTrackDetails = FindViewById<LinearLayout>(Resource.Id.lnrTrackDetails);
                lnrCheckBoxLayout = FindViewById<LinearLayout>(Resource.Id.lnrCheckBoxLayout);
                btnSubmitDetails = FindViewById<Button>(Resource.Id.btnSubmitDetails);
                btnResetSign = FindViewById<Button>(Resource.Id.btnResetSign);
                objSignaturePadView = FindViewById<SignaturePadView>(Resource.Id.signaturePadView1);
                objSignaturePadView.SignaturePromptText = "";
                spinnerState = FindViewById<Spinner>(Resource.Id.spinnerState);
                spinnerCountry = FindViewById<Spinner>(Resource.Id.spinnerCountry);
                spinnerDescription = FindViewById<Spinner>(Resource.Id.spinnerDescription);
                spinnerDescription.Enabled = false;
                spinnerDescription.Clickable = false;
                txtActivityDate = FindViewById<EditText>(Resource.Id.txtActivityDate);
                txtActivityTime = FindViewById<EditText>(Resource.Id.txtActivityTime);
                txtProNumber = FindViewById<EditText>(Resource.Id.txtProNumber);
                txtCity = FindViewById<EditText>(Resource.Id.txtCity);
                if (carrierShipmentDetail != null)
                {
                    txtProNumber.Text = carrierShipmentDetail.ProNum;
                }
                txtActivityTime.Click += (sender, e) =>
                {
                    this.Window.SetSoftInputMode(SoftInput.StateAlwaysHidden);
                    timePick = new TimePickerDialog(this, ActivityTimePicker, DateTime.Now.Hour, DateTime.Now.Hour, true);
                    timePick.Show();
                };
                txtActivityDate.Click += (sender, e) =>
                {
                    this.Window.SetSoftInputMode(SoftInput.StateAlwaysHidden);
                    today = DateTime.Today;
                    dialog = new DatePickerDialog(this, ActivityDatePicker, today.Year, today.Month - 1, today.Day);
                    dialog.DatePicker.MinDate = today.Millisecond;
                    dialog.Show();
                };
                btnResetSign.Click += delegate
                {
                    objSignaturePadView.Clear();
                    imgViewCamera.SetImageResource(Resource.Drawable.img_camera);
                    bitmapImage = null;
                };
                btnSubmitDetails.Click += async delegate
                 {
                     if (CommanUtil.IsTimeOut())
                     {
                         if (CommanUtil.shipmentType == Constants.dispatcher)
                         {
                             await SubmitSignOnly();
                         }
                         else
                         {
                             if (chkTrackDetails.Checked == false)
                             {
                                 await SubmitSignOnly();
                             }
                             else
                             {
                                 await SubmitSignWithDetails();
                             }
                         }
                     }
                     else
                     {
                         Utility.ExpireSession(this);
                     }
                 };
                rdbtn_Signature.Click += rdbtn_Signature_Click;
                if (rdbtn_Signature.Checked == true)
                {
                    txtHeaderLabel.Text = "Sign Here:";
                }
                imgViewCamera.Click += imgViewCamera_Click;
                rdbtn_Picture.Click += rdbtn_Picture_Click;
                imgClosePage.Click += ImgClosePage_Click;
                lnrTrackDetails.Visibility = ViewStates.Gone;
                chkTrackDetails.CheckedChange += ChkTrackDetails_CheckedChange;
                lstTrackingDesc = CommanUtil.TrackingDescList();
                spinnerDescription.SetBackgroundColor(Color.Gray);
                if (CommanUtil.shipmentType == Constants.dispatcher)
                {
                    lnrCheckBoxLayout.Visibility = ViewStates.Gone;
                }
                else
                {
                    lnrCheckBoxLayout.Visibility = ViewStates.Visible;
                }
                if (carrierShipmentDetail.IsMultiStop)
                {
                    stopCountForConfirmtion = commanUtil.multiStopTracking(carrierShipmentDetail);
                }
                GetIntentData();
                await InitializeLocationManager();
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void imgViewCamera_Click(object sender, EventArgs e)
        {
            try
            {
                if ((ContextCompat.CheckSelfPermission(this, Manifest.Permission.Camera) == (int)Permission.Granted) &&
                        (ContextCompat.CheckSelfPermission(this, Manifest.Permission.WriteExternalStorage) == (int)Permission.Granted))
                {
                    ConfirmationAlert("What you want to do?");
                }
                else
                {
                    //ActivityCompat.RequestPermissions(this, cameraPermission, 0);
                    AlertDialog.Builder alert = new AlertDialog.Builder(this);
                    alert.SetTitle("Warning");
                    alert.SetMessage("Allow Ratelinx to use your camera");
                    alert.SetPositiveButton("Go to Setting", (senderAlert, args) =>
                    {
                        StartActivity(new Intent(Android.Provider.Settings.ActionApplicationDetailsSettings, Android.Net.Uri.Parse("package:" + Android.App.Application.Context.PackageName)));
                    });
                    alert.SetNegativeButton("Cancel", (senderAlert, args) =>
                    {
                    });
                    Dialog dialog = alert.Create();
                    dialog.Show();
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }

        }
        /// <summary>
        /// Get shipment detail data from shared preference
        /// </summary>
        private void GetShipmentDetailFromSharedPref()
        {
            string shipmentResponse = Utility.sharedPreferences.GetString(Constants.shipmentDetails, null);
            if (!string.IsNullOrEmpty(shipmentResponse))
            {
                lstShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(shipmentResponse);

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="confirmationMsg"></param>
        public void ConfirmationAlert(string confirmationMsg)
        {
            objUtility = new Utility();
            string dialogHeader = Constants.strUploadImage;
            Dialog dialogUpload = objUtility.GetUploadDialog(this, dialogHeader, "Upload Picture",
           Constants.btnTextTakePicture, Constants.btnTextCancel, ViewStates.Visible,
          ViewStates.Gone, ViewStates.Visible,
           ViewStates.Visible, ViewStates.Gone);

            Button btnTakePicture = dialogUpload.FindViewById<Button>(Resource.Id.btnTakePicture);
            Button btnUploadImage = dialogUpload.FindViewById<Button>(Resource.Id.btnUpload);

            TextView txtViewClose = dialogUpload.FindViewById<TextView>(Resource.Id.txtViewClose);
            btnTakePicture.Click += delegate
            {
                try
                {
                    dialogUpload.Hide();
                    TakePhotoByCamera();
                }
                catch (Exception ex)
                {
                    Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                }
            };
            btnUploadImage.Click += delegate
            {
                dialogUpload.Hide();
                ConfirmationUploadDialog();

            };
            txtViewClose.Click += delegate
            {

                dialogUpload.Hide();
                return;
            };

            objUtility = null;
        }

        /// <summary>
        /// 
        /// </summary>
        public void TakePhotoByCamera()
        {
            uploadIdentifier = 1;
            string timeStamp = "1221221";
            StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
            StrictMode.SetVmPolicy(builder.Build());
            Java.IO.File dir = new Java.IO.File(Android.OS.Environment
              .GetExternalStoragePublicDirectory(Android.OS.Environment.DirectoryPictures), "photo_" + timeStamp + ".png");
            selectedURI = Android.Net.Uri.FromFile(dir);
            Intent i = new Intent(MediaStore.ActionImageCapture);
            i.PutExtra(MediaStore.ExtraOutput, selectedURI);
            StartActivityForResult(i, 1);
        }


        /// <summary>
        /// 
        /// </summary>
        protected void ConfirmationUploadDialog()
        {
            try
            {
                uploadIdentifier = 2;
                objUtility = new Utility();
                string dialogHeader = Constants.strUploadImage;
                Dialog dialogUpload = objUtility.GetUploadDialog(this, dialogHeader, "Upload Picture",
                    Constants.btnTextTakePicture, Constants.btnTextCancel, ViewStates.Gone,
                   ViewStates.Gone, ViewStates.Visible,
                    ViewStates.Visible, ViewStates.Visible);
                Button fileUpload = dialogUpload.FindViewById<Button>(Resource.Id.fileUpload);
                Button btnUploadFile = dialogUpload.FindViewById<Button>(Resource.Id.btnUploadFile);
                TextView txtViewClose = dialogUpload.FindViewById<TextView>(Resource.Id.txtViewClose);
                textFileName = dialogUpload.FindViewById<TextView>(Resource.Id.textFileName);
                fileUpload.Click += delegate
                {
                    dialogUpload.Hide();
                    FileUpload_Click();
                };
                btnUploadFile.Click += BtnUploadFile_Click;

                txtViewClose.Click += delegate
                {

                    dialogUpload.Hide();
                    return;
                };

                objUtility = null;
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
            }
        }

        /// <summary>
        /// Browser button for selecting file
        /// </summary>
        private void FileUpload_Click()
        {
            try
            {
                imageIntent = new Intent(Intent.ActionPick, Android.Provider.MediaStore.Images.Media.ExternalContentUri);
                imageIntent.SetType("*/*");
                imageIntent.PutExtra("return-data", true);
                imageIntent.SetAction(Intent.ActionGetContent);
                StartActivityForResult(
                    Intent.CreateChooser(imageIntent, Constants.strSelectFile), 0);
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void BtnUploadFile_Click(object sender, EventArgs e)
        {
            try
            {
                if (CommanUtil.IsTimeOut())
                {
                    if (bytes != null)
                    {
                        Alerts.showBusyLoader(this);
                        string jsonRequest = string.Empty;
                        objServiceHelper = new ServiceHelper();
                        string uploadResult = await UploadBitmapAsync(bytes);
                        if (uploadResult != null)
                        {
                            jobject = JObject.Parse(uploadResult);
                            if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
                            {
                                //File Response will post in another API
                                jsonRequest = FileUploadHelper.UploadsJsonRequest(uploadResult);
                                apiMethod = APIMethods.shipmentDetails + "/" + lstShipmentDetail.ClientID + "|" + lstShipmentDetail.LocID + "|" + lstShipmentDetail.BolNum + "/supportfile";
                                //Requesting To Other API
                                jsonRequest = "{\"Files\":[" + jsonRequest + "]}";
                                string fileResult = await objServiceHelper.PostRequestJson(jsonRequest, apiMethod, token, true);
                                if (fileResult != null)
                                {
                                    objFileList = JsonConvert.DeserializeObject<List<string>>(fileResult);
                                    apiMethod = APIMethods.shipmentDetails + "/" + lstShipmentDetail.ClientID + "|" + lstShipmentDetail.BolNum;
                                    await objUtility.BindShipmentDetail(apiMethod, this);//Refresh shipment detail data
                                    //BindFiles(objFileList); //Re-binding List of files
                                    textFileName.Text = "";
                                    bytes = null;
                                    Alerts.HideBusyLoader();
                                }
                                else
                                {
                                    Alerts.HideBusyLoader();
                                    Toast.MakeText(this, Constants.strNoFile, ToastLength.Long).Show();
                                }
                            }
                            else
                            {
                                Alerts.HideBusyLoader();
                                Toast.MakeText(this, Convert.ToString(jobject[Constants.strErrorMessage]), ToastLength.Long).Show();
                                Utility.ErrorLog(Constants.strSupporting, Convert.ToString(jobject[Constants.strErrorMessage]), CommanUtil.tokenNo, this);
                            }
                        }
                        else
                        {
                            Alerts.HideBusyLoader();
                            Toast.MakeText(this, Constants.strFileLength, ToastLength.Long).Show();
                        }
                    }
                    else
                    {
                        Alerts.HideBusyLoader();
                        Toast.MakeText(this, Resources.GetString(Resource.String.choosFile), ToastLength.Long).Show();
                    }
                }
                else
                {
                    //Token Exired 
                    Utility.ExpireSession(this);
                }
            }
            catch (Exception ex)
            {
                Alerts.HideBusyLoader();
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Resources.GetString(Resource.String.choosFile), ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// File upload
        /// </summary>
        /// <param name="bytes">File will be in bytes</param>
        /// <returns></returns>
        public async Task<string> UploadBitmapAsync(byte[] bytes)
        {
            try
            {
                objFileHelper = new FileUploadHelper();
                apiMethod = APIMethods.supportfile;
                var response = await objFileHelper.PostFiles(bytes, null, apiMethod, token, true);
                return response;
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="requestCode"></param>
        /// <param name="resultCode"></param>
        /// <param name="data"></param>
        protected override void OnActivityResult(int requestCode, [GeneratedEnum] Result resultCode, Intent data)
        {
            base.OnActivityResult(requestCode, resultCode, data);
            try
            {
                base.OnActivityResult(requestCode, resultCode, data);
                if (resultCode == Result.Canceled)
                    return;
                if (resultCode == Result.Ok)
                {

                    if (uploadIdentifier == Constants.int1)
                    {
                        bitmapImage = MediaStore.Images.Media.GetBitmap(ContentResolver, selectedURI);
                    }

                    else
                    {
                        selectedURI = data.Data;
                        string filePath = FileUploadHelper.GetFilePath(selectedURI, this);
                        textFileName.Text = FileUploadHelper.GetFileName(filePath);
                        // Conversion of selected file into bytes
                        bytes = FileUploadHelper.ConvertFileIntoByte(filePath);
                        bitmapImage = BitmapFactory.DecodeByteArray(bytes, 0, bytes.Length);
                    }
                    string imgaeURL = string.Empty;
                    imgaeURL = FileUploadHelper.GetFilePath(selectedURI, this);


                    BitmapFactory.Options bounds = new BitmapFactory.Options();
                    bounds.InJustDecodeBounds = true;
                    BitmapFactory.DecodeFile(imgaeURL, bounds);

                    BitmapFactory.Options opts = new BitmapFactory.Options();
                    Bitmap bm = BitmapFactory.DecodeFile(imgaeURL, opts);
                    Android.Media.ExifInterface exif = new Android.Media.ExifInterface(imgaeURL);
                    // get the initial orientation of image
                    string orientString = exif.GetAttribute(Android.Media.ExifInterface.TagOrientation);
                    int orientation = orientString != null ? Convert.ToInt32(orientString) : Constants.int0;
                    int rotationAngle = Constants.int0;
                    if (orientation == Constants.int6) rotationAngle = Constants.int90;
                    if (orientation == Constants.int3) rotationAngle = Constants.int180;
                    if (orientation == Constants.int20) rotationAngle = Constants.int270;
                    if (orientation != Constants.int0)
                    {
                        int maxHeight = 1200;
                        int maxWidth = 1200;
                        // Setting pre rotate
                        Matrix matrix = new Matrix();
                        matrix.SetRotate(rotationAngle, (float)bm.Width / 2, (float)bm.Height / 2);
                        float scale = Math.Min(((float)maxHeight / bm.Width), ((float)maxWidth / bm.Height));

                        matrix.PostScale(scale, scale);
                        bitmapImage = Bitmap.CreateBitmap(bm, Constants.int0, Constants.int0, bounds.OutWidth, bounds.OutHeight, matrix, true);
                        bitmapImage = bitmapImage.Copy(Bitmap.Config.Argb8888, true);

                    }
                    if (bounds.OutWidth > 4500)
                    {
                        imgViewCamera.SetImageResource(Resource.Drawable.img_camera);
                        Toast.MakeText(this, Constants.strLargeFile, ToastLength.Short).Show();
                    }
                    else
                    {
                        imgViewCamera.SetImageBitmap(bitmapImage);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="image"></param>
        /// <param name="width"></param>
        /// <param name="height"></param>
        /// <returns></returns>
        public Bitmap resizeAndRotate(Bitmap image, int width, int height)
        {
            var matrix = new Matrix();
            var scaleWidth = ((float)width) / image.Width;
            var scaleHeight = ((float)height) / image.Height;
            matrix.PostRotate(0);
            matrix.PreScale(scaleWidth, scaleHeight);
            return Bitmap.CreateBitmap(image, 0, 0, image.Width, image.Height, matrix, true);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void rdbtn_Picture_Click(object sender, EventArgs e)
        {
            objSignaturePadView.Clear();
            txtHeaderLabel.Text = "Upload Picture:";
            requiredMessage = "Please upload image";
            imgViewCamera.Visibility = ViewStates.Visible;
            objSignaturePadView.Visibility = ViewStates.Gone;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void rdbtn_Signature_Click(object sender, EventArgs e)
        {
            bitmapImage = null;
            requiredMessage = Constants.signatureRequired;
            txtHeaderLabel.Text = "Sign Here:";
            imgViewCamera.Visibility = ViewStates.Gone;
            objSignaturePadView.Visibility = ViewStates.Visible;
        }


        /// <summary>
        /// Close the Activity
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgClosePage_Click(object sender, EventArgs e)
        {
            Finish();
        }

        /// <summary>
        /// Get Data from intent
        /// </summary>
        private void GetIntentData()
        {
            try
            {
                strConfValue = Intent.GetStringExtra("PickupConf");
                string[] PickupConf = strConfValue.Split('|');
                if (PickupConf[3].ToUpper() == Constants.strPickConf.ToUpper())
                {
                    ConfType = Constants.strpickup;
                    lnrRadio.Visibility = ViewStates.Gone;
                }
                else
                {
                    ConfType = Constants.strdelivery;
                    lnrRadio.Visibility = ViewStates.Visible;
                }
                txtDialogHeader.Text = PickupConf[3];
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Preparing payload for hitting API
        /// </summary>
        public string GetTrackingPayload()
        {
            try
            {
                activityDate = new string[2];
                if (txtActivityDate.Text != "")
                {
                    ActivityDate = Convert.ToDateTime(txtActivityDate.Text).ToString(Constants.dateFormatMMDDYYYY);
                    activityDate = CommanUtil.FormatDate(ActivityDate);
                    newActivityDate = activityDate[2] + "-" + activityDate[0] + "-" + activityDate[1];
                }
                if ((txtActivityTime.Text.Contains("AM")))
                {
                    activityTime = txtActivityTime.Text.Replace("AM", "").Trim();
                }
                else
                {
                    activityTime = txtActivityTime.Text.Replace("PM", "").Trim();
                }
                string Cstatus = string.Empty;
                if (ConfType != Constants.strPickConf)
                {
                    Cstatus = "Delivered_";
                }
                else
                {
                    Cstatus = "Not Delivered";
                    stopCountForConfirmtion = string.Empty;
                }
                payload_str = "{"
                                + "\"ProNumber\":" + "\"" + txtProNumber.Text + "\","
                                + "\"ActivityDate\":" + "\"" + newActivityDate + " " + activityTime + "\","
                                + "\"ActivityCode\":" + "\"" + lstTrackingDesc[descriptionIndex].value + "\","
                                + "\"ActivityDescr\":" + "\"" + Convert.ToString(spinnerDescription.SelectedItem) + "\","
                                + "\"City\":" + "\"" + txtCity.Text + "\","
                                + "\"State\":" + "\"" + lstStateCodes[spinnerState.SelectedItemPosition] + "\","
                                + "\"Country\":" + "\"" + lstCountryCodes[spinnerCountry.SelectedItemPosition] + "\""

                                + "," + "\"Stop\":" + "\"" + stopCountForConfirmtion + "\","
                                 + "\"CurrentStatus\":" + "\"" + Cstatus + stopCountForConfirmtion + "\""
                                +
                                "}";

                return payload_str;
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                throw;
            }
        }

        /// <summary>
        /// Activity Time Picker
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ActivityTimePicker(object sender, TimePickerDialog.TimeSetEventArgs e)
        {
            AMPM = Utility.CheckAMPM(e);
            txtActivityTime.Text = e.HourOfDay.ToString() + ":" + e.Minute.ToString() + " " + AMPM;
        }

        /// <summary>
        /// Activity Date Picker
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ActivityDatePicker(object sender, DatePickerDialog.DateSetEventArgs e)
        {
            txtActivityDate.Text = e.Date.ToShortDateString();
        }

        /// <summary>
        /// Getting Current Location
        /// </summary>
        private async Task InitializeLocationManager()
        {
            response = objGPSServiceSettings.StartLocationUpdates(null);
            if (!string.IsNullOrEmpty(response) && !response.Equals("passive")) // && response.Equals("network")
            {
                currentLat = CommanUtil.currLat;//37.089984; //
                currentLong = CommanUtil.currLong;//-95.715063;//
                if (currentLat != 0)
                {
                    await ConvertLatLongToAddress(currentLat, currentLong);
                }
                else
                {
                    Toast.MakeText(this, Constants.strLocation, ToastLength.Long).Show();
                }
            }
            else
            {
                txtCity.Text = string.Empty;
                state = string.Empty;
                country = string.Empty;
                Toast.MakeText(this, Constants.strEnableTracking, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Submit Sign With Details
        /// </summary>
        private async Task SubmitSignWithDetails()
        {
            try
            {
                if (!Utility.FnIsOnline(this))
                {
                    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                if (objSignaturePadView.GetImage() == null && bitmapImage == null)
                {
                    //Toast.MakeText(this, Constants.enterSignatureOrImage, ToastLength.Short).Show();
                    //return;
                    if (ConfType == Constants.strpickup)
                    {
                        Toast.MakeText(this, requiredMessage, ToastLength.Short).Show();
                        return;
                    }
                    else
                    {
                        Toast.MakeText(this, requiredMessage, ToastLength.Short).Show();
                        return;
                    }
                }
                if (string.IsNullOrEmpty(txtCity.Text))
                {
                    Toast.MakeText(this, Constants.enterCity, ToastLength.Long).Show();
                    return;
                }
                else
                {
                    Alerts.showBusyLoader(this);
                    await Task.Delay(500);
                    ServiceHelper objServiceHelper = new ServiceHelper();
                    Utility objUtility = new Utility();
                    string Result = string.Empty;
                    string methodURI = APIMethods.shipmentDetails + "/" + strConfValue.Split('|')[0] + "|" + strConfValue.Split('|')[1] + "|" + strConfValue.Split('|')[2] + "/" + APIMethods.signature;
                    string token = CommanUtil.tokenNo;
                    if (objSignaturePadView.GetImage() != null)
                    {
                        objBitmap = objSignaturePadView.GetImage(Color.Black, Color.White, false);
                    }
                    else
                    {
                        objBitmap = bitmapImage;
                    }
                    using (var stream = new MemoryStream())
                    {
                        objBitmap.Compress(Bitmap.CompressFormat.Png, 50, stream);
                        var bytes = stream.ToArray();
                        strBase64String = Convert.ToBase64String(bytes);
                    }
                    if (!string.IsNullOrEmpty(GetTrackingPayload()))
                    {
                        payloadReturn = GetTrackingPayload();
                    }
                    else
                    {
                        payloadReturn = "{" + "}";
                    }
                    //if (carrierShipmentDetail.Addresses.Count > 3)
                    //{
                    //    ConfType = "STOP";
                    //}
                    if (ConfType != Constants.strpickup && carrierShipmentDetail.Addresses.Count > 3)
                    {
                        //ConfType = Constants.stopCountForConfirmtion;
                        ConfType = "STOP";
                    }
                    postDataJson = "{"
                                    + "\"Signature64\":" + "\"" + strBase64String + "\","
                                    + "\"SignatureImageType\":" + "\"png\","
                                    + "\"SignatureType\":" + "\"" + ConfType + "\","
                                     + "\"Tracking\":" + payloadReturn
                                    + "}";
                    Result = await objServiceHelper.PostRequestJson(postDataJson, methodURI, token, true);
                    if (Result != null && Result.Replace("\"", " ").Trim() == "Success")
                    {
                        methodURI = APIMethods.shipmentDetails + "/" + carrierShipmentDetail.ClientID + "|" + carrierShipmentDetail.BolNum;
                        await objUtility.BindShipmentDetail(methodURI, this);//Bind shipmen
                        Toast.MakeText(this, Constants.signatureSaved, ToastLength.Long).Show();
                        Finish();
                    }
                    else
                    {
                        jobject = JObject.Parse(Result);
                        string message = Convert.ToString(jobject[Constants.strErrorMessage]);
                        Toast.MakeText(this, message, ToastLength.Long).Show();
                        Utility.ErrorLog(APIMethods.signature, message, token, this);
                    }
                    objSignaturePadView.Clear();
                }
            }
            catch (Exception ex)
            {
                Alerts.HideBusyLoader();
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
            finally
            {
                Alerts.HideBusyLoader();
            }
        }

        /// <summary>
        /// Submit Signatureonly
        /// </summary>
        private async Task SubmitSignOnly()
        {
            try
            {
                if (!Utility.FnIsOnline(this))
                {
                    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                if (objSignaturePadView.GetImage() == null && bitmapImage == null)
                {
                    //if (CommanUtil.shipmentType == Constants.dispatcher)
                    //{
                    //    Toast.MakeText(this, Constants.signatureRequired, ToastLength.Short).Show();
                    //    return;
                    //}
                    //else
                    //{
                    if (ConfType == Constants.strpickup)
                    {
                        Toast.MakeText(this, requiredMessage, ToastLength.Short).Show();
                        return;
                    }
                    else
                    {
                        Toast.MakeText(this, requiredMessage, ToastLength.Short).Show();
                        return;
                    }
                    //}
                }
                else
                {
                    Alerts.showBusyLoader(this);
                    await Task.Delay(500);
                    ServiceHelper objServiceHelper = new ServiceHelper();
                    Utility objUtility = new Utility();
                    string Result = string.Empty;
                    string methodURI = APIMethods.shipmentDetails + "/" + strConfValue.Split('|')[0] + "|" + strConfValue.Split('|')[1] + "|" + strConfValue.Split('|')[2] + "/" + APIMethods.signature;
                    string token = CommanUtil.tokenNo;
                    if (objSignaturePadView.GetImage() != null)
                    {
                        objBitmap = objSignaturePadView.GetImage(Color.Black, Color.White, false);
                    }
                    else
                    {
                        objBitmap = bitmapImage;
                    }
                    using (var stream = new MemoryStream())
                    {
                        objBitmap.Compress(Bitmap.CompressFormat.Png, 50, stream);
                        var bytes = stream.ToArray();
                        strBase64String = Convert.ToBase64String(bytes);
                    }
                    //if (ConfType != Constants.strpickup)
                    //{
                    //    ConfType = Constants.stopCountForConfirmtion;
                    //}
                    if (ConfType != Constants.strpickup && carrierShipmentDetail.Addresses.Count > 3)
                    {
                        string payload_str1 = "{"
                                 + "\"Stop\":" + "\"" + stopCountForConfirmtion + "\","
                                  + "\"CurrentStatus\":" + "\"" + stopCountForConfirmtion + "\""
                                 +
                                 "}";
                        //ConfType = Constants.stopCountForConfirmtion;
                        ConfType = "STOP";
                        postDataJson = "{"
                                       + "\"Signature64\":" + "\"" + strBase64String + "\","
                                       + "\"SignatureImageType\":" + "\"png\","
                                       + "\"SignatureType\":" + "\"" + ConfType + "\","
                                       + "\"Tracking\":" + payload_str1
                                       + "}";
                    }
                    else
                    {
                        postDataJson = "{"
                                       + "\"Signature64\":" + "\"" + strBase64String + "\","
                                       + "\"SignatureImageType\":" + "\"png\","
                                       + "\"SignatureType\":" + "\"" + ConfType + "\""
                                       // + "\"Tracking\":" + payloadReturn
                                       + "}";
                    }

                    Result = await objServiceHelper.PostRequestJson(postDataJson, methodURI, token, true);
                    if (Result != null && Result.Replace("\"", " ").Trim() == "Success")
                    {
                        methodURI = APIMethods.shipmentDetails + "/" + carrierShipmentDetail.ClientID + "|" + carrierShipmentDetail.BolNum;
                        await objUtility.BindShipmentDetail(methodURI, this);//Bind shipment
                        Toast.MakeText(this, Constants.signatureSaved, ToastLength.Long).Show();
                        Finish();
                    }
                    else
                    {
                        jobject = JObject.Parse(Result);
                        string message = Convert.ToString(jobject[Constants.strErrorMessage]);
                        Toast.MakeText(this, message, ToastLength.Long).Show();
                        Utility.ErrorLog(APIMethods.signature, message, token, this);
                    }
                    objSignaturePadView.Clear();
                }
            }
            catch (Exception ex)
            {
                Alerts.HideBusyLoader();
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
            finally
            {
                Alerts.HideBusyLoader();
            }
        }

        /// <summary>
        /// Convert LatLong To Address
        /// </summary>
        /// <returns></returns>
        public async Task ConvertLatLongToAddress(double Lat, double Long)
        {
            try
            {
                if (!Utility.FnIsOnline(this))
                {
                    Alerts.HideBusyLoader();
                    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                var geocoder = new Geocoder(this);
                IList<Android.Locations.Address> addressList = await geocoder.GetFromLocationAsync(Lat, Long, 10);
                if (addressList != null && addressList.Count > 0)
                {
                    Android.Locations.Address addressCurrent = addressList.FirstOrDefault();
                    if (addressCurrent != null)
                    {
                        txtCity.Text = addressCurrent.Locality;
                        state = addressCurrent.AdminArea;
                        country = addressCurrent.CountryName;
                    }
                }
                else
                {
                    txtCity.Text = string.Empty;
                    state = string.Empty;
                    country = string.Empty;
                    Toast.MakeText(this, Constants.strLocation, ToastLength.Long).Show();
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                throw;
            }
        }

        /// <summary>
        /// CheckBox TrackDetails CheckedChange Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ChkTrackDetails_CheckedChange(object sender, CompoundButton.CheckedChangeEventArgs e)
        {
            try
            {
                if (CommanUtil.IsTimeOut())
                {
                    if (chkTrackDetails.Checked)
                    {
                        await InitializeLocationManager();
                        txtActivityDate.Text = DateTime.Now.ToShortDateString();
                        txtActivityTime.Text = DateTime.Now.ToShortTimeString();
                        lnrTrackDetails.Visibility = ViewStates.Visible;
                        await LoadCountry();
                        BindDescription();
                    }
                    else
                    {
                        lnrTrackDetails.Visibility = ViewStates.Gone;
                    }
                }
                else
                {
                    chkTrackDetails.Checked = false;
                    Utility.ExpireSession(this);
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Loading Country According to current Address
        /// </summary>
        public async Task LoadCountry()
        {
            lstCountryDetails = await Utility.GetCountryDetails(this);
            if (lstCountryDetails != null && lstCountryDetails.Count > 0)
            {
                lstCountries = new List<string>();
                lstCountryCodes = new List<string>();
                foreach (CountryDetails countryDetails in lstCountryDetails)
                {
                    lstCountries.Add(countryDetails.Name);
                    lstCountryCodes.Add(countryDetails.Code);
                }
                if (!string.IsNullOrEmpty(country))
                {
                    countryName = lstCountries.Where(x => x.Equals(country.ToUpper())).FirstOrDefault();
                }
                else
                {
                    countryName = lstCountries.Where(x => x.Equals(Constants.strDefaultState)).FirstOrDefault();
                }
                if (string.IsNullOrEmpty(countryName))
                {
                    countryName = Constants.strDefaultState;
                }
                ArrayAdapter adapter = new ArrayAdapter(this, Resource.Drawable.SpinnerCustomDesign, lstCountries);
                adapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
                spinnerCountry.Adapter = adapter;
                for (int indexCountry = 0; indexCountry < spinnerCountry.Count; indexCountry++)
                {
                    if (spinnerCountry.GetItemAtPosition(indexCountry).Equals(countryName.ToUpper()))
                    {
                        spinnerCountry.SetSelection(indexCountry);

                    }
                }
                spinnerCountry.ItemSelected += SpinnerCountry_ItemSelected;
            }
            else
            {
                Toast.MakeText(this, Constants.strUnableToConnect, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Spinner Country ItemSelected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SpinnerCountry_ItemSelected(object sender, AdapterView.ItemSelectedEventArgs e)
        {
            try
            {
                for (int indexCountry = 0; indexCountry < spinnerCountry.Count; indexCountry++)
                {
                    if (spinnerCountry.SelectedItem.Equals(Convert.ToString(lstCountryDetails[indexCountry].Name.ToUpper())))
                    {
                        lstStateDetails = lstCountryDetails[indexCountry].States;
                    }
                }
                //GetItemAtPosition  ///state
                lstStates = new List<string>();
                lstStateCodes = new List<string>();
                foreach (StateDetails stateDetails in lstStateDetails)
                {
                    lstStateCodes.Add(stateDetails.Code);
                    lstStates.Add(stateDetails.Name);
                }
                adapter = new ArrayAdapter(this, Resource.Drawable.SpinnerCustomDesign, lstStates);
                adapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
                spinnerState.Adapter = adapter;
                if (!string.IsNullOrEmpty(state))
                {
                    if (lstStateCodes != null && lstStateCodes.Count > 0)
                    {
                        for (int indexState = 0; indexState < spinnerState.Count; indexState++)
                        {
                            if (state.ToUpper().Equals(Convert.ToString(lstStateCodes[indexState].ToUpper())))
                            {
                                spinnerState.SetSelection(indexState);
                            }
                            else if (state.ToUpper().Equals(Convert.ToString(lstStates[indexState].ToUpper())))
                            {
                                spinnerState.SetSelection(indexState);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Funciton to bind data in the description spinner
        /// </summary>
        public void BindDescription()
        {
            adapter = Utility.DescriptionAdapter(this);
            adapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
            spinnerDescription.Adapter = adapter;
            if (ConfType == Constants.strpickup)
            {
                spinnerDescription.SetSelection(1);
                descriptionIndex = 1;
            }
            else
            {
                spinnerDescription.SetSelection(4);
                descriptionIndex = 4;
            }
        }


    }
}