using System;
using System.Collections.Generic;
using System.Linq;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Views;
using Android.Widget;
using System.Threading.Tasks;
using RateLinx.Droid.Utilities;
using RateLinx.APIs;
using RateLinx.Models;
using Newtonsoft.Json;
using RateLinx.Helper;
using Android.Content.PM;
using Android.Graphics;
using Android.Util;

namespace RateLinx.Droid.Activities
{
    /// <summary>
    /// Meta tag of the Activity
    /// </summary>
    [Activity(Label = "DispatchShipDetailsActivity", Theme = "@style/Theme.AppCompat.NoActionBar", ConfigurationChanges = ConfigChanges.Orientation | ConfigChanges.ScreenSize)]
    public class DispatchShipDetailsActivity : HeaderActivity
    {

        string intentData = string.Empty;
        CarrierShipmentDetails shipmentDetail = null;
        TextView txtSourceAddress, txtDestinationAddress, txtShipmentDetails,
            txtOriginPhone, txtOriginEmail, txtOriginFax, txtDestPhone, txtDestEmail, txtDestFax,
            txtPickupOn, txtDeliveryOn, txtCurrentStatus, txtViewCopyRight = null;
        LinearLayout lnrAddresses, linearLayout4 = null;
        List<TextView> lstTvStops = new List<TextView>();

        Button btnBack;
        /// <summary>
        /// On load method
        /// </summary>
        /// <param name="savedInstanceState"></param>
        protected override async void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);
                RequestWindowFeature(WindowFeatures.NoTitle);
                if (string.IsNullOrEmpty(CommanUtil.tokenNo))
                {
                    Utility.Logout(this);
                }
                SetContentView(Resource.Layout.DispatchShipmentDetailsLayout);
                txtViewCopyRight= FindViewById<TextView>(Resource.Id.txtViewCopyRight);
                txtViewCopyRight.Text = CommanUtil.PrintYear();//Printc Current Year in Page Footer 
                txtSourceAddress = FindViewById<TextView>(Resource.Id.txtSourceAddress);
                lnrAddresses = FindViewById<LinearLayout>(Resource.Id.lnrStops);
                lnrAddresses.Visibility = ViewStates.Gone;
                txtDestinationAddress = FindViewById<TextView>(Resource.Id.txtDestinationAddress);
                txtShipmentDetails = FindViewById<TextView>(Resource.Id.txtShipmentDetails);
                txtPickupOn = FindViewById<TextView>(Resource.Id.txtPickupOn);
                txtDeliveryOn = FindViewById<TextView>(Resource.Id.txtDeliveryOn);
                btnBack = FindViewById<Button>(Resource.Id.btnBack);
                txtCurrentStatus = FindViewById<TextView>(Resource.Id.txtCurrentStatus);
                linearLayout4 = FindViewById<LinearLayout>(Resource.Id.linearLayout4);
                btnBack.Click += delegate
                {
                    Finish();
                };

                txtOriginPhone = FindViewById<TextView>(Resource.Id.txtOriginPhone);
                txtOriginEmail = FindViewById<TextView>(Resource.Id.txtOriginEmail);
                txtOriginFax = FindViewById<TextView>(Resource.Id.txtOriginFax);
                txtDestPhone = FindViewById<TextView>(Resource.Id.txtDestPhone);
                txtDestEmail = FindViewById<TextView>(Resource.Id.txtDestEmail);
                txtDestFax = FindViewById<TextView>(Resource.Id.txtDestFax);
                intentData = Intent.GetStringExtra("compositeKey");
                // Create your application here
                if (!string.IsNullOrEmpty(intentData))
                {
                    if (CommanUtil.IsTimeOut())
                    {
                        await GetShipmentDetailsAsync();
                    }
                    else
                    {
                        Utility.ExpireSession(this);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Helper.Constants.strTimeOut, ToastLength.Long).Show();
                Finish();
            }
        }
        /// <summary>
        /// Convert pixel to dp for dynamic listView height
        /// </summary>
        /// <param name="pixels"></param>
        /// <returns></returns>
        private int PixelsToDp(int pixels)
        {
            try
            {
                return (int)TypedValue.ApplyDimension(ComplexUnitType.Dip, pixels, Resources.DisplayMetrics);
            }
            catch
            {
                return 0;
            }
        }

        /// <summary>
        /// Bind The Address Details 
        /// </summary>
        private void BindAddressDetails()
        {
            try
            {
                int stopcount = 1;
                List<Address> objAddress = new List<Address>();
                objAddress = shipmentDetail.Addresses.ToList();
                txtShipmentDetails.Text = string.Format(Constants.trackDetails, shipmentDetail.BolNum);
                txtPickupOn.Text = shipmentDetail.PickupStr;
                txtDeliveryOn.Text = shipmentDetail.DeliverOnStr;
                if (objAddress != null)
                {
                    foreach (var item in objAddress)
                    {
                        if (item.Type == Constants.strORIGIN)
                        {

                            txtOriginPhone.Text = string.Format(Constants.phone, item.Phone);
                            txtOriginEmail.Text = string.Format(Constants.email, item.Email);
                            txtOriginFax.Text = string.Format(Constants.fax, item.Fax);

                            txtSourceAddress.Text = item.Company + " ";

                            //Address
                            if (!string.IsNullOrEmpty(item.Address1))
                            {
                                txtSourceAddress.Text += item.Address1 + " ";
                            }
                            if (!string.IsNullOrEmpty(item.Address2))
                            {
                                txtSourceAddress.Text += item.Address2 + " ";
                            }
                            if (!string.IsNullOrEmpty(item.Address3))
                            {
                                txtSourceAddress.Text += item.Address3 + " ";
                            }
                            if (!string.IsNullOrEmpty(item.Address4))
                            {
                                txtSourceAddress.Text += item.Address4 + " ";
                            }
                            if (!string.IsNullOrEmpty(item.City))
                            {
                                txtSourceAddress.Text += item.City + ", ";
                            }
                            if (!string.IsNullOrEmpty(item.State))
                            {
                                txtSourceAddress.Text += item.State + " " + item.Zip + " " + item.Country;
                            }

                        }
                        else if (item.Type == Constants.strSHIPTO)
                        {

                            txtDestPhone.Text = string.Format(Constants.phone, item.Phone);
                            txtDestEmail.Text = string.Format(Constants.email, item.Email);
                            txtDestFax.Text = string.Format(Constants.fax, item.Fax);
                            txtDestinationAddress.Text = item.Company + " ";
                            //Address
                            if (!string.IsNullOrEmpty(item.Address1))
                            {
                                txtDestinationAddress.Text += item.Address1 + " ";
                            }
                            if (!string.IsNullOrEmpty(item.Address2))
                            {
                                txtDestinationAddress.Text += item.Address2 + " ";
                            }
                            if (!string.IsNullOrEmpty(item.Address3))
                            {
                                txtDestinationAddress.Text += item.Address3 + " ";
                            }
                            if (!string.IsNullOrEmpty(item.Address4))
                            {
                                txtDestinationAddress.Text += item.Address4 + " ";
                            }
                            if (!string.IsNullOrEmpty(item.City))
                            {
                                txtDestinationAddress.Text += item.City + ", ";
                            }
                            if (!string.IsNullOrEmpty(item.State))
                            {
                                txtDestinationAddress.Text += item.State + " " + item.Zip + " " + item.Country;
                            }

                        }
                        else
                        {
                            if (item.Type != "BILLTO")
                            {
                                View view = this.LayoutInflater.Inflate(Resource.Layout.MultiStopLayout, null);

                                TextView txtStop = view.FindViewById<TextView>(Resource.Id.txtStop);

                                txtStop.Id = stopcount;
                                txtStop.Text = item.Company + " ";

                                //Address
                                if (!string.IsNullOrEmpty(item.Address1))
                                {
                                    txtStop.Text += item.Address1 + " ";
                                }
                                if (!string.IsNullOrEmpty(item.Address2))
                                {
                                    txtStop.Text += item.Address2 + " ";
                                }
                                if (!string.IsNullOrEmpty(item.Address3))
                                {
                                    txtStop.Text += item.Address3 + " ";
                                }
                                if (!string.IsNullOrEmpty(item.Address4))
                                {
                                    txtStop.Text += item.Address4 + " ";
                                }
                                if (!string.IsNullOrEmpty(item.City))
                                {
                                    txtStop.Text += item.City + ", ";
                                }
                                if (!string.IsNullOrEmpty(item.State))
                                {
                                    txtStop.Text += item.State + " " + item.Zip + " " + item.Country;
                                }

                                lnrAddresses.Visibility = ViewStates.Visible;
                                lnrAddresses.AddView(view);
                                stopcount++;
                            }
                        }
                    }

                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Get shipment details
        /// </summary>
        /// <returns></returns>
        async Task GetShipmentDetailsAsync()
        {
            try
            {
                string BolNum = intentData.Split('|')[0] + "|" + intentData.Split('|')[2];
                Utility objUtility = new Utility();
                //Method Name
                string methodName = APIMethods.shipmentDetails + "/" + BolNum;
                Alerts.showBusyLoader(this);
                string shipmentDetails = await objUtility.BindShipmentDetail(methodName, this);
                Alerts.HideBusyLoader();
                if (!string.IsNullOrEmpty(shipmentDetails))
                {
                    shipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(shipmentDetails);
                    BindAddressDetails();
                    string shipStatus = string.Empty;
                    if (shipmentDetail.Addresses.Count > 3 && (!string.IsNullOrEmpty(Constants.currentShipStatus)))
                    {
                        txtCurrentStatus.Text = Constants.currentShipStatus;
                    }
                    else
                    {
                        if (shipmentDetail.TrackDetails != null)
                        {
                            shipStatus = shipmentDetail.TrackDetails[shipmentDetail.TrackDetails.Count - 1].ActivityDescr;
                        }
                        if (!string.IsNullOrEmpty(shipStatus))
                        {
                            txtCurrentStatus.Text = shipStatus;
                        }
                        else
                        {
                            txtCurrentStatus.Text = Constants.shippingNotStart;
                        }
                    }
                }
                methodName = string.Empty;
                objUtility = null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



    }
}