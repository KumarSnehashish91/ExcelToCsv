﻿using Android.App;
using Android.OS;
using RateLinx.Droid.Utilities;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using RateLinx.Helper;
using RateLinx.APIs;
using System;
using Android.Support.Design.Widget;
using Android.Support.V4.Widget;
using Android.Support.V7.App;
using Android.Widget;
using Android.Content;
using V4App = Android.Support.V4.App;
using RateLinx.Droid.Fragments;
using AndroidNetUri = Android.Net.Uri;
using RateLinx.Droid.Activities;
using Android.Preferences;
using Android.Views;
using RateLinx.Droid.PushNotificationService;
using Android.Content.PM;
using RateLinx.Droid.GoogleMapServices;

namespace RateLinx.Droid
{
    /// <summary>
    /// Home Activities
    /// </summary>
    [Activity(Label = Constants.appName, Icon = "@drawable/icon", Theme = "@style/Theme.AppCompat.NoActionBar", ConfigurationChanges = ConfigChanges.Orientation | ConfigChanges.ScreenSize, LaunchMode = LaunchMode.SingleTop)]
    public class HomeActivity : CompactActivity
    {
        #region Declaration of controls instances and variables
        DrawerLayout drawerLayout = null;
        TextView TvHeaderTitle, txtViewCopyRight = null;
        ImageView imgFacebook, imgTwitter, imgYoutube, imgLnkdin, imgGPlus, imgRSS = null;
        NavigationView navigationView = null;
        ShipmentsFragment objShipmentsFragment = null;
        ServiceHelper objServicehelper = null;
        HelpAndFeedback objHelp = null;
        JObject jobject = null;
        AndroidNetUri uriAbout, uriNews, uriTwitter = null;
        Intent intent, intentAbout, intentNews, intentTwitter = null;
        string methodName, strResponse, redirectURL = string.Empty;
        RateHistory objFragment = null;
        V4App.FragmentManager objFragmentManager = null;
        V4App.FragmentTransaction objFragmentTrans = null;
        Dialog confirmDialog = null;
        Switch pushSwitch = null;
        ISharedPreferences localStorage = null;
        //JObject jobject = null;
        //bool stopPooling, isFirstTimeLoad = false;
        bool isFirstTimeLoad = false;
        /// <summary>
        /// 
        /// </summary>
        public static bool stopPooling = false;
        GPSServiceSettings objGPSServiceSettings = null;

        #endregion

        /// <summary>
        /// Home : Page Load event
        /// </summary>
        /// <param name="savedInstanceState"></param>
        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);
                objServicehelper = new ServiceHelper();
                if (!string.IsNullOrEmpty(CommanUtil.tokenNo))
                {
                    localStorage = PreferenceManager.GetDefaultSharedPreferences(this);
                    //Set our view from the "Startup Page" layout resource
                    SetContentView(Resource.Layout.Home);
                    //Get our UI controls from the loaded layout:
                    objGPSServiceSettings = new GPSServiceSettings();
                    objGPSServiceSettings.StartLocationUpdates(null);//this
                    FnSetUpControls();
                }
                else
                {
                    Utility.Logout(this);
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, ex.Message, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Call when activity is going in background
        /// </summary>
        protected override void OnPause()
        {
            stopPooling = isFirstTimeLoad = true;
            base.OnPause();
        }

        /// <summary>
        /// Call when activity start
        /// </summary>
        protected override void OnResume()
        {
            if (stopPooling)
            {
                stopPooling = false;
                GetRealtimeShipmentsInterval();
            }
            base.OnResume();
        }

        /// <summary>
        /// Get the Real time shipment in a interval
        /// </summary>
        /// <returns></returns>
        public async void GetRealtimeShipmentsInterval()
        {
            try
            {
                while (!stopPooling)
                {
                    if (!Utility.FnIsOnline(this))
                    {
                        Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    }
                    else
                    {
                        await GetRealtimeShipments();
                    }
                    await Task.Delay(5000);
                    CommanUtil.stopThread();
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
            }
        }

        /// <summary>
        /// Get the shipments response from API and bind them on page
        /// </summary>
        public async Task GetRealtimeShipments()
        {
            try
            {
                if (CommanUtil.IsTimeOut())
                {
                    if (!isFirstTimeLoad)
                    {
                        Alerts.showBusyLoader(this);
                    }
                    //Get the Shipments
                    strResponse = await objServicehelper.GetRequest(CommanUtil.tokenNo, APIMethods.shipments, true);
                    if (!isFirstTimeLoad)
                    {
                        isFirstTimeLoad = true;
                        BindFragmentShipments(); //Call the shipments fragment
                        Alerts.HideBusyLoader();
                    }
                    Constants.activeShipmentsList = string.Empty;
                    Constants.awardedShipmentsList = string.Empty;
                    Constants.recentShipmentsList = string.Empty;
                    if (!string.IsNullOrEmpty(strResponse))
                    {
                        jobject = JObject.Parse(strResponse);
                        CommanUtil.ViewAs = Convert.ToString(jobject["ViewAs"]);
                        if (string.IsNullOrEmpty(Convert.ToString(jobject["Message"])))
                        {
                            if (!isFirstTimeLoad)
                            {
                                stopPooling = Convert.ToBoolean(Convert.ToString(jobject["StopPolling"]));
                            }
                            Constants.activeShipmentsList = Convert.ToString(jobject["ActiveShipments"]);
                            Constants.awardedShipmentsList = Convert.ToString(jobject["AwardedShipments"]);
                            Constants.recentShipmentsList = Convert.ToString(jobject["FuturePickups"]);
                        }
                        else
                        {
                            Toast.MakeText(this, Convert.ToString(jobject["Message"]), ToastLength.Short).Show();
                        }
                    }
                }
                else
                {
                    //If session got expired then logout
                    stopPooling = true;
                    ExpireSession(this);
                }
            }
            catch (Exception ex)
            {
                //stopPooling = true;
                Utility.ErrorLog(APIMethods.shipments, ex.Message, CommanUtil.tokenNo, this);
                //Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();

            }
        }

        /// <summary>
        /// Find Controls
        /// </summary>
        private void FnSetUpControls()
        {
            try
            {
                // Get our UI controls from the loaded layout:
                txtViewCopyRight = FindViewById<TextView>(Resource.Id.txtViewCopyRight);
                txtViewCopyRight.Text = CommanUtil.PrintYear();//Printc Current Year in Page Footer 
                drawerLayout = FindViewById<DrawerLayout>(Resource.Id.drawer_layout);
                // Init toolbar
                var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.app_bar);
                TvHeaderTitle = toolbar.FindViewById<TextView>(Resource.Id.toolbar_title);
                imgFacebook = FindViewById<ImageView>(Resource.Id.imgFacebook);
                imgTwitter = FindViewById<ImageView>(Resource.Id.imgTwitter);
                imgYoutube = FindViewById<ImageView>(Resource.Id.imgYoutube);
                imgLnkdin = FindViewById<ImageView>(Resource.Id.imgLnkdin);
                imgGPlus = FindViewById<ImageView>(Resource.Id.imgGPlus);
                imgRSS = FindViewById<ImageView>(Resource.Id.imgRSS);
                //Generating click events for social media links
                imgFacebook.Click += ImgFacebook_Click;
                imgTwitter.Click += ImgTwitter_Click;
                imgYoutube.Click += ImgYoutube_Click;
                imgLnkdin.Click += ImgLnkdin_Click;
                imgGPlus.Click += ImgGPlus_Click;
                imgRSS.Click += ImgRSS_Click;
                toolbar.Title = string.Empty;
                toolbar.Subtitle = string.Empty;
                SetSupportActionBar(toolbar);
                SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                SupportActionBar.SetDisplayShowHomeEnabled(true);
                objFragmentManager = SupportFragmentManager;
                // Attach item selected handler to navigation view
                navigationView = FindViewById<NavigationView>(Resource.Id.nav_view);
                //Switch For push notification
                pushSwitch = new Switch(this);
                navigationView.Menu.FindItem(Resource.Id.nav_PushNotification).SetActionView(pushSwitch);
                bool isPushAllowed = Utility.sharedPreferences.GetBoolean("isPushAllowed", true);
                if (isPushAllowed)
                {
                    pushSwitch.Checked = true;
                }
                pushSwitch.CheckedChange += PushSwitch_CheckedChange;
                //End of Switch
                navigationView.NavigationItemSelected += NavigationView_NavigationItemSelectedAsync;
                // Create ActionBarDrawerToggle button and add it to the toolbar
                var drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, Resource.String.open_drawer, Resource.String.close_drawer);
                drawerLayout.AddDrawerListener(drawerToggle);
                drawerToggle.SyncState();
                GetRealtimeShipmentsInterval(); //Bind realtime shipment
            }
            catch
            {
                throw;
                // Alerts.HideBusyLoader();
            }
        }

        /// <summary>
        /// Back function for android device
        /// </summary>
        /// <param name="keyCode"></param>
        /// <param name="e"></param>
        /// <returns></returns>
        public override bool OnKeyDown(Keycode keyCode, KeyEvent e)
        {
            try
            {
                if (e.KeyCode == Keycode.Back)
                {
                }
                return base.OnKeyDown(keyCode, e);
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Buton Confirm Click While Trying to stop the Live Tracking
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnConfirm_Click(object sender, EventArgs e)
        {
            try
            {
                localStorage.Edit().Remove("objTrackList").Commit();
                confirmDialog.Hide();
                StartActivity(typeof(HomeActivity));
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Social image Icon Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgRSS_Click(object sender, EventArgs e)
        {
            try
            {
                uriNews = AndroidNetUri.Parse(Constants.strRatLinxNews);
                intentNews = new Intent(Intent.ActionView, uriNews);
                StartActivity(intentNews);
                // Close drawer
                drawerLayout.CloseDrawers();
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Social Icon Google Plus
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgGPlus_Click(object sender, EventArgs e)
        {
            try
            {
                var uriGPlus = AndroidNetUri.Parse(Constants.strGplusURI);
                var intentGPlus = new Intent(Intent.ActionView, uriGPlus);
                StartActivity(intentGPlus);
                // Close drawer
                drawerLayout.CloseDrawers();
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Linked In icon Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgLnkdin_Click(object sender, EventArgs e)
        {
            try
            {
                var uriLnkdin = AndroidNetUri.Parse(Constants.strLinkInURI);
                var intentLnkdin = new Intent(Intent.ActionView, uriLnkdin);
                StartActivity(intentLnkdin);
                // Close drawer
                drawerLayout.CloseDrawers();
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// You Tube
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgYoutube_Click(object sender, EventArgs e)
        {
            try
            {
                var uriYoutube = AndroidNetUri.Parse(Constants.strYoutubeURI);
                var intentYoutube = new Intent(Intent.ActionView, uriYoutube);
                StartActivity(intentYoutube);
                // Close drawer
                drawerLayout.CloseDrawers();
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Twitter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgTwitter_Click(object sender, EventArgs e)
        {
            try
            {
                uriTwitter = AndroidNetUri.Parse(Constants.strTwitterURI);
                intentTwitter = new Intent(Intent.ActionView, uriTwitter);
                StartActivity(intentTwitter);
                // Close drawer
                drawerLayout.CloseDrawers();
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Facebook
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgFacebook_Click(object sender, EventArgs e)
        {
            try
            {
                var uriFacebook = AndroidNetUri.Parse(Constants.strFacebookURI);
                var intentFacebook = new Intent(Intent.ActionView, uriFacebook);
                StartActivity(intentFacebook);
                // Close drawer
                drawerLayout.CloseDrawers();
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// menu nativation 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NavigationView_NavigationItemSelectedAsync(object sender, NavigationView.NavigationItemSelectedEventArgs e)
        {
            try
            {
                switch (e.MenuItem.ItemId)
                {
                    case (Resource.Id.nav_home):
                        //load default home screen
                        if (CommanUtil.IsTimeOut())
                        {
                            BindFragmentShipments();
                        }
                        else
                        {
                            ExpireSession(this);
                        }
                        break;
                    case (Resource.Id.nav_RateHistory):
                        stopPooling = true;
                        objFragment = new RateHistory(this);
                        TvHeaderTitle.Text = Constants.strRateHistory;
                        objFragmentTrans = objFragmentManager.BeginTransaction();
                        objFragmentTrans.Replace(Resource.Id.fragment_container, objFragment, Constants.strRateHistoryPage).AddToBackStack("RateHistory");
                        objFragmentTrans.Commit();
                        break;
                    case (Resource.Id.nav_Dashboard):
                        if (CommanUtil.IsTimeOut())
                        {
                            GoToMyRateLinx();
                            Alerts.HideBusyLoader();
                        }
                        else
                        {
                            //Toekn Exired
                            ExpireSession(this);
                        }
                        break;
                    case (Resource.Id.nav_RateLinxNews):
                        uriNews = AndroidNetUri.Parse(Constants.strNewsURI);
                        intentNews = new Intent(Intent.ActionView, uriNews);
                        StartActivity(intentNews);
                        break;
                    case (Resource.Id.nav_HelpFeedback):
                        stopPooling = true;
                        objHelp = new HelpAndFeedback(this);
                        TvHeaderTitle.Text = Constants.strHelpFeedback;
                        objFragmentTrans = objFragmentManager.BeginTransaction();
                        objFragmentTrans.Replace(Resource.Id.fragment_container, objHelp, Constants.strHelpAndFeedbackPage).AddToBackStack("HelpAndFeedback");
                        objFragmentTrans.Commit();
                        break;
                    case (Resource.Id.nav_About):
                        uriAbout = AndroidNetUri.Parse(Constants.strAboutRateLinx);
                        intentAbout = new Intent(Intent.ActionView, uriAbout);
                        StartActivity(intentAbout);
                        break;
                    case (Resource.Id.nav_PushNotification):
                        pushSwitch.CheckedChange += PushSwitch_CheckedChange;
                        break;
                    case (Resource.Id.nav_Logout):
                        Utility.Logout(this);
                        break;
                }
                // Close drawer
                drawerLayout.CloseDrawers();
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
            }
        }

        /// <summary>
        /// Method to check for notification registration
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PushSwitch_CheckedChange(object sender, CompoundButton.CheckedChangeEventArgs e)
        {
            try
            {
                bool isTrue = e.IsChecked;
                FnPushToggleSwitch(isTrue); //Register Push Notification
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Push Notification Implementation To post the device details
        /// </summary>
        /// <returns></returns>
        private async void FnPushToggleSwitch(bool isPushState)
        {
            try
            {
                Alerts.showBusyLoader(this);
                await Task.Delay(4000);
                //Test Internet Connection
                if (Utility.FnIsOnline(this))
                {
                    CommanUtil.isPushAllowed = isPushState;
                    Utility.sharedPreferences.Edit().PutBoolean("isPushAllowed", CommanUtil.isPushAllowed).Commit();
                    CallRegisterIntentService();
                }
                else
                {
                    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                }
                Alerts.HideBusyLoader();
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Method to call intent service
        /// </summary>
        /// <returns></returns>
        public string CallRegisterIntentService()
        {
            try
            {
                if (RegisterService.IsPlayServicesAvailable(this))
                {
                    var intent = new Intent(this, typeof(RegistrationIntentService));
                    this.StartService(intent);
                }
                return Constants.strSucceed;
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                return Constants.strException;
            }
        }



        /// <summary>
        /// Get the Shipment screen layout from Shipments Fragment
        /// </summary>
        private void BindFragmentShipments()
        {
            try
            {
                if (stopPooling)
                {
                    stopPooling = false;
                    GetRealtimeShipmentsInterval();
                }
                else
                {

                }
                objShipmentsFragment = new ShipmentsFragment(this);
                TvHeaderTitle.Text = Constants.strHomeTitle;
                V4App.FragmentTransaction objFragmentTrans = objFragmentManager.BeginTransaction();
                objFragmentTrans.Replace(Resource.Id.fragment_container, objShipmentsFragment, "ShipmentsFragment");
                objFragmentTrans.Commit();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Expire Token
        /// </summary>
        /// <param name="activity"></param>
        public void ExpireSession(Activity activity)
        {
            try
            {
                Alerts.HideBusyLoader();
                if (!CommanUtil.IsTimeOut())
                {
                    Utility utility = new Utility();
                    Dialog dialog = utility.ConfirmationAlert(activity);
                    Button btnYes = dialog.FindViewById<Button>(Resource.Id.btnYes);
                    Button btnNo = dialog.FindViewById<Button>(Resource.Id.btnNo);
                    LinearLayout lntlayoutReason = dialog.FindViewById<LinearLayout>(Resource.Id.lntlayoutReason);
                    btnYes.Visibility = ViewStates.Visible;
                    TextView txtViewClose = dialog.FindViewById<TextView>(Resource.Id.txtViewClose);
                    btnYes.Text = Constants.btnTextYes;
                    btnNo.Text = Constants.btnTextNo;
                    lntlayoutReason.Visibility = ViewStates.Gone;
                    TextView txtMessage = dialog.FindViewById<TextView>(Resource.Id.txtMessage);
                    txtMessage.Text = Constants.reLoginText;
                    btnYes.Click += async delegate
                    {
                        dialog.Hide();
                        dialog.Dismiss();
                        Alerts.showBusyLoader(activity);
                        await Task.Delay(500);
                        string loginDetails = Utility.sharedPreferences.GetString(Constants.userCredential, null);
                        if (!string.IsNullOrEmpty(loginDetails))
                        {
                            LoginActivity loginActivity = new LoginActivity();
                            bool isLogin = await loginActivity.Login(loginDetails);
                            if (isLogin)
                            {
                                stopPooling = false;
                                GetRealtimeShipmentsInterval();
                                Alerts.HideBusyLoader(); //Loader
                            }
                            else
                            {
                                Alerts.HideBusyLoader(); //Loader
                                Utility.Logout(activity);
                            }
                        }
                        else
                        {
                            Utility.Logout(activity);
                        }
                    };
                    btnNo.Click += delegate
                    {
                        Utility.Logout(activity);
                    };
                    txtViewClose.Click += delegate
                    {
                        Utility.Logout(activity);
                    };
                }
            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// Redirecting to RateLinx Dashboard
        /// </summary>
        /// <returns></returns>
        public async void GoToMyRateLinx()
        {
            try
            {
                if (CommanUtil.IsTimeOut())
                {
                    #region uncomment this code when API starts working

                    //objServicehelper = new ServiceHelper();
                    //methodName = APIMethods.getSSOurl;
                    //if (!Utility.FnIsOnline(this))
                    //{
                    //    Alerts.HideBusyLoader();
                    //    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    //    return;
                    //}
                    //Alerts.showBusyLoader(this);
                    //strResponse = await objServicehelper.GetRequest(CommanUtil.tokenNo, methodName, true);
                    //if (!String.IsNullOrEmpty(strResponse))
                    //{
                    //    jobject = JObject.Parse(strResponse);
                    //}
                    //else
                    //{
                    //    jobject = null;
                    //}
                    //redirectURL = Convert.ToString(jobject["url"]);

                    #endregion
                    redirectURL = "https://my.ratelinx.com";

                    AndroidNetUri uri = AndroidNetUri.Parse(redirectURL);
                    intent = new Intent(Intent.ActionView, uri);
                    StartActivity(intent);
                }
                else
                {
                    ExpireSession(this);
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog("", ex.Message, CommanUtil.tokenNo, this);
            }
        }

        /// <summary>
        /// Call when back button is pressed
        /// </summary>
        public override void OnBackPressed()
        {
            try
            {
                if (SupportFragmentManager.BackStackEntryCount > 0)
                {
                    if (SupportFragmentManager.BackStackEntryCount == 1)
                    {
                        var rateHistory = SupportFragmentManager.FindFragmentByTag("RateHistory");
                        var orderHistory = SupportFragmentManager.FindFragmentByTag("OrderHistory");
                        var helpAndFeedback = SupportFragmentManager.FindFragmentByTag("HelpAndFeedback");
                        if (rateHistory != null || orderHistory != null || helpAndFeedback != null)
                        {
                            stopPooling = false;
                            GetRealtimeShipmentsInterval();
                        }
                        else
                        {

                        }
                    }
                    else
                    {
                        //No need of any action default back functionality will work here
                    }
                }
                else
                {
                    //SupportFragmentManager.PopBackStack();
                    Utility.sharedPreferences.Edit().Remove("objTrackList").Commit();
                    CommanUtil.isTrackingOn = true;
                    var intent = new Intent(this, typeof(LoginActivity));
                    intent.SetAction(Intent.Action);
                    intent.AddCategory(Intent.CategoryHome);
                    intent.PutExtra("logOut", "Logout");
                    intent.SetFlags(ActivityFlags.ClearTop | ActivityFlags.ClearTask | ActivityFlags.NewTask);
                    StartActivity(intent);
                    this.Finish();
                }
                base.OnBackPressed();
            }
            catch
            {
                Finish();
            }
        }


    }

}