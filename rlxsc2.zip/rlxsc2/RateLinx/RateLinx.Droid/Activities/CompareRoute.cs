using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Views;
using Android.Widget;
using RateLinx.Helper;
using System.Threading.Tasks;
using System.Net;
using Android.Gms.Maps.Model;
using Android.Gms.Maps;
using RateLinx.Droid.Utilities;
using RateLinx.Droid.GoogleMapServices;
using Newtonsoft.Json;
using RateLinx.GoogleServices;
using Android.Graphics;
using Android.Locations;
using RateLinx.APIs;
using Newtonsoft.Json.Linq;
using Android.Support.V7.App;
using Android.Content.PM;

namespace RateLinx.Droid.Activities
{
    /// <summary>
    /// Compare Route Meta Tag
    /// </summary>
    //[Activity(Label = "CompareRoute")]
    [Activity(Label = Constants.appName, Icon = "@drawable/icon", Theme = "@style/Theme.AppCompat.NoActionBar", ConfigurationChanges = ConfigChanges.Orientation | ConfigChanges.ScreenSize, LaunchMode = LaunchMode.SingleTop)]
    public class CompareRoute : AppCompatActivity
    {
        #region defing variables
        GoogleMap map = null;
        SupportMapFragment mapFrag = null;
        TextView txtViewShipmentNo = null;
        LatLng latLngSource;
        LatLng latLngDestination;
        TextView txtOptimalRoute, txtCarrierRout;
        string strOrgin = string.Empty;
        string strDest = string.Empty;
        #endregion

        /// <summary>
        /// Compare Route
        /// </summary>
        /// <param name="savedInstanceState"></param>
        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);
                //Remove Header Title
                RequestWindowFeature(WindowFeatures.NoTitle);
                if (string.IsNullOrEmpty(CommanUtil.tokenNo))
                {
                    Utility.Logout(this);
                }
                // Set our view from the "Startup Page" layout resource
                SetContentView(Resource.Layout.CompareRoute);
                SetUpGoogleMap();
            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.ToString(), CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
                Finish();
            }
        }

        /// <summary>
        /// SetUP Google Map
        /// </summary>
        private void SetUpGoogleMap()
        {
            if (!Utility.FnIsOnline(this))
            {
                Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                return;
            }
            //Find Controls
            mapFrag = (SupportMapFragment)SupportFragmentManager.FindFragmentById(Resource.Id.map);
            txtViewShipmentNo = FindViewById<TextView>(Resource.Id.txtViewShipment);
            LinearLayout lnrLayoutBackIcon = FindViewById<LinearLayout>(Resource.Id.lnrLayoutBackIcon);
            lnrLayoutBackIcon.Click += LnrLayoutBackIcon_Click; ;
            ImageView ImgBackIcon = FindViewById<ImageView>(Resource.Id.imgBackIcon);
            txtOptimalRoute = FindViewById<TextView>(Resource.Id.txtOptimalRoute);
            txtCarrierRout = FindViewById<TextView>(Resource.Id.txtCarrierRout);
            ImgBackIcon.Click += ImgBackIcon_Click;
            txtViewShipmentNo.Text = "";
            //Displaying Map after getting the details
            var mapReadyCallback = new OnMapReadyClass();
            mapReadyCallback.MapReadyAction += async delegate (GoogleMap objMap)
            {
                map = objMap;
                map.TrafficEnabled = true;
                await FnplotMap(map); //Plot Map
            };
            mapFrag.GetMapAsync(mapReadyCallback);
        }

        /// <summary>
        /// Back Icon
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgBackIcon_Click(object sender, EventArgs e)
        {
            Finish();
        }

        /// <summary>
        /// Back Button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LnrLayoutBackIcon_Click(object sender, EventArgs e)
        {
            Finish();
        }

        /// <summary>
        /// On Map ready
        /// </summary>
        /// <param name="googleMap"></param>
        public async Task FnplotMap(GoogleMap googleMap)
        {

            Alerts.showBusyLoader(this);
            this.map = googleMap;
            string place = Intent.GetStringExtra("location");
            var addresses = place.Split('#');
            strOrgin = addresses[0];
            var ShipmentNo = addresses[2].Split(':');
            txtViewShipmentNo.Text = ShipmentNo[0];
            //Get Lat Long 
            bool result = await FnLocationToLatLng(addresses[0], addresses[1]);
            if (result)
            {
                //Set Camera Position
                FnUpdateCameraPosition(latLngSource);
                if (latLngSource != null && latLngDestination != null)
                    await FnDrawPath(addresses[0], addresses[1]);
                Alerts.HideBusyLoader();
            }
            else
            {
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Short).Show();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="strSource"></param>
        /// <param name="strDestination"></param>
        async Task FnDrawPath(string strSource, string strDestination)
        {
            try
            {
                string strFullDirectionURL = string.Format(Constants.strGoogleDirectionUrl, strSource, strDestination);
                string strJSONDirectionResponse = await FnHttpRequest(strFullDirectionURL);
                if (strJSONDirectionResponse != Constants.strException)
                {
                    RunOnUiThread(() =>
                    {
                        if (map != null)
                        {
                            map.Clear();
                            MarkOnMap(/*Constants.strTextSource*/"Origin", strSource, latLngSource, Resource.Drawable.MarkerSource);
                            MarkOnMap(Constants.strTextDestination, strDestination, latLngDestination, Resource.Drawable.MarkerDest);
                        }
                    });
                   await FnSetDirectionQuery(strJSONDirectionResponse);
                }
                else
                {
                    RunOnUiThread(() =>
                       Toast.MakeText(this, Constants.strUnableToConnect, ToastLength.Short).Show());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="strJSONDirectionResponse"></param>
        private async Task FnSetDirectionQuery(string strJSONDirectionResponse)
        {
            try
            {
                var objRoutes = JsonConvert.DeserializeObject<GoogleDirectionClass>(strJSONDirectionResponse);
                //objRoutes.routes.Count  --may be more then one 
                if (objRoutes.routes.Count > 0)
                {
                    string encodedPoints = objRoutes.routes[0].overview_polyline.points;

                    var lstDecodedPoints = FnDecodePolylinePoints(encodedPoints);
                    //convert list of location point to array of latlng type
                    var latLngPoints = new LatLng[lstDecodedPoints.Count];
                    int index = 0;
                    foreach (GoogleServices.Location loc in lstDecodedPoints)
                    {
                        latLngPoints[index++] = new LatLng(loc.lat, loc.lng);
                    }
                    //Calculation of miles and Kilometer
                    //double mile, km;
                    string distance = objRoutes.routes.Select(m => m.legs.Select(len => len.distance.text).FirstOrDefault()).FirstOrDefault();
                    //mile = Convert.ToDouble(distance.Split(' ')[0]);
                    //km = mile * 1.609344;
                    //string optimalRoute = Math.Round(km, 1).ToString();
                    txtOptimalRoute.Text = Constants.strOptimalRout + distance.Split(' ')[0] + Constants.mile;
                    txtCarrierRout.Text = Constants.strCarrierRoute + "0" + Constants.mile;
                    var polylineoption = new PolylineOptions();
                    polylineoption.InvokeColor(Color.Red);
                    polylineoption.Geodesic(true);
                    polylineoption.Add(latLngPoints);
                    RunOnUiThread(() =>
                    map.AddPolyline(polylineoption));
                    //Calculate Carrier Route
                    await CalCarrierRoute(); // TrackingInterval();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="encodedPoints"></param>
        /// <returns></returns>
        List<GoogleServices.Location> FnDecodePolylinePoints(string encodedPoints)
        {
            if (string.IsNullOrEmpty(encodedPoints))
                return null;
            var poly = new List<GoogleServices.Location>();
            char[] polylinechars = encodedPoints.ToCharArray();
            int index = 0;

            int currentLat = 0;
            int currentLng = 0;
            int next5bits;
            int sum;
            int shifter;

            try
            {
                while (index < polylinechars.Length)
                {
                    // calculate next latitude
                    sum = 0;
                    shifter = 0;
                    do
                    {
                        next5bits = (int)polylinechars[index++] - 63;
                        sum |= (next5bits & 31) << shifter;
                        shifter += 5;
                    } while (next5bits >= 32 && index < polylinechars.Length);

                    if (index >= polylinechars.Length)
                        break;

                    currentLat += (sum & 1) == 1 ? ~(sum >> 1) : (sum >> 1);

                    //calculate next longitude
                    sum = 0;
                    shifter = 0;
                    do
                    {
                        next5bits = (int)polylinechars[index++] - 63;
                        sum |= (next5bits & 31) << shifter;
                        shifter += 5;
                    } while (next5bits >= 32 && index < polylinechars.Length);

                    if (index >= polylinechars.Length && next5bits >= 32)
                        break;

                    currentLng += (sum & 1) == 1 ? ~(sum >> 1) : (sum >> 1);
                    GoogleServices.Location p = new GoogleServices.Location();
                    p.lat = Convert.ToDouble(currentLat) / 100000.0;
                    p.lng = Convert.ToDouble(currentLng) / 100000.0;

                    poly.Add(p);


                }
            }
            catch
            {
                RunOnUiThread(() =>
                  Toast.MakeText(this, Constants.strPleaseWait, ToastLength.Short).Show());
            }
            return poly;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pos"></param>
        private void FnUpdateCameraPosition(LatLng pos)
        {
            try
            {
                CameraPosition.Builder builder = CameraPosition.InvokeBuilder();
                builder.Target(pos);
                builder.Zoom(8);
                //builder.Bearing(45);
                //builder.Tilt(10);
                CameraPosition cameraPosition = builder.Build();
                CameraUpdate cameraUpdate = CameraUpdateFactory.NewCameraPosition(cameraPosition);
                map.AnimateCamera(cameraUpdate);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="strSource"></param>
        /// <param name="strDestination"></param>
        /// <returns></returns>
        async Task<bool> FnLocationToLatLng(string strSource, string strDestination)
        {
            try
            {
                var geo = new Geocoder(this);
                var sourceAddress = await geo.GetFromLocationNameAsync(strSource, 1);
                sourceAddress.ToList().ForEach((addr) =>
                {
                    latLngSource = new LatLng(addr.Latitude, addr.Longitude);
                });

                var destAddress = await geo.GetFromLocationNameAsync(strDestination, 1);
                destAddress.ToList().ForEach((addr) =>
                {
                    latLngDestination = new LatLng(addr.Latitude, addr.Longitude);
                });

                return true;
            }
            catch (AggregateException ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="title"></param>
        /// <param name="address"></param>
        /// <param name="pos"></param>
        /// <param name="resourceId"></param>
        private void MarkOnMap(string title, string address, LatLng pos, int resourceId)
        {
            RunOnUiThread(() =>
            {
                try
                {
                    var marker = new MarkerOptions();
                    marker.SetTitle(title);
                    marker.SetPosition(pos); //Resource.Drawable.BlueDot
                    marker.SetSnippet(address);
                    marker.SetIcon(BitmapDescriptorFactory.FromResource(resourceId));
                    map.AddMarker(marker);
                }
                catch
                {
                    throw;
                }
            });
        }

        private async Task CalCarrierRoute()
        {
            try
            {
                if (!Utility.FnIsOnline(this))
                {
                    Alerts.HideBusyLoader();
                    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                if (CommanUtil.IsTimeOut())
                {
                    Geocoder geocoder = new Geocoder(this);
                    StringBuilder deviceAddress = new StringBuilder();
                    ServiceHelper objHelper = new ServiceHelper();
                    JObject jobject;
                    string methodName = APIMethods.specTrackingPosition + txtViewShipmentNo.Text;
                    string response = await objHelper.GetRequest(CommanUtil.tokenNo, methodName, true);
                    if (!string.IsNullOrEmpty(response))
                    {
                        jobject = JObject.Parse(response);
                        if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
                        {
                            Models.TrackShipment trackingDetail = JsonConvert.DeserializeObject<Models.TrackShipment>(response);
                            if (!string.IsNullOrEmpty(trackingDetail.ShipmentPos[0].ErrorMsg))
                            {
                                Toast.MakeText(this, trackingDetail.ShipmentPos[0].ErrorMsg, ToastLength.Long).Show();
                                return;
                            }
                            else
                            {
                                //Get the details of shipment and trying to show in map
                                for (int index = 0; index < trackingDetail.ShipmentPos.Count; index++)
                                {
                                    string city, Country, State = string.Empty;
                                    if (trackingDetail.ShipmentPos[index].Positions[index] != null)
                                    {
                                        city = trackingDetail.ShipmentPos[index].Positions[index].City;
                                        State = trackingDetail.ShipmentPos[index].Positions[index].State;
                                        Country = trackingDetail.ShipmentPos[index].Positions[index].Country;
                                        strDest = city + " " + State + " " + Country;
                                    }
                                    else
                                    {
                                        strDest = string.Empty;
                                    }
                                    if (strDest != null)
                                    {
                                        string strFullDirectionURL = string.Format(Constants.strGoogleDirectionUrl, strOrgin, strDest);
                                        string strJSONDirectionResponse = await FnHttpRequest(strFullDirectionURL);
                                        if (strJSONDirectionResponse != Constants.strException)
                                        {
                                            var objRoutes = JsonConvert.DeserializeObject<GoogleDirectionClass>(strJSONDirectionResponse);
                                            //objRoutes.routes.Count  --may be more then one 
                                            if (objRoutes.routes.Count > 0)
                                            {
                                                //Calculation of miles and Kilometer
                                                string distance = objRoutes.routes.Select(m => m.legs.Select(len => len.distance.text).FirstOrDefault()).FirstOrDefault();
                                                txtCarrierRout.Text = Constants.strCarrierRoute + distance.Split(' ')[0] + Constants.mile;
                                            }
                                        }
                                        else
                                        {
                                            txtCarrierRout.Text = Constants.strCarrierRoute + "0" + Constants.mile;
                                            RunOnUiThread(() =>
                                               Toast.MakeText(this, Constants.strUnableToConnect, ToastLength.Short).Show());
                                        }
                                    }
                                    else
                                    {
                                        txtCarrierRout.Text = Constants.strCarrierRoute + "0" + Constants.mile;
                                        Toast.MakeText(this, GetString(Resource.String.trackLocation), ToastLength.Long).Show();
                                    }
                                }
                            }
                        }
                        else
                        {
                            txtCarrierRout.Text = Constants.strCarrierRoute + "0" + Constants.mile;
                            response = string.Empty;
                            //Post Error Logger Request 
                            Utility.ErrorLog(Constants.strLiveTrack, Convert.ToString(jobject[Constants.strErrorMessage]), CommanUtil.tokenNo, this);
                            Toast.MakeText(this, Convert.ToString(jobject[Constants.strErrorMessage]), ToastLength.Long).Show();
                            return;
                        }
                    }
                }
                else
                {
                    //Toekn Exired
                    Utility.ExpireSession(this);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        WebClient webclient;
        async Task<string> FnHttpRequest(string strUri)
        {
            webclient = new WebClient();
            string strResultData;
            try
            {
                strResultData = await webclient.DownloadStringTaskAsync(new Uri(strUri));
                Console.WriteLine(strResultData);
            }
            catch
            {
                strResultData = Constants.strException;
            }
            finally
            {
                if (webclient != null)
                {
                    webclient.Dispose();
                    webclient = null;
                }
            }
            return strResultData;
        }
    }
}