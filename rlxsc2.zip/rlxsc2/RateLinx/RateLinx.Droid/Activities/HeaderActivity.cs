using System;
using Android.App;
using Android.Content;
using Android.OS;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;
using Android.Support.V4.Content;
using Android.Widget;

namespace RateLinx.Droid.Activities
{
    /// <summary>
    /// Activity To Call The Notification Message
    /// </summary>
    [Activity(Label = "HeaderActivity")]
    public class HeaderActivity : Activity
    {

        /// <summary>
        /// 
        /// </summary>
        IncomingMessageReceiver receiver;
        

        /// <summary>
        /// On load method
        /// </summary>
        /// <param name="savedInstanceState"></param>
        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);
                Utility.activity = this;
                if (GetType().ToString()!=Constants.loginActivity)
                {
                    Utility.ExpireSession(this);
                }
                //CommanUtil.loginTime = DateTime.Now;
                
                receiver = new IncomingMessageReceiver();
                LocalBroadcastManager.GetInstance(this).RegisterReceiver(receiver, new IntentFilter(Constants.strMessageReceiver));
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

       
        /// <summary>
        /// On destroy method
        /// </summary>
        protected override void OnDestroy()
        {
            try
            {
                base.OnDestroy();
                LocalBroadcastManager.GetInstance(this).UnregisterReceiver(receiver);
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }
        
    }
}