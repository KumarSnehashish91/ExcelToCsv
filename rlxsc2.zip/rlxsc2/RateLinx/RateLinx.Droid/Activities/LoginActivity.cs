using System;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Views;
using Android.Widget;
using Newtonsoft.Json.Linq;
using Android.Preferences;
using RateLinx.Droid.Utilities;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RateLinx.Helper;
using RateLinx.APIs;
using RateLinx.Models;
using RateLinx.Droid.PushNotificationService;
using Android.Content.PM;
using Android.Support.V4.Content;
using Android;
using Android.Support.V4.App;
using RateLinx.Droid.GoogleMapServices;

namespace RateLinx.Droid.Activities
{
    /// <summary>
    /// Login Activities
    /// </summary>
    [Activity(Label = Constants.appName, MainLauncher = false, Icon = "@drawable/icon", NoHistory = true, LaunchMode =LaunchMode.SingleTop)]
    public class LoginActivity : HeaderActivity
    {
        #region Global used variables
        ServiceHelper objServicehelper = null;
        AccountSettings objAccountSettings = null;
        JObject jobject = null;
        Button button = null;
        Switch rememberMeSwitch;
        LoginModels objLogin;
        bool isRemember = false;
        EditText txtClientId, txtUserName, txtPassword = null;
        string validationMessage = string.Empty;
        string postData = string.Empty;
        string methodName = string.Empty;
        string strToken = string.Empty;
        string strMinVersion = string.Empty;
        string strResponse = string.Empty;
        bool isLogin = false;
        string clientID = string.Empty;
        string loadNum = string.Empty;
        string slideNo = string.Empty;
        public string compositValue = string.Empty;
        public string compositekey = string.Empty;
       
        Dialog dialog = null;
        bool isForcedLogin = false;
        Utility objUtil = null;
        const int RequestLocationId = 0;
        readonly string[] PermissionsLocation =
                          {
         Manifest.Permission.AccessCoarseLocation,
         Manifest.Permission.AccessFineLocation,
         Manifest.Permission.Camera,
         Manifest.Permission.WriteExternalStorage };

        #endregion

        /// <summary>
        /// Login page Load event Handler  
        /// </summary>
        /// <param name="bundle"></param>
        protected async override void OnCreate(Bundle bundle)
        {
            try
            {
                base.OnCreate(bundle);
                //Remove Header Title
                RequestWindowFeature(WindowFeatures.NoTitle);
                // Set our view from the "Startup Page" layout resource
                SetContentView(Resource.Layout.Login);
                //Close keyboard on load
                this.Window.SetSoftInputMode(SoftInput.StateAlwaysHidden);
                #region  Clear Local stored values
                Utility.sharedPreferences = PreferenceManager.GetDefaultSharedPreferences(this);

                //if (Intent.GetStringExtra("compositeKey") != null)
                //{
                //    compositekey = Intent.GetStringExtra("compositekey");
                //    compositeValue = Intent.GetStringExtra("compositeKey").Split('|');
                //}

                //Utility.sharedPreferences.Edit().Remove(Constants.strActiveShipment).Commit();
                //Utility.sharedPreferences.Edit().Remove(Constants.strAwardedShipment).Commit();
                //Utility.sharedPreferences.Edit().Remove(Constants.strRecentShipment).Commit();

                //CommanUtil.tokenNo = string.Empty;
                CommanUtil.ViewAs = string.Empty;
                CommanUtil.userID = string.Empty;
                CommanUtil.isTrackingEnable = false;
                CommanUtil.isTrackingOn = true;
                #endregion
                #region Allow permission checks
                if ((ContextCompat.CheckSelfPermission(this, Manifest.Permission.AccessFineLocation) != (int)Permission.Granted) &&
                     (ContextCompat.CheckSelfPermission(this, Manifest.Permission.AccessCoarseLocation) != (int)Permission.Granted) &&
                     (ContextCompat.CheckSelfPermission(this, Manifest.Permission.Camera) != (int)Permission.Granted) &&
                     (ContextCompat.CheckSelfPermission(this, Manifest.Permission.WriteExternalStorage) == (int)Permission.Granted))
                {
                    #region Start Location service
                    GPSServiceSettings gPSServiceSettings = new GPSServiceSettings();
                    gPSServiceSettings.StartLocationUpdates(null);
                    gPSServiceSettings = null;
                    #endregion

                }
                else
                {
                    ActivityCompat.RequestPermissions(this, PermissionsLocation, RequestLocationId);
                }
                #endregion
                await GetControlId();
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
                //Crashlytics.Crashlytics.LogException(Java.Lang.Throwable.FromException(ex));
            }
        }

        /// <summary>
        /// On Request Permissions Result
        /// </summary>
        /// <param name="requestCode"></param>
        /// <param name="permissions"></param>
        /// <param name="grantResults"></param>
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
        {
            try
            {
                //     Toast.MakeText(this, "in onrequestpermissionresull", ToastLength.Long).Show();
                switch (requestCode)
                {
                    case RequestLocationId:
                        {
                            if (grantResults[0] == Permission.Granted)
                            {
                                #region Start Location service
                                GPSServiceSettings gPSServiceSettings = new GPSServiceSettings();
                                gPSServiceSettings.StartLocationUpdates(null);
                                gPSServiceSettings = null;
                                #endregion
                            }
                            else
                            {
                                //Toast.MakeText(this, "Camera permission is denied.", ToastLength.Short).Show();
                            }
                        }
                        break;
                }
            }
            catch { }
        }

        /// <summary>
        /// Get our UI controls from the loaded layout:
        /// </summary>
        private async Task GetControlId()
        {
            try
            {
                // Get our controls from the layout resource,
                button = FindViewById<Button>(Resource.Id.btnLogin);
                txtClientId = FindViewById<EditText>(Resource.Id.txtClientID);
                txtUserName = FindViewById<EditText>(Resource.Id.txtUserName);
                txtPassword = FindViewById<EditText>(Resource.Id.txtPassword);
                rememberMeSwitch = FindViewById<Switch>(Resource.Id.rememberMeSwitch);
                //Get the service Helper Object
                objServicehelper = new ServiceHelper();
                rememberMeSwitch.CheckedChange += delegate (object sender, CompoundButton.CheckedChangeEventArgs e)
                {
                    isRemember = e.IsChecked;
                };
                //To Check the Credentials are Stored in Local memory
                postData = Utility.sharedPreferences.GetString(Constants.userCredential, null);
                //Login button click event
                button.Click += async delegate
                {
                   await btnLogin_Click();
                };
                if (!string.IsNullOrEmpty(postData))
                {
                    objLogin = JsonConvert.DeserializeObject<LoginModels>(postData);
                    if (objLogin != null && objLogin.IsRemember)
                    {
                        rememberMeSwitch.Checked = true;
                    }
                    else
                    {
                        rememberMeSwitch.Checked = false;

                    }
                    //If Login details are rememberd
                    await IsRememberLoginDetail();
                }
                else
                {
                    rememberMeSwitch.Checked = false;
                    Bundle notificationData = Intent.GetBundleExtra("message");
                    if (notificationData != null)
                    {
                        GetNotification();
                        ShowPopup(notificationData);
                    }
                }
                //GetNotification();
                
               
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Login Button Click 
        /// </summary>
        ///// <param name="sender"></param>
        ///// <param name="e"></param>
        //public async void btnLogin_Click(object sender, EventArgs e)
        public async Task btnLogin_Click()
        {
            try
            {
                //Test Internet Connection
                if (!Utility.FnIsOnline(this))
                {
                    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                else
                {
                    //txtClientId.Text = "demo";
                    //txtUserName.Text = "chetu";
                    //txtPassword.Text = "chetu123";
                    //txtClientId.Text = "demotl";
                    //txtUserName.Text = "demo";
                    //txtPassword.Text = "demo";
                    //------------- Login Fields Validation check------//
                    validationMessage = IsRequiredValidated();
                    if (!string.IsNullOrEmpty(validationMessage))
                    {
                        Toast.MakeText(this, validationMessage, ToastLength.Long).Show();
                        return;
                    }
                    else
                    {
                        Alerts.showBusyLoader(this); //Loader
                                                     //Parameters
                        LoginModels objLogin = new LoginModels
                        {
                            ClientID = txtClientId.Text,
                            UserName = txtUserName.Text,
                            Password = txtPassword.Text,
                            FromDevice = Constants.strAndroid,
                            IsRemember = isRemember
                        };
                        postData = JsonConvert.SerializeObject(objLogin);
                        //Store login credentials in local storage
                        Utility.sharedPreferences.Edit().PutString(Constants.userCredential, postData).Commit();
                       // compositekey= Utility.sharedPreferences.GetString("notification_compositekey", null);
                        //if (!string.IsNullOrEmpty(compositekey))
                        //{
                        //    var clientID = compositekey.Split('#')[2];
                        //    var loadNum = compositekey.Split('#')[1];
                        //    var slideNo = compositekey.Split('#')[3];
                        //    var composit_Value = clientID + "|" + loadNum + "|" + slideNo;
                            //compositeValue = compositekey;
                        //}
                        //Toast.MakeText(this, compositekey, ToastLength.Long).Show();
                        await Task.Delay(500);
                        isLogin = await Login(postData);
                        if (isLogin)
                        {
                           // GetNotification();   ----- commented for testing
                            //CommanUtil.stopPooling = false;
                            CommanUtil.refresh = true;
                            // TrackingInterval();
                            if (!string.IsNullOrEmpty(compositValue))
                            {
                                Intent objIntent = new Intent(this, typeof(ShipmentsDetailedActivity));
                                objIntent.PutExtra("compositekey", compositValue);
                                StartActivity(objIntent);
                            }
                            else
                            {
                                StartActivity(typeof(HomeActivity));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Alerts.HideBusyLoader(); //Loader
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Back click of mobile device
        /// </summary>
        /// <param name="keyCode"></param>
        /// <param name="e"></param>
        /// <returns></returns>
        public override bool OnKeyDown(Keycode keyCode, KeyEvent e)
        {
            try
            {
                if (e.KeyCode == Keycode.Back)
                {
                    this.FinishAffinity();
                    return true;
                }
                return base.OnKeyDown(keyCode, e);
            }
            catch(Exception ex)
            {
                Toast.MakeText(this, ex.Message, ToastLength.Long).Show();
                return false;
            }
        }

        /// <summary>
        /// Requesting To API for Login 
        /// </summary>
        /// <param name="requestData"></param>
        public async Task<bool> Login(string requestData)
        {
            try
            {
                //Method Name
                bool result;
                methodName = APIMethods.auth;
                if (objServicehelper == null)
                {
                    objServicehelper = new ServiceHelper();
                    Alerts.showBusyLoader(this);
                }
                strResponse = await objServicehelper.PostRequestJson(requestData, methodName, "", false);
                if (!string.IsNullOrEmpty(strResponse))
                {
                    try
                    {
                        // create json object that holds the api values
                        jobject = JObject.Parse(strResponse);
                    }
                    catch(Exception ex)
                    {
                        Alerts.HideBusyLoader();
                        Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
                        throw ex;
                    }
                    if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
                    {
                        strToken = Convert.ToString(jobject["Token"]);
                        strMinVersion = Convert.ToString(jobject["MinVersionReq"]);
                        if (!CommanUtil.IsTimeOut())
                        {
                            result = await UserLoginDetails();
                            return result;
                        }
                            //Compare min and max version to update the application
                            PackageManager manager = PackageManager;
                        PackageInfo info = manager.GetPackageInfo(PackageName, 0);
                        //if (FnCompareVersion(strMinVersion, info.VersionName))
                        //{
                        //    result= await UserLoginDetails();
                        //    return result;
                        //}
                        //else
                        //{
                        //   /* Alerts.HideBusyLoader();*/ //hide Loader

                        //    //Redirect To app store to update the latest application
                        //    if (isForcedLogin == false)
                        //    {
                        //        Alerts.HideBusyLoader();
                        //        RedirectToPlayStore();
                        //        return false;
                        //    }
                        //    else
                        //    {
                        //        result = await UserLoginDetails();
                        //        return result;
                        //    }
                        //    //else
                        //    //{
                        //    //    return false;
                        //    //}

                        //}
                        result = await UserLoginDetails();
                        return result;
                    }
                    else
                    {
                        Alerts.HideBusyLoader(); //Loader
                        Toast.MakeText(this, Convert.ToString(jobject[Constants.strErrorMessage]), ToastLength.Long).Show();
                        return false;
                    }
                }
                else
                {
                    Alerts.HideBusyLoader(); //Loader
                    return false;
                }
            }
            catch(AggregateException ex)
            {
                Alerts.HideBusyLoader();
                //return false;
                throw ex;                
            }
            finally
            {
                Alerts.HideBusyLoader();
                //Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }
        /// <summary>
        /// 
        /// </summary>
        protected async Task<bool> UserLoginDetails()
        {
            try
            {
                CommanUtil.loginTime = DateTime.Now;
                CommanUtil.tokenNo = strToken;
                //Is push notification enable
                if (IsPushNotification())
                {
                    //Checking Account Settings
                    await GetAccountsDetail(strToken);
                    if (objAccountSettings != null)
                    {
                        CommanUtil.UserPermissions = objAccountSettings.Permissions;
                        CommanUtil.userID = objAccountSettings.UserID;
                        CommanUtil.ViewAs = objAccountSettings.ClientType;
                        return true;
                    }
                    else
                    {
                        Alerts.HideBusyLoader(); //Loader
                        return false;
                    }
                }
                else
                {
                    Alerts.HideBusyLoader(); //Loader
                    return false;
                }
            }
            catch(Exception ex)
            {
                //Alerts.HideBusyLoader();
                //return false;
                throw ex;
            }
        }
        /// <summary>
        /// Redirect To Play Store
        /// </summary>
        protected void RedirectToPlayStore()
        {

            objUtil = new Utility();
            dialog = objUtil.ConfirmationAlert(this);
            Button btnYes = dialog.FindViewById<Button>(Resource.Id.btnYes);
            Button btnNo = dialog.FindViewById<Button>(Resource.Id.btnNo);
            LinearLayout lntlayoutReason = dialog.FindViewById<LinearLayout>(Resource.Id.lntlayoutReason);
            btnYes.Text = Constants.btnUpgrade;
            btnNo.Text = Constants.btnTextCancel;
            lntlayoutReason.Visibility = ViewStates.Gone;
            TextView txtMessage = dialog.FindViewById<TextView>(Resource.Id.txtMessage);
            txtMessage.Text = Constants.redirectionMessage;
            btnYes.Click += delegate
            {
                dialog.Hide();
                var uriAppStore = Android.Net.Uri.Parse(Constants.strPlayStoreURI);
                var intentAppStore = new Intent(Intent.ActionView, uriAppStore);
                StartActivity(intentAppStore);
            };
            btnNo.Click += delegate
            {
                dialog.Hide();
                isForcedLogin = true;
                btnLogin_Click();
            };

            //return isForcedLogin;
        }

        /// <summary>
        /// Compare app version
        /// </summary>
        /// <param name="strMinVersion">new app version</param>
        /// <param name="versionNumber">installed app version</param>
        private bool FnCompareVersion(string strMinVersion, string versionNumber)
        {
            string[] minVersionReq_Arr = strMinVersion.Split('.');
            int minVersionReq_int = (Convert.ToInt32(minVersionReq_Arr[0] + minVersionReq_Arr[1] + minVersionReq_Arr[2]));
            var appVersion_Arr = versionNumber.Split('.');
            int appVersion = (Convert.ToInt32(appVersion_Arr[0] + appVersion_Arr[1] + appVersion_Arr[2]));
            if (minVersionReq_int <= appVersion)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Login Fields Validation check Validate the text fields
        /// </summary>
        /// <returns></returns>
        private string IsRequiredValidated()
        {
            try
            {
                validationMessage = string.Empty;
                //-----ClientID field----//
                if (string.IsNullOrEmpty(txtClientId.Text))
                {
                    validationMessage = Constants.strClientID;
                }
                else if (txtClientId.Length() > 50)
                {
                    validationMessage = Constants.strClientIDLength;
                }
                //-----User Name field----//
                else if (string.IsNullOrEmpty(txtUserName.Text))
                {
                    validationMessage = Constants.strUserId;
                }
                else if (txtUserName.Length() > 50)
                {
                    validationMessage = Constants.strUserIdLength;
                }
                //-----Password field----//
                else if (string.IsNullOrEmpty(txtPassword.Text))
                {
                    validationMessage = Constants.strPassword;
                }
                return validationMessage;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        ///  Method to hide charges when Driver is logged in
        /// </summary>
        /// <param name="token">Token No generated from login API</param>
        private async Task GetAccountsDetail(string token)
        {
            try
            {
                string searchResult = string.Empty;
                methodName = APIMethods.getAccountDetails;
                if (objServicehelper == null)
                {
                    objServicehelper = new ServiceHelper();
                }
                strResponse = await objServicehelper.GetRequest(token, methodName, true);
                if (strResponse != null)
                {
                    jobject = JObject.Parse(strResponse);
                    if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
                    {
                        // convert json to own object that holds the api response  
                        objAccountSettings = JsonConvert.DeserializeObject<AccountSettings>(strResponse);
                        List<string> permission = objAccountSettings.Permissions;
                        searchResult = permission.Where(x => x.Equals("DRIVERROLE")).FirstOrDefault();
                        if (!string.IsNullOrEmpty(searchResult))
                        {
                            CommanUtil.isShowCharges = false;
                        }
                        else
                        {
                            CommanUtil.isShowCharges = true;
                        }
                    }
                    else
                    {
                        objAccountSettings = null;
                        Alerts.HideBusyLoader(); //Hide Loader
                        Toast.MakeText(this, Convert.ToString(jobject[Constants.strErrorMessage]), ToastLength.Long).Show();
                        //Post Error Logger Request 
                        Utility.ErrorLog(APIMethods.getAccountDetails, Convert.ToString(jobject[Constants.strErrorMessage]), token, this);
                    }
                    strResponse = string.Empty;
                }
            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// Is Notification Allowed
        /// </summary>
        private bool IsPushNotification()
        {
            try
            {
                CommanUtil.isPushAllowed = Utility.sharedPreferences.GetBoolean("isPushAllowed", true);
                //if (!string.IsNullOrEmpty(strToken) && CommanUtil.isPushAllowed)
                if (!string.IsNullOrEmpty(strToken))
                {
                    if (CommanUtil.isPushAllowed)
                    {
                        CallRegisterIntentService();                        
                    }
                    else
                    {
                        // No registration required for FCM token
                    }
                    return true;
                }
                else
                {
                    Toast.MakeText(this, Constants.strDeviceReady, ToastLength.Long).Show();
                    return false;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Call To Register Service
        /// </summary>
        /// <returns></returns>
        private string CallRegisterIntentService()
        {
            try
            {
                if (RegisterService.IsPlayServicesAvailable(this))
                {
                    var intent = new Intent(this, typeof(RegistrationIntentService));
                    this.StartService(intent);
                }
                return Constants.strSucceed;
            }
            catch
            {
                return Constants.strException;
            }
        }

        /// <summary>
        /// Auto Login
        /// </summary>
        private async Task AutoLogin()
        {
            try
            {
                //string notificationData = GetNotification();
                Bundle notificationData = Intent.GetBundleExtra("background_Notification");
               
                   
               
                //Internet Connection Availabilty
                if (Utility.FnIsOnline(this))
                {
                    Alerts.showBusyLoader(this); //Loader
                    await Task.Delay(500);
                    isLogin = await Login(postData);
                    if (isLogin)
                    {
                        if (notificationData!=null)
                        {
                            //Intent intent = Utility.RedirectTo(this, typeof(ShipmentsDetailedActivity), compositekey, compositValue);
                            //StartActivity(intent);
                            ShowPopup(notificationData);
                        }
                        else
                        {
                            StartActivity(typeof(HomeActivity));
                        }
                    }
                    else
                    {
                        Alerts.HideBusyLoader();
                        //Toast.MakeText(this, Constants.strCredentials, ToastLength.Long).Show();
                    }
                }
                else
                {
                    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
            }
            catch(AggregateException ex)
            {               
                Alerts.HideBusyLoader();
                throw ex;
            }
        }

        /// <summary>
        /// If Remembered Login Detail and Logout Feature while Remember me true
        /// Also we have Background notification implementation
        /// </summary>
        private async Task IsRememberLoginDetail()
        {
            try
            {
                Bundle notificationData = Intent.GetBundleExtra("background_Notification");
                if (objLogin != null && objLogin.IsRemember)
                {
                    txtClientId.Text = objLogin.ClientID;
                    txtUserName.Text = objLogin.UserName;
                    txtPassword.Text = objLogin.Password;
                    if (string.IsNullOrEmpty(Intent.GetStringExtra(Constants.strLogOut)))
                    {
                        await AutoLogin(); //If App open 
                    }
                    else
                    {
                        //Force Logout Case
                    }
                }
                else
                {
                    if(notificationData!=null)
                    {
                        GetNotification();
                        ShowPopup(notificationData);
                    }
                    txtClientId.Text = txtUserName.Text = txtPassword.Text = string.Empty;
                    
                }
            }
            catch(AggregateException ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// GetNotification if app in background
        /// </summary>
        private string GetNotification()
        {
            //Bundle notificationData = Intent.GetBundleExtra("data");
            Bundle notificationData = Intent.GetBundleExtra("message");
           string url = Utility.sharedPreferences.GetString("notification_compositekey", null);
            if (url != null)
            {
                //Utility.sharedPreferences.Edit().Remove("notification_compositekey").Commit();
                //string url = notificationData.GetString("url");
                //clientID = url.Split('#')[2];
                //loadNum = url.Split('#')[1];
                //slideNo = url.Split('#')[3];
                //compositValue = clientID + "|" + loadNum + "|" + slideNo;
                compositValue = url;
                compositekey = Constants.compositeKey;
            }
            return compositValue;
        }
        /// <summary>
        /// Creating Dialog Or PopUp
        /// </summary>
        /// <param name="message"></param>
        /// <param name="context"></param>
        public void ShowPopup(Bundle message)
        {
            try
            {
                if (Utility.notificationCount == 0)
                {
                    Utility.notificationCount = 1;
                    //using BrodCast = Android.Support.V4.Content;
                    objUtil = new Utility();
                    // Activity context;
                    dialog = objUtil.ConfirmationAlert(this);
                    Button btnYes = dialog.FindViewById<Button>(Resource.Id.btnYes);
                    Button btnNo = dialog.FindViewById<Button>(Resource.Id.btnNo);
                    LinearLayout lntlayoutReason = dialog.FindViewById<LinearLayout>(Resource.Id.lntlayoutReason);
                    btnYes.Text = Constants.btnTextYes;
                    btnNo.Text = /*Constants.btnTextCancel*/"No";
                    lntlayoutReason.Visibility = ViewStates.Gone;
                    TextView txtMessage = dialog.FindViewById<TextView>(Resource.Id.txtMessage);
                    //Fill All The Details
                    string clientID = string.Empty;
                    string loadNum = string.Empty;
                    string slideNo = string.Empty;
                    string url = string.Empty;

                    if (!string.IsNullOrEmpty(Constants.notificationMsg))
                    {
                        txtMessage.Text = Constants.notificationMsg;


                        //if(txtMessage.Text.Contains("award") || txtMessage.Text.Contains("unaward") || txtMessage.Text.Contains("assined as the driver"))
                        //{
                        //    btnYes.Text = "OK";
                        //    btnNo.Visibility = ViewStates.Gone;
                        //}
                        if (txtMessage.Text.Contains("New TRUCKLOAD"))
                        {
                            txtMessage.Text += "." + "\n" + "Do you wish to go to shipment detail screen? ";
                            btnYes.Text = "Yes";
                        }
                        else
                        {
                            btnYes.Text = "OK";
                            btnNo.Visibility = ViewStates.Gone;
                        }
                    }

                    if (message != null)
                    {
                        url = message.GetString("url");
                    }
                    if (!string.IsNullOrEmpty(url))
                    {
                        txtMessage.Text = message.GetString("message"); //message
                        if (txtMessage.Text.Contains("New TRUCKLOAD"))
                        {
                            txtMessage.Text += "." + "\n" + "Do you wish to go to shipment detail screen? ";
                            btnYes.Text = "Yes";
                        }
                        else
                        {
                            btnYes.Text = "OK";
                            btnNo.Visibility = ViewStates.Gone;
                        }
                      
                    }
                    //If Click on Yes
                    btnYes.Click += delegate
                    {
                        if (btnYes.Text == "OK")
                        {
                            compositValue = string.Empty;
                            compositekey = string.Empty;
                            dialog.Hide();
                        }
                        else
                        {
                            clientID = url.Split('#')[2];
                            loadNum = url.Split('#')[1];
                            slideNo = url.Split('#')[3];
                            string compositValue = clientID + "|" + loadNum + "|" + slideNo;
                            string compositekey = "compositeKey";
                            string isLogin = CommanUtil.tokenNo;
                            string postData = Utility.sharedPreferences.GetString(Constants.userCredential, null);
                            if (!string.IsNullOrEmpty(postData))
                            {
                                Utility.sharedPreferences.Edit().PutString("notification_compositekey", compositValue).Commit();
                                //objLogin = JsonConvert.DeserializeObject<LoginModels>(postData);
                                if (objLogin != null && objLogin.IsRemember)
                                {
                                    Intent objIntent = new Intent(this, typeof(ShipmentsDetailedActivity));
                                    objIntent.PutExtra(compositekey, compositValue);
                                    this.StartActivity(objIntent);
                                }
                                //else
                                //{

                                //    if (objLogin != null && !string.IsNullOrEmpty(CommanUtil.ViewAs))
                                //    {
                                //        Intent objIntent = new Intent(this, typeof(ShipmentsDetailedActivity));
                                //        objIntent.PutExtra(compositekey, compositValue);
                                //        this.StartActivity(objIntent);
                                //    }
                                //    //context.Finish();
                                //    //Intent objIntent = new Intent(context, typeof(LoginActivity));
                                //    //objIntent.PutExtra(compositekey, compositValue);
                                //    //context.StartActivity(objIntent);
                                //    //Toast.MakeText(context, compositValue, ToastLength.Long).Show();

                                //}
                                dialog.Hide();

                            }


                            //        if (!string.IsNullOrEmpty(isLogin))
                            //{

                            //}

                        }
                    };

                    btnNo.Click += delegate
                    {
                        Alerts.HideBusyLoader();
                        compositValue = string.Empty;
                        compositekey = string.Empty;
                        if (objLogin != null && objLogin.IsRemember)
                        {
                            //Intent objIntent = new Intent(this, typeof(HomeActivity));
                            //this.StartActivity(objIntent);
                            StartActivity(typeof(HomeActivity));
                           
                        }
                        dialog.Hide();
                    };
                }
            }
            catch
            {
                //Console.Write(Constants.strErrorOccured);
            }
        }
    }
}