using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Gms.Maps;
using Android.Gms.Maps.Model;
using Android.Graphics;
using Android.Locations;
using Android.OS;
using Android.Views;
using Android.Views.Animations;
using Android.Widget;
using Newtonsoft.Json;
using PubnubApi;
using RateLinx.APIs;
using RateLinx.Droid.GoogleMapServices;
using RateLinx.Droid.ServiceModels;
using RateLinx.Droid.Utilities;
using RateLinx.GoogleServices;
using RateLinx.Helper;
using RateLinx.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using LatLng = Android.Gms.Maps.Model.LatLng;

namespace RateLinx.Droid.Activities
{
    /// <summary>
    /// , ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize, ScreenOrientation = ScreenOrientation.Portrait
    /// </summary>
    [Activity(Label = Constants.appName, Icon = "@drawable/icon", Theme = "@style/Theme.AppCompat.NoActionBar", ConfigurationChanges = ConfigChanges.Orientation | ConfigChanges.ScreenSize)]
    public class RealTimeTrackingActivity : HeaderActivity
    {
        #region defing variables
        SubscribeCallbackExt listener;
        /// <summary>
        /// 
        /// </summary>
        static public Pubnub pubnub;
        PNConfiguration config;
        GoogleMap map = null;
        MapFragment mapFrag = null;
        TextView txtAddressFrom, txtAddressTo, txtShipmentStatus, txtCurrentLocation, txtDistanceTravelled
            , txtTimeTaken, txtDistanceLeft, txtViewCopyRight = null;
        LatLng latLngSource, latLngStop;
        LatLng latLngDestination;
        // LatLng currentLatLang;
        ImageButton imgBtnShipDetails, imgBack = null;
        ImageView imViewSource, imViewDestination = null;
        //MarkerOptions options = null;
        LatLng lastSecodLatLong = null;
        PolylineOptions polylineoption = null;
        CameraPosition.Builder builder = null;
        CarrierShipmentDetails carrierShipmentDetails = null;
        CameraPosition cameraPosition = null;
        CameraUpdate cameraUpdate = null;
        float currentZoomLevel = 15;
        public string shipStatus;
        int hours = 0;
        Utility objUtility = null;
        int minutes = 0;
        int seconds = 0;
        Marker objMarker = null;
        string shipmentStatus = string.Empty;
        Dictionary<string, string> trackingStatus = null;
        string shipCompletedTime = string.Empty;
        string shipmentDetails = string.Empty;
        List<Models.ShipmentActivity> lstShipmentActivity = null;
        string[] addresses = null;
        ScrollView mainScrollView;
        List<string> shipmentAddress = null;
        string[] latlong = new[] { "28.621185 , 77.378664","28.621178 , 77.378711","28.621176 , 77.378755","28.621175 , 77.378779"
            ,"28.621170 , 77.378832","28.621166 , 77.378885","28.621165 , 77.378912","28.621164 , 77.378939","28.621162 , 77.379002"
            ,"28.621158 , 77.379034","28.621155 , 77.37908","28.621098, 77.379129","28.621104, 77.379074","28.621110, 77.379014"
            ,"28.621117, 77.378975","28.621121, 77.378941","28.621121, 77.378904","28.621125, 77.378855","28.621128, 77.378819"
            ,"28.621130, 77.378788","28.621130, 77.378749","28.621136, 77.378724","28.621136, 77.378704","28.621136, 77.378670","28.621137, 77.378642"
            ,"28.621137, 77.378642","28.621144, 77.378617","28.621143, 77.378594","28.621145, 77.378572","28.621145, 77.378555","28.621147, 77.378536"
            ,"28.621150, 77.378515","28.621151, 77.378491","28.621151, 77.378450","28.621154, 77.378422","28.621160, 77.378397","28.621157, 77.378369"
            ,"28.621160, 77.378344","28.621162, 77.378316","28.621164, 77.378291","28.621165, 77.378260","28.621168, 77.378232","28.621170, 77.378202"
            ,"28.621174, 77.378161","28.621175, 77.378107","28.621177, 77.378083","28.621178, 77.378047","28.621182, 77.378019"
            ,"28.621184, 77.377976","28.621187, 77.377941","28.621188, 77.377907","28.621190, 77.377876","28.621194, 77.377836"
            ,"28.621231, 77.377209","28.621238, 77.377117","28.621249, 77.377038","28.621251, 77.376968","28.621256, 77.376897","28.621262, 77.376864"
            ,"28.621263, 77.376830","28.621271, 77.376778","28.621274, 77.376743","28.621278, 77.376698","28.621280, 77.376644","28.621280, 77.376607"
            ,"28.621285, 77.376566","28.621288, 77.376522","28.621291, 77.376485","28.621297, 77.376443","28.621297, 77.376401","28.621301, 77.376359"
            ,"28.621305, 77.376322","28.621310, 77.376291","28.621311, 77.376228","28.621316, 77.376181","28.621320, 77.376128"
            ,"28.621325, 77.376059","28.621332, 77.375948","28.621339, 77.375847","28.621344, 77.375756","28.621353, 77.375686","28.621363, 77.375584"
            ,"28.621371, 77.375466","28.621377, 77.375359","28.621384, 77.375265","28.621391, 77.375167","28.621400, 77.375047","28.621409, 77.374902"
            ,"28.621415, 77.374793","28.621423, 77.374693","28.621429, 77.374616","28.621435, 77.374489","28.621441, 77.374365","28.621446, 77.374294"
            ,"28.621433, 77.374229","28.621376, 77.374195","28.621303, 77.374165","28.621190, 77.374124","28.621059, 77.374108","28.620890, 77.374086"
            ,"28.620691, 77.374074","28.620496, 77.374051","28.620327, 77.374039","28.620150, 77.374019","28.619954, 77.373997","28.619812, 77.373978"
            ,"28.619625, 77.373962","28.619312, 77.373926","28.619118, 77.373907","28.618815, 77.373876","28.618582, 77.373856","28.618353, 77.373833"
            ,"28.618182, 77.373820","28.617936, 77.373803","28.617708, 77.373811","28.617492, 77.373837","28.617187, 77.373844","28.616908, 77.373817"
            ,"28.616715, 77.373805","28.616381, 77.373751","28.616172, 77.373702","28.615955, 77.373646","28.615780, 77.373598","28.615453, 77.373552"
            ,"28.615262, 77.373520","28.615001, 77.373497","28.614790, 77.373477","28.614505, 77.373452","28.614286, 77.373433","28.613748, 77.373366"
            ,"28.613265, 77.373323","28.612611, 77.373259","28.612000, 77.373199","28.611562, 77.373151","28.611056, 77.373107","28.610468, 77.373053"
            ,"28.610212, 77.373082","28.609644, 77.373018","28.609461, 77.373002","28.609294, 77.372956","28.609103, 77.372933","28.608896, 77.372935"
            ,"28.608717, 77.372924","28.608053, 77.372869","28.607925, 77.372837","28.607910, 77.372790","28.607936, 77.372723","28.608126, 77.372673"
            ,"28.608255, 77.372590","28.608253, 77.372518","28.608301, 77.372536"
        };
        string place, addressOrigin, addressShipTo = string.Empty;
        string bolNo, clientID, compositeKey = string.Empty;
        bool isAnimate = true;
        #endregion
        /// <summary>
        /// 
        /// </summary>
        public RealTimeTrackingActivity()
        {
            shipmentAddress = new List<string>();
            trackingStatus = CommanUtil.TrackingStatus();
            lstTrackingVal = CommanUtil.TrackingValue();
        }

        /// <summary>
        /// Pubnub logs
        /// </summary>
        public class LocalLog : IPubnubLog
        {
            void IPubnubLog.WriteToLog(string logText)
            {
                System.Diagnostics.Debug.WriteLine(logText);
            }
        }

        /// <summary>
        /// On load event of RealTime Tracking Activity
        /// </summary>
        /// <param name="savedInstanceState"></param>
        async protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);
                if (string.IsNullOrEmpty(CommanUtil.tokenNo))
                {
                    Utility.Logout(this);
                }
                RequestWindowFeature(WindowFeatures.NoTitle);
                SetContentView(Resource.Layout.LiveTrackingLayout);
                imViewSource = FindViewById<ImageView>(Resource.Id.imViewSource);
                imViewDestination = FindViewById<ImageView>(Resource.Id.imViewDest);
                mainScrollView = FindViewById<ScrollView>(Resource.Id.mainScrollView);
                txtViewCopyRight = FindViewById<TextView>(Resource.Id.txtViewCopyRight);
                txtViewCopyRight.Text = CommanUtil.PrintYear();//Printc Current Year in Page Footer 
                imgBtnShipDetails = FindViewById<ImageButton>(Resource.Id.imgBtnShipDetails);
                txtAddressFrom = FindViewById<TextView>(Resource.Id.txtAddressFrom);
                txtAddressTo = FindViewById<TextView>(Resource.Id.txtAddressTo);
                txtShipmentStatus = FindViewById<TextView>(Resource.Id.txtShipmentStatus);
                txtCurrentLocation = FindViewById<TextView>(Resource.Id.txtCurrentLocation);
                txtDistanceTravelled = FindViewById<TextView>(Resource.Id.txtDistanceTravelled);
                txtTimeTaken = FindViewById<TextView>(Resource.Id.txtTimeTaken);
                txtDistanceLeft = FindViewById<TextView>(Resource.Id.txtDistanceLeft);
                imgBack = FindViewById<ImageButton>(Resource.Id.imgBack);
                lstShipmentActivity = new List<Models.ShipmentActivity>();
                place = Intent.GetStringExtra("location");
                addresses = place.Split('#');
                addressOrigin = addresses[0];//address1;//
                addressShipTo = addresses[1];//address2;//
                bolNo = addresses[2];
                clientID = addresses[4];
                txtAddressFrom.Text = addresses[0];
                txtAddressTo.Text = addresses[1];
                compositeKey = CommanUtil.CompositeKey(addresses[4], Convert.ToInt32(addresses[3]), addresses[2]);
                objUtility = new Utility();
                Alerts.showBusyLoader(this);
                // await Task.Delay(100);
                string response = await objUtility.BindShipmentDetail(APIMethods.shipmentDetails + "/" + addresses[4] + "|" + addresses[2], this);
                if (!string.IsNullOrEmpty(response))
                {
                    carrierShipmentDetails = JsonConvert.DeserializeObject<CarrierShipmentDetails>(response);
                    foreach (var address in carrierShipmentDetails.Addresses)
                    {
                        shipmentAddress.Add(string.Format($"{address.Address1} {address.Address2} {address.City} {address.State} {address.Zip}"));
                    }
                }
                imgBack.Click += delegate
            {
                Finish();
            };
                imgBtnShipDetails.Click += delegate
                {
                    if (lstShipmentActivity != null && lstShipmentActivity.Count > 0)
                    {
                        compositeKey += "|" + txtShipmentStatus.Text;
                    }
                    else
                    {
                        compositeKey += "|" + txtShipmentStatus.Text;
                    }
                    Intent intentDispatchDetails = Utility.RedirectTo(this, typeof(DispatchShipDetailsActivity), "compositeKey", compositeKey);
                    StartActivity(intentDispatchDetails);
                };
                SetUpGoogleMap();
                // await GetShipmentDetails();
                #region Checking callback Response 
                //Set Account setting of pubnub
                PubNubAccountSetting();
                listener = new SubscribeCallbackExt(
                    (o, m) =>
                    {
                        //Publisher Response
                        if (m != null)
                        {
                            //Display(pubnub.JsonPluggableLibrary.SerializeToJsonString(m.Message));
                            var demo = pubnub.JsonPluggableLibrary.SerializeToJsonString(m.Message);
                            ShipmentStatus objShipmentStatus = JsonConvert.DeserializeObject<ShipmentStatus>(demo);
                            GetDirectionResponseAsync(objShipmentStatus);
                        }
                    },
                    (o, p) =>
                    {
                        //Subscriber join or not 
                        if (p != null)
                        {
                            //Display(p.Event);
                        }
                    },
                    (o, s) =>
                    {
                        //status code of subscriber
                        if (s != null)
                        {
                            //Display(s.Category + " " + s.Operation + " " + s.StatusCode);
                        }
                    }
                    );
                #endregion
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                //Toast.MakeText(this, "error test", ToastLength.Long).Show();
            }
            finally
            {
                Alerts.HideBusyLoader();
            }
        }

        /// <summary>
        /// Get status of current Shipment
        /// </summary>
        /// <returns></returns>
        async Task GetShipmentStatusAsync()
        {
            try
            {
                if (carrierShipmentDetails == null)
                {
                    string response = await objUtility.BindShipmentDetail(APIMethods.shipmentDetails + "/" + addresses[4] + "|" + addresses[2], this);
                    if (!string.IsNullOrEmpty(response))
                    {
                        carrierShipmentDetails = JsonConvert.DeserializeObject<Models.CarrierShipmentDetails>(response);
                    }
                }
                if (carrierShipmentDetails.TrackDetails != null && carrierShipmentDetails.TrackDetails.Count > 0)
                {
                    shipStatus = trackingStatus.Where(x => x.Value == carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 1].ActivityDescr).Select(x => x.Key).FirstOrDefault();
                    if (shipStatus == null && carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 1].ActivityDescr == "Pickup")
                    {
                        shipStatus = Constants.inTransitkey;
                    }

                    if (shipStatus == Constants.completedkey
                        || shipStatus == Constants.exceptionkey1
                         || shipStatus == Constants.exceptionkey2
                          || shipStatus == Constants.exceptionkey3
                           || shipStatus == Constants.exceptionkey4
                            || shipStatus == Constants.exceptionkey5)
                    {
                        if (shipStatus == Constants.completedkey)
                        {
                            txtCurrentLocation.Text = addressShipTo;
                        }
                        txtShipmentStatus.Text = trackingStatus[shipStatus];
                        txtDistanceLeft.Text = Constants.zeroMiles;

                        decimal distBtwDestCurrent = GPSService.GetDistance(latLngSource, latLngDestination);
                        txtDistanceTravelled.Text = distBtwDestCurrent.ToString() + Constants.mile;

                        string[] shipStartTime = carrierShipmentDetails.TrackDetails[0].Activity.Split('T');
                        string startTime = shipStartTime[0].Replace('-', '/') + " " + shipStartTime[1];
                        string[] shipEndTIme = carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 1].Activity.Split('T');
                        string endTime = shipEndTIme[0].Replace('-', '/') + " " + shipEndTIme[1];
                        DateTime startDateTime = DateTime.ParseExact(startTime, "yyyy/MM/dd HH:mm:ss", CultureInfo.InvariantCulture);
                        DateTime endDateTime = DateTime.ParseExact(endTime, "yyyy/MM/dd HH:mm:ss", CultureInfo.InvariantCulture);
                        TimeSpan totalTimeTaken = endDateTime.Subtract(startDateTime);
                        txtTimeTaken.Text = totalTimeTaken.ToString();
                    }
                    else
                    {
                        txtShipmentStatus.Text = trackingStatus[shipStatus];
                    }
                    //currentLatLong = null;
                }
                else
                {
                    decimal distBtwDestCurrent = GPSService.GetDistance(latLngSource, latLngDestination);
                    txtCurrentLocation.Text = addressOrigin;
                    txtDistanceLeft.Text = distBtwDestCurrent.ToString() + Constants.mile;
                    txtDistanceTravelled.Text = Constants.zeroMiles;
                    txtShipmentStatus.Text = Constants.shippingNotStart;
                }
                // objGPSService = null;
                //objUtility = null;
                //}
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        /// <summary>
        /// Get the shipment detail
        /// </summary>
        public async Task GetShipmentDetails()
        {
            string shipStatus = string.Empty;

            try
            {
                if (carrierShipmentDetails == null)
                {
                    string response = await objUtility.BindShipmentDetail(APIMethods.shipmentDetails + "/" + addresses[4] + "|" + addresses[2], this);
                    if (!string.IsNullOrEmpty(response))
                    {
                        carrierShipmentDetails = JsonConvert.DeserializeObject<Models.CarrierShipmentDetails>(response);
                    }
                }
                if (carrierShipmentDetails.TrackDetails != null && carrierShipmentDetails.TrackDetails.Count > 0)
                {
                    if (txtShipmentStatus.Text == Constants.shippingNotStart)
                    {
                        txtShipmentStatus.Text = carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 1].ActivityDescr.ToString();
                    }
                    shipmentStatus = carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 1].ActivityDescr.ToString();
                    shipStatus = carrierShipmentDetails.TrackDetails[0].ActivityDescr.ToString();
                    Constants.shipStartTime = carrierShipmentDetails.TrackDetails.Where(m => m.ActivityDescr == "In Transit" || m.ActivityDescr == "Enroute to Pickup Location").Select(m => m.Activity).LastOrDefault();

                    if (shipmentStatus == Constants.strCompletedDeliveryText || shipmentStatus == Constants.completedkey || shipmentStatus == Constants.strTruckBrokeDown || shipmentStatus == Constants.strTrafficDelay || shipmentStatus == Constants.strWeatherDelay || shipmentStatus == Constants.strDockClosed || shipmentStatus == Constants.strOtherText || shipmentStatus == "Exception" || shipmentStatus == "Completed Unloading at Delivery Location")
                    {
                        shipCompletedTime = carrierShipmentDetails.TrackDetails.Where(m => m.ActivityDescr.Equals(shipmentStatus)).Select(m => m.Activity).LastOrDefault();
                    }
                }
                else
                {
                    Constants.shipStartTime = string.Empty;
                }
                if (!string.IsNullOrEmpty(Constants.shipStartTime))
                {
                    if (shipmentStatus == Constants.strCompletedDeliveryText || shipmentStatus == Constants.completedkey || shipmentStatus == Constants.strTruckBrokeDown || shipmentStatus == Constants.strTrafficDelay || shipmentStatus == Constants.strWeatherDelay || shipmentStatus == Constants.strDockClosed || shipmentStatus == Constants.strOtherText || shipmentStatus == "Exception" || shipmentStatus == "Completed Unloading at Delivery Location")
                    {
                        Constants.isEnroute = false;
                    }
                    else
                    {
                        Constants.isEnroute = true;
                    }
                }
                StartTimer();
                //}
            }
            catch (Exception ex)
            {
                //throw;
            }
        }

        /// <summary>
        /// Function to start timer functionality
        /// </summary>
        public async void StartTimer()
        {
            string time = "00:00:00";
            string timeDiff = string.Empty;
            string newTime = string.Empty;
            DateTime completedTime = new DateTime();
            DateTime currentTime = new DateTime();
            TimeSpan timeSpan = new TimeSpan();
            try
            {
                var shipmentEnroute = lstShipmentActivity.Where(activity => activity.Status.ToUpper() == Constants.enRoutekey.ToUpper()).FirstOrDefault();

                string shipmentEnrouteTime = string.Empty;

                if (!string.IsNullOrEmpty(Constants.shipStartTime))
                {
                    IFormatProvider culture = new CultureInfo("en-US", true);
                    DateTime shipStartTime = new DateTime();
                    shipStartTime = Convert.ToDateTime(Constants.shipStartTime, culture);

                    if (shipmentStatus == Constants.strCompletedDeliveryText
                        || shipmentStatus == Constants.completedkey
                        || shipmentStatus == Constants.strTruckBrokeDown
                        || shipmentStatus == Constants.strTrafficDelay
                        || shipmentStatus == Constants.strWeatherDelay
                        || shipmentStatus == Constants.strDockClosed
                        || shipmentStatus == Constants.strOtherText
                         || shipmentStatus == "Exception"
                         || shipmentStatus == "Completed Unloading at Delivery Location")
                    {
                        //var shipCompletedTime = lstShipmentActivity[lstShipmentActivity.Count - 1].Time;
                        completedTime = Convert.ToDateTime(shipCompletedTime, culture);

                        timeSpan = completedTime.Subtract(shipStartTime);
                    }
                    else
                    {
                        currentTime = DateTime.Now;
                        timeSpan = currentTime.Subtract(shipStartTime);
                    }

                    timeDiff = String.Format("{0}:{1}:{2}", timeSpan.Hours, timeSpan.Minutes, timeSpan.Seconds);
                    if (shipmentStatus == Constants.strCompletedDeliveryText
                         || shipmentStatus == Constants.completedkey
                         || shipmentStatus == Constants.strTruckBrokeDown
                         || shipmentStatus == Constants.strTrafficDelay
                         || shipmentStatus == Constants.strWeatherDelay
                         || shipmentStatus == Constants.strDockClosed
                         || shipmentStatus == Constants.strOtherText
                          || shipmentStatus == "Exception" || shipmentStatus == "Completed Unloading at Delivery Location")
                    {
                        Constants.isEnroute = false;
                        var newHrs = string.Empty;
                        var newMinutes = string.Empty;
                        var newSeconds = string.Empty;
                        if (timeSpan.Seconds >= 0 && timeSpan.Seconds <= 9)
                        {
                            newSeconds = "0" + Convert.ToString(timeSpan.Seconds);
                        }
                        else
                        {
                            newSeconds = timeSpan.Seconds.ToString();
                        }
                        if (timeSpan.Minutes >= 0 && timeSpan.Minutes <= 9)
                        {
                            newMinutes = "0" + Convert.ToString(timeSpan.Minutes);
                        }
                        else
                        {
                            newMinutes = timeSpan.Minutes.ToString();
                        }
                        if (timeSpan.Hours >= 0 && timeSpan.Hours <= 9)
                        {
                            newHrs = "0" + Convert.ToString(timeSpan.Hours);
                        }
                        else
                        {
                            newHrs = timeSpan.Hours.ToString();
                        }
                        txtTimeTaken.Text = string.Format("{0}:{1}:{2}", newHrs, newMinutes, newSeconds);
                    }
                    else if (shipmentStatus == Constants.enrouteToPickup)
                    {
                        Constants.isEnroute = true;
                    }

                }
                else
                {
                    txtTimeTaken.Text = time;
                }
                while (Constants.isEnroute)
                {
                    RunOnUiThread(() =>
                    {
                        if (string.IsNullOrEmpty(Constants.shipStartTime))
                        {
                            newTime = RunTimer(time);
                        }
                        else
                        {
                            newTime = RunTimer(newTime);
                        }
                        if (!string.IsNullOrEmpty(timeDiff))
                        {
                            newTime = RunTimer(timeDiff);
                            timeDiff = string.Empty;
                        }
                        txtTimeTaken.Text = newTime;
                    });
                    await Task.Delay(1000);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// RunTimer of driver while driving vehicle
        /// </summary>
        /// <returns></returns>
        public string RunTimer(string previousTime)
        {
            try
            {
                if (!string.IsNullOrEmpty(previousTime))
                {
                    string[] strTimer = previousTime.Split(':');
                    seconds = Convert.ToInt32(strTimer[2]);
                    minutes = Convert.ToInt32(strTimer[1]);
                    hours = Convert.ToInt32(strTimer[0]);
                }
                string result = string.Empty;
                string secs = string.Empty;
                string mins = string.Empty;
                string hrs = string.Empty;
                if (seconds <= 59)
                {
                    seconds++;
                }
                if (seconds == 60)
                {
                    seconds = 00;
                    if (minutes <= 59)
                    {
                        minutes++;
                    }
                    if (minutes == 60)
                    {
                        minutes = 00;
                        hours++;
                    }
                }
                if (seconds >= 0 && seconds <= 9)
                {
                    secs = "0" + Convert.ToString(seconds);
                }
                else
                {
                    if (Convert.ToString(seconds) == "60")
                    {
                        secs = "00";
                    }
                    else
                    {
                        secs = Convert.ToString(seconds);
                    }
                }

                if (minutes >= 0 && minutes <= 9)
                {
                    mins = "0" + Convert.ToString(minutes);
                }
                else
                {
                    if (Convert.ToString(minutes) == "60")
                    {
                        mins = "00";
                        minutes = 00;
                    }
                    else
                    {
                        mins = Convert.ToString(minutes);
                    }

                }
                if (hours >= 0 && hours <= 9)
                {
                    hrs = "0" + Convert.ToString(hours);
                }
                else
                {
                    if (Convert.ToString(hours) == "60")
                    {
                        hrs = "00";
                    }
                    else
                    {
                        hrs = Convert.ToString(hours);
                    }
                }
                return result = hrs + " : " + mins + " : " + secs;
            }
            catch
            {
                return "00";
            }

        }


        /// <summary>
        /// Set Account setting of pubnub
        /// </summary>
        void PubNubAccountSetting()
        {
            try
            {
                config = new PNConfiguration();
                config.SubscribeKey = Constants.pubnubSubscribeKey;
                config.PublishKey = Constants.pubnubPublishKey;
                //config.Secure = true;
                config.PubnubLog = new LocalLog();
                config.LogVerbosity = PNLogVerbosity.BODY;
                config.ReconnectionPolicy = PNReconnectionPolicy.LINEAR;
                pubnub = new Pubnub(config);
                Subscribe(clientID + bolNo.Trim());//clientID
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// SetUP Google Map
        /// </summary>
        private void SetUpGoogleMap()
        {
            try
            {

                if (!Utility.FnIsOnline(this))
                {
                    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                //Find Controls
                mapFrag = (MapFragment)FragmentManager.FindFragmentById(Resource.Id.map);
                //Displaying Map after getting the details
                var mapReadyCallback = new OnMapReadyClass();
                mapReadyCallback.MapReadyAction += async delegate (GoogleMap objMap)
                 {
                     map = objMap;
                     // map.TrafficEnabled = true;
                     await FnplotMap(map); //Plot Map
                 };
                mapFrag.GetMapAsync(mapReadyCallback);
            }
            catch
            {
                throw;
            }
            finally
            {
                Alerts.HideBusyLoader();
            }
        }

        /// <summary>
        /// On Map ready
        /// </summary>
        /// <param name="googleMap"></param>
        //public async void FnplotMap(GoogleMap googleMap)
        //{
        //    try
        //    {
        //        await GetShipmentDetails();
        //        Alerts.showBusyLoader(this);
        //        this.map = googleMap;
        //        //Get Lat Long 
        //        bool result = await FnLocationToLatLng(addressOrigin, addressShipTo);
        //        if (result)
        //        {
        //            //Set Camera Position
        //            FnUpdateCameraPosition(latLngSource);
        //            if (latLngSource != null && latLngDestination != null)
        //            {
        //                if (carrierShipmentDetails.IsMultiStop)
        //                {
        //                    await multiStopTracking();
        //                }
        //                else
        //                {
        //                    await GetShipmentStatusAsync(); //Get Shipment Status
        //                }
        //            }
        //            FnDrawPath(addressOrigin, addressShipTo);
        //            Alerts.HideBusyLoader();
        //        }
        //        else
        //        {
        //            Toast.MakeText(this, Constants.strLocation, ToastLength.Long).Show();
        //            //Finish();
        //            Alerts.HideBusyLoader();
        //        }
        //    }
        //    catch
        //    {
        //        //Finish();
        //        Alerts.HideBusyLoader();

        //    }
        //}
        /// <summary>
        /// Disable scrollview scrolling on Map touch event
        /// </summary>
        /// <param name="e"></param>
        /// <returns></returns>
        public override bool DispatchTouchEvent(MotionEvent e)
        {
            var action = e.Action;
            switch (action)
            {
                case MotionEventActions.Down:
                    // Disallow ScrollView to intercept touch events.
                    mainScrollView.RequestDisallowInterceptTouchEvent(true);
                    // Disable touch on transparent view
                    break;
                case MotionEventActions.Up:
                    // Allow ScrollView to intercept touch events.
                    mainScrollView.RequestDisallowInterceptTouchEvent(false);
                    break;

                case MotionEventActions.Move:
                    mainScrollView.RequestDisallowInterceptTouchEvent(true);
                    break;
            }
            return base.DispatchTouchEvent(e);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="googleMap"></param>
        /// <returns></returns>
        public async Task FnplotMap(GoogleMap googleMap)
        {
            try
            {
                Alerts.showBusyLoader(this);
                this.map = googleMap;
                Constants.showSourceMarker = true;
                //Get Lat Long 
                var i = 0;
                bool result = false;
                for (i = 0; i <= shipmentAddress.Count - 2; i++)
                {
                    result = await FnLocationToLatLng(shipmentAddress[i], shipmentAddress[i + 1]);
                    if (result)
                    {
                        //Set Camera Position

                        if (latLngSource != null && latLngDestination != null)
                        {
                            if (i == shipmentAddress.Count - 2)
                            {
                                Constants.showDestinationMarker = true;
                            }
                            await FnDrawPathAsync(shipmentAddress[i], shipmentAddress[i + 1]);
                        }
                        //Alerts.HideBusyLoader();
                    }
                    else
                    {
                        Alerts.HideBusyLoader();
                        Toast.MakeText(this, Constants.strLocation, ToastLength.Long).Show();
                    }
                    //}

                }
                if (latLngSource != null)
                {
                    FnUpdateCameraPosition(latLngSource);
                }
                if (carrierShipmentDetails != null)
                {

                    if (carrierShipmentDetails.IsMultiStop)
                    {

                        await multiStopTracking();
                    }
                    else
                    {
                        await GetShipmentStatusAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                Alerts.HideBusyLoader();
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
            }
            finally
            {
                Alerts.HideBusyLoader();
            }
        }


        /// <summary>
        /// FnDrawPathAsync of origin and source
        /// </summary>
        /// <param name="strSource"></param>
        /// <param name="strDestination"></param>
        /// <returns></returns>
        async Task FnDrawPathAsync(string strSource, string strDestination)
        {
            try
            {
                string strFullDirectionURL = string.Format(Constants.strGoogleDirectionUrl, strSource, strDestination);
                string strJSONDirectionResponse = await FnHttpRequest(strFullDirectionURL);
                if (strJSONDirectionResponse != Constants.strException)
                {
                    RunOnUiThread(() =>
                    {
                        if (map != null)
                        {
                            if (Constants.showSourceMarker)
                            {
                                MarkOnMap(/*Constants.strTextSource*/"Origin", strSource, latLngSource, Resource.Drawable.MarkerSource);
                                if (shipmentAddress.Count > 2)
                                {
                                    Constants.showSourceMarker = false;
                                }
                            }
                            if (Constants.showDestinationMarker)
                            {
                                MarkOnMap(Constants.strTextDestination, strDestination, latLngDestination, Resource.Drawable.MarkerDest);
                                Constants.showDestinationMarker = false;
                            }
                            else
                            {
                                Constants.stopIncrement += 1;
                                MarkOnMap("Stop" + Constants.stopIncrement, strDestination, latLngDestination, Resource.Drawable.imgstop);
                            }
                        }
                    });
                    FnSetDirectionQuery(strJSONDirectionResponse, false);
                }
                else
                {

                    Toast.MakeText(this, Constants.strUnableToConnect, ToastLength.Short).Show();
                }
            }
            catch
            {
                throw;
            }
        }
        decimal totalDistance = 0;
        /// <summary>
        /// FnSetDirectionQuery
        /// </summary>
        /// <param name="strJSONDirectionResponse"></param>
        /// <param name="isCalculate"></param>
        private void FnSetDirectionQuery(string strJSONDirectionResponse, bool isCalculate = true)
        {
            try
            {
                var objRoutes = JsonConvert.DeserializeObject<GoogleDirectionClass>(strJSONDirectionResponse);
                //objRoutes.routes.Count  --may be more then one 
                if (objRoutes.routes.Count > 0)
                {
                    if (isCalculate)
                    {
                        totalDistance = GPSService.CalculateDistance(objRoutes); //Get Distance
                    }
                    else
                    {
                        string encodedPoints = objRoutes.routes[0].overview_polyline.points;
                        var lstDecodedPoints = FnDecodePolylinePoints(encodedPoints);
                        //convert list of location point to array of latlng type
                        var latLngPoints = new LatLng[lstDecodedPoints.Count];
                        int index = 0;
                        foreach (GoogleServices.Location loc in lstDecodedPoints)
                        {
                            latLngPoints[index++] = new LatLng(loc.lat, loc.lng);
                        }
                        var polylineoption = new PolylineOptions();
                        polylineoption.InvokeColor(Color.Red);
                        polylineoption.Geodesic(true);
                        polylineoption.InvokeWidth(6);
                        polylineoption.Add(latLngPoints);
                        RunOnUiThread(() =>
                        {
                            map.AddPolyline(polylineoption);
                        });
                    }
                }
            }
            catch
            {
                throw;
            }
        }


        /// <summary>
        /// Create Lat Long for polyline
        /// </summary>
        /// <param name="encodedPoints"></param>
        /// <returns></returns>
        List<GoogleServices.Location> FnDecodePolylinePoints(string encodedPoints)
        {
            if (string.IsNullOrEmpty(encodedPoints))
                return null;
            var poly = new List<GoogleServices.Location>();
            char[] polylinechars = encodedPoints.ToCharArray();
            int index = 0;

            int currentLat = 0;
            int currentLng = 0;
            int next5bits;
            int sum;
            int shifter;

            try
            {
                while (index < polylinechars.Length)
                {
                    // calculate next latitude
                    sum = 0;
                    shifter = 0;
                    do
                    {
                        next5bits = (int)polylinechars[index++] - 63;
                        sum |= (next5bits & 31) << shifter;
                        shifter += 5;
                    } while (next5bits >= 32 && index < polylinechars.Length);

                    if (index >= polylinechars.Length)
                        break;

                    currentLat += (sum & 1) == 1 ? ~(sum >> 1) : (sum >> 1);

                    //calculate next longitude
                    sum = 0;
                    shifter = 0;
                    do
                    {
                        next5bits = (int)polylinechars[index++] - 63;
                        sum |= (next5bits & 31) << shifter;
                        shifter += 5;
                    } while (next5bits >= 32 && index < polylinechars.Length);

                    if (index >= polylinechars.Length && next5bits >= 32)
                        break;

                    currentLng += (sum & 1) == 1 ? ~(sum >> 1) : (sum >> 1);
                    GoogleServices.Location p = new GoogleServices.Location();
                    p.lat = Convert.ToDouble(currentLat) / 100000.0;
                    p.lng = Convert.ToDouble(currentLng) / 100000.0;
                    poly.Add(p);
                }
            }
            catch
            {
                RunOnUiThread(() =>
                  Toast.MakeText(this, Constants.strPleaseWait, ToastLength.Short).Show());
            }
            return poly;
        }

        /// <summary>
        /// Set marker on map
        /// </summary>
        /// <param name="title"></param>
        /// <param name="address"></param>
        /// <param name="pos"></param>
        /// <param name="resourceId"></param>
        private void MarkOnMap(string title, string address, LatLng pos, int resourceId)
        {
            RunOnUiThread(() =>
            {
                try
                {
                    var marker = new MarkerOptions();
                    marker.SetTitle(title);
                    marker.SetPosition(pos); //Resource.Drawable.BlueDot
                    marker.SetSnippet(address);
                    marker.SetIcon(BitmapDescriptorFactory.FromResource(resourceId));
                    map.AddMarker(marker);
                }
                catch (Exception ex)
                {
                    Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                    Toast.MakeText(this, "error test1", ToastLength.Long).Show();
                }
            });
        }

        /// <summary>
        /// 
        /// </summary>
        WebClient webclient;
        async Task<string> FnHttpRequest(string strUri)
        {
            webclient = new WebClient();
            string strResultData;
            try
            {
                strResultData = await webclient.DownloadStringTaskAsync(new Uri(strUri));
                Console.WriteLine(strResultData);
            }
            catch
            {
                strResultData = Constants.strException;
            }
            finally
            {
                if (webclient != null)
                {
                    webclient.Dispose();
                    webclient = null;
                }
            }
            return strResultData;
        }

        /// <summary>
        /// Update camera position
        /// </summary>
        /// <param name="pos"></param>
        async private void FnUpdateCameraPosition(LatLng pos)
        {
            try
            {
                var geo = new Geocoder(this);
                #region Enable UI Settings for map for map
                map.UiSettings.MyLocationButtonEnabled = true;
                map.MyLocationEnabled = true;
                map.UiSettings.RotateGesturesEnabled = true;
                map.UiSettings.ZoomGesturesEnabled = true;
                #endregion

                double PickUpCenterlat = (Convert.ToDouble(latLngSource.Latitude) + Convert.ToDouble(latLngDestination.Latitude)) / 2;
                double PickUpCenterlong = (Convert.ToDouble(latLngSource.Longitude) + Convert.ToDouble(latLngDestination.Longitude)) / 2;

                LatLng Centerlatlong = new LatLng(PickUpCenterlat, PickUpCenterlong);

                LatLng latlngPU;
                LatLng latlngDO;
                LatLngBounds.Builder builder1 = new LatLngBounds.Builder();

                latlngPU = new LatLng(Convert.ToDouble(latLngSource.Latitude), Convert.ToDouble(latLngSource.Longitude));
                latlngDO = new LatLng(Convert.ToDouble(latLngDestination.Latitude), Convert.ToDouble(latLngDestination.Longitude));
                List<LatLng> markers = new List<LatLng>();
                foreach (var stops in carrierShipmentDetails.Addresses)
                {
                    List<string> stopAddress = new List<string>();
                    stopAddress.Add(string.Format($"{stops.Address1} {stops.Address2} {stops.City} {stops.State} {stops.Zip}"));

                    var currentstopAddress = await geo.GetFromLocationNameAsync(stopAddress[0], 1);

                    currentstopAddress.ToList().ForEach((addr) =>
                    {
                        latLngStop = new LatLng(addr.Latitude, addr.Longitude);
                    });

                    markers.Add(latLngStop);
                }
                markers.Add(latlngPU);
                markers.Add(latlngDO);

                foreach (LatLng item in markers)
                {
                    builder1.Include(item);
                }

                var metrics = Resources.DisplayMetrics;

                int height = metrics.HeightPixels;
                int width = metrics.WidthPixels;
                int padding = (int)(width * 0.20); // offset from edges of the map 10% of screen

                LatLngBounds bounds = builder1.Build();
                map.AnimateCamera(CameraUpdateFactory.NewLatLngBounds(bounds, padding));
                //Camera change listener to manage the map zoom level
                map.CameraChange += delegate (object sender, GoogleMap.CameraChangeEventArgs e)
                {
                    if ((int)e.Position.Zoom != (int)currentZoomLevel)
                    {
                        currentZoomLevel = e.Position.Zoom;
                        isAnimate = false;
                    }
                };
                map.MyLocationButtonClick += Map_MyLocationButtonClick;
            }
            catch
            {

            }
        }
        /// <summary>
        /// Click event of My Location button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Map_MyLocationButtonClick(object sender, GoogleMap.MyLocationButtonClickEventArgs e)
        {
            isAnimate = true;
        }

        /// <summary>
        /// Get lat long of souce and destination
        /// </summary>
        /// <param name="strSource"></param>
        /// <param name="strDestination"></param>
        /// <returns></returns>
        async Task<bool> FnLocationToLatLng(string strSource, string strDestination)
        {
            try
            {
                var geo = new Geocoder(this);
                var sourceAddress = await geo.GetFromLocationNameAsync(strSource, 1);
                if (sourceAddress != null)
                {
                    sourceAddress.ToList().ForEach((addr) =>
                    {
                        latLngSource = new LatLng(addr.Latitude, addr.Longitude);
                    });
                    var destAddress = await geo.GetFromLocationNameAsync(strDestination, 1);
                    if (destAddress != null)
                    {
                        destAddress.ToList().ForEach((addr) =>
                    {
                        latLngDestination = new LatLng(addr.Latitude, addr.Longitude);
                    });
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }

            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// Draw the path of vehicle
        /// </summary>
        /// <param name="objShipmentStatus"></param>
        public void GetDirectionResponseAsync(ShipmentStatus objShipmentStatus)
        {
            try
            {
                LatLng currentLatLang = new LatLng(Convert.ToDouble(objShipmentStatus.CurrentLat), Convert.ToDouble(objShipmentStatus.CurrentLong));
                // string currentLoc = string.Empty;
                if (map != null)
                {
                    RunOnUiThread(() =>
                    {
                        try
                        {
                            txtShipmentStatus.Text = objShipmentStatus.ShipmentCurrStatus;
                            txtCurrentLocation.Text = objShipmentStatus.CurrentLocation;
                            txtDistanceLeft.Text = objShipmentStatus.DistanceLeft + Constants.mile;
                            txtDistanceTravelled.Text = objShipmentStatus.DistanceTravelled + Constants.mile;
                            //txtTimeTaken.Text = objShipmentStatus.TimeTaken;
                            if (lastSecodLatLong == null)
                            {
                                lastSecodLatLong = currentLatLang;
                                //  lastSecodLatLong = currentLatLang;
                            }
                            float bearing = GPSService.BearingBetweenLocations(lastSecodLatLong, currentLatLang);
                            if (float.IsNaN(bearing))
                            {
                                bearing = 180;
                            }
                            if (objMarker != null)
                            {
                                AnimateMarker(objMarker, currentLatLang, bearing);
                            }
                            else
                            {
                                MarkerOptions options = new MarkerOptions()
                                                .SetPosition(currentLatLang)
                                                .SetTitle(objShipmentStatus.CurrentLocation)
                                                .Flat(true)
                                                .Anchor(0.5f, 0.5f)
                                                .SetIcon(BitmapDescriptorFactory.FromResource(Resource.Drawable.CarTopView2));
                                objMarker = map.AddMarker(options);
                            }

                            CameraPosition.Builder builder = CameraPosition.InvokeBuilder();
                            builder.Target(currentLatLang); // Sets the center of the map to Mountain View
                            builder.Zoom(currentZoomLevel);// Sets the zoom
                                                           //builder.Bearing(bearing);// Sets the orientation of the camera to east
                                                           //builder.Tilt(30);// Sets the tilt of the camera to 30 degrees
                            cameraPosition = builder.Build();
                            //map.AnimateCamera(CameraUpdateFactory.NewCameraPosition(cameraPosition));
                            cameraUpdate = CameraUpdateFactory.NewCameraPosition(cameraPosition);
                            if (isAnimate == true)
                            {
                                map.AnimateCamera(cameraUpdate);
                            }
                            //Assign Old Latitude and Longitude
                            lastSecodLatLong = currentLatLang;
                        }
                        catch
                        {
                            throw;
                        }
                    });
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Animate marker
        /// </summary>
        /// <param name="marker"></param>
        /// <param name="toPosition"></param>
        /// <param name="rotation"></param>
        public void AnimateMarker(Marker marker, LatLng toPosition, float rotation)
        {
            Handler handler = new Handler();
            long start = SystemClock.UptimeMillis();
            Projection proj = map.Projection;
            Point startPoint = proj.ToScreenLocation(marker.Position);
            LatLng startLatLng = proj.FromScreenLocation(startPoint);
            long duration = 600;
            LinearInterpolator interpolator = new LinearInterpolator();

            handler.Post(Run);
            void Run()
            {

                long elapsed = SystemClock.UptimeMillis() - start;
                float t = interpolator.GetInterpolation((float)elapsed
                         / duration);
                double lng = t * toPosition.Longitude + (1 - t)
                        * startLatLng.Longitude;
                double lat = t * toPosition.Latitude + (1 - t)
                        * startLatLng.Latitude;
                RunOnUiThread(() =>
                {
                    try
                    {
                        marker.Position = new LatLng(lat, lng);
                        marker.Rotation = rotation;
                        marker.SetAnchor(0.5f, 0.5f);
                        marker.SetIcon(BitmapDescriptorFactory.FromResource(Resource.Drawable.CarTopView2));
                    }
                    catch
                    {
                        MarkerOptions options = new MarkerOptions()
                                .SetPosition(new LatLng(lat, lng))
                                .SetRotation(rotation)
                                .Flat(true)
                                .Anchor(0.5f, 0.5f)
                                .SetIcon(BitmapDescriptorFactory.FromResource(Resource.Drawable.CarTopView2));
                        objMarker = map.AddMarker(options);
                    }
                });
                if (t < 1.0)
                {
                    // Post again 16ms later.
                    handler.PostDelayed(Run, 16);
                    // Task.Delay(1);
                }
                else
                {
                    if (polylineoption == null)
                    {
                        polylineoption = new PolylineOptions();
                        polylineoption.InvokeColor(Color.Black);
                        polylineoption.Geodesic(true);
                        polylineoption.InvokeWidth(4);

                    }
                    polylineoption.Add(lastSecodLatLong, new LatLng(lat, lng));
                    map.AddPolyline(polylineoption);
                }

            }
        }


        /// <summary>
        /// Subscribe client to PubNub
        /// </summary>
        /// <param name="subscriber"></param>
        public void Subscribe(string subscriber)
        {
            try
            {
                ThreadPool.QueueUserWorkItem(o =>
                {
                    pubnub.AddListener(listener);
                    pubnub.Subscribe<object>()
                            .Channels(new[] { subscriber })
                          .WithPresence().Execute();
                }
                );
            }
            catch
            { }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ShipmentActivity, statusCode, status_Code, currentStop = "";
        List<TrackingDesc> lstTrackingVal;
        List<TrackingDesc> lstTrackingExceptionVal;
        /// <summary>
        ///
        /// </summary>
        /// <returns></returns>
        public async Task multiStopTracking()
        {
            try
            {
              //  Alerts.showBusyLoader(this);
                int stopCount = 1;

                if (carrierShipmentDetails.TrackDetails != null && carrierShipmentDetails.TrackDetails.Count > 0)
                {
                    if (txtShipmentStatus.Text == "Pickup")
                    {
                        statusCode = trackingStatus.Where(x => x.Value == carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 2].ActivityDescr).Select(x => x.Key).FirstOrDefault();
                        ShipmentActivity = statusCode;
                    }
                    else
                    {
                        foreach (var stop in carrierShipmentDetails.Addresses)
                        {
                            if (Convert.ToString(carrierShipmentDetails.Addresses[stopCount].CurrentStatus) != "Delivered")
                            {

                                string shipmentCurrentText = carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 1].ActivityDescr;
                                lstTrackingExceptionVal = CommanUtil.ExceptionDescList();
                                statusCode = lstTrackingExceptionVal.Where(x => x.text == shipmentCurrentText).Select(x => x.value).FirstOrDefault();
                                if (statusCode == Constants.exceptionkey1 || statusCode == Constants.exceptionkey2 || statusCode == Constants.exceptionkey3
                                    || statusCode == Constants.exceptionkey4 || statusCode == Constants.exceptionkey5)
                                {

                                    for (int trackDetailsCount = carrierShipmentDetails.TrackDetails.Count; trackDetailsCount > 0; trackDetailsCount--)
                                    {
                                        string trackInfo = carrierShipmentDetails.TrackDetails[trackDetailsCount - 1].ActivityDescr;
                                        if (!CommanUtil.ExceptionTextList.Contains(trackInfo))
                                        {
                                            status_Code = trackingStatus.Where(x => x.Value == carrierShipmentDetails.TrackDetails[trackDetailsCount - 1].ActivityDescr).Select(x => x.Key).FirstOrDefault();
                                            break;
                                        }
                                    }

                                    ShipmentActivity = status_Code;
                                    statusCode = status_Code;
                                    txtAddressTo.Text = string.Format($"{carrierShipmentDetails.Addresses[1].Address1} {carrierShipmentDetails.Addresses[1].Address2} {carrierShipmentDetails.Addresses[1].City} {carrierShipmentDetails.Addresses[1].State} {carrierShipmentDetails.Addresses[1].Zip}");
                                    txtAddressFrom.Text = string.Format($"{carrierShipmentDetails.Addresses[0].Address1} {carrierShipmentDetails.Addresses[0].Address2} {carrierShipmentDetails.Addresses[0].City} {carrierShipmentDetails.Addresses[0].State} {carrierShipmentDetails.Addresses[0].Zip}");
                                }

                                if (carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 1].ActivityDescr == Constants.strIntransit)
                                {
                                    statusCode = Constants.inTransitkey;
                                }
                                if (carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 1].ActivityDescr == Constants.enrouteToDeliveryLocation)
                                {
                                    statusCode = Constants.enRoutekey;
                                }
                                if (carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 1].ActivityDescr == Constants.strCarrierDeparted)
                                {
                                    statusCode = Constants.pickedupKey;
                                }
                                else
                                {
                                    if (statusCode == string.Empty || statusCode == null)
                                    {
                                        statusCode = trackingStatus.Where(x => x.Value == carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 1].ActivityDescr).Select(x => x.Key).FirstOrDefault();

                                    }
                                }

                                if (statusCode == Constants.arrivedkey)
                                {
                                    if (carrierShipmentDetails.Addresses[stopCount].Type == "BILLTO")
                                    {
                                        ShipmentActivity = Constants.completedkey;
                                    }
                                    else
                                    {

                                        ShipmentActivity = "enrouteToNextStop";
                                    }
                                }
                                else
                                {
                                    if (statusCode == null)
                                    {
                                        ShipmentActivity = string.Empty;
                                    }
                                    else
                                    {
                                        ShipmentActivity = statusCode;
                                    }
                                }
                                currentStop = carrierShipmentDetails.Addresses[stopCount].Type;
                                break;
                            }
                            else
                            {
                                stopCount += 1;
                            }
                            txtAddressTo.Text = string.Format($"{carrierShipmentDetails.Addresses[stopCount].Address1} {carrierShipmentDetails.Addresses[stopCount].Address2} {carrierShipmentDetails.Addresses[stopCount].City} {carrierShipmentDetails.Addresses[stopCount].State} {carrierShipmentDetails.Addresses[stopCount].Zip}");
                            txtAddressFrom.Text = string.Format($"{carrierShipmentDetails.Addresses[stopCount - 1].Address1} {carrierShipmentDetails.Addresses[stopCount - 1].Address2} {carrierShipmentDetails.Addresses[stopCount - 1].City} {carrierShipmentDetails.Addresses[stopCount - 1].State} {carrierShipmentDetails.Addresses[stopCount - 1].Zip}");
                        }
                    }
                }
                else
                {
                    txtAddressTo.Text = string.Format($"{carrierShipmentDetails.Addresses[1].Address1} {carrierShipmentDetails.Addresses[1].Address2} {carrierShipmentDetails.Addresses[1].City} {carrierShipmentDetails.Addresses[1].State} {carrierShipmentDetails.Addresses[1].Zip}");
                    txtAddressFrom.Text = string.Format($"{carrierShipmentDetails.Addresses[0].Company} {carrierShipmentDetails.Addresses[0].Address1} {carrierShipmentDetails.Addresses[0].Address2} {carrierShipmentDetails.Addresses[0].City} {carrierShipmentDetails.Addresses[0].State} {carrierShipmentDetails.Addresses[0].Zip}");
                    imViewSource.SetImageResource(Resource.Drawable.imgSource);
                    imViewDestination.SetBackgroundResource(0);
                    imViewDestination.SetImageResource(Resource.Drawable.imgstop);
                }
                Constants.stopCount = currentStop;
                switch (ShipmentActivity)
                {
                    case Constants.inTransitkey:

                        statusCode = Helper.Constants.inTransitkey;

                        txtShipmentStatus.Text = Constants.enrouteToPickup;

                        imViewSource.SetImageResource(Resource.Drawable.imgSource);
                        imViewDestination.SetBackgroundResource(0);
                        imViewDestination.SetImageResource(Resource.Drawable.imgstop);

                        break;
                    case Constants.arrivedAtPickupKey:

                        statusCode = Helper.Constants.arrivedAtPickupKey;

                        txtShipmentStatus.Text = Constants.arrivedATPickupLocation;


                        imViewSource.SetImageResource(Resource.Drawable.imgSource);
                        imViewDestination.SetBackgroundResource(0);
                        imViewDestination.SetImageResource(Resource.Drawable.imgstop);

                        break;

                    case Constants.pickedupKey:

                        statusCode = Helper.Constants.pickedupKey;

                        txtShipmentStatus.Text = Constants.completedPickup;

                        imViewSource.SetImageResource(Resource.Drawable.imgSource);
                        imViewDestination.SetBackgroundResource(0);
                        imViewDestination.SetImageResource(Resource.Drawable.imgstop);

                        break;

                    case Constants.enRoutekey:

                        statusCode = Helper.Constants.enRoutekey;
                        if (carrierShipmentDetails.Addresses[stopCount].Type == "SHIPTO")
                        {

                            txtShipmentStatus.Text = Constants.strEnrouteToDestination;

                            imViewSource.SetImageResource(Resource.Drawable.imgstop);
                            imViewDestination.SetBackgroundResource(0);
                            imViewDestination.SetImageResource(Resource.Drawable.imgDestination);

                        }
                        else
                        {

                            txtShipmentStatus.Text = "Enroute to " + carrierShipmentDetails.Addresses[stopCount].Type;//trackingStatus



                            if (stopCount - 1 >= 1)
                            {
                                imViewSource.SetImageResource(Resource.Drawable.imgstop);
                                imViewDestination.SetBackgroundResource(0);
                                imViewDestination.SetImageResource(Resource.Drawable.imgstop);
                            }
                            else
                            {
                                imViewSource.SetImageResource(Resource.Drawable.imgSource);
                                imViewDestination.SetBackgroundResource(0);
                                imViewDestination.SetImageResource(Resource.Drawable.imgstop);
                            }

                        }
                        if (stopCount - 1 >= 1)
                        {
                            Constants.stopCountForConfirmtion = "STOP" + (stopCount - 1);

                        }

                        break;
                    case "enrouteToNextStop":

                        statusCode = Helper.Constants.enRoutekey;
                        if (carrierShipmentDetails.Addresses[stopCount].Type == "SHIPTO")
                        {

                            imViewDestination.SetBackgroundResource(0);
                            imViewSource.SetImageResource(Resource.Drawable.imgstop);
                            imViewDestination.SetImageResource(Resource.Drawable.imgDestination);
                        }
                        else
                        {
                            imViewDestination.SetBackgroundResource(0);
                            imViewSource.SetImageResource(Resource.Drawable.imgstop);
                            imViewDestination.SetImageResource(Resource.Drawable.imgstop);

                        }

                        txtShipmentStatus.Text = "Completed Delivery of " + carrierShipmentDetails.Addresses[stopCount - 1].Type;//trackingStatus
                        if (stopCount - 1 >= 1)
                        {
                            Constants.stopCountForConfirmtion = "STOP" + (stopCount - 1);

                        }

                        break;
                    case Constants.arrivedkey:

                        statusCode = Helper.Constants.arrivedkey;
                        if (carrierShipmentDetails.Addresses[stopCount].Type == "SHIPTO")
                        {

                            txtShipmentStatus.Text = Constants.strArrivedAtDestination;

                            imViewSource.SetImageResource(Resource.Drawable.imgstop);
                            imViewDestination.SetImageResource(Resource.Drawable.imgDestination);

                        }
                        else
                        {

                            txtShipmentStatus.Text = "Arrived at " + carrierShipmentDetails.Addresses[stopCount].Type;//trackingStatus
                            imViewSource.SetImageResource(Resource.Drawable.imgstop);
                            imViewDestination.SetBackgroundResource(0);
                            imViewDestination.SetImageResource(Resource.Drawable.imgstop);

                        }
                        Constants.stopCountForConfirmtion = "STOP" + stopCount;

                        break;
                    case Constants.completedkey:

                        statusCode = Helper.Constants.completedkey;
                        if (carrierShipmentDetails.Addresses[stopCount].Type == "SHIPTO")
                        {


                            txtShipmentStatus.Text = Constants.strArrivedAtDestination;

                            imViewSource.SetImageResource(Resource.Drawable.imgstop);
                            imViewDestination.SetImageResource(Resource.Drawable.imgDestination);

                        }
                        else if (carrierShipmentDetails.Addresses[stopCount].Type == "BILLTO")
                        {
                            if (carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 1].ActivityDescr == Constants.strCompletedDeliveryText)
                            {

                                txtShipmentStatus.Text = Constants.strCompletedDeliveryText;

                            }
                            else
                            {

                                txtShipmentStatus.Text = Constants.strArrivedAtDestination;

                            }

                            imViewSource.SetImageResource(Resource.Drawable.imgstop);
                            imViewDestination.SetImageResource(Resource.Drawable.imgDestination);
                        }
                        else
                        {
                            txtShipmentStatus.Text = "Completed Delivery of " + carrierShipmentDetails.Addresses[stopCount - 1].Type;

                            imViewSource.SetImageResource(Resource.Drawable.imgstop);
                            imViewDestination.SetImageResource(Resource.Drawable.imgDestination);
                        }

                        Constants.stopCountForConfirmtion = "STOP" + (stopCount - 1);

                        //ResetTracking(); //Reset tracking details
                        break;
                    case "Shipment Completed":

                        statusCode = Helper.Constants.completedkey;

                        txtShipmentStatus.Text = Constants.strCompletedDeliveryText;

                        imViewSource.SetImageResource(Resource.Drawable.imgstop);
                        imViewDestination.SetImageResource(Resource.Drawable.imgDestination);

                        break;
                    case Constants.exceptionkey1:
                        //statuscount = 7;
                        statusCode = Helper.Constants.exceptionkey1;

                        txtShipmentStatus.Text = trackingStatus[ShipmentActivity];

                        //ResetTracking(); //Reset tracking details
                        break;
                    case Constants.exceptionkey2:
                        //statuscount = 7;
                        statusCode = Helper.Constants.exceptionkey2;

                        txtShipmentStatus.Text = trackingStatus[ShipmentActivity];
                        //txtViewUpdatedStatus.Text = Constants.strCompletedDeliveryText;

                        // ResetTracking(); //Reset tracking details
                        break;
                    case Constants.exceptionkey3:
                        //statuscount = 7;
                        statusCode = Helper.Constants.exceptionkey3;

                        txtShipmentStatus.Text = trackingStatus[ShipmentActivity];
                        //txtViewUpdatedStatus.Text = Constants.strCompletedDeliveryText;

                        //ResetTracking(); //Reset tracking details
                        break;
                    case Constants.exceptionkey4:
                        //statuscount = 7;
                        statusCode = Helper.Constants.exceptionkey4;

                        txtShipmentStatus.Text = trackingStatus[ShipmentActivity];
                        //txtViewUpdatedStatus.Text = Constants.strCompletedDeliveryText;

                        //ResetTracking(); //Reset tracking details
                        break;
                    case Constants.exceptionkey5:
                        //statuscount = 7;
                        statusCode = Helper.Constants.exceptionkey5;

                        txtShipmentStatus.Text = trackingStatus[ShipmentActivity];
                        //txtViewUpdatedStatus.Text = Constants.strCompletedDeliveryText;

                        //ResetTracking(); //Reset tracking details
                        break;
                    default:
                        txtShipmentStatus.Text = Constants.shippingNotStart;

                        break;
                }
                if (ShipmentActivity == Constants.completedkey)
                {
                    txtAddressTo.Text = string.Format($"{carrierShipmentDetails.Addresses[stopCount - 1].Company}{carrierShipmentDetails.Addresses[stopCount - 1].Address1} {carrierShipmentDetails.Addresses[stopCount - 1].Address2} {carrierShipmentDetails.Addresses[stopCount - 1].City} {carrierShipmentDetails.Addresses[stopCount - 1].State} {carrierShipmentDetails.Addresses[stopCount - 1].Zip}");
                    txtAddressFrom.Text = string.Format($"{carrierShipmentDetails.Addresses[stopCount - 2].Company} {carrierShipmentDetails.Addresses[stopCount - 2].Address1} {carrierShipmentDetails.Addresses[stopCount - 2].Address2} {carrierShipmentDetails.Addresses[stopCount - 2].City} {carrierShipmentDetails.Addresses[stopCount - 2].State} {carrierShipmentDetails.Addresses[stopCount - 2].Zip}");
                }
                else
                {
                    txtAddressTo.Text = string.Format($"{carrierShipmentDetails.Addresses[stopCount].Company} {carrierShipmentDetails.Addresses[stopCount].Address1} {carrierShipmentDetails.Addresses[stopCount].Address2} {carrierShipmentDetails.Addresses[stopCount].City} {carrierShipmentDetails.Addresses[stopCount].State} {carrierShipmentDetails.Addresses[stopCount].Zip}");
                    txtAddressFrom.Text = string.Format($"{carrierShipmentDetails.Addresses[stopCount - 1].Company} {carrierShipmentDetails.Addresses[stopCount - 1].Address1} {carrierShipmentDetails.Addresses[stopCount - 1].Address2} {carrierShipmentDetails.Addresses[stopCount - 1].City} {carrierShipmentDetails.Addresses[stopCount - 1].State} {carrierShipmentDetails.Addresses[stopCount - 1].Zip}");
                }
                Constants.currentShipStatus = txtShipmentStatus.Text;
                //}
            }
            catch
            {
                throw;
            }
            finally
            {
                Alerts.HideBusyLoader();
            }
        }
    }

}