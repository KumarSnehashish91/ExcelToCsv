using System;
using System.Collections.Generic;
using System.Linq;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Views;
using Android.Widget;
using Android.Gms.Maps;
using Android.Gms.Maps.Model;
using Android.Locations;
using RateLinx.GoogleServices;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;
using System.Threading.Tasks;
using System.Net;
using Newtonsoft.Json;
using Android.Graphics;
using RateLinx.Droid.GoogleMapServices;
using Android.Content.PM;
using RateLinx.Droid.Adapters;
using Android.Support.V7.App;
using RateLinx.APIs;
using RateLinx.Models;
using LatLng = Android.Gms.Maps.Model.LatLng;

namespace RateLinx.Droid.Activities
{
    /// <summary>
    /// Shipment Address Activity
    /// </summary>
    [Activity(Label = "ShipmentsAddressActivity", Theme = "@style/Theme.AppCompat.NoActionBar", ConfigurationChanges = ConfigChanges.Orientation | ConfigChanges.ScreenSize)]
    public class ShipmentsAddressActivity : AppCompatActivity

    {
        #region defing variables
        /// <summary>
        /// 
        /// </summary>
        public static string compositeKey;
        GoogleMap map = null;
        SupportMapFragment mapFrag = null;
        TextView txtViewShipmentNo = null;
        LatLng latLngSource, latLngStop;
        Utility objUtility = null;
        LatLng latLngDestination;
        CarrierShipmentDetails carrierShipmentDetails = null;
        List<string> shipmentAddress = null;
        decimal totalDistance = 0;

        #endregion
        public ShipmentsAddressActivity()
        {
            
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        public ShipmentsAddressActivity(string key)
        {
            compositeKey = key;
            shipmentAddress = new List<string>();
        }
        /// <summary>
        /// Showing Address Details on Map
        /// </summary>
        /// <param name="savedInstanceState"></param>
        async protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                if(shipmentAddress==null)
                {
                    shipmentAddress = new List<string>();
                }
                base.OnCreate(savedInstanceState);
                //Remove Header Title
                RequestWindowFeature(WindowFeatures.NoTitle);
                if (string.IsNullOrEmpty(CommanUtil.tokenNo))
                {
                    Utility.Logout(this);
                }
                objUtility = new Utility();
                Alerts.showBusyLoader(this);
                // await Task.Delay(100);
                string response = await objUtility.BindShipmentDetail(compositeKey, this);
                if (!string.IsNullOrEmpty(response))
                {
                    carrierShipmentDetails = JsonConvert.DeserializeObject<CarrierShipmentDetails>(response);
                    foreach (var address in carrierShipmentDetails.Addresses)
                    {
                        shipmentAddress.Add(string.Format($"{address.Address1} {address.Address2} {address.City} {address.State} {address.Zip}"));
                    }
                }
                SetContentView(Resource.Layout.ShipmentsAddress);
                SetUpGoogleMap();
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
                Finish();
            }
            finally
            {
                Alerts.HideBusyLoader();
            }
        }

        /// <summary>
        /// SetUP Google Map
        /// </summary>
        private void SetUpGoogleMap()
        {
            try
            {
                if (!Utility.FnIsOnline(this))
                {
                    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                //Find Controls
                // mapFrag = (MapFragment)FragmentManager.FindFragmentById(Resource.Id.map);
                mapFrag = (SupportMapFragment)SupportFragmentManager.FindFragmentById(Resource.Id.map);
                txtViewShipmentNo = FindViewById<TextView>(Resource.Id.txtViewShipment);
                LinearLayout lnrLayoutBackIcon = FindViewById<LinearLayout>(Resource.Id.lnrLayoutBackIcon);
                lnrLayoutBackIcon.Click += LnrLayoutBackIcon_Click;
                ImageView ImgBackIcon = FindViewById<ImageView>(Resource.Id.imgBackIcon);
                ImgBackIcon.Click += ImgBackIcon_Click;
                txtViewShipmentNo.Text = "";
                //Displaying Map after getting the details
                var mapReadyCallback = new OnMapReadyClass();
                mapReadyCallback.MapReadyAction += async delegate (GoogleMap objMap)
                 {
                     map = objMap;
                    // map.TrafficEnabled = true;
                    await FnplotMap(map); //Plot Map
                };
                mapFrag.GetMapAsync(mapReadyCallback);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Back Icon
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgBackIcon_Click(object sender, EventArgs e)
        {
            Finish();
        }

        /// <summary>
        /// Back Button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LnrLayoutBackIcon_Click(object sender, EventArgs e)
        {
            Finish();
        }

        /// <summary>
        /// On Map ready
        /// </summary>
        /// <param name="googleMap"></param>
        public async Task FnplotMap(GoogleMap googleMap)
        {
            try
            {
                Alerts.showBusyLoader(this);
                this.map = googleMap;
                Constants.showSourceMarker = true;
                //Get Lat Long 
                var i = 0;
                bool result = false;
                for (i = 0; i <= shipmentAddress.Count - 2; i++)
                {
                    result = await FnLocationToLatLng(shipmentAddress[i], shipmentAddress[i + 1]);
                    if (result)
                    {
                        //Set Camera Position

                        if (latLngSource != null && latLngDestination != null)
                        {
                            if (i == shipmentAddress.Count - 2)
                            {
                                Constants.showDestinationMarker = true;
                            }
                            await FnDrawPathAsync(shipmentAddress[i], shipmentAddress[i + 1]);
                        }
                        //Alerts.HideBusyLoader();
                    }
                    else
                    {
                        Alerts.HideBusyLoader();
                        Toast.MakeText(this, Constants.strLocation, ToastLength.Long).Show();
                    }
                    //}

                }
                if (latLngSource != null)
                {
                    FnUpdateCameraPosition(latLngSource);
                }
                //if (carrierShipmentDetails != null)
                //{

                //    if (carrierShipmentDetails.IsMultiStop)
                //    {

                //        await multiStopTracking();
                //    }
                //    else
                //    {
                //        await GetShipmentStatusAsync();
                //    }
                //}
            }
            catch (Exception ex)
            {
                Alerts.HideBusyLoader();
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
            }
            finally
            {
                Alerts.HideBusyLoader();
            }
        }

        /// <summary>
        /// Draw path from source to destination
        /// </summary>
        /// <param name="strSource"></param>
        /// <param name="strDestination"></param>
        async Task FnDrawPath(string strSource, string strDestination)
        {
            try
            {
                string strFullDirectionURL = string.Format(Constants.strGoogleDirectionUrl, strSource, strDestination);
                string strJSONDirectionResponse = await FnHttpRequest(strFullDirectionURL);
                if (strJSONDirectionResponse != Constants.strException)
                {
                    //RunOnUiThread(() =>
                    //{
                    if (map != null)
                    {
                        map.Clear();
                        MarkOnMap(/*Constants.strTextSource*/"Origin", strSource, latLngSource, Resource.Drawable.MarkerSource);
                        MarkOnMap(Constants.strTextDestination, strDestination, latLngDestination, Resource.Drawable.MarkerDest);
                    }
                    //});
                    FnSetDirectionQuery(strJSONDirectionResponse);
                }
                else
                {

                    Toast.MakeText(this, Constants.strUnableToConnect, ToastLength.Short).Show();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Add Polyline in Map
        /// </summary>
        /// <param name="strJSONDirectionResponse"></param>
        private void FnSetDirectionQuery(string strJSONDirectionResponse, bool isCalculate = true)
        {
            try
            {
                var objRoutes = JsonConvert.DeserializeObject<GoogleDirectionClass>(strJSONDirectionResponse);
                //objRoutes.routes.Count  --may be more then one 
                if (objRoutes.routes.Count > 0)
                {
                    if (isCalculate)
                    {
                        totalDistance = GPSService.CalculateDistance(objRoutes); //Get Distance
                    }
                    else
                    {
                        string encodedPoints = objRoutes.routes[0].overview_polyline.points;
                        var lstDecodedPoints = FnDecodePolylinePoints(encodedPoints);
                        //convert list of location point to array of latlng type
                        var latLngPoints = new LatLng[lstDecodedPoints.Count];
                        int index = 0;
                        foreach (GoogleServices.Location loc in lstDecodedPoints)
                        {
                            latLngPoints[index++] = new LatLng(loc.lat, loc.lng);
                        }
                        var polylineoption = new PolylineOptions();
                        polylineoption.InvokeColor(Color.Red);
                        polylineoption.Geodesic(true);
                        polylineoption.InvokeWidth(6);
                        polylineoption.Add(latLngPoints);
                        RunOnUiThread(() =>
                        {
                            map.AddPolyline(polylineoption);
                        });
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Create Lat Long for polyline
        /// </summary>
        /// <param name="encodedPoints"></param>
        /// <returns></returns>
        List<GoogleServices.Location> FnDecodePolylinePoints(string encodedPoints)
        {
            if (string.IsNullOrEmpty(encodedPoints))
                return null;
            var poly = new List<GoogleServices.Location>();
            char[] polylinechars = encodedPoints.ToCharArray();
            int index = 0;

            int currentLat = 0;
            int currentLng = 0;
            int next5bits;
            int sum;
            int shifter;

            try
            {
                while (index < polylinechars.Length)
                {
                    // calculate next latitude
                    sum = 0;
                    shifter = 0;
                    do
                    {
                        next5bits = (int)polylinechars[index++] - 63;
                        sum |= (next5bits & 31) << shifter;
                        shifter += 5;
                    } while (next5bits >= 32 && index < polylinechars.Length);

                    if (index >= polylinechars.Length)
                        break;

                    currentLat += (sum & 1) == 1 ? ~(sum >> 1) : (sum >> 1);

                    //calculate next longitude
                    sum = 0;
                    shifter = 0;
                    do
                    {
                        next5bits = (int)polylinechars[index++] - 63;
                        sum |= (next5bits & 31) << shifter;
                        shifter += 5;
                    } while (next5bits >= 32 && index < polylinechars.Length);

                    if (index >= polylinechars.Length && next5bits >= 32)
                        break;

                    currentLng += (sum & 1) == 1 ? ~(sum >> 1) : (sum >> 1);
                    GoogleServices.Location p = new GoogleServices.Location();
                    p.lat = Convert.ToDouble(currentLat) / 100000.0;
                    p.lng = Convert.ToDouble(currentLng) / 100000.0;
                    poly.Add(p);
                }
            }
            catch
            {

                Toast.MakeText(this, Constants.strPleaseWait, ToastLength.Short).Show();
            }
            return poly;
        }

        /// <summary>
        /// Update camera position
        /// </summary>
        /// <param name="pos"></param>
        private void FnUpdateCameraPosition(LatLng pos)
        {
            try
            {
                LatLngBounds.Builder builder1 = new LatLngBounds.Builder();
                builder1.Include(latLngSource);
                builder1.Include(latLngDestination);
                map.UiSettings.ZoomControlsEnabled = true;
                map.UiSettings.MyLocationButtonEnabled = true;
                map.MyLocationEnabled = true;
                map.UiSettings.RotateGesturesEnabled = true;
                map.UiSettings.ZoomGesturesEnabled = true;
                var metrics = Resources.DisplayMetrics;
                int width = metrics.WidthPixels;
                int padding = (int)(width * 0.10);
                LatLngBounds bounds = builder1.Build();
                CameraUpdate cameraUpdate = CameraUpdateFactory.NewLatLngBounds(bounds, padding);
                map.AnimateCamera(cameraUpdate);
            }
            catch (Exception ex)
            {

            }
        }

        /// <summary>
        /// Get lat long of souce and destination
        /// </summary>
        /// <param name="strSource"></param>
        /// <param name="strDestination"></param>
        /// <returns></returns>
        async Task<bool> FnLocationToLatLng(string strSource, string strDestination)
        {
            try
            {
                var geo = new Geocoder(this);
                var sourceAddress = await geo.GetFromLocationNameAsync(strSource, 1);
                sourceAddress.ToList().ForEach((addr) =>
                {
                    latLngSource = new LatLng(addr.Latitude, addr.Longitude);
                });

                var destAddress = await geo.GetFromLocationNameAsync(strDestination, 1);
                destAddress.ToList().ForEach((addr) =>
                {
                    latLngDestination = new LatLng(addr.Latitude, addr.Longitude);
                });

                return true;
            }
            catch
            {
                return false;
            }

        }
        /// <summary>
        /// FnDrawPathAsync of origin and source
        /// </summary>
        /// <param name="strSource"></param>
        /// <param name="strDestination"></param>
        /// <returns></returns>
        async Task FnDrawPathAsync(string strSource, string strDestination)
        {
            try
            {
                string strFullDirectionURL = string.Format(Constants.strGoogleDirectionUrl, strSource, strDestination);
                string strJSONDirectionResponse = await FnHttpRequest(strFullDirectionURL);
                if (strJSONDirectionResponse != Constants.strException)
                {
                    RunOnUiThread(() =>
                    {
                        if (map != null)
                        {
                            if (Constants.showSourceMarker)
                            {
                                MarkOnMap(/*Constants.strTextSource*/"Origin", strSource, latLngSource, Resource.Drawable.MarkerSource);
                                if (shipmentAddress.Count > 2)
                                {
                                    Constants.showSourceMarker = false;
                                }
                            }
                            if (Constants.showDestinationMarker)
                            {
                                MarkOnMap(Constants.strTextDestination, strDestination, latLngDestination, Resource.Drawable.MarkerDest);
                                Constants.showDestinationMarker = false;
                            }
                            else
                            {
                                Constants.stopIncrement += 1;
                                MarkOnMap("Stop" + Constants.stopIncrement, strDestination, latLngDestination, Resource.Drawable.imgstop);
                            }
                        }
                    });
                    FnSetDirectionQuery(strJSONDirectionResponse, false);
                }
                else
                {

                    Toast.MakeText(this, Constants.strUnableToConnect, ToastLength.Short).Show();
                }
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Set marker on map
        /// </summary>
        /// <param name="title"></param>
        /// <param name="address"></param>
        /// <param name="pos"></param>
        /// <param name="resourceId"></param>
        private void MarkOnMap(string title, string address, LatLng pos, int resourceId)
        {
            //RunOnUiThread(() =>
            //{
            try
            {
                var marker = new MarkerOptions();
                marker.SetTitle(title);
                marker.SetPosition(pos); //Resource.Drawable.BlueDot
                marker.SetSnippet(address);
                marker.SetIcon(BitmapDescriptorFactory.FromResource(resourceId));
                map.AddMarker(marker);
                map.SetInfoWindowAdapter(new InfoWindowAdapter(this));
            }
            catch
            {
                throw;
            }
            //});
        }

        /// <summary>
        /// 
        /// </summary>
        WebClient webclient;
        async Task<string> FnHttpRequest(string strUri)
        {
            webclient = new WebClient();
            string strResultData;
            try
            {
                strResultData = await webclient.DownloadStringTaskAsync(new Uri(strUri));
                Console.WriteLine(strResultData);
            }
            catch
            {
                strResultData = Constants.strException;
            }
            finally
            {
                if (webclient != null)
                {
                    webclient.Dispose();
                    webclient = null;
                }
            }
            return strResultData;
        }
        /// <summary>
        /// On map click event
        /// </summary>
        /// <param name="point"></param>
        public void OnMapClick(LatLng point)
        {

        }
        /// <summary>
        /// On marker click event
        /// </summary>
        /// <param name="marker"></param>
        /// <returns></returns>
        public bool OnMarkerClick(Marker marker)
        {
            return true;
        }
    }
}