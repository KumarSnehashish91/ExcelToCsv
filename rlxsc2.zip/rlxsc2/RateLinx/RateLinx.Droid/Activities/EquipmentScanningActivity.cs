﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Android;
using Android.App;
using Android.Content.PM;
using Android.OS;
using Android.Support.V4.Content;
using Android.Views;
using Android.Views.Animations;
using Android.Widget;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RateLinx.APIs;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;
using RateLinx.Models;
using ZXing.Mobile;
using V4App = Android.Support.V4.App;

namespace RateLinx.Droid.Activities
{
    /// <summary>
    /// EquipmentScanningActivity
    /// </summary>
    [Activity(Label = "EquipmentScanningActivity", Theme = "@style/Theme.AppCompat.NoActionBar", ConfigurationChanges = ConfigChanges.Orientation | ConfigChanges.ScreenSize)]
    public class EquipmentScanningActivity : Activity
    {
        #region Declaration of controls instances and variables 
        TextView txtPickupScan, txtPickupCancel, txtDropScan, txtDropoffCancel, txtDialogHeader, editTextCross
            , txtDialogBody, tvBarcode, tvCancel, txtAttributeHead, txtPickupValue, txtDropOffValue, txtOtherValue = null;
        Button btnScanPickup, btnScanDrop, btnScanOthers, btnSaveDetails, btnCancel, btnProceed = null;
        LinearLayout lnrOtherEquipScans, lnrAttributeHdr, lnrScannedAttributeLayout, lnrScannedEquipmentList = null;
        List<TextView> lstTvOthersCancel = new List<TextView>();
        List<TextView> lstTvOthersScanNo = new List<TextView>();
        List<string> lstOtherEquipNo = new List<string>();
        string shipmentDetails = string.Empty;
        CarrierShipmentDetails lstShipmentDetail = null;
        //ListView lstViewScannedAttribute;
        Dialog dialog;
        int idTvOtherCancel;
        CommanUtil commanUtil;
        int idCount = 1;
        AlertDialog.Builder alert = null;
        string stopCountForConfirmtion = string.Empty;
        MobileBarcodeScanner scanner = null;
        View zxingOverlay, viewLine;
        ImageView btnCancelScan;
        Animation anim;
        int multipleBarcodeCount = 0;
        readonly string[] PermissionsLocation =
                         {
         Manifest.Permission.Camera };
        #endregion

        /// <summary>
        /// Equipment Scanning Activity On Create Event
        /// </summary>
        /// <param name="savedInstanceState"></param>
        async protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                commanUtil = new CommanUtil();
                base.OnCreate(savedInstanceState);
                // Create your application here

                SetContentView(Resource.Layout.EquipmentScanning);
                if (string.IsNullOrEmpty(CommanUtil.tokenNo))
                {
                    Utility.Logout(this);
                }
                this.Window.SetSoftInputMode(SoftInput.StateAlwaysHidden);

                await BindShipment();

                //Alerts.HideBusyLoader();
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Alerts.HideBusyLoader();
                //Toast.MakeText(this, ex.Message, ToastLength.Long).Show();
                //Finish();
            }
        }
        /// <summary>
        /// 
        /// </summary>
        async public Task BindShipment()
        {
            try
            {
                Utility objUtility = new Utility();
                Alerts.showBusyLoader(this);
                if (!Utility.FnIsOnline(this))
                {
                    Alerts.HideBusyLoader();
                    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                //await Task.Delay(5000);
                string response = await objUtility.BindShipmentDetail(Constants.methodNmaeForEquipmentScanning, this);
                if (!string.IsNullOrEmpty(response))
                {
                    lstShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(response);
                    Alerts.HideBusyLoader();
                }
                else
                {
                    Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
                }
                await GetControlById();
               
                if (lstShipmentDetail.IsMultiStop)
                {
                    stopCountForConfirmtion = commanUtil.multiStopTracking(lstShipmentDetail);
                }
            }
            catch
            {
                Alerts.HideBusyLoader();
            }

        }
        /// <summary>
        /// Get Control By Id And Creating Events
        /// </summary>
        public async Task GetControlById()
        {
            try
            {
                Alerts.showBusyLoader(this);
                await Task.Delay(1000);
                MobileBarcodeScanner.Initialize(this.Application);
                ImageView imgClosePage = FindViewById<ImageView>(Resource.Id.imgClosePage);
                txtPickupScan = FindViewById<TextView>(Resource.Id.txtPickupScan);
                txtAttributeHead = FindViewById<TextView>(Resource.Id.txtAttributeHead);
                txtPickupCancel = FindViewById<TextView>(Resource.Id.txtPickupCancel);
                txtDropScan = FindViewById<TextView>(Resource.Id.txtDropScan);
                txtDropoffCancel = FindViewById<TextView>(Resource.Id.txtDropoffCancel);
                lnrOtherEquipScans = FindViewById<LinearLayout>(Resource.Id.lnrOtherEquipScans);
                lnrAttributeHdr = FindViewById<LinearLayout>(Resource.Id.lnrAttributeHdr);
                lnrScannedAttributeLayout = FindViewById<LinearLayout>(Resource.Id.lnrScannedAttributeLayout);
                lnrScannedEquipmentList = FindViewById<LinearLayout>(Resource.Id.lnrScannedEquipmentList);
                btnScanPickup = FindViewById<Button>(Resource.Id.btnScanPickup);
                btnScanDrop = FindViewById<Button>(Resource.Id.btnScanDrop);
                btnScanOthers = FindViewById<Button>(Resource.Id.btnScanOthers);
                btnSaveDetails = FindViewById<Button>(Resource.Id.btnSaveDetails);
                btnCancel = FindViewById<Button>(Resource.Id.btnCancel);
                TextView txtViewCopyRight = FindViewById<TextView>(Resource.Id.txtViewCopyRight);
                txtPickupValue = FindViewById<TextView>(Resource.Id.txtPickupValue);
                txtDropOffValue = FindViewById<TextView>(Resource.Id.txtDropOffValue);
                txtOtherValue = FindViewById<TextView>(Resource.Id.txtOtherValue);
                txtViewCopyRight.Text = CommanUtil.PrintYear();//Printc Current Year in Page Footer 
                BindAttributes();//Bind Attributes
                Alerts.HideBusyLoader();
                btnScanPickup.Click += async delegate
                 {
                     if ((ContextCompat.CheckSelfPermission(this, Manifest.Permission.Camera) == (int)Permission.Granted))
                     {
                         await OpenScanner("Pickup");
                     }
                     else
                     {
                         V4App.ActivityCompat.RequestPermissions(this, PermissionsLocation, 0);
                     }

                 };
                btnScanDrop.Click += async delegate
                {
                    if ((ContextCompat.CheckSelfPermission(this, Manifest.Permission.Camera) == (int)Permission.Granted))
                    {
                        await OpenScanner("DropOff");
                    }
                    else
                    {
                        V4App.ActivityCompat.RequestPermissions(this, PermissionsLocation, 0);
                    }

                };
                btnScanOthers.Click += async delegate
                {
                    if ((ContextCompat.CheckSelfPermission(this, Manifest.Permission.Camera) == (int)Permission.Granted))
                    {
                        await OpenScanner("Other");
                    }
                    else
                    {
                        V4App.ActivityCompat.RequestPermissions(this, PermissionsLocation, 0);
                    }

                };
                zxingOverlay = LayoutInflater.FromContext(this).Inflate(Resource.Layout.ZxingOverlay, null);
                btnCancelScan = zxingOverlay.FindViewById<ImageView>(Resource.Id.btnCancel);
                btnCancelScan.Click += delegate
                {
                    Alerts.HideBusyLoader();
                    scanner.Cancel();
                };
                anim = AnimationUtils.LoadAnimation(ApplicationContext,
                           Resource.Drawable.blinkAnimation);
                viewLine = zxingOverlay.FindViewById<View>(Resource.Id.viewLine);
                imgClosePage.Click += ImgClosePage_Click;
                btnSaveDetails.Click += BtnSaveDetails_Click;
                btnCancel.Click += BtnCancel_Click;
                txtPickupCancel.Click += TxtPickupCancel_Click;
                txtDropoffCancel.Click += TxtDropoffCancel_Click;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Scanned Attribute
        /// </summary>
        public void BindAttributes()
        {
            try
            {
                if (lstShipmentDetail != null)
                {
                    ;

                    var scannedEquipmentListAttribute = lstShipmentDetail.Attributes.Where(m => m.Key.ToLower().Contains("equip")).Select(m => new ScannedEquipmentKeyValue() { ScannedEquipKey = m.Key, ScannedEquipValue = m.Value }).ToList();
                    txtAttributeHead.Text = Constants.attributes + scannedEquipmentListAttribute.Count;

                    if (scannedEquipmentListAttribute != null && scannedEquipmentListAttribute.Count > 0)
                    {
                        lnrScannedEquipmentList.RemoveAllViews();
                        foreach (var equipment in scannedEquipmentListAttribute)
                        {
                            View view = this.LayoutInflater.Inflate(Resource.Layout.ScannedEquipmentRowLayout, null);
                            TextView txtPickupKey = view.FindViewById<TextView>(Resource.Id.txtPickupKey);
                            TextView txtPickupValue = view.FindViewById<TextView>(Resource.Id.txtPickupValue);

                            txtPickupKey.Text = equipment.ScannedEquipKey;
                            txtPickupValue.Text = equipment.ScannedEquipValue;

                            lnrScannedEquipmentList.AddView(view);

                        }
                    }
                }
                else
                {
                    lnrAttributeHdr.Visibility = ViewStates.Gone;
                }

            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Open custom barcode scanner
        /// </summary>
        /// <param name="scanType"></param>
        private async Task OpenScanner(string scanType)
        {
            try
            {
                viewLine.StartAnimation(anim);
                scanner = new MobileBarcodeScanner();
                scanner.UseCustomOverlay = true;
                scanner.CustomOverlay = zxingOverlay;
                alert = new AlertDialog.Builder(this);
                alert.SetView(Resource.Layout.dialog);
                dialog = alert.Create();
                Alerts.showBusyLoader(this);
                await Task.Delay(2000);
                var result = await scanner.Scan(new MobileBarcodeScanningOptions { AutoRotate = false });
                //HandleScanResult(result);
                if (scanType == "Pickup")
                {
                    if (result != null)
                    {
                        Alerts.HideBusyLoader();
                        txtPickupScan.Text = string.Empty;
                        txtPickupScan.Text = result.Text;
                        txtPickupCancel.Visibility = ViewStates.Visible;
                    }
                }

                if (scanType == "DropOff")
                {
                    if (result != null)
                    {
                        Alerts.HideBusyLoader();
                        txtDropScan.Text = string.Empty;
                        txtDropScan.Text = result.Text;
                        txtDropoffCancel.Visibility = ViewStates.Visible;
                    }
                }

                if (scanType == "Other")
                {
                    if (lstTvOthersScanNo.Count > 0)
                    {
                        lnrOtherEquipScans.RemoveAllViews();
                        for (int indexEqipScan = 0; indexEqipScan < lstTvOthersCancel.Count; indexEqipScan++)
                        {
                            lnrOtherEquipScans.AddView(lstTvOthersScanNo[indexEqipScan]);
                            lnrOtherEquipScans.AddView(lstTvOthersCancel[indexEqipScan]);
                        }
                    }
                    alert = new AlertDialog.Builder(this);
                    alert.SetView(Resource.Layout.dialog);
                    dialog = alert.Create();
                    if (result != null)
                    {
                        Alerts.HideBusyLoader();
                        dialog.Show();
                        txtDialogHeader = dialog.FindViewById<TextView>(Resource.Id.txtDialogHeader);
                        editTextCross = dialog.FindViewById<TextView>(Resource.Id.editTextCross);
                        txtDialogBody = dialog.FindViewById<TextView>(Resource.Id.txtDialogBody);
                        btnProceed = dialog.FindViewById<Button>(Resource.Id.btnProceed);
                        btnProceed.Text = Constants.strkeepScanning;
                        btnCancel = dialog.FindViewById<Button>(Resource.Id.btnCancel);
                        btnCancel.Text = Constants.strDoneBtn;
                        dialog.SetCancelable(false);
                        txtDialogHeader.Text = Constants.strOtherScan;
                        txtDialogBody.Text = Constants.strYouscanned + result.Text + Constants.strWouldScan;
                        btnProceed.Click += async delegate
                        {
                            if (lstTvOthersScanNo.Count > 0)
                            {
                                lnrOtherEquipScans.RemoveAllViews();
                                for (int indexOtherScan = 0; indexOtherScan < lstTvOthersCancel.Count; indexOtherScan++)
                                {
                                    lnrOtherEquipScans.AddView(lstTvOthersScanNo[indexOtherScan]);
                                    lnrOtherEquipScans.AddView(lstTvOthersCancel[indexOtherScan]);
                                }
                            }
                            dialog.Dismiss();
                            TextView txtViewOthers = new TextView(this);
                            txtViewOthers.Id = 100 + multipleBarcodeCount;/*lstTvOthersCancel.Count;*/
                            txtViewOthers.Text = result.Text;
                            txtViewOthers.SetTextColor(Android.Graphics.Color.Black);
                            lstTvOthersScanNo.Add(txtViewOthers);
                            TextView txtViewOthersCancel = new TextView(this);
                            txtViewOthersCancel.Id = 100 + multipleBarcodeCount;
                            txtViewOthersCancel.Click += delegate
                            {
                                RemoveBarcodeFromList(txtViewOthersCancel.Id);
                            };
                            multipleBarcodeCount++;
                            txtViewOthersCancel.Text = " X ";
                            txtViewOthersCancel.SetTextColor(Android.Graphics.Color.Red);
                            lstTvOthersCancel.Add(txtViewOthersCancel);
                            lnrOtherEquipScans.AddView(txtViewOthers);
                            lnrOtherEquipScans.AddView(txtViewOthersCancel);
                            idCount++;
                            await OpenScanner("Other");
                            //dialog.Hide();
                        };
                        editTextCross.Click += delegate
                        {
                            try
                            {
                                Alerts.HideBusyLoader();
                                dialog.Dismiss();
                                TextView txtViewOthers = new TextView(this);
                                txtViewOthers.Id = 100 + multipleBarcodeCount;/* lstTvOthersCancel.Count;*/
                                txtViewOthers.Text = result.Text;
                                txtViewOthers.SetTextColor(Android.Graphics.Color.Black);
                                lstTvOthersScanNo.Add(txtViewOthers);
                                TextView txtViewOthersCancel = new TextView(this);
                                txtViewOthersCancel.Id = 100 + multipleBarcodeCount;
                                txtViewOthersCancel.Text = " X ";
                                txtViewOthersCancel.SetTextColor(Android.Graphics.Color.Red);
                                lstTvOthersCancel.Add(txtViewOthersCancel);
                                lnrOtherEquipScans.AddView(txtViewOthers);
                                lnrOtherEquipScans.AddView(txtViewOthersCancel);
                                txtViewOthersCancel.Click += delegate
                                {
                                    RemoveBarcodeFromList(txtViewOthersCancel.Id);
                                };
                                multipleBarcodeCount++;
                            }
                            catch (Exception ex)
                            {
                                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                            }
                            finally
                            {
                                Alerts.HideBusyLoader();
                            }
                        };
                        btnCancel.Click += delegate
                        {
                            try
                            {
                                Alerts.HideBusyLoader();
                                dialog.Dismiss();
                                TextView txtViewOthers = new TextView(this);
                                txtViewOthers.Id = 100 + multipleBarcodeCount;/* lstTvOthersCancel.Count;*/
                                txtViewOthers.Text = result.Text;
                                txtViewOthers.SetTextColor(Android.Graphics.Color.Black);

                                lstTvOthersScanNo.Add(txtViewOthers);
                                TextView txtViewOthersCancel = new TextView(this);
                                txtViewOthersCancel.Id = 100 + multipleBarcodeCount;

                                txtViewOthersCancel.Text = " X ";
                                txtViewOthersCancel.SetTextColor(Android.Graphics.Color.Red);
                                lstTvOthersCancel.Add(txtViewOthersCancel);
                                lnrOtherEquipScans.AddView(txtViewOthers);
                                lnrOtherEquipScans.AddView(txtViewOthersCancel);
                                //AddEventToButtonsAtRunTime();
                                txtViewOthersCancel.Click += delegate
                                {
                                    RemoveBarcodeFromList(txtViewOthersCancel.Id);
                                };
                                multipleBarcodeCount++;
                            }
                            catch (Exception ex)
                            {
                                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                            }
                            finally
                            {
                                Alerts.HideBusyLoader();
                            }
                        };
                    }
                    Alerts.HideBusyLoader();

                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
            }
        }

        /// <summary>
        /// Fnish Activity
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgClosePage_Click(object sender, EventArgs e)
        {
            Finish();
        }

        /// <summary>
        /// On resume event of Activity
        /// </summary>
        protected override void OnResume()
        {
            Alerts.HideBusyLoader();
            base.OnResume();
        }
        /// <summary>
        /// 
        /// </summary>
        protected override void OnDestroy()
        {
            base.OnDestroy();
            stopCountForConfirmtion = string.Empty;
        }
        /// <summary>
        /// Add Event To Buttons At RunTime
        /// </summary>
        private void AddEventToButtonsAtRunTime()
        {
            try
            {
                for (int index = 0; index < lstTvOthersCancel.Count; index++)
                {
                    idTvOtherCancel = lstTvOthersCancel[index].Id;
                    int barcodePosition = idTvOtherCancel - 100;
                    lstTvOthersCancel[barcodePosition].Click += delegate
                    {
                        RemoveBarcodeFromList(barcodePosition);
                    };
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
            }
        }

        /// <summary>
        /// Remove Barcode FromList
        /// </summary>
        /// <param name="txtViewId"></param>
        private void RemoveBarcodeFromList(int txtViewId)
        {
            try
            {
                if (lstTvOthersScanNo.Count > 0)
                {
                    tvBarcode = lstTvOthersScanNo.Where(x => x.Id == txtViewId).FirstOrDefault();
                    tvCancel = lstTvOthersCancel.Where(x => x.Id == txtViewId).FirstOrDefault();
                    lstTvOthersScanNo.Remove(tvBarcode);
                    lstTvOthersCancel.Remove(tvCancel);
                    lnrOtherEquipScans.RemoveAllViews();
                    for (int indexScan = 0; indexScan < lstTvOthersCancel.Count; indexScan++)
                    {
                        lnrOtherEquipScans.AddView(lstTvOthersScanNo[indexScan]);
                        lnrOtherEquipScans.AddView(lstTvOthersCancel[indexScan]);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// TxtDropoff Cancel Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TxtDropoffCancel_Click(object sender, EventArgs e)
        {
            try
            {
                txtDropScan.Text = "";
                txtDropoffCancel.Visibility = ViewStates.Gone;
            }
            catch
            {
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
                Finish();
            }
        }

        /// <summary>
        /// TxtPickup Cancel Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TxtPickupCancel_Click(object sender, EventArgs e)
        {
            try
            {
                txtPickupScan.Text = "";
                txtPickupCancel.Visibility = ViewStates.Gone;
            }
            catch
            {
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
                Finish();
            }
        }

        /// <summary>
        /// Button Cancel Click Event Redirecting to previous activity
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnCancel_Click(object sender, EventArgs e)
        {
            Finish();
        }

        /// <summary>
        /// Button SaveDetails Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void BtnSaveDetails_Click(object sender, EventArgs e)
        {
            string apiResponse = string.Empty;
            try
            {
                if (!Utility.FnIsOnline(this))
                {
                    Alerts.HideBusyLoader();
                    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                if (CommanUtil.IsTimeOut())
                {
                    if (!string.IsNullOrEmpty(txtPickupScan.Text) || !string.IsNullOrEmpty(txtDropScan.Text) || lstTvOthersScanNo.Count > 0)
                    {
                        SaveScannedEquipment saveScannedEquipment = new SaveScannedEquipment();
                        if (lstOtherEquipNo != null)
                        {
                            lstOtherEquipNo.Clear();
                        }
                        foreach (TextView tvBarcode in lstTvOthersScanNo)
                        {
                            lstOtherEquipNo.Add(tvBarcode.Text);
                        }

                        saveScannedEquipment.PickupNum = txtPickupScan.Text;
                        saveScannedEquipment.DropoffNum = txtDropScan.Text;
                        saveScannedEquipment.OnSiteEquipNums = lstOtherEquipNo;

                        if (lstShipmentDetail.Addresses.Count > 3 && (!string.IsNullOrEmpty(Constants.currentShipStatus)))
                        {

                            if (!string.IsNullOrEmpty(stopCountForConfirmtion))
                            {
                                saveScannedEquipment.Stop = stopCountForConfirmtion;
                            }


                        }

                        string postData = JsonConvert.SerializeObject(saveScannedEquipment);
                        string requestData = lstShipmentDetail.ClientID + "|" + lstShipmentDetail.LocID + "|" + lstShipmentDetail.BolNum;
                        string methodURI = APIMethods.Shipment + "/" + requestData + "/" + APIMethods.equipnumbers;
                        ServiceHelper objServiceHelper = new ServiceHelper();
                        Alerts.showBusyLoader(this); //Loader
                        string Result = await objServiceHelper.PostRequestJson(postData, methodURI, CommanUtil.tokenNo, true);
                        if (!string.IsNullOrEmpty(Result))
                        {
                            Result = Constants.strSuccess;
                            await GetShipmentDetail();
                            Alerts.HideBusyLoader(); //Loader
                            Toast.MakeText(this, Constants.equipmentSaved, ToastLength.Long).Show();

                            txtPickupCancel.Visibility = ViewStates.Gone;
                            txtDropoffCancel.Visibility = ViewStates.Gone;
                            txtPickupScan.Text = string.Empty;
                            txtDropScan.Text = string.Empty;
                            lstOtherEquipNo.Clear();
                            lstTvOthersScanNo.Clear();
                            lstTvOthersCancel.Clear();
                            lnrOtherEquipScans.RemoveAllViews();
                        }
                        else
                        {
                            Alerts.HideBusyLoader(); //Loader
                        }
                    }
                    else
                    {
                        Toast.MakeText(this, Constants.strPickupDropOffEquipNoReq, ToastLength.Short).Show();
                    }
                }
                else
                {
                    Utility.ExpireSession(this);
                }
            }
            catch (Exception ex)
            {
                Alerts.HideBusyLoader(); //Loader
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Get The Shipment Detail
        /// </summary>
        public async Task GetShipmentDetail()
        {
            string compositeKey, strToken, methodName = string.Empty;
            ServiceHelper objServicehelper = null;
            JObject jobject = null;
            compositeKey = CommanUtil.CompositeKey(lstShipmentDetail.ClientID, lstShipmentDetail.LocID, lstShipmentDetail.BolNum);
            objServicehelper = new ServiceHelper();
            //Create json object that holds the api values
            //Method Name
            strToken = CommanUtil.tokenNo;
            methodName = APIMethods.shipmentDetails + "/" + lstShipmentDetail.ClientID + "|" + lstShipmentDetail.BolNum;
            //Get the Shipments
            string strResponse = await objServicehelper.GetRequest(strToken, methodName, true);
            if (strResponse != null)
            {
                jobject = JObject.Parse(strResponse);
                if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
                {
                    lstShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(strResponse);
                    BindAttributes();//Bind Attributes
                }
                else
                {
                    Toast.MakeText(this, Convert.ToString(jobject[Constants.strErrorMessage]), ToastLength.Long).Show();
                    //Post Error Logger Request 
                    Utility.ErrorLog(Constants.strEquipment, Convert.ToString(jobject[Constants.strErrorMessage]), strToken, this);
                }
            }
        }

        /// <summary>
        /// Button Other Sacn Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnScanOthers_Click(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
        }
    }

}