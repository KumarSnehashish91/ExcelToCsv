using Android.App;
using Android.OS;
using Android.Views;
using Android.Content.PM;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;
using Android.Preferences;

namespace RateLinx.Droid.Activities
{
    /// <summary>
    /// 
    /// </summary>
    [Activity(Theme = "@style/splashTheme", MainLauncher = true, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation, NoHistory = true)]
    public class SplashActivity : Activity
    {
        /// <summary>
        /// OnCreate
        /// </summary>
        /// <param name="savedInstanceState"></param>
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            RequestWindowFeature(WindowFeatures.NoTitle);
            // Set our view from the "Startup Page" layout resource
            Utility.sharedPreferences = PreferenceManager.GetDefaultSharedPreferences(this);
            CommanUtil.tokenNo = string.Empty;
            CommanUtil.ViewAs = string.Empty;
            CommanUtil.userID = string.Empty;
            CommanUtil.isTrackingEnable = false;
            CommanUtil.isTrackingOn = true;
            Utility.sharedPreferences.Edit().Remove("objTrackList").Commit();
            StartActivity(typeof(LoginActivity));
            // Create your application here
        }
    }
}