using System;
using System.Collections.Generic;
using System.Linq;
using Android.App;
using Android.OS;
using Android.Views;
using Android.Widget;
using RateLinx.Droid.Utilities;
using RateLinx.Droid.Adapters;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RateLinx.Models;
using RateLinx.Helper;
using RateLinx.APIs;
using System.Threading.Tasks;
using Android.Util;
using System.Security;
using Android.Locations;
using RateLinx.Droid.GoogleMapServices;

[assembly: SecurityCritical]
namespace RateLinx.Droid.Activities
{
    /// <summary>
    /// TrackingInfoActivity Activity
    /// </summary>
    [Activity(Label = "RateLinx", Icon = "@drawable/icon", Theme = "@style/Theme.AppCompat.NoActionBar", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class TrackingInfoActivity : HeaderActivity
    {
        #region  Declaration of controls
        TextView txtActivityDate, txtActivityTime, txtTrackDescription, txtProNumber, lblProNumber, txtCity;
        Spinner spinnerState, spinnerCountry, spinnerDescription;
        string AMPM = string.Empty;
        List<CountryDetails> lstCountryDetails = null;
        List<StateDetails> lstStateDetails = null;
        List<string> lstCountries, lstCountryCodes, lstStates, lstStateCodes = null;
        ListView lstVWTrackingInfo;
        LinearLayout linearLayoutTrackDetails, lnrEnterDesc, lnrTrackLbl, lnrDetailHeading;
        CarrierShipmentDetails lstShipmentDetail = null;
        List<TrackDetail> lstTrackDetail = null;
        List<TrackingDesc> lstTrackDescVal = null;
        string TrackId, response = string.Empty;
        string trackingDescription = string.Empty;
        string activityTime, shipmentDetails = string.Empty;
        RelativeLayout relativeLayoutSave;
        LinearLayout lnrTrackingInformation;
        Button btnSaveTrackInfo;
        bool showDescriptionText = false;
        string[] activityDate = null;
        string newActivityDate, selectedVal, countryName, country, state = string.Empty;
        ListView lstVWTrackingInfo1 = null;
        ImageView imgClosePage;
        TrackDetailsAdapter objTrackDetailsAdapter = null;
        ArrayAdapter adapter = null;
        CommanUtil objCommanUtil = null;
        GPSServiceSettings objGPSServiceSettings = null;
        #endregion

        /// <summary>
        /// TrackingInfoActivity Layout On Load Event
        /// </summary>
        /// <param name="savedInstanceState"></param>
        async protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);
                if (string.IsNullOrEmpty(CommanUtil.tokenNo))
                {
                    Utility.Logout(this);
                }
                SetContentView(Resource.Layout.TrackingInfo);
                this.Window.SetSoftInputMode(SoftInput.StateAlwaysHidden);
                await GetControls();
            }
            catch (Exception ex)
            {
                Alerts.HideBusyLoader();
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
                Utility.ErrorLog(Constants.strEquipment, ex.Message, CommanUtil.tokenNo, this);
                //Finish();
            }
        }

        /// <summary>
        /// Get Controls by id and binding of data
        /// </summary>
        public async Task GetControls()
        {
            try
            {
                objCommanUtil = new CommanUtil();
                objGPSServiceSettings = new GPSServiceSettings();
                imgClosePage = FindViewById<ImageView>(Resource.Id.imgClosePage);
                spinnerState = FindViewById<Spinner>(Resource.Id.spinnerState);
                spinnerCountry = FindViewById<Spinner>(Resource.Id.spinnerCountry);
                spinnerDescription = FindViewById<Spinner>(Resource.Id.spinnerDescription);
                txtActivityDate = FindViewById<EditText>(Resource.Id.txtActivityDate);
                txtActivityTime = FindViewById<EditText>(Resource.Id.txtActivityTime);
                txtTrackDescription = FindViewById<EditText>(Resource.Id.txtTrackDescription);
                txtProNumber = FindViewById<EditText>(Resource.Id.txtProNumber);
                lblProNumber= FindViewById<TextView>(Resource.Id.lblProNumber);
                txtCity = FindViewById<EditText>(Resource.Id.txtCity);
                btnSaveTrackInfo = FindViewById<Button>(Resource.Id.btnSaveTrackInfo);
                btnSaveTrackInfo.Click += BtnSaveTrackInfo_Click;
                lstVWTrackingInfo = FindViewById<ListView>(Resource.Id.lstVWTrackingInfo);
                linearLayoutTrackDetails = FindViewById<LinearLayout>(Resource.Id.linearLayoutTrackDetails);
                lnrEnterDesc = FindViewById<LinearLayout>(Resource.Id.lnrEnterDesc);
                lnrTrackLbl = FindViewById<LinearLayout>(Resource.Id.lnrTrackLbl);
                lnrDetailHeading = FindViewById<LinearLayout>(Resource.Id.lnrDetailHeading);
                lnrTrackingInformation = FindViewById<LinearLayout>(Resource.Id.lnrTrackingInformation);
                relativeLayoutSave = FindViewById<RelativeLayout>(Resource.Id.relativeLayoutSave);
                txtActivityDate.Text = DateTime.Now.ToShortDateString();
                shipmentDetails = Utility.sharedPreferences.GetString(Constants.shipmentDetails, null);
                lstShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(shipmentDetails);
                await InitializeLocationManager();
                await GetShipmentDetail();
                SetTime();
                txtActivityTime.Click += (sender, e) =>
                {
                    Window.SetSoftInputMode(SoftInput.StateAlwaysHidden);
                    TimePickerDialog timePick = new TimePickerDialog(this, ActivityTime, DateTime.Now.Hour, DateTime.Now.Hour, true);
                    timePick.Show();
                };
                txtActivityDate.Click += (sender, e) =>
                {
                    Window.SetSoftInputMode(SoftInput.StateAlwaysHidden);
                    DateTime today = DateTime.Today;
                    DatePickerDialog dialog = new DatePickerDialog(this, ActivityDate, today.Year, today.Month - 1, today.Day);
                    dialog.DatePicker.MinDate = today.Millisecond;
                    dialog.Show();
                };
                if (lstShipmentDetail.DispatchFlag)
                {
                    lnrTrackingInformation.Visibility = ViewStates.Gone;
                    lblProNumber.Text = "Pro Number: " + lstShipmentDetail.ProNum;
                }
                else
                {
                    BindDescription();
                    await LoadCountry();
                    lnrTrackingInformation.Visibility = ViewStates.Visible;
                    lblProNumber.Text = "Tracking Details";
                }
                imgClosePage.Click += ImgClosePage_Click;
            }
            catch
            {
                Alerts.HideBusyLoader();
                throw;
            }
        }

        /// <summary>
        /// Getting Current Location
        /// </summary>
        private async Task InitializeLocationManager()
        {
            try
            {
                response = objGPSServiceSettings.StartLocationUpdates(null);
                if (!string.IsNullOrEmpty(response) && !response.Equals("passive"))
                {
                    double currentLat = CommanUtil.currLat;//37.089984;//
                    double currentLong = CommanUtil.currLong;//-95.715063;//
                    if (currentLat != 0)
                    {
                        await ConvertLatLongToAddress(currentLat, currentLong);
                    }
                    else
                    {
                        Toast.MakeText(this, Constants.strLocation, ToastLength.Long).Show();
                    }
                }
                else
                {
                    txtCity.Text = string.Empty;
                    state = string.Empty;
                    country = string.Empty;
                    Toast.MakeText(this, Constants.strEnableTracking, ToastLength.Long).Show();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        ///  Convert LatLong To Address
        /// </summary>
        /// <param name="Lat"></param>
        /// <param name="Long"></param>
        /// <returns></returns>
        public async Task ConvertLatLongToAddress(double Lat, double Long)
        {
            try
            {
                if (!Utility.FnIsOnline(this))
                {
                    Alerts.HideBusyLoader();
                    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                var geocoder = new Geocoder(this);
                IList<Android.Locations.Address> addressList = await geocoder.GetFromLocationAsync(Lat, Long, 10);
                if (addressList != null && addressList.Count > 0)
                {
                    Android.Locations.Address addressCurrent = addressList.FirstOrDefault();
                    if (addressCurrent != null)
                    {
                        txtCity.Text = addressCurrent.Locality;
                        state = addressCurrent.AdminArea;
                        country = addressCurrent.CountryName;
                    }
                }
                else
                {
                    txtCity.Text = string.Empty;
                    state = string.Empty;
                    country = string.Empty;
                    Toast.MakeText(this, Constants.strLocation, ToastLength.Long).Show();
                }
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
            }
        }

        private void ImgClosePage_Click(object sender, EventArgs e)
        {
            Finish();
        }

        /// <summary>
        /// Bind Description
        /// </summary>
        private void BindDescription()
        {
            try
            {
                ArrayAdapter adapter = Utility.DescriptionAdapter(this);
                adapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
                spinnerDescription.Adapter = adapter;
                spinnerDescription.ItemSelected += SpinnerDescription_ItemSelected;
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
            }
        }

        /// <summary>
        /// Get The Shipment Detail
        /// </summary>
        public async Task GetShipmentDetail()
        {
            try
            {
                string compositeKey, strToken, methodName = string.Empty;
                ServiceHelper objServicehelper = null;
                JObject jobject = null;
                compositeKey = CommanUtil.CompositeKey(lstShipmentDetail.ClientID, lstShipmentDetail.LocID, lstShipmentDetail.BolNum);
                objServicehelper = new ServiceHelper();
                // create json object that holds the api values
                //Method Name
                strToken = CommanUtil.tokenNo;
                methodName = APIMethods.shipmentDetails + "/" + lstShipmentDetail.ClientID + "|" + lstShipmentDetail.BolNum;
                lstShipmentDetail = null;
                Alerts.showBusyLoader(this);
                //Get the Shipments
                string strResponse = await objServicehelper.GetRequest(strToken, methodName, true);
                if (strResponse != null)
                {
                    Alerts.HideBusyLoader();
                    jobject = JObject.Parse(strResponse);
                    if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
                    {
                        lstShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(strResponse);
                        BindTrackingInfo(lstShipmentDetail);
                    }
                    else
                    {
                        Alerts.HideBusyLoader();
                        //Print Message
                        Toast.MakeText(this, Convert.ToString(jobject[Constants.strErrorMessage]), ToastLength.Long).Show();
                        //Post Error Logger Request 
                        Utility.ErrorLog(lstShipmentDetail.BolNum, Convert.ToString(jobject[Constants.strErrorMessage]), strToken, this);
                    }
                }
            }
            catch
            {
                Alerts.HideBusyLoader();
                throw;
            }

        }

        /// <summary>
        /// Save Tracking Information
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void BtnSaveTrackInfo_Click(object sender, EventArgs e)
        {
            try
            {
                if (CommanUtil.IsTimeOut())
                {
                    if (!string.IsNullOrEmpty(txtCity.Text))
                    {
                        TrackId = CommanUtil.CompositeKey(lstShipmentDetail.ClientID, lstShipmentDetail.LocID, lstShipmentDetail.BolNum);
                        if (showDescriptionText == true)
                        {
                            if (string.IsNullOrEmpty(txtTrackDescription.Text))
                            {
                                Toast.MakeText(this, Constants.strTrackingDes, ToastLength.Short).Show();
                                return;
                            }
                            else
                            {
                                trackingDescription = txtTrackDescription.Text;
                            }
                        }
                        else
                        {
                            if (Convert.ToString(spinnerDescription.SelectedItem) == Constants.strDescriptionDefaultText)
                            {
                                Toast.MakeText(this, Constants.strSelectDescription, ToastLength.Short).Show();
                                return;
                            }
                            else
                            {
                                trackingDescription = Convert.ToString(spinnerDescription.SelectedItem);
                            }
                        }
                        btnSaveTrackInfo.Enabled = false;
                        string methodURI = APIMethods.shipmentDetails + "/" + TrackId + "/" + APIMethods.tracking;
                        //ratePayload = GetRatePayload();
                        string token = CommanUtil.tokenNo;
                        Alerts.showBusyLoader(this);
                        ServiceHelper objServiceHelper = new ServiceHelper();
                        var Result = await objServiceHelper.PostRequestJson(GetTrackingPayload(), methodURI, token, true);
                        Alerts.HideBusyLoader();
                        if (Result != null)
                        {
                            await ResetTrackingInfoScreen();
                        }
                        else
                        {
                            Toast.MakeText(this, Constants.strTrackingError, ToastLength.Short).Show();
                            StartActivity(typeof(HomeActivity));
                            txtProNumber.Text = string.Empty;
                            txtCity.Text = string.Empty;
                        }
                        btnSaveTrackInfo.Enabled = true;
                    }
                    else
                    {
                        Toast.MakeText(this, Constants.enterCity, ToastLength.Long).Show();
                    }
                }
                else
                {
                    Utility.ExpireSession(this);
                }
            }
            catch (Exception ex)
            {
                Alerts.HideBusyLoader();
                Utility.ErrorLog(Constants.strEquipment, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strTrackingError, ToastLength.Short).Show();
            }
        }
        /// <summary>
        /// Setting time in the time textview 
        /// </summary>
        public void SetTime()
        {
            int hour = 0;
            if (DateTime.Now.Hour < 12)
            {
                AMPM = " AM";
                hour = DateTime.Now.Hour;
            }
            else
            {
                AMPM = " PM";
                hour = DateTime.Now.Hour - 12;
            }
            txtActivityTime.Text = hour.ToString() + ":" + DateTime.Now.Minute.ToString() + " " + AMPM;
        }

        /// <summary>
        /// Reset Tracking Informations
        /// </summary>
        private async Task ResetTrackingInfoScreen()
        {
            try
            {
                txtActivityDate.Text = DateTime.Now.ToShortDateString();
                SetTime();
                txtProNumber.Text = string.Empty;
                txtCity.Text = string.Empty;
                BindTrackingInfo(lstShipmentDetail);
                BindDescription();
                await InitializeLocationManager();
                await GetShipmentDetail();
                await LoadCountry();
            }
            catch (Exception ex)
            {
                Alerts.HideBusyLoader();
                Utility.ErrorLog(Constants.strEquipment, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strTrackingError, ToastLength.Short).Show();
            }
        }

        /// <summary>
        /// Creating Tracking Payload for posting data in API
        /// </summary>
        /// <returns></returns>
        public string GetTrackingPayload()
        {
            try
            {
                string payload_str = string.Empty;
                activityDate = new string[2];
                lstTrackDescVal = CommanUtil.TrackingDescList();
                if (txtActivityDate.Text != "")
                {
                    string ActivityDate = Convert.ToDateTime(txtActivityDate.Text).ToString("MM/dd/yyyy");
                    activityDate = CommanUtil.FormatDate(ActivityDate);
                    newActivityDate = activityDate[2] + "-" + activityDate[0] + "-" + activityDate[1];
                }

                string activityDateTime = newActivityDate + " " + txtActivityTime.Text;

                payload_str = "{"
                                + "\"ProNumber\":" + "\"" + txtProNumber.Text + "\","
                                + "\"ActivityDate\":" + "\"" + activityDateTime + "\","
                                + "\"ActivityCode\":" + "\"" + lstTrackDescVal[spinnerDescription.SelectedItemPosition].value + "\","
                                + "\"ActivityDescr\":" + "\"" + trackingDescription + "\","
                                + "\"City\":" + "\"" + txtCity.Text + "\","
                                + "\"State\":" + "\"" + lstStateCodes[spinnerState.SelectedItemPosition] + "\","
                                + "\"Country\":" + "\"" + lstCountryCodes[spinnerCountry.SelectedItemPosition] + "\""
                                +
                                "}";

                return payload_str;
            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// SpinnerDescription_ItemSelected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SpinnerDescription_ItemSelected(object sender, AdapterView.ItemSelectedEventArgs e)
        {
            try
            {
                Android.Graphics.Color brownColor = new Android.Graphics.Color(224, 223, 223);
                Android.Graphics.Color whiteColor = new Android.Graphics.Color(255, 255, 255);
                lnrEnterDesc.SetBackgroundColor(brownColor);
                relativeLayoutSave.SetBackgroundColor(whiteColor);
                lnrTrackLbl.SetBackgroundColor(brownColor);
                lnrDetailHeading.SetBackgroundColor(whiteColor);
                linearLayoutTrackDetails.SetBackgroundColor(brownColor);

                selectedVal = spinnerDescription.SelectedItem.ToString();

                if (selectedVal == Constants.trackExc || selectedVal == Constants.trackOther)
                {
                    lnrEnterDesc.Visibility = ViewStates.Visible;
                    showDescriptionText = true;
                }
                else
                {
                    lnrEnterDesc.Visibility = ViewStates.Gone;
                    showDescriptionText = false;
                }
            }
            catch
            {
                Alerts.HideBusyLoader();
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Binding Tracking Information
        /// </summary>
        /// <param name="lstShipmentDetail"></param>
        public void BindTrackingInfo(CarrierShipmentDetails lstShipmentDetail)
        {
            try
            {
                if (lstShipmentDetail != null)
                {
                    objTrackDetailsAdapter = null;
                    txtProNumber.Text = lstShipmentDetail.ProNum;
                   
                    if (lstShipmentDetail.ViewAs.ToUpper() == Constants.strCarrier)
                    {
                        lnrTrackingInformation.Visibility = ViewStates.Visible;
                    }
                    else
                    {
                        lnrTrackingInformation.Visibility = ViewStates.Gone;
                    }
                    lstVWTrackingInfo1 = null;
                    lstVWTrackingInfo1 = new ListView(this);
                    if (lstShipmentDetail.TrackDetails != null)
                    {
                        lstTrackDetail = null;
                        lstTrackDetail = lstShipmentDetail.TrackDetails;
                    }
                    else
                    {
                        lstTrackDetail = new List<TrackDetail>();
                    }
                    objTrackDetailsAdapter = new TrackDetailsAdapter(this, lstTrackDetail);
                    lstVWTrackingInfo.Adapter = objTrackDetailsAdapter;
                    var layoutParams = lstVWTrackingInfo;
                    var param = layoutParams.LayoutParameters;
                    param.Height = PixelsToDp(35 * (lstTrackDetail.Count));
                    int childCount = lstVWTrackingInfo.ChildCount;
                    lstVWTrackingInfo.LayoutParameters = new LinearLayout.LayoutParams(100, 100);
                    lstVWTrackingInfo1.Adapter = objTrackDetailsAdapter;
                    linearLayoutTrackDetails.RemoveAllViews();
                    for (int indexTracking = 0; indexTracking < lstVWTrackingInfo1.Count; indexTracking++)
                    {
                        View viewTracking = lstVWTrackingInfo1.Adapter.GetView(indexTracking, null, null);
                        linearLayoutTrackDetails.AddView(viewTracking);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Pixels to Dp conversion
        /// </summary>
        /// <param name="pixels"></param>
        /// <returns></returns>
        private int PixelsToDp(int pixels)
        {
            try
            {
                return (int)TypedValue.ApplyDimension(ComplexUnitType.Dip, pixels, Resources.DisplayMetrics);
            }
            catch
            {
                return 0;
            }
        }

        /// <summary>
        /// Load Country Details
        /// </summary>
        public async Task LoadCountry()
        {
            try
            {
                lstCountryDetails = await Utility.GetCountryDetails(this);
                if (lstCountryDetails != null && lstCountryDetails.Count > 0)
                {
                    lstCountries = new List<string>();
                    lstCountryCodes = new List<string>();
                    foreach (CountryDetails countryDetails in lstCountryDetails)
                    {
                        lstCountries.Add(countryDetails.Name);
                        lstCountryCodes.Add(countryDetails.Code);
                    }
                    if (!string.IsNullOrEmpty(country))
                    {
                        countryName = lstCountries.Where(x => x.Equals(country.ToUpper())).FirstOrDefault();
                    }
                    else
                    {
                        countryName = lstCountries.Where(x => x.Equals(Constants.strDefaultState)).FirstOrDefault();
                    }
                    if (string.IsNullOrEmpty(countryName))
                    {
                        countryName = Constants.strDefaultState;
                    }
                    adapter = new ArrayAdapter(this, Resource.Drawable.SpinnerCustomDesign, lstCountries);
                    adapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
                    spinnerCountry.Adapter = adapter;
                    for (int i = 0; i < spinnerCountry.Count; i++)
                    {
                        if (spinnerCountry.GetItemAtPosition(i).Equals(countryName.ToUpper()))
                        {
                            spinnerCountry.SetSelection(i);
                        }
                    }
                    spinnerCountry.ItemSelected += SpinnerCountry_ItemSelected;
                }
                else
                {
                    Toast.MakeText(this, Constants.strUnableToConnect, ToastLength.Long).Show();
                }
            }
            catch
            {
                Alerts.HideBusyLoader();
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// SpinnerCountry_ItemSelected Country Selected Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SpinnerCountry_ItemSelected(object sender, AdapterView.ItemSelectedEventArgs e)
        {
            try
            {
                lstStates = new List<string>();
                lstStateCodes = new List<string>();
                for (int indexCountry = 0; indexCountry < spinnerCountry.Count; indexCountry++)
                {
                    if (spinnerCountry.SelectedItem.Equals(Convert.ToString(lstCountryDetails[indexCountry].Name.ToUpper())))
                    {
                        lstStateDetails = lstCountryDetails[indexCountry].States;
                    }
                }
                foreach (StateDetails stateDetails in lstStateDetails)
                {
                    lstStateCodes.Add(stateDetails.Code);
                    lstStates.Add(stateDetails.Name);
                }
                ArrayAdapter adapter = new ArrayAdapter(this, Resource.Drawable.SpinnerCustomDesign, lstStates);
                adapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
                spinnerState.Adapter = adapter;
                if (!string.IsNullOrEmpty(state))
                {
                    if (lstStateCodes != null && lstStateCodes.Count > 0)
                    {
                        for (int indexState = 0; indexState < spinnerState.Count; indexState++)
                        {
                            if (state.ToUpper().Equals(Convert.ToString(lstStateCodes[indexState].ToUpper())))
                            {
                                spinnerState.SetSelection(indexState);
                            }
                            else if (state.ToUpper().Equals(Convert.ToString(lstStates[indexState].ToUpper())))
                            {
                                spinnerState.SetSelection(indexState);
                            }
                        }
                    }
                }
            }
            catch
            {
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// ActivityTime
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ActivityTime(object sender, TimePickerDialog.TimeSetEventArgs e)
        {
            try
            {
                int hour = 0;
                AMPM = Utility.CheckAMPM(e);

                if (e.HourOfDay < 12)
                {
                    hour = e.HourOfDay;
                }
                else
                {
                    hour = e.HourOfDay - 12;
                }

                txtActivityTime.Text = hour.ToString() + ":" + e.Minute.ToString() + " " + AMPM;
            }
            catch
            {
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// ActivityDate
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ActivityDate(object sender, DatePickerDialog.DateSetEventArgs e)
        {
            try
            {
                txtActivityDate.Text = e.Date.ToShortDateString();
            }
            catch
            {
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }
    }
}