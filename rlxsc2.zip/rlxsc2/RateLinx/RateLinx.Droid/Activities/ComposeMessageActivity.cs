using System;
using System.Collections.Generic;
using System.Linq;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Views;
using Android.Widget;
using JavaFile = Java.IO.File;
using URI = Android.Net;
using RateLinx.Helper;
using System.Threading.Tasks;
using RateLinx.APIs;
using Newtonsoft.Json.Linq;
using RateLinx.Droid.Utilities;
using Newtonsoft.Json;
using RateLinx.Models;
using RateLinx.Droid.Adapters;
using RateLinx.Droid.FileHelper;

namespace RateLinx.Droid.Activities
{
    /// <summary>
    /// Meta tag of the Activity
    /// </summary>
    [Activity(Label = "RateLinx", Icon = "@drawable/icon", Theme = "@style/Theme.AppCompat.NoActionBar")]
    public class ComposeMessageActivity : Activity
    {
        #region Variables declaration 
        TextView txtFileName1, txtFileName2, txtFileName3;
        Button btnCancel, fileUpload1, fileUpload2, fileUpload3, btnSelectedItem, btnCompMsg;
        EditText edtTxtMessage, editTxtSubject;
        Intent imageIntent = null;
        ImageView imgCloseDialog;
        JavaFile file = null;
        string apiMethod = string.Empty;
        string fileUrl = string.Empty;
        string token = string.Empty;
        string[] fileUri = null;
        List<byte[]> listFileBytes = null;
        URI.Uri selectedURI = null;
        int btnClickEvent = 0;
        JObject jobject = null;
        Dialog dialog = null;
        AlertDialog.Builder alert = null;
        ServiceHelper objServiceHelper = null;
        CommanUtil objUtility = null;
        CarrierShipmentDetails lstShipmentDetail = null;
        List<AllowedConversationToList> AllowedConversationToList = null;
        CustomerComposeTo.AdapterCustomerComposeTo objComposeAdapter = null;
        List<CustomerConversationList> lstCustomerConversationList = null;
        List<ComposeMessage> lstConposeMsg = null;
        int itemCount = 0;
        ListView listViewSpinner = null;
        string jsonFileRequest = string.Empty;
        string jsonCharge = string.Empty;
        FileUploadHelper objFileHelper = null;
        Spinner spinnerTo = null;
        List<string> composeTo = null;
        string composeToJson = string.Empty;
        string strMessage = string.Empty;
        bool isValidated = true;
        #endregion

        /// <summary>
        /// On Load Method
        /// </summary>
        /// <param name="savedInstanceState"></param>
        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);
                SetContentView(Resource.Layout.ComposeMessageDialog);
                if (string.IsNullOrEmpty(CommanUtil.tokenNo))
                {
                    Utility.Logout(this);
                }
                this.Window.SetSoftInputMode(SoftInput.StateAlwaysHidden);  //Close keyboard on load
                //Finding controls from the layout and applying events to the required controls
                FnSetupControls();
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
                Finish();
            }
        }

        /// <summary>
        /// Finding controls from the layout and applying events to the required controls
        /// </summary>
        private void FnSetupControls()
        {
            try
            {
                imgCloseDialog = FindViewById<ImageView>(Resource.Id.imgCloseDialog);
                btnCancel = FindViewById<Button>(Resource.Id.btnCancel);
                fileUpload1 = FindViewById<Button>(Resource.Id.fileUpload1);
                fileUpload2 = FindViewById<Button>(Resource.Id.fileUpload2);
                fileUpload3 = FindViewById<Button>(Resource.Id.fileUpload3);
                btnCompMsg = FindViewById<Button>(Resource.Id.btnCompMsg);
                txtFileName1 = FindViewById<TextView>(Resource.Id.txtFileName1);
                txtFileName2 = FindViewById<TextView>(Resource.Id.txtFileName2);
                txtFileName3 = FindViewById<TextView>(Resource.Id.txtFileName3);
                edtTxtMessage = FindViewById<EditText>(Resource.Id.edtTxtMessage);
                editTxtSubject = FindViewById<EditText>(Resource.Id.editTxtSubject);
                spinnerTo = FindViewById<Spinner>(Resource.Id.spinnerTo);
                btnSelectedItem = FindViewById<Button>(Resource.Id.btnSelectedItem);
                //Controls Binding
                composeTo = new List<string>();
                lstConposeMsg = new List<ComposeMessage>();
                FnBindSpinner();
                //
                listFileBytes = new List<byte[]>();
                listFileBytes.Add(null);
                listFileBytes.Add(null);
                listFileBytes.Add(null);
                fileUri = new string[3];

                objUtility = new CommanUtil();
                fileUpload1.Click += delegate
                {
                    btnClickEvent = 1;
                    FnBrowseFile();
                };
                fileUpload2.Click += delegate
                {
                    btnClickEvent = 2;
                    FnBrowseFile();
                };
                fileUpload3.Click += delegate
                {
                    btnClickEvent = 3;
                    FnBrowseFile();
                };
                //Button Compose Message
                btnCompMsg.Click +=async delegate
                 {
                     if (CommanUtil.IsTimeOut())
                     {
                        await FnsaveComposeMessage();
                     }
                     else
                     {
                         Utility.ExpireSession(this);
                     }
                 };
                token = CommanUtil.tokenNo; //Token No
                imgCloseDialog.Click += ImgCloseDialog_Click;
                btnCancel.Click += BtnCancel_Click;
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
                throw;
            }
        }

        /// <summary>
        /// Close Dialog
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgCloseDialog_Click(object sender, EventArgs e)
        {
            Finish();
        }

        /// <summary>
        /// Call back method to get the selected file url from device
        /// </summary>
        /// <param name="requestCode"></param>
        /// <param name="resultCode"></param>
        /// <param name="data"></param>
        protected override void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            try
            {
                base.OnActivityResult(requestCode, resultCode, data);
                // User canceled
                if (resultCode == Result.Canceled)
                    return;
                if (resultCode == Result.Ok)
                {
                    byte[] selectedFile = null;
                    //Select File And File in Bytes
                    selectedURI = data.Data;
                    string filePath = FileUploadHelper.GetFilePath(selectedURI, this);
                    if (!string.IsNullOrEmpty(filePath))
                    {
                        file = new JavaFile(filePath);
                        selectedFile = FileUploadHelper.ConvertFileIntoByte(filePath);
                        //Print File name in textview And holding file in list
                        switch (btnClickEvent)
                        {
                            case 1:
                                txtFileName1.Text = FileUploadHelper.GetFileName(filePath);
                                fileUri[0] = filePath;
                                listFileBytes[0] = selectedFile;
                                break;
                            case 2:
                                txtFileName2.Text = FileUploadHelper.GetFileName(filePath);
                                fileUri[1] = filePath;
                                listFileBytes[1] = selectedFile;
                                break;
                            case 3:
                                txtFileName3.Text = FileUploadHelper.GetFileName(filePath);
                                fileUri[2] = filePath;
                                listFileBytes[2] = selectedFile;
                                break;
                        };
                    }
                    else
                    {
                        txtFileName3.Text = txtFileName2.Text = txtFileName1.Text = "";
                        Toast.MakeText(this, Constants.strErrorFile, ToastLength.Long).Show();
                    }

                }
            }
            catch (Exception ex)
            {
                txtFileName3.Text = txtFileName2.Text = txtFileName1.Text = "";
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorFile, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Compose Message
        /// </summary>
        private async Task FnsaveComposeMessage()
        {
            try
            {
                Alerts.showBusyLoader(this);
                isValidated = FnIsValidate(); //Validations 
                if (isValidated)
                {
                    //  
                    if (lstShipmentDetail.ViewAs == Constants.strCustomer && itemCount != 0)
                    {
                        foreach (AllowedConversationToList item in AllowedConversationToList.Where(m => m.Action.Equals(true)))
                        {
                            composeTo.Add(item.Key);
                        }
                    }
                    else
                    {
                        composeTo.RemoveAt(0);
                        composeTo.Add(AllowedConversationToList[0].Key);
                    }
                    composeToJson = JsonConvert.SerializeObject(composeTo);
                    await FnSaveFiles();
                }
                else
                {
                    Toast.MakeText(this, strMessage, ToastLength.Long).Show();
                }
                Alerts.HideBusyLoader();
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
                Alerts.HideBusyLoader();
            }
        }

        /// <summary>
        /// Validate Required Fields
        /// </summary>
        /// <returns></returns>
        private bool FnIsValidate()
        {
            isValidated = true;
            if (lstShipmentDetail.ViewAs == Constants.strCustomer && itemCount == 0)
            {
                strMessage = Constants.strBroadCastMsg;
                isValidated = false;
            }
            else if (string.IsNullOrEmpty(editTxtSubject.Text))
            {
                strMessage = Constants.strSubject;
                isValidated = false;
            }
            else if (string.IsNullOrEmpty(edtTxtMessage.Text))
            {
                strMessage = Constants.strMessage;
                isValidated = false;
            }
            return isValidated;
        }

        /// <summary>
        /// Save Files If Any File Selected 
        /// </summary>
        /// <returns></returns>
        private async Task FnSaveFiles()
        {
            try
            {
                if (listFileBytes != null)
                {
                    //File Will be upload
                    for (int fileIndex = 0; fileIndex < listFileBytes.Count; fileIndex++)
                    {
                        if (listFileBytes[fileIndex] != null)
                        {
                            file = new JavaFile(fileUri[fileIndex]);
                            string uploadResult = await UploadBitmapAsync(listFileBytes[fileIndex], file);
                            if (uploadResult != null)
                            {
                                jobject = JObject.Parse(uploadResult);
                                if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
                                {
                                    jsonFileRequest += FileUploadHelper.UploadsJsonRequest(uploadResult);
                                    jsonFileRequest += ",";
                                }
                                else
                                {
                                    Toast.MakeText(this, Convert.ToString(jobject[Constants.strErrorMessage]), ToastLength.Long).Show();
                                    Utility.ErrorLog(Constants.strComposeMessage, Convert.ToString(jobject[Constants.strErrorMessage]), token, this);
                                }
                            }
                            else
                            {
                                Toast.MakeText(this, Constants.strNoFile, ToastLength.Long).Show();
                            }
                        }
                    }
                    //Save Compose File And Data
                    await FnsaveComposeData();
                }
                else
                {
                    //Save Compose File And Data
                    await FnsaveComposeData();
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                throw;
            }
            finally
            {
                Alerts.HideBusyLoader();
            }
        }

        /// <summary>
        /// File upload
        /// </summary>
        /// <param name="bytes">File will be in bytes</param>
        /// <param name="files">file Type</param>
        /// <returns></returns>
        public async Task<string> UploadBitmapAsync(byte[] bytes, JavaFile files)
        {
            try
            {
                objFileHelper = new FileUploadHelper();
                apiMethod = APIMethods.composeDocs;
                var response = await objFileHelper.PostFiles(bytes, files, apiMethod, token, true);
                return response;
            }
            catch
            {
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
                Alerts.HideBusyLoader();
                return null;
            }
        }

        /// <summary>
        /// Compose Selected Details
        /// </summary>
        /// <returns></returns>
        private async Task FnsaveComposeData()
        {
            try
            {
                objServiceHelper = new ServiceHelper();
                apiMethod = APIMethods.shipmentDetails + "/" + lstShipmentDetail.ClientID + "|" + lstShipmentDetail.LocID + "|" + lstShipmentDetail.BolNum + "/" + APIMethods.msg;
                string requestBody = "{" + "\"ReplyToID\":" + "\"0\"" + ",";
                requestBody += "\"To\":" + composeToJson + ",";
                requestBody += "\"Subject\":" + "\"" + editTxtSubject.Text + "\"" + ",";
                requestBody += "\"Message\":" + "\"" + edtTxtMessage.Text + "\"" + ",";
                requestBody += "\"Files\":[" + jsonFileRequest + "]";
                requestBody += "}";

                var response = await objServiceHelper.PostRequestJson(requestBody, apiMethod, token, true);
                if (response != null)
                {
                    lstConposeMsg = (List<ComposeMessage>)JsonConvert.DeserializeObject(response, typeof(List<ComposeMessage>));
                    FnResetControl();
                    if (!string.IsNullOrEmpty(lstConposeMsg[0].ErrorMessage))
                    {
                        Toast.MakeText(this, Convert.ToString(jobject[Constants.strErrorMessage]), ToastLength.Long).Show();
                        Utility.ErrorLog(Constants.strComposeMessage, Convert.ToString(jobject[Constants.strErrorMessage]), token, this);
                    }
                    else
                    {
                        string value = lstShipmentDetail.ClientID + "|" + lstShipmentDetail.BolNum + "|" + "";
                        CommanUtil.isReply = true;
                        Intent objIntent = Utility.RedirectTo(this, typeof(ShipmentsDetailedActivity), "compositeKey", value);
                        this.StartActivity(objIntent);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
                throw;
            }
            finally
            {
                Alerts.HideBusyLoader();
            }
        }

        /// <summary>
        /// Reset Controls
        /// </summary>
        private void FnResetControl()
        {
            edtTxtMessage.Text = "";
            editTxtSubject.Text = "";
            txtFileName1.Text = "";
            txtFileName2.Text = "";
            txtFileName3.Text = "";
            if (lstShipmentDetail.ViewAs == Constants.strCustomer)
            {
                //Reset CheckBox
                foreach (var item in AllowedConversationToList)
                {
                    item.Action = false;
                }
                btnSelectedItem.Text = Constants.strNoSelected;
            }
        }

        /// <summary>
        /// Finishing Activity on Cancel button click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnCancel_Click(object sender, EventArgs e)
        {
            Finish();
        }

        /// <summary>
        /// Function to browse File 
        /// </summary>
        private void FnBrowseFile()
        {
            try
            {
                imageIntent = new Intent(Intent.ActionPick, Android.Provider.MediaStore.Images.Media.ExternalContentUri);
                imageIntent.SetType("*/*");
                imageIntent.PutExtra("return-data", true);
                imageIntent.SetAction(Intent.ActionGetContent);
                StartActivityForResult(
                    Intent.CreateChooser(imageIntent, Constants.strSelectFile), 0);
            }
            catch
            {
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Dropdown Binding
        /// </summary>
        private void FnBindSpinner()
        {
            try
            {
                string shipmentDetails = string.Empty;
                shipmentDetails = Utility.sharedPreferences.GetString(Constants.shipmentDetails, null);
                lstShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(shipmentDetails);
                AllowedConversationToList = lstShipmentDetail.AllowedConversationToList;
                //Carrier
                if (lstShipmentDetail.ViewAs == Constants.strCarrier)
                {
                    spinnerTo.Visibility = ViewStates.Visible;
                    btnSelectedItem.Visibility = ViewStates.Gone;
                    composeTo.Add(AllowedConversationToList[0].Value);
                    ArrayAdapter spinnerArrayAdapter = new ArrayAdapter<string>(this, Resource.Drawable.SpinnerCustomDesign, composeTo);
                    spinnerArrayAdapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
                    spinnerTo.Adapter = spinnerArrayAdapter;
                }
                else //Customer Login
                {
                    spinnerTo.Visibility = ViewStates.Gone;
                    btnSelectedItem.Visibility = ViewStates.Visible;
                    //Open Dialog for multiple selection
                    btnSelectedItem.Click += delegate
                    {
                        FnComposeTo();
                    };
                }
            }
            catch
            {
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Compose To multiple data binding while Customer is Looged in
        /// </summary>
        private void FnComposeTo()
        {
            try
            {
                //Remove Old Data from list or object
                lstCustomerConversationList = null;
                listViewSpinner = null;
                lstCustomerConversationList = new List<CustomerConversationList>();
                CustomerConversationList objCustConv = null;
                //Add Current data in toporary List for modification
                foreach (var item in AllowedConversationToList)
                {
                    objCustConv = new CustomerConversationList();
                    objCustConv.Key = item.Key;
                    objCustConv.Value = item.Value;
                    objCustConv.Action = item.Action;
                    lstCustomerConversationList.Add(objCustConv);
                }
                //Create Dialog
                alert = new AlertDialog.Builder(this);
                alert.SetView(Resource.Layout.ComposeToDialog);
                dialog = alert.Create();
                dialog.Show();
                Button btnCancel = dialog.FindViewById<Button>(Resource.Id.btnCancel);
                Button btnOk = dialog.FindViewById<Button>(Resource.Id.btnOk);
                //Binding of List Vew 
                listViewSpinner = dialog.FindViewById<ListView>(Resource.Id.listViewSpinner);
                objComposeAdapter = new CustomerComposeTo.AdapterCustomerComposeTo(this, lstCustomerConversationList);
                listViewSpinner.Adapter = objComposeAdapter;
                //Cancel Button Click
                btnCancel.Click += delegate
                {
                    dialog.Hide();//hide Dialog
                };
                dialog.SetCancelable(false);
                //If Click on Ok
                btnOk.Click += delegate
                {
                    //Remove Old Data from AllowedConversationToList
                    AllowedConversationToList objAllowedConv = null;
                    AllowedConversationToList = null;
                    AllowedConversationToList = new List<AllowedConversationToList>();
                    //Add New Modified Recodrs from selected list
                    foreach (var item in lstCustomerConversationList)
                    {
                        objAllowedConv = new AllowedConversationToList();
                        objAllowedConv.Key = item.Key;
                        objAllowedConv.Value = item.Value;
                        objAllowedConv.Action = item.Action;
                        AllowedConversationToList.Add(objAllowedConv);
                    }
                    //Get Count Of Selected Item
                    itemCount = AllowedConversationToList.Count(m => m.Action == true);
                    if (itemCount != 1)
                    {
                        btnSelectedItem.Text = itemCount + " Selected";
                    }
                    else
                    {
                        //If Selected Item is One Then Print selected Name on Button
                        btnSelectedItem.Text = AllowedConversationToList.Where(m => m.Action == true).Select(m => m.Value).FirstOrDefault();
                    }
                    dialog.Hide();//Hide Dialog
                };
            }
            catch
            {
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

    }
}