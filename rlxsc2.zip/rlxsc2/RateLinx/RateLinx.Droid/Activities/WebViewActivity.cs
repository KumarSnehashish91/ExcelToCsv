using Android.App;
using Android.Content;
using Android.OS;
using Android.Views;
using Android.Webkit;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;
using Android.Widget;
using AndroidNetUri = Android.Net.Uri;
using Android.Graphics;
using Android.Content.PM;

namespace RateLinx.Droid.Activities
{
    /// <summary>
    /// Meta Tag For File View
    /// </summary>
    [Activity(Label = "WebViewActivity", Theme = "@style/Theme.AppCompat.NoActionBar", ConfigurationChanges = ConfigChanges.Orientation | ConfigChanges.ScreenSize)]
    public class WebViewActivity : HeaderActivity
    {
        #region  Declaration of controls
        string fileURL = string.Empty;
        string html = string.Empty;
        WebView LocalWebView = null;
        TextView txtViewHome;
        #endregion

        /// <summary>
        /// File View Activity
        /// </summary>
        /// <param name="savedInstanceState"></param>
        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);
                if (string.IsNullOrEmpty(CommanUtil.tokenNo))
                {
                    Utility.Logout(this);
                }
                //Remove Header Title
                RequestWindowFeature(WindowFeatures.NoTitle);
                SetContentView(Resource.Layout.WebView);
                //Test Internet Connection
                if (!Utility.FnIsOnline(this))
                {
                    Alerts.HideBusyLoader();
                    Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                    return;
                }
                //Find controls Id's
                LinearLayout lnrLayoutBackIcon = FindViewById<LinearLayout>(Resource.Id.lnrLayoutBackIcon);
                ImageView imgBackIcon = FindViewById<ImageView>(Resource.Id.imgBackIcon);
                txtViewHome= FindViewById<TextView>(Resource.Id.txtViewHome);
                imgBackIcon.Click += ImgBackIcon_Click;
                lnrLayoutBackIcon.Click += LnrLayoutBackIcon_Click;
                if(Constants.uploadType=="BOL")
                {
                    txtViewHome.Text = "Print Bol Report";
                }
                LocalWebView = FindViewById<WebView>(Resource.Id.LocalWebView);
                string intentURL = Intent.GetStringExtra("URL");
                if(intentURL.Contains(".PDF") || intentURL.Contains(".pdf") || intentURL.Contains(".xls") || intentURL.Contains(".xlsx"))
                {
                    fileURL = "http://docs.google.com/gview?embedded=true&url=" + Intent.GetStringExtra("URL");
                    LocalWebView.SetInitialScale(100);
                }
                else
                {
                    fileURL = intentURL;
                    LocalWebView.SetInitialScale(50);
                }
                LocalWebView.SetWebViewClient(new MyWebClient(this)); // stops request going to Web Browser
                //LocalWebView.FitsSystemWindows = true;
                LocalWebView.Settings.JavaScriptEnabled = true;
                LocalWebView.SetFitsSystemWindows(true);
                LocalWebView.Settings.SetSupportZoom(true);
                
                LocalWebView.Settings.BuiltInZoomControls = true;
                LocalWebView.LoadUrl(fileURL);
            }
            catch
            {
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Back to activity
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LnrLayoutBackIcon_Click(object sender, System.EventArgs e)
        {
            Finish();
        }

        /// <summary>
        /// Back to activity
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgBackIcon_Click(object sender, System.EventArgs e)
        {
            Finish();
        }
    }

    /// <summary>
    /// MyWebClient
    /// </summary>
    public class MyWebClient : WebViewClient
    {
        Activity context;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        public MyWebClient(Activity context)
        {
            this.context = context;
            Alerts.showBusyLoader(context);
        }


        /// <summary>
        /// OnPageStarted
        /// </summary>
        /// <param name="view"></param>
        /// <param name="url"></param>
        /// <param name="favicon"></param>
        public override void OnPageStarted(WebView view, string url, Bitmap favicon)
        {
            base.OnPageStarted(view, url, favicon);
        }

        /// <summary>
        /// LoadResource
        /// </summary>
        /// <param name="view"></param>
        /// <param name="url"></param>
        public override void OnLoadResource(WebView view, string url)
        {
            base.OnLoadResource(view, url);
        }

        /// <summary>
        /// OnPageFinished
        /// </summary>
        /// <param name="view"></param>
        /// <param name="url"></param>
        public override void OnPageFinished(WebView view, string url)
        {
            base.OnPageFinished(view, url);
            Alerts.HideBusyLoader();
        }


    }
}