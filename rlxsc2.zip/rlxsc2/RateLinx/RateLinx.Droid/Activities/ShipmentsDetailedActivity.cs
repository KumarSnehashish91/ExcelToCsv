using System;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Views;
using Android.Widget;
using RateLinx.Droid.Utilities;
using RateLinx.Droid.Fragments;
using V4App = Android.Support.V4.App;
using Newtonsoft.Json.Linq;
using RateLinx.Helper;
using RateLinx.APIs;
using System.Threading.Tasks;
using RateLinx.Models;
using Newtonsoft.Json;
using Android.Support.V4.Content;
using Android;
using Android.Content.PM;

namespace RateLinx.Droid.Activities
{
    /// <summary>
    /// Shipment Detailed Activity
    /// </summary>
    [Activity(Label = "ShipmentsDetailedActivity", Theme = "@style/Theme.AppCompat.NoActionBar", ConfigurationChanges = ConfigChanges.Orientation | ConfigChanges.ScreenSize)]
    public class ShipmentsDetailedActivity : CompactActivity
    {

        #region Global used controls
        TextView txtViewBolNo, txtFilterQuery;
        string strToken = string.Empty;
        string refresh = string.Empty;
        string[] compositeKey = null;
        ImageView ImgInvoice, ImgTracking, ImgRefreshIcon, ImgPrintBol;
        CarrierShipmentDetails lstShipmentDetail = null;
        Utility objUtility = null;
        Intent slideactivity = null;
        Bundle bndlanimation = null;
        JObject jobject = null;
        ServiceHelper objServicehelper = null;
        string methodName = string.Empty;
        Dialog dialog = null;
        Button btnConfirm, btnCancel;
        TextView txtMessage, txtViewClose, txtDialogHeader, txtReasonlbl, txtAcceptDeny;
        LinearLayout lntlayoutReason;
        ImageView imgheader, imgheaderError;

        readonly string[] PermissionsLocation =
                        {
         Manifest.Permission.AccessCoarseLocation,
         Manifest.Permission.AccessFineLocation
        };
        #endregion

        /// <summary>
        /// On load event of Shipment Detailed Activity
        /// </summary>
        /// <param name="savedInstanceState"></param>
        protected override async void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);
                // Set our view from the "Startup Page" layout resource
                SetContentView(Resource.Layout.ShipmentsDetailedlayout);
                if (string.IsNullOrEmpty(CommanUtil.tokenNo))
                {
                    Utility.Logout(this);
                }
                FindControls();
                await BindShipments(refresh);
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                //Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
                //Finish();
            }
        }       

        /// <summary>
        /// Get our UI controls from the loaded layout:
        /// </summary>
        private void FindControls()
        {
            TextView txtCopyRight = FindViewById<TextView>(Resource.Id.txtCopyRight);
            ImgInvoice = FindViewById<ImageView>(Resource.Id.ImgInvoice);
            ImgTracking = FindViewById<ImageView>(Resource.Id.ImgTracking);
            ImgPrintBol = FindViewById<ImageView>(Resource.Id.ImgPrintBol);
            txtFilterQuery = FindViewById<TextView>(Resource.Id.txtFilterQuery);
            txtViewBolNo = FindViewById<TextView>(Resource.Id.txtViewBolNo);
            LinearLayout lnrLayoutBackIcon = FindViewById<LinearLayout>(Resource.Id.lnrLayoutBackIcon);
            ImageView imgBackIcon = FindViewById<ImageView>(Resource.Id.imgBackIcon);
            ImgRefreshIcon = FindViewById<ImageView>(Resource.Id.ImgRefreshIcon);
            //Controls Events
            ImgInvoice.Click += ImgInvoice_Click;
            ImgTracking.Click += ImgTracking_Click;
            ImgPrintBol.Click += ImgPrintBol_Click;
            txtCopyRight.Text = CommanUtil.PrintYear();
            imgBackIcon.Click += ImgBackIcon_Click;
            lnrLayoutBackIcon.Click += LnrLayoutBackIcon_Click;
            strToken = CommanUtil.tokenNo;

        }

        /// <summary>
        /// Get Bol NO
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ImgPrintBol_Click(object sender, EventArgs e)
        {
            try
            {
                if (CommanUtil.IsTimeOut())
                {
                    objServicehelper = new ServiceHelper();
                    // create json object that holds the api values
                    //Method Name
                    string shipmentId = CommanUtil.CompositeKey(lstShipmentDetail.ClientID, lstShipmentDetail.LocID, lstShipmentDetail.BolNum);
                    methodName = APIMethods.shipmentDetails + "/" + shipmentId + "/" + APIMethods.printBoL;
                    Alerts.showBusyLoader(this);
                    if (!Utility.FnIsOnline(this))
                    {
                        Alerts.HideBusyLoader();
                        Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                        return;
                    }
                    //Get the Shipments
                    var strResponse = await objServicehelper.GetRequest(strToken, methodName, true);
                    Alerts.HideBusyLoader();
                    if (strResponse != null)
                    {
                        jobject = JObject.Parse(strResponse);
                        if (string.IsNullOrEmpty(Convert.ToString(jobject["BOLError"])))
                        {
                            OpenBol(jobject);
                        }
                        else
                        {
                            Utility.ErrorLog(txtViewBolNo.Text, Constants.strPrintBol, strToken, this);
                            string message = Constants.strPrintError;
                            GetDialog();
                            txtDialogHeader.Text = Resources.GetString(Resource.String.ErrorAlert);
                            lntlayoutReason.Visibility = ViewStates.Gone;
                            txtMessage.Visibility = ViewStates.Visible;
                            btnConfirm.Visibility = ViewStates.Visible;
                            btnCancel.Visibility = ViewStates.Gone;
                            imgheader.Visibility = ViewStates.Gone;
                            imgheaderError.Visibility = ViewStates.Gone;
                            txtMessage.Text = message;
                            btnConfirm.Text = Constants.btnTextOk;
                            btnConfirm.Click += delegate
                            {
                                dialog.Hide();
                            };
                            //Redirect To login page 
                            txtViewClose.Click += delegate
                            {
                                dialog.Hide();
                            };
                            btnCancel.SetBackgroundColor(Android.Graphics.Color.White);
                        }
                        strResponse = null;
                    }
                }
                else
                {
                    Utility.ExpireSession(this);
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Print Bol NO
        /// </summary>
        /// <param name="jobject"></param>
        private void OpenBol(JObject jobject)
        {
            try
            {
                string BOLReport = Convert.ToString(jobject["BOLReport"]);
                Utility.ViewUploadedFile(BOLReport, this);
                Constants.uploadType = "BOL";
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Open Dialog
        /// </summary>
        public void GetDialog()
        {
            try
            {
                objUtility = new Utility();
                dialog = objUtility.ConfirmationAlert(this);//Generate Confirmation Alert Box
                btnConfirm = dialog.FindViewById<Button>(Resource.Id.btnYes);
                btnCancel = dialog.FindViewById<Button>(Resource.Id.btnNo);
                txtMessage = dialog.FindViewById<TextView>(Resource.Id.txtMessage);
                txtViewClose = dialog.FindViewById<TextView>(Resource.Id.txtViewClose);
                txtDialogHeader = dialog.FindViewById<TextView>(Resource.Id.txtDialogHeader);
                txtReasonlbl = dialog.FindViewById<TextView>(Resource.Id.txtReason);
                lntlayoutReason = dialog.FindViewById<LinearLayout>(Resource.Id.lntlayoutReason);
                imgheader = dialog.FindViewById<ImageView>(Resource.Id.imgheader);
                imgheaderError = dialog.FindViewById<ImageView>(Resource.Id.imgheaderError);
                txtAcceptDeny = dialog.FindViewById<EditText>(Resource.Id.txtEnterReason);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        ///  Tracking
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgTracking_Click(object sender, EventArgs e)
        {
            try
            {
                if (CommanUtil.IsTimeOut())
                {
                    if ((ContextCompat.CheckSelfPermission(this, Manifest.Permission.AccessFineLocation) == (int)Permission.Granted) &&
                (ContextCompat.CheckSelfPermission(this, Manifest.Permission.AccessCoarseLocation) == (int)Permission.Granted))
                    {
                        Utility.ActiveConversationHeader = 0;
                        slideactivity = new Intent(this, typeof(TrackingInfoActivity));
                        bndlanimation = ActivityOptions.MakeCustomAnimation(this, Resource.Animation.abc_slide_in_bottom, Resource.Animation.abc_slide_out_bottom).ToBundle();
                        StartActivity(slideactivity, bndlanimation);
                        slideactivity = null;
                        bndlanimation = null;
                    }
                    else
                    {
                        V4App.ActivityCompat.RequestPermissions(this, PermissionsLocation, 0);
                    }
                }
                else
                {
                    //Toekn Exired
                    Utility.ExpireSession(this);
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Invoic Tracking
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgInvoice_Click(object sender, EventArgs e)
        {
            try
            {
                if (CommanUtil.IsTimeOut())
                {
                    Utility.ActiveConversationHeader = 0;
                    slideactivity = new Intent(this, typeof(InvoiceActivity));
                    bndlanimation = ActivityOptions.MakeCustomAnimation(this, Resource.Animation.abc_slide_in_bottom, Resource.Animation.abc_slide_out_bottom).ToBundle();
                    StartActivity(slideactivity, bndlanimation);

                    slideactivity = null;
                    bndlanimation = null;
                }
                else
                {
                    //Toekn Exired
                    Utility.ExpireSession(this);
                }
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Redirecting To Required Page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LnrLayoutBackIcon_Click(object sender, EventArgs e)
        {
            try
            {
                Utility.ActiveConversationHeader = 0;
                RedirectURI();
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Back to home page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgBackIcon_Click(object sender, EventArgs e)
        {
            try
            {
                Utility.ActiveConversationHeader = 0;
                RedirectURI();
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Get the perticular shipment details
        /// </summary>
        /// <param name="refresh"></param>
        /// <returns></returns>
        public async Task BindShipments(string refresh)
        {
            try
            {
                if (CommanUtil.IsTimeOut())
                {
                    objUtility = new Utility();
                    //Show Loader
                    Alerts.showBusyLoader(this);

                    //When redirecting from other pages
                   string notification_compositekey = Utility.sharedPreferences.GetString("notification_compositekey", null);
                    if (!string.IsNullOrEmpty(notification_compositekey))
                    {
                        compositeKey = notification_compositekey.Split('|');
                        //Utility.sharedPreferences.Edit().Remove("notification_compositekey").Commit();
                    }
                    else
                    {
                        if (Intent.GetStringExtra("compositeKey") != null)
                        {
                            compositeKey = Intent.GetStringExtra("compositeKey").Split('|');
                        }
                        else if (!string.IsNullOrEmpty(CommanUtil.shipClientIdBolNo))
                        {
                            compositeKey = CommanUtil.shipClientIdBolNo.Split('|');
                        }
                    }
                    
                    txtViewBolNo.Text = compositeKey[1];
                    if (!string.IsNullOrEmpty(compositeKey[2]))
                    {
                        txtFilterQuery.Text = compositeKey[2];
                    }
                    else
                    {
                        txtFilterQuery.Text = "";
                    }
                    if (!Utility.FnIsOnline(this))
                    {
                        Alerts.HideBusyLoader();
                        Toast.MakeText(this, Constants.strNoInternet, ToastLength.Short).Show();
                        return;
                    }
                    //Method Name
                    methodName = APIMethods.shipmentDetails + "/" + compositeKey[0] + "|" + compositeKey[1];
                    Constants.methodNmaeForEquipmentScanning = methodName;
                    string response = await objUtility.BindShipmentDetail(methodName, this);
                    if (!string.IsNullOrEmpty(response))
                    {
                        lstShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(response);
                        ShowConditionalControls();
                        V4App.Fragment objFragment = new ShipmentDetailedFragment(this);
                        V4App.FragmentManager objFragmentManager = SupportFragmentManager;
                        V4App.FragmentTransaction objFragmentTrans = objFragmentManager.BeginTransaction();
                        objFragmentTrans.Add(Resource.Id.fragment_container, objFragment);
                        objFragmentTrans.Commit();

                    }
                    else
                    {
                        Toast.MakeText(this, Constants.strTimeOut, ToastLength.Short).Show();
                        //Finish();
                    }
                    Alerts.HideBusyLoader();
                }
                else
                {
                    //Toekn Exired
                    Utility.ExpireSession(this);
                }
            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
            }
            finally
            {
                Alerts.HideBusyLoader();
            }
        }

        /// <summary>
        /// Show Hide Invoice and Tracking icon
        /// </summary>
        private void ShowConditionalControls()
        {
            try
            {
                bool isShowCharges = Utility.sharedPreferences.GetBoolean("isShowCharges", true);

                if (lstShipmentDetail.CanAddTracking)
                {
                    ImgTracking.Visibility = ViewStates.Visible;

                }
                else
                {
                    ImgTracking.Visibility = ViewStates.Gone;
                }
                if (isShowCharges && lstShipmentDetail.CanInvoice)
                {
                    ImgInvoice.Visibility = ViewStates.Visible;
                }
                else
                {
                    ImgInvoice.Visibility = ViewStates.Gone;
                }
                if (lstShipmentDetail.ViewAs == Constants.strCustomer && lstShipmentDetail.Status == Constants.strClosed)
                {
                    ImgPrintBol.Visibility = ViewStates.Visible;
                }

            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Redirect To URI
        /// </summary>
        private void RedirectURI()
        {
            if (CommanUtil.IsTimeOut())
            {
                Utility.sharedPreferences.Edit().Remove(Constants.shipmentDetails).Commit();
                if (!string.IsNullOrEmpty(txtFilterQuery.Text))
                {
                    if (txtFilterQuery.Text == "2")
                    {
                        Intent.RemoveExtra("compositeKey");
                        //Finish();
                        var intent = new Intent(this, typeof(HomeActivity));
                        intent.SetFlags(ActivityFlags.ClearTop | ActivityFlags.ClearTask | ActivityFlags.NewTask);
                        StartActivity(intent);
                    }
                    else if (txtFilterQuery.Text == "#")
                    {
                        Finish();
                    }
                    else
                    {
                        Finish();
                        var intent = new Intent(this, typeof(HomeActivity));
                        intent.SetFlags(ActivityFlags.ClearTop | ActivityFlags.ClearTask | ActivityFlags.NewTask);
                        StartActivity(intent);
                    }
                }
                else
                {
                    Finish();
                }
            }
            else
            {
                Utility.ExpireSession(this);
            }
        }

        /// <summary>
        /// Clear shipment details data from local storage
        /// </summary>
        public override void OnBackPressed()
        {
            RedirectURI();
            base.OnBackPressed();
        }
    }
}