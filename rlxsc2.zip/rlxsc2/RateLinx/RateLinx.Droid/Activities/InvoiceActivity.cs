using System;
using System.Collections.Generic;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Views;
using Android.Widget;
using RateLinx.Droid.Utilities;
using Newtonsoft.Json;
using RateLinx.Models;
using RateLinx.Droid.Adapters;
using Android.Util;
using JavaFile = Java.IO.File;
using URI = Android.Net;
using RateLinx.Helper;
using System.Threading.Tasks;
using RateLinx.APIs;
using Newtonsoft.Json.Linq;
using RateLinx.Droid.FileHelper;
using Android.Support.V4.Content;
using Android;
using Android.Content.PM;
using Android.Support.V4.App;

namespace RateLinx.Droid.Activities
{
    /// <summary>
    /// InvoiceActivity 
    /// </summary>
    [Activity(Label = "RateLinx", Icon = "@drawable/icon", Theme = "@style/Theme.AppCompat.NoActionBar", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class InvoiceActivity : HeaderActivity
    {
        #region Global used variable
        ServiceHelper objServiceHelper = null;
        FileUploadHelper objUploadHelper = null;
        CommanUtil objUtility = null;
        CarrierShipmentDetails lstShipmentDetail = null;
        List<Charges> listCharges = new List<Charges>();
        FileListAdapter.FileListAdapterShipments FileListAdapter = null;
        InvoiceChargesAdapter.InvoiceChargesList invoiceChargesAdapter = null;
        ListView lstViewCharges, lstViewDocs = null;
        ImageView imgCros;
        TextView txtDialogHeader,
        txtComment, txtExtraCharge, txtFileName1, txtFileName2, txtFileName3,
        txtAmount, txtViewUploadHead = null;
        Button fileUpload1, fileUpload2, fileUpload3, btnAddCharge, btnCreateInvoice = null;
        Spinner spinnerCharge=null;
        LinearLayout lnrAddChargeHead, lnrAddChargeDetails, lnrLayoutUploads = null;
        Charges objlistCharges = null;
        List<ImageView> lstImageView = new List<ImageView>();
        List<LinearLayout> lstLinearCharges = new List<LinearLayout>();
        Intent imageIntent = null;
        JavaFile file = null;
        string apiMethod = string.Empty;
        List<string> objFileList = null;
        string fileUrl = string.Empty;
        string token = string.Empty;
        string[] fileUri = null;
        List<byte[]> listFileBytes = null;
        URI.Uri selectedURI = null;
        int btnClickEvent = 0;
        JObject jobject = null;
        Dialog dialog = null;
        Utility objUtil = null;
        string jsonFileRequest = string.Empty;
        string jsonCharge = string.Empty;

        readonly string[] PermissionsLocation =
                        {
         Manifest.Permission.WriteExternalStorage };
        #endregion

        /// <summary>
        /// Layout Get Event
        /// </summary>
        /// <param name="savedInstanceState"></param>
        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);
                SetContentView(Resource.Layout.Invoice);
                this.Window.SetSoftInputMode(SoftInput.StateAlwaysHidden);
                token = CommanUtil.tokenNo;
                if (string.IsNullOrEmpty(token))
                {
                    Utility.Logout(this);
                }
                FindControls();
                GetInvoiceDetails();
            }
            catch(Exception ex)
            {
                Alerts.HideBusyLoader();
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }
     
        /// <summary>
        /// Convert pixel to dp for dynamic listView height
        /// </summary>
        /// <param name="pixels"></param>
        /// <returns></returns>
        private int PixelsToDp(int pixels)
        {
            try
            {
                return (int)TypedValue.ApplyDimension(ComplexUnitType.Dip, pixels, Resources.DisplayMetrics);
            }
            catch
            {              
                return 0;
            }
        }

        /// <summary>
        /// Find Controls ID's From Layout
        /// </summary>
        private void FindControls()
        {
            try
            {
                #region Find controls
                txtDialogHeader = FindViewById<TextView>(Resource.Id.txtDialogHeader);
                imgCros = FindViewById<ImageView>(Resource.Id.imgCros);
                txtComment = FindViewById<TextView>(Resource.Id.txtComment);
                txtExtraCharge = FindViewById<TextView>(Resource.Id.txtExtraCharge);
                txtFileName1 = FindViewById<TextView>(Resource.Id.txtFileName1);
                txtFileName2 = FindViewById<TextView>(Resource.Id.txtFileName2);
                txtFileName3 = FindViewById<TextView>(Resource.Id.txtFileName3);
                txtViewUploadHead = FindViewById<TextView>(Resource.Id.txtViewUploadHead);
                txtAmount = FindViewById<TextView>(Resource.Id.txtAmount);
                fileUpload1 = FindViewById<Button>(Resource.Id.fileUpload1);
                fileUpload2 = FindViewById<Button>(Resource.Id.fileUpload2);
                fileUpload3 = FindViewById<Button>(Resource.Id.fileUpload3);
                btnAddCharge = FindViewById<Button>(Resource.Id.btnAddCharge);
                btnCreateInvoice = FindViewById<Button>(Resource.Id.btnCreateInvoice);
                spinnerCharge = FindViewById<Spinner>(Resource.Id.spinnerCharge); ;
                lnrAddChargeHead = FindViewById<LinearLayout>(Resource.Id.lnrAddChargeHead);
                lnrAddChargeDetails = FindViewById<LinearLayout>(Resource.Id.lnrAddChargeDetails);
                lnrLayoutUploads = FindViewById<LinearLayout>(Resource.Id.lnrLayoutUploads);
                lstViewCharges = FindViewById<ListView>(Resource.Id.lstViewCharges);
                lstViewDocs = FindViewById<ListView>(Resource.Id.lstViewDocs);
                #endregion
                imgCros.Click += ImgCros_Click;
                lstViewDocs.ItemClick += LstViewDocs_ItemClick;
                btnAddCharge.Click += BtnAddCharge_Click;
                lnrAddChargeHead.Visibility = ViewStates.Gone;
                lnrAddChargeDetails.Visibility = ViewStates.Gone;
                listFileBytes = new List<byte[]>();
                listFileBytes.Add(null);
                listFileBytes.Add(null);
                listFileBytes.Add(null);
                fileUri = new string[3];
                objUtility = new CommanUtil();
                fileUpload1.Click += delegate
                {
                    btnClickEvent = 1;
                    BrowseFile();
                };
                fileUpload2.Click += delegate
                {
                    btnClickEvent = 2;
                    BrowseFile();
                };
                fileUpload3.Click += delegate
                {
                    btnClickEvent = 3;
                    BrowseFile();
                };
                //Invoice Create Event
                btnCreateInvoice.Click += BtnCreateInvoice_Click;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Close Invoice Popup
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgCros_Click(object sender, EventArgs e)
        {
            Finish();
        }

        /// <summary>
        /// Call back method to get the selected file url from device
        /// </summary>
        /// <param name="requestCode"></param>
        /// <param name="resultCode"></param>
        /// <param name="data"></param>
        protected override void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            try
            {
                base.OnActivityResult(requestCode, resultCode, data);
                // User canceled
                if (resultCode == Result.Canceled)
                    return;
                if (resultCode == Result.Ok)
                {
                    byte[] selectedFile = null;
                    //Select File And File in Bytes
                    selectedURI = data.Data;
                    string filePath = FileUploadHelper.GetFilePath(selectedURI, this);
                    if (!String.IsNullOrEmpty(filePath))
                    {
                        file = new JavaFile(filePath);
                        selectedFile = FileUploadHelper.ConvertFileIntoByte(filePath);
                        //Print File name in textview And holding file in list
                        switch (btnClickEvent)
                        {
                            case 1:
                                txtFileName1.Text = FileUploadHelper.GetFileName(filePath);
                                fileUri[0] = filePath;
                                listFileBytes[0] = selectedFile;
                                break;
                            case 2:
                                txtFileName2.Text = FileUploadHelper.GetFileName(filePath);
                                fileUri[1] = filePath;
                                listFileBytes[1] = selectedFile;
                                break;
                            case 3:
                                txtFileName3.Text = FileUploadHelper.GetFileName(filePath);
                                fileUri[2] = filePath;
                                listFileBytes[2] = selectedFile;
                                break;
                        };
                    }
                    else
                    {
                        txtFileName3.Text = txtFileName2.Text = txtFileName1.Text = "";
                        Toast.MakeText(this, Constants.strErrorFile, ToastLength.Long).Show();
                    }

                }
            }
            catch
            {
                txtFileName3.Text = txtFileName2.Text = txtFileName1.Text = "";
                Toast.MakeText(this, Constants.strErrorFile, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Button Invoice Create Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnCreateInvoice_Click(object sender, EventArgs e)
        {
            try
            {
                if (CommanUtil.IsTimeOut())
                {
                    objUtil = new Utility();
                    double totalShipCost = 0;
                    double totalExtraCharges = 0;
                    decimal total = 0;
                    for (var entry = 0; entry < lstShipmentDetail.Entries.Count; entry++)
                    {
                        totalShipCost += lstShipmentDetail.Entries[entry].Price;
                    }
                    for (var charges = 0; charges < listCharges.Count; charges++)
                    {
                        totalExtraCharges += Convert.ToDouble(listCharges[charges].Value);
                    }
                    total = Convert.ToDecimal(totalShipCost + totalExtraCharges);
                    string message = Constants.strSubmitInvoice + total + Constants.strWithoutCharges;
                    //Generate Confirmation Alert Box
                    dialog = objUtil.ConfirmationAlert(this);
                    Button btnYes = dialog.FindViewById<Button>(Resource.Id.btnYes);
                    Button btnNo = dialog.FindViewById<Button>(Resource.Id.btnNo);
                    LinearLayout lntlayoutReason = dialog.FindViewById<LinearLayout>(Resource.Id.lntlayoutReason);
                    btnYes.Text = Constants.btnTextOk;
                    btnNo.Text = Constants.btnTextCancel;
                    lntlayoutReason.Visibility = ViewStates.Gone;
                    TextView txtMessage = dialog.FindViewById<TextView>(Resource.Id.txtMessage);
                    txtMessage.Text = message;
                    //If Click on Yes
                    btnYes.Click += async delegate
                    {
                        jsonCharge = JsonConvert.SerializeObject(listCharges);
                        await CreateInvoice();
                        dialog.Hide();
                    };
                }
                else
                {
                    Utility.ExpireSession(this);
                }
            }
            catch(Exception ex)
            {
                Toast.MakeText(this, Resources.GetString(Resource.String.choosFile), ToastLength.Long).Show();
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);                
            }
        }

        /// <summary>
        /// Create Invoice If Any File Selected 
        /// </summary>
        /// <returns></returns>
        private async Task CreateInvoice()
        {
            try
            {
                Alerts.showBusyLoader(this);
                if (listFileBytes != null)
                {
                    //File Will be upload
                    for (int fileIndex = 0; fileIndex < listFileBytes.Count; fileIndex++)
                    {
                        if (listFileBytes[fileIndex] != null)
                        {
                            file = new JavaFile(fileUri[fileIndex]);
                            string uploadResult = await UploadBitmapAsync(listFileBytes[fileIndex], file);
                            if (uploadResult != null)
                            {
                                jobject = JObject.Parse(uploadResult);
                                if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
                                {
                                    jsonFileRequest += FileUploadHelper.UploadsJsonRequest(uploadResult);
                                    jsonFileRequest += ",";
                                }
                                else
                                {
                                    Toast.MakeText(this, Convert.ToString(jobject[Constants.strErrorMessage]), ToastLength.Long).Show();
                                    Utility.ErrorLog(Constants.invoiceUploads, Convert.ToString(jobject[Constants.strErrorMessage]), CommanUtil.tokenNo, this);
                                }
                            }
                            else
                            {
                                Toast.MakeText(this, Constants.strNoFile, ToastLength.Long).Show();
                            }
                        }
                    }
                    //Save Invoice with files
                    await SaveInvoice();
                }
                else
                {
                    //Save Invoice withod files
                    await SaveInvoice();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Save Invoice with Files and Extra charges
        /// </summary>
        /// <returns></returns>
        private async Task SaveInvoice()
        {
            try
            {
                objServiceHelper = new ServiceHelper();
                apiMethod = APIMethods.shipmentDetails + "/" + lstShipmentDetail.ClientID + "|" + lstShipmentDetail.LocID + "|" + lstShipmentDetail.BolNum + "/" + APIMethods.invoice;
                string requestBody = "{" + "\"Comments\":" + "\"" + txtComment.Text + "\"" +",";
                requestBody += "\"ExtraCharges\":" + jsonCharge + ",";
                requestBody += "\"Files\":[" + jsonFileRequest + "]";
                requestBody += "}";

                string response = await objServiceHelper.PostRequestJson(requestBody, apiMethod, token, true);
                if (!string.IsNullOrEmpty(response))
                {
                    await ResetControl();
                }
                else
                {
                    jobject = JObject.Parse(response);
                    await ResetControl();
                    Toast.MakeText(this, Convert.ToString(jobject[Constants.strErrorMessage]), ToastLength.Long).Show();
                    Utility.ErrorLog(Constants.invoiceUploads, Convert.ToString(jobject[Constants.strErrorMessage]), CommanUtil.tokenNo, this);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// File upload
        /// </summary>
        /// <param name="bytes">File will be in bytes</param>
        /// <param name="files">file Type</param>
        /// <returns></returns>
        public async Task<string> UploadBitmapAsync(byte[] bytes, JavaFile files)
        {
            try
            {
                objUploadHelper = new FileUploadHelper();
                apiMethod = APIMethods.invoiceDocs;
                var response = await objUploadHelper.PostFiles(bytes, files, apiMethod, token, true);
                return response;
            }
            catch
            {                
                return null;
            }
        }

        /// <summary>
        /// Browser File from Device
        /// </summary>
        private void BrowseFile()
        {
            try
            {
                if ((ContextCompat.CheckSelfPermission(this, Manifest.Permission.WriteExternalStorage) == (int)Permission.Granted))
                {
                    // var imageIntent = new Intent();
                    imageIntent = new Intent(Intent.ActionPick, Android.Provider.MediaStore.Images.Media.ExternalContentUri);
                    imageIntent.SetType("*/*");
                    imageIntent.PutExtra("return-data", true);
                    imageIntent.SetAction(Intent.ActionGetContent);
                    StartActivityForResult(
                        Intent.CreateChooser(imageIntent, Constants.strSelectFile), 0);
                }
                else
                {
                    ActivityCompat.RequestPermissions(this, PermissionsLocation, 0);
                }
                
            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Add Charges
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnAddCharge_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtAmount.Text))
                {
                    //Adding Charges
                    objlistCharges = new Charges();
                    objlistCharges.ID = spinnerCharge.SelectedItem.ToString();
                    objlistCharges.Value = txtAmount.Text;
                    listCharges.Add(objlistCharges);
                    if (listCharges != null)
                    {
                        invoiceChargesAdapter = new InvoiceChargesAdapter.InvoiceChargesList(this, listCharges, lstViewCharges);
                        lstViewCharges.Adapter = invoiceChargesAdapter;

                        lstImageView.Clear();
                        lstLinearCharges.Clear();
                        for (int i = 0; i < listCharges.Count; i++)
                        {
                            View V = lstViewCharges.Adapter.GetView(i, null, null);
                            lstImageView.Add(V.FindViewById<ImageView>(i));
                            lstLinearCharges.Add(V.FindViewById<LinearLayout>(1000 + i));
                        }
                        for(int i= 0; i<lstImageView.Count; i++)
                        {
                            ImageView imageView = lstImageView[i];
                            int rowNum = imageView.Id;
                            imageView.Click += delegate
                            {
                                RemoveViewFromList(rowNum);
                            };
                        }
                        lnrAddChargeHead.Visibility = ViewStates.Visible;
                        lnrAddChargeDetails.Visibility = ViewStates.Visible;
                    }
                    spinnerCharge.SetSelection(0);
                    txtAmount.Text = "";

                    var ll = FindViewById<ListView>(Resource.Id.lstViewCharges);
                    var param = ll.LayoutParameters;
                    param.Height = PixelsToDp(25*(listCharges.Count));
                }
                else
                {
                    Toast.MakeText(this, Constants.strEnterAmount, ToastLength.Long).Show();
                }
            }
            catch
            {
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Remove Extra Charges From List
        /// </summary>
        /// <param name="fileIndex"></param>
        private void RemoveViewFromList(int fileIndex)
        {
            try
            {
                lstViewCharges.RemoveViewAt(fileIndex);
                lstViewCharges.RemoveView(lstLinearCharges[fileIndex]);
            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Open Uploaded files on click of file name
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LstViewDocs_ItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            try
            {
                //Get position
                int index = e.Position;
                //Get file url from objFileList
                fileUrl = lstShipmentDetail.AddlDocs[index];
                Utility.ViewUploadedFile(fileUrl, this);
                //Intent EditNote = new Intent(this, typeof(WebViewActivity));
                //EditNote.PutExtra("URL", fileUrl);
                //StartActivity(EditNote); //Redirect on Web View Layout 
                //EditNote = null;
            }
            catch
            {
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Get Invoice Details
        /// </summary>
        private void GetInvoiceDetails()
        {
            try
            {
                string shipmentDetails = string.Empty;
                shipmentDetails = Utility.sharedPreferences.GetString(Constants.shipmentDetails, null);
                lstShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(shipmentDetails);
                BindSpinner();//Bind Spinner
                if (!string.IsNullOrEmpty(lstShipmentDetail.InvoiceCreatedOn))
                {
                    txtDialogHeader.Text = Constants.strRecreateInvoice + "\n"+Constants.strCreatedOn + lstShipmentDetail.InvoiceCreatedOn;
                }
                else
                {
                    txtDialogHeader.Text = Constants.strCreateInvoice;
                }
                if(lstShipmentDetail.AddlDocs !=null)
                {
                    txtViewUploadHead.Visibility = ViewStates.Visible;
                    lnrLayoutUploads.Visibility = ViewStates.Visible;
                    objFileList = new List<string>();
                    //Assign Files in a List object
                    objFileList = lstShipmentDetail.AddlDocs;
                    //Bind Files
                    BindFiles(objFileList);
                    //Set dynamci height of layout
                    var ll = FindViewById<ListView>(Resource.Id.lstViewDocs);
                    var param = ll.LayoutParameters;
                    param.Height = PixelsToDp(32 * (objFileList.Count));
                    //lstLinearCharges.RemoveAll(;
                }
                else
                {
                    lnrLayoutUploads.Visibility = ViewStates.Gone;
                    txtViewUploadHead.Visibility = ViewStates.Gone;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Bind Supporting Documents 
        /// </summary>
        private void BindFiles(List<string> objFiles)
        {
            try
            {
                if (objFiles != null)
                {
                    //Calling Adapter and binding data into list view
                    lstViewDocs.Visibility = ViewStates.Visible; txtViewUploadHead.Visibility = ViewStates.Visible;
                    lnrLayoutUploads.Visibility = ViewStates.Visible;
                    FileListAdapter = new FileListAdapter.FileListAdapterShipments(this, objFiles);
                    lstViewDocs.Adapter = FileListAdapter;
                }
                else
                {
                    lstViewDocs.Visibility = ViewStates.Gone;
                    lnrLayoutUploads.Visibility = ViewStates.Gone;
                    txtViewUploadHead.Visibility = ViewStates.Gone;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Binding Spinner
        /// </summary>
        private void BindSpinner()
        {
            try
            {
                spinnerCharge.ItemSelected += SpinnerCharge_ItemSelected;
                ArrayAdapter adapter = ArrayAdapter.CreateFromResource(
                        this, Resource.Array.invoiceChargeType, Resource.Drawable.SpinnerCustomDesign);
                adapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
                spinnerCharge.Adapter = adapter;
                adapter = null;
            }
            catch
            {
                throw;
            }
            
        }

        /// <summary>
        /// Dropdown list On selected Item
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SpinnerCharge_ItemSelected(object sender, AdapterView.ItemSelectedEventArgs e)
        {
            try
            {
                Spinner spinner = (Spinner)sender;
                string selected = spinner.GetItemAtPosition(e.Position).ToString();
            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }

        /// <summary>
        /// Data refresh and Reset the controls
        /// </summary>
        private async Task ResetControl()
        {
            try
            {
                apiMethod = APIMethods.shipmentDetails + "/" + lstShipmentDetail.ClientID + "|" + lstShipmentDetail.BolNum;
                await objUtil.BindShipmentDetail(apiMethod, this);//Bind shipment
                GetInvoiceDetails();//Get Latest changes
                Alerts.HideBusyLoader();
                listCharges =  new List<Charges>();
                lnrAddChargeHead.Visibility = ViewStates.Gone;
                lnrAddChargeDetails.Visibility = ViewStates.Gone;
                txtFileName1.Text = "";
                txtFileName2.Text = "";
                txtFileName3.Text = "";
                txtComment.Text = "";
                txtAmount.Text = "";
            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, this);
                Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Long).Show();
            }
        }
    }
}