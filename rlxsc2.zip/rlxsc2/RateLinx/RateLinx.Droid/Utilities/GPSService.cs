using System.Collections.Generic;
using System.Linq;
using Android.App;
using Android.Locations;
using RateLinx.Models;
using System.Threading.Tasks;
using RateLinx.Droid.GoogleMapServices;
using RateLinx.Helper;
using System.Text;
using System;
using RateLinx.GoogleServices;

namespace RateLinx.Droid.Utilities
{
    /// <summary>
    /// Meta tag of the class
    /// </summary>
    public class GPSService
    {
      
        
        /// <summary>
        /// 
        /// </summary>
        public Activity context;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        public GPSService(Activity context)
        {
            this.context = context;
        }

        ///// <summary>
        ///// Get Current location
        ///// </summary>
        ///// <returns></returns>
        //public GPSData GetLocation()
        //{
        //    try
        //    {
        //        //var locator = CrossGeolocator.Current;
        //        GPSData objGPSData = null;
        //        //locator.DesiredAccuracy = 100; //100 is new default
        //        //var position = await locator.GetPositionAsync(timeoutMilliseconds: 10000);
        //        GPSSettings objGPSService = new GPSSettings();
        //        string response = objGPSService.StartLocationUpdates();
        //        if (!string.IsNullOrEmpty(response) && response.Equals("network"))
        //        {
        //            double lat = CommanUtil.currLat;
        //            double lng = CommanUtil.currLong;
        //            Geocoder geocoder;
        //            IList<Android.Locations.Address> addresses;
        //            geocoder = new Geocoder(context);
        //            addresses = geocoder.GetFromLocation(lat, lng, 10); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
        //            if (addresses != null && addresses.Count > 0)
        //            {
        //                Android.Locations.Address addressCurrent = addresses.FirstOrDefault();
        //                string city = addressCurrent.Locality;
        //                string state = "UP";//addressCurrent.AdminArea;
        //                string country = addressCurrent.CountryCode;

        //                objGPSData = new GPSData
        //                {
        //                    Lattitude = lat,
        //                    Longitude = lng,
        //                    City = city,
        //                    State = state,
        //                    Country = country
        //                };
        //                return objGPSData;
        //            }
        //            else
        //            {
        //                return null;
        //            }
        //        }
        //        else
        //        {
        //            return null;
        //        }
        //    }
        //    catch
        //    {
        //        return null;
        //    }

        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="latLong"></param>
        /// <returns></returns>
        public string GetCurrentAddress(Android.Gms.Maps.Model.LatLng latLong)
        {
            try
            {
                Geocoder geocoder;
                string address = string.Empty;
                IList<Android.Locations.Address> addresses;
                geocoder = new Geocoder(context);
                addresses = geocoder.GetFromLocation(latLong.Latitude, latLong.Longitude, 10); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
                if (addresses != null && addresses.Count > 0)
                {
                    Android.Locations.Address addressCurrent = addresses.FirstOrDefault();
                    address = addressCurrent.GetAddressLine(0);
                }
                return address;
            }
            catch
            {
                return null;
            }
        }

        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="sourcePos"></param>
        ///// <param name="currentPos"></param>
        ///// <returns></returns>
        //public static string MakeURL(Android.Gms.Maps.Model.LatLng sourcePos, Android.Gms.Maps.Model.LatLng currentPos)
        //{
        //    StringBuilder urlString = new StringBuilder();
        //    urlString.Append("https://maps.googleapis.com/maps/api/directions/json");
        //    urlString.Append("?origin=");// from
        //    urlString.Append(Convert.ToString(sourcePos.Latitude));
        //    urlString.Append(",");
        //    urlString.Append(Convert.ToString(sourcePos.Longitude));
        //    urlString.Append("&destination=");// to
        //    urlString.Append(Convert.ToString(currentPos.Latitude));
        //    urlString.Append(",");
        //    urlString.Append(Convert.ToString(currentPos.Longitude));
        //    //urlString.Append("&sensor=false&mode=driving&alternatives=false");
        //    urlString.Append("&mode=driving&key=" + Constants.strGoogleServerDirKey + "");
        //    return urlString.ToString();
        //}

        /// <summary>
        /// Get bearing for rotate marker
        /// </summary>
        /// <param name="latLng1"></param>
        /// <param name="latLng2"></param>
        /// <returns></returns>
        public static float BearingBetweenLocations(Android.Gms.Maps.Model.LatLng latLng1, Android.Gms.Maps.Model.LatLng latLng2)
        {
            //new added
            double lat = Math.Abs(latLng1.Latitude - latLng2.Latitude);
            double lng = Math.Abs(latLng1.Longitude - latLng2.Longitude);
            if (latLng1.Latitude < latLng2.Latitude && latLng1.Longitude < latLng2.Longitude)
            {
                double angl = Math.Atan(lng / lat);
                return (float)(90 - radiansToDegrees(angl));
            }
            else if (latLng1.Latitude >= latLng2.Latitude && latLng1.Longitude < latLng2.Longitude)
            {
                return (float)((90 - radiansToDegrees(Math.Atan(lng / lat))) + 180);
            }
            else if (latLng1.Latitude >= latLng2.Latitude && latLng1.Longitude >= latLng2.Longitude)
            {
                return (float)(radiansToDegrees(Math.Atan(lng / lat)) + 270);
            }
            else if (latLng1.Latitude < latLng2.Latitude && latLng1.Longitude >= latLng2.Longitude)
            {
                return (float)((radiansToDegrees(Math.Atan(lng / lat))) + 270);
            }
            else
            {
                return -1;
            }
        }

        /// <summary>
        /// Calculate angle
        /// </summary>
        /// <param name="radians"></param>
        /// <returns></returns>
        public static double radiansToDegrees(double radians)
        {
            return radians * 180.0 / Math.PI;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="latLng1"></param>
        /// <param name="latLng2"></param>
        /// <returns></returns>
        public static float bearingBetweenLocations(Android.Gms.Maps.Model.LatLng latLng1, Android.Gms.Maps.Model.LatLng latLng2)
        {

            double lat1 = latLng1.Latitude;
            double lng1 = latLng1.Longitude;

            // destination
            double lat2 = latLng2.Latitude;
            double lng2 = latLng2.Longitude;

            double dLon = (lng2 - lng1);
            double y = Math.Sin(dLon) * Math.Cos(lat2);
            double x = Math.Cos(lat1) * Math.Sin(lat2) - Math.Sin(lat1) * Math.Cos(lat2) * Math.Cos(dLon);
            float brng = (float)radiansToDegrees((Math.Atan2(y, x)));
            brng = (360 - ((brng + 360) % 360));
            return brng + 90;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="objRoutes"></param>
        /// <returns></returns>
        public static decimal CalculateDistance(GoogleDirectionClass objRoutes)
        {
            //Calculation of miles and Kilometer
            //double mile, km;
            string distance = objRoutes.routes.Select(m => m.legs.Select(len => len.distance.text).FirstOrDefault()).FirstOrDefault();
            //mile = Convert.ToDouble(distance.Split(' ')[0]);
            //km = mile * 1.609344;
            //string optimalRoute = Math.Round(km, 1).ToString();
            return Convert.ToDecimal(distance.Split(' ')[0]);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="my_latlong"></param>
        /// <param name="frnd_latlong"></param>
        /// <returns></returns>
        public static decimal GetDistance(Android.Gms.Maps.Model.LatLng my_latlong, Android.Gms.Maps.Model.LatLng frnd_latlong)
        {
            try
            {
                decimal dist = 0;
                Android.Locations.Location l1 = new Android.Locations.Location("One");
                l1.Latitude = my_latlong.Latitude;
                l1.Longitude = my_latlong.Longitude;

                Android.Locations.Location l2 = new Android.Locations.Location("Two");
                l2.Latitude = frnd_latlong.Latitude;
                l2.Longitude = frnd_latlong.Longitude;

                float distance = l1.DistanceTo(l2);
                distance = distance / 1000.0f;
                dist = Convert.ToDecimal((distance / 1.609f).ToString("F"));
                return dist;
            }
            catch
            {
                Console.WriteLine(Constants.strErrorOccured);
                return 0;
            }
        }



        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="originLatLng"></param>
        ///// <param name="destinationLatLng"></param>
        //public void AnimateMarker(LatLng originLatLng, LatLng destinationLatLng)
        //{
        //    int numDeltas = 10;

        //    double deltaLat;
        //    double deltaLng;

        //    deltaLat = (destinationLatLng.Latitude - originLatLng.Latitude) / numDeltas;
        //    deltaLng = (destinationLatLng.Longitude - originLatLng.Longitude) / numDeltas;
        //    MoveMarker(originLatLng, destinationLatLng, deltaLat, deltaLng);

        //}
        //LatLng currentLatLng;
        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="originLatLng"></param>
        ///// <param name="destinationLatLng"></param>
        ///// <param name="deltaLat"></param>
        ///// <param name="deltaLng"></param>
        //public void MoveMarker(LatLng originLatLng, LatLng destinationLatLng, double deltaLat, double deltaLng)
        //{
        //    originLatLng.Latitude += deltaLat;
        //    originLatLng.Longitude += deltaLng;

        //    for (int i = 1; i <= 10; i++)
        //    {
        //        currentLatLng = new LatLng(originLatLng.Latitude, originLatLng.Longitude);
        //        //Set marker postion to currentLatLng
        //        //objMarker.Position = currentLatLng;
        //        Task.Delay(100);
        //        originLatLng.Latitude += deltaLat;
        //        originLatLng.Longitude += deltaLng;
        //    }


        //}


    }
}