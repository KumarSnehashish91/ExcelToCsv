using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using RateLinx.APIs;
using Android.Net;
using Android.Content;
using RateLinx.Models;
using Newtonsoft.Json;
using RateLinx.Helper;
using Android.App;
using Android.Widget;
using Android.Views;
using Newtonsoft.Json.Linq;
using Android.Preferences;
using RateLinx.Droid.Activities;
using AndroidNetUri = Android.Net.Uri;
using Android.Graphics;

namespace RateLinx.Droid.Utilities
{
    /// <summary>
    /// Meta Tag for Comman Utility class
    /// </summary>
    public class Utility
    {
        /// <summary>
        /// 
        /// </summary>
        public static Activity activity;

        /// <summary>
        /// 
        /// </summary>
        public static int notificationCount = 0;

        /// <summary>
        /// sharedPreferences for local storage of the variables
        /// </summary>
        public static ISharedPreferences sharedPreferences = null;
        
        /// <summary>
        /// To check which conversation part is expanded when replying from user
        /// </summary>
        public static int ActiveConversationHeader = 0;

        /// <summary>
        /// 
        /// </summary>
        public static bool isReplied = false;

        /// <summary>
        /// 
        /// </summary>
        public static bool replySectionIsClosed = true;

        /// <summary>
        /// 
        /// </summary>
        public static Dialog dialog;
        /// <summary>
        /// 
        /// </summary>
        public static Utility objutil = new Utility();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="e"></param>
        /// <returns></returns>
        public static string CheckAMPM(TimePickerDialog.TimeSetEventArgs e)
        {
            if (e.HourOfDay < 12)
            {
               CommanUtil.AMPM = "AM";
            }
            else
            {
                CommanUtil.AMPM = "PM";
            }
            return CommanUtil.AMPM;
        }

        /// <summary>
        /// 
        /// </summary>
        public static ArrayAdapter DescriptionAdapter(Activity context)
        {
            try
            {
                List<TrackingDesc> lstTrackingDesc = CommanUtil.TrackingDescList();

                List<string> lstTrackDescVal = new List<string>();

                foreach (TrackingDesc objTrackDesc in lstTrackingDesc)
                {
                    lstTrackDescVal.Add(Convert.ToString(objTrackDesc.text));
                }
                ArrayAdapter adapter = new ArrayAdapter(context, Resource.Drawable.SpinnerCustomDesign, lstTrackDescVal);
                return adapter;
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public static ArrayAdapter ExceptionAdapter(Activity context)
        {
            try
            {
                List<TrackingDesc> lstTrackingDesc = CommanUtil.ExceptionDescList();

                List<string> lstTrackDescVal = new List<string>();

                foreach (TrackingDesc objTrackDesc in lstTrackingDesc)
                {
                    lstTrackDescVal.Add(Convert.ToString(objTrackDesc.text));
                }
                ArrayAdapter adapter = new ArrayAdapter(context, Resource.Drawable.SpinnerCustomDesign, lstTrackDescVal);
                return adapter;
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
                return null;
            }
        }


        /// <summary>
        /// Get Country Details
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public static async Task<List<CountryDetails>> GetCountryDetails(Activity context)
        {
            try
            {
                List<CountryDetails> lstCountryDetails = null;
                //Get the service Helper Object
                ServiceHelper objServicehelper = new ServiceHelper();
                // create json object that holds the api values
                //Method Name
                string methodName = APIMethods.getCountry;
                Alerts.showBusyLoader(context);
                //Get the Shipments
                var strResponse = await objServicehelper.GetRequest(CommanUtil.tokenNo, methodName, true);
                Alerts.HideBusyLoader();
                lstCountryDetails = new List<CountryDetails>();
                if (strResponse != null)
                {
                    lstCountryDetails = (List<CountryDetails>)JsonConvert.DeserializeObject(strResponse, typeof(List<CountryDetails>));
                }
                return lstCountryDetails;
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
                return null;
            }
        }

        /// <summary>
        /// Confirmation Dialog Alert Box
        /// </summary>
        /// <returns></returns>
        public  Dialog ConfirmationAlert(Activity context)
        {
            try
            {
                Dialog dialog = null;
                AlertDialog.Builder alert = null;
                alert = new AlertDialog.Builder(context);
                alert.SetView(Resource.Layout.ConfirmationMessageAlert);
                dialog = alert.Create();
                dialog.Show();

                TextView txtMessage = dialog.FindViewById<TextView>(Resource.Id.txtMessage);
                TextView txtDialogHeader = dialog.FindViewById<TextView>(Resource.Id.txtDialogHeader);
                
                Button btnNo = dialog.FindViewById<Button>(Resource.Id.btnNo);
                TextView txtViewClose = dialog.FindViewById<TextView>(Resource.Id.txtViewClose);
                btnNo.Click += delegate
                {
                    dialog.Hide();
                };
                txtViewClose.Click += delegate
                {
                    dialog.Hide();
                };
                dialog.SetCancelable(false);
                return dialog;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public Dialog UploadPictureAlert(Activity context)
        {
            try
            {
                Dialog dialog = null;
                AlertDialog.Builder alert = null;
                alert = new AlertDialog.Builder(context);
                alert.SetView(Resource.Layout.UploadPictureDialog);
                dialog = alert.Create();
                dialog.Show();
                TextView txtDialogHeader = dialog.FindViewById<TextView>(Resource.Id.txtDialogHeader);

                Button btnNo = dialog.FindViewById<Button>(Resource.Id.btnNo);
                Button btnTakePicture = dialog.FindViewById<Button>(Resource.Id.btnTakePicture);
                Button btnUpload = dialog.FindViewById<Button>(Resource.Id.btnUpload);
                TextView txtViewClose = dialog.FindViewById<TextView>(Resource.Id.txtViewClose);
                btnNo.Click += delegate
                {
                    dialog.Hide();
                };
                txtViewClose.Click += delegate
                {
                    dialog.Hide();
                };
                dialog.SetCancelable(false);
                return dialog;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        ///  Generating Custome Dialog according to requirement
        /// </summary>
        /// <param name="context"></param>
        /// <param name="dialogHeader"></param>
        /// <param name="message"></param>
        /// <param name="btnConfirmText"></param>
        /// <param name="btnCancelText"></param>
        /// <param name="txtReasonLbl"></param>
        /// <param name="lntlayoutReasonVisiblity"></param>
        /// <param name="txtMessageVisibility"></param>
        /// <param name="btnConfirmVisibility"></param>
        /// <param name="btnCancelVisibility"></param>
        /// <param name="imgheaderVisibility"></param>
        /// <param name="imgheaderErrorVisibility"></param>
        /// <returns></returns>
        public Dialog GetDialog(Activity context, string dialogHeader, string message, 
            string btnConfirmText, string btnCancelText, string txtReasonLbl, 
            ViewStates lntlayoutReasonVisiblity, ViewStates txtMessageVisibility, 
            ViewStates btnConfirmVisibility, ViewStates btnCancelVisibility,
            ViewStates imgheaderVisibility, ViewStates imgheaderErrorVisibility)
        {
            try
            {
                Dialog dialog = ConfirmationAlert(context);//Generate Confirmation Alert Box
                Button btnConfirm = dialog.FindViewById<Button>(Resource.Id.btnYes);
                Button btnCancel = dialog.FindViewById<Button>(Resource.Id.btnNo);
                TextView txtMessage = dialog.FindViewById<TextView>(Resource.Id.txtMessage);
                TextView txtDialogHeader = dialog.FindViewById<TextView>(Resource.Id.txtDialogHeader);
                TextView txtReasonlbl = dialog.FindViewById<TextView>(Resource.Id.txtReason);
                LinearLayout lntlayoutReason = dialog.FindViewById<LinearLayout>(Resource.Id.lntlayoutReason);
                ImageView imgheader = dialog.FindViewById<ImageView>(Resource.Id.imgheader);
                ImageView imgheaderError = dialog.FindViewById<ImageView>(Resource.Id.imgheaderError);
                EditText txtAcceptDeny = dialog.FindViewById<EditText>(Resource.Id.txtEnterReason);
                txtReasonlbl.Text = txtReasonLbl;
                txtDialogHeader.Text = dialogHeader;
                txtMessage.Text = message;
                btnConfirm.Text = btnConfirmText;
                btnCancel.Text = btnCancelText;
                lntlayoutReason.Visibility = lntlayoutReasonVisiblity;
                txtMessage.Visibility = txtMessageVisibility;
                btnConfirm.Visibility = btnConfirmVisibility;
                btnCancel.Visibility = btnCancelVisibility;
                //imgheader.Visibility = imgheaderVisibility;
                //imgheaderError.Visibility = imgheaderErrorVisibility;                
                imgheaderError.Visibility = ViewStates.Gone;
                imgheader.Visibility = ViewStates.Gone;
                return dialog;
            }
            catch
            {
                 Console.Write(Constants.strErrorOccured);
                return null;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="dialogHeader"></param>
        /// <param name="message"></param>
        /// <param name="btnConfirmText"></param>
        /// <param name="btnCancelText"></param>
        /// <param name="lntlayoutMessageVisibility"></param>
        /// <param name="btnConfirmVisibility"></param>
        /// <param name="btnCancelVisibility"></param>
        /// <param name="imgheaderVisibility"></param>
        /// <param name="lnrUploadLayoutVisibility"></param>
        /// <returns></returns>
        public Dialog GetUploadDialog(Activity context, string dialogHeader, string message,
           string btnConfirmText, string btnCancelText,ViewStates lntlayoutMessageVisibility,
           ViewStates btnConfirmVisibility, ViewStates btnCancelVisibility,
           ViewStates imgheaderVisibility,  ViewStates lnrUploadLayoutVisibility)
        {
            try
            {
                Dialog dialog = UploadPictureAlert(context);//Generate Confirmation Alert Box
                Button btnConfirm = dialog.FindViewById<Button>(Resource.Id.btnYes);
                btnConfirm.Visibility = ViewStates.Gone;
                Button btnCancel = dialog.FindViewById<Button>(Resource.Id.btnNo);
                Button btnTakePicture = dialog.FindViewById<Button>(Resource.Id.btnTakePicture);
                Button btnUpload = dialog.FindViewById<Button>(Resource.Id.btnUpload);
                //TextView txtMessage = dialog.FindViewById<TextView>(Resource.Id.txtMessage);
                TextView txtDialogHeader = dialog.FindViewById<TextView>(Resource.Id.txtDialogHeader);
                //TextView txtReasonlbl = dialog.FindViewById<TextView>(Resource.Id.txtReason);
                //LinearLayout lntlayoutReason = dialog.FindViewById<LinearLayout>(Resource.Id.lntlayoutReason);
                ImageView imgheader = dialog.FindViewById<ImageView>(Resource.Id.imgheader);
                //EditText txtAcceptDeny = dialog.FindViewById<EditText>(Resource.Id.txtEnterReason);
                LinearLayout lnrUploadLayout = dialog.FindViewById<LinearLayout>(Resource.Id.lnrUploadLayout);
                LinearLayout lntlayoutMessage = dialog.FindViewById<LinearLayout>(Resource.Id.lntlayoutMessage);
                txtDialogHeader.Text = dialogHeader;
                btnConfirm.Text = btnConfirmText;
                btnCancel.Text = btnCancelText;
               
                //txtMessage.Visibility = txtMessageVisibility;
                btnConfirm.Visibility = btnConfirmVisibility;
                btnCancel.Visibility = btnCancelVisibility;
                imgheader.Visibility = imgheaderVisibility;
                lntlayoutMessage.Visibility = lntlayoutMessageVisibility;
                lnrUploadLayout.Visibility = lnrUploadLayoutVisibility;
                return dialog;
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
                return null;
            }
        }

        /// <summary>
        /// Changing Linear Layout gackground color
        /// </summary>
        /// <param name="lnrLayout">Linear Layout control Id</param>
        /// <param name="view">Layout Form</param>
        /// <param name="position">Position of Layout</param>
        public void ChangeLayoutColor(LinearLayout lnrLayout, View view, int position)
        {
            try
            {
               // int _evenColor, _oddColor = 0;
                //_evenColor = Resource.Color.EvenColor;
                //_oddColor = Resource.Color.OddColor;
                if (position % 2 == 0)
                {
                    //lnrLayout.SetBackgroundColor(view.Resources.GetColor(_evenColor));
                    lnrLayout.SetBackgroundResource(Resource.Color.EvenColor);
                }
                else
                {
                    //lnrLayout.SetBackgroundColor(view.Resources.GetColor(_oddColor));
                    lnrLayout.SetBackgroundResource(Resource.Color.OddColor);
                }
            }
            catch
            {
                 Console.Write(Constants.strErrorOccured);
            }

        }

        /// <summary>
        /// Get Shipment Detail 
        /// </summary>
        /// <param name="apiMethod"></param>
        /// <param name="context"></param>
        public async Task<string> BindShipmentDetail(string apiMethod, Activity context)
        {
            try
            {
                string response = string.Empty;
                ServiceHelper objServicehelper = null;
                JObject jobject = null;
              //  CarrierShipmentDetails lstShipmentDetail = null;
                objServicehelper = new ServiceHelper();
                //Get the Shipments
                response = await objServicehelper.GetRequest(CommanUtil.tokenNo, apiMethod, true);
                if (response != null)
                {
                    jobject = JObject.Parse(response);
                    if (string.IsNullOrEmpty(Convert.ToString(jobject[Constants.strErrorMessage])))
                    {
                       // lstShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(response);
                        //Removing Local storage
                        sharedPreferences.Edit().Remove(Constants.shipmentDetails).Commit();
                        sharedPreferences.Edit().PutString(Constants.shipmentDetails, response).Commit();
                    }
                    else
                    {
                        response = string.Empty;
                        //Post Error Logger Request 
                        ErrorLog(Constants.shipmentDetail, Convert.ToString(jobject[Constants.strErrorMessage]), CommanUtil.tokenNo, context);
                    }
                    
                }
                return response;
            }
            catch(Exception ex)
            {
                 Console.Write(Constants.strErrorOccured);
                return null;
            }
        }

        /// <summary>
        /// Redirect to Any Activity 
        /// </summary>
        /// <param name="context">From redirect page context</param>
        /// <param name="activityName">Activity Name where want to redirect</param>
        /// <param name="key">Key name from you will get the value</param>
        /// <param name="value">what you want to send with key</param>
        /// <returns></returns>
        public static Intent RedirectTo(Activity context, Type activityName, string key, string value)
        {
            try
            {
                Intent objIntent = new Intent(context, activityName);
                objIntent.PutExtra(key, Convert.ToString(value));
                return objIntent;
            }
            catch
            {
                 Console.Write(Constants.strErrorOccured);
                return null;
            }
        }

        /// <summary>
        /// Function to log the error into database table
        /// </summary>
        /// <param name="recordId">Error ID</param>
        /// <param name="message">Error Message</param>
        /// <param name="tokenNo">Token Number</param>
        /// <param name="context">Activity Name</param>
        public static async void ErrorLog(string recordId, string message, string tokenNo, Activity context)
        {
            try
            {
                string strPostData = string.Empty;
                ServiceHelper objServiceHelper = new ServiceHelper();
                strPostData = "RecordID=" + recordId + "&Message=" + message;
                //Post Error Logger Request 
                var response = await objServiceHelper.PostRequest(strPostData, APIMethods.logerror, tokenNo, true);
                if (response != null)
                {
                    //Toast.MakeText(context, Convert.ToString(jsonResponse), ToastLength.Long).Show();
                }
                else
                {
                    //Toast.MakeText(context, "Error", ToastLength.Long).Show();
                }
                objServiceHelper = null;
            }
            catch
            {
                 Console.Write(Constants.strErrorOccured);;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public static Android.Locations.Address geoAddress = null;

        /// <summary>
        /// Checking Internet Connection
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public static Boolean FnIsOnline(Context context)
        {
            try
            {
                var connectionManager = (ConnectivityManager)context.GetSystemService(Context.ConnectivityService);
                NetworkInfo networkInfo = connectionManager.ActiveNetworkInfo;
                if (networkInfo != null && networkInfo.IsConnected)
                {
                    return true;
                }
            }
            catch
            {
                return false;
            }
            return false;
        }

        /// <summary>
        /// Logout From Application
        /// </summary>
        /// <param name="context"></param>
        public static void Logout(Activity context)
        {
            try
            {
                #region  Clear the Local stored values
                sharedPreferences = PreferenceManager.GetDefaultSharedPreferences(context);
                //sharedPreferences.Edit().Remove(Constants.strActiveShipment).Commit();
                //sharedPreferences.Edit().Remove(Constants.strAwardedShipment).Commit();
                //sharedPreferences.Edit().Remove(Constants.strRecentShipment).Commit();
                sharedPreferences.Edit().Remove(Constants.shipmentDetails).Commit();
                sharedPreferences.Edit().Remove("objTrackList").Commit();
               // CommanUtil.tokenNo = string.Empty;
                CommanUtil.ViewAs = string.Empty;
                CommanUtil.userID = string.Empty;
                CommanUtil.UserPermissions = null;
                CommanUtil.isTrackingEnable = false;
                CommanUtil.loginTime = DateTime.Now;
                CommanUtil.isTrackingOn = true;
                //CommanUtil.stopPooling = true;
                //CommanUtil.isActiveIntervalAllow = true;
                //CommanUtil.isAwardIntervalAllow = true;
                //CommanUtil.isRecentIntervalAllow = true;
                CommanUtil.refresh = false;
                #endregion
                Intent objIntent = new Intent(context, typeof(LoginActivity));
                objIntent.PutExtra("logOut", "Logout");
                objIntent.SetFlags(ActivityFlags.ClearTop | ActivityFlags.ClearTask | ActivityFlags.NewTask);
                context.StartActivity(objIntent);
                context.Finish();
            }
            catch
            {
                 Console.Write(Constants.strErrorOccured);;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public static async Task<string> Node_GetToken()
        {
            try
            {
                ServiceHelper objServiceHelper = new ServiceHelper();
                TokenReq objTokenReq = new TokenReq();
                string requestData = string.Empty;
                requestData = JsonConvert.SerializeObject(objTokenReq);
                string result = await objServiceHelper.Node_PostRequestJson(requestData, APIMethods.node_Auth, "", false);
                if(!string.IsNullOrEmpty(result))
                {
                    DispatureToken objDispatureToken = JsonConvert.DeserializeObject<DispatureToken>(result);
                    if(objDispatureToken.statusNum==200)
                    {
                        result = objDispatureToken.data.accessToken;
                        return result;
                    }
                    else
                    {
                        result = string.Empty;
                    }
                }
                else
                {
                    result = string.Empty;
                }
                objServiceHelper = null;
                objTokenReq = null;
                requestData = string.Empty;
                return result;
            }
            catch
            {
                //Console.WriteLine(Constants.strErrorOccured);
                //return "";
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="assignDriver"></param>
        public static async Task<string> Node_AssignDriver(AssignDriver assignDriver)
        {
            try
            {
                //node_AssignDriver
                string tokenNo = await Node_GetToken();
                ServiceHelper objServiceHelper = new ServiceHelper();
                string requestData = string.Empty;
                requestData = JsonConvert.SerializeObject(assignDriver);
                string result = await objServiceHelper.Node_PostRequestJson(requestData, APIMethods.node_AssignDriver, tokenNo, true);
                if (!string.IsNullOrEmpty(result))
                {
                    //AssignDriverRes objAssignDriverRes = JsonConvert.DeserializeObject<AssignDriverRes>(result);
                    //if(objAssignDriverRes.statusNum==200)
                    //{
                    //    result = objAssignDriverRes.statusMsg;
                    //}
                    //else
                    //{
                    //    result = objAssignDriverRes.statusMsg;
                    //}
                    result = Constants.driverAssignedSucessfully;
                }
                else
                {
                    result = Constants.strErrorOccured;
                }
                objServiceHelper = null;
                requestData = string.Empty;
                return result;
            }
            catch
            {
                //Console.WriteLine(Constants.strErrorMessage);
                //return Constants.strErrorMessage;
                throw;
            }
        }

        /// <summary>
        /// Get Shipment tracking status
        /// </summary>
        /// <param name="bolNum"></param>
        /// <returns></returns>
        public async Task<List<ShipmentActivity>> GetRealtimeShipmentStatus(string bolNum)
        {
            List<ShipmentActivity> lstShipmentActivity = new List<ShipmentActivity>();
            try
            {
                string tokenNo = await Node_GetToken(); //Get the token
                ServiceHelper objServiceHelper = new ServiceHelper();
                string requestData = string.Empty;
                string result = await objServiceHelper.Node_GetRequest(tokenNo, APIMethods.node_GetShipmentStatus + bolNum, true);
                if (!string.IsNullOrEmpty(result))
                {
                    RealTimeShipmentStatus realTimeShipmentStatus = JsonConvert.DeserializeObject<RealTimeShipmentStatus>(result);
                    if (realTimeShipmentStatus.statusNum == 200)
                    {
                        lstShipmentActivity = realTimeShipmentStatus.data.Activities;
                    }
                    else
                    {
                        result = Constants.strErrorOccured;
                    }
                }
                else
                {
                    result = Constants.strErrorOccured;
                }
                objServiceHelper = null;
                requestData = string.Empty;
                return lstShipmentActivity;
            }
            catch
            {
                Console.WriteLine(Constants.strErrorMessage);
                return lstShipmentActivity;
            }
        }

        /// <summary>
        /// Update Real time tracking Status of shipment
        /// </summary>
        /// <param name="updateRealTimeStatus"></param>
        public static async Task<string> UpdateRealTimeStatus(UpdateRealTimeStatus updateRealTimeStatus)
        {
            try
            {
                string tokenNo = await Node_GetToken();
                ServiceHelper objServiceHelper = new ServiceHelper();
                string requestData = string.Empty;
                requestData = JsonConvert.SerializeObject(updateRealTimeStatus);
                string result = await objServiceHelper.Node_PostRequestJson(requestData, APIMethods.node_UpdateShipmentStatus, tokenNo, true);
                if (result.ToUpper() == Constants.strOK)
                {
                    return result;                   
                }
                else
                {
                    result = string.Empty;
                }
                objServiceHelper = null;
                requestData = string.Empty;
                return result;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Expire Token
        /// </summary>
        /// <param name="activity"></param>
        public static void ExpireSession(Activity activity )
        {
            try
            {
                Alerts.HideBusyLoader();
                if (!CommanUtil.IsTimeOut())
                {
                    dialog = objutil.ConfirmationAlert(activity);
                    Button btnYes = dialog.FindViewById<Button>(Resource.Id.btnYes);
                    Button btnNo = dialog.FindViewById<Button>(Resource.Id.btnNo);
                    LinearLayout lntlayoutReason = dialog.FindViewById<LinearLayout>(Resource.Id.lntlayoutReason);
                    btnYes.Visibility = ViewStates.Visible;
                    TextView txtViewClose = dialog.FindViewById<TextView>(Resource.Id.txtViewClose);
                    btnYes.Text = Constants.btnTextYes;
                    //btnYes.SetBackgroundColor(Android.Graphics.Color.Red);
                    btnNo.Text = Constants.btnTextNo;
                    //btnNo.Visibility = ViewStates.Invisible;
                    lntlayoutReason.Visibility = ViewStates.Gone;
                    TextView txtMessage = dialog.FindViewById<TextView>(Resource.Id.txtMessage);
                    txtMessage.Text = Constants.reLoginText;
                    btnYes.Click += async delegate
                     {
                         dialog.Hide();
                         dialog.Dismiss();
                         Alerts.showBusyLoader(activity);
                         await Task.Delay(500);
                         string loginDetails = sharedPreferences.GetString(Constants.userCredential, null);
                         if (!string.IsNullOrEmpty(loginDetails))
                         {
                             LoginActivity loginActivity = new LoginActivity();
                             bool isLogin = await loginActivity.Login(loginDetails);
                             if (isLogin)
                             {
                             //if(Utility.activity.GetType().Name== Constants.strHomeAct)
                             //{
                             //    Alerts.HideBusyLoader();
                             //    //CommanUtil.stopPooling = false;
                             //    Utility.activity.StartActivity(typeof(HomeActivity));
                             //    //HomeActivity homeActivity = new HomeActivity();
                             //    // homeActivity.GetRealtimeShipmentsInterval();
                             //}
                             Alerts.HideBusyLoader(); //Loader
                         }
                             else
                             {
                                 Alerts.HideBusyLoader(); //Loader
                             Logout(activity);
                             }
                         }
                         else
                         {
                             Alerts.HideBusyLoader(); //Loader
                         Logout(activity);
                         }
                     };
                    btnNo.Click += delegate
                    {
                        Logout(activity);
                    };
                    txtViewClose.Click += delegate
                    {
                        Logout(activity);
                    };
                }
            }
            catch
            {

            }
            
        }

        /// <summary>
        /// View uploaded file
        /// </summary>
        /// <param name="url"></param>
        /// <param name="context"></param>
        public static void ViewUploadedFile(string url, Activity context)
        {
            //var fileUrl = AndroidNetUri.Parse(url);
            //var intentGPlus = new Intent(Intent.ActionView, fileUrl);
            //context.StartActivity(intentGPlus);
            Intent EditNote = new Intent(context, typeof(WebViewActivity));
            EditNote.PutExtra("URL", url);
            context.StartActivity(EditNote); //Redirect on Web View Layout 
            EditNote = null;
        }
    }
}