using System;
using Android.App;
using Android.Widget;
using Com.Bumptech.Glide;
using RateLinx.Helper;
      

namespace RateLinx.Droid.Utilities
{
    /// <summary>
    /// Dialog Alerts for showing loader in the applicatin
    /// </summary>
    public static class Alerts
    {
        /// <summary>
        /// 
        /// </summary>
        public static Dialog dialog = null;

        /// <summary>
        /// Creating Custome Hearder Dialog
        /// </summary>
        /// <param name="_Activity"></param>
        public static void showBusyLoader(Activity _Activity)
        {
            try
            {
                dialog = new Dialog(_Activity);
                //dialog.RequestWindowFeature(WindowFeatures.NoTitle);
                dialog.SetContentView(Resource.Layout.CustomProgressDialog);
                dialog.SetCancelable(false);
                ImageView ImageLoader = dialog.FindViewById<ImageView>(Resource.Id.imgProgrssBar);
                Glide.With(_Activity).Load(Resource.Drawable.loading_icon).Into(ImageLoader);
                dialog.Window.SetBackgroundDrawableResource(Android.Resource.Color.Transparent);
                dialog.Show();
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
            }
        }

        /// <summary>
        /// Hide Custome Dial Box 
        /// </summary>
        public static void HideBusyLoader()
        {

            if(dialog != null)
            {
                dialog.Hide();
                dialog.Dismiss();
                dialog = null;
            }
            
        }
    }
}