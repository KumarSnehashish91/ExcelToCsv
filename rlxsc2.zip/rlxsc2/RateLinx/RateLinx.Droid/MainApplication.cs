﻿using System;

using Android.App;
using Android.OS;
using Android.Runtime;
using HockeyApp.Android;
using Plugin.CurrentActivity;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;
using Constants = RateLinx.Helper.Constants;

namespace RateLinx.Droid
{
    /// <summary>
    /// 
    /// </summary>
	[Application]
	public class MainApplication : Application, Application.IActivityLifecycleCallbacks
	{
        /// <summary>
        /// 
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="transer"></param>
		public MainApplication(IntPtr handle, JniHandleOwnership transer)
		  : base(handle, transer)
		{
		}

        /// <summary>
        /// 
        /// </summary>
		public override void OnCreate()
		{
			base.OnCreate();
            CrashManager.Register(this, "fbf0faa4a08d4153adeebd5e567cffac");
            // Crashlytics.Crashlytics.HandleManagedExceptions();
            RegisterActivityLifecycleCallbacks(this);
		}
        
        /// <summary>
        /// 
        /// </summary>
		public override void OnTerminate()
		{
			base.OnTerminate();
            Console.WriteLine("Application stopped forcefully");
            CommanUtil.isTrackingEnable = false;
            CommanUtil.isTrackingOn = true;
            //CommanUtil.stopPooling = true;
            CommanUtil.refresh = false;
            CommanUtil.tokenNo = string.Empty;
            CommanUtil.ViewAs = string.Empty;
            CommanUtil.userID = string.Empty;
            //CommanUtil.isActiveIntervalAllow = true;
            //CommanUtil.isAwardIntervalAllow = true;
            //CommanUtil.isRecentIntervalAllow = true;
            UnregisterActivityLifecycleCallbacks(this);
            
            //Utility.sharedPreferences.Edit().PutString(Constants.Client_Id + "/" + Constants.BolNO, DateTime.Now.ToString()).Commit();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="activity"></param>
        /// <param name="savedInstanceState"></param>
		public void OnActivityCreated(Activity activity, Bundle savedInstanceState)
		{
			CrossCurrentActivity.Current.Activity = activity;
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="activity"></param>
		public void OnActivityDestroyed(Activity activity)
		{
            //Utility.sharedPreferences.Edit().PutString(Constants.Client_Id + "/" + Constants.BolNO, DateTime.Now.ToString()).Commit();
            //Utility.sharedPreferences.Edit().PutString("ClosedTime", DateTime.Now.ToString()).Commit();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="activity"></param>
		public void OnActivityPaused(Activity activity)
		{
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="activity"></param>
		public void OnActivityResumed(Activity activity)
		{
			CrossCurrentActivity.Current.Activity = activity;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="activity"></param>
        /// <param name="outState"></param>
		public void OnActivitySaveInstanceState(Activity activity, Bundle outState)
		{

		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="activity"></param>
		public void OnActivityStarted(Activity activity)
		{
			CrossCurrentActivity.Current.Activity = activity;
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="activity"></param>
		public void OnActivityStopped(Activity activity)
		{
            //Utility.sharedPreferences.Edit().PutString(Constants.Client_Id + "/" + Constants.BolNO, DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")).Commit();

        }
    }
}