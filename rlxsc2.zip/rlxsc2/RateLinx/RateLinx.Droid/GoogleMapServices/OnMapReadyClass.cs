﻿using Android.Gms.Maps;
using System;

namespace RateLinx.Droid.GoogleMapServices
{
    /// <summary>
    /// Google Services
    /// </summary>
    public class OnMapReadyClass : Java.Lang.Object, IOnMapReadyCallback
    {
        /// <summary>
        /// 
        /// </summary>
        public GoogleMap Map { get; private set; }

        /// <summary>
        /// 
        /// </summary>
        public event Action<GoogleMap> MapReadyAction;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="googleMap"></param>
        public void OnMapReady(GoogleMap googleMap)
        {
            Map = googleMap;
            if (MapReadyAction != null)
                MapReadyAction(Map);
        }

    }
}
