﻿using System;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Locations;
using RateLinx.Helper;
using RateLinx.Droid.Activities;

namespace RateLinx.Droid.GoogleMapServices
{
    /// <summary>
    ///GPSService meta tag class
    /// </summary>
    [Service]
    public class GPSSettings : Service, ILocationListener
    {
        #region
        private string _sourceAddress = Constants._source;
        private string _location = string.Empty;
        private string _address = string.Empty;
        private string _remarks = string.Empty;
        #endregion

        /// <summary>
        /// 
        /// </summary>
        public string LOCATION_UPDATE_ACTION = Constants.LOCATION_UPDATED;
        private Android.Locations.Location _currentLocation;
       // public static string chanelName = string.Empty;
        IBinder _binder;
        /// <summary>
        /// 
        /// </summary>
        protected LocationManager _locationManager = (LocationManager)Android.App.Application.Context.GetSystemService(LocationService);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="intent"></param>
        /// <returns></returns>
        public override IBinder OnBind(Intent intent)
        {
            try
            {
                _binder = new GPSServiceBinder(this);
                return _binder;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="intent"></param>
        /// <param name="flags"></param>
        /// <param name="startId"></param>
        /// <returns></returns>
        public override StartCommandResult OnStartCommand(Intent intent, StartCommandFlags flags, int startId)
        {
            return StartCommandResult.Sticky;
        }

        //public string StartLocationUpdates()
        //{
        //    try
        //    {
        //        string result = string.Empty;
        //        Criteria criteriaForGPSService = new Criteria
        //        {
        //            //A constant indicating an approximate accuracy
        //            //Accuracy = Accuracy.Coarse,
        //            //PowerRequirement = Power.Medium
        //            Accuracy = Accuracy.Fine,
        //            PowerRequirement = Power.High
        //        };

        //        var locationProvider = _locationManager.GetBestProvider(criteriaForGPSService, true);
        //        _locationManager.RequestLocationUpdates(locationProvider, 1000, 0, this);
        //        if (!string.IsNullOrEmpty(locationProvider))
        //        {
        //            if (locationProvider.Equals("network"))
        //            {
        //                result = "network";
        //            }
        //            else
        //            {
        //                CommanUtil.currLat = 0.0;
        //                CommanUtil.currLong = 0.0;
        //            }
        //        }
        //        return result;
        //    }
        //    catch
        //    {
        //        Console.WriteLine(Constants.strErrorOccured);
        //        return null;
        //    }
        //}

        /// <summary>
        /// 
        /// </summary>
        public event EventHandler<LocationChangedEventArgs> LocationChanged = delegate { };

        /// <summary>
        /// 
        /// </summary>
        /// <param name="location"></param>
        public void OnLocationChanged(Android.Locations.Location location)
        {
            try
            {
                _currentLocation = location;

                if (_currentLocation == null)
                {
                    CommanUtil.currLat = 0.0;
                    CommanUtil.currLong = 0.0;
                    _location = Constants.locationNotFound;
                }
                else
                {
                    _location = String.Format("{0},{1}", _currentLocation.Latitude, _currentLocation.Longitude);
                    CommanUtil.currLat = _currentLocation.Latitude;
                    CommanUtil.currLong = _currentLocation.Longitude;
                    //var s = _currentLocation.Bearing;

                    //UpdateShipmentStatusActivity objUpdateShipmentStatusActivity = new UpdateShipmentStatusActivity();
                    //objUpdateShipmentStatusActivity.Publish(chanelName, Convert.ToString(_currentLocation.Latitude + "," + _currentLocation.Longitude));

                    //Geocoder geocoder = new Geocoder(this);

                    ////The Geocoder class retrieves a list of address from Google over the internet
                    //IList<Address> addressList = geocoder.GetFromLocation(_currentLocation.Latitude, _currentLocation.Longitude, 10);

                    //Address addressCurrent = addressList.FirstOrDefault();

                    //if (addressCurrent != null)
                    //{
                    //    StringBuilder deviceAddress = new StringBuilder();

                    //    for (int i = 0; i < addressCurrent.MaxAddressLineIndex; i++)
                    //        deviceAddress.Append(addressCurrent.GetAddressLine(i))
                    //            .AppendLine(",");

                    //    _address = deviceAddress.ToString();
                    //}
                    //else
                    //    _address = Constants.locationNotFound;

                    //IList<Address> source = geocoder.GetFromLocationName(_sourceAddress, 1);
                    //Address addressOrigin = source.FirstOrDefault();

                    //var coord1 = new RateLinx.Models.LatLng(addressOrigin.Latitude, addressOrigin.Longitude);
                    //var coord2 = new RateLinx.Models.LatLng(addressCurrent.Latitude, addressCurrent.Longitude);

                    //var distanceInRadius = Utils.HaversineDistance(coord1, coord2, Utils.DistanceUnit.Miles);
                }
            }
            catch
            {
                _address = Constants.locationNotFound;
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="provider"></param>
        /// <param name="status"></param>
        /// <param name="extras"></param>
        public void OnStatusChanged(string provider, Availability status, Bundle extras)
        {
            //TO DO:
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="provider"></param>
        public void OnProviderDisabled(string provider)
        {
            //TO DO:
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="provider"></param>
        public void OnProviderEnabled(string provider)
        {
            //TO DO:
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public class GPSServiceBinder : Binder
    {
        /// <summary>
        /// 
        /// </summary>
        public GPSSettings Service { get { return this.LocService; } }

        /// <summary>
        /// 
        /// </summary>
        protected GPSSettings LocService;

        /// <summary>
        /// 
        /// </summary>
        public bool IsBound { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        public GPSServiceBinder(GPSSettings service) { this.LocService = service; }
    }

   
    //public class GPSServiceConnection : Java.Lang.Object, IServiceConnection
    //{

    //    GPSServiceBinder _binder;
    //    /// <summary>
    //    /// 
    //    /// </summary>
    //    public event Action Connected;
    //    /// <summary>
    //    /// 
    //    /// </summary>
    //    /// <param name="binder"></param>
    //    public GPSServiceConnection(GPSServiceBinder binder)
    //    {
    //        try
    //        {
    //            if (binder != null)
    //                this._binder = binder;
    //        }
    //        catch
    //        {

    //        }
    //    }

    //    /// <summary>
    //    /// 
    //    /// </summary>
    //    /// <param name="name"></param>
    //    /// <param name="service"></param>
    //    //public void OnServiceConnected(ComponentName name, IBinder service)
    //    //{
    //    //    try
    //    //    {
    //    //        GPSServiceBinder serviceBinder = (GPSServiceBinder)service;
    //    //        if (serviceBinder != null)
    //    //        {
    //    //            this._binder = serviceBinder;
    //    //            this._binder.IsBound = true;
    //    //            serviceBinder.Service.StartLocationUpdates();
    //    //            if (Connected != null)
    //    //                Connected.Invoke();
    //    //        }
    //    //    }
    //    //    catch
    //    //    {

    //    //    }
    //    //}

    //    /// <summary>
    //    /// 
    //    /// </summary>
    //    /// <param name="name"></param>
    //    public void OnServiceDisconnected(ComponentName name)
    //    {
    //        try
    //        {
    //            this._binder.IsBound = false;
    //        }
    //        catch
    //        {

    //        }
    //    }
    //}

}
