﻿using System;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Locations;
using RateLinx.Helper;
using RateLinx.Droid.Activities;

namespace RateLinx.Droid.GoogleMapServices
{
    /// <summary>
    ///GPSService meta tag class
    /// </summary>
    [Service]
    public class GPSServiceSettings : Service, ILocationListener
    {

        UpdateShipmentStatusActivity objUpdateShipmentStatusActivity = null;
        NonDispatchUpdateTracking objNonDispatchUpdateTracking = null;
        /// <summary>
        /// 
        /// </summary>
        private Location _currentLocation;
        //public static string chanelName = string.Empty;
        IBinder _binder;
        /// <summary>
        /// 
        /// </summary>
        protected LocationManager _locationManager = (LocationManager)Android.App.Application.Context.GetSystemService(LocationService);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="intent"></param>
        /// <returns></returns>
        public override IBinder OnBind(Intent intent)
        {
            _binder = new GPSLocationServiceBinder(this);
            return _binder;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="intent"></param>
        /// <param name="flags"></param>
        /// <param name="startId"></param>
        /// <returns></returns>
        public override StartCommandResult OnStartCommand(Intent intent, StartCommandFlags flags, int startId)
        {
            return StartCommandResult.Sticky;
        }

        /// <summary>
        /// 
        /// </summary>
        public string StartLocationUpdates(UpdateShipmentStatusActivity updateShipmentStatusActivity)
        {
            try
            {
                string result = string.Empty;
                if (updateShipmentStatusActivity != null)
                {
                    objUpdateShipmentStatusActivity = updateShipmentStatusActivity;
                }
                Criteria criteriaForGPSService = new Criteria
                {
                    //A constant indicating an approximate accuracy
                    Accuracy = Accuracy.Fine,//Fine
                    PowerRequirement = Power.High
                };
                var locationProvider = _locationManager.GetBestProvider(criteriaForGPSService, true);
                if (!string.IsNullOrEmpty(locationProvider))
                {
                    //if(locationProvider.Equals(LocationManager.GpsProvider))
                    //{
                    //}
                    _locationManager.RequestLocationUpdates(LocationManager.GpsProvider, 3000, 2, this);
                    _locationManager.RequestLocationUpdates(LocationManager.NetworkProvider, 3000, 2, this);

                    //_locationManager.RequestLocationUpdates(LocationManager.GpsProvider, 0, 0, this);
                    //_locationManager.RequestLocationUpdates(LocationManager.NetworkProvider, 0, 0, this);

                    result = locationProvider;
                }
                else
                {
                    result = locationProvider;
                }
                return result;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public string StartLocationUpdatesNonDispatch(NonDispatchUpdateTracking updateShipmentStatusActivity)
        {
            try
            {
                string result = string.Empty;
                if (updateShipmentStatusActivity != null)
                {
                    objNonDispatchUpdateTracking = updateShipmentStatusActivity;
                }
                Criteria criteriaForGPSService = new Criteria
                {
                    //A constant indicating an approximate accuracy
                    Accuracy = Accuracy.Fine,//Fine
                    PowerRequirement = Power.High
                };
                var locationProvider = _locationManager.GetBestProvider(criteriaForGPSService, true);
                if (!string.IsNullOrEmpty(locationProvider))
                {
                    //if(locationProvider.Equals(LocationManager.GpsProvider))
                    //{
                    //}
                    _locationManager.RequestLocationUpdates(LocationManager.GpsProvider, 3000, 2, this);
                    _locationManager.RequestLocationUpdates(LocationManager.NetworkProvider, 3000, 2, this);
                    // _locationManager.RequestLocationUpdates(locationProvider, 0, 0, this);
                    result = locationProvider;
                }
                else
                {
                    result = locationProvider;
                }
                return result;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public event EventHandler<LocationChangedEventArgs> LocationChanged = delegate { };

        /// <summary>
        /// 
        /// </summary>
        /// <param name="location"></param>
        public void OnLocationChanged(Location location)
        {
            try
            {
                _currentLocation = location;

                if (_currentLocation == null)
                {
                    CommanUtil.currLat = 0.0;
                    CommanUtil.currLong = 0.0;
                }
                else
                {
                    CommanUtil.currLat = _currentLocation.Latitude;
                    CommanUtil.currLong = _currentLocation.Longitude;
                    //var s = _currentLocation.Bearing;
                    if (objUpdateShipmentStatusActivity != null && objUpdateShipmentStatusActivity.HasWindowFocus == true && CommanUtil.isTrackingEnable)
                    {
                        if(_currentLocation.Accuracy<50.0 && _currentLocation.Speed<1.95)
                        {
                            //Still There is flatucation
                            if (CommanUtil.isAccuracyFine)
                            {
                                objUpdateShipmentStatusActivity.Publish(Convert.ToString(_currentLocation.Latitude + "," + _currentLocation.Longitude), true);
                            }
                        }
                        else
                        {
                            objUpdateShipmentStatusActivity.Publish(Convert.ToString(_currentLocation.Latitude + "," + _currentLocation.Longitude), true);
                        }
                    }
                    else if (objNonDispatchUpdateTracking != null && objNonDispatchUpdateTracking.HasWindowFocus == true && CommanUtil.isTrackingEnable)
                    {
                        if (_currentLocation.Accuracy < 50.0 && _currentLocation.Speed < 1.95)
                        {
                            //Still There is flatucation
                            if (CommanUtil.isAccuracyFine)
                            {
                                objNonDispatchUpdateTracking.Publish(Convert.ToString(_currentLocation.Latitude + "," + _currentLocation.Longitude), true);
                            }
                        }
                        else
                        {
                            objNonDispatchUpdateTracking.Publish(Convert.ToString(_currentLocation.Latitude + "," + _currentLocation.Longitude), true);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="provider"></param>
        /// <param name="status"></param>
        /// <param name="extras"></param>
        public void OnStatusChanged(string provider, Availability status, Bundle extras)
        {
            //TO DO:
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="provider"></param>
        public void OnProviderDisabled(string provider)
        {
            //TO DO:
            try
            {
                if (objUpdateShipmentStatusActivity != null)
                {
                    objUpdateShipmentStatusActivity.Publish(Convert.ToString(0.0 + "," + 0.0), false);
                }
                if (objNonDispatchUpdateTracking != null)
                {
                    objNonDispatchUpdateTracking.Publish(Convert.ToString(0.0 + "," + 0.0), false);
                }
            }
            catch
            {
                Console.WriteLine(Constants.strLocation);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="provider"></param>
        public void OnProviderEnabled(string provider)
        {
            //TO DO:
            try
            {
                if (objUpdateShipmentStatusActivity != null)
                {
                    StartLocationUpdates(objUpdateShipmentStatusActivity);
                }
                else if (objNonDispatchUpdateTracking != null)
                {
                    StartLocationUpdatesNonDispatch(objNonDispatchUpdateTracking);
                }
                else
                {
                    StartLocationUpdates(null);
                    StartLocationUpdatesNonDispatch(null);
                }
            }
            catch
            {
                Console.WriteLine(Constants.strLocation);
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public class GPSLocationServiceBinder : Binder
    {
        /// <summary>
        /// 
        /// </summary>
        public GPSServiceSettings Service { get { return this.LocService; } }

        /// <summary>
        /// 
        /// </summary>
        protected GPSServiceSettings LocService;

        /// <summary>
        /// 
        /// </summary>
        public bool IsBound { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        public GPSLocationServiceBinder(GPSServiceSettings service) { this.LocService = service; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class GPSLocationServiceConnection : Java.Lang.Object, IServiceConnection
    {

        GPSLocationServiceBinder _binder;
        /// <summary>
        /// 
        /// </summary>
        public event Action Connected;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="binder"></param>
        public GPSLocationServiceConnection(GPSLocationServiceBinder binder)
        {
            if (binder != null)
                this._binder = binder;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="service"></param>
        public void OnServiceConnected(ComponentName name, IBinder service)
        {
            GPSLocationServiceBinder serviceBinder = (GPSLocationServiceBinder)service;
            if (serviceBinder != null)
            {
                this._binder = serviceBinder;
                this._binder.IsBound = true;
                serviceBinder.Service.StartLocationUpdates(null);
                serviceBinder.Service.StartLocationUpdatesNonDispatch(null);
                if (Connected != null)
                    Connected.Invoke();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        public void OnServiceDisconnected(ComponentName name) { this._binder.IsBound = false; }
    }

}
