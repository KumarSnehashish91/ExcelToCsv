﻿using Newtonsoft.Json;

namespace RateLinx.Droid.ServiceModels
{
    /// <summary>
    ///     
    /// </summary>
   public class OrderHistoryColumns
    {
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "FieldName")]
        public string FieldName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "FieldType")]
        public string FieldType { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "Label")]
        public string Label { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "Format")]
        public string Format { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "Hidden")]
        public bool Hidden { get; set; }

    }
}