﻿using Newtonsoft.Json;

namespace RateLinx.Droid.ServiceModels
{
    /// <summary>
    /// 
    /// </summary>
   public class OrderHistoryResults
    {
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "Client ID")]
        public string ClientID { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "Loc ID")]
        public int LocID { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Mode { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "Rate Type")]
        public string RateType { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "Load Num")]
        public string LoadNum { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "Auction Status")]
        public string AuctionStatus { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "Rate Status")]
        public string RateStatus { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "Date Opened")]
        public string DateOpened { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "Rate Deadline")]
        public string RateDeadline { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "Ship From")]
        public string ShipFrom { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "Ship To")]
        public string ShipTo { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Pickup { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Reference { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "User Created")]
        public string UserCreated { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool isCheckBoxChecked { get; set; }
    }
}