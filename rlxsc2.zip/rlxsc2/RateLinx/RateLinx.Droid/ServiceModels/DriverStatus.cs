﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Gms.Maps.Model;

namespace RateLinx.Droid.ServiceModels
{
    /// <summary>
    /// 
    /// </summary>
    public class DriverStatus
    {
        
    }

    /// <summary>
    /// 
    /// </summary>
    public class ShipmentStatus
    {
        /// <summary>
        /// 
        /// </summary>
        public string CurrentLocation { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public decimal DistanceTravelled { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string TimeTaken { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public decimal DistanceLeft { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string CurrentLat { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string CurrentLong { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipmentCurrStatus { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string BolNo { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string DriverID { get; set; }
    }
}