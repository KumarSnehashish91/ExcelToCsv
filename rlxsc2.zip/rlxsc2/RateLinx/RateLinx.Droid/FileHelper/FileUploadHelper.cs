using System;
using System.Collections.Generic;
using System.Net;
using StreamReference = System.IO.Stream;
using JavaFile = Java.IO.File;
using System.IO;

using System.Net.Http.Headers;
using System.Threading.Tasks;
using RateLinx.APIs;
using RateLinx.Models;
using Newtonsoft.Json;
using RateLinx.Helper;
using URI = Android.Net;
using Android.App;
using Provider = Android.Provider;
using Android.Database;
using Android.OS;
using System.Net.Http;
using System.IO.Compression;

namespace RateLinx.Droid.FileHelper
{
    /// <summary>
    /// FileUploadHelper Meta class
    /// </summary>
    public class FileUploadHelper
    {
        /// <summary>
        /// Variable
        /// </summary>
        static RegisterDevice objDevice = null;

        /// <summary>
        /// Function To register device for notification service
        /// </summary>
        /// <returns></returns>
        public static async Task<string> FnRegisterDevice(bool notificationEnabled, string deviceToken)
        {
            try
            {
                string requestBody = string.Empty;
                string result = string.Empty;
                ServiceHelper objSevice = new ServiceHelper();
                //Get device Details
                objDevice = GetDeviceInfo();
                objDevice.App = "ShipReq";
                objDevice.ServerToken = deviceToken;
                objDevice.Enabled = notificationEnabled;
                //serialize the request
                requestBody = JsonConvert.SerializeObject(objDevice);
                result = await objSevice.PostRequestJson(requestBody, APIMethods.autoPushReg, CommanUtil.tokenNo, true);
                if (!string.IsNullOrEmpty(result))
                {
                    var Jobject = JsonConvert.DeserializeObject(result);
                    if (Jobject.ToString() == Constants.strSuccess)
                    {
                        result = Constants.strSuccess;
                    }
                    else
                    {
                        result = Constants.strException;
                    }
                }
                else
                {
                    result = Constants.strException;
                }
                objDevice = null;
                return result;
            }
            catch
            {
                 Console.Write(Constants.strErrorOccured);
                return null;
            }
        }

        /// <summary>
        /// Creating JSON Request
        /// </summary>
        /// <param name="uploadResult">file uploaded result</param>
        /// <returns></returns>
        public static string UploadsJsonRequest(string uploadResult)
        {
            try
            {
                string jsonRequest = string.Empty;
                Dictionary<string, string> objResponse = JsonConvert.DeserializeObject<Dictionary<string, string>>(uploadResult);
                foreach (KeyValuePair<string, string> objKVP in objResponse)
                {
                    jsonRequest += "{\"SaveAsFilename\":\"" + objKVP.Key + "\",\"ULFilename\":\"" + objKVP.Value + "\"}";
                }
                objResponse = null;
                return jsonRequest;
            }
            catch
            {
                 Console.Write(Constants.strErrorOccured);
                return null;
            }
        }

        /// <summary>
        /// Get Image Name And Path
        /// </summary>
        /// <param name="uri">Image URL</param>
        /// <param name="context">Activity context</param>
        /// <returns></returns>
        public static string GetFilePath(URI.Uri uri, Activity context)
        {
            try
            {
                string androidDownloadsPath = Android.OS.Environment.GetExternalStoragePublicDirectory(
            Android.OS.Environment.DirectoryDownloads).ToString();
                string result = string.Empty;
                if (uri.Host.Contains("downloads"))
                {
                    ICursor cursor1 = context.ContentResolver.Query(uri, null, null, null, null);
                    if (cursor1 == null)
                    {
                        result = uri.Path;
                    }
                    else
                    {
                        int column_index = cursor1.GetColumnIndexOrThrow(Provider.OpenableColumns.DisplayName);
                        cursor1.MoveToFirst();
                        result = androidDownloadsPath + "/" + cursor1.GetString(column_index);
                        cursor1.Close();
                    }
                }
                if (string.IsNullOrEmpty(result))
                {
                    string[] proj = new[] { Android.Provider.MediaStore.Images.Media.InterfaceConsts.Data };
                    using (ICursor cursor = context.ContentResolver.Query(uri, proj, null, null, null))
                    {
                        if (cursor != null)
                        {
                            int columnIndex = cursor.GetColumnIndexOrThrow(Android.Provider.MediaStore.Images.Media.InterfaceConsts.Data);
                            cursor.MoveToFirst();
                            result = cursor.GetString(columnIndex);
                        }
                        else
                        {
                            result = uri.Path;
                        }
                    }
                }
                if (string.IsNullOrEmpty(result))
                {
                    ICursor cursor = context.ContentResolver.Query(uri, null, null, null, null);
                    cursor.MoveToFirst();
                    string document_id = cursor.GetString(0);
                    if (document_id.Contains(":"))
                    {
                        document_id = document_id.Split(':')[1];//document_id.Substring(document_id.LastIndexOf(":") + 1);//
                    }
                    cursor.Close();
                    if (!document_id.Contains("/"))
                    {
                        string selection = Android.Provider.MediaStore.Images.Media.InterfaceConsts.Id + " =? ";
                        cursor = context.ContentResolver.Query(Provider.MediaStore.Images.Media.ExternalContentUri, null, selection, new string[] { document_id }, null);
                        cursor.MoveToFirst();
                        var columnIndex = cursor.GetColumnIndex(Provider.MediaStore.Images.Media.InterfaceConsts.Data);
                        result = cursor.GetString(columnIndex);
                        cursor.Close();
                    }
                    else
                    {
                        result = document_id;
                    }
                }
                return result;
            }
            catch
            {
                return null;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="uri"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public static string GetPathToImage(URI.Uri uri, Activity context)
        {
            
            try
            {
                string path = null;
                string doc_id = "";
                using (var c1 = context.ContentResolver.Query(uri, null, null, null, null))
                {
                    c1.MoveToFirst();
                    String document_id = c1.GetString(0);
                    doc_id = document_id.Substring(document_id.LastIndexOf(":") + 1);
                }

                // The projection contains the columns we want to return in our query.
                string selection = Android.Provider.MediaStore.Images.Media.InterfaceConsts.Id + " =? ";
                using (var cursor = context.ManagedQuery(Provider.MediaStore.Images.Media.ExternalContentUri, null, selection, new string[] { doc_id }, null))
                {
                    if (cursor == null) return path;
                    var columnIndex = cursor.GetColumnIndexOrThrow(Provider.MediaStore.Images.Media.InterfaceConsts.Data);
                    cursor.MoveToFirst();
                    path = cursor.GetString(columnIndex);
                }
                return path;
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
                return null;
            }
        }


        /// <summary>
        /// Convert File Into Bytes
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public static byte[] ConvertFileIntoByte(string filePath)
        {
            try
            {
                byte[] bytes = null;
                FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                // Create a byte array of file stream length
                bytes = new byte[fs.Length];
                //Read block of bytes from stream into the byte array
                fs.Read(bytes, 0, System.Convert.ToInt32(fs.Length));
                //MemoryStream output = new MemoryStream();
                //using (DeflateStream dstream = new DeflateStream(output, CompressionMode.Compress))
                //{
                //    dstream.Write(bytes, 100, bytes.Length);
                //}
                //Close the File Stream
                fs.Close();
                return bytes;
            }
            catch(Exception ex)
            {
                 Console.Write(Constants.strErrorOccured);
                return null;
            }
        }

        /// <summary>
        /// Getting file name from file path
        /// </summary>
        /// <param name="filePath">Required Selected file path</param>
        /// <returns></returns>
        public static string GetFileName(string filePath)
        {
            try
            {
                string fileName = string.Empty;
                int cut = filePath.LastIndexOf('/');
                if (cut != -1)
                {
                    fileName = filePath.Substring(cut + 1);
                }
                else
                {
                    fileName = filePath;
                }
                return fileName;
            }
            catch
            {
                 Console.Write(Constants.strErrorOccured);
                return null;
            }
        }

        /// <summary>
        /// Get Device Details
        /// </summary>
        /// <returns></returns>
        public static RegisterDevice GetDeviceInfo()
        {
            try
            {
                objDevice = new RegisterDevice();
#if __IOS__
                    // id = UIKit.UIDevice.CurrentDevice.IdentifierForVendor.AsString();
#else
                // FYI won't work on devices prior to Gingerbread 2.3
                objDevice.DeviceID = Build.Serial;
                objDevice.DeviceType = "Android";
                objDevice.DeviceVer = Build.VERSION.Release;
                // int apiVersion = (int)Build.VERSION.SdkInt

#endif
                return objDevice;
            }
            catch
            {
                 Console.Write(Constants.strErrorOccured);
                return null;
            }
        }

        /// <summary>
        /// File Upload functionality
        /// </summary>
        /// <param name="bytes"></param>
        /// <param name="file"></param>
        /// <param name="strMethod"></param>
        /// <param name="token"></param>
        /// <param name="isHeader"></param>
        /// <returns></returns>
        public async Task<string> PostFiles(byte[] bytes, JavaFile file, string strMethod, string token, bool isHeader)
        {
            try
            {
                string serviceUri = string.Empty;
                string content = string.Empty;
                string boundary = "---8d0f01e6b3b5dafaaadaad";
                serviceUri = APIBaseUri.baseUri + strMethod;
                using (ByteArrayContent fileContent = new ByteArrayContent(bytes))
                {
                    fileContent.Headers.ContentType = MediaTypeHeaderValue.Parse("application/octet-stream");
                    //fileContent.Headers.Add("Authorization", "bearer" + token);
                    fileContent.Headers.ContentDisposition = new ContentDispositionHeaderValue("form-data")
                    {
                        FileName = file.Name
                    };
                    using (MultipartFormDataContent multipartContent = new MultipartFormDataContent(boundary))
                    {
                        multipartContent.Add(fileContent);
                        //multipartContent.Headers.Add("Authorization", "bearer " + token);
                        using (HttpClient httpClient = new HttpClient())
                        {
                            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", token);
                            using (HttpResponseMessage response = await httpClient.PostAsync(serviceUri, multipartContent))
                            {
                                if (response.IsSuccessStatusCode)
                                {
                                    content = await response.Content.ReadAsStringAsync();
                                    response.Dispose();
                                    return content;
                                }
                                else
                                {
                                    return null;
                                }
                            }
                        }
                    }
                }
            }
            catch (WebException ex)
            {
                WebResponse response = ex.Response;
                string text;
                if (ex.Status == WebExceptionStatus.Timeout)
                {
                    // Handle timeout exception
                    text = "{error:\"nullResponse\"," + Constants.strErrorMessage + ":\"" + Constants.strTimeOut + ".\"}";
                    return text;
                }

                else if (response == null)
                {
                    text = "{error:\"nullResponse\","+Constants.strErrorMessage+":\""+Constants.strNetwork + ".\"}";
                    return text;
                }
                else
                {
                    HttpWebResponse httpResponse = (HttpWebResponse)response;
                    Console.WriteLine("Error code: {0}", httpResponse.StatusCode);
                    StreamReference data = response.GetResponseStream();

                    var reader = new StreamReader(data);
                    text = reader.ReadToEnd();
                    return text;
                }
            }

        }
    }
}