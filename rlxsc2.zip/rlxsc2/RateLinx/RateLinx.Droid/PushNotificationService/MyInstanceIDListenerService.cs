using Android.App;
using Android.Content;
using Android.Gms.Iid;
using Firebase.Iid;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;

namespace RateLinx.Droid.PushNotificationService
{
    /// <summary>
    /// Register InstanceIDListenerService with token
    /// </summary>
    [Service]
    [IntentFilter(new[] {
        "com.google.firebase.INSTANCE_ID_EVENT"
    })]
    public class MyInstanceIDListenerService : FirebaseInstanceIdService
    {
        const string TAG = "MyFirebaseIIDService";
        /// <summary>
        /// 
        /// </summary>
        public override void OnTokenRefresh()
        {
            var refreshedToken = FirebaseInstanceId.Instance.Token;
            Constants.deviceToken = refreshedToken;
            Utility.sharedPreferences.Edit().PutString("FCMToken", refreshedToken).Commit();
            Constants.FCMToken = refreshedToken;
            var intent = new Intent(this, typeof(RegistrationIntentService));
            StartService(intent);
           
        }
    }
}