using System;
using Android.App;
using Android.Content;
using Android.Gms.Iid;
using Android.Gms.Gcm;
using RateLinx.Helper;
using System.Threading.Tasks;
using RateLinx.Droid.Utilities;
using RateLinx.Droid.FileHelper;
using Task = System.Threading.Tasks.Task;
using Firebase.Iid;
using Android.Util;
using Firebase;

namespace RateLinx.Droid.PushNotificationService
{
    /// <summary>
    /// RegistrationIntentService
    /// </summary>
    [Service(Exported = false)]
    public class RegistrationIntentService : IntentService
    {
        static object locker = new object();
        /// <summary>
        /// 
        /// </summary>
        public string SenderID = Constants.SenderID;

        /// <summary>
        /// 
        /// </summary>
        public RegistrationIntentService()
            : base("RegistrationIntentService")
        {
           
        }

        /// <summary>
        /// handle notification
        /// </summary>
        /// <param name="intent"></param>
        protected override void OnHandleIntent(Intent intent)
        {
            try
            {
                lock (locker)
                {
                    //string token = GetToken();//instanceID.GetToken(SenderID, GoogleCloudMessaging.InstanceIdScope, null);
                    //if (!string.IsNullOrEmpty(token))
                    //{
                    //    SendRegistrationToAppServer(token);
                    //    Subscribe(token);
                    //    if (!string.IsNullOrEmpty(token))
                    //    {
                    //        SaveDeviceToken(token);
                    //    }
                    //}


                    //FirebaseApp.InitializeApp(this);
                    //Task.Run(() =>
                    //{
                    //    try
                    //    {
                    //        FirebaseApp.InitializeApp(this);
                    //        var instanceid = FirebaseInstanceId.Instance;
                    //        instanceid.DeleteInstanceId();
                    //        Log.Debug("TAG", "{0} {1}", instanceid.Token, instanceid.GetToken(GetString(Convert.ToInt32(Constants.SenderID)), Firebase.Messaging.FirebaseMessaging.InstanceIdScope));
                    //        //Constants.token = instanceid.GetToken(GetString(Convert.ToInt32(Constants.SenderID)), Firebase.Messaging.FirebaseMessaging.InstanceIdScope);
                    //    }
                    //    catch (Exception ex)
                    //    {

                    //    }
                    //});
                    string token = Utility.sharedPreferences.GetString("FCMToken", "");
                    if (!string.IsNullOrEmpty(token))
                    {
                        SendRegistrationToAppServer(token);
                        Subscribe(token);
                        if (!string.IsNullOrEmpty(token))
                        {
                            SaveDeviceToken(token);
                        }
                    }
                }
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="token"></param>
        private void SendRegistrationToAppServer(string token)
        {
            //// Add custom implementation here as needed.
            //// save the value to send it to  server to manage the notifications
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="token"></param>
        private void Subscribe(string token)
        {
            try
            {
                // subscribe to a topic group
                var pubSub = GcmPubSub.GetInstance(this);
                pubSub.Subscribe(token, "/topics/global", null);
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
            }
        }

        /// <summary>
        /// method is used to save device token into database
        /// </summary>
        /// <param name="deviceToken"></param>
        public async Task<string> SaveDeviceToken(string deviceToken)
        {
            string strResult = string.Empty;
            try
            {
                //Utility.sharedPreferences.Edit().PutString("deviceToken", deviceToken).Commit();
                strResult = await FileUploadHelper.FnRegisterDevice(CommanUtil.isPushAllowed, deviceToken);
                return strResult;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Register token in GCM
        /// </summary>
        /// <returns></returns>
        public string GetToken()
        {
            try
            {
                var instanceID = InstanceID.GetInstance(this);
                var token = instanceID.GetToken(SenderID, GoogleCloudMessaging.InstanceIdScope, null);
                return token;
            }
            catch
            {
                return null;
            }
        }
    }
}