using System;
using Android.Content;
using Android.Gms.Common;
using RateLinx.Helper;

namespace RateLinx.Droid.PushNotificationService
{
    /// <summary>
    /// RegisterService meta tag
    /// </summary>
    public static class RegisterService
    {
        /// <summary>
        /// Is Google Paly Service available or not
        /// </summary>
        /// <returns></returns>
        public static bool IsPlayServicesAvailable(Context context)
        {
            try
            {
                string msgText;
                int resultCode = GoogleApiAvailability.Instance.IsGooglePlayServicesAvailable(context);
                if (resultCode != ConnectionResult.Success)
                {
                    if (GoogleApiAvailability.Instance.IsUserResolvableError(resultCode))
                    {
                        msgText = GoogleApiAvailability.Instance.GetErrorString(resultCode);
                    }
                    else
                    {
                        msgText = string.Empty;
                    }
                    return false;
                }
                else
                {
                    msgText = string.Empty;
                    return true;
                }
            }
            catch
            {
                 Console.Write(Constants.strErrorOccured);
                return false;
            }
        }


    }
}