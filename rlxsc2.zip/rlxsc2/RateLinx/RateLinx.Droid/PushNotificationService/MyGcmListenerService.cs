using System;
using System.Collections.Generic;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Gms.Gcm;
using RateLinx.Droid.Activities;
using RateLinx.Droid.Utilities;
using Java.Util;
using RateLinx.Helper;
using Android.Graphics;
using Firebase.Messaging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Linq;
using Android.Support.V4.App;
using Android.Widget;

namespace RateLinx.Droid.PushNotificationService
{
    /// <summary>
    /// Push Notification Service
    /// </summary>
    //[Service(Exported = false), IntentFilter(new[] { "com.google.android.c2dm.intent.RECEIVE" })]
    [Service]
    [IntentFilter(new[] { "com.google.firebase.MESSAGING_EVENT" })]
    public class MyGcmListenerService : FirebaseMessagingService
    {
        /// <summary>
        /// 
        /// </summary>
        public MyGcmListenerService()
        {

        }

        private static int countNotification = 0;
        /// <summary>
        /// 
        /// </summary>
        public static string NOTIFICATION_CHANNEL_ID = "10001";
        /// <summary>
        /// On Message Receive
        /// </summary>
        /// <param name="data"></param>
        public override void OnMessageReceived(RemoteMessage data)
        {
            try
            {
                bool isForeGround = AppInForeground();
                if (isForeGround)
                {
                    string orderID = string.Empty;
                    string nameOfJob = string.Empty;
                    JObject objMsg = JObject.Parse(data.GetNotification().Body);
                    string notificationMsg = objMsg["message"].ToString();
                    //Getting orderId and nameOfJob from notification data
                    orderID = notificationMsg.Split('/').Last();
                    nameOfJob = orderID.Split('-').Last().Trim();
                    orderID = orderID.Split('-').First();
                    notificationMsg = notificationMsg.Split('/').First();
                    Intent intent = new Intent(Constants.strMessageReceiver);
                    // If desired, pass some values to the broadcast receiver.
                    Utility.notificationCount = 0;
                    intent.PutExtra(notificationMsg, data);

                    Android.Support.V4.Content.LocalBroadcastManager.GetInstance(this).SendBroadcast(intent);
                }
                else
                {
                    //SendNotification(data.GetNotification().Body);
                }
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
            }
        }
      
        /// <summary>
        /// 
        /// </summary>
        /// <param name="intent"></param>
        public override void HandleIntent(Intent intent)
        {
            try
            {

                var extra = intent.Extras;
                var data = extra.Get("gcm.notification.message").ToString();
                Constants.message = extra.Get("gcm.notification.message").ToString();
                Constants.title = extra.Get("gcm.notification.title").ToString();
                Constants.url = extra.Get("gcm.notification.url").ToString();
                Bundle bundle = new Bundle();
                //JObject objMsg = JObject.Parse(data);
                //string notificationMsg = objMsg["message"].ToString();
                bundle.PutString("message", extra.Get("gcm.notification.message").ToString());
                bundle.PutString("title", extra.Get("gcm.notification.title").ToString());
                bundle.PutString("url", extra.Get("gcm.notification.url").ToString());

                //Getting orderId and nameOfJob from notification data
                //orderID = notificationMsg.Split('/').Last();
                //nameOfJob = orderID.Split('-').Last().Trim();
                //orderID = orderID.Split('-').First();
                //notificationMsg = notificationMsg.Split('/').First();
                Intent intent1 = new Intent(Constants.strMessageReceiver);
                // If desired, pass some values to the broadcast receiver.
                Utility.notificationCount = 0;
                intent1.PutExtra("message", bundle);
                Constants.notificationMsg = string.Empty;

                if (!string.IsNullOrEmpty(extra.Get("gcm.notification.message").ToString()))
                {
                    Constants.notificationMsg = extra.Get("gcm.notification.message").ToString();
                }
                bool isForeGround = AppInForeground();
                if (isForeGround)
                {                 

                    Android.Support.V4.Content.LocalBroadcastManager.GetInstance(this).SendBroadcast(intent1);
                }
                else
                {
                    SendNotification(intent1);
                }
            }
            catch
            {
                //Toast.MakeText(this, Constants.strErrorOccured, ToastLength.Short).Show();
            }
        }

        /// <summary>
        /// Application is in Background or in ForGround
        /// </summary>
        /// <returns></returns>
        public bool AppInForeground()
        {
            try
            {
                ArrayList runningactivities = new ArrayList();
                Context context = Application.Context;
                ActivityManager activityManager = (ActivityManager)context.GetSystemService(ActivityService);

                IList<ActivityManager.RunningAppProcessInfo> appProcesses = activityManager.RunningAppProcesses;
                if (appProcesses == null)
                {
                    return false;
                }
                string packageName = context.PackageName;
                foreach (ActivityManager.RunningAppProcessInfo appProcess in appProcesses)
                {
                    if (appProcess.Importance == Importance.Foreground && appProcess.ProcessName == packageName)
                    {
                        return true;
                    }
                }
                return false;
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
                return false;
            }
        }

        /// <summary>
        /// this method is used to create UI for notification message 
        /// </summary>
        ///// <param name="data"></param>
        private void SendNotification( Intent intent)
        {
            

            try
            {
                var extra = intent.Extras;
                var data = intent.GetBundleExtra("message");
                Bundle bundle = new Bundle();
                
               
                string notificationMsg = Constants.message;
                string notificationTitle = Constants.title;


                bundle.PutString("message", notificationMsg);
                bundle.PutString("title", Constants.title);
                bundle.PutString("url", Constants.url);

                //Intent intent = new Intent();

               string clientID = Constants.url.Split('#')[2];
               string loadNum = Constants.url.Split('#')[1];
               string slideNo = Constants.url.Split('#')[3];
                string compositValue = clientID + "|" + loadNum + "|" + slideNo;
                intent = new Intent(this, typeof(LoginActivity));
                intent.AddFlags(ActivityFlags.ClearTop);
                intent.PutExtra("background_Notification", bundle);
                Utility.sharedPreferences.Edit().PutString("notification_compositekey", compositValue).Commit();
                //intent.PutExtra("data", bundle);
               
                var pendingIntent = PendingIntent.GetActivity(this, 0, intent, PendingIntentFlags.OneShot);


                var notificationBuilder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
                .SetSmallIcon(GetNotificationIcon())
                .SetStyle(new NotificationCompat.BigTextStyle().BigText(notificationMsg))
                .SetContentTitle(notificationTitle)
                .SetAutoCancel(true)
                // .AddAction()
                .SetContentIntent(pendingIntent);
                var notificationManager = (NotificationManager)GetSystemService(NotificationService);
                if (((int)Build.VERSION.SdkInt) >= 26)
                {
                    var importance = NotificationImportance.High;
                    NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, "NOTIFICATION_CHANNEL_NAME", importance);
                    notificationChannel.EnableLights(true);
                    notificationChannel.LightColor = Color.Red;
                    if (notificationManager != null)
                    {
                        notificationBuilder.SetChannelId(NOTIFICATION_CHANNEL_ID);
                    }
                    notificationManager.CreateNotificationChannel(notificationChannel);
                }
                notificationManager.Notify(countNotification++, notificationBuilder.Build());
            }
            catch (Exception ex)
            {
                Console.Write("error: " + ex.ToString());
            }

        }
        /// <summary>
        /// Get Notification Icon
        /// </summary>
        /// <returns></returns>
        public int GetNotificationIcon()
        {
            Boolean useWhiteIcon = (10 >= 20);
            return useWhiteIcon ? Droid.Resource.Drawable.Icon : Droid.Resource.Drawable.Icon;
        }
    }
}