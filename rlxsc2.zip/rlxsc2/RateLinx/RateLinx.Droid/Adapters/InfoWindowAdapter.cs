﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.Gms.Maps;
using Android.Gms.Maps.Model;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace RateLinx.Droid.Adapters
{
    class InfoWindowAdapter : Java.Lang.Object,GoogleMap.IInfoWindowAdapter
    {
        LayoutInflater inflater;
        public Context context;
        View view;
        public InfoWindowAdapter(Context context)
        {
            this.context = context;
        }
        public View GetInfoContents(Marker marker)
        {
            throw new NotImplementedException();
        }

        public View GetInfoWindow(Marker marker)
        {
            inflater = (LayoutInflater)context.GetSystemService(Context.LayoutInflaterService);
            view = inflater.Inflate(Resource.Layout.InfoWindowLayout, null);
            TextView title = (TextView)view.FindViewById(Resource.Id.title);
            TextView subtitle = (TextView)view.FindViewById(Resource.Id.lnrAddressHead); /*title.setText(marker.getTitle());*/
            title.SetText(marker.Title, TextView.BufferType.Normal);
            subtitle.SetText(marker.Snippet, TextView.BufferType.Normal);
            return view;
        }
    }
}