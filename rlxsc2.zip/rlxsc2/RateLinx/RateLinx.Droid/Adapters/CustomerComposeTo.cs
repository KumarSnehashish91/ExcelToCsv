using System;
using System.Collections.Generic;
using Android.App;
using Android.Views;
using Android.Widget;
using RateLinx.Models;
using RateLinx.Helper;
using System.Runtime.InteropServices;
using RateLinx.Droid.Utilities;

namespace RateLinx.Droid.Adapters
{
    /// <summary>
    /// Meta Tag of the Class
    /// </summary>
    [ComVisible(false)]
    public class CustomerComposeTo
    {

        /// <summary>
        /// Adapter to hold the Recent shipmets properties
        /// </summary>
        [ComVisible(true)]
        public class AdapterCustomerComposeTo : BaseAdapter<CustomerConversationList>
        {
            #region Declaration of variable
            /// <summary>
            /// List of the Recent Shipments
            /// </summary>
            public List<CustomerConversationList> lstCustomerConversationList;
            Activity context;
            TextView txtComposeTo;
            CheckBox chkBox;
            View viewLine;
            #endregion

            /// <summary>
            /// 
            /// </summary>
            /// <param name="context"></param>
            /// <param name="lstCustomerConversationList"></param>
            public AdapterCustomerComposeTo(Activity context, List<CustomerConversationList> lstCustomerConversationList)
                : base()
            {
                this.context = context;
                this.lstCustomerConversationList = lstCustomerConversationList;
            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="position"></param>
            /// <returns></returns>
            public override long GetItemId(int position)
            {
                return position;
            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="position"></param>
            /// <returns></returns>
            public override CustomerConversationList this[int position]
            {
                get
                {
                    return lstCustomerConversationList[position];
                }
            }

            /// <summary>
            /// 
            /// </summary>
            public override int Count
            {
                get { return lstCustomerConversationList.Count; }
            }

            /// <summary>
            /// Get the View Controls and bind them
            /// </summary>
            /// <param name="position"></param>
            /// <param name="convertView"></param>
            /// <param name="parent"></param>
            /// <returns></returns>
            public override View GetView(int position, View convertView, ViewGroup parent)
            {
                View view = convertView;
                try
                {
                    view = context.LayoutInflater.Inflate(Resource.Layout.ComposeToLayout, null);
                    //Get the controls
                    txtComposeTo = view.FindViewById<TextView>(Resource.Id.txtComposeTo);
                    chkBox = view.FindViewById<CheckBox>(Resource.Id.chkBox);
                    viewLine = view.FindViewById<View>(Resource.Id.viewLine);
                    //
                    txtComposeTo.Text = lstCustomerConversationList[position].Value;
                    chkBox.CheckedChange += delegate
                     {
                         CheckAndUncheck(position, view);
                     };
                    chkBox.Checked = lstCustomerConversationList[position].Action;
                    if (lstCustomerConversationList.Count - 1 == position)
                    {
                        viewLine.Visibility = ViewStates.Gone;
                    }
                    else
                    {
                        viewLine.Visibility = ViewStates.Visible;
                    }

                    return view;
                }
                catch(Exception ex)
                {
                    Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                    Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                    return null;
                }
            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="position"></param>
            /// <param name="chkView"></param>
            private void CheckAndUncheck(int position, View chkView)
            {
                try
                {
                    chkBox = chkView.FindViewById<CheckBox>(Resource.Id.chkBox);
                    if (chkBox.Checked)
                    {
                        lstCustomerConversationList[position].Action = true;
                    }
                    else
                    {
                        lstCustomerConversationList[position].Action = false;
                    }
                }
                catch
                {
                    throw;
                }
            }

        }
    }
}