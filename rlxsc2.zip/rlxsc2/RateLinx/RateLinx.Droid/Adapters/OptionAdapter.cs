using System;
using System.Collections.Generic;
using Android.App;
using Android.Views;
using Android.Widget;
using RateLinx.Models;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;

namespace RateLinx.Droid.Adapters
{
    /// <summary>
    ///Meta Tag of Option data in shipments 
    /// </summary>
    public class OptionAdapter
    {
        /// <summary>
        /// Adapter to hold the option shipmets properties
        /// </summary>
        public class OptionAdapterShipments : BaseAdapter<SS>
        {
            #region Declaration of variable
            /// <summary>
            /// List of the Options in Shipments
            /// </summary>
            public List<SS> lstSSShipments;
            Activity context;
            TextView txtOptionID, txtOptionValue;
            LinearLayout linrOptionLayout;
            Utility objUtility = null;
            #endregion

            /// <summary>
            /// 
            /// </summary>
            /// <param name="context"></param>
            /// <param name="lstSSShipments"></param>
            public OptionAdapterShipments(Activity context, List<SS> lstSSShipments)
                : base()
            {
                this.context = context;
                this.lstSSShipments = lstSSShipments;
            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="position"></param>
            /// <returns></returns>
            public override long GetItemId(int position)
            {
                return position;
            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="position"></param>
            /// <returns></returns>
            public override SS this[int position]
            {
                get
                {
                    return lstSSShipments[position];
                }
            }

            /// <summary>
            /// 
            /// </summary>
            public override int Count
            {
                get { return lstSSShipments.Count; }
            }

            /// <summary>
            /// Get the View Controls and bind them
            /// </summary>
            /// <param name="position"></param>
            /// <param name="convertView"></param>
            /// <param name="parent"></param>
            /// <returns></returns>
            public override View GetView(int position, View convertView, ViewGroup parent)
            {
                View view = convertView;
                try
                {
                    if (view == null)
                        view = context.LayoutInflater.Inflate(Resource.Layout.OptionsLayout, null);
                    //Get the controls
                    txtOptionID = view.FindViewById<TextView>(Resource.Id.txtOptionID);
                    txtOptionValue = view.FindViewById<TextView>(Resource.Id.txtOptionValue);
                    linrOptionLayout = view.FindViewById<LinearLayout>(Resource.Id.linrOptionLayout);
                    //Assign Values from API response
                    txtOptionID.Text = lstSSShipments[position].ID;
                    txtOptionValue.Text = lstSSShipments[position].Value;
                    //For Changing Layout Color Dynamically
                    objUtility = new Utility();
                    objUtility.ChangeLayoutColor(linrOptionLayout, view, position);
                    return view;
                }
                catch(Exception ex)
                {
                    Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                    Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                    return null;
                }
            }
        }
    }
}