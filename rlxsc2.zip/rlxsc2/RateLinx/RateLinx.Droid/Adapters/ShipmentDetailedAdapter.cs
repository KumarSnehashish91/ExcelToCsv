using System;
using System.Collections.Generic;
using Android.Support.V4.App;
using V4App = Android.Support.V4.App;
using Java.Lang;
using RateLinx.Helper;
using RateLinx.Droid.Fragments;

namespace RateLinx.Droid.Adapters
{
    /// <summary>
    /// Shipment Detail Adapter 
    /// </summary>
    public class ShipmentDetailedAdapter : FragmentPagerAdapter
    {
        /// <summary>
        ///  Fragment Manager List
        /// </summary>
        private List<V4App.Fragment> mFragmentList = new List<V4App.Fragment>();
        /// <summary>
        ///  Fragment Title List
        /// </summary>
        private List<string> mFragmentTitleList = new List<string>();
        private V4App.FragmentManager childFragmentManager;

        /// <summary>
        /// Shipment Detail Adapter
        /// </summary>
        /// <param name="manager"></param>
        public ShipmentDetailedAdapter(V4App.FragmentManager manager) : base(manager)
        {
            this.childFragmentManager = manager;
        }

        /// <summary>
        /// 
        /// </summary>
        public override int Count
        {
            get
            {
                return mFragmentList.Count;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="postion"></param>
        /// <returns></returns>
        public override V4App.Fragment GetItem(int postion)
        {
            return mFragmentList[postion];
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public override ICharSequence GetPageTitleFormatted(int position)
        {
            return new Java.Lang.String(mFragmentTitleList[position].ToLower());// display the title
        }

        /// <summary>
        /// Add Fragment
        /// </summary>
        /// <param name="fragment"></param>
        /// <param name="title"></param>
        public void AddFragment(V4App.Fragment fragment, string title)
        {
            try
            {
                mFragmentList.Add(fragment);
                mFragmentTitleList.Add(title);
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
            }
        }

        //PositionNone

        /// <summary>
        /// 
        /// </summary>
        /// <param name="objectValue"></param>
        /// <returns></returns>
        public override int GetItemPosition(Java.Lang.Object objectValue)
        {
            return PositionNone;
        }
    }
}