using System;
using System.Collections.Generic;
using Android.App;
using Android.Content;
using Android.Views;
using Android.Widget;
using RateLinx.Models;
using RateLinx.Droid.Activities;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;
using System.Runtime.InteropServices;

namespace RateLinx.Droid.Adapters
{
    /// <summary>
    /// Meta Tag Awarded Shipment Utility
    /// </summary>
    [ComVisible(false)]
    public class AwardedShipmentAdapter
    {
        /// <summary>
        /// Adapter to hold the Recent shipmets properties
        /// </summary>
        [ComVisible(true)]
        public class AdapterAwardedShipments : BaseAdapter<AwardedShipments>
        {
            #region Declaration of variable
            /// <summary>
            /// List of the Recent Shipments
            /// </summary>
            public List<AwardedShipments> lstAwardedShipments;
            /// <summary>
            /// 
            /// </summary>
            public Activity context;
            TextView txtBolNum, txtViewForValue, txtViewFromValue, txtViewToValue,
                txtViewPickupValue, txtViewDriverIDValue, txtViewStatusValue;
            RelativeLayout rltLayoutAwarded;
            LinearLayout lnrLayoutStatus;

            //Button btnAcceptShip, btnDenyShip, btnConfirm, btnCancel = null;
            string value = string.Empty;
            Intent objIntent = null;
            #endregion

            /// <summary>
            /// Method to bind data
            /// </summary>
            /// <param name="context"></param>
            /// <param name="lstAwardedShipments"></param>
            public AdapterAwardedShipments(Activity context, List<AwardedShipments> lstAwardedShipments)
                : base()
            {
                this.context = context;
                this.lstAwardedShipments = lstAwardedShipments;
            }
            /// <summary>
            /// Method to update list
            /// </summary>
            /// <param name="lstNewAwardedShipments"></param>
            public void UpdateList(List<AwardedShipments> lstNewAwardedShipments)
            {
                lstAwardedShipments.Clear();
                lstAwardedShipments.AddRange(lstNewAwardedShipments);
                NotifyDataSetChanged();
            }
            /// <summary>
            /// 
            /// </summary>
            /// <param name="position"></param>
            /// <returns></returns>
            public override long GetItemId(int position)
            {
                return position;
            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="position"></param>
            /// <returns></returns>
            public override AwardedShipments this[int position]
            {
                get
                {
                    return lstAwardedShipments[position];
                }
            }

            /// <summary>
            /// 
            /// </summary>
            public override int Count
            {
                get { return lstAwardedShipments.Count; }
            }


            /// <summary>
            /// Get the View Controls and bind them
            /// </summary>
            /// <param name="position"></param>
            /// <param name="convertView"></param>
            /// <param name="parent"></param>
            /// <returns></returns>
            public override View GetView(int position, View convertView, ViewGroup parent)
            {
                View view = convertView;
                try
                {
                    //if (view == null)
                        view = context.LayoutInflater.Inflate(Resource.Layout.AwardedShipmentLayout, null);
                    //Get the controls
                    txtBolNum = view.FindViewById<TextView>(Resource.Id.txtBolNum);
                    txtViewStatusValue = view.FindViewById<TextView>(Resource.Id.txtViewStatusValue);
                    txtViewForValue = view.FindViewById<TextView>(Resource.Id.txtViewForValue);
                    txtViewFromValue = view.FindViewById<TextView>(Resource.Id.txtViewFromValue);
                    txtViewToValue = view.FindViewById<TextView>(Resource.Id.txtViewToValue);
                    txtViewPickupValue = view.FindViewById<TextView>(Resource.Id.txtViewPickupValue);
                    txtViewDriverIDValue = view.FindViewById<TextView>(Resource.Id.txtViewDriverIDValue);
                    rltLayoutAwarded = view.FindViewById<RelativeLayout>(Resource.Id.rltLayoutAwarded);
                    string fromAddress = ""; string toAddress = "";
                    lnrLayoutStatus = view.FindViewById<LinearLayout>(Resource.Id.lnrLayoutStatus);
                    //Assign Values from API response
                    txtViewForValue.Text = lstAwardedShipments[position].ClientID;
                    if (!string.IsNullOrEmpty(lstAwardedShipments[position].OriginAddress1))
                    { fromAddress = lstAwardedShipments[position].OriginAddress1 + "\n"; }
                    if (!string.IsNullOrEmpty(lstAwardedShipments[position].OriginAddress2))
                    { fromAddress += lstAwardedShipments[position].OriginAddress2 + "\n"; }
                    txtViewFromValue.Text = fromAddress + lstAwardedShipments[position].OriginCity + ", "
                        + lstAwardedShipments[position].OriginState + " "
                        + lstAwardedShipments[position].OriginZip;
                    if (!string.IsNullOrEmpty(lstAwardedShipments[position].ShipToAddress1))
                    { toAddress = lstAwardedShipments[position].ShipToAddress1 + "\n"; }
                    if (!string.IsNullOrEmpty(lstAwardedShipments[position].ShipToAddress2))
                    { toAddress += lstAwardedShipments[position].ShipToAddress2 + "\n"; }
                    txtViewToValue.Text = toAddress + lstAwardedShipments[position].ShipToCity + ", "
                        + lstAwardedShipments[position].ShipToState + " " + lstAwardedShipments[position].ShipToZip;
                    txtViewPickupValue.Text = lstAwardedShipments[position].PickupStr;
                    txtViewDriverIDValue.Text = lstAwardedShipments[position].DriverID;
                    //Header value 
                    txtBolNum.Text = lstAwardedShipments[position].BolNum;
                    if (lstAwardedShipments[position].IsTest == true)
                    {
                        txtBolNum.Text = txtBolNum.Text + Constants.strTestBol;
                    }
                    decimal awardedPrice = Convert.ToDecimal(lstAwardedShipments[position].AwardedPrice);
                    var awardedDecimalPrice = string.Format("{0:0.00}", awardedPrice);

                    txtBolNum.Text = txtBolNum.Text + " for " + "$" + awardedDecimalPrice;

                    //For Layout Show and Hide
                    if (lstAwardedShipments[position].ViewAs != Constants.strCarrier)
                    {
                        LinearLayout lnrLayoutFor = view.FindViewById<LinearLayout>(Resource.Id.lnrLayoutFor);
                        lnrLayoutFor.Visibility = ViewStates.Gone;
                    }
                    //Click Event for Map
                    value = txtViewFromValue.Text + "#" + txtViewToValue.Text + "#" + txtBolNum.Text;
                    objIntent = Utility.RedirectTo(context, typeof(ShipmentsAddressActivity), "location", value);
                    txtViewFromValue.Click += (sender, e) =>
                    {
                        context.StartActivity(objIntent);
                    };
                    txtViewToValue.Click += (sender, e) =>
                    {
                        context.StartActivity(objIntent);
                    };
                    //Redirecting to Detailed page
                    rltLayoutAwarded.Click += (sender, e) =>
                    {
                        if (CommanUtil.IsTimeOut())
                        {
                            value = lstAwardedShipments[position].ClientID + "|" + lstAwardedShipments[position].BolNum + "|" + "";
                            objIntent = Utility.RedirectTo(context, typeof(ShipmentsDetailedActivity), "compositeKey", value);
                            context.StartActivity(objIntent);
                        }
                        else
                        {
                            Utility.ExpireSession(context);
                        }
                    };
                    return view;
                }
                catch(Exception ex)
                {
                    Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);          
                    return null;
                }
            }
        }
    }
}