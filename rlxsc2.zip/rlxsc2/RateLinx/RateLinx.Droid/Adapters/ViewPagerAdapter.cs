using System;
using System.Collections.Generic;
using Android.Support.V4.App;
using Java.Lang;
using V4App = Android.Support.V4.App;
using RateLinx.Helper;

namespace RateLinx.Droid.Adapters
{
    /// <summary>
    /// View Pager Adapter Meta Class
    /// </summary>
    public class ViewPagerAdapter : FragmentPagerAdapter
    {
        #region Declaration of variable
        private List<V4App.Fragment> mFragmentList = new List<V4App.Fragment>();
        private List<string> mFragmentTitleList = new List<string>();
        private V4App.FragmentManager childFragmentManager;
        #endregion
        /// <summary>
        /// Fragment Manager
        /// </summary>
        /// <param name="childFragmentManager"></param>
        public ViewPagerAdapter(V4App.FragmentManager childFragmentManager) : base(childFragmentManager)
        {
            this.childFragmentManager = childFragmentManager;
        }

        /// <summary>
        /// Get count of fragment
        /// </summary>
        public override int Count
        {
            get
            {
                return mFragmentList.Count;
            }
        }

        /// <summary>
        /// Get Position of fragment
        /// </summary>
        /// <param name="postion"></param>
        /// <returns></returns>
        public override V4App.Fragment GetItem(int postion)
        {
            return mFragmentList[postion];
        }

        /// <summary>
        /// Set  Title for fragment or tab layout
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public override ICharSequence GetPageTitleFormatted(int position)
        {
            return new Java.Lang.String(mFragmentTitleList[position].ToLower());// display the title
            //return null;// display only the icon
        }

        /// <summary>
        /// Set Tab with title
        /// </summary>
        /// <param name="fragment"></param>
        /// <param name="title"></param>
        public void AddFragment(V4App.Fragment fragment, string title)
        {
            try
            {
                mFragmentList.Add(fragment);
                mFragmentTitleList.Add(title);
            }catch
            {
                 Console.Write(Constants.strErrorOccured);
            }
        }
    }
}