using System.Collections.Generic;
using Android.App;
using Android.Views;
using Android.Widget;
using RateLinx.Models;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;
using System;

namespace RateLinx.Droid.Adapters
{
    /// <summary>
    /// Tracking Details Adapter
    /// </summary>
    public class TrackDetailsAdapter : BaseAdapter<TrackDetail>
    {
        #region Declaration of variable
        Activity context = null;
        List<TrackDetail> lstTrackDetail = null;
        TextView txtActivity,
        txtCity,
        txtState,
        txtCountry,
        txtDescription = null;
        LinearLayout lnrTrackInfo = null;
        Utility objUtility = new Utility();
        #endregion

        /// <summary>
        /// TrackDetailsAdapter
        /// </summary>
        /// <param name="context"></param>
        /// <param name="lstTrackDetail"></param>
        public TrackDetailsAdapter(Activity context, List<TrackDetail> lstTrackDetail)
        {
            this.context = context;
            this.lstTrackDetail = lstTrackDetail;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public override long GetItemId(int position)
        {
            return position;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public override TrackDetail this[int position]
        {
            get
            {
                return lstTrackDetail[position];
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public override int Count
        {
            get
            {
                return lstTrackDetail.Count;
            }
        }
        /// <summary>
        /// Data Binding in Controls
        /// </summary>
        /// <param name="position"></param>
        /// <param name="convertView"></param>
        /// <param name="parent"></param>
        /// <returns></returns>
        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            try
            {
                View viewTrackDetail = convertView;
              
                if (viewTrackDetail == null)
                {
                    viewTrackDetail = context.LayoutInflater.Inflate(Resource.Layout.TrackingInfoLayout, null);
                }
               
                txtActivity = viewTrackDetail.FindViewById<TextView>(Resource.Id.txtActivity);
                txtCity = viewTrackDetail.FindViewById<TextView>(Resource.Id.txtCity);
                txtState = viewTrackDetail.FindViewById<TextView>(Resource.Id.txtState);
                txtCountry = viewTrackDetail.FindViewById<TextView>(Resource.Id.txtCountry);
                txtDescription = viewTrackDetail.FindViewById<TextView>(Resource.Id.txtDescription);
                lnrTrackInfo = viewTrackDetail.FindViewById<LinearLayout>(Resource.Id.lnrTrackInfo);
                txtActivity.Text = lstTrackDetail[position].Activity;
                txtCity.Text = lstTrackDetail[position].City;
                txtState.Text = lstTrackDetail[position].State;
                txtCountry.Text = lstTrackDetail[position].Country;

                if (lstTrackDetail[position].ActivityDescr == "Carrier Departed Pick-up Location with Shipment")
                {
                    txtDescription.Text = Constants.strPickedUpText;
                }
                else if (lstTrackDetail[position].ActivityDescr == "En Route to Delivery Location")
                {
                    txtDescription.Text = Constants.strEnRouteText;
                }
                else
                {
                    txtDescription.Text = lstTrackDetail[position].ActivityDescr;
                }
                objUtility.ChangeLayoutColor(lnrTrackInfo, viewTrackDetail, position);
                return viewTrackDetail;
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
                return null;
            }
        }
    }
}