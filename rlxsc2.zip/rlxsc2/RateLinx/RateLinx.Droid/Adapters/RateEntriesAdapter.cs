using System;
using System.Collections.Generic;
using Android.App;
using Android.Views;
using Android.Widget;
using RateLinx.Models;
using RateLinx.Droid.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RateLinx.Helper;
using RateLinx.APIs;
using RateLinx.Droid.Activities;
using System.Text.RegularExpressions;
using Android.Text.Method;
using System.Threading.Tasks;

namespace RateLinx.Droid.Adapters
{
    /// <summary>
    /// Rate Entries Adapter
    /// </summary>
    public class RateEntriesAdapter : BaseAdapter<Entry>
    {
        #region Declaration of variable
        /// <summary>
        /// List of the Options in Shipments
        /// </summary>
        public List<Entry> lstRateEntry;
        Dialog dialog = null;
        Button btnConfirm, btnCancel = null;
        TextView txtMessage, txtDialogHeader, txtReasonlbl = null;
        LinearLayout lntlayoutReason = null;
        ImageView imgheader, imgheaderError = null;
        EditText txtAcceptDeny = null;
        Utility objUtility = null;
        Activity context;
        TextView txtCarrier, txtDateEntered;
        ImageButton imgBtnLorry, imgDenyShip, imgBtnNote, imgConfirmShip = null;
        TextView txtCarrierName, txtShipCost, txtTermsAlt, txtStatus, txtAuthedBy, txtAwarded, txtReason = null;
        CarrierShipmentDetails carrierShipmentDetail = null;
        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="context"></param>
        /// <param name="lstRateEntry"></param>
        /// <param name="carrierShipmentDetail"></param>
        public RateEntriesAdapter(Activity context, List<Entry> lstRateEntry, CarrierShipmentDetails carrierShipmentDetail)
                : base()
        {
            this.context = context;
            this.lstRateEntry = lstRateEntry;
            this.carrierShipmentDetail = carrierShipmentDetail;
        }

        /// <summary>
        /// Get item by ID
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public override long GetItemId(int position)
        {
            return position;
        }

        /// <summary>
        /// get positions
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public override Entry this[int position]
        {
            get
            {
                return lstRateEntry[position];
            }
        }

        /// <summary>
        /// Count of data
        /// </summary>
        public override int Count
        {
            get { return lstRateEntry.Count; }
        }

        /// <summary>
        /// Get View
        /// </summary>
        /// <param name="position"></param>
        /// <param name="convertView"></param>
        /// <param name="parent"></param>
        /// <returns></returns>
        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            try
            {
                View view = convertView;
                view = context.LayoutInflater.Inflate(Resource.Layout.RateHistoryFragment, null);
                imgBtnLorry = view.FindViewById<ImageButton>(Resource.Id.imgLorry);
                imgBtnLorry.Click += async delegate
                 {
                     if (CommanUtil.IsTimeOut())
                     {
                         await AwardTheShipment(position);
                     }
                     else
                     {
                         //Token Exired
                         Utility.ExpireSession(context);
                     }
                 };
                imgDenyShip = view.FindViewById<ImageButton>(Resource.Id.imgDenyShip);
                imgDenyShip.Click += delegate
                {
                    string tag = Convert.ToString(imgDenyShip.Tag);
                    AcceptDenyShip(tag, position, carrierShipmentDetail);
                };
                imgBtnNote = view.FindViewById<ImageButton>(Resource.Id.imgNote);
                imgBtnNote.Click += delegate
            {
                CheckComment(position);
            };
                imgConfirmShip = view.FindViewById<ImageButton>(Resource.Id.imgConfirmShip);
                imgConfirmShip.Click += delegate
                {
                    string tag = Convert.ToString(imgConfirmShip.Tag);
                    AcceptDenyShip(tag, position, carrierShipmentDetail);
                };
                txtCarrier = view.FindViewById<TextView>(Resource.Id.txtCarrier);
                txtCarrierName = view.FindViewById<TextView>(Resource.Id.txtCarrierName);
                txtShipCost = view.FindViewById<TextView>(Resource.Id.txtShipCost);
                txtShipCost.Click += delegate
                {
                    ShipmentCostDetails(position);
                };
                txtTermsAlt = view.FindViewById<TextView>(Resource.Id.txtTermsAlt);
                txtStatus = view.FindViewById<TextView>(Resource.Id.txtStatus);
                txtAuthedBy = view.FindViewById<TextView>(Resource.Id.txtAuthedBy);
                txtDateEntered = view.FindViewById<TextView>(Resource.Id.txtDateEntered);
                txtDateEntered.Text = lstRateEntry[position].EnteredOnStr;
                txtAwarded = view.FindViewById<TextView>(Resource.Id.txtAwarded);
                txtReason = view.FindViewById<TextView>(Resource.Id.txtReason);
                txtCarrier.Text = lstRateEntry[position].SCAC;
                txtCarrierName.Text = lstRateEntry[position].CarrierName;
                txtShipCost.Text = "$ " + Convert.ToString(lstRateEntry[position].Price);
                txtTermsAlt.Text = lstRateEntry[position].Altered ? Constants.btnTextYes : Constants.btnTextNo;
                txtStatus.Text = lstRateEntry[position].Status;
                txtAuthedBy.Text = lstRateEntry[position].AuthedBy;
                ShowHideLayoutOnConditn(position);
                txtAwarded.Text = lstRateEntry[position].Winner ? Constants.btnTextYes : Constants.strPending;
                txtReason.Text = lstRateEntry[position].DenyReason;
                return view;
            }
            catch (Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                return null;
            }
        }

        /// <summary>
        /// Getnerating a Dialog 
        /// </summary>
        /// <param name="dialogHeader"></param>
        /// <param name="message"></param>
        /// <param name="btnConfirmText"></param>
        /// <param name="btnCancelText"></param>
        /// <param name="txtReasonLbl"></param>
        /// <param name="lntlayoutReasonVisiblity"></param>
        /// <param name="txtMessageVisibility"></param>
        /// <param name="btnConfirmVisibility"></param>
        /// <param name="btnCancelVisibility"></param>
        /// <param name="imgheaderVisibility"></param>
        /// <param name="imgheaderErrorVisibility"></param>
        /// <returns></returns>
        public Dialog GetDialog(string dialogHeader, string message, string btnConfirmText, string btnCancelText, string txtReasonLbl, ViewStates lntlayoutReasonVisiblity, ViewStates txtMessageVisibility, ViewStates btnConfirmVisibility, ViewStates btnCancelVisibility, ViewStates imgheaderVisibility, ViewStates imgheaderErrorVisibility)
        {
            try
            {
                objUtility = new Utility();
                dialog = objUtility.ConfirmationAlert(context);//Generate Confirmation Alert Box
                btnConfirm = dialog.FindViewById<Button>(Resource.Id.btnYes);
                btnCancel = dialog.FindViewById<Button>(Resource.Id.btnNo);
                txtMessage = dialog.FindViewById<TextView>(Resource.Id.txtMessage);
                txtDialogHeader = dialog.FindViewById<TextView>(Resource.Id.txtDialogHeader);
                txtReasonlbl = dialog.FindViewById<TextView>(Resource.Id.txtReason);
                lntlayoutReason = dialog.FindViewById<LinearLayout>(Resource.Id.lntlayoutReason);
                imgheader = dialog.FindViewById<ImageView>(Resource.Id.imgheader);
                imgheaderError = dialog.FindViewById<ImageView>(Resource.Id.imgheaderError);
                txtAcceptDeny = dialog.FindViewById<EditText>(Resource.Id.txtEnterReason);
                var viewDivide = dialog.FindViewById<View>(Resource.Id.viewDivide);
                viewDivide.Visibility = ViewStates.Invisible;

                txtReasonlbl.Text = txtReasonLbl;
                if (txtReasonLbl == Constants.ConfShiplbl || txtReasonLbl == Constants.DenyShiplbl)
                {
                    txtReasonlbl.SetTypeface(null, Android.Graphics.TypefaceStyle.Bold);
                }
                txtDialogHeader.Text = dialogHeader;
                txtMessage.Text = message;
                btnConfirm.Text = btnConfirmText;
                btnCancel.Text = btnCancelText;
                lntlayoutReason.Visibility = lntlayoutReasonVisiblity;
                txtMessage.Visibility = txtMessageVisibility;
                btnConfirm.Visibility = btnConfirmVisibility;
                btnCancel.Visibility = btnCancelVisibility;
                imgheaderError.Visibility = ViewStates.Gone;
                imgheader.Visibility = ViewStates.Gone;
                string prono = txtAcceptDeny.Text;
                txtAcceptDeny.TextChanged += delegate
                {
                    if (CommanUtil.IsSpecialCharacter(txtAcceptDeny.Text))
                    {
                        Toast.MakeText(context, Constants.specialCharacterMessage, ToastLength.Short).Show();
                        txtAcceptDeny.Text = "";
                    }
                    else
                    {

                    }
                };

                return dialog;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dialogHeader"></param>
        /// <param name="message"></param>
        /// <param name="btnConfirmText"></param>
        /// <param name="btnCancelText"></param>
        /// <param name="txtReasonLbl"></param>
        /// <param name="lntlayoutReasonVisiblity"></param>
        /// <param name="txtMessageVisibility"></param>
        /// <param name="btnConfirmVisibility"></param>
        /// <param name="btnCancelVisibility"></param>
        /// <param name="imgheaderVisibility"></param>
        /// <param name="imgheaderErrorVisibility"></param>
        /// <param name="shipmentID"></param>
        /// <param name="bidID"></param>
        /// <returns></returns>
        public Dialog GetShipConfirmDialog(string dialogHeader, string message, string btnConfirmText, string btnCancelText, string txtReasonLbl, ViewStates lntlayoutReasonVisiblity, ViewStates txtMessageVisibility, ViewStates btnConfirmVisibility, ViewStates btnCancelVisibility, ViewStates imgheaderVisibility, ViewStates imgheaderErrorVisibility, string shipmentID, int bidID)
        {
            try
            {
                objUtility = new Utility();
                dialog = objUtility.ConfirmationAlert(context);//Generate Confirmation Alert Box
                btnConfirm = dialog.FindViewById<Button>(Resource.Id.btnYes);
                btnCancel = dialog.FindViewById<Button>(Resource.Id.btnNo);
                txtMessage = dialog.FindViewById<TextView>(Resource.Id.txtMessage);
                txtDialogHeader = dialog.FindViewById<TextView>(Resource.Id.txtDialogHeader);
                txtReasonlbl = dialog.FindViewById<TextView>(Resource.Id.txtReason);
                lntlayoutReason = dialog.FindViewById<LinearLayout>(Resource.Id.lntlayoutReason);
                imgheader = dialog.FindViewById<ImageView>(Resource.Id.imgheader);
                imgheaderError = dialog.FindViewById<ImageView>(Resource.Id.imgheaderError);
                txtAcceptDeny = dialog.FindViewById<EditText>(Resource.Id.txtEnterReason);
                var viewDivide = dialog.FindViewById<View>(Resource.Id.viewDivide);
                viewDivide.Visibility = ViewStates.Invisible;
                txtReasonlbl.Text = txtReasonLbl;
                txtDialogHeader.Text = dialogHeader;
                txtMessage.Text = message;
                btnConfirm.Text = btnConfirmText;
                btnCancel.Text = btnCancelText;
                lntlayoutReason.Visibility = lntlayoutReasonVisiblity;
                txtMessage.Visibility = txtMessageVisibility;
                btnConfirm.Visibility = btnConfirmVisibility;
                btnCancel.Visibility = btnCancelVisibility;
                imgheader.Visibility = ViewStates.Gone;
                imgheaderError.Visibility = ViewStates.Gone;
                string prono = txtAcceptDeny.Text;
                btnConfirm.Click += async delegate
                {
                    if (!string.IsNullOrEmpty(txtAcceptDeny.Text))
                    {
                        dialog.Hide();
                        ServiceHelper objServiceHelper = new ServiceHelper();
                        string methodURI = APIMethods.shipmentDetails + "/" + shipmentID + "/" + bidID + "/" + APIMethods.award;
                        BidComment bidComment = new BidComment();
                        bidComment.NonOptimalReason = txtAcceptDeny.Text;
                        string payLoad = JsonConvert.SerializeObject(bidComment);
                        var result = objServiceHelper.PostRequestJson(payLoad, methodURI, CommanUtil.tokenNo, true);
                        if (result != null)
                        {

                            string[] shipDetails = shipmentID.Split('|');
                            string key = shipDetails[0] + "|" + shipDetails[2] + "|" + Constants.strBID;
                            await RefreshDataSet();
                        }
                    }
                    else
                    {
                        Toast.MakeText(context, Constants.strEnterReason, ToastLength.Short).Show();
                    }
                };

                return dialog;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Show Hide Conditional Controls
        /// </summary>
        private void ShowHideLayoutOnConditn(int position)
        {
            try
            {
                if (carrierShipmentDetail.Entries[position].CanConfirm)
                {
                    imgConfirmShip.Visibility = ViewStates.Visible;
                }
                else
                {
                    imgConfirmShip.Visibility = ViewStates.Invisible;
                }
                if (carrierShipmentDetail.Entries[position].CanDeny)
                {
                    imgDenyShip.Visibility = ViewStates.Visible;
                }
                else
                {
                    imgDenyShip.Visibility = ViewStates.Invisible;
                }
                if (carrierShipmentDetail.Entries[position].CanAward)
                {
                    imgBtnLorry.Visibility = ViewStates.Visible;
                }
                else
                {
                    imgBtnLorry.Visibility = ViewStates.Invisible;
                }
                if (!string.IsNullOrEmpty(carrierShipmentDetail.Entries[position].Comments))
                {
                    imgBtnNote.Visibility = ViewStates.Visible;
                }
                else
                {
                    imgBtnNote.Visibility = ViewStates.Invisible;
                }


            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Shipment Cost Details
        /// </summary>
        /// <param name="position"></param>
        private void ShipmentCostDetails(int position)
        {
            try
            {
                AlertDialog.Builder alert = null;
                alert = new AlertDialog.Builder(context);
                alert.SetView(Resource.Layout.DialogLayout);
                dialog = alert.Create();
                dialog.Show();
                dialog.SetCancelable(false);
                Button btnOK = dialog.FindViewById<Button>(Resource.Id.btnOk);
                TextView editTextCross = dialog.FindViewById<TextView>(Resource.Id.editTextCross);
                TextView txtAccessorialChg = dialog.FindViewById<TextView>(Resource.Id.txtAccessorialChg);
                TextView txtBaseChg = dialog.FindViewById<TextView>(Resource.Id.txtBaseChg);
                TextView txtFuelChg = dialog.FindViewById<TextView>(Resource.Id.txtFuelChg);
                if (carrierShipmentDetail != null)
                {
                    txtAccessorialChg.Text = "$ " + Convert.ToString(carrierShipmentDetail.Entries[position].Charges[0].Value);
                    txtBaseChg.Text = "$ " + Convert.ToString(carrierShipmentDetail.Entries[position].Charges[1].Value);
                    txtFuelChg.Text = "$ " + Convert.ToString(carrierShipmentDetail.Entries[position].Charges[2].Value);
                }
                btnOK.Click += delegate
                {
                    dialog.Hide();
                };
                editTextCross.Click += delegate
                {
                    dialog.Hide();
                };
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Accept and Deny Shipment
        /// </summary>
        /// <param name="imgButtonTag"></param>
        /// <param name="position"></param>
        /// <param name="carrierShipmentDetail"></param>
        private void AcceptDenyShip(string imgButtonTag, int position, CarrierShipmentDetails carrierShipmentDetail)
        {
            try
            {
                string id = string.Empty;
                int bidId = carrierShipmentDetail.Entries[position].ID;
                if (imgButtonTag == Constants.strDialogHdr)
                {
                    string confirmLbl = Constants.ConfShiplbl;
                    string message = Constants.ConfirmShipment;
                    Dialog confirmDialog = GetDialog(Constants.strConfirmShip, message, Constants.strDialogHdr,
                        Constants.btnTextCancel, confirmLbl, ViewStates.Visible,
                        ViewStates.Visible, ViewStates.Visible, ViewStates.Visible,
                        ViewStates.Visible, ViewStates.Gone);
                    string chkSpecialCharacter = txtAcceptDeny.Text;
                    btnConfirm.Click += async delegate
                    {
                        if (CommanUtil.IsTimeOut())
                        {
                            string payLoad = "{" + "\"ProNumber\"" + ":" + "\"" + txtAcceptDeny.Text + "\"" + "}";
                            if (string.IsNullOrEmpty(txtAcceptDeny.Text))
                            {
                                Toast.MakeText(context, Constants.strEnterProNo, ToastLength.Short).Show();
                                id = CommanUtil.CompositeKey(carrierShipmentDetail.ClientID, carrierShipmentDetail.LocID, carrierShipmentDetail.BolNum);
                            }
                            if (CommanUtil.IsSpecialCharacter(txtAcceptDeny.Text))
                            {
                                Toast.MakeText(context, Constants.specialCharacterMessage, ToastLength.Short).Show();
                                return;
                            }
                            else
                            {
                                try
                                {
                                    Alerts.showBusyLoader(context);
                                    await Task.Delay(500);
                                    ServiceHelper objServiceHelper = new ServiceHelper();
                                    string token = CommanUtil.tokenNo;
                                    id = CommanUtil.CompositeKey(carrierShipmentDetail.ClientID, carrierShipmentDetail.LocID, carrierShipmentDetail.BolNum);
                                    string methodURI = APIMethods.shipmentDetails + "/" + id + "/" + bidId + "/" + APIMethods.confirm;
                                    var Result = await objServiceHelper.PostRequestJson(payLoad, methodURI, token, true);
                                    if (!string.IsNullOrEmpty(Result))
                                    {
                                        await RefreshDataSet();
                                        Alerts.HideBusyLoader();
                                        if (Result.Replace("\"", " ").Trim().ToUpper() == Constants.strSuccess.ToUpper())
                                        {
                                            confirmDialog.Hide();
                                        }
                                        else
                                        {
                                            try
                                            {
                                                JObject response = JObject.Parse(Result);
                                                string Message = Convert.ToString(response[Constants.strErrorMessage]);
                                                if (!string.IsNullOrEmpty(Message))
                                                {
                                                    confirmDialog.Hide();
                                                    string dialogHeader = Constants.ErrorAlert;
                                                    Dialog errorDialog = GetDialog(dialogHeader, Message, Constants.btnTextOk, "", "", ViewStates.Gone, ViewStates.Visible, ViewStates.Visible, ViewStates.Gone, ViewStates.Gone, ViewStates.Visible);
                                                    btnConfirm = errorDialog.FindViewById<Button>(Resource.Id.btnYes);
                                                    btnConfirm.Click += delegate
                                                    {
                                                        errorDialog.Hide();
                                                    };
                                                    btnCancel.SetBackgroundColor(Android.Graphics.Color.White);
                                                }

                                            }
                                            catch
                                            {
                                                confirmDialog.Hide();
                                                string dialogHeader = Constants.ErrorAlert;
                                                Dialog errorDialog = GetDialog(dialogHeader, Constants.strServerError, Constants.btnTextOk, "", "", ViewStates.Gone, ViewStates.Visible, ViewStates.Visible, ViewStates.Gone, ViewStates.Gone, ViewStates.Visible);
                                                btnConfirm = errorDialog.FindViewById<Button>(Resource.Id.btnYes);
                                                btnConfirm.Click += delegate
                                                {
                                                    errorDialog.Hide();
                                                };
                                                btnCancel.SetBackgroundColor(Android.Graphics.Color.White);

                                            }

                                        }
                                    }
                                    else
                                    {
                                        await RefreshDataSet();
                                        confirmDialog.Hide();
                                        Alerts.HideBusyLoader();
                                    }
                                }
                                catch
                                {
                                    Alerts.HideBusyLoader();
                                    Console.Write(Constants.strErrorOccured);
                                }
                            }
                        }
                        else
                        {
                            Utility.ExpireSession(context);
                        }
                    };
                }
                else if (imgButtonTag == Constants.strDeny)
                {
                    string denySthipment = Constants.DenyShipment;
                    string denyShipmentLbl = Constants.DenyShiplbl;
                    Dialog denyDialog = GetDialog(Constants.strDenyShip, denySthipment, Constants.strDialogHdr, Constants.btnTextCancel, denyShipmentLbl, ViewStates.Visible, ViewStates.Visible, ViewStates.Visible, ViewStates.Visible, ViewStates.Visible, ViewStates.Gone);
                    btnConfirm.Click += async delegate
                    {
                        if (CommanUtil.IsTimeOut())
                        {
                            if (string.IsNullOrEmpty(txtAcceptDeny.Text))
                            {
                                Toast.MakeText(context, Constants.strReason, ToastLength.Short);
                            }
                            else
                            {
                                try
                                {
                                    Alerts.showBusyLoader(context);
                                    await Task.Delay(500);
                                    ServiceHelper objServiceHelper = new ServiceHelper();
                                    string denyToken = CommanUtil.tokenNo;
                                    id = CommanUtil.CompositeKey(carrierShipmentDetail.ClientID, carrierShipmentDetail.LocID, carrierShipmentDetail.BolNum);
                                    string denyURI = APIMethods.shipmentDetails + "/" + id + "/" + bidId + "/" + APIMethods.deny;
                                    string payLoad = "{" + "\"DenyReason\"" + ":" + "\"" + txtAcceptDeny.Text + "\"" + "}";
                                    var Result = await objServiceHelper.PostRequestJson(payLoad, denyURI, denyToken, true);
                                    if (!string.IsNullOrEmpty(Result))
                                    {
                                        await RefreshDataSet();
                                        var Jobject = JsonConvert.DeserializeObject(Result);
                                        if (Jobject.ToString().ToUpper() == Constants.strSuccess.ToUpper())
                                        {
                                            Alerts.HideBusyLoader();
                                            denyDialog.Hide();
                                        }
                                    }
                                    else
                                    {
                                        Alerts.HideBusyLoader();
                                        Dialog errorDialog = GetDialog(Constants.ErrorAlert, Constants.strErrorOccured, Constants.btnTextOk, "", "", ViewStates.Gone, ViewStates.Visible, ViewStates.Visible, ViewStates.Gone, ViewStates.Gone, ViewStates.Visible);
                                        btnConfirm = errorDialog.FindViewById<Button>(Resource.Id.btnYes);
                                        btnConfirm.Click += delegate
                                        {
                                            errorDialog.Hide();
                                        };
                                        btnCancel.SetBackgroundColor(Android.Graphics.Color.White);
                                    }

                                }
                                catch
                                {
                                    Alerts.HideBusyLoader();
                                    Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                                    context.Finish();
                                }
                            }
                        }
                        else
                        {
                            //Token Exired
                            Utility.ExpireSession(context);
                        }

                    };
                }
            }
            catch
            {
                Alerts.HideBusyLoader();
                throw;
            }
            finally
            {
                Alerts.HideBusyLoader();
            }
        }

        /// <summary>
        /// Check Comment 
        /// </summary>
        /// <param name="position"></param>
        private void CheckComment(int position)
        {
            try
            {
                string comment = carrierShipmentDetail.Entries[position].Comments;
                string rateEntryHeader = Constants.RateCommentHeader;
                GetDialog(rateEntryHeader, comment, "", Constants.btnTextOk, "", ViewStates.Gone, ViewStates.Visible, ViewStates.Gone, ViewStates.Visible, ViewStates.Gone, ViewStates.Gone);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Award The Shipment 
        /// </summary>
        /// <param name="position"></param>
        private async Task AwardTheShipment(int position)
        {
            try
            {
                int bidID = carrierShipmentDetail.Entries[position].ID;
                double minPrice = 0.00;
                // bool NeedsNonOptReason = false;
                string selectedOptReason = string.Empty;
                string PayLoad = string.Empty;
                double entryPrice = carrierShipmentDetail.Entries[position].Price;
                if (carrierShipmentDetail.NeedsNonOptReason)
                {
                    minPrice = carrierShipmentDetail.Entries[position].Price;
                    for (int count = 0; count < carrierShipmentDetail.Entries.Count; count++)
                    {
                        if (carrierShipmentDetail.Entries[count].Price <= minPrice)
                        {
                            minPrice = carrierShipmentDetail.Entries[count].Price;
                        }
                    }
                    if (minPrice != entryPrice)
                    {
                        PayLoad = "{}";
                        await AwardShipment(bidID, PayLoad);
                        imgBtnLorry.Visibility = ViewStates.Invisible;
                        CommanUtil.visibilitybtnUnAward = true;
                        CommanUtil.visibilitybtnReSubmit = false;
                    }
                    else
                    {
                        PayLoad = "{}";
                        await AwardShipment(bidID, PayLoad);
                        imgBtnLorry.Visibility = ViewStates.Invisible;
                        CommanUtil.visibilitybtnUnAward = true;
                        CommanUtil.visibilitybtnReSubmit = false;
                    }
                }
                else
                {
                    PayLoad = "{}";
                    await AwardShipment(bidID, PayLoad);
                    imgBtnLorry.Visibility = ViewStates.Invisible;
                    CommanUtil.visibilitybtnUnAward = true;
                    CommanUtil.visibilitybtnReSubmit = false;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// AwardShipment And Post it in API
        /// </summary>
        /// <param name="bidID"></param>
        /// <param name="payLoad"></param>
        private async Task AwardShipment(int bidID, string payLoad)
        {
            try
            {
                JObject response = null;
                ServiceHelper objServiceHelper = new ServiceHelper();
                string shipmentId = CommanUtil.CompositeKey(carrierShipmentDetail.ClientID, carrierShipmentDetail.LocID, carrierShipmentDetail.BolNum);
                Alerts.showBusyLoader(context);
                await Task.Delay(500);
                string methodURI = APIMethods.shipmentDetails + "/" + shipmentId + "/" + bidID + "/" + APIMethods.award;
                string token = CommanUtil.tokenNo;
                var Result = await objServiceHelper.PostRequestJson(payLoad, methodURI, token, true);
                if (!string.IsNullOrEmpty(Result))
                {
                    await RefreshDataSet();
                    response = JObject.Parse(Result);
                    string message = Convert.ToString(response[Constants.strErrorMessage]);
                    if (!string.IsNullOrEmpty(message))
                    {
                        Alerts.HideBusyLoader();
                        string dialogHeader = Constants.Warning;
                        dialog = GetDialog(dialogHeader, message, Constants.btnTextOk, "", "", ViewStates.Gone, ViewStates.Visible, ViewStates.Visible, ViewStates.Gone, ViewStates.Gone, ViewStates.Visible);
                        btnConfirm = dialog.FindViewById<Button>(Resource.Id.btnYes);
                        btnConfirm.Click += delegate
                        {
                            dialog.Hide();
                            Dialog confirmDialog = GetShipConfirmDialog(Constants.strConfirmShip, "Please enter reason to award the shipment", Constants.strDialogHdr,
                      Constants.btnTextCancel, "", ViewStates.Visible,
                      ViewStates.Visible, ViewStates.Visible, ViewStates.Visible,
                      ViewStates.Visible, ViewStates.Gone, shipmentId, bidID);

                        };
                        btnCancel.SetBackgroundColor(Android.Graphics.Color.White);
                    }
                    else
                    {
                        imgBtnLorry.Visibility = ViewStates.Invisible;
                        Alerts.HideBusyLoader();
                    }
                    Alerts.HideBusyLoader();
                }
                else
                {
                    Alerts.HideBusyLoader();
                    Dialog errorDialog = GetDialog(Constants.ErrorAlert, Constants.strErrorOccured, Constants.btnTextOk, "", "", ViewStates.Gone, ViewStates.Visible, ViewStates.Visible, ViewStates.Gone, ViewStates.Gone, ViewStates.Visible);
                    btnConfirm = errorDialog.FindViewById<Button>(Resource.Id.btnYes);
                    btnConfirm.Click += delegate
                    {
                        errorDialog.Hide();
                    };
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Refresh Data Set
        /// </summary>
        /// <returns></returns>
        public async Task RefreshDataSet()
        {
            objUtility = new Utility();
            CommanUtil.visibilitybtnUnAward = true;
            CommanUtil.visibilitybtnReSubmit = false;
            string methodURI = APIMethods.shipmentDetails + "/" + carrierShipmentDetail.ClientID + "|" + carrierShipmentDetail.BolNum;
            string apiResponse = await objUtility.BindShipmentDetail(methodURI, context);
            if (!string.IsNullOrEmpty(apiResponse))
            {
                carrierShipmentDetail = JsonConvert.DeserializeObject<CarrierShipmentDetails>(apiResponse);
            }
            lstRateEntry = carrierShipmentDetail.Entries;
            NotifyDataSetChanged();
        }
    }
}