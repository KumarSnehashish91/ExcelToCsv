using System.Collections.Generic;
using Android.App;
using Android.Views;
using Android.Widget;
using RateLinx.Models;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;
using System;
using Attribute = RateLinx.Models.Attribute;

namespace RateLinx.Droid.Adapters
{
    /// <summary>
    /// ScannedAttributeAdapter Details Adapter
    /// </summary>
    public class ScannedAttributeAdapter : BaseAdapter<Attribute>
    {
        #region Declaration of variable
        Activity context = null;
        List<Attribute> lstTrackDetail = null;
        TextView txtKey,
        txtValue = null;
        LinearLayout lnrTrackInfo = null;
        Utility objUtility = new Utility();
        #endregion

        /// <summary>
        /// TrackDetailsAdapter
        /// </summary>
        /// <param name="context"></param>
        /// <param name="lstTrackDetail"></param>
        public ScannedAttributeAdapter(Activity context, List<Attribute> lstTrackDetail)
        {
            this.context = context;
            this.lstTrackDetail = lstTrackDetail;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public override long GetItemId(int position)
        {
            return position;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public override Attribute this[int position]
        {
            get
            {
                return lstTrackDetail[position];
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public override int Count
        {
            get
            {
                return lstTrackDetail.Count;
            }
        }
        /// <summary>
        /// Data Binding in Controls
        /// </summary>
        /// <param name="position"></param>
        /// <param name="convertView"></param>
        /// <param name="parent"></param>
        /// <returns></returns>
        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            try
            {
                View viewTrackDetail = convertView;
              
                if (viewTrackDetail == null)
                {
                    viewTrackDetail = context.LayoutInflater.Inflate(Resource.Layout.ScannedEquipmentLayout, null);
                }
                txtKey = viewTrackDetail.FindViewById<TextView>(Resource.Id.txtKey);
                txtValue = viewTrackDetail.FindViewById<TextView>(Resource.Id.txtValue);
                lnrTrackInfo = viewTrackDetail.FindViewById<LinearLayout>(Resource.Id.linrScannedLayout);
                txtKey.Text = lstTrackDetail[position].Key;
                txtValue.Text = lstTrackDetail[position].Value;
                objUtility.ChangeLayoutColor(lnrTrackInfo, viewTrackDetail, position);
                return viewTrackDetail;
            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                return null;
            }
        }
    }
}