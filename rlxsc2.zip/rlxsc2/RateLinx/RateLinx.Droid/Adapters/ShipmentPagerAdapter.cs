﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using V4App = Android.Support.V4.App;
using Android.Views;
using Android.Widget;
using RateLinx.Droid.Fragments;

namespace RateLinx.Droid.Adapters
{
    /// <summary>
    /// 
    /// </summary>
    public class ShipmentPagerAdapter : V4App.FragmentStatePagerAdapter
    {
        Activity context = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="manager"></param>
        /// <param name="context"></param>
        public ShipmentPagerAdapter(V4App.FragmentManager manager, Activity context) : base(manager)
        {
            this.context = context;
        }

        /// <summary>
        /// 
        /// </summary>
        public override int Count => 3;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public override Android.Support.V4.App.Fragment GetItem(int position)
        {
            switch (position)
            {
                case 0:
                    return null;//ActiveShipmentFragment.NewInstance("Active Shipment", context);
                case 1:
                    return null; //AwardedShipmentFragment.NewInstance("Awarded Shipment", context); //PendingFragment.newInstance(mContext.getResources().getString(R.string.pending_fragment), mContext);
                case 2:
                    return null; //RecentShipmentFragment.NewInstance("Recent Shipment", context);//ReportFragment.newInstance(mContext.getResources().getString(R.string.report_fragment), mContext);

                default:
                    return null; //ActiveShipmentFragment.NewInstance("Active Shipment", context); //ReportFragment.newInstance(mContext.getResources().getString(R.string.report_fragment), mContext);
            }
        }
    }
}