using System;
using System.Collections.Generic;
using Android.App;
using Android.Content;
using Android.Views;
using Android.Widget;
using RateLinx.Models;
using RateLinx.Droid.Activities;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;
using System.Runtime.InteropServices;
using Android.Util;
using Android.Content.Res;
using System.Threading;
//using System.Timers;
using Android.OS;
using Android.Support.V7.Widget;
//using Java.Lang;
//using Android.OS;

[assembly: ComVisible(false)]
namespace RateLinx.Droid.Adapters
{
    /// <summary>
    /// Meta Tag for Active shipments
    /// </summary>
    [ComVisible(false)]
    public class AdapterActiveShipments : RecyclerView.Adapter
    {
        public event EventHandler<int> ItemClick;
        bool isAddressClicked = false;
        /// <summary>
        /// Method to bind data
        /// </summary>
        /// <param name="context"></param>
        /// <param name="lstActiveShipments"></param>
        public AdapterActiveShipments(Activity context, List<ActiveShipments> lstActiveShipments)
        {
            this.context = context;
            
            this.lstActiveShipments = lstActiveShipments;
            lstViewBidDetails = new ListView(context);
            CommanUtil.lstRecyclerActiveShipments = lstActiveShipments;
        }
        /// <summary>
        /// 
        /// </summary>
        public override int ItemCount => lstActiveShipments.Count;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="viewHolder"></param>
        /// <param name="position"></param>
        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            ActiveShipmentsViewHolder holder = viewHolder as ActiveShipmentsViewHolder;
            rowPosition = lstActiveShipments[position].DeadLineUTC;
            holder.context = context;
            //Assign Values from API response
            //If Bid now button Click
            holder.btnBidNow.Click += delegate
            {
                try
                {
                    if (CommanUtil.IsTimeOut())
                    {
                        BidNow(position);
                    }
                    else
                    {
                        //Token Exired
                        Utility.ExpireSession(context);
                    }
                }
                catch { }
            };
            holder.txtViewFromValue.Click -= delegate { };
            //holder.txtViewFromValue.Click += delegate
            //  {
            //      if (CommanUtil.IsTimeOut())
            //      {
            //          isAddressClicked = true;
            //          RedirectToShipmentAddressDetails(position);
            //      }
            //      else
            //      {
            //          //Token Exired
            //          Utility.ExpireSession(context);
            //      }
            //  };
            holder.txtViewForValue.Text = lstActiveShipments[position].ClientID;
            holder.txtViewDeadlineValue.Text = Convert.ToString(lstActiveShipments[position].DeadLineStr);
            if (!string.IsNullOrEmpty(lstActiveShipments[position].OriginAddress1))
            { fromAddress = lstActiveShipments[position].OriginAddress1 + "\n"; }
            if (!string.IsNullOrEmpty(lstActiveShipments[position].OriginAddress2))
            { fromAddress += lstActiveShipments[position].OriginAddress2 + "\n"; }
            holder.txtViewFromValue.Text = fromAddress + lstActiveShipments[position].OriginCity + " "
                + lstActiveShipments[position].OriginState + " "
                + lstActiveShipments[position].OriginZip;
            if (!string.IsNullOrEmpty(lstActiveShipments[position].ShipToAddress1))
            { toAddress = lstActiveShipments[position].ShipToAddress1 + "\n"; }
            if (!string.IsNullOrEmpty(lstActiveShipments[position].ShipToAddress2))
            {
                toAddress += lstActiveShipments[position].ShipToAddress2 + "\n";
                toAddress = toAddress.Replace("#", " ");
            }
            holder.txtViewToValue.Text = toAddress + lstActiveShipments[position].ShipToCity + " "
                + lstActiveShipments[position].ShipToState + " " + lstActiveShipments[position].ShipToZip;
            holder.txtViewPickupValue.Text = lstActiveShipments[position].PickupStr;
            holder.txtViewModeValue.Text = lstActiveShipments[position].Mode;
            //Active Shipment header 
            if (lstActiveShipments[position].LowestPriceLbl == "N/A")
            {
                holder.txtBolNum.Text = lstActiveShipments[position].BolNum;
                if (lstActiveShipments[position].IsTest == true)
                {
                    holder.txtBolNum.Text += Constants.strTestBol;
                }
            }
            else
            {
                holder.txtBolNum.Text = lstActiveShipments[position].BolNum;
                if (lstActiveShipments[position].IsTest == true)
                {
                    holder.txtBolNum.Text += Constants.strTestBol;
                }
                holder.txtBolNum.Text = holder.txtBolNum.Text + " : " + lstActiveShipments[position].LowestPriceLbl + " - " + "$" + lstActiveShipments[position].LowestPrice;
            }
            //Color Coding for active shipments
            string CarrierAlertLevel = lstActiveShipments[position].CarrierAlertLevel;
            holder.txtBidTimer.Text = lstActiveShipments[position].ShipTime;
            if (lstActiveShipments[position].ViewAs == Constants.strCarrier)
            {
                //holder.txtBidTimer.Text = lstActiveShipments[position].ShipTime;
                //Color Coding
                LayoutBgColor(CarrierAlertLevel.ToUpper(), holder.ItemView);
                //Bid Now for CARRIER
                if (lstActiveShipments[position].EnforceDeadline == true && lstActiveShipments[position].ShipTime== Constants.timerMsg)
                {
                    holder.btnBidNow.Visibility = ViewStates.Gone;
                    if (lstActiveShipments[position].CarriersBid == -1)
                    {
                        holder.txtBidMsg.Visibility = ViewStates.Visible;
                        holder.txtBidMsg.Text = Constants.strNoBids;
                        holder.lnrBidNowMsg.Visibility = ViewStates.Visible;
                    }
                    else if (lstActiveShipments[position].CarriersBid != -1)
                    {
                        holder.txtBidMsg.Visibility = ViewStates.Visible;
                        holder.txtBidMsg.Text = Constants.strCurrentBid + lstActiveShipments[position].CarriersBid;
                    }

                    else
                    {
                        holder.txtBidMsg.Visibility = ViewStates.Gone;
                    }
                }
                else
                {
                    if (lstActiveShipments[position].CarriersBid == -1)
                    {
                        holder.txtBidMsg.Visibility = ViewStates.Visible;
                        holder.txtBidMsg.Text = Constants.strNoBids;
                        holder.lnrBidNowMsg.Visibility = ViewStates.Visible;
                        holder.btnBidNow.Visibility = ViewStates.Visible;
                    }
                    else if (lstActiveShipments[position].CarriersBid != -1)
                    {
                        holder.btnBidNow.Visibility = ViewStates.Gone;
                        holder.txtBidMsg.Visibility = ViewStates.Visible;
                        holder.txtBidMsg.Text = Constants.strCurrentBid + lstActiveShipments[position].CarriersBid;
                    }

                    else
                    {
                        holder.txtBidMsg.Visibility = ViewStates.Gone;
                        holder.btnBidNow.Visibility = ViewStates.Gone;
                    }
                }
            }
            else  //Customer Login
            {
                holder.lnrActiveFor.Visibility = ViewStates.Gone; //For 
                                                                  //Bind Bid Content for customer 
                if (lstActiveShipments[position].Bids.Count > 0)
                {
                    holder.lnrLayBidHead.Visibility = ViewStates.Visible;
                    holder.lnrLayBidContent.Visibility = ViewStates.Visible;
                    holder.scrollViewBid.Visibility = ViewStates.Visible;
                    holder.viewCanAward.Visibility = ViewStates.Gone; //Header Space
                    holder.btnBidNow.Visibility = ViewStates.Gone; //Bid Now
                    objActiveShipment = lstActiveShipments[position];

                    objBindNowDetailAdapter = new BindNowDetailAdapter(context, objActiveShipment);
                   
                    lstViewBidDetails.Adapter = objBindNowDetailAdapter;

                    lstVWBid = new ListView(context);
                    int childCount = lstViewBidDetails.ChildCount;
                    lstViewBidDetails.LayoutParameters = new LinearLayout.LayoutParams(100, 100);
                    lstVWBid.Adapter = objBindNowDetailAdapter;
                    holder.lnrLayBidContent.RemoveAllViews();
                    for (int indexTracking = 0; indexTracking < lstVWBid.Count; indexTracking++)
                    {
                        viewTracking = lstVWBid.Adapter.GetView(indexTracking, null, null);
                        holder.lnrLayBidContent.AddView(viewTracking);
                    }


                    holder.txtBidMsg.Visibility = ViewStates.Gone;
                    holder.lnrBidNowMsg.Visibility = ViewStates.Gone;
                    foreach (var lstBid in lstActiveShipments[position].Bids)
                    {
                        if (lstBid.CanAward)
                        {
                            holder.viewCanAward.Visibility = ViewStates.Visible; //Header Space
                        }
                    }
                }
                else if (lstActiveShipments[position].Bids.Count == 0)
                {
                    holder.txtBidMsg.Visibility = ViewStates.Visible;
                    holder.txtBidMsg.Text = Constants.strNoBidYet;
                    holder.lnrBidNowMsg.Visibility = ViewStates.Visible;
                    holder.btnBidNow.Visibility = ViewStates.Gone;
                    holder.lnrLayBidContent.Visibility = ViewStates.Gone;
                    holder.scrollViewBid.Visibility = ViewStates.Gone;
                    holder.lnrLayBidHead.Visibility = ViewStates.Gone;
                   
                }
            }
            //Click event of the location textview
            value = holder.txtViewFromValue.Text + "#" + holder.txtViewToValue.Text + "#" + holder.txtBolNum.Text;
            objIntent = Utility.RedirectTo(context, typeof(ShipmentsAddressActivity), "location", value);
            //if (!holder.txtViewFromValue.HasOnClickListeners)
            //{
            //    holder.txtViewFromValue.Click += (sender, e) =>
            //    {
            //        context.StartActivity(objIntent);
            //    };
            //}
            //if (!holder.txtViewToValue.HasOnClickListeners)
            //{
            //    holder.txtViewToValue.Click += (sender, e) =>
            //    {
            //        context.StartActivity(objIntent);
            //    };
            //}
            //Redirecting to Detailed page
            //if (!holder.relativeHeader.HasOnClickListeners)
            //{
               
                //holder.relativeHeader.Click += (sender, e) =>
                //{
                //    if (CommanUtil.IsTimeOut())
                //    {
                //        value = lstActiveShipments[position].ClientID + "|" + lstActiveShipments[position].BolNum + "|" + "";
                //        objIntent = Utility.RedirectTo(context, typeof(ShipmentsDetailedActivity), "compositeKey", value);
                //        context.StartActivity(objIntent);
                //    }
                //    else
                //    {
                //        //Token Exired
                //        Utility.ExpireSession(context);
                //    }
                //};
            //}
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="viewType"></param>
        /// <returns></returns>
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            View itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.ActiveShipmentLayout, parent, false);
            ActiveShipmentsViewHolder vh = new ActiveShipmentsViewHolder(itemView, OnClick);
            return vh;
        }
        private void OnClick(int obj)
        {
            if (ItemClick != null)
                ItemClick(this, obj);
        }

        #region Declaration of variable
        /// <summary>
        /// List of the Recent Shipments
        /// </summary>
        public List<ActiveShipments> lstActiveShipments;
        /// <summary>
        /// 
        /// </summary>
        public Activity context;
        View viewCanAward = null;
        string value = string.Empty;
        Intent objIntent = null;
        ListView lstViewBidDetails;
        string fromAddress, toAddress = string.Empty;
        string rowPosition;
        ActiveShipments objActiveShipment;
        ListView lstVWBid = null;
        BindNowDetailAdapter objBindNowDetailAdapter = null;
        View viewTracking;
        #endregion

        /// <summary>
        /// Bid Now Button Click Event Function
        /// </summary>
        /// <param name="position">list of shipment position</param>
        private void BidNow(int position)
        {
            try
            {
                value = lstActiveShipments[position].ClientID + "|" + lstActiveShipments[position].BolNum + "|" + "2";
                objIntent = Utility.RedirectTo(context, typeof(ShipmentsDetailedActivity), "compositeKey", value);
                context.StartActivity(objIntent);
            }
            catch (Exception ex)
            {
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
            }
        }

        private void RedirectToShipmentAddressDetails(int position)
        {
            try
            {
                //value = lstActiveShipments[position].ClientID + "|" + lstActiveShipments[position].BolNum + "|" + "2";
                //objIntent = Utility.RedirectTo(context, typeof(ShipmentsDetailedActivity), "compositeKey", value);
                //context.StartActivity(objIntent);

                value = fromAddress + "#" + toAddress + "#" + lstActiveShipments[position].BolNum;
                objIntent = Utility.RedirectTo(context, typeof(ShipmentsAddressActivity), "location", value);

                context.StartActivity(objIntent);
            }
            catch (Exception ex)
            {
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
            }
        }

        /// <summary>
        /// Changing color of layouts
        /// </summary>
        /// <param name="CarrierAlertLevel">evenColor</param>
        /// <param name="convertView">Referenced View</param>
        private void LayoutBgColor(string CarrierAlertLevel, View convertView)
        {
            try
            {
                var view = convertView;
                //finding all layouts
                LinearLayout lnrActiveFor, lntlayoutDeadline, lntlayoutFrom, lntlayoutTo, lnrLayoutPickup, lntlayoutMode;
                lnrActiveFor = view.FindViewById<LinearLayout>(Resource.Id.lnrActiveFor);
                lntlayoutDeadline = view.FindViewById<LinearLayout>(Resource.Id.lntlayoutDeadline);
                lntlayoutFrom = view.FindViewById<LinearLayout>(Resource.Id.lntlayoutFrom);
                lntlayoutTo = view.FindViewById<LinearLayout>(Resource.Id.lntlayoutTo);
                lnrLayoutPickup = view.FindViewById<LinearLayout>(Resource.Id.lnrLayoutPickup);
                lntlayoutMode = view.FindViewById<LinearLayout>(Resource.Id.lntlayoutMode);
                //Set backgroud Color of the layout
                if (CarrierAlertLevel.ToUpper() == Constants.btnTextOk.ToUpper())
                {
                    lnrActiveFor.SetBackgroundResource(Resource.Color.Ok_evenColor);
                    lntlayoutDeadline.SetBackgroundResource(Resource.Color.Ok_oddColor);
                    lntlayoutFrom.SetBackgroundResource(Resource.Color.Ok_evenColor);
                    lntlayoutTo.SetBackgroundResource(Resource.Color.Ok_oddColor);
                    lnrLayoutPickup.SetBackgroundResource(Resource.Color.Ok_evenColor);
                    lntlayoutMode.SetBackgroundResource(Resource.Color.Ok_oddColor);
                }
                else if (CarrierAlertLevel == Constants.strWarning.ToUpper())
                {
                    lnrActiveFor.SetBackgroundResource(Resource.Color.Warning_evenColor);
                    lntlayoutDeadline.SetBackgroundResource(Resource.Color.Warning_oddColor);
                    lntlayoutFrom.SetBackgroundResource(Resource.Color.Warning_evenColor);
                    lntlayoutTo.SetBackgroundResource(Resource.Color.Warning_oddColor);
                    lnrLayoutPickup.SetBackgroundResource(Resource.Color.Warning_evenColor);
                    lntlayoutMode.SetBackgroundResource(Resource.Color.Warning_oddColor);
                }
                else
                {
                    lnrActiveFor.SetBackgroundResource(Resource.Color.Critical_evenColor);
                    lntlayoutDeadline.SetBackgroundResource(Resource.Color.Critical_oddColor);
                    lntlayoutFrom.SetBackgroundResource(Resource.Color.Critical_evenColor);
                    lntlayoutTo.SetBackgroundResource(Resource.Color.Critical_oddColor);
                    lnrLayoutPickup.SetBackgroundResource(Resource.Color.Critical_evenColor);
                    lntlayoutMode.SetBackgroundResource(Resource.Color.Critical_oddColor);
                }

            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Convert Pixels to Dp
        /// </summary>
        /// <param name="pixels"></param>
        /// <returns></returns>
        private int PixelsToDp(int pixels)
        {
            try
            {
                return (int)TypedValue.ApplyDimension(ComplexUnitType.Dip, pixels, Resources.System.DisplayMetrics);
            }
            catch
            {
                throw;
            }
        }
    }
    /// <summary>
    /// 
    /// </summary>
    public class ActiveShipmentsViewHolder : RecyclerView.ViewHolder
    {
        public Activity context;
        Intent objIntent = null;

        /// <summary>
        /// 
        /// </summary>
        public TextView txtBolNum { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public TextView txtViewForValue { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public TextView txtViewDeadlineValue { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public TextView txtViewFromValue { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public TextView txtViewToValue { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public TextView txtViewPickupValue { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public TextView txtViewModeValue { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public TextView txtBidTimer { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public TextView txtBidMsg { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Button btnBidNow { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public LinearLayout lnrActiveFor { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public LinearLayout lnrBidNowMsg { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public LinearLayout lnrLayBidHead { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public LinearLayout lnrLayBidContent { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public View viewCanAward { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public RelativeLayout relativeHeader { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public ListView lstViewBidDetails { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public ScrollView scrollViewBid { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public ActiveShipmentsViewHolder(View itemview, Action<int> listener) : base(itemview)
        {
            txtBolNum = itemview.FindViewById<TextView>(Resource.Id.txtBolNum);
            txtViewForValue = itemview.FindViewById<TextView>(Resource.Id.txtViewForValue);
            txtViewDeadlineValue = itemview.FindViewById<TextView>(Resource.Id.txtViewDeadlineValue);
            txtViewFromValue = itemview.FindViewById<TextView>(Resource.Id.txtViewFromValue);
            txtViewToValue = itemview.FindViewById<TextView>(Resource.Id.txtViewToValue);
            txtViewPickupValue = itemview.FindViewById<TextView>(Resource.Id.txtViewPickupValue);
            txtViewModeValue = itemview.FindViewById<TextView>(Resource.Id.txtViewModeValue);
            txtBidTimer = itemview.FindViewById<TextView>(Resource.Id.txtBidTimer);
            relativeHeader = itemview.FindViewById<RelativeLayout>(Resource.Id.relativeHeader);
            lnrLayBidHead = itemview.FindViewById<LinearLayout>(Resource.Id.lnrLayBidHead);
            lnrActiveFor = itemview.FindViewById<LinearLayout>(Resource.Id.lnrActiveFor);
            viewCanAward = itemview.FindViewById<View>(Resource.Id.viewCanAward);
            txtBidMsg = itemview.FindViewById<TextView>(Resource.Id.txtBidMsg);
            btnBidNow = itemview.FindViewById<Button>(Resource.Id.btnBidNow);
            lnrLayBidContent = itemview.FindViewById<LinearLayout>(Resource.Id.lnrLayBidContent);
            lstViewBidDetails = itemview.FindViewById<ListView>(Resource.Id.lstViewBidDetails);
            lnrBidNowMsg = itemview.FindViewById<LinearLayout>(Resource.Id.lnrBidNowMsg);
            scrollViewBid = itemview.FindViewById<ScrollView>(Resource.Id.scrollViewBid);
            relativeHeader.Click += (sender, e) => listener(base.Position);
            txtViewFromValue.Click += TxtViewFromValue_Click;
            txtViewToValue.Click += TxtViewToValue_Click;

        }

        private void TxtViewToValue_Click(object sender, EventArgs e)
        {
            string value = txtViewFromValue.Text + "#" + txtViewToValue.Text + "#" + txtBolNum.Text;
            objIntent = Utility.RedirectTo(context, typeof(ShipmentsAddressActivity), "location", value);

            context.StartActivity(objIntent);
        }

        private void TxtViewFromValue_Click(object sender, EventArgs e)
        {
           string value = txtViewFromValue.Text + "#" + txtViewToValue.Text + "#" + txtBolNum.Text;
            objIntent = Utility.RedirectTo(context, typeof(ShipmentsAddressActivity), "location", value);

            context.StartActivity(objIntent);
        }
        private void BindVaribleData()
        {

        }
    }
}