using System;
using System.Collections.Generic;
using Android.App;
using Android.Views;
using Android.Widget;
using RateLinx.Models;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;

namespace RateLinx.Droid.Adapters
{
    class RateHistoryEntriesAdapter : BaseAdapter<OldEntry>
    {
        #region Declaration of variable
        /// <summary>
        /// List of the Options in Shipments
        /// </summary>
        public List<OldEntry> lstOldEntry;
        Utility objUtility = null;
        Activity context;
        TextView txtCarrier, txtAmount, txtDateEntered;
        LinearLayout lnrRateEntries;
        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="lstOldEntry"></param>
        public RateHistoryEntriesAdapter(Activity context, List<OldEntry> lstOldEntry)
                : base()
            {
            this.context = context;
            this.lstOldEntry = lstOldEntry;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public override long GetItemId(int position)
        {
            return position;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public override OldEntry this[int position]
        {
            get
            {
                return lstOldEntry[position];
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public override int Count
        {
            get { return lstOldEntry.Count; }
        }

        /// <summary>
        /// Get the View Controls and bind them
        /// </summary>
        /// <param name="position"></param>
        /// <param name="convertView"></param>
        /// <param name="parent"></param>
        /// <returns></returns>
        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            View view = convertView;
            try
            {
                if (view == null)
                view = context.LayoutInflater.Inflate(Resource.Layout.RateHistoryEntryLayout, null);
                //Get the controls
                txtCarrier = view.FindViewById<TextView>(Resource.Id.txtCarrier);
                txtAmount = view.FindViewById<TextView>(Resource.Id.txtAmount);
                txtDateEntered = view.FindViewById<TextView>(Resource.Id.txtDateEntered);
                lnrRateEntries =view.FindViewById<LinearLayout>(Resource.Id.lnrRateEntries);

                txtCarrier.Text = lstOldEntry[position].SCAC;
                txtAmount.Text = Convert.ToString(lstOldEntry[position].Price);
                txtDateEntered.Text = lstOldEntry[position].EnteredOnStr;
                
                if (lstOldEntry[position].Status.ToUpper() == Constants.strBID.ToUpper())
                {
                    txtCarrier.SetTypeface(null, Android.Graphics.TypefaceStyle.Bold);
                    txtAmount.SetTypeface(null, Android.Graphics.TypefaceStyle.Bold);
                    txtDateEntered.SetTypeface(null, Android.Graphics.TypefaceStyle.Bold);
                }
                objUtility = new Utility();
                objUtility.ChangeLayoutColor(lnrRateEntries, view, position);
                return view;
            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                return null;
            }
        }
    }
}