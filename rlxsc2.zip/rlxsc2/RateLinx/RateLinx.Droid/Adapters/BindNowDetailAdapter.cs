using System;
using System.Collections.Generic;
using Android.App;
using Android.Views;
using Android.Widget;
using RateLinx.Models;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;
using RateLinx.APIs;
using Newtonsoft.Json.Linq;
using System.Threading.Tasks;

namespace RateLinx.Droid.Adapters
{
    /// <summary>
    /// BindNowDetailAdapter
    /// </summary>
    public class BindNowDetailAdapter :BaseAdapter<Bid>
    {
        ActiveShipments objActiveShipment;
        Activity context;
        List<Bid> lstBids;
        TextView txtCarrierName, txtBidPrice, txtAltCheck, txtBidStatus;
        LinearLayout lnrLayBidContent = null;
        ImageView imgCanAwardIcon = null;
        Utility objUtility;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="objActiveShipment"></param>
        public BindNowDetailAdapter(Activity context, ActiveShipments objActiveShipment)
                : base()
        {
            this.context = context;
            this.objActiveShipment = objActiveShipment;
            lstBids = objActiveShipment.Bids;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public override long GetItemId(int position)
        {
            return position;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public override Bid this[int position]
        {
            get
            {
                return lstBids[position];
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public override int Count
        {
            get { return lstBids.Count; }
        }
        /// <summary>
        /// Get the View Controls and bind them
        /// </summary>
        /// <param name="position"></param>
        /// <param name="convertView"></param>
        /// <param name="parent"></param>
        /// <returns></returns>
        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            View view = convertView;
            try
            {
                if (view == null)
                    view = context.LayoutInflater.Inflate(Resource.Layout.BidingDetailsLayout, null);
                //Get the controls
                txtCarrierName = view.FindViewById<TextView>(Resource.Id.txtCarrierName);
                txtBidPrice = view.FindViewById<TextView>(Resource.Id.txtBidPrice);
                txtBidStatus = view.FindViewById<TextView>(Resource.Id.txtBidStatus);
                txtAltCheck = view.FindViewById<TextView>(Resource.Id.txtAltCheck);
                lnrLayBidContent = view.FindViewById<LinearLayout>(Resource.Id.lnrLayBidContent);
                imgCanAwardIcon = view.FindViewById<ImageView>(Resource.Id.imgCanAwardIcon);

                txtCarrierName.Text = lstBids[position].Carrier;
                txtBidPrice.Text = "$"+Convert.ToString(lstBids[position].Price);
                if (lstBids[position].AltTerms)
                { txtAltCheck.Text = Constants.btnTextYes; }
                else
                { txtAltCheck.Text = Constants.btnTextNo; }
                txtBidStatus.Text = lstBids[position].Status;
                imgCanAwardIcon.Click += async delegate
                {
                    if (CommanUtil.IsTimeOut())
                    {
                        await AwardTheShipment(lstBids[position].ID);
                    }
                    else
                    {
                        //Token Exired
                        Utility.ExpireSession(context);
                    }
                };
                if (lstBids[position].CanAward)
                {
                    imgCanAwardIcon.Visibility = ViewStates.Visible;
                }
                else
                {
                    imgCanAwardIcon.Visibility = ViewStates.Gone;
                }
                //For Changing Layout Color Dynamically
                objUtility = new Utility();
                objUtility.ChangeLayoutColor(lnrLayBidContent, view, position);
                return view;
            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                return null;
            }
        }

        /// <summary>
        /// Award The Shipment for customer login 
        /// </summary>
        /// <param name="bidID">Bid ID</param>
        private async Task AwardTheShipment(int bidID)
        {
            try
            {
                JObject jobject = null;
                string methodName = string.Empty;
                //Get the service Helper Object
                ServiceHelper objServicehelper = new ServiceHelper();
                // create json object that holds the api values
                //Method Name  award
                methodName = APIMethods.shipmentDetails + "/" + objActiveShipment.ClientID + "|" + objActiveShipment.LocID + "|" + objActiveShipment.BolNum;
                methodName += "/" + bidID + "/" + APIMethods.award;
                Alerts.showBusyLoader(context);
                //Get the Shipments
                string strResponse = await objServicehelper.PostRequestJson("", methodName, CommanUtil.tokenNo, true);
                Alerts.HideBusyLoader();
                if (strResponse != null)
                {
                    jobject = JObject.Parse(strResponse);
                    //if (string.IsNullOrEmpty(Convert.ToString(Constants.strErrorMessage)))
                    //{
                    //    Utility.sharedPreferences.Edit().Remove(Constants.shipmentDetails).Commit();
                    //    Utility.sharedPreferences.Edit().PutString(Constants.shipmentDetails, strResponse).Commit();
                    //}
                    if (strResponse.Contains("Success"))
                    {
                        Toast.MakeText(context, Convert.ToString(Constants.awardedSucessfully), ToastLength.Long).Show();
                        Utility.sharedPreferences.Edit().Remove(Constants.shipmentDetails).Commit();
                        Utility.sharedPreferences.Edit().PutString(Constants.shipmentDetails, strResponse).Commit();
                    }
                    else
                    {
                        Toast.MakeText(context, Convert.ToString(Constants.strErrorMessage), ToastLength.Long).Show();
                        Utility.ErrorLog(Constants.strCanAward, Convert.ToString(Constants.strErrorMessage), CommanUtil.tokenNo, context);
                    }
                    strResponse = string.Empty;
                }
            }
            catch
            {
                throw;
            }
        }
    }
}