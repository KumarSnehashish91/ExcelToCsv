using System;
using System.Collections.Generic;
using Android.App;
using Android.Views;
using Android.Widget;
using RateLinx.Droid.Utilities;
using System.Runtime.InteropServices;
using RateLinx.Helper;

namespace RateLinx.Droid.Adapters
{
    /// <summary>
    /// Meta Tag of the class
    /// </summary>
    [ComVisible(false)]
    public class FileListAdapter
    {
        /// <summary>
        /// Adapter to hold the option shipmets properties
        /// </summary>
        [ComVisible(true)]
        public class FileListAdapterShipments : BaseAdapter<string>
        {
            #region Declaration of variable
            /// <summary>
            /// List of the Options in Shipments
            /// </summary>
            public List<string> lstSSShipments;
            Utility objUtility = null;
            Activity context;
            TextView txtFilesName;
            LinearLayout lnrLayoutFiles;
            #endregion

            /// <summary>
            /// 
            /// </summary>
            /// <param name="context"></param>
            /// <param name="lstSSShipments"></param>
            public FileListAdapterShipments(Activity context, List<string> lstSSShipments)
                : base()
            {
                this.context = context;
                this.lstSSShipments = lstSSShipments;
            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="position"></param>
            /// <returns></returns>
            public override long GetItemId(int position)
            {
                return position;
            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="position"></param>
            /// <returns></returns>
            public override string this[int position]
            {
                get
                {
                    return lstSSShipments[position];
                }
            }

            /// <summary>
            /// 
            /// </summary>
            public override int Count
            {
                get { return lstSSShipments.Count; }
            }

            /// <summary>
            /// Get the View Controls and bind them
            /// </summary>
            /// <param name="position"></param>
            /// <param name="convertView"></param>
            /// <param name="parent"></param>
            /// <returns></returns>
            public override View GetView(int position, View convertView, ViewGroup parent)
            {
                View view = convertView;
                try
                {
                   // if (view == null)
                        view = context.LayoutInflater.Inflate(Resource.Layout.SupportingFileLayout, null);
                    //Get the controls
                    txtFilesName = view.FindViewById<TextView>(Resource.Id.txtFilesName);
                    lnrLayoutFiles = view.FindViewById<LinearLayout>(Resource.Id.lnrLayoutFiles);
                    //Assign Values from API response
                    txtFilesName.Text = lstSSShipments[position];
                    //File Name
                    int cut = txtFilesName.Text.LastIndexOf('/');
                    if (cut != -1)
                    {
                        txtFilesName.Text = txtFilesName.Text.Substring(cut + 1);
                    }
                    objUtility = new Utility();
                    objUtility.ChangeLayoutColor(lnrLayoutFiles, view, position);
                    return view;
                }
                catch
                {
                     Console.Write(Constants.strErrorOccured);
                    return null;
                }
            }
        }
    }
}