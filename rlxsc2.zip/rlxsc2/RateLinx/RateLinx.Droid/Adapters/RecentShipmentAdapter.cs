using System;
using System.Collections.Generic;
using Android.App;
using Android.Content;
using Android.Views;
using Android.Widget;
using RateLinx.Models;
using RateLinx.Droid.Activities;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;
using Newtonsoft.Json;
using Android.Support.V4.Content;
using Android;
using Android.Content.PM;
//using Android.Support.V4.App;
using RateLinx.APIs;
using V4App = Android.Support.V4.App;
using System.Threading.Tasks;
using RateLinx.Droid.Fragments;

namespace RateLinx.Droid.Adapters
{
    /// <summary>
    /// Meta Tag RecentShipmentUtility   
    /// </summary>
    public class RecentShipmentAdapter
    {
        /// <summary>
        /// Adapter to hold the Recent shipmets properties 
        /// </summary>
        public class AdapterRecentShipments : BaseAdapter<RecentShipments>
        {
            #region Declaration of variable
            /// <summary>
            /// List of the Recent Shipments
            /// </summary>
            public List<RecentShipments> lstRecentShipments;
            ImageView imgTrackLocation;
            /// <summary>
            /// 
            /// </summary>
            public Activity context;
            TextView txtViewHeader, txtViewForValue, txtViewFromValue, txtViewToValue,
                txtViewPickupValue, txtViewDriverIDValue, txtViewDeliverValue, txtViewEmailValue,
                txtViewPhoneValue;
            RelativeLayout rltLayoutRecent = null;
            string ShipmentTrackingList = string.Empty;
            LinearLayout lnrlocationbuttons, lnrLayoutConfirmations;
            string value = string.Empty;
            Dialog dialog = null;
            Utility objUtility;
            CarrierShipmentDetails carrierShipmentDetails = null;
            Button btnfindCurrentlc, btnCompareRoute, btnPickup, btnDelivery = null;
            string compositeKey = string.Empty;

            readonly string[] PermissionsLocation =
                         {
         Manifest.Permission.AccessCoarseLocation,
         Manifest.Permission.AccessFineLocation
        };
            /// <summary>
            /// 
            /// </summary>
            public V4App.FragmentActivity fragmentActivity;
            #endregion

            /// <summary>
            /// Adapter of Recent Shipments
            /// </summary>
            /// <param name="context"></param>
            /// <param name="lstRecentShipments"></param>
            /// <param name="fragmentActivity"></param>
            public AdapterRecentShipments(Activity context, List<RecentShipments> lstRecentShipments, V4App.FragmentActivity fragmentActivity)
                : base()
            {
                this.context = context;
                this.lstRecentShipments = lstRecentShipments;
                this.fragmentActivity = fragmentActivity;
            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="position"></param>
            /// <returns></returns>
            public override long GetItemId(int position)
            {
                return position;
            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="position"></param>
            /// <returns></returns>
            public override RecentShipments this[int position]
            {
                get
                {
                    return lstRecentShipments[position];
                }
            }

            /// <summary>
            /// 
            /// </summary>
            public override int Count
            {
                get { return lstRecentShipments.Count; }
            }

            /// <summary>
            /// bind the recent shipment values
            /// </summary>
            /// <param name="position"></param>
            /// <param name="convertView"></param>
            /// <param name="parent"></param>
            /// <returns></returns>
            public override View GetView(int position, View convertView, ViewGroup parent)
            {
                View view = convertView;
                try
                {
                    #region Get the controld By ID
                    view = context.LayoutInflater.Inflate(Resource.Layout.RecentShipmentLayout, null);
                    //Get the controls
                    imgTrackLocation = view.FindViewById<ImageView>(Resource.Id.imgTrackLocation);
                    txtViewHeader = view.FindViewById<TextView>(Resource.Id.txtViewHeader);
                    txtViewForValue = view.FindViewById<TextView>(Resource.Id.txtViewForValue);
                    txtViewFromValue = view.FindViewById<TextView>(Resource.Id.txtViewFromValue);
                    txtViewToValue = view.FindViewById<TextView>(Resource.Id.txtViewToValue);
                    txtViewPickupValue = view.FindViewById<TextView>(Resource.Id.txtViewPickupValue);
                    txtViewDriverIDValue = view.FindViewById<TextView>(Resource.Id.txtViewDriverIDValue);
                    txtViewDeliverValue = view.FindViewById<TextView>(Resource.Id.txtViewDeliverValue);
                    txtViewEmailValue = view.FindViewById<TextView>(Resource.Id.txtViewEmailValue);
                    txtViewPhoneValue = view.FindViewById<TextView>(Resource.Id.txtViewPhoneValue);
                    rltLayoutRecent = view.FindViewById<RelativeLayout>(Resource.Id.rltLayoutRecent);
                    btnDelivery = view.FindViewById<Button>(Resource.Id.btnDelivery);
                    btnPickup = view.FindViewById<Button>(Resource.Id.btnPickup);
                    btnfindCurrentlc = view.FindViewById<Button>(Resource.Id.btnfindCurrentlc);
                    btnCompareRoute = view.FindViewById<Button>(Resource.Id.btnCompareRoute);
                    btnCompareRoute.Visibility = ViewStates.Gone;
                    lnrlocationbuttons = view.FindViewById<LinearLayout>(Resource.Id.lnrlocationbuttons);
                    lnrLayoutConfirmations = view.FindViewById<LinearLayout>(Resource.Id.lnrLayoutConfirmations);
                    string fromAddress = ""; string toAddress = "";



                    #endregion
                    #region Customer conditions
                    if (lstRecentShipments[position].ViewAs.ToUpper() == Constants.strCustomer.ToUpper())
                    {
                        btnCompareRoute.Visibility = ViewStates.Visible;
                        btnfindCurrentlc.Visibility = ViewStates.Visible;
                        lnrlocationbuttons.Visibility = ViewStates.Visible;
                        btnfindCurrentlc.Text = Constants.trackShipment;
                        btnCompareRoute.Text = Constants.btnTextCompare;
                    }
                    #endregion
                    #region Carrier Conditions
                    else
                    {
                        lnrlocationbuttons.Visibility = ViewStates.Visible;
                        lnrLayoutConfirmations.Visibility = ViewStates.Visible;
                        btnCompareRoute.Visibility = ViewStates.Invisible;
                        btnfindCurrentlc.Visibility = ViewStates.Visible;
                        //Check from the driver's API. If Driver's API gives 0 result then button text will be "Update Shipment Status".
                        btnfindCurrentlc.Text = Constants.updateShipmentStatus;
                        if (lstRecentShipments[position].DispatchFlag || CommanUtil.UserPermissions.Contains("ADMINUSERS") ||
                            CommanUtil.UserPermissions.Contains("ALLOWDISPATCH") || CommanUtil.UserPermissions.Contains("DISPATCHDRIVER") || CommanUtil.UserPermissions.Contains("ASSIGNSHIPMENTDRIVER"))
                        {
                            if (CommanUtil.UserPermissions != null && CommanUtil.UserPermissions.Count > 0)
                            {
                                if (CommanUtil.UserPermissions.Contains("ADMINUSERS")|| CommanUtil.UserPermissions.Contains("ASSIGNSHIPMENTDRIVER"))
                                {
                                    if (!string.IsNullOrEmpty(lstRecentShipments[position].DriverID)
                                        && lstRecentShipments[position].DriverID.Equals(CommanUtil.userID))
                                    {
                                        imgTrackLocation.Visibility = ViewStates.Visible;
                                        btnfindCurrentlc.Text = Constants.updateShipmentStatus;//Check from the driver's API. If Driver's API gives 0 result then button text will be "Update Shipment Status".
                                    }
                                    else
                                    {
                                        if (!string.IsNullOrEmpty(lstRecentShipments[position].DriverID)
                                            && !lstRecentShipments[position].DriverID.Equals(CommanUtil.userID))
                                        {
                                            imgTrackLocation.Visibility = ViewStates.Visible;
                                            btnfindCurrentlc.Visibility = ViewStates.Visible;
                                            btnfindCurrentlc.Text = Constants.trackShipment; //Constants.trackShipment;
                                        }
                                        else
                                        {
                                            imgTrackLocation.Visibility = ViewStates.Gone;
                                            btnfindCurrentlc.Text = Constants.assignDriver;//Check from the driver's API. If Driver's API gives 0 result then button text will be "Update Shipment Status".
                                            lnrLayoutConfirmations.Visibility = ViewStates.Gone;
                                        }

                                    }

                                }
                                else if (CommanUtil.UserPermissions.Contains(Constants.dispatcherDriver))
                                {
                                    if (!string.IsNullOrEmpty(lstRecentShipments[position].DriverID)
                                       && lstRecentShipments[position].DriverID.Equals(CommanUtil.userID))
                                    {
                                        imgTrackLocation.Visibility = ViewStates.Visible;
                                        btnfindCurrentlc.Text = Constants.updateShipmentStatus;//Check from the driver's API. If Driver's API gives 0 result then button text will be "Update Shipment Status".
                                    }
                                    else
                                    {
                                        lnrlocationbuttons.Visibility = ViewStates.Gone;
                                        imgTrackLocation.Visibility = ViewStates.Gone;
                                        lnrLayoutConfirmations.Visibility = ViewStates.Gone;
                                    }

                                }
                                else
                                {
                                    lnrlocationbuttons.Visibility = ViewStates.Gone;
                                    imgTrackLocation.Visibility = ViewStates.Gone;
                                }
                            }
                            else
                            {
                                btnfindCurrentlc.Visibility = ViewStates.Visible;
                                imgTrackLocation.Visibility = ViewStates.Visible;
                                btnfindCurrentlc.Text = Constants.updateShipmentStatus;
                            }
                        }
                        else
                        {
                            lnrlocationbuttons.Visibility = ViewStates.Gone;
                            imgTrackLocation.Visibility = ViewStates.Gone;
                            lnrLayoutConfirmations.Visibility = ViewStates.Gone;
                        }
                    }
                    #endregion
                    #region Button Pickup and delivery condition
                    if (lstRecentShipments[position].Status == Constants.strClosed)
                    {
                        if (lstRecentShipments[position].ViewAs.ToUpper() == Constants.strCustomer.ToUpper())
                        {
                            btnPickup.Visibility = ViewStates.Gone;
                            btnDelivery.Visibility = ViewStates.Gone;
                            lnrLayoutConfirmations.Visibility = ViewStates.Gone;
                        }
                        else
                        {
                            btnPickup.Visibility = ViewStates.Visible;
                            btnDelivery.Visibility = ViewStates.Visible;
                        }
                    }
                    else
                    {
                        btnPickup.Visibility = ViewStates.Gone;
                        btnDelivery.Visibility = ViewStates.Gone;
                    }
                    btnDelivery.Click += delegate
                    {
                        if ((ContextCompat.CheckSelfPermission(context, Manifest.Permission.AccessFineLocation) == (int)Permission.Granted) &&
                 (ContextCompat.CheckSelfPermission(context, Manifest.Permission.AccessCoarseLocation) == (int)Permission.Granted))
                        {
                            GotoShipConfirmation(position, Constants.strDeliveryConf);
                        }
                        else
                        {
                            V4App.ActivityCompat.RequestPermissions(context, PermissionsLocation, 0);
                        }

                    };
                    btnPickup.Click += delegate
                    {
                        if ((ContextCompat.CheckSelfPermission(context, Manifest.Permission.AccessFineLocation) == (int)Permission.Granted) &&
                 (ContextCompat.CheckSelfPermission(context, Manifest.Permission.AccessCoarseLocation) == (int)Permission.Granted))
                        {
                            GotoShipConfirmation(position, Constants.strPickConf);
                        }
                        else
                        {
                            V4App.ActivityCompat.RequestPermissions(context, PermissionsLocation, 0);
                        }

                    };
                    #endregion
                    #region Data Binding
                    txtViewHeader.Text = lstRecentShipments[position].BolNum;
                    txtViewForValue.Text = lstRecentShipments[position].ClientID;
                    if (!string.IsNullOrEmpty(lstRecentShipments[position].OriginAddress1))
                    { fromAddress = lstRecentShipments[position].OriginAddress1 + "\n"; }
                    if (!string.IsNullOrEmpty(lstRecentShipments[position].OriginAddress2))
                    { fromAddress += lstRecentShipments[position].OriginAddress2 + "\n"; }
                    txtViewFromValue.Text = fromAddress +
                        lstRecentShipments[position].OriginCity + " "
                        + lstRecentShipments[position].OriginState + " "
                        + lstRecentShipments[position].OriginZip;
                    if (!string.IsNullOrEmpty(lstRecentShipments[position].ShipToAddress1))
                    { toAddress = lstRecentShipments[position].ShipToAddress1 + "\n"; }
                    if (!string.IsNullOrEmpty(lstRecentShipments[position].ShipToAddress2))
                    { toAddress += lstRecentShipments[position].ShipToAddress2 + "\n"; }
                    txtViewToValue.Text = toAddress +
                       lstRecentShipments[position].ShipToCity + " "
                        + lstRecentShipments[position].ShipToState + " " + lstRecentShipments[position].ShipToZip;
                    txtViewPickupValue.Text = lstRecentShipments[position].PickupStr;
                    txtViewDriverIDValue.Text = lstRecentShipments[position].DriverID;
                    txtViewDeliverValue.Text = lstRecentShipments[position].DeliverOnStr;
                    txtViewEmailValue.Text = lstRecentShipments[position].OriginEmail;
                    txtViewPhoneValue.Text = lstRecentShipments[position].OriginPhone;
                    //sending values to other page
                    value = txtViewFromValue.Text + "#" + txtViewToValue.Text + "#" + txtViewHeader.Text;
                    Intent intentAddress = Utility.RedirectTo(context, typeof(ShipmentsAddressActivity), "location", value);
                    #endregion
                    #region Controls Click events
                    //Assign driver OR Trach Shipment OR Update Shipment Status 
                    btnfindCurrentlc.Click += async delegate
                     {
                         if (CommanUtil.IsTimeOut())
                         {
                             await UpdateTrackShipment(position);
                         }
                         else
                         {
                             //Token Exired
                             Utility.ExpireSession(context);
                         }
                     };
                    //Compare Route
                    btnCompareRoute.Click += delegate
                    {
                        if (CommanUtil.IsTimeOut())
                        {
                            GoToComparisonRouteMap(position);
                        }
                        else
                        {
                            //Token Exired
                            Utility.ExpireSession(context);
                        }
                    };
                    //Display map on click of address
                    txtViewFromValue.Click += (sender, e) =>
                    {
                        compositeKey = APIMethods.shipmentDetails + "/" + lstRecentShipments[position].ClientID + "|" + lstRecentShipments[position].BolNum;
                        
                        ShipmentsAddressActivity shipmentsAddressActivity = new ShipmentsAddressActivity(compositeKey);
                        //shipmentsAddressActivity.compositeKey = APIMethods.shipmentDetails + "/" + lstRecentShipments[position].ClientID + "|" + lstRecentShipments[position].BolNum;
                        context.StartActivity(intentAddress);
                    };
                    //Display map on click of address
                    txtViewToValue.Click += (sender, e) =>
                    {
                        compositeKey = APIMethods.shipmentDetails + "/" + lstRecentShipments[position].ClientID + "|" + lstRecentShipments[position].BolNum;

                        ShipmentsAddressActivity shipmentsAddressActivity = new ShipmentsAddressActivity(compositeKey);
                        //shipmentsAddressActivity.compositeKey = APIMethods.shipmentDetails + "/" + lstRecentShipments[position].ClientID + "|" + lstRecentShipments[position].BolNum;
                        context.StartActivity(intentAddress);
                    };
                    //Redirecting to Detailed page
                    rltLayoutRecent.Click += (sender, e) =>
                    {
                        if (CommanUtil.IsTimeOut())
                        {
                            Constants.loc_SourceDest = lstRecentShipments[position].OriginCompany + " " +
                      fromAddress +
                      lstRecentShipments[position].OriginCity + " "
                      + lstRecentShipments[position].OriginState + " "
                      + lstRecentShipments[position].OriginZip + "#" +
                      toAddress
                      + lstRecentShipments[position].ShipToCity + " "
                      + lstRecentShipments[position].ShipToState + " "
                      + lstRecentShipments[position].ShipToZip + "#"
                      + lstRecentShipments[position].BolNum + "#"
                      + lstRecentShipments[position].LocID + "#"
                      + lstRecentShipments[position].ClientID + "#"
                      + lstRecentShipments[position].DriverID + "#"
                      + lstRecentShipments[position].ProNum + "#"
                      + lstRecentShipments[position].OriginPhone;

                            value = lstRecentShipments[position].ClientID + "|" + lstRecentShipments[position].BolNum + "|" + "";
                            Intent intentDetail = Utility.RedirectTo(context, typeof(ShipmentsDetailedActivity), "compositeKey", value);
                            context.StartActivity(intentDetail);
                        }
                        else
                        {
                            //Token Exired
                            Utility.ExpireSession(context);
                        }
                    };
                    //Redirect To Driver Navigation page
                    imgTrackLocation.Click += async (sender, e) =>
                     {
                         if (CommanUtil.IsTimeOut())
                         {
                             await UpdateTrackShipment(position);
                         }
                         else
                         {
                             //Token Exired
                             Utility.ExpireSession(context);
                         }
                     };
                    #endregion
                    return view;
                }
                catch (Exception ex)
                {
                    Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                    // Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                    return null;
                }
            }

            /// <summary>
            /// Function for accepting recent shipment from driver
            /// </summary>
            private async Task UpdateTrackShipment(int position)
            {
                try
                {
                    if (lstRecentShipments[position].ViewAs.ToUpper() == Constants.strCarrier.ToUpper())
                    {
                        if (CommanUtil.UserPermissions != null && CommanUtil.UserPermissions.Count > 0)
                        {
                            if (CommanUtil.UserPermissions.Contains("ADMINUSERS") || CommanUtil.UserPermissions.Contains("ASSIGNSHIPMENTDRIVER"))
                            {
                                if (!string.IsNullOrEmpty(lstRecentShipments[position].DriverID)
                                    && lstRecentShipments[position].DriverID.Equals(CommanUtil.userID))
                                {
                                    await UpdateTrackShipment(Constants.updateShipmentStatus, position);
                                }
                                else
                                {
                                    if (!string.IsNullOrEmpty(lstRecentShipments[position].DriverID)
                                        && !lstRecentShipments[position].DriverID.Equals(CommanUtil.userID))
                                    {
                                        await UpdateTrackShipment(Constants.trackShipment, position);//trackShipment
                                    }
                                    else
                                    {
                                        await UpdateTrackShipment(Constants.assignDriver, position);
                                    }
                                }
                            }
                            else if (CommanUtil.UserPermissions.Contains(Constants.dispatcherDriver))
                            {
                                if (!string.IsNullOrEmpty(lstRecentShipments[position].DriverID)
                                   && lstRecentShipments[position].DriverID.Equals(CommanUtil.userID))
                                {
                                    await UpdateTrackShipment(Constants.updateShipmentStatus, position);
                                }
                            }
                        }
                        else
                        {
                            await UpdateTrackShipment(Constants.updateShipmentStatus, position);
                        }
                    }
                    else
                    {
                        await UpdateTrackShipment(Constants.trackShipment, position);
                    }
                }
                catch (Exception ex)
                {
                    Utility.ErrorLog(Constants.shipmentDetail, Constants.updateShipmentStatus, CommanUtil.tokenNo, context);
                    Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                }
            }

            /// <summary>
            /// Update Track Shipment status
            /// </summary>
            /// <param name="btnfindCurrentlc"></param>
            /// <param name="position"></param>
            public async Task UpdateTrackShipment(string btnfindCurrentlc, int position)
            {
                try
                {
                    if (btnfindCurrentlc == Constants.assignDriver)
                    {
                        await AssignDriverToShipmentAsync(position);
                    }
                    else
                    {
                        await TrackAndUpdateLocation(position, btnfindCurrentlc);
                    }
                }
                catch
                {
                    throw;
                }
            }

            /// <summary>
            /// Open Popup for Binding assign drivers
            /// </summary>
            public async Task AssignDriverToShipmentAsync(int position)
            {
                try
                {
                    ServiceHelper objServiceHelper = new ServiceHelper();
                    DriversList objDriversList = null;
                    List<string> lstDrivers = new List<string>();
                    Alerts.showBusyLoader(context); //Start Loader
                    if (!Utility.FnIsOnline(context))
                    {
                        Alerts.HideBusyLoader();
                        Toast.MakeText(context, Constants.strNoInternet, ToastLength.Short).Show();
                        return;
                    }
                    await Task.Delay(500);
                    string driverList = await objServiceHelper.GetDriverList();
                    if (!string.IsNullOrEmpty(driverList))
                    {
                        objDriversList = JsonConvert.DeserializeObject<DriversList>(driverList);
                        // lstDrivers.Add(Constants.filterBy); //My Self Text
                        if (objDriversList != null && objDriversList.Drivers.Count > 0)
                        {
                            foreach (var item in objDriversList.Drivers)
                            {
                                lstDrivers.Add(item.UserID);
                            }
                        }
                        AlertDialog.Builder alert = null;
                        alert = new AlertDialog.Builder(context);
                        alert.SetView(Resource.Layout.AssignDriverPopupLayout);
                        dialog = alert.Create();
                        dialog.Show();
                        Button btnNo = dialog.FindViewById<Button>(Resource.Id.btnNo);
                        Button btnAssign = dialog.FindViewById<Button>(Resource.Id.btnYes);
                        TextView txtViewClose = dialog.FindViewById<TextView>(Resource.Id.txtViewClose);
                        Spinner spinnerDriver = dialog.FindViewById<Spinner>(Resource.Id.spinnerDriver);
                        ArrayAdapter driverAdapter = new ArrayAdapter(context, Resource.Drawable.SpinnerCustomDesign, lstDrivers);
                        driverAdapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
                        spinnerDriver.Adapter = driverAdapter;
                        Alerts.HideBusyLoader();
                        driverAdapter = null;
                        btnNo.Click += delegate
                        {
                            //dialog.Hide();
                            dialog.Dismiss();
                        };
                        txtViewClose.Click += delegate
                        {
                            dialog.Hide();
                        };
                        btnAssign.Click += async delegate
                        {
                            await AssignDriverAsync(spinnerDriver.SelectedItem.ToString(), position);
                        };
                        dialog.SetCancelable(false);
                    }
                    else
                    {
                        Alerts.HideBusyLoader();
                        Toast.MakeText(context, Constants.driverNotAvail, ToastLength.Short).Show();
                    }
                }
                catch(Exception ex)
                {
                    Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                }
            }

            /// <summary>
            /// Assign Driver
            /// </summary>
            /// <param name="driverId"> Selected Driver</param>
            /// <param name="position">Position of selected shipment</param>
            /// <returns></returns>
            private async Task AssignDriverAsync(string driverId, int position)
            {
                try
                {
                    string message = string.Empty;
                    AssignDriver assignDriver = null;
                    if (driverId == Constants.strDriver)
                    {
                        Toast.MakeText(context, Constants.strSelectDriver, ToastLength.Long).Show();
                    }
                    else
                    {
                        Alerts.showBusyLoader(context); //Start Loader
                        await Task.Delay(1000);
                        if (!Utility.FnIsOnline(context))
                        {
                            Alerts.HideBusyLoader();
                            Toast.MakeText(context, Constants.strNoInternet, ToastLength.Short).Show();
                            return;
                        }
                        if (driverId.ToUpper().Equals(Constants.filterBy.ToUpper()))
                        {
                            driverId = lstRecentShipments[position].ClientID;
                        }
                        #region Assign Driver object
                        assignDriver = new AssignDriver();
                        assignDriver.bolNum = lstRecentShipments[position].BolNum;
                        assignDriver.clientID = lstRecentShipments[position].ClientID;
                        assignDriver.dispatcherID = lstRecentShipments[position].SCAC;
                        assignDriver.dispatcherToken = CommanUtil.tokenNo;
                        assignDriver.driverID = driverId;
                        #endregion
                        #region RateLinx- API integration
                        string method = APIMethods.Shipment + "/" + lstRecentShipments[position].ClientID + "|" + lstRecentShipments[position].LocID + "|" + lstRecentShipments[position].BolNum + "/" + APIMethods.driverid;
                        #endregion
                        message = await Utility.Node_AssignDriver(assignDriver);
                        if (!string.IsNullOrEmpty(message))
                        {
                            Alerts.HideBusyLoader(); //Hide Loader
                            if (dialog != null)
                            {
                                dialog.Hide();
                            }
                            Toast.MakeText(context, message, ToastLength.Long).Show();
                        }

                        assignDriver = null;
                    }
                }
                catch
                {
                    Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                    Alerts.HideBusyLoader(); //Hide Loader
                    if (dialog != null)
                    {
                        dialog.Hide();
                    }
                }
            }

            /// <summary>
            /// TrackAndUpdateLocation
            /// </summary>
            /// <param name="position"></param>
            /// <param name="btnfindCurrentlc"></param>
            private async Task TrackAndUpdateLocation(int position, string btnfindCurrentlc)
            {
                try
                {
                    if (!Utility.FnIsOnline(context))
                    {
                        Toast.MakeText(context, Constants.strNoInternet, ToastLength.Short).Show();
                        return;
                    }
                    string fromAddress = "";
                    string toAddress = "";
                    if (!string.IsNullOrEmpty(lstRecentShipments[position].OriginAddress1))
                    { fromAddress = lstRecentShipments[position].OriginAddress1 + ""; }
                    if (!string.IsNullOrEmpty(lstRecentShipments[position].OriginAddress2))
                    { fromAddress += lstRecentShipments[position].OriginAddress2 + "\n"; }
                    if (!string.IsNullOrEmpty(lstRecentShipments[position].ShipToAddress1))
                    { toAddress = lstRecentShipments[position].ShipToAddress1 + ""; }
                    if (!string.IsNullOrEmpty(lstRecentShipments[position].ShipToAddress2))
                    { toAddress += lstRecentShipments[position].ShipToAddress2 + "\n"; }
                    string locationSourceDestination =
                        lstRecentShipments[position].OriginCompany + " " +
                        fromAddress +
                        lstRecentShipments[position].OriginCity + " "
                        + lstRecentShipments[position].OriginState + " "
                        + lstRecentShipments[position].OriginZip + "#" +
                        toAddress
                        + lstRecentShipments[position].ShipToCity + " "
                        + lstRecentShipments[position].ShipToState + " "
                        + lstRecentShipments[position].ShipToZip + "#"
                        + lstRecentShipments[position].BolNum + "#"
                        + lstRecentShipments[position].LocID + "#"
                        + lstRecentShipments[position].ClientID + "#"
                        + lstRecentShipments[position].DriverID + "#"
                        + lstRecentShipments[position].ProNum + "#"
                        + lstRecentShipments[position].OriginPhone;
                    Constants.loc_SourceDest = locationSourceDestination;
                    if (lstRecentShipments[position].ViewAs.ToUpper() == Constants.strCarrier.ToUpper())
                    {
                        if (btnfindCurrentlc == Constants.updateShipmentStatus)
                        {
                            Alerts.showBusyLoader(context);
                            await Task.Delay(1000);
                            //if (lstRecentShipments[position].DispatchFlag)
                            //{


                            objUtility = new Utility();
                            string response = await objUtility.BindShipmentDetail(APIMethods.shipmentDetails + "/" + lstRecentShipments[position].ClientID + "|" + lstRecentShipments[position].BolNum, context);
                            if (!string.IsNullOrEmpty(response))
                            {
                                carrierShipmentDetails = JsonConvert.DeserializeObject<CarrierShipmentDetails>(response);
                            }

                            //List<ShipmentActivity> lstShipmentActivity = await objUtility.GetRealtimeShipmentStatus(lstRecentShipments[position].ClientID + "/" + lstRecentShipments[position].BolNum);
                            if (carrierShipmentDetails != null && carrierShipmentDetails.TrackDetails !=null)
                            {
                                Alerts.HideBusyLoader();
                                if (carrierShipmentDetails.TrackDetails[carrierShipmentDetails.TrackDetails.Count - 1].ActivityDescr.ToUpper() != Constants.strCompletedDeliveryText.ToUpper())
                                {
                                    Intent intentUpdateShipStatus = Utility.RedirectTo(context, typeof(UpdateShipmentStatusActivity), "shipmentDetails", locationSourceDestination);
                                    context.StartActivity(intentUpdateShipStatus);
                                }
                                else
                                {
                                    Toast.MakeText(context, Constants.shippingCompleted, ToastLength.Short).Show();
                                    return;
                                }
                            }

                            else
                            {
                                Alerts.HideBusyLoader();
                                Intent intentUpdateShipStatus = Utility.RedirectTo(context, typeof(UpdateShipmentStatusActivity), "shipmentDetails", locationSourceDestination);
                                context.StartActivity(intentUpdateShipStatus);
                            }
                        }
                        else
                        {
                            Intent intentRealTimeTracking = Utility.RedirectTo(context, typeof(RealTimeTrackingActivity), "location", locationSourceDestination);
                            context.StartActivity(intentRealTimeTracking);
                        }
                        // }

                    }
                    else
                    {
                        Intent intentRealTimeTracking = Utility.RedirectTo(context, typeof(RealTimeTrackingActivity), "location", locationSourceDestination);
                        context.StartActivity(intentRealTimeTracking);
                    }
                }
                catch
                {
                    Alerts.HideBusyLoader();
                    throw;
                }
            }

            /// <summary>
            /// Compare Carrier Route
            /// </summary>
            /// <param name="position">position of shipment</param>
            private void GoToComparisonRouteMap(int position)
            {
                try
                {
                    string compositeValue = lstRecentShipments[position].OriginCompany
                        + lstRecentShipments[position].OriginAddress1
                        + lstRecentShipments[position].OriginAddress2
                        + lstRecentShipments[position].OriginCity + ", "
                          + lstRecentShipments[position].OriginState + " "
                          + lstRecentShipments[position].OriginZip + "#"
                          + lstRecentShipments[position].ShipToAddress1
                          + lstRecentShipments[position].ShipToAddress2
                          + lstRecentShipments[position].ShipToCity + ", "
                            + lstRecentShipments[position].ShipToState + ", " + lstRecentShipments[position].ShipToZip + "#" + lstRecentShipments[position].BolNum;
                    Intent intentCompare = Utility.RedirectTo(context, typeof(CompareRoute), "location", compositeValue);
                    context.StartActivity(intentCompare);
                }
                catch
                {
                    Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                }
            }

            /// <summary>
            /// Shipment Confirmation  
            /// </summary>
            /// <param name="position">position of shipment</param>
            /// <param name="type">Pickup/Delivery shipment</param>
            private void GotoShipConfirmation(int position, string type)
            {
                try
                {
                    string[] arrPickupConf = new string[4];
                    if (type == Constants.strDeliveryConf)
                    {
                        arrPickupConf[0] = Constants.strDeliveryConf;
                    }
                    else
                    {
                        arrPickupConf[0] = Constants.strPickConf;
                    }
                    arrPickupConf[1] = lstRecentShipments[position].ClientID + "|" + lstRecentShipments[position].LocID + "|" + lstRecentShipments[position].BolNum;
                    arrPickupConf[2] = "1";
                    arrPickupConf[3] = lstRecentShipments[position].ProNum;
                    if (lstRecentShipments[position].DispatchFlag)
                    {
                        CommanUtil.shipmentType = Constants.dispatcher;
                    }
                    else
                    {
                        CommanUtil.shipmentType = Constants.strCustomer;
                    }
                    ConfirmationFragment confirmationFragment = new ConfirmationFragment(context, arrPickupConf, CommanUtil.shipmentType);
                    //TvHeaderTitle.Text = Constants.strHistory;
                    V4App.FragmentManager objFragmentManager = fragmentActivity.SupportFragmentManager;
                    V4App.FragmentTransaction objFragmentTrans = objFragmentManager.BeginTransaction();
                    objFragmentTrans.Replace(Resource.Id.fragment_container, confirmationFragment, "ConfirmationFragment").AddToBackStack("ConfirmationFragment");
                    objFragmentTrans.Commit();
                }
                catch (Exception ex)
                {
                    Toast.MakeText(context, ex.Message, ToastLength.Long).Show();
                }
            }

        }
    }
}