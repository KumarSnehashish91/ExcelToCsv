﻿using System;
using System.Collections.Generic;
using Android.App;
using Android.Views;
using Android.Widget;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;
using RateLinx.Droid.ServiceModels;
using System.Runtime.InteropServices;
using RateLinx.Models;

namespace RateLinx.Droid.Adapters
{
    /// <summary>
    /// History result Adapter
    /// </summary>
    [ComVisible(true)]
    public class OrderHistoryAdapter : BaseAdapter<OrderHistory>
    {

        #region Declaration of variable
        Activity context;

        /// <summary>
        /// 
        /// </summary>
        public List<OrderHistory> lstHistoryResult;
        /// <summary>
        /// 
        /// </summary>
        //public List<OrderHistoryColumns> lstOrderHistoryColumns;
        TextView  txtOrderID, txtStoreID, txtStatus, txtOrderDate, txtShipto, txtCompany;
        CheckBox chkSelectOrder;
        Utility objUtility = null;
        LinearLayout lnrLayoutHRF = null;
        #endregion

       /// <summary>
       /// 
       /// </summary>
       /// <param name="context"></param>
       /// <param name="lstOrderHistory"></param>
        public OrderHistoryAdapter(Activity context, List<OrderHistory> lstOrderHistory) : base()
        {
            this.context = context;
            this.lstHistoryResult = lstOrderHistory;
            //this.lstOrderHistoryColumns = lstOrderHistoryColumns;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public override long GetItemId(int position)
        {
            return position;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public override OrderHistory this[int position]
        {
            get
            {
                return lstHistoryResult[position];
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public override int Count
        {
            get { return lstHistoryResult.Count; }
        }

        //public override OrderHistoryResults this[int position] => throw new NotImplementedException();

        /// <summary>
        /// Get the View Controls and bind them
        /// </summary>
        /// <param name="position"></param>
        /// <param name="convertView"></param>
        /// <param name="parent"></param>
        /// <returns></returns>
        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            try
            {
                View viewHistoryResultLayout = convertView;
                View orderhistory = context.LayoutInflater.Inflate(Resource.Layout.OrderHistory, null);
                viewHistoryResultLayout = context.LayoutInflater.Inflate(Resource.Layout.OrderHistoryLayout, null);
                CheckBox selectall = orderhistory.FindViewById<CheckBox>(Resource.Id.chkSelectAll);
                lnrLayoutHRF = viewHistoryResultLayout.FindViewById<LinearLayout>(Resource.Id.lnrLayoutHRF);
                txtOrderID      = viewHistoryResultLayout.FindViewById<TextView>(Resource.Id.txtOrderID);
                txtStoreID      = viewHistoryResultLayout.FindViewById<TextView>(Resource.Id.txtStoreID);
                txtStatus       = viewHistoryResultLayout.FindViewById<TextView>(Resource.Id.txtStatus);
                txtOrderDate    = viewHistoryResultLayout.FindViewById<TextView>(Resource.Id.txtOrderDate);
                txtShipto       = viewHistoryResultLayout.FindViewById<TextView>(Resource.Id.txtShipTo);
                txtCompany      = viewHistoryResultLayout.FindViewById<TextView>(Resource.Id.txtCompany);
                chkSelectOrder = viewHistoryResultLayout.FindViewById<CheckBox>(Resource.Id.chkSelectorder);

                chkSelectOrder.Click += delegate
                 {
                     ManageOrderHistoryCheckBox(position);
                 };
                txtOrderID.Text = lstHistoryResult[position].OrderID;
                txtStoreID.Text =lstHistoryResult[position].StoreID;
                txtStatus.Text =lstHistoryResult[position].Status;
                txtOrderDate.Text =Convert.ToString( lstHistoryResult[position].OrderDate);
                txtCompany.Text =lstHistoryResult[position].ShipTo_Company;

                if (lstHistoryResult[position].isCheckBoxChecked)
                {
                    chkSelectOrder.Checked = true;
                }
                else
                {
                    chkSelectOrder.Checked = false;
                }
               
                objUtility = new Utility();
                objUtility.ChangeLayoutColor(lnrLayoutHRF, viewHistoryResultLayout, position);
                return viewHistoryResultLayout;
            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                return null;
            }
        }

        private void ManageOrderHistoryCheckBox(int position)
        {
            if (lstHistoryResult[position].isCheckBoxChecked)
            {
                lstHistoryResult[position].isCheckBoxChecked = false;
            }
            else
            {
                lstHistoryResult[position].isCheckBoxChecked = true;
            }
        }
    }


}