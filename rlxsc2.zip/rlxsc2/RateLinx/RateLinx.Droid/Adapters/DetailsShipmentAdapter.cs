﻿using System;
using System.Collections.Generic;
using Android.App;
using Android.Views;
using Android.Widget;
using RateLinx.Models;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;

namespace RateLinx.Droid.Adapters
{
    /// <summary>
    /// Adapter to hold the option shipmets properties
    /// </summary>
    public class DetailsShipment : BaseAdapter<LineDetail>
    {
        #region Declaration of variable
        /// <summary>
        /// List of the Options in Shipments
        /// </summary>
        public List<LineDetail> lstdetailsdatashipment;
        Activity context;
        CarrierShipmentDetails shipmentDtails;
        TextView txtLine, txtPieces, txtPallets, txtUOM, txtItem, txtDescription, txtDimension, txtClass, txtFAK, txtWeight, txtPUStop, txtDOStop;
        LinearLayout lnrDetailsData;
        Utility objUtility = null;
        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="detailsdatashipment"></param>
        public DetailsShipment(Activity context, CarrierShipmentDetails detailsdatashipment)
            : base()
        {
            this.context = context;
            this.lstdetailsdatashipment = detailsdatashipment.LineDetails;
            this.shipmentDtails = detailsdatashipment;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public override long GetItemId(int position)
        {
            return position;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public override LineDetail this[int position]
        {
            get
            {
                return lstdetailsdatashipment[position];
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public override int Count
        {
            get { return lstdetailsdatashipment.Count; }
        }

        /// <summary>
        /// Get the View Controls and bind them
        /// </summary>
        /// <param name="position"></param>
        /// <param name="convertView"></param>
        /// <param name="parent"></param>
        /// <returns></returns>
        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            View view = convertView;
            try
            {
                if (view == null)
                    view = context.LayoutInflater.Inflate(Resource.Layout.DetailsDataLayout, null);
                //Get the controls
                txtLine = view.FindViewById<TextView>(Resource.Id.txtLine);
                txtPieces = view.FindViewById<TextView>(Resource.Id.txtPieces);
                txtPallets = view.FindViewById<TextView>(Resource.Id.txtPallets);
                txtUOM = view.FindViewById<TextView>(Resource.Id.txtUOM);
                txtItem = view.FindViewById<TextView>(Resource.Id.txtItem);
                txtDescription = view.FindViewById<TextView>(Resource.Id.txtDescription);
                txtDimension = view.FindViewById<TextView>(Resource.Id.txtDimension);
                txtClass = view.FindViewById<TextView>(Resource.Id.txtClass);
                txtFAK = view.FindViewById<TextView>(Resource.Id.txtFAK);
                txtWeight = view.FindViewById<TextView>(Resource.Id.txtWeight);
                txtPUStop = view.FindViewById<TextView>(Resource.Id.txtPUStop);
                txtDOStop = view.FindViewById<TextView>(Resource.Id.txtDOStop);

                lnrDetailsData = view.FindViewById<LinearLayout>(Resource.Id.lnrDetailsData);
                //Assign Values from API response
                txtLine.Text = Convert.ToString(lstdetailsdatashipment[position].LineNum);
                txtPieces.Text = Convert.ToString(lstdetailsdatashipment[position].Pieces);
                txtPallets.Text = Convert.ToString(lstdetailsdatashipment[position].Pallets);
                txtUOM.Text = Convert.ToString(lstdetailsdatashipment[position].UOM);
                txtItem.Text = Convert.ToString(lstdetailsdatashipment[position].Item);
                txtDescription.Text = Convert.ToString(lstdetailsdatashipment[position].Descr);
                txtDimension.Text = Convert.ToString(Math.Round(lstdetailsdatashipment[position].Length, 2) + " x " + Math.Round(lstdetailsdatashipment[position].Width, 2) + " x " + Math.Round(lstdetailsdatashipment[position].Height, 2));
                txtClass.Text = Convert.ToString(lstdetailsdatashipment[position].Class);
                txtFAK.Text = Convert.ToString(lstdetailsdatashipment[position].FAK);
                txtWeight.Text = Math.Round(Convert.ToDecimal(lstdetailsdatashipment[position].Weight), 2).ToString();
                txtPUStop.Text = Convert.ToString(lstdetailsdatashipment[position].PUStop);
                txtDOStop.Text = Convert.ToString(lstdetailsdatashipment[position].DOStop);

                if (lstdetailsdatashipment != null)
                {
                    if (shipmentDtails.Mode == Constants.strTRUCKLOAD)
                    {
                        txtClass.Visibility = ViewStates.Visible;
                    }
                    else
                    {
                        txtClass.Visibility = ViewStates.Gone;
                    }
                    if (shipmentDtails.IsMultiStop)
                    {
                        txtPUStop.Visibility = ViewStates.Visible;
                        txtDOStop.Visibility = ViewStates.Visible;
                    }
                    else
                    {
                        txtPUStop.Visibility = ViewStates.Gone;
                        txtDOStop.Visibility = ViewStates.Gone;
                    }
                }
                //For Changing Layout Color Dynamically
                objUtility = new Utility();
                objUtility.ChangeLayoutColor(lnrDetailsData, view, position);
                return view;
            }
            catch (Exception ex)
            {
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                return null;
            }
        }
    }

}