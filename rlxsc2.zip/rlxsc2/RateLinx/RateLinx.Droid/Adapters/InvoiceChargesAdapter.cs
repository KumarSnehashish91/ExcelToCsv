using System;
using System.Collections.Generic;
using Android.App;
using Android.Views;
using Android.Widget;
using RateLinx.Droid.Utilities;
using RateLinx.Models;
using System.Runtime.InteropServices;
using RateLinx.Helper;

namespace RateLinx.Droid.Adapters
{
    /// <summary>
    ///  Meta Tag of the class
    /// </summary>
    [ComVisible(false)]
    public class InvoiceChargesAdapter
    {
        /// <summary>
        /// Adapter to hold the option shipmets properties
        /// </summary>
        [ComVisible(true)]
        public class InvoiceChargesList : BaseAdapter<Charges>
        {
            #region Declaration of variable
            /// <summary>
            /// List of the Options in Shipments
            /// </summary>
            public List<Charges> lstInvoiceCharges;
            Utility objUtility = null;
            ListView lstInvoice;
            Activity context;
            ImageView imgCros;
            TextView  txtViewCharge, txtViewAmount;
            LinearLayout lnrInvoiceCharges;
            #endregion

            /// <summary>
            /// 
            /// </summary>
            /// <param name="lstInvoice"></param>
            /// <param name="context"></param>
            /// <param name="lstInvoiceCharges"></param>
            public InvoiceChargesList(Activity context, List<Charges> lstInvoiceCharges,ListView lstInvoice)
                : base()
            {
                this.context = context;
                this.lstInvoiceCharges = lstInvoiceCharges;
                this.lstInvoice = lstInvoice;
            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="position"></param>
            /// <returns></returns>
            public override long GetItemId(int position)
            {
                return position;
            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="position"></param>
            /// <returns></returns>
            public override Charges this[int position]
            {
                get
                {
                    return lstInvoiceCharges[position];
                }
            }

            /// <summary>
            /// 
            /// </summary>
            public override int Count
            {
                get { return lstInvoiceCharges.Count; }
            }

            /// <summary>
            /// Get the View Controls and bind them
            /// </summary>
            /// <param name="position"></param>
            /// <param name="convertView"></param>
            /// <param name="parent"></param>
            /// <returns></returns>
            public override View GetView(int position, View convertView, ViewGroup parent)
            {
                View view = convertView;
                try
                {
                    //if (view == null)
                        view = context.LayoutInflater.Inflate(Resource.Layout.InvoiceCharges, null);
                    //Get the controls
                    imgCros = view.FindViewById<ImageView>(Resource.Id.imgCros);
                    //string buttonId = "btnCross" + Convert.ToString(position);
                    //imgCros.SetTag(position, buttonId);
                    imgCros.Id = position;
                    txtViewCharge = view.FindViewById<TextView>(Resource.Id.txtViewCharge);
                    txtViewAmount = view.FindViewById<TextView>(Resource.Id.txtViewAmount);
                    lnrInvoiceCharges = view.FindViewById<LinearLayout>(Resource.Id.lnrInvoiceCharges);
                    lnrInvoiceCharges.Id = 1000 + position;
                    //Changing Layout Color 
                    imgCros.Click += delegate
                     {
                         RemoveCharges(position);
                     };
                    txtViewCharge.Text = lstInvoiceCharges[position].ID;
                    txtViewAmount.Text = lstInvoiceCharges[position].Value;
                    objUtility = new Utility();
                    objUtility.ChangeLayoutColor(lnrInvoiceCharges, view, position);
                    return view;
                }
                catch(Exception ex)
                {
                    Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                    Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                    return null;
                }
            }

            /// <summary>
            /// Remove Charges from charge list
            /// </summary>
            /// <param name="position"></param>
            private void RemoveCharges(int position)
            {
                try
                {
                    lstInvoiceCharges.RemoveAt(position);
                    InvoiceChargesList invoiceChargesAdapter = new InvoiceChargesAdapter.InvoiceChargesList(context, lstInvoiceCharges, lstInvoice);
                    lstInvoice.Adapter = invoiceChargesAdapter;
                }
                catch
                {
                    throw;
                }
            }


        }
    }
}