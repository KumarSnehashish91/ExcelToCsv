using System;
using System.Collections.Generic;
using Android.App;
using Android.Views;
using Android.Widget;
using RateLinx.Droid.Utilities;
using RateLinx.Helper;
using RateLinx.Droid.ServiceModels;
using System.Runtime.InteropServices;

namespace RateLinx.Droid.Adapters
{

    /// <summary>
    /// History result Adapter
    /// </summary>
    [ComVisible(true)]
    public class HistoryResultAdapter : BaseAdapter<RateHistoryResult>
    {
        #region Declaration of variable
        Activity context;
        /// <summary>
        /// 
        /// </summary>
        public List<RateHistoryResult> lstHistoryResult;
        /// <summary>
        /// 
        /// </summary>
        public List<RateHistoryColumns> lstRateHistoryColumns;
        TextView txtClientID, txtLocID, txtMode, txtRateType, txtLoadNo, txtAuctionStatus, txtRateStatus,
            txtDateOpened, txtRateDeadLine, txtShipFrom, txtShipTo, txtPickUp, txtReference, txtUserCreated;
        Utility objUtility = null;
        LinearLayout lnrLayoutHRF = null;
        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="lstHistoryResult"></param>
        /// <param name="lstRateHistoryColumns"></param>
        public HistoryResultAdapter(Activity context, List<RateHistoryResult> lstHistoryResult, List<RateHistoryColumns> lstRateHistoryColumns) : base()
        {
            this.context = context;
            this.lstHistoryResult = lstHistoryResult;
            this.lstRateHistoryColumns = lstRateHistoryColumns;
        }


      /// <summary>
      /// 
      /// </summary>
      /// <param name="position"></param>
      /// <returns></returns>
        public override long GetItemId(int position)
        {
            return position;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public override RateHistoryResult this[int position]
        {
            get
            {
                return lstHistoryResult[position];
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public override int Count
        {
            get { return lstHistoryResult.Count; }
        }
        /// <summary>
        /// Get the View Controls and bind them
        /// </summary>
        /// <param name="position"></param>
        /// <param name="convertView"></param>
        /// <param name="parent"></param>
        /// <returns></returns>
        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            try
            {
                View viewHistoryResultLayout = convertView;
                viewHistoryResultLayout = context.LayoutInflater.Inflate(Resource.Layout.HistoryResultFragment, null);
                lnrLayoutHRF = viewHistoryResultLayout.FindViewById<LinearLayout>(Resource.Id.lnrLayoutHRF);
                RateHistoryResult objHistoryResult = lstHistoryResult[0];
                txtClientID = viewHistoryResultLayout.FindViewById<TextView>(Resource.Id.txtClientID);
                txtLocID = viewHistoryResultLayout.FindViewById<TextView>(Resource.Id.txtLocID);
                txtMode = viewHistoryResultLayout.FindViewById<TextView>(Resource.Id.txtMode);
                txtRateType = viewHistoryResultLayout.FindViewById<TextView>(Resource.Id.txtRateType);
                txtLoadNo = viewHistoryResultLayout.FindViewById<TextView>(Resource.Id.txtLoadNo);
                txtAuctionStatus = viewHistoryResultLayout.FindViewById<TextView>(Resource.Id.txtAuctionStatus);
                txtRateStatus = viewHistoryResultLayout.FindViewById<TextView>(Resource.Id.txtRateStatus);
                txtDateOpened = viewHistoryResultLayout.FindViewById<TextView>(Resource.Id.txtDateOpened);
                txtRateDeadLine = viewHistoryResultLayout.FindViewById<TextView>(Resource.Id.txtRateDeadLine);
                txtShipFrom = viewHistoryResultLayout.FindViewById<TextView>(Resource.Id.txtShipFrom);
                txtShipTo = viewHistoryResultLayout.FindViewById<TextView>(Resource.Id.txtShipTo);
                txtPickUp = viewHistoryResultLayout.FindViewById<TextView>(Resource.Id.txtPickUp);
                txtReference = viewHistoryResultLayout.FindViewById<TextView>(Resource.Id.txtReference);
                txtUserCreated = viewHistoryResultLayout.FindViewById<TextView>(Resource.Id.txtUserCreated);
                //Assign Values in Controls
                txtClientID.Text = lstHistoryResult[position].ClientID;
                txtLocID.Text = Convert.ToString(lstHistoryResult[position].LocID);
                txtMode.Text = lstHistoryResult[position].Mode;
                txtRateType.Text = lstHistoryResult[position].RateType;
                txtLoadNo.Text = lstHistoryResult[position].LoadNum;
                txtAuctionStatus.Text = lstHistoryResult[position].AuctionStatus;
                
                txtDateOpened.Text = lstHistoryResult[position].DateOpened;
                txtRateDeadLine.Text = lstHistoryResult[position].RateDeadline;
                txtShipFrom.Text = lstHistoryResult[position].ShipFrom;
                txtShipTo.Text = lstHistoryResult[position].ShipTo;
                txtPickUp.Text = lstHistoryResult[position].Pickup;
                txtReference.Text = lstHistoryResult[position].Reference;
                txtUserCreated.Text = lstHistoryResult[position].UserCreated;
                if (CommanUtil.ViewAs.ToUpper() == Constants.strCustomer.ToUpper())
                {
                    txtRateStatus.Text = "";
                    txtRateStatus.Visibility = ViewStates.Gone;
                }
                else
                {
                    txtRateStatus.Text = lstHistoryResult[position].RateStatus;
                }
                objUtility = new Utility();
                objUtility.ChangeLayoutColor(lnrLayoutHRF, viewHistoryResultLayout, position);
                return viewHistoryResultLayout;
            }
            catch(Exception ex)
            {
                Utility.ErrorLog(Constants.shipmentDetail, ex.Message, CommanUtil.tokenNo, context);
                Toast.MakeText(context, Constants.strErrorOccured, ToastLength.Long).Show();
                return null;
            }
        }
    }

  
}