﻿using System.Collections.Generic;

namespace RateLinx.GoogleServices
{
    /// <summary>
    /// 
    /// </summary>
	public class GeocodedWaypoint
	{
        /// <summary>
        /// 
        /// </summary>
		public string geocoder_status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string place_id { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<string> types { get; set; }
	}

    /// <summary>
    /// 
    /// </summary>
	public class Southwest
	{
        /// <summary>
        /// 
        /// </summary>
		public double lat { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double lng { get; set; }
	}
    /// <summary>
    /// 
    /// </summary>
	public class Bounds
	{
        /// <summary>
        /// 
        /// </summary>
		public Northeast northeast { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Southwest southwest { get; set; }
	}
    /// <summary>
    /// 
    /// </summary>
	public class Distance
	{
        /// <summary>
        /// 
        /// </summary>
		public string text { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int value { get; set; }
	}
    /// <summary>
    /// 
    /// </summary>
	public class Duration
	{
        /// <summary>
        /// 
        /// </summary>
		public string text { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int value { get; set; }
	}
    /// <summary>
    /// 
    /// </summary>
	public class EndLocation
	{
        /// <summary>
        /// 
        /// </summary>
		public double lat { get; set; }
        /// <summary>
        /// 
        /// </summary>
		public double lng { get; set; }
	}
    /// <summary>
    /// 
    /// </summary>
	public class StartLocation
	{
        /// <summary>
        /// 
        /// </summary>
		public double lat { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double lng { get; set; }
	}
    /// <summary>
    /// 
    /// </summary>
	public class Distance2
	{
        /// <summary>
        /// 
        /// </summary>
		public string text { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int value { get; set; }
	}
    /// <summary>
    /// 
    /// </summary>
	public class Duration2
	{
        /// <summary>
        /// 
        /// </summary>
		public string text { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int value { get; set; }
	}
    /// <summary>
    /// 
    /// </summary>
	public class EndLocation2
	{
        /// <summary>
        /// 
        /// </summary>
		public double lat { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double lng { get; set; }
	}
    /// <summary>
    /// 
    /// </summary>
	public class Polyline
	{
        /// <summary>
        /// 
        /// </summary>
		public string points { get; set; }
	}
    /// <summary>
    /// 
    /// </summary>
	public class StartLocation2
	{
        /// <summary>
        /// 
        /// </summary>
		public double lat { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double lng { get; set; }
	}
    /// <summary>
    /// 
    /// </summary>
	public class Step
	{
        /// <summary>
        /// 
        /// </summary>
		public Distance2 distance { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Duration2 duration { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public EndLocation2 end_location { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string html_instructions { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Polyline polyline { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public StartLocation2 start_location { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string travel_mode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string maneuver { get; set; }
	}
    /// <summary>
    /// 
    /// </summary>
	public class Leg
	{
        /// <summary>
        /// 
        /// </summary>
		public Distance distance { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Duration duration { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string end_address { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public EndLocation end_location { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string start_address { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public StartLocation start_location { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<Step> steps { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<object> via_waypoint { get; set; }
	}
    /// <summary>
    /// 
    /// </summary>
	public class OverviewPolyline
	{
        /// <summary>
        /// 
        /// </summary>
		public string points { get; set; }
	}

    /// <summary>
    /// 
    /// </summary>
	public class Route
	{
        /// <summary>
        /// 
        /// </summary>
		public Bounds bounds { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string copyrights { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<Leg> legs { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public OverviewPolyline overview_polyline { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string summary { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<object> warnings { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<object> waypoint_order { get; set; }
	}
    /// <summary>
    /// 
    /// </summary>
	public class GoogleDirectionClass
	{
        /// <summary>
        /// 
        /// </summary>
		public List<GeocodedWaypoint> geocoded_waypoints { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<Route> routes { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string status { get; set; }
	}
}

