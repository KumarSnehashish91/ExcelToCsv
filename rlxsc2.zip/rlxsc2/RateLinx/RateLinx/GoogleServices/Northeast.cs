﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RateLinx.GoogleServices
{
    /// <summary>
    /// 
    /// </summary>
    public class Northeast
    {
        /// <summary>
        /// 
        /// </summary>
        public double lat { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double lng { get; set; }
    }
}
