﻿using System;
using System.Collections.Generic;

namespace RateLinx.GoogleServices
{
    /// <summary>
    /// 
    /// </summary>
	public class AddressComponent
	{
        /// <summary>
        /// 
        /// </summary>
		public string long_name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string short_name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<string> types { get; set; }
	}
    /// <summary>
    /// 
    /// </summary>
    public class Location
	{
        /// <summary>
        /// 
        /// </summary>
		public double lat { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double lng { get; set; }
	}

    /// <summary>
    /// 
    /// </summary>
	public class Northeast2
	{
        /// <summary>
        /// 
        /// </summary>
        public double lat { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double lng { get; set; }
	}
    /// <summary>
    /// 
    /// </summary>
	public class Southwest2
	{
        /// <summary>
        /// 
        /// </summary>
		public double lat { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double lng { get; set; }
	}
    /// <summary>
    /// 
    /// </summary>
	public class Viewport
	{
        /// <summary>
        /// 
        /// </summary>
		public Northeast2 northeast { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Southwest2 southwest { get; set; }
	}
    /// <summary>
    /// 
    /// </summary>
	public class Geometry
	{
        /// <summary>
        /// 
        /// </summary>
		public Bounds bounds { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Location location { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string location_type { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Viewport viewport { get; set; }
	}
    /// <summary>
    /// 
    /// </summary>
	public class Result
	{
        /// <summary>
        /// 
        /// </summary>
		public List<AddressComponent> address_components { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string formatted_address { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Geometry geometry { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string place_id { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<string> types { get; set; }
	}
    /// <summary>
    /// 
    /// </summary>
	public class GeoCodeJSONClass
	{
        /// <summary>
        /// 
        /// </summary>
		public List<Result> results { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string status { get; set; }
	}
}

