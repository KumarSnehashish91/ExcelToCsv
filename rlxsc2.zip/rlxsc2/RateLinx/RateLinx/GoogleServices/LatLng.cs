﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RateLinx.GoogleServices
{
    /// <summary>
    /// 
    /// </summary>
    public class CurrentLatLng
    {
        /// <summary>
        /// 
        /// </summary>
        public double Latitude { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double Longitude { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="lat"></param>
        /// <param name="lng"></param>
        public CurrentLatLng(double lat, double lng)
        {
            this.Latitude = lat;
            this.Longitude = lng;
        }
    }
}
