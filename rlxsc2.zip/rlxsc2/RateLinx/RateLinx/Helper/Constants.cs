﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RateLinx.Helper
{
    /// <summary>
    /// 
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// 
        /// </summary>
        public static string notificationMsg = string.Empty;
        /// <summary>
        /// 
        /// </summary>
        public static string Client_Id = string.Empty;
        /// <summary>
        /// 
        /// </summary>
        public static string BolNO = string.Empty;
        /// <summary>
        /// 
        /// </summary>
        public static string datetime = string.Empty;
        /// <summary>
        /// 
        /// </summary>
        public static string message = string.Empty;
        /// <summary>
        /// 
        /// </summary>
        public static string title = string.Empty;
        /// <summary>
        /// 
        /// </summary>
        public static string url = string.Empty;
        /// <summary>
        /// 
        /// </summary>
        public static string uploadType = string.Empty;
        internal const string appName = "RateLinx";
        internal static string redirectionMessage = "There is a new version available! Please upgrade now to ensure full functionality.";
        //internal static string strGoogleServerKey = "AIzaSyBddzG5beZJf1cECREGkC7QbCTyS5PaAqA";//AIzaSyAWtq8a0rbojFDwbd0DDEH75TYJDGCekLk
        internal static string strGoogleServerKey = "AIzaSyAWtq8a0rbojFDwbd0DDEH75TYJDGCekLk";
        /*internal static string SenderID = "558962108478";   */   // old sender id
        internal static string SenderID = "812927631355";     // sender id send by Mark
        internal static string strGoogleServerDirKey = "AIzaSyAWtq8a0rbojFDwbd0DDEH75TYJDGCekLk";
        internal static string strMessageReceiver = "com.gcm.MessageReceiver";
        internal static string strGoogleDirectionUrl = "https://maps.googleapis.com/maps/api/directions/json?origin={0}&destination={1}&key=" + strGoogleServerDirKey + "";
        internal static string strGeoCodingUrl = "https://maps.googleapis.com/maps/api/geocode/json?{0}&key=" + strGoogleServerKey + "";
        //Pub Nub Details"sub-c-224b39ec-8548-11e8-b9aa-969f058f0c4c";//"pub-c-45962b28-288d-4967-b50c-5c798ec8d851";//
        internal const string pubnubSubscribeKey = "sub-c-224b39ec-8548-11e8-b9aa-969f058f0c4c";//"sub-c-8c959766-0330-11e7-ae7c-02ee2ddab7fe";
        internal const string pubnubPublishKey = "pub-c-45962b28-288d-4967-b50c-5c798ec8d851";//"pub-c-578d4b1e-9002-4cce-821e-8d0d8b6ae200";
        //Social Icons
        internal const string strNewsURI = "https://www.ratelinx.com/news-events/";
        internal const string strAboutRateLinx = "http://www.ratelinx.com/about";
        internal const string strRatLinxNews = "http://www.ratelinx.com/feed/";
        internal const string strGplusURI = "https://plus.google.com/+Ratelinx/posts";
        internal const string strLinkInURI = "https://www.linkedin.com/company/ratelinx";
        internal const string strYoutubeURI = "https://www.youtube.com/c/ratelinx";
        internal const string strTwitterURI = "https://twitter.com/RateLinx";
        internal const string strFacebookURI = "https://www.facebook.com/RateLinx";
        internal const string strPlayStoreURI = "https://play.google.com/store/apps/details?id=com.ratelinx.app";
        internal const string strEnterOrderID = "Please enter Order ID";
        internal const string strStatusUpdated = "Shipment updated successfully";
        internal static string strException = "Error :";
        internal const string trackExc = "Exception";
        internal const string trackOther = "Other";
        internal static string strTimeOut = "Operation time out, Please try again";
        internal static string strNetwork = "Please check your VPN network first";
        internal static string strSuccess = "Success";  //
        internal static string strSucceed = "Succeed";
        internal static string strTextSource = "Source";
        internal const string PickupEquipNum = "PickupEquipNum";
        internal const string DropoffEquipNum = "DropoffEquipNum";
        internal const string OtherEquipNums = "OtherEquipNums";
        internal const string strLogOut = "logOut";
        internal static string strTextDestination = "Destination";
        internal const string statusUpdate = "Update successful";
        internal const string attributes = "Attribute(s) - ";
        internal static string deviceToken = "";
        internal static string shipStartTime = string.Empty;
        internal static bool isEnroute = false;
        //Dialog 
        internal static string btnTextOk = "OK";
        internal static string btnUpgrade = "Upgrade";
        internal static string btnTextCancel = "Cancel";
        internal static string btnTextYes = "Yes";
        internal static string btnTextNo = "No";
        internal static string strDialogHdr = "Confirm";
        internal const string compositeKey = "compositeKey";
        internal static string btnTextTakePicture = "Take Picture";
        internal static string btnTextUploadImage = "Upload Image";

        internal const string strTruckBrokeDown = "Truck Broke Down";
        internal const string strTrafficDelay = "Traffic Delay";
        internal const string strWeatherDelay = "Weather Delay";
        internal const string strDockClosed = "Dock Closed";
        internal static string driverAssignedSucessfully = "Shipment sent to driver successully";
        internal static string awardedSucessfully = "Shipment has been awarded successully";
        internal static string methodNmaeForEquipmentScanning = string.Empty;
        internal static int focusedFragment = 0;
        /// <summary>
        /// 
        /// </summary>
        public static string activeShipmentsList = string.Empty;
        /// <summary>
        /// 
        /// </summary>
        public static string awardedShipmentsList = string.Empty;
        /// <summary>
        /// 
        /// </summary>
        public static string recentShipmentsList = string.Empty;
        //
        internal static string strCustomer = "CUSTOMER";
        internal static string strCarrier = "CARRIER";
        internal static string strClosed = "CLOSED";
        internal static string strTrackAll = "TRACKALL";
        //Home Activity Fragments
        internal const string strHomeTitle = "Home";
        internal static string strActive = "Active Shipments";
        internal static string strAwarded = "Awarded Shipments";
        internal static string strRecent = "Recent Shipments";
        internal const string strHomeAct = "HomeActivity";
        //Home Activity
        internal static string strEquipment = "Equipment Scanning";
        internal static string strPickup = "Pickup Confirmation";
        internal static string strHistory = "Rate History Result";
        internal static string strRateHistory = "Rate History";
        internal static string strOrderHistory = "Order History";
        internal const string strRateHistoryPage = "RateHistory";
        internal static string strHelpFeedback = "Help and Feedback";
        internal const string strHelpAndFeedbackPage = "HelpAndFeedback";
        internal static string strActiveShipment = "activeShipments";
        internal static string strAwardedShipment = "awardedShipments";
        internal static string strRecentShipment = "recentShipments";
        internal static string strWarning = "Warning";
        internal static string strTestBol = " TEST ";
        internal static string strNoBids = "You have no current bids!";
        internal static string strNoBidYet = "There are no bids yet.";
        internal static string strCurrentBid = "Your current bid : $";

        //Invoice
        internal static string strSelectFile = "Select File";
        internal static string strNoFile = "No file selected";
        internal static string strEnterReason = "Please enter reason";
        internal static string strEnterAmount = "Please enter amount";
        internal static string strRecreateInvoice = "Recreate Invoice";
        internal static string strCreateInvoice = "Create Invoice ";
        internal static string strCreatedOn = "Invoice was created on ";
        internal static string strSubmitInvoice = "Are you sure you want to submit this invoice for $";
        internal static string strWithoutCharges = "  without any further changes?";
        //
        internal static string strNoInternet = "Please check your internet connection!";
        internal static string strPleaseWait = "Please wait...";
        internal static string strUnableToConnect = "Unable to connect server!,Please try after sometime";
        //Validation Message on Login Page
        internal static string strClientID = "Please enter the Client ID.";
        internal static string strClientIDLength = "Please enter the Client ID with valid Length.\n Length is too high.";
        internal static string strUserId = "Please enter  the User ID.";
        internal static string strUserIdLength = "Please enter the User ID with valid Length.\n Length is too high.";
        internal static string strPassword = "Please enter the Password.";
        internal static string strCredentials = "Please enter credential details";
        internal const string userCredential = "UserCredentials";
        //Live Tracking 
        internal static string strTracking = "Please select atleast one tracking option.";
        internal static string strLiveTrack = "LIVE TRACKING";
        internal static string strStopTrack = "Stop Live Tracking";
        internal static string strSameTacking = "Same as Live Tracking";
        internal static string btnTextCurrentLc = "Find Current Location";
        internal static string btnTextCompare = "Compare Carrier Route";
        internal static string strDefaultState = "UNITED STATES";
        internal static string strdelivery = "Delivery";
        internal static string strPickConf = "Pickup Confirmation";
        internal static string strDeliveryConf = "Delivery Confirmation";
        internal const string strpickup = "Pickup";
        internal static string stopCount = string.Empty;
        internal static string stopCountForConfirmtion = string.Empty;
        internal static string strStopTracking = "Are you sure you want to stop tracking for this shipment?";
        internal static string strStopAllTracking = "Are you sure you want to stop tracking for all the shipment?";
        //Shipment Detail Fragments
        internal static string strRateDetail = "Shipment Details";
        internal static string strSupporting = "Supporting";
        internal const string strFileLength = "Selected file bigger than expected, please select smaller file.";
        internal static string strNewRate = "Place New Rate";
        internal static string strRate = "Rate Entries";
        internal static string strConversation = "Conversation";
        //Validation In Compose Message 
        internal static string strBroadCastMsg = "Please select the carrier(s) to broadcast message.";
        internal static string strSubject = "Please enter the subject.";
        internal static string strMessage = "Please enter the message";
        internal static string strNoSelected = "0 Selected";
        internal static string strSendFeedBackEmail = "issuetracker@ratelinx.com";
        internal static string strEmailNotSupp = "E-Mail not supported";
        internal static string cameraPermission = "Camera Permission not granted";
        internal static string internalStoragePermission = "Read/Write external storage permission not granted";
        //Print Bol
        internal static string strPrintBol = "Print Bol Error";
        internal static string strPrintError = "Some error occurred while printing Bol!";
        //Push Notification
        internal static string strDeviceReady = "Device is not ready,Please try again!";
        //For Getting Location
        internal static string LOCATION_UPDATED = "LOCATION_UPDATED";
        internal static string _source = "Brookfield, WI 53005";
        internal static string locationNotFound = "Unable to determine your location.";
        internal static double distBtwSrcCurrent = 5;
        internal static string zeroMiles = "0 miles";
        internal static string zeroMinutes = "0 Minutes";
        internal const string strComplete = "COMPLETED";
        internal const string shippingCompleted = "Shipment has been completed!";
        internal const string shippingCompletedWithException = "Shipment has been completed with Exception!";
        //Shipments
        internal static string RecentShipments = "No Recent Shipment!";
        internal static string ActiveShipments = "No Active Shipment!";
        internal static string AwardedShipments = "No Awarded Shipment!";
        internal static string NoMsgFound = "No message found";
        internal static string ConversationHeader = "Conversations (Times shown are in Pacific Time)";
        internal const string strAndroid = "Android";

        //internal static string RateCommentHeader = "Rate Entries - Comment";
        internal static string RateCommentHeader = "Entered Comment";
        internal static string ConfShiplbl = "Enter PRO Number:";
        internal static string ConfirmShipment = "Enter the PRO Number associated with this shipment.";
        internal static string AcceptShipment = "Are you sure want to accept this shipment?";

        internal static string ErrorAlert = "Error !";
        internal static string DenyShipment = "Enter a reason you have denied this shipment.";
        internal static string DenyShipmentText = "Are you sure you want to deny the shipment?";

        internal static string DenyShiplbl = "Enter a reason:";
        internal static string Warning = "Warning";
        internal static int TrackingDelay = 300000;
        internal static int RealTimeAPIDelay = 6000;
        internal static bool isFirstLoad = true;
        internal static bool isEnrouteToDelivery = false;
        internal static bool isShipmentCompleted = false;
        internal static bool showSourceMarker = true;
        internal static int stopIncrement = 0;
        internal static bool showDestinationMarker = false;

        internal const string dateFormatMMDDYYYY = "MM/dd/yyyy";
        internal const string dateFormatMMDDYYYYHHMMSS = "MM/dd/yyyy HH:mm:ss";
        internal const string dateFormatDDMMYYYYHHMMSS = "dd/MM/yyyy HH:mm:ss";
        //Not in iOS
        internal const string strComposeMessage = "ComposeMessage";
        internal const string strLive = "Live";
        internal const string strErrorMessage = "Message";
        internal const string invoiceUploads = "InvoiceUploads";
        internal const string strTrackingDes = "Please enter tracking description.";
        internal const string strTrackingError = "Some error occurred while posting tracking info!";
        internal const string strSelectDescription = "Please select description.";
        internal const string strDescriptionDefaultText = "Select";

        internal const string strPickedUpText = "Picked Up";
        internal const string strEnRouteText = "En Route";
        internal const string strExceptionText = "Exception";
        internal const string strCompletedDeliveryText = "Completed Delivery";
        internal const string strCompletedDeliveryText2 = "Completed Unloading at Delivery Location";
        internal const string strOtherText = "Other";

        internal const string strCanAward = "Can Award";
        internal const string strPending = "Pending";
        internal const string strConfirmShip = "Confirm Shipment";
        internal const string strEnterProNo = "Please enter Pro Number.";
        internal const string strDeny = "Deny";
        internal const string strDenyShip = "Deny Shipment";
        internal const string strReason = "Reason is required.";
        internal const string strErrorOccured = "Some error occurred, Please try again.";
        internal const string strServerError = "Some error occurred while contacting server!";
        internal const string strPickupDropOffEquipNoReq = "Pickup or Dropoff equipment numbers are required.";

        internal const string cameraAccessDenied = "Camera access is not allowed, Please provide permission from setting.";
        internal const string strBID = "BID";
        internal const string strEnableTracking = "GPS is disabled, please enable to continue";

        internal const string strYouAre = "You are ";
        internal const string strAwayFromPickup = " away from pickup location. Do you want to update the status?";
        //internal const string strAwayFromDrop = " away from drop location. Do you want to update the status?";
        internal const string strAwayFromDrop = " away from the destination location. Do you want to complete the shipment?";
        internal const string strAwayFromStop= " away from {0} location. Do you want to update the status?";

        internal const string filterBy = "Myself";
        internal const string strkeepScanning = "keep Scanning";
        internal const string strDoneBtn = "Done";
        internal const string strOtherScan = "Other Equipment Scanning";
        internal const string strYouscanned = "You have scanned: ";
        internal const string strWouldScan = ". Would you like to keep scanning other equipment?";
        internal const string strReplyError = "Error Occurred while reply!";
        internal const string strHistoryResult = "Result(s) retrieved.";
        internal const string strConfirmation = "Confirmation";
        internal const string strConfirm = "Confirm";
        internal const string strUploadImage = "Upload Image";

        internal const string strRESULT_CANCELED = "Cancelled by User";
        internal const string strAcknowledge = "You must acknowledge the options !";
        internal const string strBaseCharge = "Base Charge required !";
        internal const string strFuelCharge = "Fuel Charge required !";
        internal const string strComments = "Comments required !";
        internal const string strCONFIRMED = "CONFIRMED";
        internal const string strREQUEST = " REQUEST";
        internal const string strPick = "Pick on: ";
        internal const string strORIGIN = "ORIGIN";
        internal const string strSHIPTO = "SHIPTO";
        internal const string strDetail = " Detail(s) Test";
        internal const string strDetailHead = " Detail(s)";
        internal const string strlbs = " lbs ";
        internal const string strPallets = " Pallets ";
        internal const string strPieces = " Pieces";
        internal const string strTRUCKLOAD = "TRUCKLOAD";
        internal const string strDriver = "--Select Driver--";
        internal const string strBolNo = "BolNo";
        internal const string strSelectDriver = "Please select a driver";
        internal const string driverNotAvail = "Drivers not found";
        internal const string strSaveDriver = "API-saveDriver: ";
        internal const string strBlock = "API-block: ";
        internal const string strVoid = "API-void: ";
        internal const string strALL = "ALL";
        internal const string strReqConfirm = "Requires Confirmation";
        internal const string strReqResponse = "Requires a Response";
        internal const string strReqRate = "Requires Rate or Verification";
        internal const string strOpenAc = "Open Auctions";
        internal const string strAwardAc = "Awarded Auctions";
        internal const string strConShip = "Confirmed Shipments";
        internal const string strScanConf = "Scan Confirmation!";
        internal const string strYouScan = "You have scanned : ";
        internal const string strWouldLike = ", would you like to search for this shipment?";
        internal const string enterDate = "Please enter to date.";
        internal const string fromDate = "From date must be lower than To date.";
        internal const string toDate = "To date must not be greater than current date.";
        internal const string shipmentDetail = "API-ShipmentDetail";
        internal const string strErrorFile = "Error while selecting file";
        internal const string fileError = "File path not found, please select from other location.";
        internal const string fileNotSupported = "File type is not supported, please choose another file.";
        internal const string ErrorMsg = "ErrorMsg";
        internal const string strVoidMsg = "Voided";
        internal const string strBlockMsg = "Blocked";
        //----------------- After 17102017
        internal const string strLocation = "Current location not available";
        internal const string notNearPickupLocation = "You are far away from the pickup location.";
        internal const string notNearDestLocation = "You are far away from the destination.";
        internal const string strOptimalRout = "Optimal Route Distance ";
        internal const string strCarrierRoute = "Carrier Route Distance ";
        internal const string mile = " miles";
        internal const string assignDriver = "Assign Driver";
        internal const string updateShipmentStatus = "Update Shipment Status";
        internal const string trackShipment = "Track Shipment";
        internal static string currentShipStatus = string.Empty;
        //------------Node API Credentials
        internal const string clientID = "JhbGciOiJIUzI1NiIsInR5cCI6IkpXV9";
        internal const string clientSecret = "Ub2tlbiI6ImMwYWM5NmMyLTJkMmItNDZ";
        internal const int grantType = 2;
        //-------------User permissions-----------
        internal const string dispatcher = "DISPATCHER";
        internal const string dispatcherDriver = "DISPATCHDRIVER";
        internal const string shippingNotStart = "Shipping not started";
        internal const string versionCHeck = "You are using an older version. Please upgrade your application to get the latest features!";
        //------------Status Change Message-----------
       
        internal const string loadingkey = "L1";
        internal static string loc_SourceDest = string.Empty;
        
        internal const string exceptionkey = "EX";
        internal const string otherkey = "OT";
        internal const string nonDIspatchPickedupKey = "AF";
        internal const string nonDIspatchEnRoutekey = "X6";

        internal const string exceptionkey1 = "EX1";
        internal const string exceptionkey2 = "EX2";
        internal const string exceptionkey3 = "EX3";
        internal const string exceptionkey4 = "EX4";
        internal const string exceptionkey5 = "EX5";
        internal const string strDefaultText = "SELECT";

        internal const string inTransitkey = "IT";
        internal const string arrivedAtPickupKey = "X3";
        internal const string pickedupKey = "AF";
        internal const string enRoutekey = "X6";
        internal const string arrivedkey = "X1";
        internal const string completedkey = "D1";

        internal const string strIntransit = "In Transit";
        internal const string enrouteToPickup = "Enroute to Pickup Location";
        internal const string arrivedAtPickup = "Arrived at Pickup";
        internal const string completedPickup = "Completed Pickup";
        internal const string enrouteToDelivery = "Enroute to Delivery Location";
        internal const string enrouteToDeliveryLocation = "En Route to Delivery Location";
        internal const string strCarrierDeparted = "Carrier Departed Pick-up Location with Shipment";
        internal const string arrivedAtDelivery = "Arrived at Delivery Location";
        internal const string strShipmentEnrouteText = "Shipment Enroute";
        internal const string arrivedATPickupLocation = "Arrived at Pickup Location";
        internal const string strNotDelivered = "Not Delivered";
        internal const string strEnrouteToDestination = "Enroute to Destination";
        internal const string strArrivedAtDestination = "Arrived at Destination";
        internal const string completedDeliveryOfDestination = "Completed Delivery of Destination";

        internal const string strAssignDriver = "Driver is not assigned for this shipment";

        internal const string loginActivity = "RateLinx.Droid.Activities.LoginActivity";
        //internal const string reLogin = "Re-Login";
        //internal const string reLoginText= "Logged in session has been expired please login again!";
        internal const string reLoginText = "Your have been idle for more than 1 hour. Do You want to stay logged in?";
        internal const string strOK = "OK";


        internal const string enterCity = "Please enter city.";
        internal const string updateStatusConfimation = "Do you really want to update the shipment status from ''{0}'' to ''{1}''?";
        internal const string updateStatusCompleted = "Do you want to complete the shipment?";
        internal const string enterSubject = "Please enter subject.";
        internal const string enterMessage = "Please enter message.";
        internal const string trackDetails = "Shipment {0} Details";

        internal const string phone = "Phone: {0}";
        internal const string email = "Email: {0}";
        internal const string fax = "Fax: {0}";
        internal const string specialCharacterMessage = "Special Character is not Allowed";
        internal const string specialCharacters = @"([<>\?\*\@\#\$\%\^\&\()\-\\\""/\'\:\;\!\+\`\~\=\|])+";
        //internal const string specialCharacters = @"/^[A - Za - z0 - 9]/";
        internal const string enterSignature = "Please Enter Signature.";
        internal const string signatureRequired = "Signature required before submitting.";
        internal const string enterSignatureOrImage = "Please Enter Signature or Picture.";
        internal const string signatureSaved = "Signature saved Sucessfully";
        internal const string equipmentSaved = "Scanned equipment saved Sucessfully";
        internal const string shipmentDetails = "shipmentDetails";
        internal const string strSelectOrder = "Please select order(s)";
        internal const string strWantToAcceptOrder = "Are you sure want to accept {0} Order(s)";
        internal const string strWantToDenyOrder = "Are you sure want to deny {0} Order(s)";
        internal const string strLargeFile = "File size is too large!";
        internal const string strExceptionCode = "EX";
        internal const string strSelectReason = "Please select reason";

        internal const string str5 = "5";
        internal const string str15 = "15";
        internal const string str30 = "30";
        internal const string str60 = "60";
        internal const string str180 = "180";

        internal const string str5Text = "5 minutes";
        internal const string str15Text = "15 minutes";
        internal const string str30Text = "30 minutes";
        internal const string str60Text = "1 hour";
        internal const string str180Text = "3 hours";
        internal const string daysLeft = " days left";
        internal const string timerMsg = "Past deadline";
        /// <summary>
        /// 
        /// </summary>
        public static int int1 = 1;
        /// <summary>
        /// 
        /// </summary>
        public static int int0 = 0;
        /// <summary>
        /// 
        /// </summary>
        public static int int6 = 6;
        /// <summary>
        /// 
        /// </summary>
        public static int int3 = 3;
        /// <summary>
        /// 
        /// </summary>
        public static int int20 = 20;
        /// <summary>
        /// 
        /// </summary>
        public static int int90 = 90;
        /// <summary>
        /// 
        /// </summary>
        public static int int180 = 180;
        /// <summary>
        /// 
        /// </summary>
        public static int int270 = 270;

        // FCM server details
        /// <summary>
        /// 
        /// </summary>
        public static string webAddr = "https://fcm.googleapis.com/fcm/send";
        /// <summary>
        /// 
        /// </summary>
        public static string serverKey = "AAAAvUZDP_s:APA91bG3C3MUbIirAkvEBX2Vasp3-xwuE5ZKQ18uo2t_xgXGfnX0kgMGeuefSVb62kp-CBD3y-bLjZjjRqFXnkSlTBRXGMJXJK-vyzL-wFaUfrt9VqVaEO8WZ_-vcE3_WmG0Xex1aQ3A";
        /// <summary>
        /// 
        /// </summary>
        public static string FCMToken = string.Empty;


    }
}
