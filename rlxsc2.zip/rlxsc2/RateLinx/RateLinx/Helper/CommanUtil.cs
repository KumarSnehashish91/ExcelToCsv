using System;
using System.Collections.Generic;
using RateLinx.Models;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Threading;
using System.Linq;

namespace RateLinx.Helper
{
    /// <summary>
    /// Meta Tag for Comman Utility
    /// </summary>
    public class CommanUtil
    {
        string stopCountForConfirmtion = string.Empty;
        List<TrackingDesc> lstTrackingExceptionVal;
        /// <summary>
        /// 
        /// </summary>
        public string ShipmentActivity = string.Empty;
        string statusCode = string.Empty;
        Dictionary<string, string> trackingStatus = null;
        /// <summary>
        /// Check the Tracking of driver is enabled or not
        /// </summary>
        public static bool isTrackingEnable = false;
        /// <summary>
        /// Current Latitude
        /// </summary>
        public static double currLat = 0.00;
        /// <summary>
        /// Current Longitude
        /// </summary>
        public static double currLong = 0.00;
        ///// <summary>
        ///// 
        ///// </summary>
        // public static string driverList = string.Empty;

        /// <summary>
        /// 
        /// </summary>
        public static List<string> UserPermissions { get; set; }
        /// <summary>
        /// If accuracy fine then pulish current lat and long
        /// </summary>
        public static bool isAccuracyFine = true;

        /// <summary>
        /// Stores the user type
        /// </summary>
        /// 
        public static string ViewAs = string.Empty;

        /// <summary>
        /// Stores type of shipment
        /// </summary>
        public static string shipmentType = string.Empty;

        ///// <summary>
        ///// Stop pooling data
        ///// </summary>
        //public static bool stopPooling = false;
        /// <summary>
        /// Token generates from API after login
        /// </summary>
        public static string tokenNo = string.Empty;
        /// <summary>
        /// fixed from account API
        /// </summary>
        public static bool isShowCharges = true;
        /// <summary>
        /// Push Notification Allowed True 
        /// </summary>
        public static bool isPushAllowed { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public static bool isTrackingOn = false;
        /// <summary>
        /// 
        /// </summary>
        public static bool stopTracking = false;
        /// <summary>
        /// To check if tracking interval is enabled or not
        /// </summary>
        public static bool isTrackingInterval = false;
        /// <summary>
        /// Login user id
        /// </summary>
        public static string userID = string.Empty;
        /// <summary>
        /// 
        /// </summary>
        public static string AMPM = string.Empty;
        /// <summary>
        /// 
        /// </summary>
        public static bool visibilitybtnUnAward = false;
        /// <summary>
        /// 
        /// </summary>
        public static bool visibilitybtnReSubmit = false;
        /// <summary>
        /// 
        /// </summary>
        public static string shipClientIdBolNo = string.Empty;
        /// <summary>
        /// 
        /// </summary>
        public static bool isReply = false;
        /// <summary>
        /// When doing refresh on detail page
        /// </summary>
        public static bool refresh = true;
        /// <summary>
        /// 
        /// </summary>
        public static bool isChecked = false;

        /// <summary>
        /// Method For Getting current year in Page Footer
        /// </summary>
        /// <returns></returns>
        public static string PrintYear()
        {
            int currentYear = DateTime.UtcNow.Year;
            string footerHeading = " � " + currentYear + " RateLinx";
            return footerHeading;
        }
        /// <summary>
        /// Function to retrun Tracking Description List
        /// </summary>
        public static List<TrackingDesc> TrackingDescList()
        {
            List<TrackingDesc> lstTrackingDesc = new List<TrackingDesc>();

            lstTrackingDesc.Add(new TrackingDesc { value = Constants.strDefaultText, text = Constants.strDescriptionDefaultText });
            lstTrackingDesc.Add(new TrackingDesc { value = Constants.pickedupKey, text = Constants.strPickedUpText });
            lstTrackingDesc.Add(new TrackingDesc { value = Constants.enRoutekey, text = Constants.strEnRouteText });
            lstTrackingDesc.Add(new TrackingDesc { value = Constants.exceptionkey, text = Constants.strExceptionText });
            lstTrackingDesc.Add(new TrackingDesc { value = Constants.completedkey, text = Constants.strCompletedDeliveryText });
            lstTrackingDesc.Add(new TrackingDesc { value = Constants.otherkey, text = Constants.strOtherText });
            return lstTrackingDesc;
        }
        /// <summary>
        /// 
        /// </summary>
        public static List<string> ExceptionTextList = new List<string>() { Constants.strTruckBrokeDown, Constants.strTrafficDelay, Constants.strWeatherDelay, Constants.strDockClosed, Constants.strOtherText };

        /// <summary>
        /// Function to retrun Tracking Value from Description
        /// </summary>
        public static List<TrackingDesc> TrackingValue()
        {
            List<TrackingDesc> lstTrackingDesc = new List<TrackingDesc>();

            lstTrackingDesc.Add(new TrackingDesc { value = Constants.inTransitkey, text = Constants.enrouteToPickup });
            lstTrackingDesc.Add(new TrackingDesc { value = Constants.arrivedAtPickupKey, text = Constants.arrivedAtPickup });
            lstTrackingDesc.Add(new TrackingDesc { value = Constants.pickedupKey, text = Constants.completedPickup });
            lstTrackingDesc.Add(new TrackingDesc { value = Constants.enRoutekey, text = Constants.enrouteToDelivery });
            lstTrackingDesc.Add(new TrackingDesc { value = Constants.arrivedkey, text = Constants.arrivedAtDelivery });
            lstTrackingDesc.Add(new TrackingDesc { value = Constants.completedkey, text = Constants.strCompletedDeliveryText });

            return lstTrackingDesc;
        }
        /// <summary>
        /// Function to retrun Tracking Description List
        /// </summary>
        public static List<TrackingDesc> ExceptionDescList()
        {
            List<TrackingDesc> lstTrackingDesc = new List<TrackingDesc>();

            lstTrackingDesc.Add(new TrackingDesc { value = Constants.strDefaultText, text = Constants.strDescriptionDefaultText });
            lstTrackingDesc.Add(new TrackingDesc { value = Constants.exceptionkey1, text = Constants.strTruckBrokeDown });
            lstTrackingDesc.Add(new TrackingDesc { value = Constants.exceptionkey2, text = Constants.strTrafficDelay });
            lstTrackingDesc.Add(new TrackingDesc { value = Constants.exceptionkey3, text = Constants.strWeatherDelay });
            lstTrackingDesc.Add(new TrackingDesc { value = Constants.exceptionkey4, text = Constants.strDockClosed });
            lstTrackingDesc.Add(new TrackingDesc { value = Constants.exceptionkey5, text = Constants.strOtherText });
            return lstTrackingDesc;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ActivityDate"></param>
        /// <returns></returns>
        public static string[] FormatDate(string ActivityDate)
        {
            string[] activityDate = new string[2];
            if (ActivityDate.Contains("/"))
            {
                activityDate = ActivityDate.Split('/');
            }
            else
            {
                activityDate = ActivityDate.Split('-');
            }
            return activityDate;
        }
        /// <summary>
        /// Count Down Timer
        /// </summary>
        /// <param name="DeadLineStr"></param>
        /// <returns></returns>
        public string CountDown(string DeadLineStr)
        {
            try
            {
                string timerMessage = string.Empty;
                if (!string.IsNullOrEmpty(tokenNo))
                {
                    //Remove slashes from date time string
                    string[] bidDeadLine = DeadLineStr.Split('/');
                    string[] year = bidDeadLine[2].Split(' '); //Remove space between year and time
                    string[] time = year[1].Split(':');  //split hours and time
                    DateTime bidDateTime = new DateTime(Convert.ToInt32(year[0]), Convert.ToInt32(bidDeadLine[0]), Convert.ToInt32(bidDeadLine[1]), Convert.ToInt32(time[0]), Convert.ToInt32(time[1]), Convert.ToInt32(time[2]));
                    DateTime currentTime = DateTime.Now;
                    decimal span = Convert.ToDecimal(bidDateTime.Subtract(currentTime).TotalMilliseconds);
                    double diffInMili = (double)span;
                    int diffDays = (int)Math.Floor(span / (1000 * 3600 * 24));
                    int hours = (int)Math.Floor(span / 3600000); // 1 Hour = 36000 Milliseconds
                    int minutes = (int)Math.Floor((span % 3600000) / 60000); // 1 Minutes = 60000 Milliseconds
                    int seconds = (int)Math.Floor(((span % 360000) % 60000) / 1000);// 1 Second = 1000 Milliseconds

                    RemainingTime objRemainingTime = new RemainingTime { Days = diffDays, Hours = hours, Minutes = minutes, Seconds = seconds };
                    var clock = hours + ":" + minutes + ":" + seconds;

                    if (bidDateTime > currentTime)
                    {
                        if (objRemainingTime.Hours > 48)
                        {
                            timerMessage = objRemainingTime.Days + Constants.daysLeft;
                        }
                        else if (objRemainingTime.Hours == 0 && objRemainingTime.Minutes == 0 && objRemainingTime.Seconds == 0)
                        {
                            timerMessage = Constants.timerMsg;
                        }
                        else
                        {
                            timerMessage = clock + "  left";
                        }
                    }
                    else
                    {
                        timerMessage = Constants.timerMsg;
                    }
                }
                return timerMessage;
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
                return null;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="clientId"></param>
        /// <param name="locId"></param>
        /// <param name="bolNo"></param>
        /// <returns></returns>
        public static string CompositeKey(string clientId, int locId, string bolNo)
        {
            return clientId + "|" + locId + "|" + bolNo;
        }
        /// <summary>
        /// Function to return live tracking elements
        /// </summary>
        /// <returns></returns>
        public static Dictionary<string, string> GetLiveTrackingElements()
        {
            Dictionary<string, string> liveTrackingElements = new Dictionary<string, string>();
            liveTrackingElements.Add(Constants.str5, Constants.str5Text);
            liveTrackingElements.Add(Constants.str15, Constants.str15Text);
            liveTrackingElements.Add(Constants.str30, Constants.str30Text);
            liveTrackingElements.Add(Constants.str60, Constants.str60Text);

            return liveTrackingElements;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static Dictionary<string, string> TrackingStatus()
        {
            Dictionary<string, string> trackingStatus = new Dictionary<string, string>();
            trackingStatus.Add(Constants.inTransitkey, Constants.enrouteToPickup);
            trackingStatus.Add(Constants.arrivedAtPickupKey, Constants.arrivedAtPickup);
            trackingStatus.Add(Constants.pickedupKey, Constants.completedPickup);
            //trackingStatus.Add(Constants.pickedupKey, Constants.arrivedAtPickup);
            trackingStatus.Add(Constants.enRoutekey, Constants.enrouteToDelivery);
            trackingStatus.Add(Constants.arrivedkey, Constants.arrivedAtDelivery);
            trackingStatus.Add(Constants.completedkey, Constants.strCompletedDeliveryText);
            trackingStatus.Add(Constants.exceptionkey1, Constants.strTruckBrokeDown);
            trackingStatus.Add(Constants.exceptionkey2, Constants.strTrafficDelay);
            trackingStatus.Add(Constants.exceptionkey3, Constants.strWeatherDelay);
            trackingStatus.Add(Constants.exceptionkey4, Constants.strDockClosed);
            trackingStatus.Add(Constants.exceptionkey5, Constants.strOtherText);




            //trackingStatus.Add(Constants.exceptionkey, "Exception");
            return trackingStatus;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static Dictionary<string, string> GetTrackingUpdatesElements()
        {
            Dictionary<string, string> trackingUpdatesElements = new Dictionary<string, string>();
            trackingUpdatesElements.Add(Constants.str15, Constants.str15Text);
            trackingUpdatesElements.Add(Constants.str60, Constants.str60Text);
            trackingUpdatesElements.Add(Constants.str180, Constants.str180Text);
            return trackingUpdatesElements;
        }
        /// <summary>
        /// 
        /// </summary>
        public static string AutoTracking = Constants.strSameTacking;
        /// <summary>
        /// 
        /// </summary>
        public static string currentAddress = string.Empty;
        /// <summary>
        /// 
        /// </summary>
        public static bool isTrackingClicked = false;
        /// <summary>
        /// 
        /// </summary>
        public static bool isStopAllTracking = false;
        /// <summary>
        /// 
        /// </summary>
        public static List<ActiveShipments> lstRecyclerActiveShipments;

        /// <summary>
        /// 
        /// </summary>
        public static DateTime loginTime = DateTime.Now;
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static bool IsTimeOut()
        {
            try
            {
                DateTime currentTime = DateTime.Now;
                TimeSpan timespan = currentTime - loginTime;
                if (timespan.TotalMinutes <= 60)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="isspecialcharacter"></param>
        /// <returns></returns>
        public static bool IsSpecialCharacter(string isspecialcharacter)
        {
            try
            {
                string specialCharacter = Constants.specialCharacters;

                Regex rg = new Regex(specialCharacter);
                bool b = rg.IsMatch(isspecialcharacter);
                if (b)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }

        }
        private static volatile Thread blinker;
        /// <summary>
        /// 
        /// </summary>
        public static void stopThread()
        {
            try
            {
                Thread thread = Thread.CurrentThread;
                blinker = thread;
                Thread tmpBlinker = blinker;
                blinker = null;
                if (tmpBlinker != null)
                {
                    //tmpBlinker.Interrupt();
                    //tmpBlinker.Join();

                    //GC.Collect(GC.MaxGeneration);
                    GCCollectionMode gCCollectionMode = GCCollectionMode.Forced;
                    GC.Collect(GC.MaxGeneration, gCCollectionMode, false);
                }
            }
            catch 
            {

            }

        }

        /// <summary>
        /// Method to bind Multiple stops
        /// </summary>
        public string multiStopTracking(CarrierShipmentDetails carrierShipmentDetail)
        {

            try
            {
                trackingStatus = TrackingStatus();
                int stopCount = 1;

                if (carrierShipmentDetail.TrackDetails != null && carrierShipmentDetail.TrackDetails.Count > 0)
                {
                    string shipmentCurrentText = carrierShipmentDetail.TrackDetails[carrierShipmentDetail.TrackDetails.Count - 1].ActivityDescr;
                    lstTrackingExceptionVal = CommanUtil.ExceptionDescList();
                    statusCode = lstTrackingExceptionVal.Where(x => x.text == shipmentCurrentText).Select(x => x.value).FirstOrDefault();
                    if (shipmentCurrentText == Constants.strCompletedDeliveryText || shipmentCurrentText == "Completed Unloading at Delivery Location")
                    {
                        Constants.isEnroute = false;
                        ShipmentActivity = "Shipment Completed";
                        stopCount = carrierShipmentDetail.Addresses.Count;
                    }
                    else if (shipmentCurrentText == "Pickup")
                    {
                        statusCode = trackingStatus.Where(x => x.Value == carrierShipmentDetail.TrackDetails[carrierShipmentDetail.TrackDetails.Count - 2].ActivityDescr).Select(x => x.Key).FirstOrDefault();
                        ShipmentActivity = statusCode;
                    }
                    else
                    {
                        foreach (var stop in carrierShipmentDetail.Addresses)
                        {
                            if (Convert.ToString(carrierShipmentDetail.Addresses[stopCount].CurrentStatus) != "Delivered")
                            {
                                if (carrierShipmentDetail.TrackDetails[carrierShipmentDetail.TrackDetails.Count - 1].ActivityDescr == "In Transit")
                                {
                                    statusCode = "IT";
                                }
                                if (carrierShipmentDetail.TrackDetails[carrierShipmentDetail.TrackDetails.Count - 1].ActivityDescr == "En Route to Delivery Location")
                                {
                                    statusCode = Constants.enRoutekey;
                                }
                                if (carrierShipmentDetail.TrackDetails[carrierShipmentDetail.TrackDetails.Count - 1].ActivityDescr == "Carrier Departed Pick-up Location with Shipment")
                                {
                                    statusCode = "AF";
                                }
                                else
                                {
                                    if (statusCode == string.Empty || statusCode == null)
                                    {
                                        statusCode = trackingStatus.Where(x => x.Value == carrierShipmentDetail.TrackDetails[carrierShipmentDetail.TrackDetails.Count - 1].ActivityDescr).Select(x => x.Key).FirstOrDefault();
                                    }
                                }
                                if (statusCode == Constants.arrivedkey)
                                {
                                    if (carrierShipmentDetail.Addresses[stopCount].Type == "BILLTO")
                                    {
                                        ShipmentActivity = Constants.completedkey;
                                    }
                                    else
                                    {
                                        ShipmentActivity = "enrouteToNextStop";
                                    }
                                }
                                else
                                {
                                    ShipmentActivity = statusCode;
                                    if (statusCode == null)
                                    {
                                        ShipmentActivity = string.Empty;
                                    }
                                }
                                break;
                            }
                            else
                            {
                                stopCount += 1;
                            }
                        }
                    }
                }
                switch (ShipmentActivity)
                {
                    case Constants.enRoutekey:
                        if (stopCount - 1 >= 1)
                        {
                            stopCountForConfirmtion = "STOP" + (stopCount - 1);
                        }
                        break;
                    case "enrouteToNextStop":
                        if (stopCount - 1 >= 1)
                        {
                            stopCountForConfirmtion = "STOP" + (stopCount - 1);
                        }
                        break;
                    case Constants.arrivedkey:
                        stopCountForConfirmtion = "STOP" + stopCount;
                        break;
                    case Constants.completedkey:
                        stopCountForConfirmtion = "STOP" + (stopCount - 1);
                        break;
                    case "Shipment Completed":
                        stopCountForConfirmtion = "STOP" + (stopCount - 1);
                        break;
                }
                return stopCountForConfirmtion;
            }
            catch
            {
                throw;
            }
        }

    }

}