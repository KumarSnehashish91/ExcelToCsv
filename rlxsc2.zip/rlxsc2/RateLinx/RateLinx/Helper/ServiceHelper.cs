﻿using System;
using System.Net;
using System.Text;
using StreamReference = System.IO.Stream;
using System.IO;
using System.Threading.Tasks;
using RateLinx.APIs;

namespace RateLinx.Helper
{
    /// <summary>
    /// Meta tag for APi service
    /// </summary>
    public class ServiceHelper
    {

        /// <summary>
        /// Post request function
        /// </summary>
        /// <param name="strSerializedData">String serialized data.</param>
        /// <param name="strMethod">String method. Name</param>
        /// <param name="token">String token if required for header value</param>
        /// <param name="isHeader">If set to <c>true</c> then header.</param>
        /// <returns>The request.</returns>
        public async Task<string> PostRequest(string strSerializedData, string strMethod, string token, bool isHeader)
        {
            try
            {
                //Read data from StreamReader
                string strText = string.Empty;
                //for post request with body content
                HttpWebRequest request = CreateWebRequest(strMethod, token, isHeader, "POST");
                request.ContentType = "application/x-www-form-urlencoded";  // Set the ContentType property of the WebRequest.
                //Server Certificate
                ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
                // Create POST data and convert it to a byte array.
                ASCIIEncoding encoding = new ASCIIEncoding();
                Byte[] bytes = encoding.GetBytes(strSerializedData);
                // Set the ContentLength property of the WebRequest.
                request.ContentLength = bytes.Length;
                // Get the request stream.
                using (StreamReference webStream = request.GetRequestStream())
                {
                    // Write the data to the request stream.
                    webStream.Write(bytes, 0, bytes.Length);
                    // Close the Stream object.
                    webStream.Close();
                    webStream.Dispose();
                }
                // Get the original response.
                using (WebResponse response = await request.GetResponseAsync())
                {
                    // Get the stream containing all content returned by the requested server.
                    StreamReference data = response.GetResponseStream();
                    // Open the stream using a StreamReader for easy access.
                    var reader = new StreamReader(data);
                    // Read the content fully up to the end.
                    strText = reader.ReadToEnd();
                    // Clean up the streams.
                    data.Dispose();
                    reader.Dispose();
                }
                return strText;
            }
           

            catch (AggregateException e)
            {
                var baseEx = e.GetBaseException() as WebException;
                WebResponse response = baseEx.Response;
                string text;
                if (baseEx.Status == WebExceptionStatus.Timeout)
                {
                    // Handle timeout exception
                    text = "{error:\"nullResponse\"," + Constants.strErrorMessage + ":\"" + Constants.strTimeOut + ".\"}";
                    return text;
                }
                else if (response == null)
                {
                    text = "{error:\"nullResponse\"," + Constants.strErrorMessage + ":\"" + Constants.strTimeOut + ".\"}";
                    return text;
                }
                else
                {
                    HttpWebResponse httpResponse = (HttpWebResponse)response;
                    StreamReference data = response.GetResponseStream();
                    var reader = new StreamReader(data);
                    text = reader.ReadToEnd();
                    return text;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="strSerializedData"></param>
        /// <param name="strMethod"></param>
        /// <param name="token"></param>
        /// <param name="isHeader"></param>
        /// <returns></returns>
        public async Task<string> PostRequestJson(string strSerializedData, string strMethod, string token, bool isHeader)
        {
            try
            {
                string strText = "";
                //for post request with body content
                HttpWebRequest request = CreateWebRequest(strMethod, token, isHeader, "POST");
                request.ContentType = "application/json";  
                // Create POST data and convert it to a byte array.
                ASCIIEncoding encoding = new ASCIIEncoding();
                Byte[] bytes = encoding.GetBytes(strSerializedData);
                // Set the ContentLength property of the WebRequest.
                request.ContentLength = bytes.Length;
                // Get the request stream.
                using (StreamReference webStream = request.GetRequestStream())
                {
                    // Write the data to the request stream.
                    webStream.Write(bytes, 0, bytes.Length);
                    // Close the Stream object.
                    webStream.Close();
                    webStream.Dispose();
                }
                // Get the original response.
                using (WebResponse response = await request.GetResponseAsync())
                {
                    // HttpWebResponse httpResponse = (HttpWebResponse)response;
                    // Get the stream containing all content returned by the requested server.
                    StreamReference data = response.GetResponseStream();
                    // Open the stream using a StreamReader for easy access.
                    var reader = new StreamReader(data);
                    // Read the content fully up to the end.
                    strText = reader.ReadToEnd();
                    // Clean up the streams.
                    data.Dispose();
                    reader.Dispose();
                }
                return strText;
            }
            catch (Exception e)
            {
                var baseEx = e.GetBaseException() as WebException;
                WebResponse response = baseEx.Response;
                string text;
                if (baseEx.Status == WebExceptionStatus.Timeout)
                {
                    // Handle timeout exception
                    text = "{error:\"nullResponse\","+Constants.strErrorMessage+":\"" + Constants.strTimeOut + ".\"}";
                    return text;
                }
                else if (response == null)
                {
                    text = "{error:\"nullResponse\","+ Constants.strErrorMessage + ":\"" + Constants.strTimeOut + ".\"}";
                    return text;
                }
                else
                {
                    //HttpWebResponse httpResponse = (HttpWebResponse)response;
                    StreamReference data = response.GetResponseStream();

                    StreamReader reader = new StreamReader(data);
                    text = reader.ReadToEnd();
                    return text;
                }
            }
        }

        /// <summary>
        /// GET request method.
        /// </summary>
        /// <returns>The request.</returns>
        /// <param name="strSerializedData">String serialized data.</param>
        /// <param name="strMethod">String method.</param>
        /// <param name="isHeader">bool isHeader If set to <c>true</c> then header</param>
        public async Task<string> GetRequest(string strSerializedData, string strMethod, bool isHeader)
        {
            string strText = string.Empty;
            HttpWebRequest request = CreateWebRequest(strMethod, strSerializedData, isHeader, "GET");
            request.ContentType = "application/json";
            try
            {              
                using (WebResponse response = await request.GetResponseAsync())
                {
                    // HttpWebResponse httpResponse = (HttpWebResponse)response;
                    StreamReference data = response.GetResponseStream();
                    var reader = new StreamReader(data);
                    strText = reader.ReadToEnd();
                    response.Close();
                }
                request.Abort();
                return strText;
            }
            catch (AggregateException e)
            {
                var baseEx = e.GetBaseException() as WebException;
                WebResponse response = baseEx.Response;
                string text;
                if (baseEx.Status == WebExceptionStatus.Timeout)
                {
                    // Handle timeout exception
                    text = "{error:\"nullResponse\","+ Constants.strErrorMessage + ":\"" + Constants.strTimeOut + ".\"}";
                    return text;
                }
                else if (response == null)
                {
                    text = "{error:\"nullResponse\","+ Constants.strErrorMessage + ":\"" + Constants.strTimeOut + ".\"}";
                    return text;
                }
                else
                {
                    //HttpWebResponse httpResponse = (HttpWebResponse)response;
                    StreamReference data = response.GetResponseStream();

                    var reader = new StreamReader(data);
                    text = reader.ReadToEnd();
                    return text;
                }
            }
            catch
            {
                request.Abort();
                return string.Empty;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="strMethod"></param>
        /// <param name="token"></param>
        /// <param name="isHeader"></param>
        /// <param name="requestType"></param>
        /// <returns></returns>
        private HttpWebRequest CreateWebRequest(string strMethod, string token, bool isHeader, string requestType)
        {
            try
            {
                string serviceUri = string.Empty;
                serviceUri = APIBaseUri.baseUri + strMethod;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(serviceUri);
                request.KeepAlive = false;
                request.ProtocolVersion = HttpVersion.Version10;
                request.Method = requestType;
                request.Timeout = 60000;
                if (isHeader)
                {
                    //Set the ContentType property of the WebRequest.
                    request.Headers.Add("Authorization", "bearer " + token);
                }
                return request;
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="strSerializedData"></param>
        /// <param name="strMethod"></param>
        /// <param name="token"></param>
        /// <param name="isHeader"></param>
        /// <returns></returns>
        public async Task<string> Node_PostRequestJson(string strSerializedData, string strMethod, string token, bool isHeader)
        {
            try
            {
                string strText = "";
                //for post request with body content
                HttpWebRequest request = Node_CreateWebRequest(strMethod, token, isHeader, "POST");
                request.ContentType = "application/json";
                // Create POST data and convert it to a byte array.
                ASCIIEncoding encoding = new ASCIIEncoding();
                Byte[] bytes = encoding.GetBytes(strSerializedData);
                // Set the ContentLength property of the WebRequest.
                request.ContentLength = bytes.Length;
                // Get the request stream.
                using (StreamReference webStream = request.GetRequestStream())
                {
                    // Write the data to the request stream.
                    webStream.Write(bytes, 0, bytes.Length);
                    // Close the Stream object.
                    webStream.Close();
                    webStream.Dispose();
                }
                // Get the original response.
                using (WebResponse response = await request.GetResponseAsync())
                {
                    HttpWebResponse httpResponse = (HttpWebResponse)response;
                    //// Get the stream containing all content returned by the requested server.
                    StreamReference data = response.GetResponseStream();
                    // Open the stream using a StreamReader for easy access.
                    var reader = new StreamReader(data);

                    if (APIMethods.node_Auth == strMethod)
                    {
                        // Read the content fully up to the end.
                        strText = reader.ReadToEnd();
                    }
                    else
                    {
                        strText = httpResponse.StatusDescription;
                    }
                    // Clean up the streams.
                    data.Dispose();
                    reader.Dispose();
                    httpResponse.Dispose();
                }
                return strText;
            }
            catch (Exception e)
            {
                throw;
            }
        }

        internal Task PostRequestJson(string payLoad, string methodURI, object token, bool v)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="strSerializedData"></param>
        /// <param name="strMethod"></param>
        /// <param name="token"></param>
        /// <param name="isHeader"></param>
        /// <returns></returns>
        public async Task<string> Node_PostRequest_Json(string strSerializedData, string strMethod, string token, bool isHeader)
        {
            try
            {
                string strText = "";
                //for post request with body content
                HttpWebRequest request = Node_CreateWebRequest(strMethod, token, isHeader, "POST");
                request.ContentType = "application/json";
                // Create POST data and convert it to a byte array.
                ASCIIEncoding encoding = new ASCIIEncoding();
                Byte[] bytes = encoding.GetBytes(strSerializedData);
                // Set the ContentLength property of the WebRequest.
                request.ContentLength = bytes.Length;
                // Get the request stream.
                using (StreamReference webStream = request.GetRequestStream())
                {
                    // Write the data to the request stream.
                    webStream.Write(bytes, 0, bytes.Length);
                    // Close the Stream object.
                    webStream.Close();
                    webStream.Dispose();
                }
                // Get the original response.
                using (WebResponse response = await request.GetResponseAsync())
                {
                    // HttpWebResponse httpResponse = (HttpWebResponse)response;
                    // Get the stream containing all content returned by the requested server.
                    StreamReference data = response.GetResponseStream();
                    // Open the stream using a StreamReader for easy access.
                    var reader = new StreamReader(data);
                    // Read the content fully up to the end.
                    strText = reader.ReadToEnd();
                    // Clean up the streams.
                    data.Dispose();
                    reader.Dispose();
                }
                return strText;
            }
            catch (AggregateException e)
            {
                var baseEx = e.GetBaseException() as WebException;
                WebResponse response = baseEx.Response;
                string text;
                if (baseEx.Status == WebExceptionStatus.Timeout)
                {
                    // Handle timeout exception
                    text = "{error:\"nullResponse\"," + Constants.strErrorMessage + ":\"" + Constants.strTimeOut + ".\"}";
                    return text;
                }
                else if (response == null)
                {
                    text = "{error:\"nullResponse\"," + Constants.strErrorMessage + ":\"" + Constants.strTimeOut + ".\"}";
                    return text;
                }
                else
                {
                    //HttpWebResponse httpResponse = (HttpWebResponse)response;
                    StreamReference data = response.GetResponseStream();

                    StreamReader reader = new StreamReader(data);
                    text = reader.ReadToEnd();
                    return text;
                }
            }
        }


        /// <summary>
        /// GET request method.
        /// </summary>
        /// <returns>The request.</returns>
        /// <param name="token">String serialized data.</param>
        /// <param name="strMethod">String method.</param>
        /// <param name="isHeader">bool isHeader If set to <c>true</c> then header</param>
        public async Task<string> Node_GetRequest(string token, string strMethod, bool isHeader)
        {
            try
            {
                string strText = string.Empty;
                HttpWebRequest request = Node_CreateWebRequest(strMethod, token, isHeader, "GET");
                request.ContentType = "application/json";
                using (WebResponse response = await request.GetResponseAsync())
                {
                    // HttpWebResponse httpResponse = (HttpWebResponse)response;
                    StreamReference data = response.GetResponseStream();
                    var reader = new StreamReader(data);
                    strText = reader.ReadToEnd();
                }
                return strText;
            }
            catch (AggregateException e)
            {
                var baseEx = e.GetBaseException() as WebException;
                WebResponse response = baseEx.Response;
                string text;
                if (baseEx.Status == WebExceptionStatus.Timeout)
                {
                    // Handle timeout exception
                    text = "{error:\"nullResponse\"," + Constants.strErrorMessage + ":\"" + Constants.strTimeOut + ".\"}";
                    return text;
                }
                else if (response == null)
                {
                    text = "{error:\"nullResponse\"," + Constants.strErrorMessage + ":\"" + Constants.strTimeOut + ".\"}";
                    return text;
                }
                else
                {
                    //HttpWebResponse httpResponse = (HttpWebResponse)response;
                    StreamReference data = response.GetResponseStream();

                    var reader = new StreamReader(data);
                    text = reader.ReadToEnd();
                    return text;
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="strMethod"></param>
        /// <param name="token"></param>
        /// <param name="isHeader"></param>
        /// <param name="requestType"></param>
        /// <returns></returns>
        private HttpWebRequest Node_CreateWebRequest(string strMethod, string token, bool isHeader, string requestType)
        {
            try
            {
                string serviceUri = string.Empty;
                serviceUri = APIBaseUri.node_BaseUri + strMethod;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(serviceUri);
                request.KeepAlive = false;
                if (strMethod== APIMethods.node_UpdateShipmentStatus)
                {
                    requestType = "PUT";
                }
                request.Method = requestType;
                request.Timeout = 15000;
                if (isHeader)
                {
                    //Set the ContentType property of the WebRequest.
                    request.Headers.Add("authorization", "bearer " + token);
                }
                return request;
            }
            catch
            {
                Console.Write(Constants.strErrorOccured);
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<string> GetDriverList()
        {
            try
            {
                // create json object that holds the api values
                //Method Name
                string methodName = "shipmentrequests/drivers";
                //Get the Shipments
                string strResponse = await GetRequest(CommanUtil.tokenNo, methodName, true);
                return strResponse;
            }
            catch (AggregateException e)
            {
                return "";
                throw e;                
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}
