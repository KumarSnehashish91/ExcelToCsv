namespace RateLinx.Models
{
    /// <summary>
    /// 
    /// 
    /// </summary>
    public class AwardedShipments
    {
        /// <summary>
        /// 
        /// </summary>
        public string AwardedSCAC { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string AwardedPrice { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string ClientID { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string BolNum { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string LocID { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string Mode { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public bool IsTest { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string BidType { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string PickupStr { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string ViewAs { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string Status { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string DriverID { set; get; }
        /// <summary>
        /// Origin Address 1
        /// </summary>
        public string OriginAddress1 { get; set; }
        /// <summary>
        /// Origin Address 2
        /// </summary>
        public string OriginAddress2 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string OriginCity { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string OriginState { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string OriginZip { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipToAddress1 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipToAddress2 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipToCity { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipToState { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipToZip { get; set; }
       
    }
}