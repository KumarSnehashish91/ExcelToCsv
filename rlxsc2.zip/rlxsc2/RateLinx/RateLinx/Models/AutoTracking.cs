﻿using Newtonsoft.Json;

namespace RateLinx.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class AutoTracking
    {
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("Key")]
        public int key { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("Value")]
        public string value { get; set; }
    }
}
