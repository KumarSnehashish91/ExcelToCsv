﻿using Newtonsoft.Json;

namespace RateLinx.Models
{
    class TrackList
    {
        public string BolNum { get; set; }
        public int LiveTracking { get; set; }
        public int TrackingUpdate { get; set; }
        public int LD { get; set; }
        public int UD { get; set; }
        public string ProNum { get; set; }
        [JsonProperty("TrackID")]
        public string trackID { get; set; }
        [JsonProperty("ShipToAddress")]
        public string shipToAddress { get; set; }
        public int NotifyInRadius { get; set; }
        public bool IsNotificationSent { get; set; }
    }
}
