﻿using System.Collections.Generic;

namespace RateLinx.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class TrackShipment
    {
        /// <summary>
        /// 
        /// </summary>
        public string ResultMsg { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<ShipmentPos> ShipmentPos { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class ShipmentPos
    {
        /// <summary>
        /// 
        /// </summary>
        public string ClientID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string BolNum { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int LocID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string SCAC { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string TrackNum { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string ErrorMsg { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public List<Position> Positions { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class Position
    {
        /// <summary>
        /// 
        /// </summary>
        public string ReportedBy { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ReportedAt { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double Latitude { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double Longitude { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int Interval { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string City { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string State { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Country { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ActivityDescr { get; set; }
    }
}
