using System.Collections.Generic;

namespace RateLinx.Models
{
    /// <summary>
    /// Meta Tag of the shipment detailed class
    /// </summary>
    public class CarrierShipmentDetails
    {
        /// <summary>
        /// View As
        /// </summary>
        public string DeliverOnStr { get; set; }
        /// <summary>
        /// View As
        /// </summary>
        public string ViewAs { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public bool CanBid { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public bool CanBidAlterTerms { get; set; }
        /// <summary>
        /// AcceptedSSes
        /// </summary>
        public bool? AcceptedSSes { get; set; }
        /// <summary>
        /// View As
        /// </summary>
        public bool CanInvoice { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public bool CanAddTracking { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public bool BidWithDelDate { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public bool BidAsSCAC { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public string BidDeliveryDateTZ { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public bool CanResubmit { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public bool CanVoid { get; set; }
        /// <summary>
        /// To check if if the shipment could be unawarded or not
        /// </summary>
        public bool CanUnAward { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public bool CanBlock { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public bool NeedsNonOptReason { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public bool UsesBTFuel { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public bool HideFuel { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public string ClientID { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public string BolNum { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public int LocID { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public string ClientBolNum { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public string ProNum { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public string Mode { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public bool IsTest { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public bool IsMultiStop { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public string BidType { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public string PickupDate { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public string PickupStartTime { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public string PickupStr { get; set; }
        
        /// <summary>
        /// View As
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public string DateOpenedStr { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public double StartingPrice { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public string UnitsLbl { get; set; }
        /// <summary>
        /// View As
        /// </summary>
        public string UserCreated { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string DateAwardedStr { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string SentCarriers { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string InvoiceCreatedOn { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public double LowestPrice { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public string LowestPriceLbl { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public string DeadLineDate { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public string DeadLineStr { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string DeadLineUTC { get; set; }
        /// <summary>
        /// View As
        /// </summary>
        public string ReferenceLbl { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public string Reference { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Comments { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public string SCACStatement { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public string DriverID { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public bool CanAssignDriver { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public List<AssignableDriver> AssignableDrivers { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public int NotifyInRadius { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public List<Entry> Entries { get; set; } = new List<Entry>();

        /// <summary>
        /// 
        /// </summary>
        public List<OldEntry> OldEntries { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public List<Address> Addresses { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public List<LineDetail> LineDetails { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public List<SS> SSes { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public List<string> SupportFiles { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public List<Conversation> Conversations { get; set; }

        /// <summary>
        /// to contain tracking details
        /// </summary>
        public List<TrackDetail> TrackDetails { get; set; }
        /// <summary>
        /// View As
        /// </summary>
        public List<AllowedConversationToList> AllowedConversationToList { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public List<string> NonOptReasons { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<Content> Contents { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<string> AddlDocs { get; set; }
        /// <summary>
        /// If shipment is assigned to dispatcher
        /// </summary>
        public bool DispatchFlag { get; set; }
        /// <summary>
        /// Sacnned equipment attributes
        /// </summary>
        public List<Attribute> Attributes { get; set; }

    }

    /// <summary>
    /// 
    /// </summary>
    public class BidComment
    {
        /// <summary>
        /// 
        /// </summary>
        public string NonOptimalReason { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class OldEntry
    {
        /// <summary>
        /// 
        /// </summary>
        public string SCAC { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public double Price { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string EnteredOnStr { get; set; }
        
    }

    /// <summary>
    /// 
    /// </summary>
    public class Charge
    {
        /// <summary>
        /// 
        /// </summary>
        public string ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double Value { get; set; }
    }
    /// <summary>
    /// 
    /// </summary>
    public class Entry
    {
        
        /// <summary>
        /// 
        /// </summary>
        public bool CanAward { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool CanConfirm { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool CanDeny { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string SCAC { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string CarrierName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double Price { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool Winner { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool Altered { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string EnteredOnStr { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string AuthedBy { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string AuthedContact { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Comments { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string EntryType { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string DenyReason { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public string ContactName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string ContactPhone { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string ContactEmail { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<Charge> Charges { get; set; }
    }
    /// <summary>
    /// 
    /// </summary>
    public class Address
    {
        /// <summary>
        /// 
        /// </summary>
        public string Type { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Company { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Attention { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Address1 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Address2 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Address3 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Address4 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string City { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string State { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Zip { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Country { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Phone { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Email { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Fax { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string AccountNum { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string CurrentStatus { get; set; }
    }
    /// <summary>
    /// 
    /// </summary>
    public class LineDetail
    {
        /// <summary>
        /// 
        /// </summary>
        public int LineNum { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Order { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Item { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string NMFC { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int Pallets { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int Pieces { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string UOM { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool Haz { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Descr { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Class { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string FAK { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Weight { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double Length { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double Width { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double Height { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string AddlInfo { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int PUStop { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int DOStop { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class SS
    {
        /// <summary>
        /// 
        /// </summary>
        public string ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Value { get; set; }
    }

    /// <summary>
    /// Conversation Meta Class
    /// </summary>
    public class Conversation
    {
        /// <summary>
        /// 
        /// </summary>
        public int ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int Level { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int ReplyFor { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string FromClient { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string FromLoc { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string FromUser { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ReplyToUser { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Subject { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Message { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string TimeStamp { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool HasRead { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ClientType { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ToList { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<string> Attachments { get; set; }
    }

    /// <summary>
    /// Allow Conversation List
    /// </summary>
    public class AllowedConversationToList
    {
        /// <summary>
        /// View As
        /// </summary>
        public string Key { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public string Value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool Action { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class AssignableDriver
    {
        /// <summary>
        /// 
        /// </summary>
        public string Key { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Value { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class Content
    {
        /// <summary>
        /// 
        /// </summary>
        public string ProducerCountry { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ItemCode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ItemNumber { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Description { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Qty { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string UOM { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string UnitValue { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string DeclaredValue { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Weight { get; set; }
    }

    /// <summary>
    /// Scanned document 
    /// </summary>
    public class Attribute
    {
        /// <summary>
        /// Key
        /// </summary>
        public string Key { get; set; }
        /// <summary>
        /// Value
        /// </summary>
        public string Value { get; set; }
    }
}