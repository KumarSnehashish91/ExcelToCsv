﻿namespace RateLinx.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class GPSData
    {
        /// <summary>
        /// To store lat of current address
        /// </summary>
        public double Lattitude { get; set; }
        /// <summary>
        /// To store lng of current address
        /// </summary>
        public double Longitude { get; set; }
        /// <summary>
        /// To store City of current address
        /// </summary>
        public string City { get; set; }
        /// <summary>
        /// To store State of current address
        /// </summary>
        public string State { get; set; }
        /// <summary>
        /// To store Country of current address
        /// </summary>
        public string Country { get; set; }

    }
}
