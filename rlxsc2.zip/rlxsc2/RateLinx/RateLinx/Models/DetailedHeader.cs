namespace RateLinx.Models
{
    /// <summary>
    /// Shipments Detailed header 
    /// </summary>
    public class DetailedHeader
    {
        /// <summary>
        /// 
        /// </summary>
        public string Mode { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string LowestPriceLbl { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public double LowestPrice { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string PickupStr { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string ORIGIN { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string SHIPTO { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public double Weight { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int Pallets { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int Pieces { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Length { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Assign  { get; set; }
    }
}