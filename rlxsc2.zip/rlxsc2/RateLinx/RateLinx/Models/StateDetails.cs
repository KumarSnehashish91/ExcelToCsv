namespace RateLinx.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class StateDetails
    {
        /// <summary>
        /// 
        /// </summary>
        public string Code { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Country { get; set; }
    }
}