﻿namespace RateLinx.Models
{
    /// <summary>
    /// Get List of Live Tracking Saved Details
    /// </summary>
    public class LiveTrack
    {
        /// <summary>
        /// 
        /// </summary>
        public string Activity { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string City { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string State { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Country { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ActivityDescr { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Message { get; set; }

    }
}
