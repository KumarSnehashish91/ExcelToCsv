namespace RateLinx.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class TrackDetail
    {
        /// <summary>
        /// 
        /// </summary>
        public string Activity { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string City { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string State { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Country { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ActivityDescr { get; set; }
    }
}