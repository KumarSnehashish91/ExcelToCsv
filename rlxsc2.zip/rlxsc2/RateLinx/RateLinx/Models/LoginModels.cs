namespace RateLinx.Models
{
    /// <summary>
    /// Login Meta Tag
    /// </summary>
    public class LoginModels
    {
        /// <summary>
        /// 
        /// </summary>
        public string ClientID { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string FromApp { get; set; } = "Mobile";

        /// <summary>
        /// 
        /// </summary>
        public string FromDevice { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string[] Apps { get; set; } = { "Shipping" };
        /// <summary>
        /// Check for Remember Login details 
        /// </summary>
        public bool IsRemember { get; set; }
    }
}