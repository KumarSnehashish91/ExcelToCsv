using System;


namespace RateLinx.Models
{
    /// <summary>
    /// This class will hold the data for the History Result filter
    /// </summary>
    public class Filters
    {
        /// <summary>
        /// To hold the Action 
        /// </summary>
        public string Action { get; set; }

        /// <summary>
        /// To hold fromDate
        /// </summary>
        public DateTime FromDate { get; set; }

        /// <summary>
        /// To hold ToDate
        /// </summary>
        public DateTime ToDate { get; set; }

        /// <summary>
        /// To hold LoadNo
        /// </summary>
        public string LoadNo { get; set; }

        /// <summary>
        /// To hold ClientId
        /// </summary>
        public string ClientId { get; set; }
    }
}