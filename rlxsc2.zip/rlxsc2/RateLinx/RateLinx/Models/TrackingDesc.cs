using Newtonsoft.Json;

namespace RateLinx.Models
{
    /// <summary>
    /// Class to represent Tracking Description Value and text
    /// </summary>
    public class TrackingDesc
    {
        /// <summary>
        /// Tracking Description Value
        /// </summary>
        [JsonProperty("Value")]
        public string value { get; set; }
        /// <summary>
        /// Tracking Description text
        /// </summary>
        [JsonProperty("Text")]
        public string text { get; set; }
    }
}