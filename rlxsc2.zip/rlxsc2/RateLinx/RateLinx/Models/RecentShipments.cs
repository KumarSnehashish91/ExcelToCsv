namespace RateLinx.Models
{
    /// <summary>
    /// Meta tag for Recent Shipments Properties
    /// </summary>
    public class RecentShipments
    {
        /// <summary>
        /// 
        /// </summary>
        public string SCAC { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string BolNum { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string ClientID { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string OriginCompany { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string OriginAddress1 { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string OriginAddress2 { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipToAddress1 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipToAddress2 { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string ShipToCity { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipToState { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipToZip { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string OriginCity { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string OriginState { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string OriginZip { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string PickupStr { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string DriverID { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string DeliverOnStr { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string OriginEmail { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string OriginPhone { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public string ProNum { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int NotifyInRadius { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int LocID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Mode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string IsTest { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string BidType { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ViewAs { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool DispatchFlag { get; set; }
    }
}