﻿using Newtonsoft.Json;
using System;

namespace RateLinx.Models
{
    /// <summary>
    ///Daily Order History
    /// </summary>
    public class OrderHistory
    {
        /// <summary>
        /// 
        /// </summary>
        public string ClientID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string OrderID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string StoreID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTime TimeStamp { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTime OrderDate { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipTo_Attention { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipTo_Company { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipTo_Address1 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipTo_Address2 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipTo_City { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipTo_State { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipTo_Country { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipTo_Zip { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("IsCheckBoxChecked")]
        public bool isCheckBoxChecked { get; set; }
    }
}
