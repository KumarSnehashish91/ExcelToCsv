﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RateLinx.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class ScannedEquipmentKeyValue
    {
        /// <summary>
        /// 
        /// </summary>
        public string ScannedEquipKey { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ScannedEquipValue { get; set; }
    }
}
