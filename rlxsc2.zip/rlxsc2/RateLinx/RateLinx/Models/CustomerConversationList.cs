﻿namespace RateLinx.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class CustomerConversationList
    {
        /// <summary>
        /// View As
        /// </summary>
        public string Key { get; set; }

        /// <summary>
        /// View As
        /// </summary>
        public string Value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool Action { get; set; }
    }
}
