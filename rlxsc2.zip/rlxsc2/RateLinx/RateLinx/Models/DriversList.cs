﻿using System.Collections.Generic;

namespace RateLinx.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class DriversList
    {
        /// <summary>
        /// 
        /// </summary>
        public string ClientID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<Driver> Drivers { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class Driver
    {
        /// <summary>
        /// 
        /// </summary>
        public string ClientID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string UserID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string FullName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string LocID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string DateCreated { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Email { get; set; }
    }
}
