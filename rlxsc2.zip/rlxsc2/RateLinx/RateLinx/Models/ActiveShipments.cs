using System.Collections.Generic;

namespace RateLinx.Models
{
    /// <summary>
    /// Meta Tag of Active Shipments
    /// </summary>
    public class ActiveShipments
    {
        /// <summary>
        /// 
        /// </summary>
        public bool IsNew { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double LowestPrice { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string LowestPriceLbl { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string DeadLineStr { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string DeadLineUTC { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public string CarrierAlertLevel { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double CarriersBid { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<Bid> Bids { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ClientID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string BolNum { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int LocID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Mode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool IsTest { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string BidType { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string PickupStr { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ViewAs { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string DriverID { get; set; }
        /// <summary>
        /// Origin Address 1
        /// </summary>
        public string OriginAddress1 { get; set; }
        /// <summary>
        /// Origin Address 2
        /// </summary>
        public string OriginAddress2 { get; set; }
        /// <summary>
        /// Origin City
        /// </summary>
        public string OriginCity { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string OriginState { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string OriginZip { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipToAddress1 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipToAddress2 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipToCity { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipToState { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipToZip { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string TimerMessage { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool EnforceDeadline { get; set; }
    }   
    /// <summary>
    /// 
    /// </summary>
    public class Bid
    {
        /// <summary>
        /// 
        /// </summary>
        public bool CanAward { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool CanConfirm { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool CanDeny { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool IsNew { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Carrier { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double Price { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool AltTerms { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string EntryType { get; set; }
    }
}