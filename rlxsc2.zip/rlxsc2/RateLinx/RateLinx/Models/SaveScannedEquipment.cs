﻿using System.Collections.Generic;

namespace RateLinx.Models
{
    /// <summary>
    /// Save scanned equipments
    /// </summary>
    public class SaveScannedEquipment
    {
        /// <summary>
        /// Pickup scanned Num
        /// </summary>
        public string PickupNum { get; set; }
        /// <summary>
        /// Scanned Dropoff Num
        /// </summary>
        public string DropoffNum { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Stop { get; set; }
        /// <summary>
        /// OnSiteEquipNums
        /// </summary>
        public List<string> OnSiteEquipNums { get; set; }
    }
}
