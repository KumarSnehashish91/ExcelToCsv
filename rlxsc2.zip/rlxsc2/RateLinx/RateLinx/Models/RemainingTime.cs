namespace RateLinx.Models
{
    class RemainingTime
    {
        /// <summary>
        /// 
        /// </summary>
        public int Days { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int Hours { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int Minutes { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int Seconds { get; set; }
    }
}