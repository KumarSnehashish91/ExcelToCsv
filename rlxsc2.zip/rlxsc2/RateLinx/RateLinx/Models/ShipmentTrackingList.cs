﻿using Newtonsoft.Json;

namespace RateLinx.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class ShipmentTrackingList
    {
        /// <summary>
        /// 
        /// </summary>
        public string BolNum { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("LiveTracking")]
        public string liveTracking { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string trackingUpdate { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string LD { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string UD { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ProNum { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("TrackID")]
        public string trackID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("ShipToAddress")]
        public string shipToAddress { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string NotifyInRadius { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("IsNotificationSent")]
        public bool isNotificationSent { get; set; }
    }
}
