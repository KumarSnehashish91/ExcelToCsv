﻿using System.Collections.Generic;

namespace RateLinx.Models
{
    /// <summary>
    /// Compose Message
    /// </summary>
    public class ComposeMessage
    {
        /// <summary>
        /// 
        /// </summary>
        public int ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int Level { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int ReplyFor { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string FromClient { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string FromLoc { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string FromUser { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ReplyToUser { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Subject { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Message { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string TimeStamp { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool HasRead { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ClientType { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ToList { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<object> Attachments { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string ErrorMessage { get; set; }

    }
}
