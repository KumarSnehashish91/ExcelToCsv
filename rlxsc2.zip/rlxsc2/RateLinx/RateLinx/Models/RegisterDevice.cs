﻿namespace RateLinx.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class RegisterDevice
    {
        /// <summary>
        /// 
        /// </summary>
        public string App { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string DeviceID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string DeviceType { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string DeviceVer { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ServerToken { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool Enabled { get; set; }

    }
}
