namespace RateLinx.Models
{
    /// <summary>
    /// Meta tag of the File Array Class
    /// </summary>
    public class FileArray
    {
        /// <summary>
        /// Save As file name
        /// </summary>
        public string SaveAsFilename { get; set; }
        /// <summary>
        /// file Name
        /// </summary>
        public string ULFilename { get; set; }

    }
}