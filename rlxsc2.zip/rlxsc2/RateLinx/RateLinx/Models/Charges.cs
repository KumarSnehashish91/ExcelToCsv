namespace RateLinx.Models
{
    /// <summary>
    /// Meta tag of the class
    /// </summary>
    public class Charges
    {
        /// <summary>
        /// 
        /// </summary>
        public string ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Value { get; set; }
    }
}