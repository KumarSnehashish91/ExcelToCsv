﻿using Newtonsoft.Json;

namespace RateLinx.Models
{
    /// <summary>
    /// Set Location Details
    /// </summary>
    public class TrackLocation
    {
        /// <summary>
        /// Address
        /// </summary>
        [JsonProperty("Address")]
        public string address { get; set; }
        /// <summary>
        /// Address Type
        /// </summary>
        [JsonProperty("AddressType")]
        public string addressType { get; set; }
    }
}
