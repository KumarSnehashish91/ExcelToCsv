using System.Collections.Generic;


namespace RateLinx.Models
{
    /// <summary>
    /// Meta Tag For Account Settings
    /// </summary>
    public class AccountSettings
    {
        /// <summary>
        /// 
        /// </summary>
        public string UserID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string UserFullName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int UserLocID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string UserEmail { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string UserTimezone { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ClientType { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string ClientID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ClientCompany { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ClientDescr { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<string> Permissions { get; set; }
    }
}