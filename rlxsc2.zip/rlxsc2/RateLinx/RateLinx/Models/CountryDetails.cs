using System.Collections.Generic;

namespace RateLinx.Models
{
    /// <summary>
    /// Class to hold Country Details
    /// </summary>
    public class CountryDetails
    {
        /// <summary>
        /// For Country code
        /// </summary>
        public string Code { get; set; }
        /// <summary>
        /// For Country Name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// For list of states for specific country
        /// </summary>
        public List<StateDetails> States { get; set; }
    }
}