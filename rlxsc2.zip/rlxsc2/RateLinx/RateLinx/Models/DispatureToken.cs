﻿using Newtonsoft.Json;
using RateLinx.Helper;

namespace RateLinx.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class DispatureToken
    {
        /// <summary>
        /// 
        /// </summary>
       // [JsonProperty("StatusNum")]
        public int statusNum { get; set; }
        /// <summary>
        /// 
        /// </summary>
       // [JsonProperty("StatusMsg")]
        public string statusMsg { get; set; }
        /// <summary>
        /// 
        /// </summary>
       // [JsonProperty("ErrFlag")]
        public int errFlag { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("Data")]
        public TokenInfo data { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class TokenInfo
    {
        /// <summary>
        /// 
        /// </summary>
       // [JsonProperty("AccessToken")]
        public string accessToken { get; set; }
        /// <summary>
        /// 
        /// </summary>
       // [JsonProperty("ExpiresIn")]
        public int expiresIn { get; set; }
    }

    /// <summary>
    /// Token request
    /// </summary>
    public class TokenReq
    {
        /// <summary>
        /// 
        /// </summary>
       // [JsonProperty("ClientID")]
        public string clientID = Constants.clientID;
        /// <summary>
        /// 
        /// </summary>
      //  [JsonProperty("ClientSecret")]
        public string clientSecret = Constants.clientSecret;
        /// <summary>
        /// 
        /// </summary>
      //  [JsonProperty("GrantType")]
        public int grantType = Constants.grantType;
    }

    /// <summary>
    /// 
    /// </summary>
    public class AssignDriver
    {
        /// <summary>
        /// 
        /// </summary>
       // [JsonProperty("DriverID")]
        public string driverID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        //[JsonProperty("BolNum")]
        public string bolNum { get; set; }
        /// <summary>
        /// 
        /// </summary>
       // [JsonProperty("ClientID")]
        public string clientID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        //[JsonProperty("DispatcherID")]
        public string dispatcherID { get; set; }
        /// <summary>
        /// 
        /// </summary>
       // [JsonProperty("DispatcherToken")]
        public string dispatcherToken { get; set; }
    }

    /// <summary>
    /// Get the response of Assigned driver
    /// </summary>
    public class AssignDriverRes
    {
        /// <summary>
        /// 
        /// </summary>
       // [JsonProperty("StatusNum")]
        public int statusNum { get; set; }
        /// <summary>
        /// 
        /// </summary>
       // [JsonProperty("StatusMsg")]
        public string statusMsg { get; set; }
        /// <summary>
        /// 
        /// </summary>
       // [JsonProperty("ErrFlag")]
        public int errFlag { get; set; }
        /// <summary>
        /// 
        /// </summary>
       // [JsonProperty("Data")]
        public int data { get; set; }
    }
}
