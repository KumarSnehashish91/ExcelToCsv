﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace RateLinx.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class RealTimeShipmentStatus
    {
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("StatusNum")]
        public int statusNum { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("StatusMsg")]
        public string statusMsg { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("ErrFlag")]
        public int errFlag { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("Data")]
        public Data data { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class ShipmentActivity
    {
        /// <summary>
        /// 
        /// </summary>
        public string BolNum { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Msg { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double Time { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Lat { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Long { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class Data
    {
        /// <summary>
        /// 
        /// </summary>
        public string _id { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string BolNum { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("Activities")]
        public List<ShipmentActivity> Activities { get; set; }
     
    }

    /// <summary>
    /// 
    /// </summary>
    public class UpdateRealTimeStatus
    {
        /// <summary>
        /// 
        /// </summary>
       // [JsonProperty("DriverID")]
        public string driverID { get; set; }
        /// <summary>
        /// 
        /// </summary>
       // [JsonProperty("Status")]
        public string status { get; set; }
        /// <summary>
        /// 
        /// </summary>
       //[JsonProperty("BolNum")]
        public string bolNum { get; set; }

        /// <summary>
        /// 
        /// </summary>
       // [JsonProperty("Lat")]
        public string lat { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("long")]
        public string Long { get; set; }
        /// <summary>
        /// 
        /// </summary>
       //[JsonProperty("ClientID")]
        public string clientID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool ISMultistop { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Msg { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string MultistopCode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ShipConfReason { get; set; }
    }
}
