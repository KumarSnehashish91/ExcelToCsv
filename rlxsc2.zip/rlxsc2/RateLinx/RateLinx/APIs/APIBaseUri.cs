﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RateLinx.APIs
{
    /// <summary>
    /// Meta tag for the API
    /// </summary>
    public class APIBaseUri
    {
        /// <summary>
        /// Base URL of the API 
        /// </summary>
        //public static string baseUri = "https://myratelinx.com/rlx/api/v1/";
        public static string baseUri = "https://mobileapi.ratelinx.com/api/v1/";
        /// <summary>
        /// http://dayrunner.chetu.com:7002/  //http://172.16.11.13:7002/ // http://dispatchapi.ratelinxhosting.com
        /// </summary>
        //public static string node_BaseUri = "http://dispatchapi.ratelinxhosting.com/";
        //public static string node_BaseUri = "https://ratelinxdispatchapi.azurewebsites.net/";
        public static string node_BaseUri = "https://dispatcherapi.ratelinx.com/";
    }

    /// <summary>
    /// API Methods
    /// </summary>
    public class APIMethods
    {
        /// <summary>
        /// To authenticate the user
        /// </summary>
        public static string auth = "auth";
        /// <summary>
        /// Get the list of shipments
        /// </summary>
        public static string shipments = "shipmentrequests/realtime";
        /// <summary>
        /// Post the logger detail
        /// </summary>
        public static string logerror = "common/logerror";
        /// <summary>
        /// To redirect to the myratelinx.com website
        /// </summary>
        public static string getSSOurl = "auth/ssourl";
        /// <summary>
        /// To get History Result
        /// </summary>
        public static string getHistoryResult = "shipmentrequests";
        /// <summary>
        /// Get The All Type of shipments details
        /// </summary>
        public static string shipmentDetails = "shipmentrequests";
        /// <summary>
        /// Method to hide charges when Driver is logged in
        /// </summary>
        public static string getAccountDetails = "account";
        /// <summary>
        /// Block Shipment
        /// </summary>
        public static string Block = "block";
        /// <summary>
        /// Void the shipment
        /// </summary>
        public static string Void = "void";
        /// <summary>
        /// 
        /// </summary>
        public static string Shipment = "shipment";
        /// <summary>
        /// 
        /// </summary>
        public static string driverid = "driverid";
        /// <summary>
        /// 
        /// </summary>
        public static string supportfile = "shipmentrequests/fusupportfile";

        /// <summary>
        /// To get the list of contries
        /// </summary>
        public static string getCountry = "datalookup/country";

        /// <summary>
        /// Award The shipment
        /// </summary>
        public static string award = "award";
        /// <summary>
        /// To print Bol of the shipment when shipment status is closed by customer
        /// </summary>
        public static string printBoL = "docs";
        /// <summary>
        /// To unaward an specific shipment 
        /// </summary>
        public static string unAward = "unaward";

        /// <summary>
        /// To resubmit a shipment 
        /// </summary>
        public static string reSubmitShipment = "resubmit";

        /// <summary>
        /// Upload Invoice documnets
        /// </summary>
        public static string invoiceDocs = "shipmentrequests/fuinvoice";
        
        /// <summary>
        /// Save Invoice
        /// </summary>
        public static string invoice = "invoice";
        /// <summary>
        /// Get All Shipment Tracking Position
        /// </summary>
        public static string trackingPositions = "shipmentrequests/currenttrackingpositions";

        /// <summary>
        /// Get Specific Shipment Current Position
        /// </summary>
        public static string specTrackingPosition = "shipment/trackingposition?id=";

        /// <summary>
        /// Upload Compose Documents
        /// </summary>
        public static string composeDocs = "shipmentrequests/fumsg";
        /// <summary>
        /// 
        /// </summary>
        public static string gpsLocation = "gpslocation";
        /// <summary>
        /// 
        /// </summary>
        public static string tracking = "tracking";

        /// <summary>
        /// Register Device for push notification 
        /// </summary>
        public static string autoPushReg = "auth/pushreg";

        /// <summary>
        /// confirm Shipment on Place New Rate page
        /// </summary>
        public const string confirm = "confirm";

        /// <summary>
        /// deny Shipment
        /// </summary>
        public const string deny = "deny";

        /// <summary>
        /// 
        /// </summary>
        public const string signature = "signature";

        /// <summary>
        /// 
        /// </summary>
        public const string equipnumbers = "equipnumbers";

        /// <summary>
        /// In Conversation
        /// </summary>
        public const string msg = "msg";

        /// <summary>
        /// bid in New Rate
        /// </summary>
        public const string bid = "bid";

        /// <summary>
        /// 
        /// </summary>
        public const string node_Auth = "oauth/accessToken";
        /// <summary>
        /// 
        /// </summary>
        public const string node_GetShipmentStatus = "api/shipments/activityPath/";
        /// <summary>
        /// 
        /// </summary>
        public const string node_UpdateShipmentStatus = "api/driver/shipmentStatus";
        /// <summary>
        /// 
        /// </summary>
        public const string node_AssignDriver = "api/dispatcher/assignShipmentToDriverMobile";

        /// <summary>
        /// 
        /// </summary>
        public const string getOrders = "pickorders";
        /// <summary>
        /// 
        /// </summary>
        public const string getIDWiseOrders = "pickorders/{0}";
        /// <summary>
        /// 
        /// </summary>
        public const string approveOrders = "pickorders/{0}/approve";
        /// <summary>
        /// 
        /// </summary>
        public const string denyOrders = "pickorders/{0}/deny";
    }
}
